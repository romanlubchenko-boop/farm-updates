"""Веб-сервер ветаптеки.

Запуск:
    python3 web_app.py

Сервер слухає на http://127.0.0.1:5000 (можна змінити змінними оточення
HOST та PORT).
"""

from __future__ import annotations

import math
import os
import sys
import tempfile
import time
import json
import hashlib
import secrets
import subprocess
import updater
import licensing
import milk_excel
from datetime import date, datetime, timedelta
from io import BytesIO, StringIO
import zipfile
from pathlib import Path
import csv

from flask import (Flask, render_template, request, jsonify, send_file,
                   abort, session, redirect, url_for, Response)

from vet_pharmacy.web_db import WebInventoryDB


# Реквізити аптеки для товарного чека (редагуються у config/business.json)
BUSINESS_CONFIG_PATH = Path(__file__).resolve().parent / "config" / "business.json"
DEFAULT_BUSINESS = {
    "name": "Ветеринарна аптека",
    "entity": "ФОП ____________________",
    "edrpou": "________",
    "address": "м. ____________, вул. ____________",
    "phone": "+380 __ ___ __ __",
}


def load_business() -> dict:
    try:
        with open(BUSINESS_CONFIG_PATH, encoding="utf-8") as f:
            return {**DEFAULT_BUSINESS, **(json.load(f) or {})}
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return DEFAULT_BUSINESS


app = Flask(__name__, template_folder="web/templates", static_folder="web/static")
app.config["JSON_AS_ASCII"] = False
# Не кешувати статику браузером — щоб після оновлення коду користувач
# завжди отримував свіжі JS/CSS без ручного "жорсткого" перезавантаження.
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
# Перечитувати HTML-шаблони з диска при кожному запиті — щоб зміни розмітки
# застосовувались без перезапуску сервера (як і JS/CSS).
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.jinja_env.auto_reload = True

# Версія додатка — показуємо в боковій панелі, щоб при підтримці було видно,
# що в клієнта встановлено.
APP_VERSION = "1.66.2"


DEFAULT_UPDATE_SOURCE = "https://raw.githubusercontent.com/romanlubchenko-boop/farm-updates/main/latest.json"


def _effective_update_source() -> str:
    """Чинне джерело оновлень: локальна папка (якщо вказана) має пріоритет,
    інакше — стандартне вшите джерело (GitHub)."""
    local = (db.get_setting("update_local_dir", "") or "").strip()
    return local if local else DEFAULT_UPDATE_SOURCE
# Секретний ключ для підпису cookie-сесій. Зберігається на диску, щоб після
# перезапуску сервера існуючі сесії лишались валідними.
SECRET_FILE = Path(__file__).resolve().parent / "config" / "secret.key"


def _get_or_create_secret() -> str:
    if SECRET_FILE.exists():
        try:
            data = SECRET_FILE.read_text().strip()
            if data:
                return data
        except OSError:
            pass
    SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
    key = secrets.token_hex(32)
    SECRET_FILE.write_text(key)
    return key


app.config["SECRET_KEY"] = _get_or_create_secret()
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=14)

# --- Безпека cookie сесії ---
# HttpOnly: cookie недоступна для JS (захист від крадіжки через XSS).
# SameSite=Lax: cookie не йде на «чужі» крос-сайтові POST (помʼякшує CSRF).
# Secure (захищене зʼєднання) виставляється ПО-ЗАПИТНО: для https-відповідей —
# так (cookie не піде по http), для http://localhost (власний ПК) — ні, щоб
# не ламати локальний вхід. Це працює разом із редиректом http→https у мережі.
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# ── Серверний режим (Bovio, VPS): застосунок працює за nginx на своєму
# домені. Вимикає суто локальне (LAN-сертифікати, апдейтер, Excel-міст) і
# додає інтернет-гігієну (rate-limit логіну, довші паролі). Локальний режим
# (ферми на своїх ПК, як-от Перемога) НЕ зачіпається — прапорець вимкнено.
# Вмикається env-змінною (VPS) АБО файлом-маркером app/config/server_mode.flag
# (Mac Романа: config/ не потрапляє ні в пакети клієнтам, ні в деплой на сервер,
# тож маркер — суто локальний спосіб бачити «хмарний» вигляд у себе).
# env має пріоритет над маркером: "1" — увімкнути, "0" — примусово вимкнути
_sm_env = os.environ.get("FARM_SERVER_MODE", "")
SERVER_MODE = (_sm_env == "1" or (_sm_env != "0" and
               (Path(__file__).resolve().parent / "config" / "server_mode.flag").exists()))
DEMO_AUTOLOGIN = os.environ.get("BOVIO_DEMO_AUTOLOGIN") == "1"

# Прапорці тенанта (серверна версія): перелік ВИМКНЕНИХ модулів через кому в env
# тенанта, напр. BOVIO_FEATURES_OFF="materials,plan". Гілка зникає з меню і хаба
# та блокується напряму за URL. Порожньо (усі локальні клієнти) — все як було.
FEATURES_OFF = {t.strip() for t in
                os.environ.get("BOVIO_FEATURES_OFF", "").split(",") if t.strip()}


@app.context_processor
def _inject_server_mode():
    # server_mode у шаблонах: серверна версія ховає суто локальне
    # (Telegram-звіти, LAN-сертифікати тощо)
    return {"server_mode": SERVER_MODE}
if SERVER_MODE:
    from vet_pharmacy.web_db import WebInventoryDB as _WDB
    _WDB.MIN_PASSWORD_LEN = 8
if SERVER_MODE:
    # nginx термінує TLS: без ProxyFix request.is_secure=False і secure-cookie
    # не ставиться; X-Forwarded-* приходить рівно з одного проксі.
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

try:
    from flask.sessions import SecureCookieSessionInterface

    class _PerRequestSecureSession(SecureCookieSessionInterface):
        def get_cookie_secure(self, app):  # noqa: D401
            try:
                return bool(request.is_secure)
            except Exception:  # noqa: BLE001
                return False

    app.session_interface = _PerRequestSecureSession()
except Exception:  # noqa: BLE001
    pass

# Ліміт розміру запиту — щоб надто великий файл не забив памʼять/диск і не
# поклав сервер. 100 МБ із запасом для імпорту CSV / відновлення БД / пакета.
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024


@app.after_request
def _security_headers(resp):
    """Заголовки безпеки: проти sniffing, clickjacking, витоку referer; CSP
    замикає ресурси на власний домен (помʼякшує наслідки XSS); HSTS — лише
    для https-відповідей."""
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Content-Security-Policy", (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "media-src 'self' blob:; "
        "connect-src 'self'; "
        "worker-src 'self' blob:; "
        "object-src 'none'; base-uri 'self'; frame-ancestors 'none'"))
    # HSTS свідомо ВИМКНено (max-age=0). Для LAN-застосунку з власним CA він
    # шкодить: 1) робить будь-яку похибку сертифіката НЕпереборною — браузер
    # прибирає кнопку «Все одно продовжити», тож пристрій намертво втрачає
    # доступ; 2) змушує браузер підвищувати http→https ще до сервера, через що
    # ламається завантаження CA по HTTP (farm-ca.crt). max-age=0 ще й ЗНІМАЄ
    # раніше встановлені піни, щойно пристрій відкриє https — тобто лікує вже
    # «залиплі» телефони. HTTPS усе одно забезпечується редіректом і Secure-cookie.
    try:
        if request.is_secure:
            resp.headers["Strict-Transport-Security"] = "max-age=0"
    except Exception:  # noqa: BLE001
        pass
    return resp

# Версія статики = найсвіжіший час зміни файлів у static/. Підставляється
# у ?v=... до всіх <script> та <link>.
#
# Раніше тут стояв час старту сервера. Це давало підступний ефект: правиш
# JS у вже запущеному застосунку — версія та сама, браузер (і service worker)
# віддають стару копію, і виправлення «не доїжджає» без перезапуску. За
# часом зміни файлів версія оновлюється сама, щойно файл змінився.
#
# Обхід дерева кешуємо на кілька секунд, щоб не робити це на кожен запит.
_STATIC_DIR = Path(__file__).resolve().parent / "web" / "static"
_static_v_cache = {"value": "0", "checked": 0.0}


def _static_version() -> str:
    now = time.time()
    if now - _static_v_cache["checked"] < 3:
        return _static_v_cache["value"]
    newest = 0.0
    try:
        for p in _STATIC_DIR.rglob("*"):
            if p.is_file():
                m = p.stat().st_mtime
                if m > newest:
                    newest = m
    except OSError:
        newest = now
    _static_v_cache.update(value=str(int(newest)), checked=now)
    return _static_v_cache["value"]


STATIC_VERSION = _static_version()


@app.context_processor
def _inject_static_version():
    return {"static_v": _static_version(), "app_version": APP_VERSION}


@app.get("/sw.js")
def service_worker():
    """Service worker має лежати в корені, щоб охоплювати весь сайт (scope '/')."""
    resp = send_file(str(Path(app.static_folder) / "sw.js"),
                     mimetype="application/javascript")
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"
    return resp


# ===================================================================== гілки
# Платформа складається з кількох гілок виробництва. Аптека — перша готова
# гілка; решта поки заготовки, що наповнюються по ходу проекту.
BRANCHES = [
    {"id": "hub",       "label": "Головна",              "icon": "⌂",  "home": "/",          "ready": True,
     "desc": "Огляд усіх гілок виробництва"},
    # Стадо позначено «у розробці» (Роман 2026-09-04: ще не готове до показу);
    # гілка лишається клікабельною — бейдж лише чесно каже про статус.
    {"id": "herd",      "label": "Управління стада",     "icon": "🐄", "home": "/herd",      "ready": False,
     "desc": "Поголів'я, групи, переміщення, події (отелення, вибуття)"},
    {"id": "pharmacy",  "label": "Аптека",               "icon": "💊", "home": "/pharmacy",  "ready": True,
     "desc": "Прихід, видача на блоки, склад, терміни придатності, звіти"},
    {"id": "materials", "label": "Матеріали",            "icon": "📦", "home": "/m/pharmacy", "ready": True,
     "desc": "Облік ТМЦ: прихід, видача та залишки матеріалів"},
    {"id": "milk",      "label": "Виробництво молока",   "icon": "🥛", "home": "/milk",      "ready": True,
     "desc": "Надої та продаж молока з Excel: періоди, жир/білок, ціна"},
    {"id": "finance",   "label": "Фінанси та аналітика", "icon": "💵", "home": "/finance",   "ready": True,
     "desc": "Витрати з Excel, щоденна ефективність молочної ферми, аналітика"},
    # ready=False, доки не завершені етапи 2–5 (номенклатура, рецепти КК,
    # імпорт Profeed, аналітика). Каркас уже робочий, але клієнтам не показуємо.
    {"id": "feed",      "label": "Годівля",              "icon": "🌾", "home": "/f/pharmacy", "ready": True,
     "desc": "Склад кормів: прихід, комбікорми, списання з Profeed, витрати"},
    {"id": "standard",  "label": "Стандарт виробництва", "icon": "📐", "home": "/standard",  "ready": False,
     "desc": "Технологічні карти, нормативи й регламенти"},
    {"id": "plan",      "label": "План-прогноз",         "icon": "📈", "home": "/plan",      "ready": False,
     "desc": "Планування потреб, прогноз витрат і залишків"},
]

# Гілки, доступ до яких регулюється правами користувача (хаб і адмін — окремо)
PERMISSIONABLE_BRANCHES = {"herd", "pharmacy", "materials", "milk", "feed", "finance", "standard", "plan"}


def _branch_level(user, branch: str) -> str:
    """Рівень доступу користувача до гілки: 'view' | 'work' | 'manage'.

    Роман 2026-09-09: «хто може керувати гілкою, хто тільки передивлятися».
    Адмін — керує всім. Якщо користувачу гілки взагалі не роздавали, лишається
    попередня поведінка (повний доступ рівня 'work')."""
    if not user:
        return ""
    if user.get("role") == "admin":
        return "manage"
    levels = db.user_branch_levels(user["id"])
    if not levels:
        return "work"                      # нічого не задано — як було раніше
    return levels.get(branch, "")


def _user_work_place(user) -> str:
    """Де людині дозволено ВНОСИТИ зміни: 'any' | 'server' (браузер ферми) |
    'pc' (застосунок на компʼютері). Адміністратора не обмежуємо."""
    if not user or user.get("role") == "admin":
        return "any"
    try:
        return db.user_work_place(user["id"])
    except Exception:  # noqa: BLE001
        return "any"


def _work_place_ok(user) -> bool:
    place = _user_work_place(user)
    if place == "any":
        return True
    return place == ("server" if SERVER_MODE else "pc")


def _manage_guard(branch: str = ""):
    """Дія рівня «керування гілкою»: налаштування, довідники, імпорти.
    Адмін — завжди; звичайний користувач — лише з рівнем 'manage' на цю гілку."""
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if not u:
        return _err("Не авторизовано", 401)
    if not _work_place_ok(u):
        return _err(_WORK_PLACE_MSG[_user_work_place(u)], 403)
    if _branch_level(u, branch or _active_branch()) != "manage":
        return _err("Потрібні права керування цією гілкою.", 403)
    return None


_WORK_PLACE_MSG = {
    "server": "Ваші зміни вносяться у браузері на фермі, а не на цьому компʼютері.",
    "pc": "Ваші зміни вносяться у застосунку на компʼютері, а не тут.",
    "any": "",
}


def _allowed_branch_ids(user) -> set:
    """Які гілки доступні користувачу. Адмін — усі. Якщо для звичайного
    користувача нічого не задано — теж усі (без обмежень)."""
    if not user:
        return set()
    if user.get("role") == "admin":
        return set(PERMISSIONABLE_BRANCHES)
    assigned = set(db.list_user_branch_ids(user["id"]))
    return assigned if assigned else set(PERMISSIONABLE_BRANCHES)


def _licensed_branches():
    """Гілки, дозволені ліцензією (entitlements). None = без обмежень (усі).
    Береться з підписаного токена; старі/безлімітні ключі → усі гілки."""
    try:
        br = _license_status().get("branches")
    except Exception:  # noqa: BLE001
        return None
    if not br:
        return None
    return set(br)


def _licensed_branch_id_set() -> set:
    """Множина id гілок для шаблонів: дозволені ліцензією (+ hub завжди).
    Якщо ліцензія без обмежень — усі гілки."""
    lic = _licensed_branches()
    all_ids = {b["id"] for b in BRANCHES}
    if lic is None:
        return all_ids
    return (lic & all_ids) | {"hub"}


def _hidden_branch_ids() -> set:
    """Гілки, які адміністратор приховав у Налаштуваннях (не показувати в меню)."""
    raw = db.get_setting("hidden_branches", "")
    ids = set(FEATURES_OFF)  # вимкнені прапорцем тенанта — приховані завжди
    if not raw:
        return ids
    try:
        v = json.loads(raw)
        return (set(v) | ids) if isinstance(v, list) else ids
    except Exception:  # noqa: BLE001
        return ids


# Шляхи, що належать до гілки «Аптека» (решта — у своїх префіксах)
_PHARMACY_PATHS = {
    "/pharmacy", "/receive", "/sale", "/products", "/orders", "/expiry", "/reports",
    "/catalogs", "/settings", "/economics",
}


def _inv_category() -> str:
    """Категорія складського обліку за префіксом шляху:
    матеріали — під /m, корми (годівля) — під /f, решта — аптека."""
    p = request.path
    if p == "/m" or p.startswith("/m/"):
        return "materials"
    if p == "/f" or p.startswith("/f/"):
        return "feed"
    return "pharmacy"


def _active_branch() -> str:
    p = request.path
    # Гілка «Матеріали» — під префіксом /m, «Годівля» — під /f
    if p == "/m" or p.startswith("/m/"):
        return "materials"
    if p == "/f" or p.startswith("/f/"):
        return "feed"
    if p == "/" or p.startswith("/hub"):
        return "hub"
    # Користувачі та База даних — рівень платформи (над гілками)
    if p.startswith("/users") or p.startswith("/database"):
        return "admin"
    if p.startswith("/herd") or p.startswith("/api/herd"):
        return "herd"
    if p.startswith("/materials"):
        return "materials"
    if p.startswith("/milk") or p.startswith("/api/milk"):
        return "milk"
    if p.startswith("/finance") or p.startswith("/api/finance"):
        return "finance"
    if p.startswith("/standard"):
        return "standard"
    if p.startswith("/plan"):
        return "plan"
    if p in _PHARMACY_PATHS or p.startswith("/receipt"):
        return "pharmacy"
    return "pharmacy"


@app.context_processor
def _inject_branches():
    user = db.get_user(session["user_id"]) if "user_id" in session else None
    allowed = _allowed_branch_ids(user) if user else set(PERMISSIONABLE_BRANCHES)
    # Гілки, де користувачу дозволено офлайн-роботу (для пункту меню «Офлайн»)
    if user and user.get("role") == "admin":
        offline_ids = set(PERMISSIONABLE_BRANCHES)
    elif user:
        offline_ids = set(db.list_user_offline_branch_ids(user["id"]))
    else:
        offline_ids = set()
    _br = _active_branch()
    is_mat, is_feed = _br == "materials", _br == "feed"
    # Словоформи назви позиції — залежать від гілки
    if is_feed:
        item_words = {"nom": "Корм", "gen": "корму", "acc": "корм", "gen_pl": "кормів"}
    elif is_mat:
        item_words = {"nom": "Матеріал", "gen": "матеріалу",
                      "acc": "матеріал", "gen_pl": "матеріалів"}
    else:
        item_words = {"nom": "Препарат", "gen": "препарату",
                      "acc": "препарат", "gen_pl": "ветпрепаратів"}
    # Куди видається. У Годівлі це групи тварин (дійні/сухостій/молодняк),
    # в Аптеці й Матеріалах лишаються звичні блоки. Списки різні — блоки
    # зберігаються з прив'язкою до категорії гілки.
    if is_feed:
        block_words = {"nom": "Група тварин", "nom_pl": "Групи тварин",
                       "acc": "групу", "gen": "групи", "gen_pl": "груп",
                       "loc": "групі", "loc_pl": "групах"}
    else:
        block_words = {"nom": "Блок", "nom_pl": "Блоки",
                       "acc": "блок", "gen": "блоку", "gen_pl": "блоків",
                       "loc": "блоку", "loc_pl": "блоках"}
    return {
        "branches": BRANCHES,
        "active_branch": _active_branch(),
        "allowed_branch_ids": allowed,
        "licensed_branch_ids": _licensed_branch_id_set(),
        "hidden_branch_ids": _hidden_branch_ids(),
        "features_off": FEATURES_OFF,
        "mirror_view": {"on": _mirror_on(),
                        "last": db.get_setting("mirror_last_push", "")} if SERVER_MODE else {"on": False},
        "offline_branch_ids": offline_ids,
        "api_base": "/f" if is_feed else ("/m" if is_mat else ""),
        "item_words": item_words,
        "block_words": block_words,
    }


db = WebInventoryDB()
# Зафіксувати версію коду (для історії оновлень). Структура вже захищена
# копією перед міграцією всередині WebInventoryDB.
db.record_app_version(APP_VERSION)

# Міграція джерела оновлень: стандартне джерело — GitHub (вшите, DEFAULT_UPDATE_SOURCE),
# а змінне — необов'язкова локальна папка (update_local_dir). Якщо раніше в
# update_source була вказана локальна папка — переносимо її як локальне джерело.
if db.get_setting("update_local_dir", None) is None:
    _old_src = (db.get_setting("update_source", "") or "").strip()
    if _old_src and not _old_src.lower().startswith(("http://", "https://")):
        db.set_setting("update_local_dir", _old_src)
    else:
        db.set_setting("update_local_dir", "")

# Пільга на ознайомлення без ліцензії (днів від першого запуску).
TRIAL_DAYS = 14


def _license_status() -> dict:
    """Статус ліцензії + пільга на ознайомлення, якщо ліцензії ще немає."""
    try:
        st = licensing.status(db.get_setting("license_key", ""))
    except Exception:  # noqa: BLE001
        return {"state": "invalid", "read_only": True, "company": "", "expires": ""}
    if st.get("state") == "none":
        inst = db.get_setting("install_date", "")
        if not inst:
            inst = date.today().isoformat()
            db.set_setting("install_date", inst)
        try:
            used = (date.today() - datetime.strptime(inst, "%Y-%m-%d").date()).days
        except ValueError:
            used = 9999
        if used <= TRIAL_DAYS:
            st = dict(st, state="trial", read_only=False,
                      trial_left=max(0, TRIAL_DAYS - used))
    # Прив'язка до компанії: ключ має збігатися з «Моєю компанією» у програмі.
    cfg = (db.get_setting("company_name", "") or "").strip()
    st["company_name"] = cfg
    if cfg and st.get("company") and st.get("state") in ("active", "grace", "expired"):
        if cfg.casefold() != str(st["company"]).strip().casefold():
            st = dict(st, state="mismatch", read_only=True, company_name=cfg)
    # Ліцензія-оренда (захист ПК-версії, рішення Романа 2026-09-06): ключ із
    # lease_days вимагає живого зв'язку з сервером Bovio — кожен успішний обмін
    # дзеркала оновлює bovio_last_ok. Немає зв'язку довше за строк оренди →
    # лише-читання, доки обмін не відновиться. Ключі без lease_days — як були.
    ld = int(st.get("lease_days") or 0)
    if ld > 0 and st.get("state") in ("active", "grace"):
        anchor = (db.get_setting("bovio_last_ok", "") or "").strip() \
            or str(st.get("issued") or "")[:10]
        try:
            silent = (date.today()
                      - datetime.strptime(anchor[:10], "%Y-%m-%d").date()).days
        except ValueError:
            silent = 0
        st["lease_left"] = max(0, ld - silent)
        if silent > ld:
            st = dict(st, state="lease_expired", read_only=True, lease_days=ld)
    # Код активації цього ПК (для показу на сторінці «Ліцензія»).
    try:
        st["activation_code"] = licensing.activation_code()
    except Exception:  # noqa: BLE001
        st["activation_code"] = ""
    return st


# ===================================================================== auth

# Сторінки/шляхи, доступні без логіну
PUBLIC_PATHS = {"/login", "/logout", "/setup", "/sw.js", "/farm-cert.crt", "/farm-ca.crt",
                "/api/mirror/pull", "/api/mirror/push",
                "/api/satellite/ops", "/api/profeed/upload"}  # авторизація — власним токеном
# Сторінки й API-префікси, що доступні лише адміністраторам
ADMIN_PAGES = {"/economics", "/database", "/users", "/settings", "/license", "/audit", "/sync-conflicts"}
#: Сторінки налаштувань гілок — лише з рівнем «керування» цією гілкою
#: (перевіряються за закінченням шляху, бо гілки живуть під префіксами /m, /f).
_MANAGE_PAGE_SUFFIXES = ("/feed/settings", "/milk/settings", "/milk/notify",
                         "/notify", "/herd/structure")
ADMIN_API_PREFIXES = (
    "/api/economics", "/api/expense-categories", "/api/expenses",
    "/api/database", "/api/users", "/api/settings", "/api/license", "/api/audit",
    "/api/notify",
)


def _maybe_https_redirect():
    if SERVER_MODE:
        return None    # TLS робить nginx, редиректи — теж він
    """У мережевому режимі НЕ-локальний доступ по HTTP перенаправляємо на HTTPS,
    щоб логін і cookie сесії не йшли мережею у відкритому вигляді.

    Власний ПК по http://localhost лишаємо без змін (трафік не виходить у мережу),
    щоб не змушувати приймати самопідписаний сертифікат на робочому компʼютері."""
    if os.environ.get("FARM_NETWORK_MODE") != "1":
        return None
    try:
        if request.is_secure:
            return None
    except Exception:  # noqa: BLE001
        return None
    # Сертифікат CA мусить лишатися доступним по HTTP: новому пристрою він потрібен,
    # щоб HTTPS став довіреним. Якби ми редиректили його на HTTPS — вийшло б
    # замкнене коло (для HTTPS треба сертифікат, а сертифікат лише по HTTPS).
    if request.path in ("/farm-ca.crt", "/farm-cert.crt"):
        return None
    hostname = (request.host or "").split(":")[0].lower()
    if hostname in ("", "127.0.0.1", "localhost", "::1"):
        return None
    https_port = os.environ.get("FARM_HTTPS_PORT", "8443")
    target = f"https://{hostname}:{https_port}{request.full_path}"
    if target.endswith("?"):
        target = target[:-1]
    if request.method in ("GET", "HEAD"):
        return redirect(target, code=302)
    if request.path.startswith("/api/"):
        return jsonify({"ok": False,
                        "error": "Потрібне захищене зʼєднання (HTTPS)."}), 403
    return "Use HTTPS", 403


def _csrf_check():
    """Захист від CSRF для небезпечних методів: перевіряємо, що запит прийшов
    із нашого ж сайту (Origin/Referer збігається з хостом запиту). Razom із
    SameSite=Lax cookie це блокує крос-сайтові підроблені дії. Якщо ні Origin,
    ні Referer немає (рідкісні не-браузерні клієнти) — не блокуємо."""
    if request.method in ("GET", "HEAD", "OPTIONS", "TRACE"):
        return None
    from urllib.parse import urlparse
    host = (request.host or "").lower()
    for header in ("Origin", "Referer"):
        val = request.headers.get(header)
        if not val:
            continue
        if urlparse(val).netloc.lower() != host:
            if request.path.startswith("/api/") or request.path.startswith("/m/api/"):
                return jsonify({"ok": False,
                                "error": "Запит відхилено (захист CSRF)."}), 403
            return "Запит відхилено (захист CSRF).", 403
        return None
    return None


@app.before_request
def _check_auth():
    orig = request.path
    if orig.startswith("/static/") or orig == "/sw.js":
        # статику віддаємо обома протоколами (кешування SW), без редиректу
        return None
    # Мережевий режим: спершу гарантуємо HTTPS для не-локальних клієнтів
    _redir = _maybe_https_redirect()
    if _redir is not None:
        return _redir
    # Захист від CSRF на діях, що змінюють стан
    _csrf = _csrf_check()
    if _csrf is not None:
        return _csrf
    # Нормалізуємо префікс гілки матеріалів (/m) — щоб усі перевірки
    # (публічні шляхи, /api/, адмін-зони) працювали так само, як для аптеки.
    if orig == "/m":
        p = "/"
    elif orig.startswith("/m/"):
        p = "/" + orig[3:]
    else:
        p = orig
    # Перший запуск — користувачів іще немає → ведемо на /setup
    try:
        has_users = db.count_users() > 0
    except Exception:  # noqa: BLE001
        has_users = True   # БД ще не готова — не блокуємо
    if not has_users:
        # свіжий тенант-дзеркало: перший знімок із ПК має пройти ДО створення
        # користувачів (він і принесе їх разом із базою)
        if (p == "/setup" or p.startswith("/api/mirror/")
                or p == "/api/bovio/setup-pull"):
            return None
        return redirect(url_for("page_setup"))
    # Демо-ферма Bovio (env BOVIO_DEMO_AUTOLOGIN=1 лише в її тенанта):
    # відвідувач із сайту заходить БЕЗ логіна — сесія створюється сама.
    # База демо все одно скидається щоночі, тож ризику немає.
    if DEMO_AUTOLOGIN and "user_id" not in session and has_users:
        try:
            _du = next((u for u in db.list_users()
                        if u.get("is_active") and u.get("role") == "admin"), None)
            if _du:
                session.permanent = True
                session["user_id"] = _du["id"]
        except Exception:  # noqa: BLE001
            pass
    if p in PUBLIC_PATHS:
        return None
    # Перевірка сесії
    if "user_id" not in session:
        if p.startswith("/api/"):
            return jsonify({"ok": False, "error": "Не авторизовано"}), 401
        return redirect(url_for("page_login", next=orig))
    # Користувач може бути деактивований або видалений
    user = db.get_user(session["user_id"])
    if not user or not user.get("is_active"):
        session.clear()
        if p.startswith("/api/"):
            return jsonify({"ok": False, "error": "Сесію завершено"}), 401
        return redirect(url_for("page_login"))
    # Оновлюємо last_seen користувача (тихо, не блокуючи запит)
    try:
        db.touch_user(user["id"])
    except Exception:  # noqa: BLE001
        pass
    # Обмеження адмін-зон для не-адмінів
    is_admin_area = (p in ADMIN_PAGES
                     or any(p.startswith(pre) for pre in ADMIN_API_PREFIXES))
    if is_admin_area and user["role"] != "admin":
        if p.startswith("/api/"):
            return jsonify({"ok": False, "error": "Доступ заборонено"}), 403
        return ("<h1>Доступ заборонено</h1>"
                "<p>Ця сторінка доступна лише адміністратору. "
                "<a href='/'>На головну</a></p>"), 403
    # Місце роботи: людині призначено вносити зміни або в браузері на фермі,
    # або на своєму ПК. У «чужому» місці лишається перегляд (Роман: «так буде
    # менше помилок»). Власний пароль і оновлення застосунку не чіпаємо.
    if request.method not in ("GET", "HEAD", "OPTIONS") and not _work_place_ok(user):
        if not p.startswith(("/api/account", "/api/update", "/api/database")):
            msg = _WORK_PLACE_MSG[_user_work_place(user)]
            if p.startswith("/api/"):
                return jsonify({"ok": False, "error": msg}), 403
            return ("<h1>Лише перегляд</h1><p>" + msg
                    + " <a href='/'>На головну</a></p>"), 403
    # Сторінки НАЛАШТУВАНЬ гілки — рівень «керування». Інакше вони
    # відкривалися б, а кнопка «Зберегти» відповідала відмовою.
    if any(p.endswith(suf) for suf in _MANAGE_PAGE_SUFFIXES):
        _b = _active_branch()
        if _b in PERMISSIONABLE_BRANCHES and _branch_level(user, _b) != "manage":
            return ("<h1>Немає доступу</h1><p>Налаштування цієї гілки доступні "
                    "лише з правом «керування». <a href='/'>На головну</a></p>"), 403
    # Доступ до гілки виробництва за правами користувача
    branch = _active_branch()
    if branch in PERMISSIONABLE_BRANCHES:
        allowed = _allowed_branch_ids(user)
        # Рівень «перегляд» — жодних змін у цій гілці
        if (request.method not in ("GET", "HEAD", "OPTIONS")
                and branch in allowed
                and _branch_level(user, branch) == "view"):
            if p.startswith("/api/"):
                return jsonify({"ok": False,
                                "error": "Ця гілка вам доступна лише для перегляду."}), 403
            return ("<h1>Лише перегляд</h1><p>Ця гілка вам доступна лише для "
                    "перегляду. <a href='/'>На головну</a></p>"), 403
        if branch not in allowed:
            if p.startswith("/api/"):
                return jsonify({"ok": False, "error": "Немає доступу до цієї гілки"}), 403
            return ("<h1>Немає доступу</h1>"
                    "<p>Ця гілка вам недоступна. "
                    "<a href='/'>На головну</a></p>"), 403
        # Модуль вимкнено прапорцем тенанта (BOVIO_FEATURES_OFF)
        if branch in FEATURES_OFF:
            if p.startswith("/api/"):
                return jsonify({"ok": False,
                                "error": "Цей модуль вимкнено для вашої ферми"}), 403
            return ("<h1>Модуль вимкнено</h1>"
                    "<p>Цей модуль вимкнено для вашої ферми. "
                    "<a href='/'>На головну</a></p>"), 403
        # Обмеження ліцензії: гілка не входить у ваш ключ
        lic = _licensed_branches()
        if lic is not None and branch not in lic:
            if p.startswith("/api/"):
                return jsonify({"ok": False,
                                "error": "Гілка недоступна за вашою ліцензією"}), 403
            return ("<h1>Гілка недоступна за вашою ліцензією</h1>"
                    "<p>Ця гілка не входить у ваш ліцензійний ключ. "
                    "Щоб її увімкнути, зверніться до постачальника. "
                    "<a href='/license'>Ліцензія</a> · <a href='/'>На головну</a></p>"), 403
    # Супутник: дозволені лише операції, які вміє черга (штрихкодні складські),
    # решта запису — на серверній фермі (інакше зникли б при оновленні знімком).
    if (request.method not in ("GET", "HEAD", "OPTIONS") and not SERVER_MODE
            and db.get_setting("bovio_satellite", "0") == "1"
            and p.startswith("/api/")):
        # Дії САМОГО ПК (оновлення застосунку, ліцензія цього компʼютера,
        # власний пароль, копії бази) — не дані ферми, тож дозволені завжди.
        # Роман 2026-09-08: «в режимі супутника оновиться?» — ні, не оновлювався:
        # POST /api/update/apply падав у 403 і кнопка оновлення не працювала.
        _SAT_OK = ("/api/sale", "/api/receive", "/api/products", "/api/adjust",
                   "/api/batches", "/api/bovio", "/api/satellite",
                   "/api/account", "/api/database", "/api/sync",
                   "/api/update", "/api/license")
        if not any(p.startswith(x) for x in _SAT_OK):
            return jsonify({"ok": False, "error":
                            "Супутниковий режим: ця дія доступна лише на "
                            "серверній фермі (у браузері)."}), 403
    # Дзеркало: облік ведеться локально на ПК — у браузері лише перегляд.
    if (request.method not in ("GET", "HEAD", "OPTIONS") and _mirror_on()
            and p.startswith("/api/") and not p.startswith("/api/mirror")):
        return jsonify({"ok": False,
                        "error": "Ферма ведеться локально на ПК — у браузері "
                                 "лише перегляд."}), 403
    # Ліцензія: у режимі лише-читання блокуємо операції-зміни (крім дозволених).
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        st = _license_status()
        if st.get("read_only") and p.startswith("/api/"):
            allowed = ("/api/license", "/api/database", "/api/analytics",
                       "/api/update", "/api/account/password", "/api/notify")
            if not any(p.startswith(a) for a in allowed):
                return jsonify({
                    "ok": False, "license": st.get("state"),
                    "error": "Ліцензія неактивна — режим лише для читання. "
                             "Активуйте ліцензію на сторінці «Ліцензія»."}), 403
    return None


@app.context_processor
def _inject_manage():
    """`can_manage` у шаблонах: гілки, де людина має рівень «керування».
    Через нього ховаємо ⚙ і керівні кнопки — раніше вони були привʼязані до
    ролі адміністратора, і користувач із «керуванням» їх не бачив
    (Роман 2026-09-09: «у Надії не видно ⚙»)."""
    try:
        u = db.get_user(session["user_id"]) if "user_id" in session else None
        if not u:
            return {"can_manage": set()}
        if u.get("role") == "admin":
            return {"can_manage": set(PERMISSIONABLE_BRANCHES)}
        return {"can_manage": {b for b in PERMISSIONABLE_BRANCHES
                               if _branch_level(u, b) == "manage"}}
    except Exception:  # noqa: BLE001
        return {"can_manage": set()}


@app.context_processor
def _inject_work_place():
    """Банер «тут лише перегляд», коли людині призначено вносити зміни в
    іншому місці (у браузері ферми або на своєму ПК)."""
    try:
        u = db.get_user(session["user_id"]) if "user_id" in session else None
        if u and not _work_place_ok(u):
            return {"work_place_ro": _WORK_PLACE_MSG[_user_work_place(u)]}
    except Exception:  # noqa: BLE001
        pass
    return {"work_place_ro": ""}


@app.context_processor
def _inject_satellite():
    """satellite_on у шаблонах: ПК-копія ховає те, що робить серверна ферма
    (напр. вивантаження на сервер аналітики — інакше два джерела в одну схему)."""
    try:
        return {"satellite_on": (not SERVER_MODE
                                 and db.get_setting("bovio_satellite", "0") == "1")}
    except Exception:  # noqa: BLE001
        return {"satellite_on": False}


@app.context_processor
def _inject_license():
    try:
        return {"license": _license_status()}
    except Exception:  # noqa: BLE001
        return {"license": {"state": "none", "read_only": False}}


@app.context_processor
def _inject_access_urls():
    try:
        return {"access_urls": _access_urls()}
    except Exception:  # noqa: BLE001
        return {"access_urls": {}}


@app.context_processor
def _inject_current_user():
    user = None
    if "user_id" in session:
        try:
            user = db.get_user(session["user_id"])
            if user:
                user.pop("password_hash", None)
        except Exception:  # noqa: BLE001
            user = None
    return {"current_user": user}




# ===================================================================== pages

@app.route("/")
def page_hub():
    return render_template("hub.html", active="hub")


@app.route("/pharmacy")
def page_dashboard():
    # Гілка «Годівля»: огляд = зведення «Результат годівлі».
    if _active_branch() == "feed":
        return render_template("feed_result.html", active="dashboard")
    return render_template("dashboard.html", active="dashboard")


@app.route("/herd")
def page_herd():
    return render_template("herd.html", active="herd")


@app.route("/herd/animals")
def page_herd_animals():
    """Реєстр тварин (поголівний облік)."""
    return render_template("herd_animals.html", active="herd_animals")


@app.route("/herd/params")
def page_herd_params():
    """Налаштування параметрів тварин (стандартні + власні)."""
    return render_template("herd_params.html", active="herd_params")


@app.route("/herd/events")
def page_herd_events():
    """Налаштування типів подій (які параметри змінюють)."""
    return render_template("herd_events.html", active="herd_events")


@app.route("/herd/animals/<int:animal_id>")
def page_herd_animal_card(animal_id: int):
    """Картка тварини: параметри плитками за секціями + події."""
    return render_template("herd_animal_card.html", active="herd_animals",
                           animal_id=animal_id)


@app.route("/herd/log")
def page_herd_log():
    """Журнал подій: проведення подій по тваринах + стрічка останніх."""
    return render_template("herd_log.html", active="herd_log")


@app.route("/herd/settings")
def page_herd_settings():
    """Налаштування стада: секції (категорія з довідника) + періоди."""
    return render_template("herd_settings.html", active="herd_settings")


@app.route("/materials")
def page_materials():
    return render_template("materials.html", active="materials")


@app.route("/standard")
def page_standard():
    return render_template("standard.html", active="standard")


@app.route("/plan")
def page_plan():
    return render_template("plan.html", active="plan")


@app.route("/receive")
def page_receive():
    return render_template("receive.html", active="receive")


@app.route("/sale")
def page_sale():
    # Нова видача (накладні + історія, дизайн 2026-09) — для аптеки й
    # матеріалів; годівля лишається на старій сторінці (таблиця по днях,
    # «не корм», Profeed-специфіка).
    if _active_branch() in ("pharmacy", "materials"):
        return render_template("vydacha.html", active="sale")
    return render_template("sale.html", active="sale")


@app.route("/products")
def page_products():
    return render_template("products.html", active="products")


@app.route("/orders")
def page_orders():
    # Схеми — лише для аптеки. У матеріалах сторінки немає (прямий /m/orders → огляд).
    if _active_branch() == "materials":
        return redirect("/m/pharmacy")
    return render_template("orders.html", active="orders")


@app.route("/expiry")
def page_expiry():
    return render_template("expiry.html", active="expiry")


@app.route("/reports")
def page_reports():
    return render_template("reports.html", active="reports")


@app.route("/scan")
def page_scan():
    # Окрема миттєва сторінка-сканер більше не використовується — скан тепер
    # наповнює СПІЛЬНИЙ кошик на сторінці Видачі (без миттєвого проведення).
    base = "/m" if request.path.startswith("/m/") else ""
    return redirect(base + "/sale")


def _scanner_url() -> str:
    """HTTPS-адреса для телефона (лише коли увімкнено мережевий режим).
    Веде на форму Видачі — скан наповнює список, користувач проводить сам."""
    if not _server_mode_enabled():
        return ""
    ip = _lan_ip()
    if not ip:
        return ""
    port = os.environ.get("FARM_HTTPS_PORT", "8443")
    return f"https://{ip}:{port}/sale"


@app.get("/api/scan-url")
def api_scan_url():
    url = _scanner_url()
    return _ok({"enabled": bool(url), "url": url})


def _phone_base_url() -> str:
    """Коренева HTTPS-адреса для телефона (камера + офлайн/PWA).
    Працює лише у мережевому режимі — інакше порожньо."""
    if not _server_mode_enabled():
        return ""
    ip = _lan_ip()
    if not ip:
        return ""
    port = os.environ.get("FARM_HTTPS_PORT", "8443")
    return f"https://{ip}:{port}/"


def _phone_base_url_host() -> str:
    """HTTPS-адреса для телефона за ІМЕНЕМ цього ПК у mDNS-формі «name.local».
    Резолвиться телефонами через Bonjour (iPhone — стабільно, Android — здебільшого)."""
    if not _server_mode_enabled():
        return ""
    host = _hostname()
    if not host:
        return ""
    port = os.environ.get("FARM_HTTPS_PORT", "8443")
    return f"https://{host}.local:{port}/"


@app.get("/api/phone-url")
def api_phone_url():
    base = _phone_base_url()
    u = _access_urls()
    return _ok({"enabled": bool(base), "url": base,
                "url_host": _phone_base_url_host(),
                "url_cert": (u.get("cert_http") if u else "")})


def _hostname() -> str:
    """Коротке ім'я цього ПК (без домену)."""
    import socket
    try:
        h = socket.gethostname() or ""
        return h.split(".")[0].strip()
    except Exception:  # noqa: BLE001
        return ""


def _access_urls() -> dict:
    """Адреси доступу за ІМЕНЕМ цього ПК — для роботи з інших ПК у мережі.
    Працює лише у мережевому режимі. http — для звичайної роботи,
    https — для камери/офлайну (ім'я ПК вписане у сертифікат)."""
    if not _server_mode_enabled():
        return {}
    host = _hostname()
    if not host:
        return {}
    http_port = os.environ.get("FARM_HTTP_PORT", "5050")
    https_port = os.environ.get("FARM_HTTPS_PORT", "8443")
    ip = _lan_ip()
    return {
        "host": host,
        # для інших ПК (Windows резолвить коротке ім'я через NetBIOS)
        "http": f"http://{host}:{http_port}/",
        "https": f"https://{host}:{https_port}/",
        # для телефона — mDNS-форма «name.local» (Bonjour): резолвиться на iPhone/Android
        "http_mdns": f"http://{host}.local:{http_port}/",
        "https_mdns": f"https://{host}.local:{https_port}/",
        "ip_https": _phone_base_url(),   # https за IP — найнадійніше для телефона
        # Сертифікат: HTTP за IP — для нового телефона найнадійніше (HTTP не
        # потребує самого сертифіката, а IP не залежить від mDNS).
        "cert_http": f"http://{ip}:{http_port}/farm-ca.crt" if ip else "",
    }


@app.get("/api/access-urls")
def api_access_urls():
    u = _access_urls()
    return _ok({"enabled": bool(u), "urls": u})


@app.get("/phone-qr.png")
def phone_qr_png():
    base = _phone_base_url()
    if not base:
        return _err("Мережевий доступ вимкнено", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(base, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.get("/phone-qr-host.png")
def phone_qr_host_png():
    base = _phone_base_url_host()
    if not base:
        return _err("Мережевий доступ вимкнено", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(base, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.get("/phone-qr-host-http.png")
def phone_qr_host_http_png():
    u = _access_urls()
    base = u.get("http_mdns") if u else ""
    if not base:
        return _err("Мережевий доступ вимкнено", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(base, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.get("/phone-qr-cert.png")
def phone_qr_cert_png():
    """QR прямо на завантаження сертифіката (HTTP за IP). Скан → сертифікат
    одразу качається у браузер, без потреби заходити в застосунок."""
    u = _access_urls()
    base = u.get("cert_http") if u else ""
    if not base:
        return _err("Мережевий доступ вимкнено", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(base, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


def _state_dir_path() -> Path:
    """Локальна папка стану (де лежать сертифікати)."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "FarmDB"


def _ca_pem_path() -> Path:
    return _state_dir_path() / "farm_ca.pem"


def _serve_ca():
    """Віддати КОРІНЬ (CA) для встановлення на телефон/планшет.
    Саме CA треба зробити довіреним — тоді сервер-сертифікати під ним валідні,
    і офлайн (Service Worker) на iOS працює надійно. Без логіну."""
    p = _ca_pem_path()
    if not p.exists():
        return _err("Сертифікат ще не створено — увімкніть мережевий режим і перезапустіть сервер.", 404)
    # без attachment — щоб Safari на iPhone запропонував встановити профіль
    return send_file(str(p), mimetype="application/x-x509-ca-cert",
                     as_attachment=False, download_name="farm-ca.crt")


@app.get("/farm-ca.crt")
def farm_ca_download():
    return _serve_ca()


@app.get("/farm-cert.crt")
def farm_cert_download():
    # сумісність зі старим посиланням — теж віддаємо КОРІНЬ (CA)
    return _serve_ca()


def _cart_key(cat: str) -> str:
    return "draft_cart_" + (cat or "pharmacy")


def _cart_load(cat: str) -> list:
    raw = db.get_setting(_cart_key(cat), "")
    if not raw:
        return []
    try:
        v = json.loads(raw)
        return v if isinstance(v, list) else []
    except Exception:  # noqa: BLE001
        return []


def _cart_save(cat: str, cart: list) -> None:
    db.set_setting(_cart_key(cat), json.dumps(cart, ensure_ascii=False))


@app.get("/api/cart")
def api_cart_get():
    return _ok({"cart": _cart_load(_inv_category() or "pharmacy")})


@app.post("/api/cart/scan")
def api_cart_scan():
    """Додати товар у СПІЛЬНИЙ кошик (без проведення). Атомарно зливає на сервері."""
    data = request.get_json(silent=True) or {}
    bc = (data.get("barcode") or "").strip()
    try:
        qty = float(data.get("qty") or 1)
    except (TypeError, ValueError):
        qty = 1.0
    product = db.get_product_by_barcode(bc)
    if not product:
        return _err("Товар не знайдено", 404)
    cat = _inv_category() or "pharmacy"
    cart = _cart_load(cat)
    line = next((l for l in cart if l.get("id") == product["id"]
                 and not l.get("block_id") and not l.get("recipient_id")), None)
    if line:
        line["qty"] = float(line.get("qty") or 0) + qty
    else:
        cart.append({"id": product["id"], "name": product["name"],
                     "barcode": product["barcode"], "unit": product.get("unit", ""),
                     "qty": qty, "stock": product.get("total_qty", 0),
                     "block_id": "", "recipient_id": ""})
    _cart_save(cat, cart)
    return _ok({"cart": cart, "added": product["name"]})


@app.post("/api/cart/save")
def api_cart_save():
    data = request.get_json(silent=True) or {}
    cart = data.get("cart")
    if not isinstance(cart, list):
        return _err("Невірний формат кошика")
    _cart_save(_inv_category() or "pharmacy", cart)
    return _ok({})


@app.post("/api/cart/clear")
def api_cart_clear():
    _cart_save(_inv_category() or "pharmacy", [])
    return _ok({})


# ── Спільна накладна (прихід) ──────────────────────────────────────────────
def _inv_key(cat: str) -> str:
    return "draft_invoice_" + (cat or "pharmacy")


def _inv_load(cat: str) -> dict:
    raw = db.get_setting(_inv_key(cat), "")
    if not raw:
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {}
    except Exception:  # noqa: BLE001
        return {}


def _inv_save(cat: str, inv: dict) -> None:
    db.set_setting(_inv_key(cat), json.dumps(inv, ensure_ascii=False))


@app.get("/api/invoice")
def api_invoice_get():
    return _ok({"invoice": _inv_load(_inv_category() or "pharmacy")})


@app.post("/api/invoice/scan")
def api_invoice_scan():
    """Додати товар у СПІЛЬНУ накладну (без збереження). Шапку не чіпає.

    Каскад: склад → каталог → новий. Якщо товару немає на складі, але він є
    в каталозі — створюємо товар з даних каталогу й додаємо. Якщо немає й там —
    повертаємо 404 (фронтенд відкриє форму «Новий товар»)."""
    data = request.get_json(silent=True) or {}
    bc = (data.get("barcode") or "").strip()
    cat = _inv_category() or "pharmacy"
    product = db.get_product_by_barcode(bc)
    from_catalog = False
    if not product:
        cat_item = db.get_catalog_by_barcode(bc, cat)
        if not cat_item:
            return _err("Товар не знайдено", 404)
        # Є в каталозі — створюємо товар складу з даних каталогу.
        try:
            db.add_product(
                name=cat_item["name"], barcode=bc,
                unit=cat_item.get("unit", "шт"), min_stock=0,
                supplier="", notes="", code="", category=cat)
        except Exception as exc:  # noqa: BLE001
            return _err(str(exc) or "Не вдалося створити товар з каталогу")
        product = db.get_product_by_barcode(bc)
        from_catalog = True
        if not product:
            return _err("Товар не знайдено", 404)
    inv = _inv_load(cat)
    items = inv.get("items")
    if not isinstance(items, list):
        items = []
    vat = "0" if inv.get("vatMode") == "without" else "20"
    items.append({"barcode": product["barcode"], "name": product["name"],
                  "unit": product.get("unit", ""), "vat_rate": vat,
                  "price_in_no_vat": "", "price_in": "", "qty": "1",
                  "lot_number": "", "expires_on": ""})
    inv["items"] = items
    _inv_save(cat, inv)
    return _ok({"invoice": inv, "added": product["name"],
                "from_catalog": from_catalog})


# ── Каталог препаратів/матеріалів (довідник) ───────────────────────────────
@app.get("/api/catalog")
def api_catalog_list():
    cat = _inv_category() or "pharmacy"
    q = (request.args.get("q") or "").strip()
    return _ok({"items": db.list_catalog(cat, q)})


@app.post("/api/catalog")
def api_catalog_save():
    data = request.get_json(silent=True) or {}
    cat = _inv_category() or "pharmacy"
    try:
        item_id = db.upsert_catalog_item(
            barcode=data.get("barcode", ""), name=data.get("name", ""),
            unit=data.get("unit", "шт"), category=cat)
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": item_id})


@app.delete("/api/catalog/<int:item_id>")
def api_catalog_delete(item_id: int):
    cat = _inv_category() or "pharmacy"
    if db.delete_catalog_item(item_id, cat):
        return _ok({})
    return _err("Запис не знайдено", 404)


def _catalog_read_csv(raw: bytes) -> list[list[str]]:
    text = None
    for enc in ("utf-8-sig", "utf-8", "cp1251", "windows-1251", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except Exception:  # noqa: BLE001
            continue
    if text is None:
        text = raw.decode("utf-8", errors="replace")
    lines = text.splitlines()
    if not lines:
        return []
    # Визначаємо роздільник: пробуємо Sniffer, інакше — найчастіший у шапці
    delim = ";"
    try:
        delim = csv.Sniffer().sniff("\n".join(lines[:10]),
                                    delimiters=";,\t|").delimiter
    except Exception:  # noqa: BLE001
        delim = max([";", ",", "\t", "|"], key=lambda d: lines[0].count(d))
    rdr = csv.reader(StringIO(text), delimiter=delim)
    return [list(r) for r in rdr if any((c or "").strip() for c in r)]


def _catalog_read_xlsx(raw: bytes) -> list[list[str]]:
    from openpyxl import load_workbook
    wb = load_workbook(BytesIO(raw), read_only=True, data_only=True)
    ws = wb.active
    out: list[list[str]] = []
    for row in ws.iter_rows(values_only=True):
        cells = ["" if c is None else str(c) for c in row]
        if any(c.strip() for c in cells):
            out.append(cells)
    wb.close()
    return out


def _catalog_detect_columns(headers: list[str],
                            sample: list[list[str]]) -> dict:
    lc = [(h or "").strip().casefold() for h in headers]

    def find(keys):
        for i, h in enumerate(lc):
            if any(k in h for k in keys):
                return i
        return None

    name_i = find(["назв", "наймен", "препарат", "товар", "name", "product"])
    bc_i = find(["штрих", "barcode", "ean", "штрих-код", "штрихкод"])
    unit_i = find(["один", "од.", "одиниц", "unit", "фасов"])
    ncols = max((len(r) for r in sample), default=0)
    # Якщо назву не знайдено за заголовком — беремо найдовший «текстовий» стовпець
    if name_i is None and ncols:
        best, best_len = None, -1.0
        for c in range(ncols):
            vals = [(r[c] if c < len(r) else "").strip() for r in sample]
            texty = [v for v in vals if v and not v.replace(" ", "").isdigit()]
            if not texty:
                continue
            avg = sum(len(v) for v in texty) / len(texty)
            if avg > best_len:
                best_len, best = avg, c
        name_i = best
    # Якщо штрихкод не знайдено — стовпець, де значення схожі на EAN (8–14 цифр)
    if bc_i is None and ncols:
        for c in range(ncols):
            if c == name_i:
                continue
            vals = [(r[c] if c < len(r) else "").strip() for r in sample]
            digits = [v for v in vals if v.isdigit() and 8 <= len(v) <= 14]
            if vals and len(digits) >= max(1, len(vals) // 2):
                bc_i = c
                break
    return {"name": name_i, "barcode": bc_i, "unit": unit_i}


@app.post("/api/catalog/import")
def api_catalog_import():
    """Імпорт каталогу з файлу (CSV/XLSX). Колонки визначаються автоматично:
    назва (обов'язково), штрихкод і одиниця (за наявності)."""
    cat = _inv_category() or "pharmacy"
    replace = (request.form.get("replace") or request.args.get("replace") or "").strip() \
        in ("1", "true", "yes", "on")
    rows: list[dict] = []
    f = request.files.get("file")
    if f:
        raw = f.read()
        if not raw:
            return _err("Файл порожній")
        fname = (f.filename or "").lower()
        try:
            if fname.endswith((".xlsx", ".xlsm", ".xls")):
                table = _catalog_read_xlsx(raw)
            else:
                table = _catalog_read_csv(raw)
        except Exception as exc:  # noqa: BLE001
            return _err("Не вдалося прочитати файл: " + str(exc))
        if not table:
            return _err("У файлі немає даних")
        headers, body = table[0], table[1:]
        cols = _catalog_detect_columns(headers, body[:80] or [headers])
        ni, bi, ui = cols["name"], cols["barcode"], cols["unit"]
        if ni is None:
            return _err("Не вдалося визначити колонку з назвою. "
                        "Додайте у файл стовпець «Назва».")
        # Якщо перший рядок — це теж дані (немає заголовка-назви), включимо його
        header_is_data = not any(
            k in (headers[ni] or "").casefold()
            for k in ("назв", "наймен", "препарат", "товар", "name"))
        data_rows = ([headers] + body) if header_is_data else body
        for r in data_rows:
            name = (r[ni].strip() if ni is not None and ni < len(r) else "")
            if not name:
                continue
            bc = (r[bi].strip() if bi is not None and bi < len(r) else "")
            bc = "".join(ch for ch in bc if ch.isdigit())
            unit = (r[ui].strip() if ui is not None and ui < len(r) else "")
            rows.append({"name": name, "barcode": bc, "unit": unit})
    else:
        data = request.get_json(silent=True) or {}
        rows = data.get("rows") or []
        replace = bool(data.get("replace")) or replace
    if not rows:
        return _err("Немає рядків для імпорту")
    if replace:
        db.clear_catalog(cat)
    res = db.bulk_import_catalog(rows, cat)
    res["catalog_count"] = db.catalog_count(cat)
    return _ok(res)


@app.get("/api/catalog/export")
def api_catalog_export():
    """Експорт каталогу у CSV (Назва;Штрихкод;Одиниця). BOM — щоб Excel
    одразу коректно показував кирилицю."""
    from flask import Response
    cat = _inv_category() or "pharmacy"
    buf = StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["Назва", "Штрихкод", "Одиниця"])
    for it in db.list_catalog(cat):
        w.writerow([it["name"], it["barcode"], it["unit"]])
    data = "﻿" + buf.getvalue()
    fname = ("catalog_materials" if cat == "materials" else "catalog_pharmacy") + ".csv"
    return Response(data, mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={fname}"})


@app.get("/api/feed/arrivals.csv")
def api_feed_arrivals_export():
    """Експорт повного приходу кормів (усі надходження з даними) для перенесення."""
    from flask import Response
    rows = db.export_feed_arrivals()
    buf = StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["Назва", "Одиниця", "Партія", "Термін", "Кількість",
                "Ціна без ПДВ", "Ціна з ПДВ", "ПДВ", "Постачальник",
                "Накладна", "Дата приходу", "Мін. залишок"])

    def _n(v):
        f = float(v or 0)
        return (str(int(f)) if f == int(f) else ("%.4f" % f).rstrip("0").rstrip(".")).replace(".", ",")

    for r in rows:
        w.writerow([r["name"], r["unit"], r["lot"], r["expires"], _n(r["qty"]),
                    _n(r["price_no_vat"]), _n(r["price_vat"]), _n(r["vat"]),
                    r["supplier"], r["invoice"], r["receipt_date"], _n(r["min_stock"])])
    data = "﻿" + buf.getvalue()
    return Response(data, mimetype="text/csv",
                    headers={"Content-Disposition":
                             f"attachment; filename=pryhid_kormy_{date.today().isoformat()}.csv"})


@app.post("/api/feed/arrivals/import")
def api_feed_arrivals_import():
    """Імпорт приходу кормів із CSV (кожен рядок — окреме надходження з даними).
    Зіставлення за назвою в межах кормів."""
    f = request.files.get("file")
    if not f or not f.filename:
        return _err("Файл не вибрано")
    content = f.read()
    raw = None
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            raw = content.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if raw is None:
        return _err("Не вдалося прочитати файл — збережіть у кодуванні UTF-8")
    lines = raw.splitlines()
    if not lines:
        return _err("Файл порожній")
    delim = ";" if lines[0].count(";") >= lines[0].count(",") else ","
    table = list(csv.reader(StringIO(raw), delimiter=delim))
    if not table:
        return _err("Файл порожній")
    header = [(c or "").strip().lower() for c in table[0]]

    def col(names, exclude=()):
        for i, h in enumerate(header):
            if any(k in h for k in names) and not any(x in h for x in exclude):
                return i
        return None

    # УВАГА: «з пдв» є підрядком у «без пдв», тож для «Ціна з ПДВ» виключаємо «без»,
    # а для ставки ПДВ виключаємо цінові колонки.
    ci = {
        "name": col(["назв"]), "unit": col(["один"]),
        "lot": col(["парт"]), "expires": col(["термін", "придатн"]),
        "qty": col(["кільк"]),
        "pnv": col(["без пдв"]),
        "pv": col(["з пдв"], exclude=["без"]),
        "vat": col(["пдв"], exclude=["ціна", "без", "з пдв"]),
        "supplier": col(["постач"]), "invoice": col(["наклад"]),
        "rdate": col(["дата"]), "min": col(["мін"]),
    }
    if ci["name"] is None or ci["qty"] is None:
        return _err("Не знайдено колонок «Назва» і «Кількість». Скористайтесь експортом як шаблоном.")

    def cell(row, key):
        i = ci.get(key)
        return (row[i].strip() if i is not None and i < len(row) else "")

    def num(s):
        s = (s or "").strip().replace(" ", "").replace(" ", "").replace(",", ".")
        try:
            return float(s) if s else 0.0
        except ValueError:
            return 0.0

    rows = []
    for row in table[1:]:
        if not any((c or "").strip() for c in row):
            continue
        rows.append({
            "name": cell(row, "name"), "unit": cell(row, "unit"),
            "lot": cell(row, "lot"), "expires": cell(row, "expires"),
            "qty": num(cell(row, "qty")),
            "price_no_vat": num(cell(row, "pnv")), "price_vat": num(cell(row, "pv")),
            "vat": num(cell(row, "vat")),
            "supplier": cell(row, "supplier"), "invoice": cell(row, "invoice"),
            "receipt_date": cell(row, "rdate"), "min_stock": num(cell(row, "min")),
        })
    if not rows:
        return _err("Немає рядків для імпорту")
    try:
        res = db.import_feed_arrivals(rows)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка імпорту: {exc}")
    return _ok(res)


@app.post("/api/invoice/save")
def api_invoice_save():
    data = request.get_json(silent=True) or {}
    inv = data.get("invoice")
    if not isinstance(inv, dict):
        return _err("Невірний формат накладної")
    _inv_save(_inv_category() or "pharmacy", inv)
    return _ok({})


@app.post("/api/invoice/clear")
def api_invoice_clear():
    _inv_save(_inv_category() or "pharmacy", {})
    return _ok({})


@app.get("/license-code-qr.png")
def license_code_qr_png():
    """QR із кодом активації цього ПК — клієнт сканує телефоном і пересилає
    власнику через Telegram/Viber/будь-який месенджер."""
    try:
        code = licensing.activation_code()
    except Exception:  # noqa: BLE001
        code = ""
    if not code:
        return _err("Код активації недоступний", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(code, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.get("/scan-qr.png")
def scan_qr_png():
    url = _scanner_url()
    if not url:
        return _err("Мережевий доступ вимкнено", 404)
    import io
    import segno
    buf = io.BytesIO()
    segno.make(url, error="m").save(buf, kind="png", scale=7, border=3)
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/labels")
def page_labels():
    """Друкована сторінка QR-етикеток товарів (для наклеювання на полиці)."""
    import io
    import segno
    cat = _inv_category()
    items = db.list_products("", category=cat)
    labels = []
    for p in items:
        bc = (p.get("barcode") or "").strip()
        if not bc:
            continue
        qr = segno.make(bc, error="m")
        buf = io.BytesIO()
        qr.save(buf, kind="svg", scale=4, border=0, dark="#111111", xmldecl=False)
        svg = buf.getvalue().decode("utf-8")
        labels.append({"name": p["name"], "code": p.get("code") or "",
                       "barcode": bc, "unit": p.get("unit") or "", "qr": svg})
    branch = "Матеріали" if cat == "materials" else "Аптека"
    return render_template("labels.html", labels=labels, branch=branch)


@app.route("/economics")
def page_economics():
    return render_template("economics.html", active="economics")


@app.route("/database")
def page_database():
    return render_template("database.html", active="database")


@app.route("/license")
def page_license():
    return render_template("license.html", active="license",
                           business=load_business())


@app.route("/users")
def page_users():
    return render_template("users.html", active="users")


@app.route("/audit")
def page_audit():
    return render_template("audit.html", active="audit")


@app.route("/catalogs")
def page_catalogs():
    return render_template("catalogs.html", active="catalogs")


@app.route("/offline")
def page_offline():
    return render_template("offline.html", active="offline",
                           http_port=os.environ.get("FARM_HTTP_PORT", "5050"))


@app.route("/sync-conflicts")
def page_sync_conflicts():
    return render_template("sync_conflicts.html", active="conflicts")


@app.route("/settings")
def page_settings():
    return render_template("settings.html", active="settings",
                           business=load_business())


def _ingest_client_id() -> str:
    """Ідентифікатор ферми: вписаний вручну, інакше — «Моя компанія» з ліцензії."""
    manual = (db.get_setting("ingest_client_id", "") or "").strip()
    if manual:
        return manual
    st = licensing.status(db.get_setting("license_key", ""))
    return (st.get("company") or "").strip()


@app.get("/api/ingest/config")
def api_ingest_config_get():
    import json as _json
    try:
        hist = _json.loads(db.get_setting("ingest_history", "") or "[]")
    except Exception:  # noqa: BLE001
        hist = []
    return _ok({
        "url": db.get_setting("ingest_url", ""),
        "client_id": _ingest_client_id(),
        "token_set": bool(db.get_setting("ingest_token", "")),
        "auto": db.get_setting("ingest_auto", "0") == "1",
        "day_from": db.get_setting("ingest_day_from", "06:00"),
        "day_to": db.get_setting("ingest_day_to", "22:00"),
        "day_min": db.get_setting("ingest_day_min", "10"),
        "night_min": db.get_setting("ingest_night_min", "60"),
        "last_at": db.get_setting("ingest_last_at", ""),
        "last_result": db.get_setting("ingest_last_result", ""),
        "history": hist if isinstance(hist, list) else [],
    })


@app.post("/api/ingest/config")
def api_ingest_config_set():
    if not _is_admin():
        return _err("Змінювати може лише адміністратор")
    data = request.get_json(silent=True) or {}
    if "url" in data:
        db.set_setting("ingest_url", (data.get("url") or "").strip())
    if "client_id" in data:
        db.set_setting("ingest_client_id", (data.get("client_id") or "").strip())
    if "auto" in data:
        db.set_setting("ingest_auto", "1" if data.get("auto") else "0")

    def _hm(v, dflt):
        v = (v or "").strip()
        return v if (len(v) == 5 and v[2] == ":") else dflt

    def _pos(v, dflt):
        try:
            return str(max(1, int(float(v))))
        except (TypeError, ValueError):
            return str(dflt)
    if "day_from" in data:
        db.set_setting("ingest_day_from", _hm(data.get("day_from"), "06:00"))
    if "day_to" in data:
        db.set_setting("ingest_day_to", _hm(data.get("day_to"), "22:00"))
    if "day_min" in data:
        db.set_setting("ingest_day_min", _pos(data.get("day_min"), 10))
    if "night_min" in data:
        db.set_setting("ingest_night_min", _pos(data.get("night_min"), 60))
    # токен оновлюємо лише якщо надіслали непорожній (щоб не затерти)
    if (data.get("token") or "").strip():
        db.set_setting("ingest_token", data["token"].strip())
    return _ok({"saved": True})


@app.post("/api/ingest/push")
def api_ingest_push():
    if not _is_admin():
        return _err("Надсилати може лише адміністратор")
    cid = _ingest_client_id()
    if not cid:
        return _err("Вкажіть ідентифікатор ферми")
    data = request.get_json(silent=True) or {}
    ok, msg = db.push_ingest(app_version=APP_VERSION, client_id=cid,
                             force=bool(data.get("force")))
    return (_ok({"message": msg}) if ok else _err(msg))


@app.route("/help")
def page_help():
    """Повна інструкція користувача (доступна всім залогіненим)."""
    return render_template("help.html", active="help")


# ===================================================== Виробництво молока 🥛
# Дані живуть у зовнішньому Excel; застосунок читає їх наживо за посиланням і
# мапінгом (milk_excel.py), групує по періодах і показує. Мапінг зберігаємо в
# налаштуваннях (JSON у setting 'milk_config').
DEFAULT_MILK_CONFIG = {
    "file_path": "",
    "units": {"l": True, "kg": True},
    "yields": {
        # Аркуш «Виробництво» — тут живі щоденні дані (машинна шапка у 3-му рядку),
        # є готові підсумки milk_total_l / milk_total_kg. (Аркуш «tbl» — похідний і
        # може відставати.) Якість (жир/білок) вимірюється на продажу.
        "sheet": "Виробництво", "header_row": 3, "date_col": "date",
        "metrics": [
            {"key": "milk_l", "label": "Надій", "agg": "sum", "col": "milk_total_l", "unit": "л", "type": "number"},
            {"key": "milk_kg", "label": "Надій", "agg": "sum", "col": "milk_total_kg", "unit": "кг", "type": "number"},
        ],
    },
    "sales": {
        "sheet": "Продаж", "header_row": 2, "date_col": "date", "buyer_col": "",
        "kg_col": "sale_milk_kg",   # стовпець кг для суми та середньої ціни
        "metrics": [
            {"key": "kg", "label": "Продано", "agg": "sum", "col": "sale_milk_kg", "unit": "кг", "type": "number"},
            {"key": "l", "label": "Продано", "agg": "sum", "col": "sale_milk_l", "unit": "л", "type": "number"},
            {"key": "fat", "label": "Жир", "agg": "ratio", "num_col": "kgFat", "den_col": "sale_milk_kg", "unit": "%", "type": "percent"},
            {"key": "prot", "label": "Білок", "agg": "ratio", "num_col": "kgProtein", "den_col": "sale_milk_kg", "unit": "%", "type": "percent"},
            # Ціна/сума — похідні: _price діюча на дату, _amount = кг × _price.
            # Розклад на без/з ПДВ робить _milk_apply_vat за налаштуваннями.
            {"key": "price_nv", "label": "Ціна/кг без ПДВ", "agg": "ratio", "num_col": "_amount_nv", "den_col": "sale_milk_kg", "unit": "₴", "type": "money"},
            {"key": "amount_nv", "label": "Сума без ПДВ", "agg": "sum", "col": "_amount_nv", "unit": "₴", "type": "money"},
            {"key": "price", "label": "Ціна/кг з ПДВ", "agg": "ratio", "num_col": "_amount_v", "den_col": "sale_milk_kg", "unit": "₴", "type": "money"},
            {"key": "amount", "label": "Сума з ПДВ", "agg": "sum", "col": "_amount_v", "unit": "₴", "type": "money"},
            {"key": "vat", "label": "ПДВ (зобовʼязання)", "agg": "sum", "col": "_vat", "unit": "₴", "type": "money"},
        ],
    },
    # Ціна молока — «діюча на дату» (перенесення вперед). Аркуш dict: date → ціна/кг.
    "price": {"sheet": "dict", "header_row": 1, "date_col": "date", "price_col": "milk_price_UAH"},
    # ПДВ на продажу молока. В Excel лежить одна ціна, тож треба знати, чи вона
    # вже містить податок. Уся економіка ведеться БЕЗ ПДВ, а сума з ПДВ — це
    # гроші від молокозаводу й водночас податкове зобовʼязання.
    "vat": {"rate": 20.0, "price_includes_vat": True},
}
_MILK_PERIODS = ["day", "week", "month", "quarter", "year"]

# Показники, зміст яких змінився з появою ПДВ: у збережених конфігах їх треба
# оновити до актуального визначення, інакше на екрані лишаються старі підписи
# («Ціна/кг», «Сума») і стара колонка-джерело без розкладу податку.
_MILK_VAT_METRIC_KEYS = {"price", "amount", "price_nv", "amount_nv", "vat"}

# Версія набору показників. Доливання нових виконується РІВНО ОДИН РАЗ на базу
# і одразу зберігається. Інакше вийде пастка: користувач видаляє зайвий рядок
# у налаштуваннях, а наступне читання конфігу повертає його з дефолту.
MILK_METRICS_VERSION = 2

# Telegram-звіти про молоко. include — список "which:key" показників (колонок),
# які потрапляють у повідомлення. Порожній include → усі показники.
DEFAULT_MILK_NOTIFY = {
    "enabled": False,
    "time": "10:20",
    "cmp_week": True,    # додатковий тижневий блок по понеділках
    "cmp_month": True,   # додатковий місячний блок 1-го числа
    "include": [],       # напр. ["yields:milk_kg", "sales:fat", ...]; [] = усі
}


# ── Excel із OneDrive у хмарі ────────────────────────────────────────────────
# На ПК шлях до книги — Windows/Mac («C:\Users\User\OneDrive - LRA\farm\…»).
# На сервері тека farm синхронізується rclone у BOVIO_ONEDRIVE_ROOT (…/farm).
# Якщо збережений шлях не існує, а в ньому є сегмент «farm», беремо хвіст
# після нього під коренем сервера. Налаштування в БД НЕ змінюється — тож
# знімок/супутник несуть той самий шлях, а кожна машина читає свій файл.
ONEDRIVE_ROOT = (os.environ.get("BOVIO_ONEDRIVE_ROOT") or "").strip()


def _excel_path(path: str) -> str:
    path = (path or "").strip()
    if not path or not ONEDRIVE_ROOT or os.path.exists(path):
        return path
    parts = [x for x in path.replace("\\", "/").split("/") if x]
    if "farm" in parts:
        tail = parts[parts.index("farm") + 1:]
        cand = os.path.join(ONEDRIVE_ROOT, *tail)
        if os.path.exists(cand):
            return cand
    return path


import vet_pharmacy.web_db as _web_db_mod
_web_db_mod.PATH_RESOLVER = _excel_path      # тека звітів Profeed → OneDrive сервера


def _keep_pc_path(new_path: str, stored_key: str) -> str:
    """Не дати серверу затерти шлях ПК до книги Excel.

    У хмарі `_milk_config`/`_herd_config` віддають РОЗВ'ЯЗАНИЙ шлях (тека
    rclone), і він же показується в полі налаштувань. Якщо там просто
    натиснути «Зберегти», у базу ляже серверний шлях — а база їде знімком на
    ПК, де такої теки немає. Тому: людина не змінила поле (воно дорівнює
    розв'язаному) → лишаємо збережений шлях ПК як був."""
    try:
        raw = json.loads(db.get_setting(stored_key, "") or "{}")
        old = str(raw.get("file_path") or "")
    except Exception:  # noqa: BLE001
        return new_path
    if old and str(new_path or "") == _excel_path(old):
        return old
    return new_path


def _milk_config() -> dict:
    raw = db.get_setting("milk_config", None)
    if not raw:
        return json.loads(json.dumps(DEFAULT_MILK_CONFIG))  # копія
    try:
        cfg = json.loads(raw)
    except Exception:  # noqa: BLE001
        return json.loads(json.dumps(DEFAULT_MILK_CONFIG))
    # доповнюємо відсутні секції дефолтами
    for k, v in DEFAULT_MILK_CONFIG.items():
        cfg.setdefault(k, v)
    cfg["file_path"] = _excel_path(cfg.get("file_path") or "")
    # Нові показники (напр. ціна/сума без ПДВ) не зʼявляться самі: у базі вже
    # лежить свій список metrics. Доливаємо відсутні за ключем — але лише поки
    # конфіг старої версії. Після оновлення список належить користувачу.
    if int(cfg.get("metrics_v") or 0) >= MILK_METRICS_VERSION:
        return cfg
    for which in ("yields", "sales"):
        have = cfg.get(which) or {}
        base = DEFAULT_MILK_CONFIG[which]
        cur = have.get("metrics")
        if not isinstance(cur, list):
            continue
        by_key = {m.get("key"): m for m in base.get("metrics", []) if isinstance(m, dict)}
        keys = {m.get("key") for m in cur if isinstance(m, dict)}
        # Похідні показники ціни/суми змінили зміст (тепер із розкладом ПДВ),
        # тож їм оновлюємо підпис і колонку-джерело. Решту не чіпаємо —
        # там можуть бути власні налаштування користувача.
        for m in cur:
            if not isinstance(m, dict):
                continue
            src = by_key.get(m.get("key"))
            if src and m.get("key") in _MILK_VAT_METRIC_KEYS:
                for f in ("label", "col", "num_col", "den_col", "unit", "agg", "type"):
                    if f in src:
                        m[f] = src[f]
        merged, tail = [], list(cur)
        for m in base.get("metrics", []):
            if m.get("key") in keys:
                continue
            merged.append(json.loads(json.dumps(m)))
        if merged:
            have["metrics"] = tail + merged
            cfg[which] = have
    cfg["metrics_v"] = MILK_METRICS_VERSION
    try:
        db.set_setting("milk_config", json.dumps(cfg, ensure_ascii=False))
    except Exception:  # noqa: BLE001
        pass          # не змогли зберегти — не критично, спробуємо наступного разу
    return cfg


def _milk_fmt(v, mtype):
    """Форматування значення показника для таблиці (укр. розділювач тисяч)."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return ""
    if mtype == "percent":
        return f"{v * 100:.2f}".replace(".", ",")
    if mtype == "money":
        return f"{v:,.2f}".replace(",", " ").replace(".", ",")
    # number / int
    if abs(v - round(v)) < 1e-9:
        return f"{v:,.0f}".replace(",", " ")
    return f"{v:,.1f}".replace(",", " ").replace(".", ",")


def _milk_rows(cfg, which):
    """Прочитати рядки датасету ('yields'|'sales') з файлу з обчисленими
    _price/_amount (лише для продажу). Повертає (raw, ds, error)."""
    ds = cfg.get(which) or {}
    path = (cfg.get("file_path") or "").strip()
    metrics = ds.get("metrics") or []
    if not path:
        return [], ds, "Не вказано файл Excel (відкрийте Налаштування)."
    if not Path(path).expanduser().exists():
        return [], ds, f"Файл не знайдено: {path}"
    try:
        buyer_col = ds.get("buyer_col") or ""
        pcfg = cfg.get("price") or {}
        # Ціна може бути КОЛОНКОЮ прямо в аркуші продажу (той самий аркуш) —
        # тоді читаємо її разом із рядками (per-row); інакше — окремий графік
        # цін (date→ціна) з перенесенням вперед.
        sales_price_col = (pcfg.get("price_col")
                           if which == "sales" and pcfg.get("price_col")
                           and pcfg.get("sheet") == ds.get("sheet") else None)
        extra = [buyer_col] if buyer_col else []
        if sales_price_col:
            extra.append(sales_price_col)
        # Колонка кг для сум читається окремо: у cols_used потрапляють лише
        # колонки, названі в показниках. Поки kg_col збігався з колонкою
        # показника «Продано, кг», це проходило непоміченим — а варто вказати
        # іншу (напр. вагу молокозаводу), її ніхто не читав і всі суми
        # ставали нулями.
        if which == "sales":
            _kg = (ds.get("kg_col") or "").strip()
            if _kg and _kg not in extra:
                extra.append(_kg)
        cols = milk_excel.cols_used(metrics, extra=extra)
        raw = milk_excel.read_rows(path, ds.get("sheet"), int(ds.get("header_row", 1)),
                                   ds.get("date_col"), cols)
        # Ціна/сума (лише продаж): на кожен рядок — _price і _amount = кг × _price.
        if which == "sales":
            kg_col = ds.get("kg_col") or "sale_milk_kg"
            if sales_price_col:                       # ціна — колонка в аркуші продажу
                # заповнюється лише в дати ЗМІНИ → будуємо графік із непорожніх
                # клітинок і ПЕРЕНОСИМО вперед (як у окремому графіку цін).
                pts = [{"date": r["date"], "_p": milk_excel._num(r.get(sales_price_col))}
                       for r in raw if milk_excel._num(r.get(sales_price_col)) > 0]
                sched = milk_excel.build_price_schedule(pts, "date", "_p")
                for r in raw:
                    p = milk_excel.effective_price(sched, r["date"])
                    r["_price"] = p
                    r["_amount"] = p * milk_excel._num(r.get(kg_col))
            else:                                      # окремий графік цін (dict)
                sched = []
                if pcfg.get("sheet") and pcfg.get("price_col"):
                    try:
                        prows = milk_excel.read_rows(path, pcfg.get("sheet"),
                                                     int(pcfg.get("header_row", 1)),
                                                     pcfg.get("date_col"), [pcfg.get("price_col")])
                        sched = milk_excel.build_price_schedule(prows, pcfg.get("date_col"),
                                                                pcfg.get("price_col"))
                    except Exception:  # noqa: BLE001
                        sched = []
                for r in raw:
                    p = milk_excel.effective_price(sched, r["date"]) if sched else 0.0
                    r["_price"] = p
                    r["_amount"] = p * milk_excel._num(r.get(kg_col))
            _milk_apply_vat(cfg, raw)
        return raw, ds, ""
    except Exception as exc:  # noqa: BLE001
        return [], ds, f"Помилка читання Excel: {exc}"


def _milk_apply_vat(cfg, raw):
    """Розкласти ціну/суму продажу на «без ПДВ» і «з ПДВ».

    В Excel лежить одна ціна; що саме вона означає — задано в налаштуваннях
    (ставка + прапорець «ціна вже з ПДВ»). Уся економіка ферми ведеться БЕЗ
    ПДВ, а сума з ПДВ — це гроші від молокозаводу й водночас податкове
    зобовʼязання. Різниця _vat і є тим зобовʼязанням."""
    vcfg = cfg.get("vat") or {}
    rate = float(vcfg.get("rate") or 0)
    incl = vcfg.get("price_includes_vat") is not False
    k = 1 + rate / 100.0
    for r in raw:
        p = float(r.get("_price") or 0)
        a = float(r.get("_amount") or 0)
        if rate <= 0:
            r["_price_nv"], r["_amount_nv"] = p, a
            r["_price_v"], r["_amount_v"] = p, a
        elif incl:                       # у таблиці ціна З ПДВ
            r["_price_v"], r["_amount_v"] = p, a
            r["_price_nv"], r["_amount_nv"] = p / k, a / k
        else:                            # у таблиці ціна БЕЗ ПДВ
            r["_price_nv"], r["_amount_nv"] = p, a
            r["_price_v"], r["_amount_v"] = p * k, a * k
        r["_vat"] = r["_amount_v"] - r["_amount_nv"]


def _milk_dataset(cfg, which, period, buyer=None, days=0, src="all"):
    """Прочитати й агрегувати датасет ('yields'|'sales') — З БАЗИ. Excel лише
    джерело імпорту (_milk_ingest). Повертає (agg_rows, total_row|None,
    metrics, buyers, error, diag). days>0 у режимі 'day' — останні N днів.
    src: 'all' | 'excel' (лише Excel) | 'manual' (лише Telegram-ввід)."""
    ds = cfg.get(which) or {}
    metrics = ds.get("metrics") or []
    # рядки з БД, з ключами під milk_excel.aggregate (ПДВ уже розкладено при імпорті)
    raw = db.milk_sales_rows("", "") if which == "sales" else db.milk_yields_rows("", "")
    # фільтр джерела: Excel = source порожній, Telegram = source 'manual'
    if src == "excel":
        raw = [r for r in raw if (r.get("source") or "") != "manual"]
    elif src == "manual":
        raw = [r for r in raw if (r.get("source") or "") == "manual"]
    err = ""
    if not raw and not (cfg.get("file_path") or "").strip():
        err = "Не вказано файл Excel (відкрийте Налаштування)."
    buyers = []                          # денне зведення в БД без розбивки по покупцях
    # У режимі «День» обмежуємо останніми N днями (щоб не показувати всю історію).
    if period == "day" and days and days > 0:
        dts = [r["date"] for r in raw if r.get("date")]
        if dts:
            cutoff = max(dts) - timedelta(days=days - 1)
            raw = [r for r in raw if r.get("date") and r["date"] >= cutoff]
    agg = milk_excel.aggregate(raw, metrics, period)
    tot = milk_excel.aggregate(raw, metrics, "all")
    total = tot[0] if tot else None
    _dts = [r["date"] for r in raw if r.get("date")]
    diag = {"rows": len(raw),
            "max": max(_dts).strftime("%d.%m.%Y") if _dts else "—",
            "sheet": ds.get("sheet", "")}
    return agg, total, metrics, buyers, err, diag


# ------------------------------------------------- Telegram-звіти про молоко
def _milk_notify_config() -> dict:
    raw = db.get_setting("milk_notify", None)
    cfg = json.loads(json.dumps(DEFAULT_MILK_NOTIFY))
    if raw:
        try:
            saved = json.loads(raw)
            if isinstance(saved, dict):
                cfg.update(saved)
        except Exception:  # noqa: BLE001
            pass
    return cfg


def _milk_metric_options(mcfg=None):
    """Плоский список усіх показників обох датасетів для чекліста/дайджесту:
    [{'id':'which:key','which','metric','label','unit','type','ds_label'}]."""
    mcfg = mcfg or _milk_config()
    out = []
    for which, ds_label in (("yields", "Виробництво"), ("sales", "Продаж")):
        for m in (mcfg.get(which) or {}).get("metrics") or []:
            out.append({"id": f"{which}:{m.get('key')}", "which": which,
                        "metric": m, "label": m.get("label", ""),
                        "unit": m.get("unit", ""), "type": m.get("type", "number"),
                        "ds_label": ds_label})
    return out


def _milk_delta_str(cur, prev, mtype):
    """Рядок зміни: стрілка + абсолютна різниця (+ % для не-відсоткових)."""
    d = (cur or 0) - (prev or 0)
    if abs(d) < 1e-9:
        return "→ 0"
    arrow = "↑" if d > 0 else "↓"
    if mtype == "percent":
        return f"{arrow} " + f"{d * 100:+.2f}".replace(".", ",") + " в.п."
    body = _milk_fmt(abs(d), mtype)
    pct = ""
    if prev:
        pct = f" ({d / prev * 100:+.1f}%)".replace(".", ",")
    return f"{arrow} {'+' if d > 0 else '−'}{body}{pct}"


def build_milk_digest(*, force_all: bool = False, today=None) -> str:
    """Текст Telegram-звіту: за день (vs попередній), + тиждень (по понеділках),
    + місяць (1-го числа). Звіт за СТРОГО вчорашній день."""
    from calendar import monthrange
    today = today or date.today()
    ncfg = _milk_notify_config()
    mcfg = _milk_config()
    include = set(ncfg.get("include") or [])
    opts = _milk_metric_options(mcfg)
    picked = [o for o in opts if force_all or not include or o["id"] in include]

    # рядки читаємо ОДИН раз на датасет, далі ріжемо в пам'яті по діапазонах
    rows_cache, err = {}, None
    for which in ("yields", "sales"):
        raw, _ds, e = _milk_rows(mcfg, which)
        rows_cache[which] = raw
        if e and not err:
            err = e
    if err and not any(rows_cache.values()):
        return f"🥛 Молоко — не вдалося прочитати дані:\n{err}"

    def rng(which, metric, d1, d2):
        sub = [r for r in rows_cache.get(which, []) if r.get("date") and d1 <= r["date"] <= d2]
        agg = milk_excel.aggregate(sub, [metric], "all")
        return agg[0]["metrics"].get(metric["key"], 0) if agg else 0

    def block(title, cur1, cur2, prev1, prev2):
        lines = [title]
        for o in picked:
            cur = rng(o["which"], o["metric"], cur1, cur2)
            prev = rng(o["which"], o["metric"], prev1, prev2)
            unit = f" {o['unit']}" if o["unit"] else ""
            lines.append(f"• {o['label']}: {_milk_fmt(cur, o['type'])}{unit}  "
                         f"{_milk_delta_str(cur, prev, o['type'])}")
        return lines

    def dm(d):
        return d.strftime("%d.%m")

    yday = today - timedelta(days=1)
    out = [f"🥛 Молоко · звіт за {yday.strftime('%d.%m.%Y')}", ""]
    if not picked:
        out.append("Не обрано жодного показника (Виробництво молока → Telegram-звіти).")
        return "\n".join(out)

    # За день: вчора vs позавчора
    out += block(f"📅 За день ({dm(yday)} vs {dm(yday - timedelta(days=1))}):",
                 yday, yday, yday - timedelta(days=1), yday - timedelta(days=1))

    # За тиждень — лише по понеділках: минулий Пн–Нд vs тиждень перед ним
    if force_all or (ncfg.get("cmp_week") and today.weekday() == 0):
        w1 = today - timedelta(days=7)      # минулий понеділок
        w2 = today - timedelta(days=1)      # минула неділя
        p1, p2 = w1 - timedelta(days=7), w1 - timedelta(days=1)
        out.append("")
        out += block(f"📆 За тиждень ({dm(w1)}–{dm(w2)} vs {dm(p1)}–{dm(p2)}):",
                     w1, w2, p1, p2)

    # За місяць — лише 1-го числа: минулий місяць vs позаминулий
    if force_all or (ncfg.get("cmp_month") and today.day == 1):
        first_this = today.replace(day=1)
        m1_end = first_this - timedelta(days=1)         # останній день минулого міс.
        m1_start = m1_end.replace(day=1)
        m0_end = m1_start - timedelta(days=1)           # останній день позаминулого
        m0_start = m0_end.replace(day=1)
        out.append("")
        out += block(f"🗓 За місяць ({m1_start.strftime('%m.%Y')} vs {m0_start.strftime('%m.%Y')}):",
                     m1_start, m1_end, m0_start, m0_end)

    return "\n".join(out)


def send_milk_digest_now(*, test: bool = False) -> tuple:
    text = build_milk_digest(force_all=test)
    if test:
        text = "🔔 Тест молочного звіту\n\n" + text
    return db.send_telegram(db.get_setting("notify_tg_token", ""),
                            db.get_setting("notify_tg_chat", ""), text)


def _start_milk_notify() -> None:
    """Фонова щоденна розсилка молочного звіту о заданій годині (той самий
    бот/чат, що складські сповіщення)."""
    import threading

    def loop():
        while True:
            try:
                time.sleep(30)
                ncfg = _milk_notify_config()
                if not ncfg.get("enabled"):
                    continue
                target = db.get_setting("notify_time", "08:00")  # глобальний час
                now = datetime.now()
                cur, today = now.strftime("%H:%M"), now.strftime("%Y-%m-%d")
                if cur >= target and db.get_setting("milk_notify_last_sent", "") != today:
                    ok, _m = send_milk_digest_now()
                    if ok:
                        db.set_setting("milk_notify_last_sent", today)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="milk-notify").start()


# --------------------------------------------- Telegram-звіти складських гілок
_WH_BRANCHES = [("pharmacy", "Аптека"), ("materials", "Матеріали"), ("feed", "Годівля")]
DEFAULT_WH_NOTIFY = {
    "enabled": False,
    "inc_low": True, "inc_expiring": True, "inc_expired": True, "inc_daily": False,
    "expiry_days": 30,
}


def _wh_label(cat):
    return dict(_WH_BRANCHES).get(cat, cat)


def _wh_notify_cfg(cat) -> dict:
    raw = db.get_setting(f"wh_notify_{cat}", None)
    cfg = json.loads(json.dumps(DEFAULT_WH_NOTIFY))
    if raw:
        try:
            saved = json.loads(raw)
            if isinstance(saved, dict):
                cfg.update(saved)
        except Exception:  # noqa: BLE001
            pass
    return cfg


def build_wh_digest(cat, cfg=None, *, force_all: bool = False) -> str:
    """Текст щоденного складського звіту для однієї гілки (Аптека|Матеріали)."""
    cfg = cfg or _wh_notify_cfg(cat)
    label = _wh_label(cat)
    g = lambda k: force_all or cfg.get(k)  # noqa: E731
    try:
        days = int(cfg.get("expiry_days", 30))
    except (TypeError, ValueError):
        days = 30
    lines = [f"📦 {label} · {date.today().strftime('%d.%m.%Y')}"]
    try:
        if g("inc_low"):
            low = [p for p in db.list_products(category=cat)
                   if p["total_qty"] <= p["min_stock"]]
            if low:
                lines.append(f"⚠️ Низькі залишки ({len(low)}):")
                for p in low[:20]:
                    lines.append(f"• {p['name']} — {db._nfmt(p['total_qty'])} "
                                 f"(мін {db._nfmt(p['min_stock'])})")
                if len(low) > 20:
                    lines.append(f"…ще {len(low) - 20}")
            else:
                lines.append("✅ Низьких залишків немає")
        if g("inc_expiring") or g("inc_expired"):
            batches = db.expiring_batches(days, category=cat)
            expiring = [b for b in batches if not b["expired"]]
            expired = [b for b in batches if b["expired"]]
            if g("inc_expiring"):
                if expiring:
                    lines.append(f"⏳ Скоро прострочиться (≤{days} дн., {len(expiring)}):")
                    for b in expiring[:20]:
                        lines.append(f"• {b['name']} — до {db._ndate(b['expires_on'])} "
                                     f"({b['days_left']} дн., {db._nfmt(b['qty'])})")
                    if len(expiring) > 20:
                        lines.append(f"…ще {len(expiring) - 20}")
                else:
                    lines.append(f"✅ Нічого не прострочиться у межах {days} дн.")
            if g("inc_expired"):
                if expired:
                    lines.append(f"❌ Прострочені ({len(expired)}):")
                    for b in expired[:20]:
                        lines.append(f"• {b['name']} — термін {db._ndate(b['expires_on'])} "
                                     f"({db._nfmt(b['qty'])})")
                    if len(expired) > 20:
                        lines.append(f"…ще {len(expired) - 20}")
                else:
                    lines.append("✅ Прострочених немає")
        if g("inc_daily"):
            yday = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")
            r = db._branch_daily_summary(cat, yday)
            lines.append(f"📊 За {db._ndate(yday)}: видач {int(r['out_cnt'] or 0)} "
                         f"на {db._nfmt(r['out_sum'] or 0)} ₴, "
                         f"надходжень {int(r['in_cnt'] or 0)}")
    except Exception as exc:  # noqa: BLE001
        lines.append(f"⚠ Помилка формування: {exc}")
    return "\n".join(lines)


def send_wh_digest_now(cat, *, test: bool = False) -> tuple:
    text = build_wh_digest(cat, force_all=test)
    if test:
        text = "🔔 Тест складського звіту\n\n" + text
    return db.send_telegram(db.get_setting("notify_tg_token", ""),
                            db.get_setting("notify_tg_chat", ""), text)


def _migrate_staff_from_participants() -> None:
    """Одноразово перенести учасників Telegram-вводу (старий список
    tg_input_participants: імʼя + id) у гілку «Персонал», щоб вони зʼявились у
    Штатній структурі. Ідемпотентно: не дублює за Telegram-ID."""
    return  # гілку «Персонал» прибрано (переїхала на сервер)
    if db.get_setting("staff_from_parts_migrated", "") == "1":
        return
    try:
        try:
            arr = json.loads(db.get_setting("tg_input_participants", "") or "[]")
        except Exception:  # noqa: BLE001
            arr = []
        have = {str(s.get("tg_id", "")).strip()
                for s in db.list_staff(include_inactive=True)}
        for p in (arr if isinstance(arr, list) else []):
            pid = str(p.get("id", "")).strip()
            if not pid or pid in have:
                continue
            db.add_staff(str(p.get("name") or ("TG " + pid)), "", pid)
            have.add(pid)
        db.set_setting("staff_from_parts_migrated", "1")
    except Exception:  # noqa: BLE001
        pass


def _migrate_wh_notify() -> None:
    """Одноразова міграція старих (спільних) складських налаштувань у
    per-branch і вимкнення старого циклу web_db._start_auto_notify."""
    if db.get_setting("wh_notify_migrated", "") == "1":
        return
    try:
        old_on = db.get_setting("notify_enabled", "0") == "1"
        days = db.get_setting("notify_expiry_days", "30")
        content = {
            "inc_low": db.get_setting("notify_inc_low", "1") == "1",
            "inc_expiring": db.get_setting("notify_inc_expiring", "1") == "1",
            "inc_expired": db.get_setting("notify_inc_expired", "1") == "1",
            "inc_daily": db.get_setting("notify_inc_daily", "0") == "1",
        }
        try:
            days_i = int(days)
        except (TypeError, ValueError):
            days_i = 30
        for cat, _lbl in _WH_BRANCHES:
            br_on = db.get_setting(f"notify_branch_{cat}", "1") == "1"
            cfg = dict(content, enabled=bool(old_on and br_on), expiry_days=days_i)
            db.set_setting(f"wh_notify_{cat}", json.dumps(cfg, ensure_ascii=False))
        db.set_setting("notify_enabled", "0")   # старий спільний цикл — вимкнено
        db.set_setting("wh_notify_migrated", "1")
    except Exception:  # noqa: BLE001
        pass


def _start_wh_notify() -> None:
    """Щоденна розсилка складських звітів по гілках о ГЛОБАЛЬНІЙ годині
    (notify_time), тим самим ботом/чатом."""
    import threading
    _migrate_wh_notify()
    _migrate_staff_from_participants()      # старі учасники бота → Штатна структура
    try:
        db.seed_default_roles()             # приклад-цикл «Доярка» (разово)
    except Exception:  # noqa: BLE001
        pass
    try:
        db.recompute_duration_answers()     # заповнити обчислювані кроки для наявних прогонів
    except Exception:  # noqa: BLE001
        pass

    def loop():
        while True:
            try:
                time.sleep(30)
                now = datetime.now()
                cur, today = now.strftime("%H:%M"), now.strftime("%Y-%m-%d")
                # після 23:00 добити незакриті цикли за сьогодні (раз на день)
                if cur >= "23:00" and db.get_setting("roles_autoclose_last", "") != today:
                    try:
                        db.autoclose_day_runs("23:00")
                    except Exception:  # noqa: BLE001
                        pass
                    db.set_setting("roles_autoclose_last", today)
                target = db.get_setting("notify_time", "08:00")
                if cur < target:
                    continue
                for cat, _lbl in _WH_BRANCHES:
                    cfg = _wh_notify_cfg(cat)
                    if not cfg.get("enabled"):
                        continue
                    if db.get_setting(f"wh_notify_{cat}_last", "") == today:
                        continue
                    ok, _m = send_wh_digest_now(cat)
                    if ok:
                        db.set_setting(f"wh_notify_{cat}_last", today)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="wh-notify").start()


def _milk_disp(rows, total, metrics):
    """Готує рядки для таблиці: {'label', 'cells':[str,...]}."""
    def cells(r):
        return [_milk_fmt(r["metrics"].get(m["key"]), m.get("type", "number")) for m in metrics]
    def fmt_at(s):
        # "2026-08-14 18:07:23" → "14.08.2026 18:07"
        s = str(s or "")
        try:
            d, t = s.split(" ")
            y, mo, dd = d.split("-")
            return f"{dd}.{mo}.{y} {t[:5]}"
        except Exception:  # noqa: BLE001
            return s
    disp = [{"label": r["label"], "cells": cells(r),
             "photo": r.get("photo", ""), "key": r.get("key", ""),
             "source": r.get("source", ""), "by": r.get("by", ""),
             "at": fmt_at(r.get("at", ""))} for r in rows]
    total_cells = cells(total) if total else None
    return disp, total_cells


_MILK_DAY_OPTS = [14, 30, 60, 90, 0]   # 0 = усі


def _milk_render(which, active, tmpl):
    cfg = _milk_config()
    # авто-фіксація Excel→БД при кожному відкритті (далі читаємо лише з БД)
    try:
        _milk_ingest("", "")
    except Exception:  # noqa: BLE001
        pass
    period = request.args.get("period", "month")
    if period not in _MILK_PERIODS:
        period = "month"
    buyer = request.args.get("buyer") or ""
    # Ліміт днів — лише для режиму «День». Дефолт 30.
    try:
        days = int(request.args.get("days", 30))
    except ValueError:
        days = 30
    if days not in _MILK_DAY_OPTS:
        days = 30
    src = request.args.get("src", "all")
    if src not in ("all", "excel", "manual"):
        src = "all"
    rows, total, metrics, buyers, err, diag = _milk_dataset(
        cfg, which, period, buyer or None, days if period == "day" else 0, src)
    rows = list(reversed(rows))          # новіші періоди — зверху
    disp, total_cells = _milk_disp(rows, total, metrics)
    mt = milk_excel.file_mtime(cfg.get("file_path") or "")
    file_updated = mt.strftime("%d.%m.%Y %H:%M") if mt else ""
    return render_template(tmpl, active=active, period=period, periods=_MILK_PERIODS,
                           rows=disp, total_cells=total_cells, metrics=metrics,
                           buyers=buyers, buyer=buyer, milk_err=err, days=days, src=src,
                           day_opts=_MILK_DAY_OPTS, file_updated=file_updated, diag=diag,
                           has_file=bool((cfg.get("file_path") or "").strip()))


@app.route("/milk")
def page_milk_yields():
    return _milk_render("yields", "milk_yields", "milk_yields.html")


@app.route("/milk/sales")
def page_milk_sales():
    return _milk_render("sales", "milk_sales", "milk_sales.html")


@app.route("/milk/register")
def page_milk_register():
    """Реєстр зафіксованих записів (надій + продаж): дата, тип, кг, сума,
    джерело, хто вніс, коли, фото. Новіші — зверху."""
    try:
        _milk_ingest("", "")
    except Exception:  # noqa: BLE001
        pass

    def _fmt_day(d):
        try:
            return d.strftime("%d.%m.%Y")
        except Exception:  # noqa: BLE001
            s = str(d or "")[:10]
            try:
                y, mo, da = s.split("-")
                return f"{da}.{mo}.{y}"
            except Exception:  # noqa: BLE001
                return s

    def _fmt_at(s):
        s = str(s or "")
        try:
            dd, tt = s.split(" ")
            y, mo, da = dd.split("-")
            return f"{da}.{mo}.{y} {tt[:5]}"
        except Exception:  # noqa: BLE001
            return s

    def _iso(d):
        try:
            return d.isoformat()
        except Exception:  # noqa: BLE001
            return str(d)[:10]

    recs = []
    # Надій — по ЗМІНАХ (день+зміна)
    for r in db.milk_yield_shifts_list("", ""):
        recs.append({"d": r["day"], "which": "yields", "shift": r["shift"],
                     "type": f"🥛 Надій · зм.{r['shift']}",
                     "kg": r["kg"] or 0, "amount": None, "source": "manual",
                     "by": r["by"], "at": r["at"], "photo": r["photo"]})
    # Продаж — по днях (ручні)
    for r in db.milk_sales_rows("", ""):
        if (r.get("source", "") or "") != "manual":
            continue
        recs.append({"d": _iso(r.get("date")), "which": "sales", "shift": 0,
                     "type": "💰 Продаж",
                     "kg": r.get("sale_milk_kg") or 0, "amount": r.get("_amount_nv") or 0,
                     "source": "manual", "by": r.get("entered_by", ""),
                     "at": r.get("at", ""), "photo": r.get("photo", "")})
    recs.sort(key=lambda x: (str(x["d"]), x["at"]), reverse=True)

    rows = [{
        "day": _fmt_day(r["d"]),
        "iso": str(r["d"])[:10],
        "which": r["which"],
        "shift": r["shift"],
        "type": r["type"],
        "kg": _milk_fmt(r["kg"], "number"),
        "amount": _milk_fmt(r["amount"], "money") if r["amount"] is not None else "",
        "by": r["by"], "at": _fmt_at(r["at"]), "photo": r["photo"],
    } for r in recs]
    return render_template("milk_register.html", active="milk_register",
                           rows=rows, total=len(rows))


@app.route("/milk/settings")
def page_milk_settings():
    return render_template("milk_settings.html", active="milk_settings",
                           cfg=_milk_config())


@app.get("/api/milk/sheets")
def api_milk_sheets():
    path = (request.args.get("path") or _milk_config().get("file_path") or "").strip()
    if not path or not Path(path).expanduser().exists():
        return _err("Файл не знайдено.", 404)
    try:
        return jsonify({"ok": True, "sheets": milk_excel.list_sheets(path)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося прочитати файл: {exc}")


@app.get("/api/milk/columns")
def api_milk_columns():
    path = (request.args.get("path") or _milk_config().get("file_path") or "").strip()
    sheet = request.args.get("sheet") or ""
    header_row = int(request.args.get("header_row") or 1)
    if not path or not Path(path).expanduser().exists():
        return _err("Файл не знайдено.", 404)
    try:
        return jsonify({"ok": True, "columns": milk_excel.list_columns(path, sheet, header_row)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося прочитати аркуш: {exc}")


@app.post("/api/milk/config")
def api_milk_config_save():
    g = _manage_guard("milk")
    if g is not None:
        return g
    data = request.get_json(silent=True) or {}
    cfg = _milk_config()
    # оновлюємо лише відомі верхньорівневі ключі
    cfg["metrics_v"] = MILK_METRICS_VERSION
    for k in ("file_path", "units", "yields", "sales", "price", "vat"):
        if k in data:
            cfg[k] = data[k]
    cfg["file_path"] = _keep_pc_path(cfg.get("file_path", ""), "milk_config")
    db.set_setting("milk_config", json.dumps(cfg, ensure_ascii=False))
    # мапінг змінено → одразу переімпортуємо молоко в БД
    try:
        _milk_ingest("", "")
    except Exception:  # noqa: BLE001
        pass
    return jsonify({"ok": True})


@app.post("/api/milk/ingest")
def api_milk_ingest():
    """Ручна фіксація надою й продажу з Excel у БД («Оновити молоко з Excel»).
    Далі всі сторінки/звіти/сервер читають з БД."""
    g = _manage_guard("milk")
    if g is not None:
        return g
    res = _milk_ingest("", "")
    return jsonify({"ok": True, "yields": res.get("yields", 0),
                    "sales": res.get("sales", 0)})


def _is_admin() -> bool:
    _u = db.get_user(session["user_id"]) if "user_id" in session else None
    return bool(_u and _u.get("role") == "admin")


@app.route("/milk/entry")
def page_milk_entry():
    """Ввід молока за налаштованою формою: рядки — дати, у кожній — зміни."""
    return render_template("milk_entry.html", active="milk_entry")


@app.get("/api/milk/entry")
def api_milk_entry_grid():
    """Сітка вводу за формою: ?form=<id>&days=<N>. Без form — перша форма
    (за потреби створюється типова)."""
    try:
        fid = int(request.args.get("form") or 0)
    except (TypeError, ValueError):
        fid = 0
    if not fid:
        forms = db.list_milk_forms()
        fid = int(forms[0]["id"]) if forms else db.seed_milk_form()
    try:
        days = int(request.args.get("days") or 14)
    except (TypeError, ValueError):
        days = 14
    data = db.milk_entry_grid(fid, days)
    data["forms"] = db.list_milk_forms()
    return _ok(data)


@app.post("/api/milk/entry")
def api_milk_entry_save():
    """Зберегти значення однієї зміни: {form, date, shift, values:{поле:значення}}."""
    d = request.get_json(silent=True) or {}
    try:
        who = (session.get("user_name") or "").strip()
        run_id = db.save_milk_entry(int(d.get("form") or 0), d.get("date", ""),
                                    d.get("shift", ""), d.get("values") or {}, who)
        return _ok({"run_id": run_id})
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка збереження: {exc}")


@app.get("/api/milk/fields")
def api_milk_fields():
    """Колонки форми обліку молока (для налаштування прямо на сторінці вводу)."""
    try:
        fid = int(request.args.get("form") or 0)
    except (TypeError, ValueError):
        fid = 0
    if not fid:
        forms = db.list_milk_forms()
        fid = int(forms[0]["id"]) if forms else db.seed_milk_form()
    return _ok({"form": fid, "fields": db.list_milk_form_fields(fid),
                "kinds": list(db.MILK_FIELD_KINDS),
                "orphans": db.milk_orphan_values(fid)})


@app.post("/api/milk/fields")
def api_milk_fields_save():
    """Зберегти колонки форми: {form, fields:[{label,kind,unit,required,…}]}."""
    g = _manage_guard("milk")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        if not fid:
            forms = db.list_milk_forms()
            fid = int(forms[0]["id"]) if forms else db.seed_milk_form()
        db.save_milk_form_fields(fid, d.get("fields") or [])
        # набір змінився — одразу оновлюємо дзеркало на сервері бота
        tg = ""
        try:
            if _tg_milk_cfg()["on"]:
                _tg_milk_push_form()
        except Exception as exc:  # noqa: BLE001 — обмін не має заважати збереженню
            tg = str(exc)[:150]
            db.set_setting("milk_tg_error", tg)
        return _ok({"fields": db.list_milk_form_fields(fid),
                    "orphans": db.milk_orphan_values(fid), "tg_error": tg})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/milk/entry/sale-add")
def api_milk_sale_add():
    """Додати рядок відвантаження на дату: {form, date}."""
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        key = db.milk_add_sale_run(fid, d.get("date") or "",
                                   (session.get("user") or {}).get("name", ""))
        return _ok({"key": key})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/milk/entry/sale-del")
def api_milk_sale_del():
    """Прибрати рядок відвантаження: {form, date, shift}."""
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        return _ok({"deleted": db.milk_delete_run(fid, d.get("date") or "",
                                                  d.get("shift") or "")})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


# ── Обмін із Telegram-ботом на сервері ─────────────────────────────────────
# Налаштування колонок живуть ТУТ (у застосунку). Серверу віддаємо лише опис
# колонок, позначених галочкою «Telegram», а забираємо внесені ботом значення.
# Зʼєднання завжди вихідне — білий IP на ПК не потрібен.

def _tg_milk_cfg() -> dict:
    return {
        "on": db.get_setting("milk_tg_on", "0") == "1",
        "url": (db.get_setting("milk_tg_url", "") or "").strip().rstrip("/"),
        "token": (db.get_setting("milk_tg_token", "") or "").strip(),
        "since": int(db.get_setting("milk_tg_since", "0") or 0),
        "last": db.get_setting("milk_tg_last", ""),
        "error": db.get_setting("milk_tg_error", ""),
    }


def _tg_milk_ssl_ctx():
    """SSL-контекст із кореневими сертифікатами certifi — щоб перевірка сертифіката
    сервера не залежала від того, чи налаштований системний trust store Python.
    Без цього на свіжому/фреймворковому Python був CERTIFICATE_VERIFY_FAILED."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa: BLE001
        return ssl.create_default_context()


def _tg_milk_call(path: str, payload: dict | None = None, method: str = "POST"):
    """Запит до сервера бота. Повертає розібраний JSON або кидає виняток."""
    import urllib.request
    import urllib.error
    cfg = _tg_milk_cfg()
    if not cfg["url"]:
        raise RuntimeError("Не вказано адресу сервера.")
    url = cfg["url"] + path
    data = None
    headers = {"Accept": "application/json"}
    if cfg["token"]:
        headers["X-Farm-Token"] = cfg["token"]
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20, context=_tg_milk_ssl_ctx()) as resp:
            raw = resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise RuntimeError("сервер не прийняв токен (401)") from exc
        raise RuntimeError("сервер відповів %d" % exc.code) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("немає звʼязку із сервером (%s)" % exc.reason) from exc
    return json.loads(raw) if raw.strip() else {}


def _tg_milk_form_payload() -> dict:
    """Опис форми для бота: ЛИШЕ колонки з галочкою «Telegram»."""
    forms = db.list_milk_forms()
    if not forms:
        return {}
    form = forms[0]
    fields = [f for f in db.list_milk_form_fields(int(form["id"]))
              if f.get("ask_tg") and (f.get("kind") or "") != "formula"]
    out = {
        "form": {"id": int(form["id"]), "name": form["name"],
                 "per_shift": bool(form.get("per_shift", 1))},
        "fields": [{
            "id": int(f["id"]), "label": f["label"], "kind": f["kind"],
            "unit": f.get("unit") or "", "section": f.get("section") or "shift",
            "sort_order": int(f.get("sort_order") or 0),
            "decimals": int(f.get("decimals") if f.get("decimals") is not None else -1),
            "auto_dot": int(f.get("auto_dot") or 0),
            "default_value": f.get("default_value") or "",
        } for f in fields],
    }
    # Версія набору: змінилась назва/склад/порядок колонок — змінилась версія.
    # Сервер за нею розуміє, що перелік питань оновився (повна заміна, не доповнення).
    sig = "|".join("%s:%s:%s:%s" % (x["id"], x["label"], x["section"], x["sort_order"])
                   for x in out["fields"])
    out["version"] = hashlib.sha1(sig.encode("utf-8")).hexdigest()[:12]
    out["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return out


def _tg_milk_push_form() -> int:
    """Надіслати опис колонок на сервер. Повертає, скільки полів надіслано."""
    payload = _tg_milk_form_payload()
    if not payload:
        return 0
    _tg_milk_call("/api/milk/form", payload)
    db.set_setting("milk_tg_error", "")
    return len(payload["fields"])


def _tg_milk_form_adopt() -> None:
    """Разово (за версією) забрати з сервера ферми ПОВНЕ означення форми молока
    і засвоїти локально з точними id колонок. Немає експорту на сервері (404)
    або версія вже засвоєна — тихо нічого не робимо."""
    try:
        res = _tg_milk_call("/api/milk/form-full", None, "GET") or {}
    except Exception:  # noqa: BLE001
        return
    ver = str(res.get("version") or "")
    if not ver or not res.get("fields"):
        return
    if db.get_setting("milk_form_adopted", "") == ver:
        return
    db.milk_adopt_form(res)
    db.set_setting("milk_form_adopted", ver)
    # Курсор черги міг «утекти» вперед ще ДО засвоєння (старий обмін пропускав
    # чужі id, але курсор рухав) — після засвоєння перечитуємо історію з нуля:
    # запис у форму — upsert за (дата, зміна), тож повтори безпечні.
    db.set_setting("milk_tg_since", "0")
    db.set_setting("milk_tg_skipped", "0")


def _tg_milk_pull() -> int:
    """Забрати чергу бота й записати рядки. Повертає, скільки застосовано.

    Правила з ТЗ сервера: сторінками по 200; строго за зростанням id; курсор
    рухається ЛИШЕ після того, як запис реально ліг у базу; повторний запис
    із тим самим id ігнорується (сервер нічого не видаляє — курсор ведемо ми).
    """
    cfg = _tg_milk_cfg()
    forms = db.list_milk_forms()
    if not forms:
        return 0
    fid = int(forms[0]["id"])
    by_id = {int(f["id"]): f["label"] for f in db.list_milk_form_fields(fid)}
    since = cfg["since"]
    saved, skipped, pages = 0, int(db.get_setting("milk_tg_skipped", "0") or 0), 0
    while pages < 20:                      # запобіжник від нескінченного циклу
        pages += 1
        res = _tg_milk_call("/api/milk/pull?since=%d" % since, None, "GET") or {}
        rows = res.get("entries") or res.get("rows") or []
        if not rows:
            break
        rows = sorted(rows, key=lambda r: int(r.get("id") or 0))
        for r in rows:
            eid = int(r.get("id") or 0)
            if eid <= since:               # вже застосовано — тихо пропускаємо
                continue
            vals, miss = {}, 0
            for k, v in (r.get("values") or {}).items():
                # ключ — id колонки, тож перейменування нічого не ламає
                label = by_id.get(int(k)) if str(k).isdigit() else str(k)
                if label:
                    vals[label] = v
                else:
                    miss += 1              # колонку прибрали, поки відповідь чекала
            try:
                if vals:
                    # upsert за (дата, зміна): повторний запис — це ВИПРАВЛЕННЯ,
                    # а не другий рядок поруч
                    db.save_milk_entry(fid, str(r.get("run_date") or "")[:10],
                                       str(r.get("shift") or ""), vals,
                                       "telegram:" + str(r.get("who") or ""))
                    saved += 1
                skipped += miss
                since = eid                # курсор — тільки після успішного запису
                db.set_setting("milk_tg_since", str(since))
            except Exception as exc:       # noqa: BLE001
                db.set_setting("milk_tg_error", "запис %d: %s" % (eid, str(exc)[:150]))
                break
        if len(rows) < 200:                # черга вичерпалась
            break
    db.set_setting("milk_tg_last", datetime.now().strftime("%Y-%m-%d %H:%M"))
    db.set_setting("milk_tg_skipped", str(skipped))
    db.set_setting("milk_tg_applied",
                   str(int(db.get_setting("milk_tg_applied", "0") or 0) + saved))
    return saved


def _tg_feed_pull() -> int:
    """Забрати з сервера чергу РУЧНИХ видач кормів (внесені в Telegram
    «Мій день») і провести їх звичайною видачею OUT на групу.

    Правила ті самі, що в molока: сторінками, за зростанням id, курсор
    (feed_tg_since) рухається після успішного проведення. Записи одного
    запиту з однаковими (день, група) проводяться ОДНИМ документом.
    Збій проведення (немає корму на складі тощо) фіксується в
    feed_tg_error, запис пропускається — черга не стопориться, а
    відсутність оповіщення в гілці «Годівля» покаже проблему."""
    since = int(db.get_setting("feed_tg_since", "0") or 0)
    done, pages = 0, 0
    while pages < 20:
        pages += 1
        res = _tg_milk_call("/api/feed/issue-pull?since=%d" % since, None, "GET") or {}
        rows = res.get("entries") or []
        if not rows:
            break
        rows = sorted(rows, key=lambda r: int(r.get("id") or 0))
        # групуємо поспіль за (день, група) — одна видача = один документ
        groups: list = []
        for r in rows:
            if int(r.get("id") or 0) <= since:
                continue
            key = (str(r.get("day") or "")[:10], int(r.get("block_id") or 0))
            if groups and groups[-1][0] == key:
                groups[-1][1].append(r)
            else:
                groups.append((key, [r]))
        for (day, block_id), ls in groups:
            top = max(int(x.get("id") or 0) for x in ls)
            who = str(ls[0].get("who") or "").strip()
            lines = [{"barcode": str(x.get("barcode") or ""),
                      "qty": float(x.get("qty") or 0),
                      "block_id": block_id} for x in ls
                     if x.get("barcode") and float(x.get("qty") or 0) > 0]
            try:
                if lines and block_id:
                    db.process_sale(lines, move_type="OUT",
                                    note="Telegram · " + (who or "видача"),
                                    user_id=None, block_id=block_id, op_date=day)
                    done += len(lines)
            except Exception as exc:  # noqa: BLE001
                db.set_setting("feed_tg_error",
                               "видача %d: %s" % (top, str(exc)[:150]))
            since = top
            db.set_setting("feed_tg_since", str(since))
        if len(rows) < 200:
            break
    if done:
        db.set_setting("feed_tg_last", datetime.now().strftime("%Y-%m-%d %H:%M"))
    return done


# Колонка форми обліку молока (розділ «продаж») → колонка таблиці dairyFactory
# на аркуші «Продаж» + множник (відсотки в Excel зберігаються часткою: 3.84 → 0.0384).
_EXCEL_SALE_MAP = {
    "Продано л": ("salefact_nakladna_l", 1.0),
    "Жир ферма": ("section_fat%", 0.01),
    "Білок ферма": ("section_protein%", 0.01),
    "Прийнято кг": ("sale_milk_kg_factory", 1.0),
    "Жир завод": ("section_fat%_factory", 0.01),
    "Білок завод": ("section_protein%_factory", 0.01),
}


# Колонка форми (зміни am/pm) → колонка таблиці product_milk («Виробництво»):
# {label: (col_зміна1, col_зміна2)}; None — колонка одна на день (пишеться з
# будь-якої зміни, якщо порожня). Мапінг підтверджено Романом 2026-08-28.
_EXCEL_PROD_MAP = {
    "Виробн. молока товарне л": ("1-session", "2-session"),
    "Виробн. молока товарне кг": ("sale_1-session_kg", "sale_2-session_kg"),
    "Маститне молоко": ("mastitis_milk_1-session", "mastitis_milk_2-session"),
    "Родильне відділення": ("market_milk_1", "market_milk_2"),
    # Бики/телиці — ПОЗМІННО (Роман 2026-08-28 додав 4 колонки в Excel):
    # сума за день не працювала — «лише порожні клітинки» блокував другу
    # зміну, коли перша вже записала свою суму в спільну клітинку
    "Молоко бикам": ("milk_bull_1-session", "milk_bull_2-session"),
    "Молоко телицям": ("milk_heifer_1-session", "milk_heifer_2-session"),
}


def _excel_ensure_date_rows(ws, table, day: str, rows_per_day: int) -> bool:
    """Дописати в кінець таблиці рядки дат до `day` включно (авто-продовження
    за рішенням Романа 2026-08-28): дата в колонку A, формули розрахункових
    колонок — зі структурованих формул таблиці, ref таблиці розширюється.
    Якщо `day` — остання дата таблиці, дотягує їй рядки до rows_per_day.
    Повертає True, якщо щось додано."""
    from copy import copy as _copy
    first_row = int(str(table.ref).split(":")[0].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) + 1
    ref_end = str(table.ref).split(":")[1]
    end_col = "".join(ch for ch in ref_end if ch.isalpha())
    last_row = int("".join(ch for ch in ref_end if ch.isdigit()))
    target = date.fromisoformat(day)
    last_date, last_date_rows = None, 0
    for rr in range(first_row, last_row + 1):
        v = ws.cell(row=rr, column=1).value
        if hasattr(v, "date"):
            if last_date == v.date():
                last_date_rows += 1
            else:
                last_date, last_date_rows = v.date(), 1
    if last_date is None or (target - last_date).days > 40:
        return False                       # дивна прірва — не чіпаємо файл
    todo: list[tuple[date, int]] = []
    if target == last_date and last_date_rows < rows_per_day:
        todo.append((target, rows_per_day - last_date_rows))
    d = last_date
    while d < target:
        d = d + timedelta(days=1)
        todo.append((d, rows_per_day))
    if not todo:
        return False
    formulas = {i + 1: "=" + c.calculatedColumnFormula.attr_text
                for i, c in enumerate(table.tableColumns)
                if c.calculatedColumnFormula is not None
                and getattr(c.calculatedColumnFormula, "attr_text", None)}
    ncols = len(table.tableColumns)
    r = last_row
    for dd, cnt in todo:
        for _ in range(cnt):
            r += 1
            # формат КОЖНОЇ клітинки — копія з останнього рядка таблиці
            # (числові формати, рамки, заливки; «формат продовжується»)
            for ci in range(1, ncols + 1):
                ws.cell(row=r, column=ci)._style = _copy(
                    ws.cell(row=last_row, column=ci)._style)
            dc = ws.cell(row=r, column=1)
            dc.value = datetime(dd.year, dd.month, dd.day)
            for ci, f in formulas.items():
                ws.cell(row=r, column=ci).value = f
    table.ref = str(table.ref).split(":")[0] + ":" + end_col + str(r)
    return True


def _excel_backfill_production(wb, entries, wrote_notes=None, journal=None) -> int:
    """Дописати дані виробництва (зміни am/pm) у аркуш «Виробництво» —
    лише порожні клітинки. Повертає к-сть записаних клітинок; у wrote_notes
    (якщо передали) додає рядки «що і куди» для нотатки адміну."""
    if wrote_notes is None:
        wrote_notes = []
    if journal is None:
        journal = {}
    ws = wb["Виробництво"]
    table = ws.tables["product_milk"]
    cols = [c.name for c in table.tableColumns]
    col_idx = {n: i + 1 for i, n in enumerate(cols)}
    first_row = int(str(table.ref).split(":")[0].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) + 1
    by_day: dict[str, int] = {}
    for row in ws.iter_rows(min_row=first_row, max_row=ws.max_row, max_col=1):
        v = row[0].value
        if hasattr(v, "date"):
            by_day.setdefault(v.date().isoformat(), row[0].row)
    changed = 0
    for e in entries:
        r = by_day.get(e["date"])
        if not r and _excel_ensure_date_rows(ws, table, e["date"], 1):
            by_day.clear()
            first_row = int(str(table.ref).split(":")[0].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) + 1
            for row in ws.iter_rows(min_row=first_row, max_row=ws.max_row, max_col=1):
                v = row[0].value
                if hasattr(v, "date"):
                    by_day.setdefault(v.date().isoformat(), row[0].row)
            r = by_day.get(e["date"])
        if not r:
            db.set_setting("milk_excel_write_error",
                           "Виробництво %s: немає рядка дати" % e["date"])
            continue
        for label, pair in _EXCEL_PROD_MAP.items():
            raw = str(e["values"].get(label) or "").strip()
            col = pair[0] if e["n"] == 1 else pair[1]
            if not raw or col not in col_idx:
                continue
            cell = ws.cell(row=r, column=col_idx[col])
            try:
                newv = round(float(raw.replace(",", ".")), 6)
            except ValueError:
                continue
            if newv < 0:
                # відʼємне «молоко» = формула форми з НЕВНЕСЕНИМ операндом
                # (напр. мастит = всього − товарне при порожньому «всього»):
                # не пишемо проміжок; коли внесуть — значення прийде і
                # заміниться журналом власних клітинок
                continue
            res = _excel_put(cell, newv, "Вир:%s:%d:%s" % (e["date"], e["n"], col),
                             journal)
            if res:
                changed += 1
                wrote_notes.append("Виробництво %s · зміна %d · %s %s %s"
                                   % (e["date"][8:10] + "." + e["date"][5:7],
                                      e["n"], label,
                                      "=" if res == "new" else "виправлено на", raw))
        # inTank_N-session = «Додано в танк від пробл.» − «Взято з танка на
        # випойку» (мапінг Романа 2026-08-28; може бути відʼємним)
        def _f(lbl):
            s = str(e["values"].get(lbl) or "").strip().replace(",", ".")
            try:
                return float(s) if s else None
            except ValueError:
                return None
        added, taken = _f("Додано в танк молока від пробл."), \
            _f("Взято з танка молока на випойку")
        if added is not None or taken is not None:
            col = "inTank_1-session" if e["n"] == 1 else "inTank_2-session2"
            if col in col_idx:
                cell = ws.cell(row=r, column=col_idx[col])
                newv = round((added or 0.0) - (taken or 0.0), 6)
                res = _excel_put(cell, newv, "Вир:%s:%d:%s" % (e["date"], e["n"], col),
                                 journal)
                if res:
                    changed += 1
                    wrote_notes.append(
                        "Виробництво %s · зміна %d · В танк (дод.−взято) %s %s"
                        % (e["date"][8:10] + "." + e["date"][5:7], e["n"],
                           "=" if res == "new" else "виправлено на", round(newv, 3)))
    return changed


def _excel_journal_load() -> dict:
    """Журнал клітинок, які записав МІСТ (ключ «аркуш:день:№:колонка» →
    значення). Дає право оновлювати ВЛАСНІ записи (виправлення з бота),
    ніколи не чіпаючи внесене людиною в Excel (Роман 2026-08-30:
    «Треба зробити заміну даних в ексель»)."""
    try:
        j = json.loads(db.get_setting("milk_excel_cells", "") or "{}")
    except Exception:  # noqa: BLE001
        j = {}
    # чистка: журнал потрібен лише на глибину проходу запису (+запас)
    edge = (date.today() - timedelta(days=30)).isoformat()
    return {k: v for k, v in j.items()
            if len(k.split(":")) > 1 and k.split(":")[1] >= edge}


def _excel_journal_save(j: dict) -> None:
    try:
        db.set_setting("milk_excel_cells", json.dumps(j))
    except Exception:  # noqa: BLE001
        pass


def _excel_put(cell, newv: float, key: str, journal: dict) -> str:
    """Записати значення у клітинку за правилами моста. Повертає:
    'new' — записано в порожню; 'upd' — оновлено ВЛАСНЕ (ботівське) значення;
    '' — нічого (збіг або людське значення)."""
    cur = cell.value
    if cur in (None, ""):
        cell.value = newv
        journal[key] = newv
        return "new"
    try:
        curf = float(cur)
    except (TypeError, ValueError):
        return ""                          # текст людини — не чіпаємо
    if abs(curf - newv) < 1e-9:
        journal[key] = newv                # значення вже таке — «всиновлюємо»
        return ""
    prev = journal.get(key)
    if prev is not None and abs(curf - float(prev)) < 1e-9:
        cell.value = newv                  # у клітинці НАШЕ старе → виправляємо
        journal[key] = newv
        return "upd"
    return ""                              # людина писала/правила — недоторканно


def _excel_file_is_open(path: str) -> bool:
    """Чи відкритий файл у Excel. Маркер ~$ (класика Windows) + Windows-лок
    + lsof на macOS (OneDrive-файли на Mac маркера не створюють)."""
    try:
        if os.path.exists(os.path.join(os.path.dirname(path),
                                       "~$" + os.path.basename(path))):
            return True
        if sys.platform == "win32":
            try:
                with open(path, "r+b"):
                    pass
                return False
            except PermissionError:
                return True
        import subprocess
        res = subprocess.run(["lsof", "-t", "--", path],
                             capture_output=True, timeout=10)
        return bool(res.stdout.strip())
    except Exception:  # noqa: BLE001
        return False                      # не змогли перевірити — не блокуємо


def _excel_recalc_native(path: str) -> None:
    """Після збереження openpyxl файл лишається БЕЗ кешу формул (обчислювані
    колонки читаються як порожні). На macOS повертаємо кеш, давши файл
    перерахувати самому Excel.

    ГОЛОВНЕ ПРАВИЛО (Роман 2026-09-02): якщо людина працює в Excel — навіть з
    ІНШИМИ файлами — не лізти туди взагалі. Причина: `calculate` рахує всі
    відкриті книги, а робота через «активну книгу» могла б зберегти й закрити
    чужий файл, якби фокус змінився під час нашої роботи. Тому перерахунок
    робиться, ЛИШЕ коли Excel закритий або в ньому немає жодної книги; інакше
    крок відкладається до наступного циклу (дані вже записані, а читання
    захищене нуль-гардами web_db з 1.61.0).

    На Windows кроку немає: там кеш відновлює людина, відкривши файл."""
    if sys.platform != "darwin":
        return
    script = (
        'set p to POSIX file "%s"\n'
        'set busy to false\n'
        'tell application "System Events"\n'
        '  set isRunning to (exists process "Microsoft Excel")\n'
        'end tell\n'
        # питаємо кількість книг лише в уже запущеного Excel — інакше сам
        # запит його б і запустив
        'if isRunning then\n'
        '  tell application "Microsoft Excel"\n'
        '    if (count of workbooks) > 0 then set busy to true\n'
        '  end tell\n'
        'end if\n'
        'if busy then\n'
        '  return "busy"\n'
        'end if\n'
        'tell application "Microsoft Excel"\n'
        '  set su to screen updating\n'
        '  set screen updating to false\n'
        '  open p\n'
        # Excel не повертає посилання з `open`, тож беремо книгу адресно:
        # книг перед цим було 0 (перевірено вище), отже перша — наша
        '  set wb to workbook 1\n'
        '  delay 2\n'
        '  calculate\n'
        '  save wb\n'
        '  close wb\n'
        '  set screen updating to su\n'
        '  set wbLeft to count of workbooks\n'
        'end tell\n'
        # по собі не лишаємо запущений порожній Excel
        'if wbLeft = 0 then\n'
        '  tell application "Microsoft Excel" to quit\n'
        'end if\n'
        'return "done"' % path.replace('"', '\\"'))
    try:
        res = subprocess.run(["osascript", "-e", script], timeout=120,
                             capture_output=True, text=True)
        out = (res.stdout or "").strip()
        if out == "busy":
            # людина працює в Excel — спробуємо наступного разу
            db.set_setting("milk_excel_recalc_skipped",
                           datetime.now().strftime("%Y-%m-%d %H:%M"))
        elif out == "done":
            db.set_setting("milk_excel_recalc_skipped", "")
    except Exception as exc:  # noqa: BLE001
        try:
            db.set_setting("milk_excel_write_error",
                           "перерахунок Excel: %s" % str(exc)[:150])
        except Exception:  # noqa: BLE001
            pass


def _excel_backfill_sales(days_back: int = 3) -> int:
    """Дописати дані продажу з БД (введені через Telegram) у РОБОЧИЙ Excel —
    ЛИШЕ в порожні клітинки (рішення Романа 2026-08-27): людські записи ніколи
    не перезаписуються, повторний прохід нічого не задвоює. Відсік N = N-й
    рядок дати в таблиці dairyFactory. Перед першим записом дня — бекап файлу.
    Best-effort: будь-який збій пишеться в milk_excel_write_error і не ламає
    обмін."""
    import shutil
    from openpyxl import load_workbook
    # У хмарі Excel — лише читання (копія з OneDrive через rclone): писати в
    # неї не можна, інакше розійдеться з файлом, який редагують на ПК.
    if SERVER_MODE and os.environ.get("BOVIO_EXCEL_WRITE", "") != "1":
        return 0
    try:
        cfg = _milk_config()
        path = (cfg.get("file_path") or "").strip()
        forms = db.list_milk_forms()
        if not path or not os.path.exists(path) or not forms:
            return 0
        # Файл відкритий в Excel — НЕ пишемо: людина може зберегти свою копію
        # поверх і затерти наш запис. Клітинки порожні, тож допишуться
        # наступним циклом після закриття. Маркер ~$ на OneDrive-файлах Mac
        # не створюється, тому перевіряємо чесно: Windows — ексклюзивний лок
        # (відкриття r+b падає), macOS — lsof по файлу.
        if _excel_file_is_open(path):
            db.set_setting("milk_excel_write_error",
                           "файл відкритий в Excel — запис відкладено")
            return 0
        day_from = (date.today() - timedelta(days=days_back)).isoformat()
        entries = db.milk_sale_runs_since(int(forms[0]["id"]), day_from)
        prod_entries = db.milk_shift_runs_since(int(forms[0]["id"]), day_from)
        if not entries and not prod_entries:
            return 0
        wb = load_workbook(path)
        journal = _excel_journal_load()        # наші клітинки: можна оновлювати
        _j0 = dict(journal)
        wrote_notes: list[str] = []            # що і куди дописали — для нотатки
        ws = wb["Продаж"]
        table = ws.tables["dairyFactory"]
        cols = [c.name for c in table.tableColumns]
        col_idx = {n: i + 1 for i, n in enumerate(cols)}      # 1-based
        # рядки таблиці за датою (порядок = номер відсіку)
        first_row = int(str(table.ref).split(":")[0].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ")) + 1
        by_day: dict[str, list[int]] = {}
        for row in ws.iter_rows(min_row=first_row, max_row=ws.max_row, max_col=1):
            v = row[0].value
            if hasattr(v, "date"):
                by_day.setdefault(v.date().isoformat(), []).append(row[0].row)
        changed = 0
        for e in entries:
            rows = by_day.get(e["date"]) or []
            if len(rows) < e["n"] and _excel_ensure_date_rows(
                    ws, table, e["date"], max(3, e["n"])):
                by_day.clear()
                for row in ws.iter_rows(min_row=first_row, max_row=ws.max_row, max_col=1):
                    v = row[0].value
                    if hasattr(v, "date"):
                        by_day.setdefault(v.date().isoformat(), []).append(row[0].row)
                rows = by_day.get(e["date"]) or []
            if len(rows) < e["n"]:
                db.set_setting("milk_excel_write_error",
                               "%s: немає рядка для відсіку %d" % (e["date"], e["n"]))
                continue
            r = rows[e["n"] - 1]
            for label, (col, factor) in _EXCEL_SALE_MAP.items():
                raw = str(e["values"].get(label) or "").strip()
                if not raw or col not in col_idx:
                    continue
                cell = ws.cell(row=r, column=col_idx[col])
                try:
                    newv = round(float(raw.replace(",", ".")) * factor, 6)
                except ValueError:
                    continue
                if newv < 0:
                    continue    # відʼємна кількість = недорахована формула форми
                res = _excel_put(cell, newv, "Продаж:%s:%d:%s" % (e["date"], e["n"], col),
                                 journal)
                if res:
                    changed += 1
                    # у нотатку — людське значення (як у Telegram), не факторне
                    wrote_notes.append("Продаж %s · відсік %d · %s %s %s"
                                       % (e["date"][8:10] + "." + e["date"][5:7],
                                          e["n"], label,
                                          "=" if res == "new" else "виправлено на", raw))
        changed += _excel_backfill_production(wb, prod_entries, wrote_notes, journal)
        if journal != _j0:                     # «всиновлення» теж зберігаємо
            _excel_journal_save(journal)
        if changed:
            bdir = os.path.join(str(db.db_path.parent), "backups_excel")
            os.makedirs(bdir, exist_ok=True)
            bak = os.path.join(bdir, "%s-%s" % (date.today().isoformat(),
                                                os.path.basename(path)))
            if not os.path.exists(bak):
                shutil.copy2(path, bak)            # бекап — раз на день
            wb.save(path)
            _excel_recalc_native(path)
            db.set_setting("milk_excel_write_last",
                           datetime.now().strftime("%Y-%m-%d %H:%M") + " · %d кліт." % changed)
            db.set_setting("milk_excel_write_error", "")
            # особиста нотатка адміну бота (НЕ в групу): що саме дописано
            try:
                # перелік «що і куди»; хвіст ріжемо під ліміт Telegram (4096)
                lines = wrote_notes[:40]
                if len(wrote_notes) > len(lines):
                    lines.append("… і ще %d кліт." % (len(wrote_notes) - len(lines)))
                _tg_milk_call("/api/milk/excel-note", {
                    "text": "📗 Excel: дописано %d кліт. (%s)\n%s"
                            % (changed, datetime.now().strftime("%d.%m %H:%M"),
                               "\n".join("• " + t for t in lines))})
            except Exception:  # noqa: BLE001
                pass
        return changed
    except Exception as exc:  # noqa: BLE001
        try:
            db.set_setting("milk_excel_write_error", str(exc)[:200])
        except Exception:  # noqa: BLE001
            pass
        return 0


def _start_tg_milk_sync() -> None:
    """Фоновий обмін: раз на 3 хвилини віддати форму й забрати записи."""
    import threading

    def loop():
        while True:
            try:
                cfg = _tg_milk_cfg()
                if cfg["on"] and cfg["url"]:
                    _tg_milk_form_adopt()
                    _tg_milk_push_form()
                    _got = _tg_milk_pull()
                    if _got:
                        db.bovio_log_add(
                            "bot_in", "Telegram-бот → сервер · записів молока: %d" % _got)
                    _tg_feed_pull()
                    _excel_backfill_sales()
                    db.set_setting("milk_tg_error", "")
            except Exception as exc:  # noqa: BLE001
                try:
                    db.set_setting("milk_tg_error", str(exc)[:200])
                except Exception:  # noqa: BLE001
                    pass
            time.sleep(180)

    threading.Thread(target=loop, daemon=True).start()


@app.get("/api/milk/tg")
def api_milk_tg_info():
    cfg = _tg_milk_cfg()
    payload = _tg_milk_form_payload()
    cfg["fields"] = len(payload.get("fields") or [])
    cfg["version"] = payload.get("version") or ""
    cfg["applied"] = int(db.get_setting("milk_tg_applied", "0") or 0)
    cfg["skipped"] = int(db.get_setting("milk_tg_skipped", "0") or 0)
    cfg["token"] = "•" * len(cfg["token"]) if cfg["token"] else ""
    return _ok(cfg)


@app.post("/api/milk/tg")
def api_milk_tg_save():
    g = _manage_guard("milk")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    db.set_setting("milk_tg_on", "1" if d.get("on") else "0")
    db.set_setting("milk_tg_url", str(d.get("url") or "").strip())
    tok = str(d.get("token") or "").strip()
    if tok and not set(tok) <= {"•"}:
        db.set_setting("milk_tg_token", tok)
    return _ok({})


@app.post("/api/milk/tg/sync")
def api_milk_tg_sync():
    """Обмін просто зараз (кнопка в налаштуваннях).

    Це дія РОБОТИ, а не налаштування: фоновий обмін і так іде щотри хвилини,
    кнопка лише не змушує чекати. Тому вистачає рівня «робота» на молоко —
    інакше людина, яка веде молоко, не могла б підштовхнути обмін сама."""
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if _branch_level(u, "milk") not in ("work", "manage"):
        return _err("Потрібен доступ до гілки «Виробництво молока».", 403)
    if not _work_place_ok(u):
        return _err(_WORK_PLACE_MSG[_user_work_place(u)], 403)
    try:
        _tg_milk_form_adopt()
        sent = _tg_milk_push_form()
        got = _tg_milk_pull()
        db.set_setting("milk_tg_error", "")
        return _ok({"sent": sent, "got": got,
                    "skipped": int(db.get_setting("milk_tg_skipped", "0") or 0)})
    except Exception as exc:  # noqa: BLE001
        db.set_setting("milk_tg_error", str(exc)[:200])
        return _err(f"Не вдалося: {exc}")


@app.post("/api/milk/fields/width")
def api_milk_fields_width():
    """Запамʼятати ширину колонок: {form, widths:{id: пікселі}}."""
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        return _ok({"saved": db.save_milk_col_widths(fid, d.get("widths") or {})})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/milk/fields/move")
def api_milk_fields_move():
    """Перенести значення зі старої назви колонки в наявну: {form, from, to}."""
    g = _manage_guard("milk")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        if not fid:
            forms = db.list_milk_forms()
            fid = int(forms[0]["id"]) if forms else 0
        moved = db.milk_move_values(fid, d.get("from") or "", d.get("to") or "")
        return _ok({"moved": moved, "orphans": db.milk_orphan_values(fid)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/milk/fields/cleanup")
def api_milk_fields_cleanup():
    """Прибрати значення колонок, яких у формі вже немає (лише за кнопкою)."""
    g = _manage_guard("milk")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    try:
        fid = int(d.get("form") or 0)
        if not fid:
            forms = db.list_milk_forms()
            fid = int(forms[0]["id"]) if forms else 0
        return _ok({"dropped": db.milk_prune_orphans(fid),
                    "orphans": db.milk_orphan_values(fid)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.route("/milk/notify")
def page_milk_notify():
    g = _manage_guard("milk")
    if g is not None:
        return redirect("/milk")
    opts = [{"id": o["id"], "label": o["label"], "unit": o["unit"],
             "ds_label": o["ds_label"]} for o in _milk_metric_options()]
    ncfg = _milk_notify_config()
    has_tg = bool((db.get_setting("notify_tg_token", "") or "").strip()
                  and (db.get_setting("notify_tg_chat", "") or "").strip())
    return render_template("milk_notify.html", active="milk_notify",
                           ncfg=ncfg, options=opts, has_tg=has_tg,
                           notify_time=db.get_setting("notify_time", "08:00"))


@app.post("/api/milk/notify")
def api_milk_notify_save():
    g = _manage_guard("milk")
    if g is not None:
        return g
    data = request.get_json(silent=True) or {}
    cfg = _milk_notify_config()
    for k in ("enabled", "cmp_week", "cmp_month"):
        if k in data:
            cfg[k] = bool(data[k])
    if "time" in data:
        cfg["time"] = str(data["time"]).strip() or "10:20"
    if "include" in data and isinstance(data["include"], list):
        cfg["include"] = [str(x) for x in data["include"]]
    db.set_setting("milk_notify", json.dumps(cfg, ensure_ascii=False))
    return jsonify({"ok": True})


@app.get("/api/milk/notify/preview")
def api_milk_notify_preview():
    g = _manage_guard("milk")
    if g is not None:
        return g
    return jsonify({"ok": True, "text": build_milk_digest()})


@app.post("/api/milk/notify/test")
def api_milk_notify_test():
    g = _manage_guard("milk")
    if g is not None:
        return g
    ok, msg = send_milk_digest_now(test=True)
    return jsonify({"ok": ok, "error": None if ok else msg})


# ---- Telegram-звіти складських гілок (Аптека / Матеріали) ----
@app.route("/notify")
def page_wh_notify():
    """Telegram-звіти складської гілки. Категорія береться з префікса шляху:
    /notify — Аптека, /m/notify — Матеріали, /f/notify — Годівля."""
    if not _is_admin():
        return redirect("/")
    cat = _inv_category()
    has_tg = bool((db.get_setting("notify_tg_token", "") or "").strip()
                  and (db.get_setting("notify_tg_chat", "") or "").strip())
    return render_template("wh_notify.html", active="wh_notify",
                           cat=cat, label=_wh_label(cat), cfg=_wh_notify_cfg(cat),
                           notify_time=db.get_setting("notify_time", "08:00"),
                           has_tg=has_tg)


def _wh_cat_ok(cat):
    return cat in dict(_WH_BRANCHES)


@app.post("/api/wh/notify/<cat>")
def api_wh_notify_save(cat):
    if not _is_admin():
        return _err("Лише адміністратор.", 403)
    if not _wh_cat_ok(cat):
        return _err("Невідома гілка.", 404)
    data = request.get_json(silent=True) or {}
    cfg = _wh_notify_cfg(cat)
    for k in ("enabled", "inc_low", "inc_expiring", "inc_expired", "inc_daily"):
        if k in data:
            cfg[k] = bool(data[k])
    if "expiry_days" in data:
        try:
            cfg["expiry_days"] = max(1, int(data["expiry_days"]))
        except (TypeError, ValueError):
            pass
    db.set_setting(f"wh_notify_{cat}", json.dumps(cfg, ensure_ascii=False))
    return jsonify({"ok": True})


@app.get("/api/wh/notify/<cat>/preview")
def api_wh_notify_preview(cat):
    if not _is_admin():
        return _err("Лише адміністратор.", 403)
    if not _wh_cat_ok(cat):
        return _err("Невідома гілка.", 404)
    return jsonify({"ok": True, "text": build_wh_digest(cat)})


@app.post("/api/wh/notify/<cat>/test")
def api_wh_notify_test(cat):
    if not _is_admin():
        return _err("Лише адміністратор.", 403)
    if not _wh_cat_ok(cat):
        return _err("Невідома гілка.", 404)
    ok, msg = send_wh_digest_now(cat, test=True)
    return jsonify({"ok": ok, "error": None if ok else msg})


@app.post("/api/notify/ping")
def api_notify_ping():
    """Проста перевірка бота: коротке повідомлення в чат."""
    data = request.get_json(silent=True) or {}
    tok = (data.get("token") or "").strip()
    chat = (data.get("chat_id") or "").strip()
    if tok:
        db.set_setting("notify_tg_token", tok)
    if chat:
        db.set_setting("notify_tg_chat", chat)
    ok, msg = db.send_telegram(db.get_setting("notify_tg_token", ""),
                               db.get_setting("notify_tg_chat", ""),
                               "✅ Бот працює. Це перевірка з застосунку «Облік ферми».")
    if not ok:
        return _err(f"Не вдалося надіслати: {msg}")
    return _ok({"message": "Надіслано"})


@app.post("/api/settings/business")
def api_settings_business():
    data = request.get_json(silent=True) or {}
    allowed = {"name", "entity", "edrpou", "address", "phone"}
    current = load_business()
    for k in allowed:
        if k in data:
            current[k] = (data.get(k) or "").strip()
    # ПДВ — окремо: bool + float
    if "is_vat_payer" in data:
        current["is_vat_payer"] = bool(data.get("is_vat_payer"))
    if "vat_rate" in data:
        try:
            current["vat_rate"] = float(data.get("vat_rate") or 0)
        except (TypeError, ValueError):
            pass
    try:
        BUSINESS_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(BUSINESS_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(current, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        return _err(f"Не вдалося зберегти: {exc}")
    return _ok({"business": current})


# ---- режим сервера (доступ з інших пристроїв у мережі) ----
SERVER_MODE_FLAG = BUSINESS_CONFIG_PATH.parent / "server_mode"


def _server_mode_enabled() -> bool:
    try:
        return SERVER_MODE_FLAG.read_text(encoding="utf-8").strip() == "1"
    except Exception:  # noqa: BLE001
        return False


def _lan_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return ""


@app.post("/api/stock/relink-moves")
def api_relink_moves():
    """Переписати історію списань КОНКРЕТНОГО корму за FIFO.

    dry_run=true — лише показати план (нічого не змінюючи). Кількості, дати й
    документи не змінюються; змінюється те, з якої партії взято корм."""
    if not _is_admin():
        return _err("Потрібні права адміністратора.", 403)
    data = request.get_json(silent=True) or {}
    pid = int(data.get("product_id") or 0)
    if not pid:
        return _err("Оберіть корм.")
    try:
        res = db.rebuild_moves_fifo(product_id=pid,
                                    dry_run=bool(data.get("dry_run", True)))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok(res)


@app.post("/api/stock/rebuild-batches")
def api_rebuild_batches():
    """Вирівняти залишок по партіях за FIFO (дата приходу).

    Документи не чіпаються — міняється лише те, на якій партії лежить залишок.
    Потрібно, коли списання свого часу пішло не з тієї партії (накладну внесли
    пізніше за заміс)."""
    if not _is_admin():
        return _err("Потрібні права адміністратора.", 403)
    data = request.get_json(silent=True) or {}
    try:
        res = db.rebuild_batches_fifo(product_id=int(data.get("product_id") or 0),
                                      category=_inv_category())
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok(res)


@app.get("/api/feed/self-check")
def api_self_check():
    """Самоперевірка обчислень (годівля + склад) — панель у Налаштуваннях годівлі."""
    return _ok(db.self_check())


@app.get("/api/settings/server-mode")
def api_server_mode_get():
    return _ok({"enabled": _server_mode_enabled(), "lan_ip": _lan_ip()})


@app.post("/api/settings/server-mode")
def api_server_mode_set():
    data = request.get_json(silent=True) or {}
    on = bool(data.get("enabled"))
    try:
        SERVER_MODE_FLAG.parent.mkdir(parents=True, exist_ok=True)
        SERVER_MODE_FLAG.write_text("1" if on else "0", encoding="utf-8")
    except OSError as exc:
        return _err(f"Не вдалося зберегти: {exc}")
    return _ok({"enabled": on})


@app.get("/api/settings/branches")
def api_settings_branches_get():
    """Список гілок із позначками: видимість, блокування ліцензією, готовність."""
    hidden = _hidden_branch_ids()
    lic = _licensed_branch_id_set()
    items = [{
        "id": b["id"], "label": b["label"], "icon": b["icon"],
        "ready": b["ready"],
        "locked": b["id"] not in lic,          # заблоковано ліцензією
        "visible": b["id"] not in hidden,      # показувати в меню
    } for b in BRANCHES if b["id"] != "hub"]
    return _ok({"branches": items})


@app.post("/api/settings/branches")
def api_settings_branches_set():
    """Зберегти список прихованих гілок (hidden = id, які НЕ показувати)."""
    data = request.get_json(silent=True) or {}
    hidden = data.get("hidden")
    if not isinstance(hidden, list):
        return _err("Невірний формат")
    valid = {b["id"] for b in BRANCHES if b["id"] != "hub"}
    clean = sorted({h for h in hidden if h in valid})
    db.set_setting("hidden_branches", json.dumps(clean, ensure_ascii=False))
    return _ok({"hidden": clean})


@app.route("/setup", methods=["GET", "POST"])
def page_setup():
    # Якщо адмін уже є — не дозволяємо створити «першого» повторно
    if db.count_users() > 0:
        return redirect(url_for("page_login"))
    error = None
    if request.method == "POST":
        try:
            uid = db.add_user(
                username=(request.form.get("username") or "").strip(),
                password=request.form.get("password") or "",
                role="admin",
                full_name=(request.form.get("full_name") or "").strip())
            session.permanent = True
            session["user_id"] = uid
            try:
                db.mark_user_online(uid)
            except Exception:  # noqa: BLE001
                pass
            return redirect(url_for("page_hub"))
        except ValueError as exc:
            error = str(exc)
    return render_template("setup.html", error=error)


# Захист логіну від перебору (лише серверний режим — в інтернеті це must):
# 5 невдалих спроб з пари IP+логін → блок на 10 хвилин.
_LOGIN_FAILS: dict = {}

def _login_blocked_secs(key: str) -> int:
    if not SERVER_MODE:
        return 0
    n, until = _LOGIN_FAILS.get(key, (0, 0))
    return max(0, int(until - time.time())) if n >= 5 else 0

def _login_fail(key: str) -> None:
    if not SERVER_MODE:
        return
    n, _ = _LOGIN_FAILS.get(key, (0, 0))
    _LOGIN_FAILS[key] = (n + 1, time.time() + 600)

@app.route("/login", methods=["GET", "POST"])
def page_login():
    if db.count_users() == 0:
        return redirect(url_for("page_setup"))
    if "user_id" in session:
        return redirect(url_for("page_hub"))
    error = None
    if request.method == "POST":
        _lkey = f"{request.remote_addr}|{(request.form.get('username') or '').strip().lower()}"
        _wait = _login_blocked_secs(_lkey)
        if _wait:
            error = f"Забагато спроб. Зачекайте {_wait // 60 + 1} хв."
            users = [u["username"] for u in db.list_users() if u.get("is_active")]
            return render_template("login.html", error=error, users=users)
        user = db.verify_password(
            (request.form.get("username") or "").strip(),
            request.form.get("password") or "")
        if user:
            _LOGIN_FAILS.pop(_lkey, None)
            session.permanent = True
            session["user_id"] = user["id"]
            try:
                db.mark_user_online(user["id"])
            except Exception:  # noqa: BLE001
                pass
            nxt = request.args.get("next") or url_for("page_hub")
            if not nxt.startswith("/") or nxt.startswith("//"):
                nxt = url_for("page_hub")
            return redirect(nxt)
        _login_fail(_lkey)
        error = "Неправильний логін або пароль."
    users = [u["username"] for u in db.list_users() if u.get("is_active")]
    return render_template("login.html", error=error, users=users)


@app.route("/logout")
def page_logout():
    uid = session.get("user_id")
    if uid:
        try:
            db.mark_user_offline(uid)
        except Exception:  # noqa: BLE001
            pass
    session.clear()
    return redirect(url_for("page_login"))


def _format_sale_no(raw: str, move_type: str = "") -> str:
    """Префіксує номер операції:
    - ВВ-N для внутрішньої видачі
    - ВС-N для списання
    - ПВ-N для повернень (move_type='RETURN')"""
    s = str(raw or "")
    if not s or s[:3] in ("ВВ-", "ВП-", "ПВ-", "ВС-"):
        return s
    if move_type == "RETURN":
        prefix = "ПВ-"
    elif move_type == "WRITE_OFF":
        prefix = "ВС-"
    else:
        prefix = "ВВ-"
    return prefix + s


@app.route("/receipt/<sale_no>")
def page_receipt(sale_no: str):
    """Друкований товарний чек / акт списання по операції."""
    sale = db.get_sale(sale_no)
    if not sale:
        abort(404)
    sale["sale_no_display"] = _format_sale_no(
        sale.get("sale_no"), sale.get("move_type"))
    return render_template("receipt.html", sale=sale, business=load_business())


@app.route("/sale/<sale_no>/invoice")
def page_issue_invoice(sale_no: str):
    """Друкована видаткова накладна-вимога / акт списання по операції."""
    sale = db.get_sale(sale_no)
    if not sale:
        abort(404)
    sale["sale_no_display"] = _format_sale_no(
        sale.get("sale_no"), sale.get("move_type"))
    titles = {"OUT": "Видаткова накладна-вимога", "WRITE_OFF": "Акт списання",
              "RETURN": "Накладна повернення"}
    doc_title = titles.get(sale.get("move_type"), "Видаткова накладна")
    issuer = ""
    uid = sale.get("user_id")
    if uid:
        u = db.get_user(uid)
        if u:
            issuer = u.get("full_name") or u.get("username") or ""
    return render_template("issue_invoice.html", sale=sale,
                           business=load_business(), doc_title=doc_title,
                           issuer=issuer)


@app.route("/receipt/<int:batch_id>/invoice")
def page_receipt_invoice(batch_id: int):
    """Друкована прибуткова накладна по надходженню (за партією)."""
    inv = db.get_receipt_invoice(batch_id)
    if not inv:
        abort(404)
    return render_template("receipt_invoice.html", inv=inv,
                           business=load_business())


# ===================================================================== API

def _err(message: str, status: int = 400):
    return jsonify({"ok": False, "error": message}), status


def _can_modify(owner_user_id) -> bool:
    """Перевірка прав на скасування/редагування операції:
    дозволено адміністратору або власнику операції.

    Окремий випадок: легасі-операції (створені до появи колонки user_id)
    не мають власника — для них дозволяємо змінювати будь-якому залогіненому,
    щоб старі записи можна було чистити/виправляти."""
    cur_id = session.get("user_id")
    user = db.get_user(cur_id) if cur_id else None
    if not user:
        return False
    if user.get("role") == "admin":
        return True
    # Легасі-операція без власника — будь-який авторизований може правити.
    if owner_user_id is None:
        return True
    # Звичайний користувач — лише власні операції
    return owner_user_id == cur_id


def _ok(payload=None):
    body = {"ok": True}
    if payload is not None:
        body.update(payload if isinstance(payload, dict) else {"data": payload})
    return jsonify(body)


@app.get("/api/dashboard")
def api_dashboard():
    cat = _inv_category()
    stats = db.dashboard_stats(category=cat)
    stats["recent_moves"] = db.recent_moves(limit=10, category=cat)
    return _ok(stats)


@app.get("/api/products")
def api_products():
    search = request.args.get("search", "")
    return _ok({"items": db.list_products(search, category=_inv_category())})


@app.get("/api/products/<barcode>")
def api_product_by_barcode(barcode: str):
    product = db.get_product_by_barcode(barcode)
    if not product:
        return _err("Товар не знайдено", 404)
    product["batches"] = db.product_batches(product["id"])
    return _ok({"product": product})


@app.get("/api/generate-barcode")
def api_generate_barcode():
    """Згенерувати унікальний внутрішній штрихкод EAN-13 для нового товару."""
    try:
        code = db.generate_internal_barcode()
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok({"barcode": code})


@app.get("/api/generate-code")
def api_generate_code():
    """Наступний номенклатурний номер — наскрізний, 6 знаків."""
    return _ok({"code": db.generate_product_code(_inv_category())})


@app.route("/production")
def page_production():
    """Виробництво комбікормів — лише гілка Годівля."""
    if _inv_category() != "feed":
        return redirect("/")
    return render_template("production.html", active="production")


@app.route("/feeding-analytics")
def page_feeding_analytics():
    """Стара «Аналітика годівлі» прибрана — переносимо на «Рух годівлі»."""
    return redirect("/f/feeding-log")


@app.route("/feeding-log")
def page_feeding_log():
    """Рух годівлі по секціях (день × секція: поголів'я, корм) — гілка Годівля."""
    if _inv_category() != "feed":
        return redirect("/")
    return render_template("feeding_log.html", active="feed_log")


@app.route("/feed-result")
def page_feed_result():
    """Стара сторінка «Результат годівлі» — тепер це «Огляд годівлі»."""
    return redirect("/f/pharmacy")


@app.route("/feed/settings")
def page_feed_settings():
    """Налаштування годівлі: тека звітів Profeed + архівація файлів у БД."""
    if _inv_category() != "feed":
        return redirect("/")
    return render_template("feed_settings.html", active="feed_settings")


@app.route("/feed-archive")
def page_feed_archive_redirect():
    return redirect("/f/feed/settings")


@app.get("/api/feed/transfer-export.csv")
def api_feed_transfer_export():
    """Експорт УСІХ даних гілки Годівля в один CSV (секції ##<таблиця>).
    Для перенесення в іншу базу через кнопку «Імпорт»."""
    import csv as _csv
    import io as _io
    data = db.feed_transfer_export()
    buf = _io.StringIO()
    w = _csv.writer(buf)
    for sect in db.FEED_XFER_SECTIONS:
        cols = db.FEED_XFER_COLS[sect]
        buf.write(f"##{sect}\n")
        w.writerow(cols)
        for row in data.get(sect, []):
            w.writerow(["" if row.get(c) is None else
                        str(row.get(c)).replace("\r", " ").replace("\n", " ")
                        for c in cols])
    fname = "feed_transfer_%s.csv" % _dt_now_stamp()
    resp = app.response_class(buf.getvalue(), mimetype="text/csv")
    resp.headers["Content-Disposition"] = f'attachment; filename="{fname}"'
    return resp


@app.post("/api/feed/transfer-import")
def api_feed_transfer_import():
    """Імпорт даних гілки Годівля з CSV: очистити наявні рухи/партії/виробництво
    годівлі й записати нові (товари/блоки/довідники upsert). Спершу — бекап БД."""
    import csv as _csv
    import io as _io
    f = request.files.get("file")
    if not f:
        return _err("Не вибрано файл")
    try:
        text = f.read().decode("utf-8-sig", "replace")
    except Exception:  # noqa: BLE001
        return _err("Не вдалося прочитати файл")

    # розбір секцій ##<таблиця> → payload
    payload: dict = {}
    cur_sect = None
    lines = text.splitlines(keepends=True)
    block: list = []

    def _flush(sect, blk):
        if not sect or not blk:
            return
        rows = list(_csv.reader(_io.StringIO("".join(blk))))
        if not rows:
            return
        header = rows[0]
        payload[sect] = [dict(zip(header, r)) for r in rows[1:] if any(x for x in r)]

    for ln in lines:
        if ln.startswith("##"):
            _flush(cur_sect, block)
            cur_sect = ln[2:].strip()
            block = []
        elif cur_sect:
            block.append(ln)
    _flush(cur_sect, block)

    if not any(payload.get(s) for s in db.FEED_XFER_SECTIONS):
        return _err("У файлі немає даних годівлі (перевірте формат)")

    # бекап БД перед заміною
    try:
        import sqlite3 as _sq
        bdir = db.backup_dir()
        bdir.mkdir(parents=True, exist_ok=True)
        bpath = bdir / f"before_feed_import_{_dt_now_stamp()}.db"
        dst = _sq.connect(str(bpath))
        with dst:
            _src = _sq.connect(str(db.db_path))
            _src.backup(dst)
            _src.close()
        dst.close()
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося зробити бекап: {exc}")

    try:
        stats = db.feed_transfer_import(payload)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка імпорту: {exc}")
    return _ok({"stats": stats, "backup": str(bpath)})


def _dt_now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


@app.get("/api/feed/combifeeds")
def api_feed_combifeeds():
    return _ok({"items": db.list_combifeeds()})


@app.get("/api/feed/recipes")
def api_feed_recipes():
    return _ok({"items": db.list_feed_recipes_full()})


@app.post("/api/feed/recipes")
def api_feed_recipe_save():
    """Створити/оновити рецепт. product_id — редагування, name — новий КК."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    try:
        return _ok(db.save_feed_recipe(
            product_id=d.get("product_id") or None,
            name=(d.get("name") or "").strip(),
            lines=d.get("lines") or [],
            note=(d.get("note") or "").strip()))
    except (ValueError, TypeError) as exc:
        return _err(str(exc))


@app.delete("/api/feed/recipes/<int:product_id>")
def api_feed_recipe_delete(product_id: int):
    if not _is_admin():
        return _err("Потрібні права адміністратора.", 403)
    db.delete_feed_recipe(product_id)
    return _ok()


@app.get("/api/feed/recipe/<int:product_id>")
def api_feed_recipe(product_id: int):
    return _ok(db.get_feed_recipe(product_id))


@app.get("/api/feed/productions")
def api_feed_productions():
    return _ok({"items": db.list_feed_productions(),
                "next_doc": db.next_production_doc_no()})


@app.get("/api/feed/production-consumption")
def api_feed_production_consumption():
    """Зведений розхід кормів на виробництво комбікормів за період."""
    return _ok(db.feed_production_consumption(
        request.args.get("from", ""), request.args.get("to", "")))


@app.get("/api/feed/productions/<int:prod_id>")
def api_feed_production_get(prod_id: int):
    doc = db.get_feed_production(prod_id)
    if not doc:
        return _err("Документ не знайдено.", 404)
    return _ok(doc)


@app.delete("/api/feed/productions/<int:prod_id>")
def api_feed_production_delete(prod_id: int):
    """Скасувати виробництво — компоненти повертаються на склад."""
    if not _is_admin():
        return _err("Потрібні права адміністратора.", 403)
    try:
        db.delete_feed_production(prod_id)
        return _ok()
    except ValueError as exc:
        return _err(str(exc))


@app.get("/api/feed/profeed/dir")
def api_feed_profeed_dir_get():
    """Тека звітів + що в ній РЕАЛЬНО лежить.

    Роман 2026-09-03: «оновлено, але файла немає». Застосунок звітів не
    видаляє, але теку, якої немає, він мовчки СТВОРЮЄ і пише туди — тож файл
    опинявся не там, де людина його шукала. Показуємо повний шлях, кількість
    файлів і найсвіжіший, щоб розбіжність було видно одразу."""
    d = db.get_setting("feed_profeed_dir", "")
    info = {"dir": d, "abs": "", "exists": False, "files": 0,
            "newest": "", "newest_at": ""}
    try:
        p = Path((d or "").strip()).expanduser()
        info["abs"] = str(p.resolve()) if str(p) else ""
        if p.is_dir():
            info["exists"] = True
            xs = sorted(list(p.glob("*.xlsx")) + list(p.glob("*.xls")),
                        key=lambda f: f.stat().st_mtime, reverse=True)
            info["files"] = len(xs)
            if xs:
                info["newest"] = xs[0].name
                info["newest_at"] = datetime.fromtimestamp(
                    xs[0].stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    except OSError:
        pass
    return _ok(info)


@app.post("/api/feed/profeed/dir")
def api_feed_profeed_dir_set():
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = (request.get_json(silent=True) or {}).get("dir", "").strip()
    db.set_setting("feed_profeed_dir", d)
    return _ok({"dir": d})


@app.post("/api/feed/profeed/pick-dir")
def api_feed_profeed_pick_dir():
    """Вибрати теку звітів Profeed системним діалогом (сервер = цей ПК)."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    path, err = _native_pick_folder("Виберіть теку зі звітами Profeed")
    if err:
        return _err(err)
    if path:
        db.set_setting("feed_profeed_dir", path)
    return _ok({"dir": path})


@app.get("/api/feed/profeed/scan")
def api_feed_profeed_scan():
    """Знайти у звітах Profeed ще не проведені заміси комбікормів."""
    folder = (request.args.get("dir") or db.get_setting("feed_profeed_dir", "")).strip()
    if not folder:
        return _err("Не вказано теку звітів Profeed.")
    try:
        res = db.scan_profeed_productions(folder)
        if res.get("error"):
            return _err(res["error"])
        return _ok(res)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка читання: {exc}")


@app.get("/api/feed/profeed/scan-feeding")
def api_feed_profeed_scan_feeding():
    """Знайти у звітах Profeed роздачі кормів (годівлю), ще не списані."""
    folder = (request.args.get("dir") or db.get_setting("feed_profeed_dir", "")).strip()
    if not folder:
        return _err("Не вказано теку звітів Profeed.")
    try:
        res = db.scan_profeed_feedings(folder)
        if res.get("error"):
            return _err(res["error"])
        return _ok(res)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка читання: {exc}")


@app.post("/api/feed/profeed/import-feeding")
def api_feed_profeed_import_feeding():
    """Списати обрані роздачі (годівлю) пакетно."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    folder = (d.get("dir") or db.get_setting("feed_profeed_dir", "")).strip()
    keys = d.get("src_keys") or []
    if not folder:
        return _err("Не вказано теку звітів Profeed.")
    if not keys:
        return _err("Не обрано жодної роздачі.")
    try:
        res = db.import_profeed_feedings(folder, keys, user_id=session.get("user_id"))
        if res.get("error"):
            return _err(res["error"])
        return _ok(res)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка списання: {exc}")


def _milk_total_kg(date_from: str, date_to: str) -> Optional[float]:
    """Сумарний надій (кг) за період із файла Excel гілки Молоко.
    Best-effort: якщо молоко не налаштоване або помилка — повертає None."""
    try:
        cfg = _milk_config()
        raw, ds, err = _milk_rows(cfg, "yields")
        if err or not raw:
            return None
        metrics = ds.get("metrics") or []
        kgm = next((m for m in metrics if m.get("agg", "sum") == "sum"), None)
        if not kgm:
            return None
        spec = kgm.get("cols") or kgm.get("col")
        total = 0.0
        for r in raw:
            d = r.get("date")
            if not d:
                continue
            ds_ = d.strftime("%Y-%m-%d")
            if date_from and ds_ < date_from:
                continue
            if date_to and ds_ > date_to:
                continue
            total += milk_excel._rowsum(r, spec)
        return round(total, 1) if total > 0 else None
    except Exception:  # noqa: BLE001
        return None


def _milk_sales_day(day: str) -> Optional[dict]:
    """Продаж молока за день — З БАЗИ (milk_sales_daily). Excel лише як джерело
    імпорту (_milk_ingest). Якщо дня ще нема в БД — доімпортуємо і пробуємо ще."""
    day = (day or "").strip()[:10]
    if not day:
        return None
    try:
        r = db.milk_sales_day(day)
        if r is None:
            _milk_ingest(day, day)
            r = db.milk_sales_day(day)
        return r
    except Exception:  # noqa: BLE001
        return None


def _milk_ingest(date_from: str = "", date_to: str = "") -> dict:
    """ЄДИНИЙ імпорт молока Excel→БД: читає надій+продаж із Excel і фіксує
    по днях у milk_daily / milk_sales_daily. Далі сторінки, звіти й сервер
    читають ЛИШЕ з БД. Best-effort; повертає {yields, sales} — к-сть днів."""
    res = {"yields": 0, "sales": 0}
    cfg = _milk_config()

    # ── Надій (yields) → milk_daily(day, kg, l) ──────────────────────────────
    try:
        raw, ds, err = _milk_rows(cfg, "yields")
        if not err and raw:
            metrics = ds.get("metrics") or []
            # Надій для звітів (Огляд, ₴/кг) = НАДІЙ ЗА ЗАЛІКОМ. Пріоритет:
            # 1) метрика з «залік» у назві; 2) feed_milk_col; 3) сира кг; 4) 1-а сума.
            spec = None
            zm = next((m for m in metrics
                       if "залік" in (m.get("label") or "").lower()), None)
            if zm:
                spec = zm.get("cols") or zm.get("col")
            if not spec:
                col = (db.get_setting("feed_milk_col", "") or "").strip()
                if col:
                    spec = col
            if not spec:
                km = next((m for m in metrics if "milk_total_kg" in
                           (m.get("cols") or [m.get("col")] or [])), None)
                if km:
                    spec = km.get("cols") or km.get("col")
            if not spec:
                kgm = next((m for m in metrics if m.get("agg", "sum") == "sum"), None)
                spec = (kgm.get("cols") or kgm.get("col")) if kgm else "milk_total_kg"
            # усі колонки, що їх використовують метрики надою (щоб зберегти залік
            # та будь-які інші колонки сторінки Надоїв, а не лише kg/l)
            all_cols = milk_excel.cols_used(metrics)
            agg: dict = {}
            for r in raw:
                d = r.get("date")
                if not d:
                    continue
                ds_ = d.strftime("%Y-%m-%d")
                if date_from and ds_ < date_from:
                    continue
                if date_to and ds_ > date_to:
                    continue
                a = agg.setdefault(ds_, {"kg": 0.0, "l": 0.0, "cols": {}})
                a["kg"] += milk_excel._rowsum(r, spec)
                a["l"] += milk_excel._num(r.get("milk_total_l"))
                for c in all_cols:
                    a["cols"][c] = a["cols"].get(c, 0.0) + milk_excel._num(r.get(c))
            if agg:
                res["yields"] = db.set_milk_daily(agg)
    except Exception:  # noqa: BLE001
        pass

    # ── Продаж (sales) → milk_sales_daily(day, kg, l, kg_fat, kg_prot, суми) ──
    try:
        raw, ds, err = _milk_rows(cfg, "sales")
        if not err and raw:
            kg_col = ds.get("kg_col") or "sale_milk_kg"
            # усі колонки метрик продажу (залік, ціна тощо) — щоб сторінка Продажу
            # показувала будь-яку метрику, а не лише фіксовані
            all_cols = milk_excel.cols_used(ds.get("metrics") or [])
            agg2: dict = {}
            for r in raw:
                d = r.get("date")
                if not d:
                    continue
                ds_ = d.strftime("%Y-%m-%d")
                if date_from and ds_ < date_from:
                    continue
                if date_to and ds_ > date_to:
                    continue
                a = agg2.setdefault(ds_, {"kg": 0.0, "l": 0.0, "kg_fat": 0.0,
                                          "kg_prot": 0.0, "sum_nv": 0.0,
                                          "sum_v": 0.0, "vat": 0.0, "cols": {}})
                a["kg"] += milk_excel._num(r.get(kg_col))
                a["l"] += milk_excel._num(r.get("sale_milk_l"))
                a["kg_fat"] += milk_excel._num(r.get("kgFat"))
                a["kg_prot"] += milk_excel._num(r.get("kgProtein"))
                a["sum_nv"] += float(r.get("_amount_nv") or 0)
                a["sum_v"] += float(r.get("_amount_v") or 0)
                a["vat"] += float(r.get("_vat") or 0)
                for c in all_cols:
                    a["cols"][c] = a["cols"].get(c, 0.0) + milk_excel._num(r.get(c))
            rows = []
            for ds_, a in agg2.items():
                kg = a["kg"]
                rows.append({"day": ds_, "kg": round(kg, 1), "l": round(a["l"], 1),
                             "kg_fat": round(a["kg_fat"], 3),
                             "kg_prot": round(a["kg_prot"], 3),
                             "sum_nv": round(a["sum_nv"], 2),
                             "price_nv": round(a["sum_nv"] / kg, 4) if kg else 0,
                             "sum_v": round(a["sum_v"], 2),
                             "price_v": round(a["sum_v"] / kg, 4) if kg else 0,
                             "vat": round(a["vat"], 2), "cols": a["cols"]})
            if rows:
                res["sales"] = db.set_milk_sales_daily(rows)
    except Exception:  # noqa: BLE001
        pass
    return res


def _milk_daily(date_from: str, date_to: str) -> dict:
    """Денний надій {дата: кг} — З БАЗИ (milk_daily). Перед читанням освіжає
    БД з Excel (_milk_ingest), тож дані завжди актуальні, а джерело — БД."""
    try:
        _milk_ingest(date_from, date_to)
    except Exception:  # noqa: BLE001
        pass
    try:
        # надій для звітів = milk_daily.kg (вибрана колонка = залік), НЕ сира кг
        return db.milk_kg_map(date_from, date_to)
    except Exception:  # noqa: BLE001
        return {}


def _milk_daily_warmup() -> None:
    """Разово прогріти БД молока за всю історію (надій+продаж) — для звітів,
    сторінок і синхронізації на сервер."""
    import threading
    import time as _t

    def run():
        _t.sleep(25)                       # дати застосунку піднятися
        try:
            _milk_ingest("", "")           # надій+продаж → БД
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=run, daemon=True, name="milk-daily-warmup").start()


_milk_daily_warmup()


def _herd_daily_cache() -> int:
    """Прочитати поголів'я по днях×групах з Excel «Управління стада» за всю
    історію і закешувати в БД (herd_daily) — щоб синхронізувалось на сервер.
    Best-effort; повертає к-сть збережених рядків."""
    try:
        cfg = _herd_config()
        cols_cfg = [c for c in (cfg.get("cols") or []) if c.get("col")]
        colnames = [c["col"] for c in cols_cfg]
        labels = {c["col"]: (c.get("label") or c["col"]) for c in cols_cfg}
        path = (cfg.get("file_path") or "").strip()
        if not path or not Path(path).expanduser().exists() or not colnames:
            return 0
        raw = milk_excel.read_rows(path, cfg.get("sheet"),
                                   int(cfg.get("header_row", 1)),
                                   cfg.get("date_col"), colnames)
        rows = []
        for r in raw:
            d = r.get("date")
            if not hasattr(d, "isoformat"):
                continue
            day = d.isoformat()
            for cn in colnames:
                v = milk_excel._num(r.get(cn))
                if not v:                      # порожні/0 групи не фіксуємо
                    continue
                rows.append({"day": day, "grp": cn,
                             "label": labels.get(cn, cn), "heads": v})
        return db.set_herd_daily(rows)
    except Exception:  # noqa: BLE001
        return 0


def _herd_daily_warmup() -> None:
    """Разово зафіксувати поголів'я по днях у БД (для синхронізації на сервер)."""
    import threading
    import time as _t

    def run():
        _t.sleep(28)                       # після прогріву молока
        try:
            _herd_daily_cache()
        except Exception:  # noqa: BLE001
            pass
    threading.Thread(target=run, daemon=True, name="herd-daily-warmup").start()


_herd_daily_warmup()


@app.get("/api/feed/feeding-log")
def api_feed_feeding_log():
    """Рух годівлі по секціях за днями (з журналу роздач Profeed)."""
    return _ok(db.list_feeding_log(
        category=_inv_category(),
        date_from=(request.args.get("from") or "").strip(),
        date_to=(request.args.get("to") or "").strip()))


@app.get("/api/feed/feeding-tree")
def api_feed_feeding_tree():
    """Ієрархія руху годівлі: Секція → Дата → метрики + завантажені корми."""
    return _ok(db.feeding_tree(
        category=_inv_category(),
        date_from=(request.args.get("from") or "").strip(),
        date_to=(request.args.get("to") or "").strip()))


@app.get("/api/feed/last-day")
def api_feed_last_day():
    """Остання дата з рухом годівлі (для дефолту режиму «День»)."""
    return _ok({"day": db.feeding_last_day()})


@app.get("/api/feed/production")
def api_feed_production():
    """Виробництво комбікорму за період: розхід кормів-компонентів + вироблений КК.
    Для блоку «Виробництво комбікорму» на сторінці «Рух годівлі»."""
    return _ok(db.feed_production_range(
        date_from=(request.args.get("from") or "").strip(),
        date_to=(request.args.get("to") or "").strip()))


@app.get("/api/feed/stock-on-date")
def api_feed_stock_on_date():
    """Обліковий залишок корму на дату (для балансування)."""
    try:
        pid = int(request.args.get("product_id") or 0)
    except ValueError:
        pid = 0
    day = (request.args.get("day") or "").strip()
    if not pid or not day:
        return _err("Вкажіть корм і дату")
    return _ok({"qty": db.feed_stock_on_date(pid, day)})


@app.get("/api/feed/balance-last")
def api_feed_balance_last():
    """Останній запис балансування (для показу/скасування)."""
    try:
        pid = int(request.args.get("product_id") or 0) or None
    except (TypeError, ValueError):
        pid = None
    try:
        return _ok({"last": db.feed_balance_last(pid)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.get("/api/feed/balance-log")
def api_feed_balance_log():
    """Журнал балансувань (останні записи) — для списку зі скасуванням."""
    try:
        pid = int(request.args.get("product_id") or 0) or None
    except (TypeError, ValueError):
        pid = None
    try:
        lim = int(request.args.get("limit") or 15)     # журнали — 15 записів
    except (TypeError, ValueError):
        lim = 15
    try:
        return _ok({"items": db.feed_balance_history(pid, lim)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/feed/balance-undo")
def api_feed_balance_undo():
    """Скасувати останнє балансування (або конкретне за id)."""
    data = request.get_json(silent=True) or {}
    try:
        lid = int(data.get("id") or 0) or None
    except (TypeError, ValueError):
        lid = None
    try:
        pid = int(data.get("product_id") or 0) or None
    except (TypeError, ValueError):
        pid = None
    try:
        mid = int(data.get("move_id") or 0) or None
    except (TypeError, ValueError):
        mid = None
    try:
        if mid and not lid:
            return _ok(db.feed_balance_undo_move(mid))
        return _ok(db.feed_balance_undo(lid, pid))
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.get("/api/feed/groups")
def api_feed_groups():
    """Категорії/підкатегорії груп годівлі (для вибору, куди віднести різницю).
    Повертає унікальні пари Категорія · Підкатегорія з представницьким блоком."""
    KIND = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}
    seen: dict = {}
    for b in db.list_blocks(category="feed"):
        cat = KIND.get(b.get("herd_kind") or "", "") or "Без категорії"
        sub = (b.get("subgroup") or "").strip()
        key = cat + "|" + sub
        if key in seen:
            continue
        seen[key] = {"block_id": b["id"], "category": cat, "subgroup": sub,
                     "label": cat + (" · " + sub if sub else "")}
    items = sorted(seen.values(), key=lambda x: x["label"])
    return _ok({"items": items})


_FEED_ISSUE_DEFAULTS = {
    "cols": [], "days": 7, "month_days": 30, "group": "sub",
    "show_kg": True, "show_sum": False, "show_period": True,
    "show_month": True, "show_total_row": True,
    "block_id": 0,          # група (категорія·підкатегорія), у яку вносимо видачу
}


def _feed_issue_settings() -> dict:
    """Конфіг таблиці видачі кормів (єдиний JSON у app_settings). Читає й старі
    окремі ключі (feed_issue_cols/days/price) — сумісність із першою версією."""
    cfg = dict(_FEED_ISSUE_DEFAULTS)
    try:
        saved = json.loads(db.get_setting("feed_issue_cfg", "") or "{}")
        if isinstance(saved, dict):
            cfg.update(saved)
    except Exception:  # noqa: BLE001
        pass
    if not cfg.get("cols"):          # легасі-ключі
        try:
            cfg["cols"] = json.loads(db.get_setting("feed_issue_cols", "") or "[]")
        except Exception:  # noqa: BLE001
            cfg["cols"] = []
        if db.get_setting("feed_issue_price", "") == "1":
            cfg["show_sum"] = True
        try:
            cfg["days"] = int(db.get_setting("feed_issue_days", "") or cfg["days"])
        except (TypeError, ValueError):
            pass
    cfg["cols"] = [int(x) for x in (cfg.get("cols") or []) if str(x).strip().isdigit()]
    try:
        cfg["days"] = max(1, min(365, int(cfg.get("days") or 7)))
    except (TypeError, ValueError):
        cfg["days"] = 7
    try:
        cfg["month_days"] = max(1, min(366, int(cfg.get("month_days") or 30)))
    except (TypeError, ValueError):
        cfg["month_days"] = 30
    cfg["group"] = "cat" if str(cfg.get("group")) == "cat" else "sub"
    try:
        cfg["block_id"] = int(cfg.get("block_id") or 0)
    except (TypeError, ValueError):
        cfg["block_id"] = 0
    for k in ("show_kg", "show_sum", "show_period", "show_month", "show_total_row"):
        cfg[k] = bool(cfg.get(k))
    if not (cfg["show_kg"] or cfg["show_sum"]):   # хоч щось має показуватись
        cfg["show_kg"] = True
    return cfg


@app.get("/api/feed/issue-matrix")
def api_feed_issue_matrix():
    """Таблична видача кормів: рядки — категорія/підкатегорія, стовпці — обрані
    корми; клітинка — кг і сума за N днів + колонка «За місяць». Плюс поточні
    налаштування і список доступних кормів для вибору стовпців."""
    st = _feed_issue_settings()
    days = request.args.get("days", "")
    if str(days).strip().isdigit():
        st["days"] = max(1, min(365, int(days)))
    data = db.feed_issue_matrix(st["days"], st["cols"],
                                st["month_days"], st["group"])
    available = [{"id": p["id"], "name": p["name"], "unit": p.get("unit") or "кг",
                  "code": p.get("code", "")}
                 for p in db.list_products(category="feed")]
    return _ok({"data": data, "settings": st, "available": available})


@app.post("/api/feed/issue-settings")
def api_feed_issue_settings_save():
    """Зберегти конфіг таблиці видачі кормів (стовпці, період, що показувати,
    групування). Приймає часткові зміни — решта лишається як була."""
    d = request.get_json(silent=True) or {}
    cfg = _feed_issue_settings()
    if "cols" in d:
        cfg["cols"] = [int(x) for x in (d.get("cols") or []) if str(x).strip().isdigit()]
    for k, lo, hi in (("days", 1, 365), ("month_days", 1, 366)):
        if k in d:
            try:
                cfg[k] = max(lo, min(hi, int(d[k])))
            except (TypeError, ValueError):
                pass
    if "group" in d:
        cfg["group"] = "cat" if str(d.get("group")) == "cat" else "sub"
    if "block_id" in d:
        try:
            cfg["block_id"] = int(d.get("block_id") or 0)
        except (TypeError, ValueError):
            cfg["block_id"] = 0
    for k in ("show_kg", "show_sum", "show_period", "show_month", "show_total_row"):
        if k in d:
            cfg[k] = bool(d.get(k))
    if not (cfg["show_kg"] or cfg["show_sum"]):
        cfg["show_kg"] = True
    db.set_setting("feed_issue_cfg", json.dumps(cfg, ensure_ascii=False))
    return _ok(cfg)


def _feed_groups_list() -> list:
    """Список груп годівлі: КОЖЕН блок = підкатегорія в межах категорії
    (Молодняк · Телят_0-3). Саме так вони заведені в Довідниках."""
    KIND = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}
    out = []
    for b in db.list_blocks(category="feed"):
        kind = b.get("herd_kind") or ""
        cat = KIND.get(kind, "") or "Без категорії"
        sub = (b.get("name") or "").strip()
        out.append({"block_id": int(b["id"]), "kind": kind, "category": cat,
                    "subgroup": sub,
                    "label": cat + (" · " + sub if sub else "")})
    return sorted(out, key=lambda x: x["label"].lower())


def _feed_tables() -> dict:
    """Таблиці видачі кормів: список + активна. Кожна таблиця:
    {id, name, block_id, days, cols:[product_id], show_total_row}."""
    try:
        raw = json.loads(db.get_setting("feed_issue_tables", "") or "[]")
    except Exception:  # noqa: BLE001
        raw = []
    tables = []
    for t in (raw if isinstance(raw, list) else []):
        if not isinstance(t, dict):
            continue
        try:
            tid = int(t.get("id") or 0)
        except (TypeError, ValueError):
            continue
        if not tid:
            continue
        tables.append({
            "id": tid,
            "name": (str(t.get("name") or "").strip() or "Таблиця"),
            "block_id": int(t.get("block_id") or 0),
            "kind": str(t.get("kind") or ""),
            "subgroup": str(t.get("subgroup") or "").strip(),
            "days": max(1, min(120, int(t.get("days") or 7))),
            "cols": [int(x) for x in (t.get("cols") or []) if str(x).strip().isdigit()],
            "bedding": [int(x) for x in (t.get("bedding") or []) if str(x).strip().isdigit()],
            "show_total_row": bool(t.get("show_total_row", True)),
            # автосписання: щоранку копіюємо попередній день і проводимо
            "auto_on": bool(t.get("auto_on", False)),
            "auto_time": (str(t.get("auto_time") or "07:00").strip() or "07:00")[:5],
            "auto_last": str(t.get("auto_last") or "")[:10],
        })
    try:
        active = int(db.get_setting("feed_issue_active", "0") or 0)
    except (TypeError, ValueError):
        active = 0
    ids = [t["id"] for t in tables]
    if active not in ids:
        active = ids[0] if ids else 0
    return {"tables": tables, "active": active}


def _feed_auto_run_table(t: dict, day: str) -> dict:
    """Автозаповнення однієї таблиці за день `day`: беремо ПОПЕРЕДНІЙ день із
    даними і проводимо ті самі кількості. Якщо за `day` уже щось проведено цією
    таблицею — не чіпаємо (людина внесла своє)."""
    block_id = int(t.get("block_id") or 0)
    cols = [int(x) for x in (t.get("cols") or [])]
    if not (block_id and cols):
        return {"ok": False, "why": "немає групи або кормів"}
    grid = db.feed_issue_grid(block_id, max(3, int(t.get("days") or 7)), cols)
    rows = {r["date"]: r for r in (grid.get("rows") or [])}
    mine = (rows.get(day) or {}).get("mine") or {}
    if any(float(v or 0) for v in mine.values()):
        return {"ok": False, "why": "за цей день уже проведено"}
    # найсвіжіший попередній день, де таблиця щось видавала
    prev = None
    for d in sorted([x for x in rows if x < day], reverse=True):
        vals = rows[d].get("mine") or {}
        if any(float(v or 0) for v in vals.values()):
            prev = (d, vals)
            break
    if not prev:
        return {"ok": False, "why": "немає попереднього дня з даними"}
    bedding = {int(x) for x in (t.get("bedding") or [])}
    # проведення чекає ШТРИХКОД товару, а сітка віддає id — зіставляємо
    bc = {int(f["id"]): str(f.get("barcode") or "") for f in (grid.get("feeds") or [])}
    items = [{"barcode": bc.get(int(pid), ""), "qty": float(q),
              "not_feed": 1 if int(pid) in bedding else 0}
             for pid, q in prev[1].items() if float(q or 0) > 0 and bc.get(int(pid))]
    if not items:
        return {"ok": False, "why": "порожній попередній день"}
    res = db.feed_issue_post_day(day, block_id, items, user_id=None)
    return {"ok": True, "from": prev[0], "items": len(items), "res": res}


def _feed_auto_tick() -> None:
    """Раз на хвилину: чи не час комусь із таблиць спрацювати сьогодні."""
    cfg = _feed_tables()
    tables = cfg.get("tables") or []
    if not any(t.get("auto_on") for t in tables):
        return
    now = datetime.now()
    day, hhmm = now.strftime("%Y-%m-%d"), now.strftime("%H:%M")
    changed = False
    for t in tables:
        if not t.get("auto_on") or t.get("auto_last") == day:
            continue
        if hhmm < (t.get("auto_time") or "07:00"):
            continue
        try:
            r = _feed_auto_run_table(t, day)
            note = ("списано з " + r["from"]) if r.get("ok") else str(r.get("why") or "")
        except Exception as exc:  # noqa: BLE001
            note = "помилка: " + str(exc)[:120]
        t["auto_last"] = day                       # друга спроба сьогодні не потрібна
        t["auto_note"] = "%s %s" % (hhmm, note)
        changed = True
    if changed:
        db.set_setting("feed_issue_tables", json.dumps(tables, ensure_ascii=False))


def _start_feed_auto() -> None:
    import threading

    def loop():
        while True:
            try:
                _feed_auto_tick()
            except Exception:  # noqa: BLE001
                pass
            time.sleep(60)

    threading.Thread(target=loop, daemon=True).start()


@app.post("/api/feed/issue-auto-now")
def api_feed_issue_auto_now():
    """Прогнати автосписання просто зараз (кнопка «Списати як учора»)."""
    d = request.get_json(silent=True) or {}
    t = _feed_table_by_id(d.get("table"))
    if not t:
        return _err("Таблицю не знайдено.")
    day = (d.get("day") or datetime.now().strftime("%Y-%m-%d"))[:10]
    try:
        return _ok(_feed_auto_run_table(t, day))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


_FEED_KIND_LABEL = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}


def _feed_resolve_block(kind: str, subgroup: str) -> int:
    """Знайти (або СТВОРИТИ) блок годівлі для пари категорія+підкатегорія.
    ПІДКАТЕГОРІЯ = блок у межах категорії (напр. Молодняк → «Телят_0-3»), саме
    так вони заведені в Довідниках. Порожня підкатегорія = блок з назвою категорії."""
    kind = kind if kind in ("cow", "young", "pig") else ""
    sub = (subgroup or "").strip()
    if not kind:
        return 0
    name = sub or _FEED_KIND_LABEL.get(kind, "Група")
    for b in db.list_blocks(category="feed"):
        if (b.get("herd_kind") or "") == kind \
                and (b.get("name") or "").strip().lower() == name.lower():
            return int(b["id"])
    return int(db.add_block(name, category="feed", herd_kind=kind))


@app.get("/api/feed/subgroups")
def api_feed_subgroups():
    """Підкатегорії (блоки годівлі) за категоріями — для вибору в таблиці видачі."""
    out: dict = {"cow": [], "young": [], "pig": [], "": []}
    for b in db.list_blocks(category="feed"):
        k = b.get("herd_kind") or ""
        nm = (b.get("name") or "").strip()
        if not nm:
            continue
        out.setdefault(k, [])
        out[k].append({"id": int(b["id"]), "name": nm})
    for k in out:
        out[k].sort(key=lambda x: x["name"].lower())
    return _ok({"subgroups": out, "labels": _FEED_KIND_LABEL})


def _feed_tables_save(tables: list, active: int) -> None:
    db.set_setting("feed_issue_tables", json.dumps(tables, ensure_ascii=False))
    db.set_setting("feed_issue_active", str(int(active or 0)))


@app.get("/api/feed/issue-tables")
def api_feed_issue_tables():
    """Список таблиць видачі + довідники для конфігуратора."""
    st = _feed_tables()
    available = [{"id": p["id"], "name": p["name"], "unit": p.get("unit") or "кг",
                  "barcode": p.get("barcode", "")}
                 for p in db.list_products(category="feed")]
    return _ok({"tables": st["tables"], "active": st["active"],
                "groups": _feed_groups_list(), "available": available})


@app.post("/api/feed/issue-tables")
def api_feed_issue_tables_save():
    """Створити / оновити / видалити таблицю або зробити її активною.
    {action: 'save'|'delete'|'activate', table:{…} | id}"""
    d = request.get_json(silent=True) or {}
    st = _feed_tables()
    tables, active = st["tables"], st["active"]
    act = str(d.get("action") or "save")
    if act == "activate":
        active = int(d.get("id") or 0)
    elif act == "reorder":
        order = [int(x) for x in (d.get("order") or []) if str(x).strip().isdigit()]
        pos = {tid: i for i, tid in enumerate(order)}
        tables.sort(key=lambda t: pos.get(t["id"], 10**6))
    elif act == "delete":
        tid = int(d.get("id") or 0)
        tables = [t for t in tables if t["id"] != tid]
        if active == tid:
            active = tables[0]["id"] if tables else 0
    else:                                    # save (створення або зміна)
        t = d.get("table") or {}
        tid = int(t.get("id") or 0)
        # категорія+підкатегорія → блок (створюємо, якщо такої пари ще немає)
        block_id = int(t.get("block_id") or 0)
        if t.get("kind"):
            try:
                block_id = _feed_resolve_block(str(t.get("kind")), str(t.get("subgroup") or ""))
            except Exception as exc:  # noqa: BLE001
                return _err(f"Не вдалося створити групу: {exc}")
        _nm = str(t.get("name") or "").strip()
        if not _nm:                       # дефолт: «Категорія · підкатегорія»
            _lbl = _FEED_KIND_LABEL.get(str(t.get("kind") or ""), "")
            _sub = str(t.get("subgroup") or "").strip()
            _nm = ((_lbl + (" · " + _sub if _sub else "")).strip() or "Таблиця")
        row = {
            "id": tid or (max([x["id"] for x in tables], default=0) + 1),
            "name": _nm,
            "block_id": block_id,
            "kind": str(t.get("kind") or ""),
            "subgroup": str(t.get("subgroup") or "").strip(),
            "days": max(1, min(120, int(t.get("days") or 7))),
            "cols": [int(x) for x in (t.get("cols") or []) if str(x).strip().isdigit()],
            "bedding": [int(x) for x in (t.get("bedding") or []) if str(x).strip().isdigit()],
            "show_total_row": bool(t.get("show_total_row", True)),
            "auto_on": bool(t.get("auto_on", False)),
            "auto_time": (str(t.get("auto_time") or "07:00").strip() or "07:00")[:5],
        }
        # зберігаємо службові позначки автосписання попередньої версії рядка
        for _old in tables:
            if _old["id"] == row["id"]:
                row["auto_last"] = _old.get("auto_last", "")
                row["auto_note"] = _old.get("auto_note", "")
                break
        found = False
        for i, x in enumerate(tables):
            if x["id"] == row["id"]:
                tables[i] = row; found = True; break
        if not found:
            tables.append(row)
        active = row["id"]
    _feed_tables_save(tables, active)
    return _ok(_feed_tables())


def _feed_table_by_id(tid) -> dict:
    st = _feed_tables()
    tid = int(tid or st["active"] or 0)
    for t in st["tables"]:
        if t["id"] == tid:
            return t
    return {}


@app.post("/api/feed/issue-clear")
def api_feed_issue_clear():
    """Прибрати ручну видачу кормів по групі за період (повертає корм на склад):
    щоб внести дані заново. {table, from, to, all:true|false}"""
    d = request.get_json(silent=True) or {}
    t = _feed_table_by_id(d.get("table"))
    block_id = int(d.get("block_id") or t.get("block_id") or 0)
    if not block_id:
        return _err("Оберіть групу в налаштуваннях таблиці.")
    try:
        res = db.feed_issue_clear(block_id, d.get("from", ""), d.get("to", ""),
                                  only_table=not bool(d.get("all")))
        return _ok(res)
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка очищення: {exc}")


@app.get("/api/feed/issue-grid")
def api_feed_issue_grid():
    """Сітка вводу видачі: рядки — дні, стовпці — обрані корми, для обраної
    групи. Показує вже проведене цією таблицею (щоб можна було правити)."""
    st = _feed_tables()
    t = _feed_table_by_id(request.args.get("table"))
    if not t:
        return _ok({"grid": {"feeds": [], "rows": []}, "table": {},
                    "tables": st["tables"], "active": st["active"],
                    "available": [], "groups": _feed_groups_list()})
    grid = db.feed_issue_grid(t["block_id"], t["days"], t["cols"])
    available = [{"id": p["id"], "name": p["name"], "unit": p.get("unit") or "кг",
                  "barcode": p.get("barcode", "")}
                 for p in db.list_products(category="feed")]
    return _ok({"grid": grid, "table": t, "tables": st["tables"],
                "active": t["id"], "available": available,
                "groups": _feed_groups_list()})


@app.post("/api/feed/issue-post")
def api_feed_issue_post():
    """Провести видачу за ОДИН день (окрема ВВ). Повторне проведення того самого
    дня скасовує попередній документ таблиці й створює новий — без задвоєння."""
    d = request.get_json(silent=True) or {}
    t = _feed_table_by_id(d.get("table"))
    block_id = int(d.get("block_id") or t.get("block_id") or 0)
    if not block_id:
        return _err("Спершу оберіть групу в налаштуваннях таблиці.")
    try:
        res = db.feed_issue_post_day(d.get("day", ""), block_id,
                                     d.get("items") or [],
                                     user_id=session.get("user_id"))
        return _ok(res)
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка проведення: {exc}")


@app.post("/api/feed/balance")
def api_feed_balance():
    """Балансування залишку корму на дату: 'opening' — початковий залишок,
    'inventory' — фактичний залишок (проводиться лише різниця)."""
    data = request.get_json(silent=True) or {}
    try:
        pid = int(data.get("product_id") or 0)
    except (TypeError, ValueError):
        pid = 0
    day = (data.get("day") or "").strip()
    mode = (data.get("mode") or "opening").strip()
    if not pid or not day:
        return _err("Вкажіть корм і дату")
    if mode not in ("opening", "inventory"):
        return _err("Невідомий спосіб балансування")
    dest = (data.get("dest") or "stock").strip()
    if dest not in ("stock", "loss", "block"):
        return _err("Невідоме призначення різниці")
    try:
        bid = int(data.get("block_id") or 0) or None
    except (TypeError, ValueError):
        bid = None
    try:
        res = db.feed_balance(pid, day, mode, data.get("qty"),
                              (data.get("note") or "").strip(),
                              session.get("user_id"), dest, bid)
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")
    return _ok(res)


@app.get("/api/feed/production-by-ingredient")
def api_feed_production_by_ingredient():
    """Розхід кормів на виробництво КК: Корм → Дата (для секції в «По кормах»)."""
    return _ok(db.feed_production_by_ingredient(
        date_from=(request.args.get("from") or "").strip(),
        date_to=(request.args.get("to") or "").strip()))


@app.get("/api/feed/usage-by-category")
def api_feed_usage_by_category():
    """Використання кормів по категоріях/підкатегоріях стада за період.
    Молоко — денний надій із модуля «Виробництво молока»."""
    date_from = (request.args.get("from") or "").strip()
    date_to = (request.args.get("to") or "").strip()
    return _ok(db.feed_usage_by_category(
        category=_inv_category(), date_from=date_from, date_to=date_to,
        milk_by_day=_milk_daily(date_from, date_to)))


@app.get("/api/feed/result")
def api_feed_result():
    """Зведення «Результат годівлі»: залишок складу кормів (кг/₴), спожито за
    період, залишки ЗМР і перенесення, утилізація, конверсія — одним запитом."""
    f = (request.args.get("from") or "").strip()
    t = (request.args.get("to") or "").strip()
    uc = db.feed_usage_by_category(category="feed", date_from=f, date_to=t,
                                   milk_by_day=_milk_daily(f, t))
    tree = db.feeding_tree("feed", f, t)
    # кг залишків і перенесень — із пулу дерева (₴ уже в uc канонічні)
    leftover_kg = sum((tree.get("pool_kg") or {}).values())
    refed_kg = 0.0
    for lst in (tree.get("pool_dest") or {}).values():
        for x in lst or []:
            if (x.get("dest") or "") != "Утилізація":
                refed_kg += x.get("qty") or 0
    # склад кормів зараз: кг + ₴ без ПДВ (усі ₴ годівлі — без ПДВ)
    prods = db.list_products(category="feed")
    uc.update({
        "stock_kg": round(sum(p.get("total_qty") or 0 for p in prods), 1),
        "stock_sum": round(sum(p.get("stock_value_no_vat") or 0 for p in prods), 2),
        "leftover_kg": round(leftover_kg, 1),
        "refed_kg": round(refed_kg, 1),
        # розкладка залишку по кормах — та сама таблиця, що на порталі
        "stock_products": sorted(
            ({"name": p.get("name") or "—",
              "kg": round(p.get("total_qty") or 0, 1),
              "sum": round(p.get("stock_value_no_vat") or 0, 2)}
             for p in prods if (p.get("total_qty") or 0) > 0),
            key=lambda x: -x["sum"]),
    })
    return _ok(uc)


@app.get("/api/feed/day")
def api_feed_day():
    """Роздачі за один день по категоріях/підкатегоріях стада."""
    d = db.feeding_day(day=(request.args.get("day") or "").strip())
    day = d.get("date") or ""
    # Надій для Звіту-1 — освіжаємо з Excel НАЖИВО на цю дату: feeding_day бере
    # молоко з кешу milk_daily, який міг застаріти після нового вводу в Excel
    # (сторінка Надої читає наживо, а Огляд — з кешу → розбіжність). Заразом
    # _milk_daily перезаписує кеш → свіже молоко піде й на сервер.
    if day:
        try:
            _mstart = day[:7] + "-01"
            _fresh = _milk_daily(_mstart, day)
            if _fresh:
                d["milk_day"] = round(_fresh.get(day, 0.0), 1)
                d["milk_month"] = round(sum(_fresh.values()), 1)
        except Exception:  # noqa: BLE001
            pass
    # Вартість завантаженого корму за день (те саме джерело, що «По категоріях»):
    # усього та лише «Корови» (розноситься по головах × коеф).
    feed_cost = feed_cost_all = cows_consumed = 0.0
    disposal_sum = pool_sum = 0.0
    if day:
        try:
            uc = db.feed_usage_by_category("feed", day, day)
            disposal_sum = uc.get("disposal_sum") or 0
            loaded_kg = 0.0
            for c in (uc.get("categories") or []):
                # спожито з переносом залишків (те саме поле, що «Спожито» у
                # «Рух годівлі») — щоб плитки Огляду й «Рух годівлі» збігалися
                val = c.get("consumed_sum") or 0
                feed_cost_all += val
                pool_sum += (c.get("leftover_sum") or 0)   # весь відданий пул ₴
                loaded_kg += (c.get("loaded") or 0)        # завантажено кг за день
                if c.get("category") == "Корови":
                    feed_cost += val                  # Корови, спожито з переносом
                    cows_consumed += val
            d["feed_loaded_kg"] = round(loaded_kg, 1)
            # втрати при балансуванні залишку (інвентаризація → «Втрати»)
            try:
                d["inv_loss"] = db.feed_inventory_loss(day, day)
            except Exception:  # noqa: BLE001
                d["inv_loss"] = {"kg": 0.0, "sum": 0.0}
            # залишки за день: утилізація (збиток) + перенесено в годівлю груп
            if isinstance(d.get("leftover"), dict):
                d["leftover"]["util_sum"] = round(disposal_sum, 2)
                d["leftover"]["util_kg"] = round(uc.get("disposal_kg") or 0, 1)
                # «Перенесено в годівлю» ₴ = пул − утилізація. Якщо в інші групи
                # фактично нічого не перенесено (перенесених кг ≈ 0), сума = 0 —
                # інакше лишалась копійка від округлення FIFO-цін (напр. 0,01 ₴).
                moved_kg = d["leftover"].get("used") or 0
                used_val = max(0.0, pool_sum - disposal_sum)
                if moved_kg <= 0.05:
                    used_val = 0.0
                d["leftover"]["used_sum"] = round(used_val, 2)
        except Exception:  # noqa: BLE001
            pass
        # Ручну годівлю більше НЕ додаємо тут окремо — вона вже входить у
        # feed_usage_by_category (підкатегорія «Ручна годівля»), тож feed_cost/
        # feed_cost_all/cows_consumed вже її містять (інакше подвійний облік).
    d["feed_cost"] = round(feed_cost, 2)
    # «Всього витрачено за день» = спожито (з ручною годівлею) + втрати
    # (утилізація) → збігається з «По кормах» (завантажено зі складу).
    feed_cost_all_full = round(feed_cost_all + disposal_sum, 2)
    d["feed_cost_all"] = feed_cost_all_full
    # для «Корм на 1 кг молока»: утиль лишаємо (збиток корів), перенесене на
    # інші групи забираємо → спожито коровами + утилізація.
    cows_full = round(cows_consumed + disposal_sum, 2)
    d["feed_cost_perkg"] = cows_full

    # Виробництво комбікорму за день (корми-компоненти + вироблений КК) —
    # окремий блок в Огляді; у «Всього витрачено» НЕ додаємо (щоб не задвоїти:
    # КК врахується, коли його згодують).
    d["production"] = db.feed_production_day(day) if day else {
        "components": [], "produced": [], "comp_total_kg": 0,
        "comp_total_cost_no_vat": 0, "prod_total_kg": 0, "prod_total_cost_no_vat": 0}

    # ── Звіт-2: Ефективність виробництва за день ─────────────────────────────
    sales = _milk_sales_day(day) if day else None
    milk_kg = d.get("milk_day") or 0
    d["milk_sold"] = sales                       # {kg, sum_nv, price_nv} або None
    # витрати інших гілок за день (Аптека, Матеріали) — собівартість без ПДВ
    d["other_expense"] = db.branch_expense_day(day) if day else {"pharmacy": 0, "materials": 0}
    # реальний вхідний ПДВ з ПРИХОДУ за день по категоріях (для Звіту-2)
    d["purchase_vat"] = db.purchase_vat_by_category_day(day) if day else {"feed": 0, "pharmacy": 0, "materials": 0}
    # ПДВ-навантаження за день: вихідний (з продажу молока) − вхідний (з усіх закупок)
    vat_out = round((sales.get("vat") or 0) if sales else 0.0, 2)
    vat_in = db.purchase_vat_day(day) if day else 0.0
    d["vat"] = {"output": vat_out, "input": vat_in, "load": round(vat_out - vat_in, 2)}
    eff = {}
    if milk_kg:
        eff["uah_per_kg_cows"] = round(cows_full / milk_kg, 2)          # корм корів+утиль на 1 кг
        eff["cost_per_kg_all"] = round(feed_cost_all_full / milk_kg, 2)  # весь корм на 1 кг молока
        loaded = d.get("feed_loaded_kg") or 0
        eff["feed_return"] = round(milk_kg / loaded, 2) if loaded else None  # кг молока / кг корму
    if sales and sales.get("sum_nv") is not None:
        # маржа за день: виручка від молока (без ПДВ) − усі витрати на корм
        eff["margin"] = round((sales["sum_nv"] or 0) - feed_cost_all_full, 2)
    d["eff"] = eff
    return _ok(d)


# ── Звіт-3: щоденний дашборд ефективності молочної ферми ──────────────────────
# Фіксовані оцінкові ставки (заглушки; згодом винесемо в Налаштування).
FEED_DASH_ASSUMPTIONS = {
    "milk_price": 17.0, "saleable_pct": 98.5, "tmr_cost_per_kg": 4.7,
    "labor_per_cow": 48.0, "vet_repro_per_cow": 10.0, "energy_fuel_per_cow": 16.0,
    "other_opex_per_cow": 12.0, "fixed_per_cow": 20.0,
    "target_accuracy": 95.0, "target_conversion": 1.25, "target_dmi": 24.5,
    "dm_pct": 45.0,
}


def _feed_dashboard_data(days_back: int = 30) -> dict:
    """Per-day дані для дашборда «Щоденна ефективність молочної ферми».
    Реальні показники — з БД (надій сира+залік, продаж жир/білок/сума, дійні
    корови, розхід/план корму, точність, refusal); фінанси — за ставками A.
    Естімейти (приймання молзаводом, СР%, plant жир/білок) позначені *.
    Молоко НЕ переімпортовуємо тут (важко) — БД уже свіжа з відкриття Огляду."""
    import datetime as _dt
    A = dict(FEED_DASH_ASSUMPTIONS)
    dmp = float(A.get("dm_pct") or 45.0)
    # діапазон: останні days_back днів до останнього дня з даними
    try:
        last = (db.feeding_day("") or {}).get("date") or ""
    except Exception:  # noqa: BLE001
        last = ""
    kg_all = {}
    try:
        kg_all = db.milk_kg_map("", "")            # залік по днях
    except Exception:  # noqa: BLE001
        kg_all = {}
    if not last:
        last = max(kg_all.keys()) if kg_all else _dt.date.today().strftime("%Y-%m-%d")
    try:
        end = _dt.datetime.strptime(last[:10], "%Y-%m-%d").date()
    except ValueError:
        end = _dt.date.today()
    if days_back and days_back > 0:
        start = end - _dt.timedelta(days=days_back - 1)
    else:
        # 0/None → уся доступна історія (від найранішої дати з даними)
        earliest = min(kg_all.keys()) if kg_all else ""
        try:
            start = _dt.datetime.strptime(earliest[:10], "%Y-%m-%d").date()
        except ValueError:
            start = end - _dt.timedelta(days=29)
    sf, st = start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")
    # мапи за період (по одному виклику)
    gross = {}
    try:
        for r in db.milk_yields_rows(sf, st):
            gross[r["date"].strftime("%Y-%m-%d")] = float(r.get("milk_total_kg") or 0)
    except Exception:  # noqa: BLE001
        pass
    sales = {}
    try:
        for r in db.milk_sales_rows(sf, st):
            sales[r["date"].strftime("%Y-%m-%d")] = r
    except Exception:  # noqa: BLE001
        pass
    # Метрики жиру/білка — З ТОГО САМОГО мапінгу, що сторінка Продаж (єдине
    # джерело правди). «ф» — через власний den_col метрики; «мз» — той самий
    # чисельник, але den = вага заводу (sale_milk_kg_factory).
    _sales_m = (_milk_config().get("sales") or {}).get("metrics") or []

    def _find_metric(word, plant):
        """Метрика продажу: word у назві ('жир'/'білок'); plant=True → заводська
        (у назві є 'завод'/'плант'/'мз'), plant=False → ферма (без цих слів)."""
        for m in _sales_m:
            lbl = str(m.get("label", "")).lower()
            if word not in lbl:
                continue
            is_plant = any(w in lbl for w in ("завод", "плант", "мз"))
            if is_plant == plant:
                return m
        return None
    _fat_m = _find_metric("жир", False)          # Жир (ф)
    _fat_plant_m = _find_metric("жир", True)      # Жир_завод (мз)
    _prot_m = _find_metric("білок", False)        # Білок (ф)
    _prot_plant_m = _find_metric("білок", True)   # Білок_завод (мз)

    def _find_sale(*words):
        """Метрика продажу, у назві якої є ВСІ слова (напр. 'продано'+'залік')."""
        for m in _sales_m:
            lbl = str(m.get("label", "")).lower()
            if all(w in lbl for w in words):
                return m
        return None
    # «Продано залік» і «Прийнято залік МЗ» — окремі налаштовані колонки-залік
    _sold_kof_m = _find_sale("продано", "залік") or _find_sale("продано")
    _accepted_m2 = _find_sale("прийнято")         # «Прийнято залік МЗ»

    def _sale_sum(m, row):
        """Сума метрики продажу за день (як milk_excel.aggregate на Продажу).
        Для sum-метрики повертає Σ колонок; 0, якщо метрики/даних немає."""
        if not m or not row:
            return 0.0
        try:
            res = milk_excel.aggregate([row], [dict(m)], "all")
            return (res[0]["metrics"].get(m.get("key")) if res else 0.0) or 0.0
        except Exception:  # noqa: BLE001
            return 0.0

    def _sale_pct(m, row, den_override=None):
        """Показник (%, ratio×100) за метрикою продажу для одного дня —
        рівно як milk_excel.aggregate на сторінці Продаж."""
        if not m or not row:
            return 0.0
        mm = dict(m)
        if den_override:
            mm["den_col"] = den_override
            mm.pop("den_cols", None)
        try:
            res = milk_excel.aggregate([row], [mm], "all")
            v = (res[0]["metrics"].get(mm.get("key")) if res else 0.0) or 0.0
            return v * 100.0
        except Exception:  # noqa: BLE001
            return 0.0
    out = []
    day = start
    while day <= end:
        iso = day.strftime("%Y-%m-%d")
        day += _dt.timedelta(days=1)
        credited = float(kg_all.get(iso) or 0)
        g = float(gross.get(iso) or 0)
        try:
            fd = db.feeding_day(iso)
        except Exception:  # noqa: BLE001
            fd = {}
        rows = fd.get("rows") or []
        if not rows and credited <= 0 and g <= 0:
            continue                       # порожній день — пропускаємо
        # дійні корови на дату + фуражні (дійні + сухостій) для маржі/гол
        cows = 0
        cows_fodder = 0
        all_head = 0
        try:
            hv = (db.herd_daily_on(iso) or {}).get("values") or {}
            cows = int(hv.get("d_cow") or 0)
            cows_fodder = int((hv.get("d_cow") or 0)
                              + (hv.get("dry_cow_1") or 0)
                              + (hv.get("dry_cow_2") or 0))
            all_head = int(hv.get("all_anymal") or 0)   # усе поголів'я
        except Exception:  # noqa: BLE001
            cows = 0
        # корм (Корови): роздано (loaded) і план (plan_loaded), refusal %,
        # РЕАЛЬНА собівартість спожитого корму (FIFO, без ПДВ) — consumed_sum
        feed_loaded = plan_feed = refusal = feed_cost = 0.0
        feed_cost_cows = 0.0
        dm_kg = dm_consumed = 0.0
        dairy_feed_cost = dairy_loaded = dairy_plan = 0.0
        acc_load = None
        cats = []; cow = None; src = None; disposal = 0.0
        try:
            uc = db.feed_usage_by_category("feed", iso, iso)
            cats = uc.get("categories") or []
            cow = next((c for c in cats if c.get("category") == "Корови"), None)
            if cow:
                # виробничі KPI (роздано/план/refusal, DMI, конверсія) — по Коровах
                feed_loaded = float(cow.get("loaded") or 0)
                plan_feed = float(cow.get("plan_loaded") or 0)
                refusal = float(cow.get("leftover_pct") or 0)
                acc_load = cow.get("acc_load")  # точність завантаження Корів
                # DMI — реальна суха речовина ДІЙНИХ корів (підгрупа «Дійні»),
                # а не фіксовані 45% від усього роздано. Fallback — рівень Корови.
                src = next((s for s in (cow.get("subs") or [])
                            if "дійн" in str(s.get("subgroup", "")).lower()), None) or cow
                dm_kg = float(src.get("dry") or 0)             # СР спожито, кг
                dm_consumed = float(src.get("consumed") or 0)  # спожито як-є, кг
                dairy_feed_cost = float(src.get("consumed_sum") or 0)  # корм ЛИШЕ дійних (IOFC)
                refusal = float(src.get("leftover_pct") or 0)  # % залишків СУТО по дійних
                dairy_loaded = float(src.get("loaded") or 0)       # роздано дійним, кг
                dairy_plan = float(src.get("plan_loaded") or 0)    # план дійним, кг
            # ВИТРАТИ на корм у P&L — УСІ категорії (ручна годівля + Profeed) +
            # утилізація, тобто «Всього витрачено за день» як у Звіті-1/Звіті-2.
            disposal = float(uc.get("disposal_sum") or 0)
            feed_cost = sum(float(c.get("consumed_sum") or 0) for c in cats) + disposal
            # корм КОРІВ (фуражних): категорія «Корови» + утилізація (як «Корм корів» у Звіті-2)
            feed_cost_cows = (float(cow.get("consumed_sum") or 0) if cow else 0.0) + disposal
        except Exception:  # noqa: BLE001
            pass
        # точність завантаження — Корови acc_load (як на «По категоріях»);
        # fallback — Σmin/Σmax по замісах дня, якщо категорії немає
        if acc_load is not None:
            accuracy = float(acc_load)
        else:
            smin = smax = 0.0
            for r in rows:
                p, f = float(r.get("plan") or 0), float(r.get("fact") or 0)
                smin += min(p, f); smax += max(p, f)
            accuracy = (smin / smax * 100) if smax else 0.0
        srow = sales.get(iso) or {}
        # Гроші/кг/ціна — напряму з таблиці milk_sales_daily (як у Продажу/Звіті-2),
        # НЕ з cols_json (там інша колонка кг спотворювала ціну).
        sd = db.milk_sales_day(iso) or {}
        skg = float(sd.get("kg") or 0)
        sale_amount = float(sd.get("sum_nv") or 0)         # ₴ без ПДВ, реальна виручка
        sale_amount_v = float(sd.get("sum_v") or 0)        # ₴ з ПДВ
        sale_vat = float(sd.get("vat") or 0)               # ₴ ПДВ
        milk_price = float(sd.get("price_nv") or 0)        # реальна ціна/кг без ПДВ
        # Жир/білок — за колонками метрик (kgFat/kgProtein ÷ кг цих метрик)
        # «ф» — метрики «Жир»/«Білок», «мз» — метрики «Жир_завод»/«Білок_завод»
        # (окремі заводські колонки), рівно як на сторінці Продаж.
        fat_pct = _sale_pct(_fat_m, srow)
        prot_pct = _sale_pct(_prot_m, srow)
        plant_fat = _sale_pct(_fat_plant_m, srow) if _fat_plant_m else fat_pct
        plant_prot = _sale_pct(_prot_plant_m, srow) if _prot_plant_m else prot_pct
        feed_head = (feed_loaded / cows) if cows else 0.0
        plan_head = (plan_feed / cows) if cows else 0.0
        # DMI = реальна СР дійних корів ÷ дійні корови (з герд-обліку).
        # СР% — реальна (СР ÷ спожито як-є); fallback на фіксовані 45%, якщо
        # даних немає.
        dmi = (dm_kg / cows) if cows else 0.0
        dm_pct_day = (dm_kg / dm_consumed * 100) if dm_consumed else dmp
        milk = (g / cows) if cows else 0.0                 # надій/гол (сира)
        yield_cred = (credited / cows) if cows else 0.0    # надій/гол (залік)
        # конверсія — як у «Рух годівлі»: надій (залік) ÷ СР спожито
        conv = (yield_cred / dmi) if dmi else 0.0
        # «Продано залік» — з налаштованої колонки-залік (не сира кг); fallback — sale_milk_kg
        sold_own = _sale_sum(_sold_kof_m, srow) if _sold_kof_m else float(srow.get("sale_milk_kg") or 0)
        # «Прийнято залік МЗ» — з налаштованої колонки-залік; fallback — milk_sales_day.kg
        accepted = _sale_sum(_accepted_m2, srow) if _accepted_m2 else skg
        # ── групи для перемикача 5.2 (усе стадо / молодняк / фуражні / дійні / сухостій)
        young_cat = next((c for c in cats if c.get("category") == "Молодняк"), None)
        dry_sub = next((s for s in ((cow.get("subs") if cow else []) or [])
                        if "сухост" in str(s.get("subgroup", "")).lower()), None)
        cows_dry = max(0, cows_fodder - cows)
        young_head = max(0, all_head - cows_fodder)

        # Собівартість корму по групі:
        #  • перенос залишку між групами — кошти вже йдуть за кормом (враховано у
        #    consumed_sum: віддавач −leftover_sum, одержувач +refed_in_sum);
        #  • УТИЛІЗАЦІЯ — витрати лишаються на групі, ЧИЙ залишок утилізовано (де
        #    роздали корм). Розкладаємо денну утилізацію пропорційно до leftover_sum
        #    кожної групи (₴ залишку, відданого в пул).
        pool_total = sum(float(c.get("leftover_sum") or 0) for c in cats)
        util_frac = (disposal / pool_total) if pool_total else 0.0

        def _gm(node, heads, cred, sale):
            node = node or {}
            cons = float(node.get("consumed") or 0)
            dry = float(node.get("dry") or 0)
            acc = node.get("acc_load")
            leftover = float(node.get("leftover") or 0)
            util = float(node.get("leftover_sum") or 0) * util_frac  # утилізація цієї групи
            return {
                "plan": round(float(node.get("plan_loaded") or 0), 0),   # план завантаження
                "loaded": round(float(node.get("loaded") or 0), 0),      # факт завантаження
                "leftover": round(leftover, 0),      # «Залишок, кг» (не з'їдено)
                # вартість = спожито ₴ (перенос уже враховано) + утилізація своєї групи
                "cost": round(float(node.get("consumed_sum") or 0) + util, 2),
                "loaded_val": round(float(node.get("sum") or 0), 2),  # вартість завантаженого корму, ₴
                "util": round(util, 2),              # втрати на утилізацію групи, ₴
                "consumed": round(cons, 1), "dry": round(dry, 1),
                "dm_pct": round(dry / cons * 100, 1) if cons else 0.0,
                "cows": int(heads or 0),
                "refusal": round(float(node.get("leftover_pct") or 0), 1),
                "accuracy": round(float(acc), 1) if acc is not None else None,
                "credited": round(cred, 1), "sale": round(sale, 2),
            }
        _all_node = {
            "plan_loaded": sum(float(c.get("plan_loaded") or 0) for c in cats),
            "loaded": sum(float(c.get("loaded") or 0) for c in cats),
            "leftover": sum(float(c.get("leftover") or 0) for c in cats),
            "consumed": sum(float(c.get("consumed") or 0) for c in cats),
            "dry": sum(float(c.get("dry") or 0) for c in cats),
            "consumed_sum": sum(float(c.get("consumed_sum") or 0) for c in cats),
            "sum": sum(float(c.get("sum") or 0) for c in cats),  # вартість завантаженого, усе стадо
            "leftover_sum": pool_total,   # уся утилізація ляже на «усе стадо»
            "leftover_pct": None, "acc_load": None,
        }
        groups = {
            "all": _gm(_all_node, all_head, credited, sale_amount),
            "young": _gm(young_cat, young_head, 0.0, 0.0),
            "fodder": _gm(cow, cows_fodder, credited, sale_amount),
            "dairy": _gm(src, cows, credited, sale_amount),
            "dry": _gm(dry_sub, cows_dry, 0.0, 0.0),
        }
        # розкладка по РАЦІОНАХ/секціях (Високопродуктивні, Низькопродуктивні…) по
        # кожній групі за день — рядок раціону з план/факт завантажено, залишки,
        # спожито, вартість. Для розкриття дати у 5.2.
        _hsecs = uc.get("herd_sections") or []
        def _is_dry(sub):
            s = (sub or "").lower()
            return ("сухост" in s) or ("запуск" in s) or ("dry" in s)
        def _ration_rows(pred):
            rows = []
            for hs in _hsecs:
                hcat, hsub = hs.get("cat", ""), hs.get("sub", "")
                if not pred(hcat, hsub):
                    continue
                for dd in (hs.get("days") or []):
                    rows.append({
                        "name": hs.get("section", ""),
                        "ration": hs.get("ration", ""),
                        "plan": round(float(dd.get("plan_loaded") or 0), 0),
                        "loaded": round(float(dd.get("loaded") or 0), 0),
                        "leftover": round(float(dd.get("leftover") or 0), 0),
                        "leftover_pct": round(float(dd.get("leftover_pct") or 0), 1)
                        if dd.get("leftover_pct") is not None else None,
                        "consumed": round(float(dd.get("consumed") or 0), 0),
                        "sum": round(float(dd.get("sum") or 0), 2),
                        "heads": round(float(dd.get("heads_days") or 0), 0),
                    })
            return sorted(rows, key=lambda x: -x["loaded"])
        groups["all"]["rations"] = _ration_rows(lambda c, s: True)
        groups["young"]["rations"] = _ration_rows(lambda c, s: c == "Молодняк")
        groups["fodder"]["rations"] = _ration_rows(lambda c, s: c == "Корови")
        groups["dairy"]["rations"] = _ration_rows(lambda c, s: c == "Корови" and not _is_dry(s))
        groups["dry"]["rations"] = _ration_rows(lambda c, s: c == "Корови" and _is_dry(s))
        out.append({
            "groups": groups,
            "iso": iso,
            "date": _dt.datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m"),
            "plan_feed": round(plan_feed, 0), "feed": round(feed_loaded, 0),
            "cows": cows, "cows_fodder": cows_fodder, "all_head": all_head,
            "plan_head": round(plan_head, 1),
            "feed_head": round(feed_head, 1), "dm_pct": round(dm_pct_day, 1),
            "dmi": round(dmi, 2), "milk": round(milk, 1),
            "conv": round(conv, 2), "accuracy": round(accuracy, 1),
            "refusal_pct": round(refusal, 1),
            "fat_pct": round(fat_pct, 2), "protein_pct": round(prot_pct, 2),
            "plant_fat_pct": round(plant_fat, 2),
            "plant_protein_pct": round(plant_prot, 2),
            "gross_milk_kg": round(g, 1),
            "accepted_plant_kg": round(accepted, 1),   # Прийнято мз = заводський залік
            "sold_own_kg": round(sold_own, 1),          # Продано залік = наш облік (sale_milk_kg)
            "credited_milk_kg": round(credited, 1),
            "yield_credited_kg": round(yield_cred, 2),
            "milk_diff_kg": round(credited - accepted, 1),
            # РЕАЛЬНІ фінанси з БД (0 → фронт бере ставку-припущення);
            # гроші — з копійками, щоб збігалося зі Звітом-2 до копійки
            "sale_amount": round(sale_amount, 2),     # виручка ₴ без ПДВ (продаж молока)
            "sale_amount_v": round(sale_amount_v, 2), # виручка ₴ з ПДВ
            "sale_vat": round(sale_vat, 2),           # ПДВ ₴
            "sale_kg": round(skg, 1),                 # продано молока, кг (для ціни за період)
            "milk_price": round(milk_price, 2),       # реальна ціна ₴/кг без ПДВ
            "feed_cost": round(feed_cost, 2),         # витрати на корм ₴ (усі + утиль)
            "feed_cost_cows": round(feed_cost_cows, 2),  # корм корів (Корови + утиль)
            "dairy_feed_cost": round(dairy_feed_cost, 2),  # корм лише дійних (для IOFC)
            "dm_consumed": round(dm_consumed, 1),        # спожито дійними як-є, кг
            "dairy_loaded": round(dairy_loaded, 0),      # роздано дійним, кг
            "dairy_plan": round(dairy_plan, 0),          # план дійним, кг
        })
    # привʼязка витрат із «Фінанси та аналітика» за НАЗВОЮ статті (щоденно)
    if out:
        try:
            fin_daily = _finance_daily_totals(out[0]["iso"], out[-1]["iso"])
            for d in out:
                d["fin"] = fin_daily.get(d["iso"], {})
        except Exception:  # noqa: BLE001
            pass
    return {"data": out, "assumptions": A}


@app.get("/api/feed/dashboard")
def api_feed_dashboard():
    """Дані Звіту-1 (щоденна ефективність) — JSON. Дефолт 180 днів (швидко);
    ?days=N — інша глибина; ?days=0 — уся історія (повільніше на відкритті)."""
    raw = request.args.get("days")
    try:
        days_back = int(raw) if raw is not None else 180
    except ValueError:
        days_back = 180
    try:
        dash = _feed_dashboard_data(days_back)
    except Exception:  # noqa: BLE001 — панель ніколи не має ламати сторінку
        dash = {"data": [], "assumptions": dict(FEED_DASH_ASSUMPTIONS)}
    return _ok(dash)


@app.get("/api/feed/manual")
def api_feed_manual_get():
    """Ручне використання кормів на дату — зі списань «Видача / списання»."""
    day = (request.args.get("day") or "").strip()[:10]
    return _ok({"day": day, "rows": db.feed_manual_usage(day)})


@app.get("/api/feed/usage-by-ingredient")
def api_feed_usage_by_ingredient():
    """Витрата кожного корму з розкладкою Корм → Категорія → Підкатегорія."""
    return _ok(db.feed_usage_by_ingredient(
        category=_inv_category(),
        date_from=(request.args.get("from") or "").strip(),
        date_to=(request.args.get("to") or "").strip()))


def _milk_yield_columns() -> list:
    """Усі стовпці аркуша «Виробництво» (для вибору стовпця надою)."""
    try:
        raw, _ds, err = _milk_rows(_milk_config(), "yields")
        if err or not raw:
            return []
        cols = [k for k in raw[0].keys()
                if k and k != "date" and not str(k).startswith("_")]
        return cols
    except Exception:  # noqa: BLE001
        return []


@app.get("/api/feed/milk-col")
def api_feed_milk_col_get():
    """Який стовпець надою фіксувати для годівлі (конверсія) + усі доступні."""
    return _ok({"col": db.get_setting("feed_milk_col", "") or "milk_total_kg",
                "options": _milk_yield_columns()})


@app.post("/api/feed/milk-col")
def api_feed_milk_col_set():
    col = ((request.get_json(silent=True) or {}).get("col") or "").strip()
    if not col:
        return _err("Вкажіть стовпець.")
    db.set_setting("feed_milk_col", col)
    return _ok({"col": col})


@app.post("/api/feed/writeoff")
def api_feed_writeoff():
    """Зафіксувати списання годівлі за «Рухом кормів» (період фільтра)."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    res = db.writeoff_from_movements(
        date_from=(d.get("from") or "").strip(),
        date_to=(d.get("to") or "").strip(),
        user_id=session.get("user_id"))
    if res.get("error"):
        return _err(res["error"])
    return _ok(res)


@app.post("/api/feed/merge-duplicates")
def api_feed_merge_duplicates():
    """Об'єднати кормові товари-дублікати (однакова назва) в один."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    return _ok(db.merge_feed_duplicates(category=_inv_category()))


@app.post("/api/feed/undo-writeoffs")
def api_feed_undo_writeoffs():
    """Скасувати ВСІ зафіксовані списання годівлі (повернути склад до стану до)."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    return _ok(db.undo_all_feeding_writeoffs(category=_inv_category()))


@app.get("/api/feed/files")
def api_feed_files():
    """Список файлів звітів Profeed у робочій теці (для архівації)."""
    return _ok(db.list_feeding_files())


@app.post("/api/feed/archive-files")
def api_feed_archive_files():
    """Архівувати вибрані файли: дані в БД + перенос у теку «_archive»."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    res = db.archive_feeding_files(d.get("names") or [])
    if res.get("error"):
        return _err(res["error"])
    return _ok(res)


@app.get("/api/feed/auto-writeoff")
def api_feed_autowriteoff_get():
    """Стан автосписання годівлі (щоденне, зі звітів Profeed)."""
    return _ok({"enabled": (db.get_setting("feed_auto_writeoff", "1") or "1") == "1",
                "time": db.get_setting("feed_writeoff_time", "06:30"),
                "last": db.get_setting("feed_writeoff_last", "")})


@app.post("/api/feed/auto-writeoff")
def api_feed_autowriteoff_set():
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    if "enabled" in d:
        db.set_setting("feed_auto_writeoff", "1" if d.get("enabled") else "0")
    t = (d.get("time") or "").strip()
    if t:
        db.set_setting("feed_writeoff_time", t)
    return _ok({"enabled": (db.get_setting("feed_auto_writeoff", "1") or "1") == "1",
                "time": db.get_setting("feed_writeoff_time", "06:30")})


@app.post("/api/feed/feeding-milk")
def api_feed_feeding_milk():
    """Ручне внесення надою по (секція, дата) — для конверсії корму."""
    d = request.get_json(silent=True) or {}
    try:
        res = db.set_feeding_milk(
            section=(d.get("section") or "").strip(),
            day=(d.get("day") or "").strip(),
            milk_kg=d.get("milk_kg"))
    except ValueError as e:
        return _err(str(e))
    return _ok(res)


@app.post("/api/feed/feeding-leftover")
def api_feed_feeding_leftover():
    """Ручне внесення залишку ЗМР у годівниці по (секція/група, дата).
    Спожито = роздача − залишок; qty=0 прибирає ручний залишок."""
    d = request.get_json(silent=True) or {}
    try:
        res = db.set_feeding_leftover(
            section=(d.get("section") or "").strip(),
            day=(d.get("day") or "").strip(),
            qty_kg=d.get("qty_kg"))
    except ValueError as e:
        return _err(str(e))
    return _ok(res)


@app.post("/api/feed/pool-dest")
def api_feed_pool_dest():
    """Розподіл ЗАГАЛЬНОГО пулу залишків на дату: куди (група / «Утилізація») і
    скільки кг. Роздане групі додається до її спожито; решта — утилізація."""
    d = request.get_json(silent=True) or {}
    try:
        res = db.set_feeding_pool_dest(
            day=(d.get("day") or "").strip(),
            dests=d.get("dests") or [])
    except ValueError as e:
        return _err(str(e))
    return _ok(res)


@app.get("/api/bovio/log")
def api_bovio_log():
    """Реєстр обміну (останні 15 подій) — і на ПК, і на серверній фермі."""
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if not u or u.get("role") != "admin":
        return _err("Лише адміністратор.", 403)
    try:
        lim = max(1, min(300, int(request.args.get("limit") or 300)))
    except (TypeError, ValueError):
        lim = 300
    return _ok({"log": db.bovio_log(lim)})


@app.get("/api/feed/pool-auto")
def api_feed_pool_auto_get():
    """Стан правила «розподіл залишків як попереднього дня»."""
    return _ok({"enabled": (db.get_setting("feed_pool_auto", "1") or "1") == "1",
                "last": db.get_setting("feed_pool_auto_last", "")})


@app.post("/api/feed/pool-auto")
def api_feed_pool_auto_set():
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    if "enabled" in d:
        db.set_setting("feed_pool_auto", "1" if d.get("enabled") else "0")
    done = []
    if d.get("now") and db.get_setting("feed_pool_auto", "1") == "1":
        done = db.feed_pool_autodist()
        if done:
            db.set_setting("feed_pool_auto_last",
                           "%s · днів: %d" % (datetime.now().strftime("%Y-%m-%d %H:%M"),
                                              len(done)))
    return _ok({"enabled": (db.get_setting("feed_pool_auto", "1") or "1") == "1",
                "filled": done, "last": db.get_setting("feed_pool_auto_last", "")})


@app.get("/api/feed/headcount-source")
def api_feed_headcount_source_get():
    return _ok({"source": db.get_setting("feed_headcount_source", "profeed") or "profeed"})


@app.post("/api/feed/headcount-source")
def api_feed_headcount_source_set():
    """Джерело поголів'я для аналітики: 'profeed' (зі звітів) або 'herd' (секції)."""
    src = ((request.get_json(silent=True) or {}).get("source") or "").strip()
    if src not in ("profeed", "herd"):
        return _err("Дозволено 'profeed' або 'herd'.")
    db.set_setting("feed_headcount_source", src)
    return _ok({"source": src})


@app.get("/api/feed/analytics")
def api_feed_analytics():
    """Аналітика годівлі по секціях: кг/гол/день, ₴/гол/день (без ПДВ),
    і ₴ корму на 1 кг молока для дійних."""
    date_from = (request.args.get("from") or "").strip()
    date_to = (request.args.get("to") or "").strip()
    res = db.feeding_analytics(category=_inv_category(),
                               date_from=date_from, date_to=date_to)
    sections = res.get("sections", [])
    # ₴ корму на 1 кг молока (дійні): сумарна собівартість кормів дійних секцій
    # ділимо на надій за той самий період.
    milk_kg = _milk_total_kg(date_from, date_to)
    def _is_dairy(s):
        blob = f"{s.get('subgroup','')} {s.get('block_name','')}".lower()
        return s.get("herd_kind") == "cow" and "дійн" in blob
    dairy_cost_nv = sum(s["cost_no_vat"] for s in sections if _is_dairy(s))
    res["milk_kg"] = milk_kg
    res["dairy_cost_no_vat"] = round(dairy_cost_nv, 2)
    res["uah_per_kg_milk"] = round(dairy_cost_nv / milk_kg, 2) if (milk_kg and dairy_cost_nv) else None
    return _ok(res)


@app.post("/api/feed/profeed/import")
def api_feed_profeed_import():
    """Провести обрані заміси з Profeed (пакетно)."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    folder = (d.get("dir") or db.get_setting("feed_profeed_dir", "")).strip()
    keys = d.get("src_keys") or []
    if not folder:
        return _err("Не вказано теку звітів Profeed.")
    if not keys:
        return _err("Не обрано жодного замісу.")
    try:
        res = db.import_profeed_productions(folder, keys, user_id=session.get("user_id"))
        if res.get("error"):
            return _err(res["error"])
        return _ok(res)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка імпорту: {exc}")


@app.post("/api/feed/produce")
def api_feed_produce():
    """Провести виробництво: списати компоненти, оприбуткувати комбікорм."""
    d = request.get_json(silent=True) or {}
    try:
        res = db.produce_combifeed(
            product_id=int(d.get("product_id") or 0),
            qty_out=float(d.get("qty_out") or 0),
            components=d.get("components") or [],
            prod_date=(d.get("prod_date") or "").strip(),
            note=(d.get("note") or "").strip(),
            # src_key/source — коли проводимо підтягнутий із Profeed заміс
            # (після можливого коригування компонентів вручну)
            src_key=(d.get("src_key") or "").strip(),
            source=(d.get("source") or "manual").strip(),
            user_id=session.get("user_id"))
        return _ok(res)
    except (ValueError, TypeError) as exc:
        return _err(str(exc))


@app.post("/api/feed/seed-catalog")
def api_feed_seed_catalog():
    """Заповнити довідник кормів позиціями з експорту Profeed.

    Ідемпотентно: додає лише те, чого ще немає; наявні корми не змінює.
    Разом додає зіставлення кодів Profeed і рецепти комбікормів."""
    g = _manage_guard("feed")
    if g is not None:
        return g
    try:
        return _ok(db.seed_feed_catalog(user_id=session.get("user_id")))
    except Exception as exc:
        return _err(str(exc))


@app.post("/api/products")
def api_create_product():
    data = request.get_json(silent=True) or {}
    try:
        pid = db.add_product(
            name=data.get("name", ""),
            barcode=data.get("barcode", ""),
            code=data.get("code", ""),
            unit=data.get("unit", "шт"),
            min_stock=float(data.get("min_stock") or 0),
            supplier=data.get("supplier", ""),
            notes=data.get("notes", ""),
            category=_inv_category(),
            dose_per_head=data.get("dose_per_head", 0),
            dose_unit=data.get("dose_unit", ""),
            dose_interval_days=data.get("dose_interval_days", 0),
            pack_content=data.get("pack_content", 0),
            exclude_from_order=data.get("exclude_from_order", 0),
        )
    except ValueError as exc:
        return _err(str(exc))
    except Exception as exc:  # sqlite UNIQUE etc
        msg = str(exc)
        if "UNIQUE" in msg:
            return _err("Товар з таким штрихкодом вже існує.")
        return _err(msg)
    prod = db.get_product(pid)
    return _ok({"id": pid, "barcode": prod["barcode"] if prod else
                data.get("barcode", "")})


@app.put("/api/products/<int:product_id>")
def api_update_product(product_id: int):
    data = request.get_json(silent=True) or {}
    try:
        db.update_product(product_id, **data)
    except Exception as exc:
        return _err(str(exc))
    return _ok()


@app.delete("/api/products/<int:product_id>")
def api_delete_product(product_id: int):
    db.delete_product(product_id)
    return _ok()


@app.get("/api/schemes")
def api_schemes_list():
    """Схеми лікування/профілактики поточної гілки (разом із рядками).
    ?year=&month= — місяць, на який показувати поголів'я зі стада."""
    y, m = _plan_year_month()
    return _ok({"items": db.list_schemes(_inv_category(), hc_year=y, hc_month=m)})


@app.post("/api/schemes")
def api_scheme_save():
    """Створити/оновити схему разом із рядками (рядки перезаписуються)."""
    data = request.get_json(silent=True) or {}
    try:
        sid = db.save_scheme(
            data.get("id"),
            data.get("name", ""),
            data.get("block_id"),
            data.get("headcount", 0),
            data.get("lines") or [],
            category=_inv_category(),
            hc_source=data.get("hc_source", "manual"),
            hc_ref_id=data.get("hc_ref_id"),
        )
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok({"id": sid})


@app.delete("/api/schemes/<int:scheme_id>")
def api_scheme_delete(scheme_id: int):
    db.delete_scheme(scheme_id)
    return _ok()


@app.post("/api/schemes/reorder")
def api_scheme_reorder():
    """Зберегти новий порядок схем (перетягуванням) у межах гілки."""
    data = request.get_json(silent=True) or {}
    db.reorder_schemes(data.get("order", []), category=_inv_category())
    return _ok()


# ------------------------------------------------------------ стадо (глобально)
@app.get("/api/herd")
def api_herd_get():
    """Групи стада + помісячні цифри за рік (одне спільне стадо для всіх гілок)."""
    try:
        year = int(request.args.get("year") or 0)
    except (TypeError, ValueError):
        year = 0
    if not year:
        year = datetime.now().year
    return _ok(db.get_herd_year(year))


@app.post("/api/herd/save")
def api_herd_save():
    """Зберегти класифікацію груп і цифри за рік одним запитом."""
    data = request.get_json(silent=True) or {}
    try:
        state = db.save_herd(data.get("year"), data.get("groups") or [],
                             data.get("deleted") or [])
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok(state)


@app.post("/api/herd/moves/save")
def api_herd_moves_save():
    """Зберегти типи руху + помісячні цифри за рік (сітка, як поголів'я)."""
    data = request.get_json(silent=True) or {}
    try:
        state = db.save_herd_moves(data.get("year"), data.get("types") or [],
                                   data.get("deleted") or [])
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok(state)


@app.get("/api/herd/sections")
def api_herd_sections_list():
    """Секції стада з періодами (дата з-по, статус, поголів'я)."""
    return _ok({"sections": db.list_herd_sections()})


@app.post("/api/herd/sections/save")
def api_herd_sections_save():
    """Зберегти секції з їх періодами одним запитом."""
    data = request.get_json(silent=True) or {}
    try:
        state = db.save_herd_sections(data.get("sections") or [],
                                      data.get("deleted") or [])
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    return _ok(state)


@app.get("/api/herd/profeed-groups")
def api_herd_profeed_groups():
    """Список роздач (груп) зі звітів Profeed — «Група-1», «Група-2»…"""
    folder = db.get_setting("feed_profeed_dir", "").strip()
    if not folder:
        return _ok({"groups": [], "note": "Не вказано теку звітів Profeed."})
    try:
        res = db.list_profeed_feed_groups(folder)
        return _ok({"groups": res.get("groups", []), "error": res.get("error", "")})
    except Exception as exc:  # noqa: BLE001
        return _ok({"groups": [], "error": f"Помилка читання: {exc}"})


@app.post("/api/herd/sections/from-profeed")
def api_herd_sections_from_profeed():
    """Створити секції за роздачами зі звітів Profeed."""
    g = _manage_guard("herd")
    if g is not None:
        return g
    folder = db.get_setting("feed_profeed_dir", "").strip()
    if not folder:
        return _err("Спершу вкажіть теку звітів Profeed (сторінка «Виробництво КК»).")
    try:
        res = db.autocreate_sections_from_profeed(folder)
        if res.get("error"):
            return _err(res["error"])
        return _ok(res)
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


# ── Поголів'я по днях із зовнішнього Excel (за шаблоном «молока»): читаємо
# файл наживо за налаштованим шляхом + мапінг колонок. Нічого не дублюємо.
DEFAULT_HERD_CONFIG = {
    "file_path": ("/Users/romanlubchenko/Library/CloudStorage/OneDrive-LRA/"
                  "farm/03_Herd_Structure/03_Herd_Structure.xlsx"),
    "sheet": "herd", "header_row": 3, "date_col": "date",
    "cols": [
        {"col": "all_anymal", "label": "Всього"},
        {"col": "d_cow", "label": "Дійні"},
        {"col": "dry_cow_1", "label": "Сухостій-1"},
        {"col": "dry_cow_2", "label": "Сухостій-2"},
        {"col": "preg_heifer(Neteli)", "label": "Нетелі"},
        {"col": "heifer_0-3", "label": "Телички 0-3"},
        {"col": "heifer_4-6", "label": "Телички 3-6"},
        {"col": "heifer_7-12", "label": "Телички 6-12"},
        {"col": "heifer_13+", "label": "Телиці парув."},
        {"col": "bull_0-3", "label": "Бички 0-3"},
        {"col": "bull_4-6", "label": "Бички 3-6"},
        {"col": "bull_7-12", "label": "Бички 6-12"},
        {"col": "bull_13+", "label": "Бугаї"},
    ],
}


def _herd_config() -> dict:
    raw = db.get_setting("herd_config", None)
    if not raw:
        return json.loads(json.dumps(DEFAULT_HERD_CONFIG))
    try:
        cfg = json.loads(raw)
    except Exception:  # noqa: BLE001
        return json.loads(json.dumps(DEFAULT_HERD_CONFIG))
    for k, v in DEFAULT_HERD_CONFIG.items():
        cfg.setdefault(k, v)
    cfg["file_path"] = _excel_path(cfg.get("file_path") or "")
    return cfg


@app.get("/api/herd/cowdays")
def api_herd_cowdays():
    """Голово-дні дійних (d_cow) з управління стада за період [from,to] —
    для розрахунку СР/гол та молоко/гол на дійну корову у «Рух годівлі»."""
    f = (request.args.get("from") or "").strip()
    t = (request.args.get("to") or "").strip()
    grp = (request.args.get("grp") or "d_cow").strip()
    try:
        return _ok(db.herd_cowdays(f, t, grp))
    except Exception:  # noqa: BLE001
        return _ok({"cowdays": 0, "days": 0, "avg": 0})


@app.get("/api/herd/daily")
def api_herd_daily():
    """Поголів'я НА КІНЕЦЬ ПЕРІОДУ (day/week/month/quarter/year) — читаємо Excel
    наживо за налаштуваннями (herd_config). Для кожного періоду беремо значення
    з останнього наявного дня (поголів'я — це стан, а не сума)."""
    cfg = _herd_config()
    period = (request.args.get("period") or "month").strip()
    if period not in ("day", "week", "month", "quarter", "year"):
        period = "month"
    cols_cfg = [c for c in (cfg.get("cols") or []) if c.get("col")]
    out_cols = [{"key": c["col"], "label": c.get("label") or c["col"]} for c in cols_cfg]
    colnames = [c["col"] for c in cols_cfg]
    path = (cfg.get("file_path") or "").strip()
    if not path or not Path(path).expanduser().exists():
        return _ok({"cols": out_cols, "rows": [], "period": period, "path": path,
                    "error": "Файл не знайдено. Відкрийте «Джерело поголів'я»."})
    try:
        raw = milk_excel.read_rows(path, cfg.get("sheet"),
                                   int(cfg.get("header_row", 1)),
                                   cfg.get("date_col"), colnames)
    except Exception as exc:  # noqa: BLE001
        return _ok({"cols": out_cols, "rows": [], "period": period, "path": path,
                    "error": f"Помилка читання: {exc}"})
    cut = ""
    if (request.args.get("today") or "") in ("1", "true", "on", "yes"):
        import datetime as _dt
        cut = _dt.date.today().isoformat()
    buckets = {}
    for r in raw:
        d = r.get("date")
        if not hasattr(d, "isoformat"):
            continue
        day = d.isoformat()
        if cut and day > cut:          # відкидаємо майбутні дати
            continue
        key, label, sort = milk_excel.bucket(d, period)
        cur = buckets.get(key)
        if cur is None or day > cur["day"]:      # останній день періоду
            vals = {}
            for cn in colnames:
                rv = r.get(cn)
                vals[cn] = None if rv in (None, "") else int(round(milk_excel._num(rv)))
            buckets[key] = {"label": label, "sort": sort, "day": day, "values": vals}
    rows = [{"period": b["label"], "day": b["day"],
             "total": b["values"].get(colnames[0]) if colnames else 0,
             "values": b["values"]}
            for b in sorted(buckets.values(), key=lambda x: x["sort"], reverse=True)]
    # заодно фіксуємо поголів'я по днях у БД (для синхронізації на сервер)
    try:
        labels = {c["col"]: (c.get("label") or c["col"]) for c in cols_cfg}
        hd = []
        for r in raw:
            d = r.get("date")
            if not hasattr(d, "isoformat"):
                continue
            day = d.isoformat()
            for cn in colnames:
                v = milk_excel._num(r.get(cn))
                if not v:
                    continue
                hd.append({"day": day, "grp": cn, "label": labels.get(cn, cn), "heads": v})
        if hd:
            db.set_herd_daily(hd)
    except Exception:  # noqa: BLE001
        pass
    return _ok({"cols": out_cols, "rows": rows, "period": period, "path": path})


def _herd_on(day: str = "") -> dict:
    """Поголів'я по групах НА ДАТУ (останній наявний день ≤ day).
    Основне джерело — БД (herd_daily); Excel — лише як відкат, якщо БД порожня."""
    cfg = _herd_config()
    day = (day or "").strip()[:10]
    cols_cfg = [c for c in (cfg.get("cols") or []) if c.get("col")]
    out_cols = [{"key": c["col"], "label": c.get("label") or c["col"]} for c in cols_cfg]
    colnames = [c["col"] for c in cols_cfg]
    res = {"cols": out_cols, "values": {}, "day": ""}
    # 1) з БД (herd_daily) — фіксовані дані, працює й офлайн/на сервері
    try:
        d = db.herd_daily_on(day)
        if d.get("day"):
            res["values"] = {cn: d["values"].get(cn) for cn in colnames}
            res["day"] = d["day"]
            return res
    except Exception:  # noqa: BLE001
        pass
    # 2) відкат: читаємо Excel наживо (якщо БД ще порожня)
    path = (cfg.get("file_path") or "").strip()
    if not path or not Path(path).expanduser().exists():
        res["error"] = "Файл не знайдено."
        return res
    try:
        raw = milk_excel.read_rows(path, cfg.get("sheet"),
                                   int(cfg.get("header_row", 1)),
                                   cfg.get("date_col"), colnames)
    except Exception as exc:  # noqa: BLE001
        res["error"] = f"Помилка читання: {exc}"
        return res
    best = None
    for r in raw:
        d = r.get("date")
        if not hasattr(d, "isoformat"):
            continue
        ds = d.isoformat()
        if day and ds > day:
            continue
        if best is None or ds > best[0]:
            best = (ds, r)
    if best:
        r = best[1]
        vals = {}
        for cn in colnames:
            rv = r.get(cn)
            vals[cn] = None if rv in (None, "") else int(round(milk_excel._num(rv)))
        res["values"] = vals
        res["day"] = best[0]
    return res


@app.get("/api/herd/on")
def api_herd_on():
    return _ok(_herd_on(request.args.get("day") or ""))


@app.route("/herd/structure")
def page_herd_structure():
    """Налаштування джерела поголів'я (Excel-файл + мапінг колонок)."""
    return render_template("herd_structure_settings.html",
                           active="herd", cfg=_herd_config())


@app.get("/api/herd/sheets")
def api_herd_sheets():
    path = (request.args.get("path") or _herd_config().get("file_path") or "").strip()
    if not path or not Path(path).expanduser().exists():
        return _err("Файл не знайдено.", 404)
    try:
        return jsonify({"ok": True, "sheets": milk_excel.list_sheets(path)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося прочитати файл: {exc}")


@app.get("/api/herd/columns")
def api_herd_columns():
    path = (request.args.get("path") or _herd_config().get("file_path") or "").strip()
    sheet = request.args.get("sheet") or ""
    header_row = int(request.args.get("header_row") or 1)
    if not path or not Path(path).expanduser().exists():
        return _err("Файл не знайдено.", 404)
    try:
        return jsonify({"ok": True, "columns": milk_excel.list_columns(path, sheet, header_row)})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося прочитати аркуш: {exc}")


@app.post("/api/herd/config")
def api_herd_config_save():
    g = _manage_guard("herd")
    if g is not None:
        return g
    data = request.get_json(silent=True) or {}
    cfg = _herd_config()
    for k in ("file_path", "sheet", "header_row", "date_col", "cols"):
        if k in data:
            cfg[k] = data[k]
    cfg["file_path"] = _keep_pc_path(cfg.get("file_path", ""), "herd_config")
    db.set_setting("herd_config", json.dumps(cfg, ensure_ascii=False))
    return jsonify({"ok": True})


# ── Поголівний облік (реєстр тварин) ────────────────────────────────────
@app.get("/api/herd/animals")
def api_herd_animals_list():
    """Список тварин із фільтрами + зведення + секції для фільтра."""
    items = db.list_animals(
        q=request.args.get("q", ""),
        status=request.args.get("status", ""),
        group_id=request.args.get("group_id") or None,
        sex=request.args.get("sex", ""))
    return _ok({"items": items, "stats": db.herd_animal_stats(),
                "groups": db.list_herd_groups(),
                "statuses": db.ANIMAL_STATUSES})


@app.get("/api/herd/animals/<int:animal_id>")
def api_herd_animal_get(animal_id: int):
    a = db.get_animal(animal_id)
    if not a:
        return _err("Тварину не знайдено.", 404)
    return _ok(a)


@app.post("/api/herd/animals")
def api_herd_animal_add():
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.add_animal(data))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/animals/<int:animal_id>")
def api_herd_animal_update(animal_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.update_animal(animal_id, data))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/animals/<int:animal_id>/status")
def api_herd_animal_status(animal_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.set_animal_status(
            animal_id, data.get("status", ""),
            data.get("exit_date", ""), data.get("exit_reason", "")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/animals/<int:animal_id>/events")
def api_herd_animal_event_add(animal_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.add_animal_event(
            animal_id, data.get("event_type", ""), data.get("event_date", ""),
            data.get("category", "other"), data.get("value", 0),
            data.get("ref_tag", ""), data.get("details", ""),
            user_id=session.get("user_id")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.delete("/api/herd/animals/events/<int:event_id>")
def api_herd_animal_event_del(event_id: int):
    return _ok(db.delete_animal_event(event_id))


@app.patch("/api/herd/animals/events/<int:event_id>")
def api_herd_animal_event_edit(event_id: int):
    """Правка події (дата/значення/коментар) з чесним перерахунком
    параметрів тварини з її ланцюга подій."""
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.update_animal_event(
            event_id, event_date=data.get("event_date"),
            inputs=data.get("inputs"), details=data.get("details")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.get("/api/herd/events-log")
def api_herd_events_log():
    return _ok({"events": db.list_recent_events(
        limit=int(request.args.get("limit") or 100),
        q=request.args.get("q", ""))})


def _animals_detect_columns(headers: list[str]) -> dict:
    lc = [(h or "").strip().casefold() for h in headers]

    def find(keys):
        for i, h in enumerate(lc):
            if any(k in h for k in keys):
                return i
        return None
    return {
        "tag": find(["бирк", "номер", "№", "tag", "ід", "id"]),
        "name": find(["кличк", "ім", "name", "прізв"]),
        "sex": find(["стат", "sex", "гендер"]),
        "birth_date": find(["народж", "birth", "дата нар", "д.н"]),
        "breed": find(["пород", "breed"]),
        "dam_tag": find(["мат", "мам", "dam", "корова-мати"]),
        "sire_code": find(["бат", "бик", "тат", "sire", "плідник"]),
        "lactation_no": find(["лактац", "lact"]),
        "group_id": find(["груп", "секц", "group", "стійл"]),
    }


@app.post("/api/herd/animals/import")
def api_herd_animals_import():
    """Імпорт тварин із CSV/XLSX. Колонки визначаються автоматично
    (бирка, кличка, стать, дата народж., порода, мама, батько, лактація)."""
    f = request.files.get("file")
    if not f:
        return _err("Файл не надіслано.")
    raw = f.read()
    if not raw:
        return _err("Файл порожній.")
    fname = (f.filename or "").lower()
    try:
        table = _catalog_read_xlsx(raw) if fname.endswith((".xlsx", ".xlsm", ".xls")) \
            else _catalog_read_csv(raw)
    except Exception as exc:  # noqa: BLE001
        return _err("Не вдалося прочитати файл: " + str(exc))
    if not table or len(table) < 2:
        return _err("У файлі немає даних.")
    headers, body = table[0], table[1:]
    cols = _animals_detect_columns(headers)
    if cols["tag"] is None:
        return _err("Не знайдено колонку з биркою/номером. Додайте стовпець «Бирка».")
    # секції: назва → id (для мапінгу групи)
    groups = {(g["name"] or "").strip().casefold(): g["id"]
              for g in db.list_herd_groups()}

    def cell(r, key):
        i = cols.get(key)
        return (r[i].strip() if i is not None and i < len(r) else "")

    def norm_sex(v):
        v = (v or "").strip().casefold()
        if v in ("m", "ч", "б", "бик", "самець", "male", "male"):
            return "M"
        return "F"
    rows = []
    for r in body:
        tag = cell(r, "tag")
        if not tag:
            continue
        gname = cell(r, "group_id").casefold()
        rows.append({
            "tag": tag, "name": cell(r, "name"), "sex": norm_sex(cell(r, "sex")),
            "birth_date": cell(r, "birth_date"), "breed": cell(r, "breed"),
            "dam_tag": cell(r, "dam_tag"), "sire_code": cell(r, "sire_code"),
            "lactation_no": cell(r, "lactation_no"),
            "group_id": groups.get(gname), "source": "imported",
        })
    if not rows:
        return _err("Немає рядків із биркою для імпорту.")
    return _ok(db.import_animals(rows))


# ── Параметри тварин (типізовані: стандартні + власні) ──────────────────
@app.get("/api/herd/params")
def api_herd_params_list():
    params = db.list_param_defs()
    # операнди-дати для узагальнених формул: спец-дати ядра + параметри типу «Дата»
    date_operands = [
        {"key": "__today__", "label": "Сьогодні"},
        {"key": "birth_date", "label": "Дата народження"},
        {"key": "entry_date", "label": "Дата надходження"},
        {"key": "exit_date", "label": "Дата вибуття"},
    ]
    num_operands = [{"key": "lactation_no", "label": "№ лактації"}]
    cod_operands = []
    for p in params:
        if p.get("dtype") == "date":
            date_operands.append({"key": p["key"], "label": p["label"]})
        elif p.get("dtype") in ("int", "float", "number"):
            num_operands.append({"key": p["key"], "label": p["label"]})
        elif p.get("dtype") in ("cod", "code"):
            cod_operands.append({"key": p["key"], "label": p["label"]})
    return _ok({"params": params,
                "dtypes": list(db.PARAM_DTYPES),
                "sections": list(db.PARAM_SECTIONS),
                "formula_ops": [
                    {"op": "date_diff", "label": "Різниця дат (A − B), у днях",
                     "a": "date", "b": "date"},
                    {"op": "date_add", "label": "Дата + число днів (A + B)",
                     "a": "date", "b": "num"},
                    {"op": "date_sub", "label": "Дата − число днів (A − B)",
                     "a": "date", "b": "num"},
                    {"op": "num_diff", "label": "Різниця чисел (A − B)",
                     "a": "num", "b": "num"},
                    {"op": "num_sum", "label": "Сума чисел (A + B)",
                     "a": "num", "b": "num"},
                    {"op": "code_label", "label": "Мітка коду (довідник відповідностей)",
                     "a": "cod", "b": ""},
                ],
                "date_operands": date_operands,
                "num_operands": num_operands,
                "cod_operands": cod_operands})


@app.post("/api/herd/params")
def api_herd_params_add():
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.add_param_def(data))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/params/reorder")
def api_herd_params_reorder():
    data = request.get_json(silent=True) or {}
    return _ok(db.reorder_param_defs(data.get("order") or []))


@app.post("/api/herd/params/<int:param_id>")
def api_herd_params_update(param_id: int):
    data = request.get_json(silent=True) or {}
    try:
        # тип стандартного параметра може змінити лише адміністратор
        return _ok(db.update_param_def(param_id, data, allow_type_change=_is_admin()))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.delete("/api/herd/params/<int:param_id>")
def api_herd_params_delete(param_id: int):
    try:
        # стандартні параметри може видалити лише адміністратор
        return _ok(db.delete_param_def(param_id, allow_standard=_is_admin()))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.get("/api/herd/animals/<int:animal_id>/params")
def api_herd_animal_params(animal_id: int):
    return _ok({"params": db.get_animal_params(animal_id)})


# ── Події, що змінюють параметри ────────────────────────────────────────
@app.get("/api/herd/calf-names")
def api_herd_calf_names_get():
    return _ok(db.get_calf_names())


@app.post("/api/herd/calf-names")
def api_herd_calf_names_set():
    data = request.get_json(silent=True) or {}
    db.set_calf_names(data.get("F") or [], data.get("M") or [])
    return _ok({})


# ── Гілка «Управління фінансами» ────────────────────────────────────────
def _fin_fmt(v: float) -> str:
    return (f"{v:,.2f}".replace(",", " ")) if v else "—"


def _spread_row_to_days(r, value_cols):
    """Розподілити місячний рядок на всі дні його місяця: сума ÷ к-сть днів на
    кожен день. Рядкові (виміри/фільтри) копіюються без змін. Для «частки» ділення
    чисельника й знаменника взаємно скорочується → частка на кожен день та сама."""
    import calendar as _cal
    import datetime as _dt
    d = r.get("date")
    dd = d.date() if hasattr(d, "date") else d
    n = _cal.monthrange(dd.year, dd.month)[1]
    out = []
    for day in range(1, n + 1):
        nr = dict(r)
        nr["date"] = _dt.date(dd.year, dd.month, day)
        for c in value_cols:
            nr[c] = milk_excel._num(r.get(c)) / n
        out.append(nr)
    return out


def _finance_ingest() -> int:
    """Excel → БД: фіксує рядки всіх активних статей витрат (усі колонки).
    Далі звіт читає З БАЗИ (Excel — лише джерело імпорту, як у молоці)."""
    items = [i for i in db.list_finance_items()
             if i["kind"] == "expense" and i["is_active"]]
    total = 0
    for it in items:
        cfg = db.get_finance_source(it["id"])
        path = (cfg.get("path") or "").strip()
        date_col = (cfg.get("date_col") or "").strip()
        if not (path and date_col):
            continue
        try:
            sheet = cfg["sheet"] or (milk_excel.list_sheets(path) or [""])[0]
            allcols = [c for c in milk_excel.list_columns(path, sheet, int(cfg["header_row"] or 1)) if c]
            rows = milk_excel.read_rows(path, sheet, int(cfg["header_row"] or 1), date_col, allcols)
        except Exception:  # noqa: BLE001
            continue
        recs = []
        for r in rows:
            d = r.get("date")
            iso = d.isoformat() if hasattr(d, "isoformat") else str(d)
            recs.append({"date": iso, "cells": {c: r.get(c) for c in allcols}})
        total += db.set_finance_rows(it["id"], recs)
    return total


def _fin_is_cows_metric(m) -> bool:
    """Показник належить «Коровам» — за групою стовпця або фільтром зі значенням Корови."""
    if (m.get("group") or "").strip().lower() == "корови":
        return True
    for f in (m.get("filters") or []):
        if (f.get("val") or "").strip().lower() == "корови":
            return True
    return False


def _fin_row_is_cows(r, dims) -> bool:
    """Рядок належить «Коровам» — якщо будь-який вимір розбивки = Корови."""
    for d in dims:
        v = r.get(d)
        if v is not None and str(v).strip().lower() == "корови":
            return True
    return False


def _finance_daily_totals(df: str = "", dt: str = "") -> dict:
    """Щоденна сума кожної статті витрат (₴) у діапазоні [df,dt] (ISO).
    Повертає {iso_day: {назва_статті: {"all": сума_всього, "cows": частина_Корови}}}.
    «all» = усе стадо (Корови+Молодняк), «cows» = лише Корови (за групою/фільтром)."""
    import datetime as _dt
    items = [i for i in db.list_finance_items()
             if i["kind"] == "expense" and i["is_active"]]
    out: dict = {}
    for it in items:
        cfg = db.get_finance_source(it["id"])
        mets = [m for m in (cfg.get("metrics") or []) if (m.get("label") or "").strip()]
        add_mets = [m for m in mets if m.get("agg", "sum") in ("sum", "psum")]
        # якщо є позначені «★ Сума» — рахуємо лише їх, інакше всі адитивні
        flagged = [m for m in add_mets if m.get("r1")]
        if flagged:
            add_mets = flagged
        piv = cfg.get("pivot") or {}
        pval = (piv.get("value_col") or "").strip()
        pdims = [d for d in (piv.get("dims") or []) if d]
        has_pivot = bool(pval and pdims)
        if not (add_mets or has_pivot):
            continue
        rows = []
        for rr in db.get_finance_rows(it["id"]):
            ds = (rr.get("op_date") or "")[:10]
            if not ds:
                continue
            try:
                dd = _dt.date.fromisoformat(ds)
            except ValueError:
                continue
            row = dict(rr.get("cells") or {})
            row["date"] = dd
            rows.append(row)
        if cfg.get("spread"):
            value_cols = set(milk_excel.cols_used(mets))
            if has_pivot:
                value_cols.add(pval)
            rows = [nr for r in rows for nr in _spread_row_to_days(r, list(value_cols))]
        for r in rows:
            iso = r["date"].isoformat()
            if df and iso < df:
                continue
            if dt and iso > dt:
                continue
            amt_all = 0.0
            amt_cows = 0.0
            for m in add_mets:
                if not _fin_metric_matches(r, m):
                    continue
                if m.get("agg") == "psum":
                    v = _fin_rowsum(r, m.get("num_col")) * _fin_rowsum(r, m.get("den_col"))
                else:
                    v = _fin_rowsum(r, m.get("cols") or m.get("col"))
                amt_all += v
                if _fin_is_cows_metric(m):
                    amt_cows += v
            if has_pivot:
                pv = milk_excel._num(r.get(pval))
                amt_all += pv
                if _fin_row_is_cows(r, pdims):
                    amt_cows += pv
            if amt_all or amt_cows:
                out.setdefault(iso, {})
                cur = out[iso].get(it["name"]) or {"all": 0.0, "cows": 0.0}
                cur["all"] += amt_all
                cur["cows"] += amt_cows
                out[iso][it["name"]] = cur
    return out


def _finance_dataset(period: str, days: int = 0):
    """Витрати за статтями (з окремих Excel) по періодах — повний рушій молока:
    кожен показник статті = стовпець (Сума / Частка A÷B / Добуток A×B), формат
    за типом. Джерело з увімкненим «Розподіл на дні» (cfg.spread) — місячну суму
    ділить на дні місяця. Повертає (rows, total_cells, metrics, err, ncfg,
    fin_groups, has_groups)."""
    import datetime as _dt
    items = [i for i in db.list_finance_items()
             if i["kind"] == "expense" and i["is_active"]]
    series, buckets, err = [], {}, None
    ncfg = 0

    # 1-й прохід: прочитати всі джерела + знайти НАЙПІЗНІШУ дату в даних
    loaded = []  # (it, mets, piv..., rows)
    max_date = None
    for it in items:
        cfg = db.get_finance_source(it["id"])
        mets = [m for m in (cfg.get("metrics") or []) if (m.get("label") or "").strip()]
        piv = cfg.get("pivot") or {}
        pdims = [d for d in (piv.get("dims") or []) if d]
        pval = (piv.get("value_col") or "").strip()
        has_pivot = bool(pval and pdims)
        if not (cfg.get("date_col") and (mets or has_pivot)):
            continue
        ncfg += 1
        # читаємо ЗАФІКСОВАНІ рядки З БАЗИ (усі колонки, зокрема resource/category)
        rows = []
        for rr in db.get_finance_rows(it["id"]):
            ds = (rr.get("op_date") or "")[:10]
            if not ds:
                continue
            try:
                dd = _dt.date.fromisoformat(ds)
            except ValueError:
                continue
            row = dict(rr.get("cells") or {})
            row["date"] = dd
            rows.append(row)
        if cfg.get("spread"):
            value_cols = set(milk_excel.cols_used(mets))
            if has_pivot:
                value_cols.add(pval)
            value_cols = list(value_cols)
            rows = [nr for r in rows for nr in _spread_row_to_days(r, value_cols)]
        for r in rows:
            dd = r["date"].date() if hasattr(r["date"], "date") else r["date"]
            if max_date is None or dd > max_date:
                max_date = dd
        loaded.append((it, mets, piv, pdims, pval, has_pivot, rows))

    # «Останні N днів» рахуємо від останньої дати В ДАНИХ, а не від сьогодні
    cutoff = None
    if period == "day" and days and max_date:
        cutoff = max_date - _dt.timedelta(days=days - 1)

    # 2-й прохід: побудова стовпців і бакетів
    for it, mets, piv, pdims, pval, has_pivot, rows in loaded:
        if cutoff:
            rows = [r for r in rows
                    if (r["date"].date() if hasattr(r["date"], "date") else r["date"]) >= cutoff]

        # --- авто-розбивка (pivot): стовпець на кожну комбінацію значень вимірів ---
        if has_pivot:
            combos = {}  # combo_key -> combo_label
            for r in rows:
                combo_vals = [(str(r.get(d)).strip() if r.get(d) is not None else "") for d in pdims]
                ckey = "|".join(combo_vals)
                combos.setdefault(ckey, " · ".join([v for v in combo_vals if v]) or "—")
                k, lbl, srt = milk_excel.bucket(r["date"], period)
                bk = buckets.setdefault(k, {"label": lbl, "sort": srt, "vals": {}})
                skey = f"{it['id']}|piv|{ckey}"
                bk["vals"][skey] = bk["vals"].get(skey, 0.0) + milk_excel._num(r.get(pval))
            for ckey in sorted(combos):
                series.append({"key": f"{it['id']}|piv|{ckey}", "item": it["id"],
                               "label": f"{it['name']} · {combos[ckey]}",
                               "unit": piv.get("unit") or "₴",
                               "type": piv.get("type") or "money", "agg": "sum"})

        # --- показники (Сума / Частка / Добуток), з фільтрами ---
        if mets:
            try:
                agg = _fin_aggregate(rows, mets, period)
            except Exception as exc:  # noqa: BLE001
                err = str(exc)
                agg = []
            for m in mets:
                skey = f"{it['id']}:{m.get('key')}"
                label = m["label"]  # назва показника як є, без префікса статті
                series.append({"key": skey, "item": it["id"], "label": label,
                               "unit": m.get("unit") or "", "group": (m.get("group") or "").strip(),
                               "type": m.get("type") or "number", "agg": m.get("agg", "sum")})
            for b in agg:
                bk = buckets.setdefault(b["key"], {"label": b["label"], "sort": b["sort"], "vals": {}})
                for m in mets:
                    bk["vals"][f"{it['id']}:{m.get('key')}"] = b["metrics"].get(m.get("key"), 0.0)
    # згрупувати показники за «Групою стовпця» (напр. Корови/Молодняк): однакова
    # група — суміжні стовпці під спільним заголовком; порядок груп — за появою
    group_order, groups = [], {}
    for s in series:
        g = s.get("group", "")
        if g not in groups:
            groups[g] = []
            group_order.append(g)
        groups[g].append(s)
    series = [s for g in group_order for s in groups[g]]
    has_groups = any(g for g in group_order)
    fin_groups = [{"label": g, "span": len(groups[g])} for g in group_order] if has_groups else []

    metrics = [{"label": s["label"], "unit": s["unit"]} for s in series]
    ordered = sorted(buckets.values(), key=lambda b: b["sort"], reverse=True)  # новіші зверху
    totals = {s["key"]: 0.0 for s in series}
    disp = []
    for b in ordered:
        cells = []
        for s in series:
            v = b["vals"].get(s["key"], 0.0)
            if s["agg"] != "ratio":
                totals[s["key"]] += v
            cells.append(_milk_fmt(v, s["type"]))
        disp.append({"label": b["label"], "cells": cells})
    # підсумковий рядок: адитивні показники — сума; частка (A÷B) — прочерк
    total_cells = []
    if series:
        total_cells = [("—" if s["agg"] == "ratio" else _milk_fmt(totals[s["key"]], s["type"]))
                       for s in series]
    return disp, total_cells, metrics, err, ncfg, fin_groups, has_groups


@app.get("/finance")
def page_finance():
    return redirect("/finance/dairy")


@app.get("/finance/expense-items")
def page_finance_expense_items():
    period = request.args.get("period", "month")
    if period not in _MILK_PERIODS:
        period = "month"
    try:
        days = int(request.args.get("days", 30))
    except ValueError:
        days = 30
    if days not in _MILK_DAY_OPTS:
        days = 30
    try:                       # авто-фіксація Excel→БД (як молоко); далі читаємо з БД
        _finance_ingest()
    except Exception:          # noqa: BLE001
        pass
    rows, total_cells, metrics, err, ncfg, fin_groups, has_groups = \
        _finance_dataset(period, days if period == "day" else 0)
    return render_template("finance_items.html", active="finance_items",
                           period=period, periods=_MILK_PERIODS, days=days,
                           day_opts=_MILK_DAY_OPTS, fin_rows=rows,
                           fin_total=total_cells, fin_metrics=metrics,
                           fin_err=err, fin_ncfg=ncfg,
                           fin_groups=fin_groups, fin_has_groups=has_groups)


@app.get("/finance/settings")
def page_finance_settings():
    return render_template("finance_settings.html", active="finance_settings")


@app.get("/finance/dairy")
def page_finance_dairy():
    """Огляд → Звіт-1: Щоденна ефективність молочної ферми (з привʼязкою витрат за назвою)."""
    try:                       # свіжі витрати в БД, щоб привʼязка за назвою була актуальна
        _finance_ingest()
    except Exception:          # noqa: BLE001
        pass
    return render_template("finance_dairy.html", active="finance_dairy")


@app.get("/api/finance/items")
def api_finance_items_list():
    return _ok({"items": db.list_finance_items()})


@app.post("/api/finance/items")
def api_finance_items_add():
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.add_finance_item(data.get("name", ""), data.get("kind", "expense")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/finance/items/reorder")
def api_finance_items_reorder():
    data = request.get_json(silent=True) or {}
    return _ok(db.reorder_finance_items(data.get("order") or []))


@app.post("/api/finance/items/<int:item_id>")
def api_finance_items_update(item_id: int):
    data = request.get_json(silent=True) or {}
    return _ok(db.update_finance_item(item_id, data))


@app.delete("/api/finance/items/<int:item_id>")
def api_finance_items_delete(item_id: int):
    return _ok(db.delete_finance_item(item_id))


@app.get("/api/finance/source/<int:item_id>")
def api_finance_source_get(item_id: int):
    return _ok(db.get_finance_source(item_id))


@app.post("/api/finance/source/<int:item_id>")
def api_finance_source_set(item_id: int):
    data = request.get_json(silent=True) or {}
    res = db.set_finance_source(item_id, data)
    try:                       # одразу зафіксувати в БД після збереження мапінгу
        _finance_ingest()
    except Exception:          # noqa: BLE001
        pass
    return _ok(res)


@app.post("/api/finance/ingest")
def api_finance_ingest():
    """Прочитати Excel і зафіксувати витрати в базу (кнопка в Налаштуваннях)."""
    try:
        n = _finance_ingest()
    except Exception as exc:   # noqa: BLE001
        return _err(str(exc))
    return _ok({"rows": n})


@app.get("/api/finance/source/<int:item_id>/sheets")
def api_finance_source_sheets(item_id: int):
    path = (request.args.get("path") or db.get_finance_source(item_id).get("path") or "").strip()
    if not path:
        return _err("Вкажіть шлях до файлу.")
    try:
        return _ok({"sheets": milk_excel.list_sheets(path)})
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.get("/api/finance/source/<int:item_id>/columns")
def api_finance_source_columns(item_id: int):
    cfg = db.get_finance_source(item_id)
    path = (request.args.get("path") or cfg.get("path") or "").strip()
    sheet = (request.args.get("sheet") or cfg.get("sheet") or "").strip()
    header = int(request.args.get("header") or cfg.get("header_row") or 1)
    if not path:
        return _err("Вкажіть шлях до файлу.")
    try:
        if not sheet:
            sheets = milk_excel.list_sheets(path)
            sheet = sheets[0] if sheets else ""
        return _ok({"columns": milk_excel.list_columns(path, sheet, header)})
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


def _fin_rowsum(r, ref) -> float:
    """Сума значень рядка за назвою колонки або списком назв."""
    if not ref:
        return 0.0
    refs = ref if isinstance(ref, list) else [ref]
    return sum(milk_excel._num(r.get(c)) for c in refs if c)


def _fin_metric_matches(r, m) -> bool:
    """Чи проходить рядок фільтри показника (усі умови col=val, AND)."""
    for f in (m.get("filters") or []):
        col = (f.get("col") or "").strip()
        if not col:
            continue
        val = (f.get("val") or "").strip()
        cell = r.get(col)
        cell = "" if cell is None else str(cell).strip()
        if cell != val:
            return False
    return True


def _fin_filter_cols(mets) -> set:
    """Усі колонки, що згадані у фільтрах показників (щоб їх прочитати)."""
    s = set()
    for m in mets:
        for f in (m.get("filters") or []):
            c = (f.get("col") or "").strip()
            if c:
                s.add(c)
    return s


def _fin_aggregate(rows, mets, period):
    """Як milk_excel.aggregate, але з фільтрами на кожен показник."""
    buckets = {}
    for r in rows:
        d = r.get("date")
        if not d:
            continue
        key, label, sort = milk_excel.bucket(d, period)
        b = buckets.setdefault(key, {"label": label, "sort": sort, "acc": {}})
        for m in mets:
            if not _fin_metric_matches(r, m):
                continue
            a = b["acc"].setdefault(m["key"], {"sum": 0.0, "num": 0.0, "den": 0.0})
            agg = m.get("agg", "sum")
            if agg == "ratio":
                a["num"] += _fin_rowsum(r, m.get("num_cols") or m.get("num_col"))
                a["den"] += _fin_rowsum(r, m.get("den_cols") or m.get("den_col"))
            elif agg == "psum":
                a["sum"] += _fin_rowsum(r, m.get("num_col")) * _fin_rowsum(r, m.get("den_col"))
            else:
                a["sum"] += _fin_rowsum(r, m.get("cols") or m.get("col"))
    out = []
    for key, b in buckets.items():
        vals = {}
        for m in mets:
            a = b["acc"].get(m["key"], {"sum": 0.0, "num": 0.0, "den": 0.0})
            if m.get("agg") == "ratio":
                vals[m["key"]] = (a["num"] / a["den"]) if a["den"] else 0.0
            else:
                vals[m["key"]] = a["sum"]
        out.append({"key": key, "label": b["label"], "sort": b["sort"], "metrics": vals})
    out.sort(key=lambda x: x["sort"])
    return out


@app.get("/api/finance/source/<int:item_id>/values")
def api_finance_source_values(item_id: int):
    """Унікальні значення стовпця (для підказки значення у фільтрі)."""
    cfg = db.get_finance_source(item_id)
    path = (request.args.get("path") or cfg.get("path") or "").strip()
    sheet = (request.args.get("sheet") or cfg.get("sheet") or "").strip()
    header = int(request.args.get("header") or cfg.get("header_row") or 1)
    col = (request.args.get("col") or "").strip()
    if not (path and col):
        return _err("Потрібні файл і стовпець.")
    try:
        if not sheet:
            sheets = milk_excel.list_sheets(path)
            sheet = sheets[0] if sheets else ""
        return _ok({"values": milk_excel.distinct_values(path, sheet, header, col)})
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.get("/api/finance/expense/<int:item_id>")
def api_finance_expense(item_id: int):
    cfg = db.get_finance_source(item_id)
    mets = [m for m in (cfg.get("metrics") or []) if (m.get("label") or "").strip()]
    # для «Разом за файлом» беремо адитивні (Сума / Добуток); якщо є ★ Сума — лише їх
    add_mets = [m for m in mets if m.get("agg", "sum") in ("sum", "psum")]
    _flagged = [m for m in add_mets if m.get("r1")]
    if _flagged:
        add_mets = _flagged
    piv = cfg.get("pivot") or {}
    pdims = [d for d in (piv.get("dims") or []) if d]
    pval = (piv.get("value_col") or "").strip()
    has_pivot = bool(pval and pdims)
    if not (cfg.get("path") and cfg.get("date_col") and (mets or has_pivot)):
        return _ok({"months": [], "total": 0, "count": 0,
                    "note": "Джерело не налаштоване (шлях + дата + показник або розбивка)."})
    df = (request.args.get("from") or "")[:10]
    dt = (request.args.get("to") or "")[:10]
    try:
        sheet = cfg["sheet"] or (milk_excel.list_sheets(cfg["path"]) or [""])[0]
        need = set(milk_excel.cols_used(mets)) | _fin_filter_cols(mets)
        if has_pivot:
            need |= {pval} | set(pdims)
        rows = milk_excel.read_rows(cfg["path"], sheet, int(cfg["header_row"] or 1),
                                    cfg["date_col"], list(need))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))
    months: dict = {}
    total = 0.0
    n = 0
    for r in rows:
        ds = r["date"].isoformat()
        if df and ds < df:
            continue
        if dt and ds > dt:
            continue
        amt = 0.0
        for m in add_mets:
            if not _fin_metric_matches(r, m):
                continue
            if m.get("agg") == "psum":
                amt += _fin_rowsum(r, m.get("num_col")) * _fin_rowsum(r, m.get("den_col"))
            else:
                amt += _fin_rowsum(r, m.get("cols") or m.get("col"))
        if has_pivot:
            amt += milk_excel._num(r.get(pval))
        total += amt
        n += 1
        months[ds[:7]] = months.get(ds[:7], 0.0) + amt
    mon = [{"month": k, "sum": round(v, 2)} for k, v in sorted(months.items())]
    return _ok({"total": round(total, 2), "count": n, "months": mon,
                "metrics": len(mets)})


@app.get("/api/herd/events")
def api_herd_events_list():
    section_names = db.active_section_names()

    def _choices(p):
        # варіанти значень для параметра (щоб у події обирати зі списку, не вручну)
        if (p.get("options") or "") == "@sections":
            return [{"value": n, "label": n} for n in section_names]
        opts = p.get("options_list") or []
        out = []
        for o in opts:
            if isinstance(o, dict):        # cod: {c,l}
                c, l = str(o.get("c", "")), str(o.get("l", ""))
                out.append({"value": c, "label": (c if c == l or not l else f"{c} — {l}")})
            else:                          # list: рядок
                out.append({"value": str(o), "label": str(o)})
        return out

    return _ok({
        "events": db.list_event_defs(active_only=request.args.get("active") == "1"),
        # довідники для редактора ефектів
        "params": [{"key": p["key"], "label": p["label"], "dtype": p["dtype"],
                    "options": p.get("options_list") or [], "choices": _choices(p),
                    "formula": p.get("formula") or ""}
                   for p in db.list_param_defs(active_only=True)],
        "categories": db.EVENT_CATEGORIES,
        "modes": db.EVENT_MODE_LABELS,
        # найуживаніші за 30 днів — закріплені «часті» плитки на сторінці Подій
        "frequent": db.frequent_event_defs(),
    })


@app.post("/api/herd/events")
def api_herd_events_add():
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.add_event_def(data))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/events/reorder")
def api_herd_events_reorder():
    data = request.get_json(silent=True) or {}
    return _ok(db.reorder_event_defs(data.get("order") or []))


@app.post("/api/herd/events/<int:event_id>")
def api_herd_events_update(event_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.update_event_def(event_id, data, allow_standard_change=_is_admin()))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.delete("/api/herd/events/<int:event_id>")
def api_herd_events_delete(event_id: int):
    try:
        return _ok(db.delete_event_def(event_id, allow_standard=_is_admin()))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/animals/<int:animal_id>/apply-event")
def api_herd_apply_event(animal_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.apply_event(
            animal_id, event_key=data.get("event_key", ""),
            event_id=int(data.get("event_id") or 0),
            event_date=data.get("event_date", ""),
            inputs=data.get("inputs") or {}, note=data.get("note", ""),
            user_id=session.get("user_id"), calves=data.get("calves") or []))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/apply-event-bulk")
def api_herd_apply_event_bulk():
    data = request.get_json(silent=True) or {}
    ids = data.get("animal_ids")
    if not ids and data.get("group_id"):
        ids = db.animals_in_section(int(data["group_id"]))
    try:
        return _ok(db.apply_event_bulk(
            ids or [], event_id=int(data.get("event_id") or 0),
            event_key=data.get("event_key", ""), event_date=data.get("event_date", ""),
            inputs=data.get("inputs") or {}, note=data.get("note", ""),
            user_id=session.get("user_id")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


@app.post("/api/herd/animals/<int:animal_id>/params")
def api_herd_animal_param_set(animal_id: int):
    data = request.get_json(silent=True) or {}
    try:
        return _ok(db.set_animal_param(animal_id, data.get("key", ""), data.get("value", "")))
    except Exception as exc:  # noqa: BLE001
        return _err(str(exc))


def _plan_year_month():
    """Рік/місяць плану з query (?year=&month=); порожнє → None (поточний)."""
    def _i(name):
        try:
            return int(request.args.get(name) or 0) or None
        except (TypeError, ValueError):
            return None
    return _i("year"), _i("month")


@app.get("/api/scheme-forecast")
def api_scheme_forecast():
    """Поблочна потреба за схемами + підсумок до замовлення (поточна гілка).
    ?year=&month= — місяць, на який формувати план (поголів'я зі стада)."""
    y, m = _plan_year_month()
    return _ok(db.scheme_forecast(_inv_category(), year=y, month=m))


@app.get("/api/products/<int:product_id>/batches")
def api_product_batches(product_id: int):
    """Партії товару — для розкривного вмісту в складі."""
    return _ok({"items": db.product_batches_detail(product_id)})


@app.post("/api/batches/<int:batch_id>/expiry")
def api_batch_expiry(batch_id: int):
    """Змінити термін придатності партії."""
    data = request.get_json(silent=True) or {}
    try:
        result = db.set_batch_expiry(batch_id, data.get("expires_on"))
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


# --- Постачальники ---

@app.get("/api/suppliers")
def api_suppliers_list():
    return _ok({"items": db.list_suppliers(category=_inv_category())})


@app.post("/api/suppliers")
def api_suppliers_create():
    data = request.get_json(silent=True) or {}
    try:
        sid = db.add_supplier(
            name=data.get("name", ""),
            notes=data.get("notes", ""),
            category=_inv_category(),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": sid})


@app.delete("/api/suppliers/<int:supplier_id>")
def api_suppliers_delete(supplier_id: int):
    db.delete_supplier(supplier_id)
    return _ok()


# --- Блоки (куди видано) ---

@app.get("/api/blocks")
def api_blocks_list():
    return _ok({"items": db.list_blocks(category=_inv_category())})


@app.post("/api/blocks")
def api_blocks_create():
    data = request.get_json(silent=True) or {}
    try:
        bid = db.add_block(name=data.get("name", ""), notes=data.get("notes", ""),
                           category=_inv_category(),
                           herd_kind=(data.get("herd_kind") or "").strip(),
                           subgroup=(data.get("subgroup") or "").strip())
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": bid})


@app.post("/api/blocks/<int:block_id>/kind")
def api_blocks_set_kind(block_id: int):
    """Розподіл блоку на корів/молодняк: herd_kind = cow | young | ''."""
    data = request.get_json(silent=True) or {}
    try:
        db.set_block_kind(block_id, (data.get("herd_kind") or "").strip())
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


@app.post("/api/blocks/<int:block_id>/subgroup")
def api_blocks_set_subgroup(block_id: int):
    """Призначити блоку підгрупу (2-й рівень: Дійні / Сухостій / Телята…)."""
    data = request.get_json(silent=True) or {}
    db.set_block_subgroup(block_id, (data.get("subgroup") or "").strip())
    return _ok()


@app.post("/api/blocks/<int:block_id>/herd-group")
def api_blocks_set_herd_group(block_id: int):
    """Привʼязати секцію-блок до групи стада (звідки брати поголівʼя)."""
    data = request.get_json(silent=True) or {}
    db.set_block_herd_group(block_id, data.get("herd_group_id"))
    return _ok()


@app.get("/api/herd/groups")
def api_herd_groups_list():
    """Список груп стада (для привʼязки секцій до поголівʼя)."""
    return _ok({"items": db.list_herd_groups()})


@app.delete("/api/blocks/<int:block_id>")
def api_blocks_delete(block_id: int):
    db.delete_block(block_id)
    return _ok()


# --- Отримувачі (кому видано) ---

@app.get("/api/recipients")
def api_recipients_list():
    return _ok({"items": db.list_recipients(category=_inv_category())})


@app.post("/api/recipients")
def api_recipients_create():
    data = request.get_json(silent=True) or {}
    try:
        rid = db.add_recipient(name=data.get("name", ""), notes=data.get("notes", ""),
                               category=_inv_category())
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": rid})


@app.delete("/api/recipients/<int:recipient_id>")
def api_recipients_delete(recipient_id: int):
    db.delete_recipient(recipient_id)
    return _ok()


@app.post("/api/receive")
def api_receive():
    data = request.get_json(silent=True) or {}

    def _flt(key: str, default: float = 0) -> float:
        v = data.get(key)
        if v is None or v == "":
            return default
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    try:
        result = db.receive_stock(
            barcode=data.get("barcode", ""),
            qty=_flt("qty"),
            lot_number=data.get("lot_number", ""),
            expires_on=data.get("expires_on") or None,
            price_in_no_vat=_flt("price_in_no_vat"),
            price_in=_flt("price_in"),
            vat_rate=_flt("vat_rate", 20),
            markup_pct=_flt("markup_pct"),
            price_out=_flt("price_out"),
            invoice_number=data.get("invoice_number", ""),
            invoice_date=data.get("invoice_date", ""),
            receipt_date=data.get("receipt_date", ""),
            supplier_name=data.get("supplier_name", ""),
            note=data.get("note", ""),
            user_id=session.get("user_id"),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.post("/api/receive/bulk")
def api_receive_bulk():
    """Зарахувати цілу накладну: спільна шапка + кілька позицій."""
    data = request.get_json(silent=True) or {}
    items = data.get("items", [])
    if not items:
        return _err("Накладна порожня — додайте позиції.")

    supplier_name = data.get("supplier_name", "")
    invoice_number = data.get("invoice_number", "")
    invoice_date = data.get("invoice_date", "")
    receipt_date = data.get("receipt_date", "")
    uid = session.get("user_id")

    def _flt(d, key, default=0.0):
        v = d.get(key)
        if v in (None, ""):
            return default
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    added = 0
    total = 0.0
    errors = []
    for i, it in enumerate(items, start=1):
        try:
            res = db.receive_stock(
                barcode=it.get("barcode", ""),
                qty=_flt(it, "qty"),
                lot_number=it.get("lot_number", ""),
                expires_on=it.get("expires_on") or None,
                price_in_no_vat=_flt(it, "price_in_no_vat"),
                price_in=_flt(it, "price_in"),
                vat_rate=_flt(it, "vat_rate", 20),
                markup_pct=0,
                price_out=0,
                invoice_number=invoice_number,
                invoice_date=invoice_date,
                receipt_date=receipt_date,
                supplier_name=supplier_name,
                note=it.get("note", ""),
                user_id=uid,
            )
            added += 1
            total += _flt(it, "qty") * _flt(it, "price_in")
        except ValueError as exc:
            errors.append(f"позиція {i}: {exc}")
    return _ok({"added": added, "total": round(total, 2), "errors": errors})


# --- Редагування / видалення приходу (за batch_id) ---

@app.get("/api/receipts/<int:batch_id>")
def api_receipt_get(batch_id: int):
    receipt = db.get_receipt(batch_id)
    if not receipt:
        return _err("Прихід не знайдено", 404)
    return _ok({"receipt": receipt})


@app.put("/api/receipts/<int:batch_id>")
def api_receipt_update(batch_id: int):
    receipt = db.get_receipt(batch_id)
    if not receipt:
        return _err("Прихід не знайдено", 404)
    if not _can_modify(receipt.get("user_id")):
        return _err("Цей прихід додав інший користувач — редагувати може лише він або адміністратор.", 403)
    data = request.get_json(silent=True) or {}

    def _flt(key: str, default: float = 0) -> float:
        v = data.get(key)
        if v is None or v == "":
            return default
        try:
            return float(v)
        except (TypeError, ValueError):
            return default

    try:
        result = db.update_receipt(
            batch_id,
            qty=_flt("qty"),
            lot_number=data.get("lot_number", ""),
            expires_on=data.get("expires_on") or None,
            price_in_no_vat=_flt("price_in_no_vat"),
            price_in=_flt("price_in"),
            vat_rate=_flt("vat_rate", 20),
            markup_pct=_flt("markup_pct"),
            price_out=_flt("price_out"),
            invoice_number=data.get("invoice_number", ""),
            invoice_date=data.get("invoice_date", ""),
            receipt_date=data.get("receipt_date", ""),
            supplier_name=data.get("supplier_name", ""),
            note=data.get("note", ""),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.delete("/api/receipts/<int:batch_id>")
def api_receipt_delete(batch_id: int):
    receipt = db.get_receipt(batch_id)
    if not receipt:
        return _err("Прихід не знайдено", 404)
    if not _can_modify(receipt.get("user_id")):
        return _err("Цей прихід додав інший користувач — видалити може лише він або адміністратор.", 403)
    try:
        db.delete_receipt(batch_id)
    except ValueError as exc:
        return _err(str(exc))
    db.log_audit(
        "DELETE", session.get("user_id"),
        category=receipt.get("category", ""),
        summary=f"Прихід: {receipt.get('product_name', '')}",
        detail=(f"К-сть {receipt.get('received_qty', '')}, накладна "
                f"{receipt.get('invoice_number', '') or '—'}"),
    )
    return _ok()


@app.post("/api/sale")
def api_sale():
    data = request.get_json(silent=True) or {}
    try:
        result = db.dispense_stock(
            barcode=data.get("barcode", ""),
            qty=float(data.get("qty") or 0),
            note=data.get("note", ""),
            move_type=data.get("move_type", "OUT"),
            user_id=session.get("user_id"),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.post("/api/sale/bulk")
def api_sale_bulk():
    """Проведення цілої операції видачі/списання (кілька позицій)."""
    data = request.get_json(silent=True) or {}

    def _int_or_none(key):
        v = data.get(key)
        try:
            return int(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None

    try:
        result = db.process_sale(
            items=data.get("items", []),
            move_type=data.get("move_type", "OUT"),
            note=data.get("note", ""),
            cash_given=0,
            user_id=session.get("user_id"),
            block_id=_int_or_none("block_id"),
            recipient_id=_int_or_none("recipient_id"),
            op_date=(data.get("date") or "").strip(),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.get("/api/sales/<sale_no>/returnable")
def api_sale_returnable(sale_no: str):
    """Дані оригінального чека продажу для форми повернення:
    позиції з полями original_qty / returned_qty / available_qty."""
    sale = db.get_sale_returnable(sale_no)
    if not sale:
        return _err("Чек продажу не знайдено", 404)
    return _ok({"sale": sale})


@app.post("/api/return")
def api_return():
    """Повернення товару від клієнта, привʼязане до оригінального чека.
    Очікує: original_sale_no, items=[{product_id, batch_id, qty, price}]."""
    data = request.get_json(silent=True) or {}
    try:
        result = db.process_return(
            original_sale_no=data.get("original_sale_no", ""),
            items=data.get("items", []),
            note=data.get("note", ""),
            cash_given=float(data.get("cash_given") or 0),
            user_id=session.get("user_id"),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.get("/api/sales/recent")
def api_sales_recent():
    date_from = request.args.get("from", "")
    date_to = request.args.get("to", "")
    # за замовчуванням 25; коли заданий період — показуємо все вікно
    default_limit = 500 if (date_from or date_to) else 25
    limit = int(request.args.get("limit", default_limit))
    items = db.recent_sales(limit, category=_inv_category(),
                            date_from=date_from, date_to=date_to)
    # Авторитетне рішення про права — на бекенді. JS просто читає can_edit.
    for it in items:
        it["can_edit"] = _can_modify(it.get("user_id"))
    return _ok({"items": items})


@app.get("/api/sales/search")
def api_sales_search():
    """Пошук операцій. Два незалежних поля:
    - sale_no: номер чека (точний збіг; префікс «ВП-» прибирається автоматично).
    - q: підстрока штрихкоду / назви / коду товару.
    Якщо обидва задані — результат «АБО»."""
    sale_no = request.args.get("sale_no", "").strip()
    q = request.args.get("q", "").strip()
    # Прибираємо префікс наших операцій — у БД зберігається тільки число
    if sale_no[:3] in ("ВВ-", "ВП-", "ПВ-", "ВС-"):
        sale_no = sale_no[3:].strip()
    if not sale_no and not q:
        return _ok({"items": []})
    items = db.search_sales(sale_no=sale_no, query=q, limit=200, category=_inv_category())
    for it in items:
        it["can_edit"] = _can_modify(it.get("user_id"))
    return _ok({"items": items})


@app.delete("/api/sales/<sale_no>")
def api_sale_undo(sale_no: str):
    sale = db.get_sale(sale_no)
    if not sale:
        return _err("Операцію не знайдено", 404)
    if not _can_modify(sale.get("user_id")):
        return _err("Цю операцію провів інший користувач — скасувати може лише він або адміністратор.", 403)
    try:
        result = db.undo_sale(sale_no)
    except ValueError as exc:
        return _err(str(exc))
    _kind = {"OUT": "видачі", "WRITE_OFF": "списання",
             "RETURN": "повернення"}.get(sale.get("move_type"), "операції")
    _names = ", ".join(i.get("name", "") for i in (sale.get("items") or [])[:3])
    db.log_audit(
        "DELETE", session.get("user_id"),
        summary=f"Скасування {_kind} №{sale_no}",
        detail=(_names or "—") + (f" · {sale.get('qty')} од." if sale.get("qty") else ""),
    )
    return _ok(result)


@app.get("/api/sales/<sale_no>/edit")
def api_sale_edit_get(sale_no: str):
    data = db.get_sale_edit(sale_no)
    if not data:
        return _err("Операцію не знайдено", 404)
    return _ok({"sale": data})


@app.post("/api/sales/<sale_no>/edit")
def api_sale_edit_set(sale_no: str):
    data = db.get_sale_edit(sale_no)
    if not data:
        return _err("Операцію не знайдено", 404)
    if not _can_modify(data.get("user_id")):
        return _err("Цю операцію провів інший користувач — редагувати може лише він або адміністратор.", 403)
    body = request.get_json(silent=True) or {}
    try:
        db.update_sale_destinations(sale_no, body.get("positions", []),
                                    body.get("note"),
                                    op_date=(body.get("date") or "").strip())
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


@app.post("/api/adjust")
def api_adjust():
    """Корекція залишків (+/-) з обовʼязковою причиною."""
    data = request.get_json(silent=True) or {}
    try:
        result = db.adjust_stock(
            barcode=data.get("barcode", ""),
            delta=float(data.get("delta") or 0),
            reason=data.get("reason", ""),
            user_id=session.get("user_id"),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.post("/api/batches/<int:batch_id>/adjust")
def api_batch_adjust(batch_id: int):
    """Коригування конкретної партії (інвентаризація / бій / тощо).
    Ціна та сума беруться з price_in цієї партії."""
    data = request.get_json(silent=True) or {}
    try:
        result = db.adjust_batch(
            batch_id,
            delta=float(data.get("delta") or 0),
            reason_type=data.get("reason_type", ""),
            note=data.get("note", ""),
            user_id=session.get("user_id"),
        )
    except ValueError as exc:
        return _err(str(exc))
    return _ok(result)


@app.get("/api/stock/as-of")
def api_stock_as_of():
    """Залишки на складі станом на конкретну дату (для друку)."""
    d = request.args.get("date", "")
    return _ok({"date": d, "items": db.stock_as_of(d, category=_inv_category())})


@app.get("/api/stock/movement")
def api_stock_movement():
    """Звіт руху за період."""
    f = request.args.get("from", "")
    t = request.args.get("to", "")
    return _ok({"from": f, "to": t,
                "items": db.stock_movement_report(f, t, category=_inv_category())})


@app.get("/api/reports/issue-by-block")
def api_issue_by_block():
    """Видача/списання за період, згруповані по блоках/отримувачах."""
    f = request.args.get("from", "")
    t = request.args.get("to", "")
    return _ok({"from": f, "to": t,
                "items": db.issue_by_block(f, t, category=_inv_category())})


@app.get("/api/expiring")
def api_expiring():
    days = int(request.args.get("days", 60))
    return _ok({"items": db.expiring_batches(days, category=_inv_category())})


@app.get("/api/expiring/count")
def api_expiring_count():
    """Кількість партій з терміном придатності, що спливає у найближчі N днів
    (за замовчуванням 30) — для бейджа в меню."""
    days = int(request.args.get("days", 30))
    return _ok({"count": len(db.expiring_batches(days, category=_inv_category()))})


@app.delete("/api/moves/<int:move_id>/adjustment")
def api_undo_adjustment(move_id: int):
    """Скасування коригувальної операції (інвентаризація / бій / …).
    Перевірка прав: лише власник або адмін."""
    owner = db.get_move_user_id(move_id)
    if not _can_modify(owner):
        return _err("Цю операцію провів інший користувач — скасувати може "
                    "лише він або адміністратор.", 403)
    brief = db.get_move_brief(move_id)
    try:
        result = db.undo_adjustment_move(move_id)
    except ValueError as exc:
        return _err(str(exc))
    if brief:
        db.log_audit(
            "DELETE", session.get("user_id"),
            category=brief.get("category", ""),
            summary=f"Скасування коригування: {brief.get('name', '')}",
            detail=brief.get("note", "") or "",
        )
    return _ok(result)


@app.get("/api/moves")
def api_moves():
    date_from = request.args.get("from", "")
    date_to = request.args.get("to", "")
    move_type = request.args.get("type", "")
    reason = request.args.get("reason", "")
    items = db.all_moves_filtered(date_from, date_to, move_type, reason=reason,
                                  category=_inv_category())
    # Авторитетне рішення про права + позначка чи це коригувальна операція
    for it in items:
        it["can_edit"] = _can_modify(it.get("user_id"))
        it["is_adjustment"] = db.is_adjustment_note(it.get("note", ""))
    return _ok({"items": items})


@app.get("/api/audit")
def api_audit():
    """Журнал дій користувачів: операції зі складу + видалення."""
    def _int(name):
        v = request.args.get(name, "")
        try:
            return int(v) if v else None
        except ValueError:
            return None
    res = db.audit_trail(
        date_from=request.args.get("from", ""),
        date_to=request.args.get("to", ""),
        user_id=_int("user"),
        branch=request.args.get("branch", ""),
        op_type=request.args.get("type", ""),
        search=request.args.get("q", ""),
    )
    return _ok(res)


@app.get("/api/audit/filters")
def api_audit_filters():
    """Списки для фільтрів журналу: користувачі та гілки."""
    users = [{"id": u["id"], "username": u["username"]} for u in db.list_users()]
    branches = [{"code": "pharmacy", "label": "Аптека"},
                {"code": "materials", "label": "Матеріали"}]
    return _ok({"users": users, "branches": branches})


@app.get("/api/receipts/invoices")
def api_receipt_invoices():
    """Надходження, згруповані за накладними (для «Останніх надходжень»)."""
    invoices = db.list_receipt_invoices(
        category=_inv_category(),
        date_from=request.args.get("from", ""),
        date_to=request.args.get("to", ""),
    )
    for inv in invoices:
        for it in inv["items"]:
            it["can_edit"] = _can_modify(it.get("user_id"))
    return _ok({"items": invoices})


@app.post("/api/receipts/reorder")
def api_receipt_reorder():
    """Зберегти новий порядок позицій накладної (перетягуванням)."""
    data = request.get_json(silent=True) or {}
    db.set_batch_order(data.get("batch_ids", []))
    return _ok()


@app.post("/api/receipts/invoice-header")
def api_receipt_invoice_header():
    """Скоригувати шапку накладної для всіх її позицій."""
    d = request.get_json(silent=True) or {}
    ids = d.get("batch_ids") or []
    # дозволяємо, якщо користувач може змінювати всі позиції накладної
    for bid in ids:
        rec = db.get_receipt(bid)
        if rec and not _can_modify(rec.get("user_id")):
            return _err("Деякі позиції додав інший користувач — редагувати може він або адміністратор.", 403)
    try:
        res = db.update_invoice_header(
            ids, supplier_name=d.get("supplier", ""),
            invoice_number=d.get("invoice_number", ""),
            invoice_date=d.get("invoice_date", ""),
            receipt_date=d.get("receipt_date", ""))
    except ValueError as exc:
        return _err(str(exc))
    db.log_audit("EDIT", session.get("user_id"), category=_inv_category(),
                 summary=f"Шапка накладної {res.get('invoice_number', '')}",
                 detail=f"Оновлено позицій: {res.get('updated', 0)}")
    return _ok(res)


def _csv_num(v):
    """Число для CSV (локаль Power BI): десятковий роздільник — кома.
    None/порожнє → ''. Цілі — без дробової частини; зайві нулі прибираються."""
    if v is None or v == "":
        return ""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v).replace(".", ",")
    if f == int(f):
        return str(int(f))
    return ("%.4f" % f).rstrip("0").rstrip(".").replace(".", ",")


@app.get("/api/export/moves.csv")
def api_export_moves():
    date_from = request.args.get("from", "")
    date_to = request.args.get("to", "")
    move_type = request.args.get("type", "")
    items = db.all_moves_filtered(date_from, date_to, move_type, category=_inv_category())
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(["Дата", "Товар", "Штрихкод", "Тип", "К-сть",
                     "Ціна", "Сума", "Примітка"])
    type_label = {"IN": "Прихід", "OUT": "Видача", "WRITE_OFF": "Списання"}
    for row in items:
        writer.writerow([
            row["created_at"],
            row["name"],
            row["barcode"],
            type_label.get(row["move_type"], row["move_type"]),
            _csv_num(row["qty"]),
            _csv_num(row.get("price") or 0),
            _csv_num(row.get("total") or 0),
            row.get("note") or "",
        ])
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(
        BytesIO(data),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"workcenter_moves_{date.today().isoformat()}.csv",
    )


@app.get("/api/export/order.csv")
def api_export_order():
    """Список замовлення (рекомендовані кількості) для постачальника — зі схем.
    Лише позиції з order_qty > 0. Формат як решта вигрузок: ';', кома в числах.
    ?year=&month= — місяць, на який формувати план."""
    y, m = _plan_year_month()
    f = db.scheme_forecast(_inv_category(), year=y, month=m)
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(["Медикамент", "Одиниця", "Потреба", "Залишок", "До замовлення"])
    for it in f.get("order", []):
        if (it.get("order_qty") or 0) <= 0:
            continue
        writer.writerow([
            it.get("name") or "",
            it.get("unit") or "",
            _csv_num(it.get("need") or 0),
            _csv_num(it.get("stock") or 0),
            _csv_num(it.get("order_qty") or 0),
        ])
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(
        BytesIO(data),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"zamovlennya_{date.today().isoformat()}.csv",
    )


@app.get("/api/export/products.csv")
def api_export_products():
    """Повний експорт складу — рядок на кожну партію кожного товару."""
    rows = db.export_full(category=_inv_category())
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow([
        "Товар", "Код товару", "Штрихкод", "Одиниця",
        "Термін придатності", "Отримано", "Залишок партії",
        "Ставка ПДВ, %",
        "Ціна закупки без ПДВ", "Ціна закупки з ПДВ",
        "Сума партії без ПДВ", "Сума партії з ПДВ",
        "Постачальник", "Накладна", "Дата приходу",
        "Загальний залишок товару",
        "Мін. залишок", "Примітки",
    ])

    def g(v):
        return "" if v is None else v

    for r in rows:
        batch_qty = r.get("batch_qty")
        price_in = r.get("price_in")
        price_in_no_vat = r.get("price_in_no_vat")
        vat_rate = r.get("vat_rate")
        # для старих партій, де ціну без ПДВ не зберігали, — обчислюємо за ставкою
        if not price_in_no_vat and price_in:
            rate = vat_rate if vat_rate not in (None, "") else 20
            price_in_no_vat = round(price_in / (1 + rate / 100), 4) if rate > 0 else price_in
        sum_no_vat = ""
        sum_with_vat = ""
        if batch_qty is not None and price_in_no_vat is not None:
            sum_no_vat = round(batch_qty * price_in_no_vat, 2)
        if batch_qty is not None and price_in is not None:
            sum_with_vat = round(batch_qty * price_in, 2)
        writer.writerow([
            g(r["name"]), g(r.get("code")), g(r["barcode"]), g(r["unit"]),
            g(r.get("expires_on")),
            _csv_num(r.get("received_qty")), _csv_num(batch_qty),
            _csv_num(vat_rate),
            _csv_num(price_in_no_vat), _csv_num(price_in),
            _csv_num(sum_no_vat), _csv_num(sum_with_vat),
            g(r.get("supplier")), g(r.get("invoice_number")), g(r.get("receipt_date")),
            _csv_num(r.get("total_qty")),
            _csv_num(r.get("min_stock")), g(r.get("notes")),
        ])
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(
        BytesIO(data),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"workcenter_sklad_{date.today().isoformat()}.csv",
    )


@app.get("/api/export/suppliers.csv")
def api_export_suppliers():
    rows = db.list_suppliers(category=_inv_category())
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(["Назва", "Примітки", "Створено"])
    for s in rows:
        writer.writerow([s.get("name") or "",
                         s.get("notes") or "",
                         s.get("created_at") or ""])
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(
        BytesIO(data), mimetype="text/csv", as_attachment=True,
        download_name=f"vet_postachalnyky_{date.today().isoformat()}.csv",
    )


@app.get("/api/export/inventory.xlsx")
def api_export_inventory():
    """Інвентаризаційний акт у форматі XLSX. Колонки: №, Код, Штрихкод,
    Назва, Од., Залишок системний, Факт (порожньо для заповнення),
    Розбіжність (=Факт-Системний), Ціна закупки сер., Сума розбіжності."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    except ImportError:
        return _err("Бібліотека openpyxl не встановлена. Запустіть: "
                    "pip install openpyxl", 500)

    products = db.list_products(category=_inv_category())
    biz = load_business()

    wb = Workbook()
    # Нейтральні властивості документа — щоб у файлі не зʼявлялося чуже ПІБ
    # (Excel інакше підставляє автора з облікового запису Office на ПК).
    _doc_author = biz.get("name") or biz.get("entity") or "Облік ферми"
    wb.properties.creator = _doc_author
    wb.properties.lastModifiedBy = _doc_author
    wb.properties.title = "Інвентаризаційний акт"
    ws = wb.active
    ws.title = "Інвентаризація"

    # Шапка
    title_font = Font(bold=True, size=14)
    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    border = Border(left=Side(style="thin", color="CCCCCC"),
                    right=Side(style="thin", color="CCCCCC"),
                    top=Side(style="thin", color="CCCCCC"),
                    bottom=Side(style="thin", color="CCCCCC"))
    center = Alignment(horizontal="center", vertical="center")

    ws["A1"] = "Інвентаризаційний акт"
    ws["A1"].font = title_font
    ws.merge_cells("A1:I1")
    ws["A1"].alignment = center

    ws["A2"] = biz.get("entity") or biz.get("name") or ""
    ws.merge_cells("A2:I2")
    ws["A2"].alignment = center
    ws["A3"] = f"Дата: {date.today().strftime('%d.%m.%Y')}"
    ws.merge_cells("A3:I3")

    headers = ["№", "Код", "Назва", "Од.",
               "Залишок системний", "Факт", "Розбіжність",
               "Ціна закупки, ₴", "Сума розбіжності, ₴"]
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=5, column=col, value=h)
        cell.font = head_font
        cell.fill = head_fill
        cell.alignment = center
        cell.border = border

    for i, p in enumerate(products, start=1):
        row = 5 + i
        avg_price = p.get("avg_price_in") or 0
        ws.cell(row=row, column=1, value=i)
        ws.cell(row=row, column=2, value=p.get("code") or "")
        ws.cell(row=row, column=3, value=p.get("name") or "")
        ws.cell(row=row, column=4, value=p.get("unit") or "")
        ws.cell(row=row, column=5, value=float(p.get("total_qty") or 0))
        # «Факт» — порожньо, для ручного заповнення
        ws.cell(row=row, column=6, value=None)
        # Розбіжність = Факт – Системний (формула)
        ws.cell(row=row, column=7, value=f"=F{row}-E{row}")
        ws.cell(row=row, column=8, value=float(avg_price))
        ws.cell(row=row, column=9, value=f"=G{row}*H{row}")
        for c in range(1, 10):
            ws.cell(row=row, column=c).border = border

    # Підсумок
    total_row = 5 + len(products) + 1
    ws.cell(row=total_row, column=3, value="Разом сума розбіжності:")
    ws.cell(row=total_row, column=3).font = Font(bold=True)
    ws.cell(row=total_row, column=3).alignment = Alignment(horizontal="right")
    ws.cell(row=total_row, column=9,
            value=f"=SUM(I6:I{total_row - 1})")
    ws.cell(row=total_row, column=9).font = Font(bold=True)

    # Підписи знизу
    sign_row = total_row + 3
    ws.cell(row=sign_row, column=1,
            value="Підпис відповідального: ______________________")
    ws.merge_cells(start_row=sign_row, start_column=1,
                   end_row=sign_row, end_column=9)
    ws.cell(row=sign_row + 1, column=1,
            value="Дата: ____________  ПІБ: ______________________")
    ws.merge_cells(start_row=sign_row + 1, start_column=1,
                   end_row=sign_row + 1, end_column=9)

    # Ширини колонок
    widths = [5, 10, 36, 7, 14, 10, 14, 14, 18]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[chr(64 + i)].width = w

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    _tag = {"materials": "materialy", "feed": "kormy"}.get(_inv_category(), "apteka")
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"inventaryzatsiya_{_tag}_{date.today().isoformat()}.xlsx",
    )


def _xlsx_period_args():
    """from/to з запиту з дефолтом (початок місяця … сьогодні)."""
    f = (request.args.get("from") or "").strip()
    t = (request.args.get("to") or "").strip()
    today = date.today()
    if not f:
        f = today.replace(day=1).isoformat()
    if not t:
        t = today.isoformat()
    return f, t


def _dm(iso):
    p = str(iso or "").split("-")
    return f"{p[2]}.{p[1]}.{p[0]}" if len(p) == 3 else str(iso)


@app.get("/api/export/movement.xlsx")
def api_export_movement_xlsx():
    """Звіт руху за період у XLSX (як друкована форма: залишок поч., надходження,
    видача+списання, залишок кін. — к-сть і сума з ПДВ по кожній позиції)."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    except ImportError:
        return _err("Бібліотека openpyxl не встановлена. Запустіть: pip install openpyxl", 500)
    f, t = _xlsx_period_args()
    cat = _inv_category()
    items = db.stock_movement_report(f, t, category=cat)
    biz = load_business()
    author = biz.get("name") or biz.get("entity") or "Облік ферми"

    wb = Workbook()
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author
    wb.properties.title = "Звіт руху"
    ws = wb.active
    ws.title = "Рух"

    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    right = Alignment(horizontal="right")
    bold = Font(bold=True)

    ws["A1"] = "Звіт руху за період"
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells("A1:K1")
    ws["A1"].alignment = Alignment(horizontal="center")
    ws["A2"] = f"{biz.get('entity') or biz.get('name') or ''} · Період: {_dm(f)} – {_dm(t)}"
    ws.merge_cells("A2:K2")
    ws["A2"].alignment = Alignment(horizontal="center")

    # Дворядкова шапка
    ws.merge_cells("A4:A5"); ws["A4"] = "№"
    ws.merge_cells("B4:B5"); ws["B4"] = "Назва"
    ws.merge_cells("C4:C5"); ws["C4"] = "Од."
    groups = [("D4:E4", f"Залишок на {_dm(f)}"), ("F4:G4", "Надходження"),
              ("H4:I4", "Видача + списання"), ("J4:K4", f"Залишок на {_dm(t)}")]
    for rng, label in groups:
        ws.merge_cells(rng)
        ws[rng.split(":")[0]] = label
    subs = ["К-сть", "Сума з ПДВ"] * 4
    for i, s in enumerate(subs):
        ws.cell(row=5, column=4 + i, value=s)
    for col in range(1, 12):
        for rw in (4, 5):
            c = ws.cell(row=rw, column=col)
            c.font = head_font
            c.fill = head_fill
            c.alignment = center
            c.border = border

    tot = [0.0] * 8
    r0 = 6
    for i, p in enumerate(items):
        row = r0 + i
        vals = [float(p.get("open_qty") or 0), float(p.get("open_val") or 0),
                float(p.get("in_qty") or 0), float(p.get("in_val") or 0),
                float(p.get("out_qty") or 0), float(p.get("out_val") or 0),
                float(p.get("close_qty") or 0), float(p.get("close_val") or 0)]
        for k in range(8):
            tot[k] += vals[k]
        ws.cell(row=row, column=1, value=i + 1)
        ws.cell(row=row, column=2, value=p.get("name") or "")
        ws.cell(row=row, column=3, value=p.get("unit") or "")
        for k in range(8):
            ws.cell(row=row, column=4 + k, value=round(vals[k], 2))
        for c in range(1, 12):
            ws.cell(row=row, column=c).border = border

    trow = r0 + len(items)
    ws.cell(row=trow, column=1, value="Разом").font = bold
    ws.merge_cells(start_row=trow, start_column=1, end_row=trow, end_column=3)
    ws.cell(row=trow, column=1).alignment = right
    for k in range(8):
        c = ws.cell(row=trow, column=4 + k, value=round(tot[k], 2))
        c.font = bold
        c.border = border

    for col, w in enumerate([5, 34, 6, 9, 12, 9, 12, 9, 12, 9, 12], start=1):
        ws.column_dimensions[chr(64 + col)].width = w

    buf = BytesIO(); wb.save(buf); buf.seek(0)
    tag = {"pharmacy": "apteka", "feed": "kormy"}.get(cat, "materialy")
    return send_file(
        buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True, download_name=f"rukh_{tag}_{f}_{t}.xlsx")


def _feed_usage_xlsx(f, t, biz):
    """Стандартизований розхід кормів за період — ФАКТ ЗАВАНТАЖЕННЯ (кг, що
    пішли зі складу) + сума ₴. Три аркуші з одного джерела (аналітика Profeed),
    тож підсумки збігаються:
      • «Розхід по групах»     — Група (секція) → Корми;
      • «Розхід по категоріях» — Категорія → Підкатегорія → Корми;
      • «Розхід по кормах»     — кожен корм усього.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

    tree = db.feeding_tree("feed", f, t)
    uc = db.feed_usage_by_category("feed", f, t)
    ui = db.feed_usage_by_ingredient("feed", f, t)
    author = biz.get("name") or biz.get("entity") or "Облік ферми"

    wb = Workbook()
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author
    wb.properties.title = "Розхід кормів"

    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    grp_fill = PatternFill("solid", fgColor="E7EEFC")
    center = Alignment(horizontal="center", vertical="center")
    right = Alignment(horizontal="right")
    bold = Font(bold=True)

    def head(ws, title, cols, wide):
        ws["A1"] = title
        ws["A1"].font = Font(bold=True, size=14)
        last = chr(64 + len(cols))
        ws.merge_cells(f"A1:{last}1"); ws["A1"].alignment = Alignment(horizontal="center")
        ws["A2"] = f"Період: {_dm(f)} – {_dm(t)} · Факт завантаження зі складу"
        ws.merge_cells(f"A2:{last}2"); ws["A2"].alignment = Alignment(horizontal="center")
        for col, h in enumerate(cols, start=1):
            c = ws.cell(row=4, column=col, value=h)
            c.font = head_font; c.fill = head_fill; c.alignment = center; c.border = border
        for col, w in zip("ABCDE", wide):
            ws.column_dimensions[col].width = w

    COLS = ["Група / Категорія / Корм", "Факт завантаження, кг", "Сума ₴ без ПДВ"]
    sub_fill = PatternFill("solid", fgColor="F1F5FB")

    def agg_ings(days):
        """Звести корми по днях у список {name, kg, sum} (за спаданням кг)."""
        acc = {}
        for d in days or []:
            for it in d.get("ingredients", []) or []:
                nm = it.get("name") or ""
                a = acc.setdefault(nm, {"name": nm, "kg": 0.0, "sum": 0.0})
                a["kg"] += float(it.get("kg") or 0)
                a["sum"] += float(it.get("sum") or 0)
        return sorted(acc.values(), key=lambda x: -x["kg"])

    def hrow(ws, r, label, kg, sm, fill):
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=2, value=round(kg, 1))
        ws.cell(row=r, column=3, value=round(sm, 2))
        for c in range(1, 4):
            cc = ws.cell(row=r, column=c); cc.font = bold; cc.fill = fill; cc.border = border

    def frow(ws, r, name, kg, sm, indent):
        ws.cell(row=r, column=1, value=" " * indent + (name or ""))
        ws.cell(row=r, column=2, value=round(float(kg or 0), 1))
        ws.cell(row=r, column=3, value=round(float(sm or 0), 2))
        for c in range(1, 4):
            ws.cell(row=r, column=c).border = border

    # ---- Аркуш 1: Група → Корми ----
    ws1 = wb.active; ws1.title = "Розхід по групах"
    head(ws1, "Розхід кормів по групах за період", COLS, (44, 20, 18))
    r = 5; g_kg = g_sum = 0.0
    for s in tree.get("sections", []):
        feeds = agg_ings(s.get("days", []))
        skg = sum(x["kg"] for x in feeds); ssum = sum(x["sum"] for x in feeds)
        hrow(ws1, r, s.get("section") or "", skg, ssum, grp_fill); r += 1
        for x in feeds:
            frow(ws1, r, x["name"], x["kg"], x["sum"], 4); r += 1
        g_kg += skg; g_sum += ssum
    hrow(ws1, r, "Разом за період", g_kg, g_sum, grp_fill)
    ws1.cell(row=r, column=1).alignment = right

    # ---- Аркуш 2: Категорія → Підкатегорія → Корми ----
    ws2 = wb.create_sheet("Розхід по категоріях")
    head(ws2, "Розхід кормів по категоріях за період", COLS, (44, 20, 18))
    r = 5; c_kg = c_sum = 0.0
    for c_ in uc.get("categories", []):
        cat_feeds = {}
        cat_kg = cat_sum = 0.0
        rows_buf = []
        for s in c_.get("subs", []):
            feeds = agg_ings(s.get("days", []))
            skg = sum(x["kg"] for x in feeds); ssum = sum(x["sum"] for x in feeds)
            rows_buf.append(("sub", s.get("subgroup") or "—", skg, ssum, feeds))
            cat_kg += skg; cat_sum += ssum
        hrow(ws2, r, c_.get("category") or "", cat_kg, cat_sum, grp_fill); r += 1
        for _tag, name, skg, ssum, feeds in rows_buf:
            hrow(ws2, r, "  " + name, skg, ssum, sub_fill); r += 1
            for x in feeds:
                frow(ws2, r, x["name"], x["kg"], x["sum"], 6); r += 1
        c_kg += cat_kg; c_sum += cat_sum
    hrow(ws2, r, "Разом за період", c_kg, c_sum, grp_fill)
    ws2.cell(row=r, column=1).alignment = right

    # ---- Аркуш 3: по кормах (усього) ----
    ws3 = wb.create_sheet("Розхід по кормах")
    head(ws3, "Розхід по кормах за період",
         ["Корм", "Факт завантаження, кг", "Сума ₴ без ПДВ"], (40, 20, 18))
    r = 5; i_kg = i_sum = 0.0
    for g in ui.get("ingredients", []):
        kg = float(g.get("kg") or 0); sm = float(g.get("sum") or 0)
        ws3.cell(row=r, column=1, value=g.get("name") or "")
        ws3.cell(row=r, column=2, value=round(kg, 1))
        ws3.cell(row=r, column=3, value=round(sm, 2))
        for c in range(1, 4):
            ws3.cell(row=r, column=c).border = border
        i_kg += kg; i_sum += sm; r += 1
    ws3.cell(row=r, column=1, value="Разом за період")
    ws3.cell(row=r, column=1).font = bold; ws3.cell(row=r, column=1).alignment = right
    ws3.cell(row=r, column=2, value=round(i_kg, 1)).font = bold
    ws3.cell(row=r, column=3, value=round(i_sum, 2)).font = bold
    for c in range(1, 4):
        ws3.cell(row=r, column=c).fill = grp_fill; ws3.cell(row=r, column=c).border = border

    buf = BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(
        buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True, download_name=f"rozhid_kormiv_{f}_{t}.xlsx")


@app.get("/api/export/issue-by-block.xlsx")
def api_export_issue_by_block_xlsx():
    """Видача/списання по блоках за період у XLSX (групи по блоках із підсумками)."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    except ImportError:
        return _err("Бібліотека openpyxl не встановлена. Запустіть: pip install openpyxl", 500)
    f, t = _xlsx_period_args()
    cat = _inv_category()
    biz = load_business()
    author = biz.get("name") or biz.get("entity") or "Облік ферми"
    # Годівля: стандартизований звіт розходу кормів по факту завантаження —
    # два аркуші (по групах/секціях і по категоріях), суми зводяться до
    # спільного джерела (аналітика Profeed), тож збігаються.
    if cat == "feed":
        return _feed_usage_xlsx(f, t, biz)
    items = db.issue_by_block(f, t, category=cat)
    is_feed = False
    bw_pl = "блоках"      # локатив мн.
    bw_nom = "Блок"       # заголовок групи
    bw_loc = "блоку"      # «Разом по …»

    # групуємо по блоку (зі збереженням порядку появи)
    groups, idx = [], {}
    for it in items:
        b = it.get("block") or ""
        if b not in idx:
            idx[b] = len(groups)
            groups.append({"name": b, "rows": [], "qty": 0.0, "sum": 0.0})
        g = groups[idx[b]]
        g["rows"].append(it)
        g["qty"] += float(it.get("qty") or 0)
        g["sum"] += float(it.get("total") or 0)

    wb = Workbook()
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author
    wb.properties.title = f"Видача по {bw_pl}"
    ws = wb.active
    ws.title = f"Видача по {bw_pl}"

    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    grp_fill = PatternFill("solid", fgColor="E7EEFC")
    sub_fill = PatternFill("solid", fgColor="F6F8FB")
    center = Alignment(horizontal="center", vertical="center")
    right = Alignment(horizontal="right")
    bold = Font(bold=True)

    ws["A1"] = f"Видача по {bw_pl} за період"
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells("A1:G1")
    ws["A1"].alignment = Alignment(horizontal="center")
    ws["A2"] = f"{biz.get('entity') or biz.get('name') or ''} · Період: {_dm(f)} – {_dm(t)}"
    ws.merge_cells("A2:G2")
    ws["A2"].alignment = Alignment(horizontal="center")

    headers = ["№", "Назва", "Од.", "Кому", "Тип", "К-сть", "Сума, ₴"]
    for col, h in enumerate(headers, start=1):
        c = ws.cell(row=4, column=col, value=h)
        c.font = head_font
        c.fill = head_fill
        c.alignment = center
        c.border = border

    row = 5
    g_qty = g_sum = 0.0
    for g in groups:
        ws.cell(row=row, column=1, value=f"{bw_nom}: {g['name']}")
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=7)
        for c in range(1, 8):
            cc = ws.cell(row=row, column=c)
            cc.fill = grp_fill
            cc.font = bold
            cc.border = border
        row += 1
        for i, it in enumerate(g["rows"]):
            ws.cell(row=row, column=1, value=i + 1)
            ws.cell(row=row, column=2, value=it.get("product") or "")
            ws.cell(row=row, column=3, value=it.get("unit") or "")
            ws.cell(row=row, column=4, value=it.get("recipient") or "")
            ws.cell(row=row, column=5,
                    value="Списання" if it.get("move_type") == "WRITE_OFF" else "Видача")
            ws.cell(row=row, column=6, value=round(float(it.get("qty") or 0), 2))
            ws.cell(row=row, column=7, value=round(float(it.get("total") or 0), 2))
            for c in range(1, 8):
                ws.cell(row=row, column=c).border = border
            row += 1
        ws.cell(row=row, column=1, value=f"Разом по {bw_loc} «{g['name']}»")
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
        ws.cell(row=row, column=1).alignment = right
        ws.cell(row=row, column=6, value=round(g["qty"], 2))
        ws.cell(row=row, column=7, value=round(g["sum"], 2))
        for c in range(1, 8):
            cc = ws.cell(row=row, column=c)
            cc.fill = sub_fill
            cc.font = bold
            cc.border = border
        g_qty += g["qty"]; g_sum += g["sum"]
        row += 1

    ws.cell(row=row, column=1, value="Разом за період")
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
    ws.cell(row=row, column=1).alignment = right
    ws.cell(row=row, column=1).font = bold
    ws.cell(row=row, column=6, value=round(g_qty, 2)).font = bold
    ws.cell(row=row, column=7, value=round(g_sum, 2)).font = bold
    for c in range(1, 8):
        ws.cell(row=row, column=c).border = border

    for col, w in enumerate([5, 34, 6, 22, 10, 10, 14], start=1):
        ws.column_dimensions[chr(64 + col)].width = w

    buf = BytesIO(); wb.save(buf); buf.seek(0)
    tag = {"pharmacy": "apteka", "feed": "kormy"}.get(cat, "materialy")
    return send_file(
        buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True, download_name=f"vydacha_blocky_{tag}_{f}_{t}.xlsx")


def _feed_request_xlsx(products, biz):
    """Проста заявка по кормах: №, Назва, Од., Залишок, До замовлення (для
    заповнення вручну). Без блоків — короткий бланк на закупівлю кормів."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    author = biz.get("name") or biz.get("entity") or "Облік ферми"
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author
    wb.properties.title = "Заявка на корми"
    ws = wb.active
    ws.title = "Заявка"

    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    total_fill = PatternFill("solid", fgColor="EEF2F7")
    border = Border(left=Side(style="thin", color="CCCCCC"),
                    right=Side(style="thin", color="CCCCCC"),
                    top=Side(style="thin", color="CCCCCC"),
                    bottom=Side(style="thin", color="CCCCCC"))
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws["A1"] = "Заявка на корми"
    ws["A1"].font = Font(bold=True, size=14)
    ws.merge_cells("A1:F1"); ws["A1"].alignment = Alignment(horizontal="center")
    ws["A2"] = biz.get("name") or biz.get("entity") or ""
    ws.merge_cells("A2:F2"); ws["A2"].alignment = Alignment(horizontal="center")
    ws["A3"] = f"Дата: {date.today().strftime('%d.%m.%Y')}"
    ws.merge_cells("A3:F3")

    head_row = 5
    for col, h in enumerate(
            ["№", "Назва корму", "Од.", "Залишок", "Потреба", "До замовлення"], start=1):
        c = ws.cell(row=head_row, column=col, value=h)
        c.font = head_font; c.fill = head_fill; c.alignment = center; c.border = border

    products = [p for p in products if not db._is_water(p.get("name"))]
    first = head_row + 1
    for i, p in enumerate(products, start=1):
        row = head_row + i
        ws.cell(row=row, column=1, value=i)
        ws.cell(row=row, column=2, value=p.get("name") or "")
        ws.cell(row=row, column=3, value=p.get("unit") or "")
        ws.cell(row=row, column=4, value=float(p.get("total_qty") or 0))
        ws.cell(row=row, column=5, value=None)          # Потреба — заповнюється вручну
        # До замовлення = МАКС(0, Потреба − Залишок)
        ws.cell(row=row, column=6, value=f"=MAX(0,E{row}-D{row})")
        for c in range(1, 7):
            ws.cell(row=row, column=c).border = border

    last = head_row + len(products)
    trow = last + 1
    tc = ws.cell(row=trow, column=2, value="Разом")
    tc.font = Font(bold=True); tc.alignment = Alignment(horizontal="right")
    for col in (4, 5, 6):
        L = get_column_letter(col)
        c = ws.cell(row=trow, column=col,
                    value=(f"=SUM({L}{first}:{L}{last})" if products else 0))
        c.font = Font(bold=True); c.fill = total_fill; c.border = border

    for col, w in (("A", 5), ("B", 40), ("C", 7), ("D", 12), ("E", 12), ("F", 14)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = f"A{first}"

    buf = BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(
        buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"zayavka_kormy_{date.today().isoformat()}.xlsx")


@app.get("/api/export/request.xlsx")
def api_export_request():
    """Бланк заявки (XLSX): список товарів, од. виміру, залишок, далі стовпці
    блоків із довідника (Відтворення, Молодняк, …). «Всього» — сума по блоках
    (формула), «Залишок після заявки» = Залишок − Всього (формула)."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        return _err("Бібліотека openpyxl не встановлена. Запустіть: "
                    "pip install openpyxl", 500)

    cat = _inv_category()
    products = db.list_products(category=cat)
    blocks = db.list_blocks(category=cat)
    biz = load_business()
    item_pl = {"materials": "матеріалів", "feed": "кормів"}.get(cat, "ветпрепаратів")

    # Годівля: проста заявка без блоків — №, Назва, Од., Залишок, До замовлення.
    if cat == "feed":
        return _feed_request_xlsx(products, biz)

    wb = Workbook()
    _doc_author = biz.get("name") or biz.get("entity") or "Облік ферми"
    wb.properties.creator = _doc_author
    wb.properties.lastModifiedBy = _doc_author
    wb.properties.title = "Бланк заявки"
    ws = wb.active
    ws.title = "Заявка"

    title_font = Font(bold=True, size=14)
    head_font = Font(bold=True, size=10, color="FFFFFF")
    head_fill = PatternFill("solid", fgColor="2F7AD9")
    block_fill = PatternFill("solid", fgColor="5B8DEF")
    total_fill = PatternFill("solid", fgColor="EEF2F7")
    border = Border(left=Side(style="thin", color="CCCCCC"),
                    right=Side(style="thin", color="CCCCCC"),
                    top=Side(style="thin", color="CCCCCC"),
                    bottom=Side(style="thin", color="CCCCCC"))
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    n_blocks = len(blocks)
    # Розкладка колонок:
    # 1 №, 2 Назва, 3 Од., 4 Залишок, [5..4+N] блоки, 5+N Всього, 6+N Залишок після
    col_first_block = 5
    col_last_block = 4 + n_blocks
    col_total = 5 + n_blocks
    col_left = 6 + n_blocks
    n_cols = col_left
    last_col_letter = get_column_letter(n_cols)

    ws["A1"] = f"Бланк заявки {item_pl}"
    ws["A1"].font = title_font
    ws.merge_cells(f"A1:{last_col_letter}1")
    ws["A1"].alignment = Alignment(horizontal="center")
    ws["A2"] = biz.get("name") or biz.get("entity") or ""
    ws.merge_cells(f"A2:{last_col_letter}2")
    ws["A2"].alignment = Alignment(horizontal="center")
    ws["A3"] = f"Дата: {date.today().strftime('%d.%m.%Y')}"
    ws.merge_cells(f"A3:{last_col_letter}3")

    head_row = 5
    headers = ["№", f"Назва {item_pl}", "Од.", "Залишок"]
    headers += [b["name"] for b in blocks]
    headers += ["Всього", "До замовлення"]
    for col, h in enumerate(headers, start=1):
        cell = ws.cell(row=head_row, column=col, value=h)
        cell.font = head_font
        cell.alignment = center
        cell.border = border
        cell.fill = (block_fill if col_first_block <= col <= col_last_block else head_fill)
    ws.row_dimensions[head_row].height = 34

    first_data = head_row + 1
    for i, p in enumerate(products, start=1):
        row = head_row + i
        ws.cell(row=row, column=1, value=i)
        ws.cell(row=row, column=2, value=p.get("name") or "")
        ws.cell(row=row, column=3, value=p.get("unit") or "")
        ws.cell(row=row, column=4, value=float(p.get("total_qty") or 0))
        # стовпці блоків — порожні для заповнення
        for c in range(col_first_block, col_last_block + 1):
            ws.cell(row=row, column=c, value=None)
        # Всього = сума по блоках
        if n_blocks:
            rng = (f"{get_column_letter(col_first_block)}{row}:"
                   f"{get_column_letter(col_last_block)}{row}")
            ws.cell(row=row, column=col_total, value=f"=SUM({rng})")
        else:
            ws.cell(row=row, column=col_total, value=0)
        # До замовлення = Всього (замовлення) − Залишок, не менше 0
        ws.cell(row=row, column=col_left,
                value=f"=MAX(0,{get_column_letter(col_total)}{row}-D{row})")
        for c in range(1, n_cols + 1):
            ws.cell(row=row, column=c).border = border

    # Підсумковий рядок «Разом»
    last_data = head_row + len(products)
    total_row = last_data + 1
    tcell = ws.cell(row=total_row, column=2, value="Разом")
    tcell.font = Font(bold=True)
    tcell.alignment = Alignment(horizontal="right")
    for c in [4] + list(range(col_first_block, n_cols + 1)):
        L = get_column_letter(c)
        cell = ws.cell(row=total_row, column=c,
                       value=(f"=SUM({L}{first_data}:{L}{last_data})"
                              if len(products) else 0))
        cell.font = Font(bold=True)
        cell.fill = total_fill
        cell.border = border

    # Ширини колонок
    ws.column_dimensions["A"].width = 5
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 7
    ws.column_dimensions["D"].width = 11
    for c in range(col_first_block, col_last_block + 1):
        ws.column_dimensions[get_column_letter(c)].width = 13
    ws.column_dimensions[get_column_letter(col_total)].width = 11
    ws.column_dimensions[get_column_letter(col_left)].width = 18

    # Закріпити шапку й перші колонки
    ws.freeze_panes = f"E{first_data}"

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    suffix = {"materials": "materialy", "feed": "kormy"}.get(cat, "apteka")
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"zayavka_{suffix}_{date.today().isoformat()}.xlsx",
    )


@app.get("/api/export/users.csv")
def api_export_users():
    # доступно лише адміну (під ADMIN_API_PREFIXES /api/users — не цей шлях,
    # тому додаємо явну перевірку)
    user = db.get_user(session.get("user_id"))
    if not user or user.get("role") != "admin":
        return _err("Доступ заборонено", 403)
    rows = db.list_users()
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(["Логін", "Імʼя", "Роль", "Активний",
                     "Створено", "Остання активність"])
    for u in rows:
        writer.writerow([
            u.get("username") or "",
            u.get("full_name") or "",
            "Адміністратор" if u.get("role") == "admin" else "Користувач",
            "так" if u.get("is_active") else "ні",
            u.get("created_at") or "",
            u.get("last_seen") or "",
        ])
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(
        BytesIO(data), mimetype="text/csv", as_attachment=True,
        download_name=f"vet_users_{date.today().isoformat()}.csv",
    )


# --- Економіка ---

@app.get("/api/expense-categories")
def api_expense_categories():
    return _ok({"items": db.list_expense_categories()})


@app.post("/api/expense-categories")
def api_expense_category_create():
    data = request.get_json(silent=True) or {}
    try:
        cid = db.add_expense_category(data.get("name", ""))
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": cid})


@app.delete("/api/expense-categories/<int:category_id>")
def api_expense_category_delete(category_id: int):
    db.delete_expense_category(category_id)
    return _ok()


@app.get("/api/expenses")
def api_expenses_list():
    items = db.list_expenses(
        request.args.get("from", ""), request.args.get("to", ""))
    return _ok({"items": items})


@app.post("/api/expenses")
def api_expense_create():
    data = request.get_json(silent=True) or {}
    cat = data.get("category_id")
    try:
        cat_id = int(cat) if cat not in (None, "") else None
    except (TypeError, ValueError):
        cat_id = None
    try:
        amount = float(data.get("amount") or 0)
    except (TypeError, ValueError):
        return _err("Невірна сума витрати")
    try:
        eid = db.add_expense(cat_id, amount,
                             data.get("expense_date", ""), data.get("note", ""))
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": eid})


@app.delete("/api/expenses/<int:expense_id>")
def api_expense_delete(expense_id: int):
    db.delete_expense(expense_id)
    return _ok()


@app.get("/api/economics")
def api_economics():
    summary = db.economics_summary(
        request.args.get("from", ""), request.args.get("to", ""))
    return _ok(summary)


# --- База даних: шаблони, імпорт, очистка ---

# Опис CSV-шаблонів для початкового заповнення бази
DB_TEMPLATES = {
    "catalog": {
        "filename": "шаблон_товари_та_залишки.csv",
        "header": ["Код товару", "Назва", "Штрихкод", "Одиниця",
                   "Мінімальний залишок", "Кількість",
                   "Ціна закупки без ПДВ", "Ціна закупки з ПДВ", "Ставка ПДВ",
                   "Номер партії", "Термін придатності",
                   "Постачальник", "Номер накладної", "Дата приходу", "Примітка"],
        "examples": [
            ["001", "Вакцина приклад", "4820000001234", "фл", "5", "12",
             "150", "180", "20", "LOT-001", "2027-02-01",
             "BioTest", "НАКЛ-1", "2026-05-25", "Холодове зберігання"],
            ["002", "Шприц приклад (без залишку)", "4820000005678", "шт",
             "20", "", "", "", "", "", "", "MedSupply", "", "", "Розхідник"],
        ],
    },
}


@app.get("/api/templates/<kind>.csv")
def api_template(kind: str):
    """Завантажити порожній CSV-шаблон для заповнення бази."""
    tpl = DB_TEMPLATES.get(kind)
    if not tpl:
        abort(404)
    buf = StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(tpl["header"])
    for ex in tpl["examples"]:
        writer.writerow(ex)
    data = buf.getvalue().encode("utf-8-sig")
    return send_file(BytesIO(data), mimetype="text/csv",
                     as_attachment=True, download_name=tpl["filename"])


@app.post("/api/import")
def api_import():
    """Імпорт заповненого CSV-файлу в базу. Тип визначається за колонками."""
    f = request.files.get("file")
    if not f or not f.filename:
        return _err("Файл не вибрано")

    content = f.read()
    raw = None
    for enc in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            raw = content.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    if raw is None:
        return _err("Не вдалося прочитати файл — збережіть його у кодуванні UTF-8")

    lines = raw.splitlines()
    if not lines:
        return _err("Файл порожній")
    delim = ";" if lines[0].count(";") >= lines[0].count(",") else ","
    rows = list(csv.reader(StringIO(raw), delimiter=delim))
    if not rows:
        return _err("Файл порожній")

    header = [(c or "").strip() for c in rows[0]]
    data_rows = rows[1:]
    idx = {name: i for i, name in enumerate(header)}
    hset = set(header)

    if "Штрихкод" not in hset:
        return _err("Не вдалося розпізнати файл. "
                    "Скористайтесь шаблоном «Товари із залишками».")
    kind = "catalog"

    def cell(row, name):
        i = idx.get(name)
        if i is None or i >= len(row):
            return ""
        return (row[i] or "").strip()

    def num(s):
        s = (s or "").strip().replace(" ", "").replace(" ", "").replace(",", ".")
        return float(s) if s else 0.0

    products_added = batches_added = 0
    errors = []

    for n, row in enumerate(data_rows, start=2):
        if not any((c or "").strip() for c in row):
            continue  # порожній рядок
        try:
            if kind == "catalog":
                barcode = cell(row, "Штрихкод")
                name = cell(row, "Назва")
                if not barcode:
                    errors.append(f"рядок {n}: порожній штрихкод")
                    continue
                # створюємо товар, якщо його ще немає
                if not db.get_product_by_barcode(barcode):
                    if not name:
                        errors.append(f"рядок {n}: новий товар без назви")
                        continue
                    db.add_product(
                        name=name, barcode=barcode, code=cell(row, "Код товару"),
                        unit=cell(row, "Одиниця") or "шт",
                        min_stock=num(cell(row, "Мінімальний залишок")),
                        supplier=cell(row, "Постачальник"),
                        notes=cell(row, "Примітка"))
                    products_added += 1
                # якщо вказано кількість — додаємо партію (залишок)
                qty = num(cell(row, "Кількість"))
                if qty > 0:
                    vat_cell = cell(row, "Ставка ПДВ")
                    db.receive_stock(
                        barcode, qty,
                        cell(row, "Номер партії"),
                        cell(row, "Термін придатності") or None,
                        price_in_no_vat=num(cell(row, "Ціна закупки без ПДВ")),
                        price_in=num(cell(row, "Ціна закупки з ПДВ")),
                        vat_rate=(num(vat_cell) if vat_cell else 20),
                        supplier_name=cell(row, "Постачальник") or "Початковий облік",
                        invoice_number=cell(row, "Номер накладної") or "ЗАЛИШОК",
                        receipt_date=cell(row, "Дата приходу"))
                    batches_added += 1
        except Exception as exc:  # noqa: BLE001
            errors.append(f"рядок {n}: {exc}")

    return _ok({"type": "catalog", "products": products_added,
                "batches": batches_added, "errors": errors})


@app.post("/api/database/clear")
def api_database_clear():
    """Повне очищення бази даних."""
    db.clear_database()
    return _ok()


@app.get("/api/database/backup")
def api_database_backup_download():
    """Завантажити поточну базу як резервну копію."""
    db.checkpoint()   # злити WAL у файл, щоб копія була актуальною
    name = f"workcenter_{date.today().isoformat()}.db"
    return send_file(db.db_path, mimetype="application/x-sqlite3",
                     as_attachment=True, download_name=name)


# ══ Дзеркало ферми: браузер ↔ локальний ПК ══════════════════════════════════
# Задумка Романа (2026-09-04): клієнт стартує в браузері (сервер — господар
# даних). Якщо хоче працювати локально — ставить застосунок на ПК, «забирає
# базу» з сервера і стає господарем; сервер відтоді ДЗЕРКАЛО: приймає знімки
# бази з ПК і показує ферму лише для перегляду. Один господар — без конфліктів.

def _mirror_on() -> bool:
    return SERVER_MODE and db.get_setting("mirror_mode", "0") == "1"


def _mirror_owner_ok() -> bool:
    """Пуш приймається лише від пристрою-господаря. Прив'язка з'являється при
    «заборі бази» (claim) або з першим пушем, що назвався; старі клієнти без
    заголовка пристрою приймаються, доки господар не зафіксований."""
    owner = (db.get_setting("mirror_owner_device", "") or "").strip()
    got = (request.headers.get("X-Bovio-Device", "") or "").strip()
    if not owner:
        if got:  # перший, хто назвався, стає господарем
            db.set_setting("mirror_owner_device", got)
        return True
    return bool(got) and got == owner


def _mirror_auth_ok() -> bool:
    import hmac
    tok = (db.get_setting("mirror_sync_token", "") or "").strip()
    got = (request.headers.get("X-Bovio-Sync", "") or "").strip()
    return bool(tok) and bool(got) and hmac.compare_digest(tok, got)


@app.post("/api/mirror/enable")
def api_mirror_enable():
    """Адмін у браузері готує підключення ПК: генерує токен (regen=1 — новий)."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if not u or u.get("role") != "admin":
        return jsonify({"ok": False, "error": "Лише адміністратор"}), 403
    tok = (db.get_setting("mirror_sync_token", "") or "").strip()
    if not tok or (request.get_json(silent=True) or {}).get("regen"):
        tok = secrets.token_urlsafe(24)
        db.set_setting("mirror_sync_token", tok)
    return _ok({"token": tok, "mirror": _mirror_on(),
                "last_push": db.get_setting("mirror_last_push", "")})


@app.post("/api/mirror/release")
def api_mirror_release():
    """Повернути ведення обліку в браузер (дзеркало вимикається).
    Локальний ПК після цього має припинити пуш (його знімки відхиляться)."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if not u or u.get("role") != "admin":
        return jsonify({"ok": False, "error": "Лише адміністратор"}), 403
    db.set_setting("mirror_mode", "0")
    db.set_setting("mirror_owner_device", "")
    return _ok({})


@app.get("/api/mirror/pull")
def api_mirror_pull():
    """Локальний застосунок забирає повну базу (gzip). ?claim=1 — ПК стає
    господарем: сервер одразу переходить у режим дзеркала."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    if not _mirror_auth_ok():
        return jsonify({"ok": False, "error": "Невірний токен підключення"}), 403
    db.checkpoint()
    data = Path(db.db_path).read_bytes()
    if request.args.get("claim") == "1":
        db.set_setting("mirror_mode", "1")
        db.set_setting("mirror_claimed_at",
                       datetime.now().strftime("%Y-%m-%d %H:%M"))
        db.set_setting("mirror_owner_device",
                       (request.headers.get("X-Bovio-Device", "") or "").strip())
    import gzip as _gz
    db.bovio_log_add("copy_out", "сервер → %s · копія бази (%.1f МБ)"
                     % (_bovio_peer(), len(data) / 1048576.0))
    resp = Response(_gz.compress(data, 6), mimetype="application/gzip")
    resp.headers["X-Bovio-DB-Bytes"] = str(len(data))
    return resp


@app.post("/api/mirror/push")
def api_mirror_push():
    """Знімок бази з локального ПК (gzip або сирий SQLite). Приймається ЛИШЕ
    в режимі дзеркала — інакше 409, і ПК бачить, що господар змінився."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    if not _mirror_auth_ok():
        return jsonify({"ok": False, "error": "Невірний токен підключення"}), 403
    if not _mirror_on():
        return jsonify({"ok": False, "error":
                        "Сервер не в режимі дзеркала — облік ведеться у браузері. "
                        "Заберіть базу заново («стати господарем»)."}), 409
    if not _mirror_owner_ok():
        return jsonify({"ok": False, "error":
                        "Ферма ведеться з ІНШОГО пристрою — знімок відхилено. "
                        "Щоб перенести ведення сюди, «заберіть базу» заново."}), 409
    raw = request.get_data(cache=False)
    import gzip as _gz
    try:
        data = _gz.decompress(raw)
    except OSError:
        data = raw
    # службові позначки дзеркала живуть у НАШІЙ базі — переживають підміну
    keep = {k: db.get_setting(k, "") for k in
            ("mirror_mode", "mirror_sync_token", "mirror_claimed_at",
             "mirror_owner_device")}
    db.restore_from_bytes(data)  # цілісність + копія + відкат при помилці
    for k, v in keep.items():
        db.set_setting(k, v)
    db.set_setting("mirror_last_push", datetime.now().strftime("%Y-%m-%d %H:%M"))
    db.bovio_log_add("snap_in", "%s → сервер · знімок бази (%.1f МБ)"
                     % (_bovio_peer(), len(data) / 1048576.0))
    return _ok({"bytes": len(data)})


def _bovio_peer() -> str:
    """Як підписати ПК у реєстрі обміну: імʼя компʼютера, а якщо старий
    застосунок його не шле — хвіст ідентифікатора пристрою."""
    h = (request.headers.get("X-Bovio-Host") or "").strip()
    if h:
        return h[:40]
    d = (request.headers.get("X-Bovio-Device") or "").strip()
    return ("ПК ·" + d[-6:]) if d else "ПК"


@app.post("/api/satellite/ops")
def api_satellite_ops():
    """Черга операцій із застосунків-«супутників» (крок 3: працюй будь-де).
    Ідемпотентне застосування apply_sync_ops; посилання за штрихкодами.
    Приймається ЛИШЕ коли ця ферма — авторитет (не дзеркало)."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    if not _mirror_auth_ok():
        return jsonify({"ok": False, "error": "Невірний токен підключення"}), 403
    if _mirror_on():
        return jsonify({"ok": False, "error":
                        "Ферма ведеться локально на ПК — операції супутників "
                        "приймаються, лише коли облік ведеться у браузері."}), 409
    d = request.get_json(silent=True) or {}
    device = str(d.get("device") or "satellite")[:64]
    results = []
    for op in (d.get("ops") or [])[:200]:
        cat = str(op.get("category") or "pharmacy")
        who = str((op.get("payload") or {}).get("who") or "").strip()
        uid = None
        if who:
            try:
                u = db.get_user_by_username(who)
                uid = int(u["id"]) if u else None
            except Exception:  # noqa: BLE001
                uid = None
        res = db.apply_sync_ops(device, uid, [op], category=cat)
        results.extend(res.get("results") or [])
    if results:
        _bad = sum(1 for r in results if str(r.get("status") or "applied") != "applied")
        _NAMES = {"sale": "видача", "receipt": "прихід", "adjust": "коригування",
                  "new_product": "новий товар"}
        _cnt: dict = {}
        for op in (d.get("ops") or [])[:200]:
            t = str(op.get("type") or "").strip()
            _cnt[t] = _cnt.get(t, 0) + 1
        _what = ", ".join("%s %d" % (_NAMES.get(t, t or "операція"), n)
                          for t, n in sorted(_cnt.items(), key=lambda x: -x[1]))
        db.bovio_log_add("ops_in", "%s → сервер · %s%s"
                         % (_bovio_peer(), _what or ("операцій: %d" % len(results)),
                            (" · з позначкою: %d" % _bad) if _bad else ""))
    return _ok({"results": results})


@app.post("/api/profeed/upload")
def api_profeed_upload():
    """Крок 2 «Profeed у хмару»: приймання звіту міксера з фермового ПК
    (агент-курʼєр). Файл лягає в теку звітів ферми НА СЕРВЕРІ — далі працює
    той самий щогодинний скан, що й локально. Ідемпотентно: файл із тим самим
    вмістом удруге не пишеться."""
    if not SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в серверній версії"}), 404
    if not _mirror_auth_ok():
        return jsonify({"ok": False, "error": "Невірний токен підключення"}), 403
    if _mirror_on():
        return jsonify({"ok": False, "error":
                        "Ферма ведеться локально на ПК — звіти сканує сам ПК."}), 409
    import hashlib
    import re as _re
    fname = (request.headers.get("X-Bovio-Filename", "") or "").strip()
    fname = os.path.basename(fname)
    if not _re.fullmatch(r"[\w.\-]{1,80}\.(xlsx|xls)", fname, _re.IGNORECASE):
        return jsonify({"ok": False, "error": "Недопустима назва файлу"}), 400
    data = request.get_data(cache=False)
    if not data or len(data) > 20 * 1024 * 1024:
        return jsonify({"ok": False, "error": "Порожній або завеликий файл"}), 400
    d = (db.get_setting("feed_profeed_dir", "") or "").strip()
    if not d:
        d = str(Path(db.db_path).resolve().parent / "profeed")
        db.set_setting("feed_profeed_dir", d)
    p = Path(d).expanduser()
    p.mkdir(parents=True, exist_ok=True)
    dest = p / fname
    if dest.exists() and hashlib.sha1(dest.read_bytes()).hexdigest() == \
            hashlib.sha1(data).hexdigest():
        return _ok({"saved": fname, "skipped": True})
    tmp = p / (fname + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, dest)
    return _ok({"saved": fname, "bytes": len(data)})




# ── Локальний бік дзеркала: ПК — господар, пушить знімки на свою ферму ──────

def _bovio_cfg() -> dict:
    return {
        "url": (db.get_setting("bovio_url", "") or "").strip().rstrip("/"),
        "token": (db.get_setting("bovio_token", "") or "").strip(),
        "push_on": db.get_setting("bovio_push_on", "0") == "1",
        "push_min": max(5, int(db.get_setting("bovio_push_min", "10") or 10)),
        "last": db.get_setting("bovio_push_last", ""),
        "error": db.get_setting("bovio_push_error", ""),
    }


def _bovio_device_id() -> str:
    did = (db.get_setting("bovio_device_id", "") or "").strip()
    if not did:
        import uuid
        did = uuid.uuid4().hex
        db.set_setting("bovio_device_id", did)
    return did


def _bovio_host_name() -> str:
    """Імʼя цього компʼютера для реєстру обміну серверної ферми: інакше в
    реєстрі всі ПК зливаються в один рядок і не видно, ХТО саме обмінявся."""
    try:
        import socket
        n = (socket.gethostname() or "").split(".")[0].strip()
    except Exception:  # noqa: BLE001
        n = ""
    return (n or "ПК")[:40]


def _bovio_call_raw(path: str, data: bytes | None = None, method: str = "GET",
                    content_type: str = "application/gzip",
                    extra_headers: dict | None = None) -> bytes:
    """Запит до серверної ферми Bovio (токен у X-Bovio-Sync)."""
    import urllib.request
    import urllib.error
    cfg = _bovio_cfg()
    if not (cfg["url"] and cfg["token"]):
        raise RuntimeError("Вкажіть адресу ферми і токен підключення.")
    hdrs = {"X-Bovio-Sync": cfg["token"],
            "X-Bovio-Device": _bovio_device_id(),
            "X-Bovio-Host": _bovio_host_name(),   # для реєстру обміну на сервері
            "Content-Type": content_type}
    hdrs.update(extra_headers or {})
    req = urllib.request.Request(
        cfg["url"] + path, data=data, method=method, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=300,
                                    context=_tg_milk_ssl_ctx()) as resp:
            return resp.read()
    except urllib.error.HTTPError as exc:
        try:
            msg = json.loads(exc.read().decode("utf-8", "replace")).get("error") or ""
        except Exception:  # noqa: BLE001
            msg = ""
        raise RuntimeError(msg or ("сервер відповів %d" % exc.code)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError("немає звʼязку із сервером (%s)" % exc.reason) from exc


def _bovio_push_once() -> str:
    """Один знімок бази → на сервер. Повертає час, або кидає виняток."""
    import gzip as _gz
    db.checkpoint()
    payload = _gz.compress(Path(db.db_path).read_bytes(), 6)
    _bovio_call_raw("/api/mirror/push", data=payload, method="POST")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    db.set_setting("bovio_push_last", ts)
    db.set_setting("bovio_push_error", "")
    db.set_setting("bovio_last_ok", ts[:10])   # якір ліцензії-оренди
    db.bovio_log_add("push", "цей ПК → сервер · знімок бази")
    return ts


def _bovio_admin_guard():
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    if SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в локальному застосунку"}), 404
    if not u or u.get("role") != "admin":
        return jsonify({"ok": False, "error": "Лише адміністратор"}), 403
    return None


@app.get("/api/bovio/info")
def api_bovio_info():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    return _ok(_bovio_cfg())


@app.post("/api/bovio/settings")
def api_bovio_settings():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    if "url" in d:
        db.set_setting("bovio_url", str(d.get("url") or "").strip().rstrip("/"))
    if "token" in d:
        db.set_setting("bovio_token", str(d.get("token") or "").strip())
    if "push_on" in d:
        db.set_setting("bovio_push_on", "1" if d.get("push_on") else "0")
    if "push_min" in d:
        try:
            db.set_setting("bovio_push_min", str(max(5, int(d.get("push_min")))))
        except (TypeError, ValueError):
            pass
    return _ok(_bovio_cfg())


def _bovio_do_pull() -> None:
    """Забрати базу з сервера і СТАТИ ГОСПОДАРЕМ (сервер стає дзеркалом).
    Поточна локальна база перед підміною зберігається копією (restore_from_bytes)."""
    import gzip as _gz
    raw = _bovio_call_raw("/api/mirror/pull?claim=1")
    try:
        data = _gz.decompress(raw)
    except OSError:
        data = raw
    # налаштування підключення живуть у НАШІЙ базі — переживають підміну
    keep = {k: db.get_setting(k, "") for k in
            ("bovio_url", "bovio_token", "bovio_push_min")}
    db.restore_from_bytes(data)
    for k, v in keep.items():
        db.set_setting(k, v)
    db.set_setting("mirror_mode", "0")        # локально ми господар, не дзеркало
    db.set_setting("bovio_push_on", "1")      # одразу починаємо слати знімки
    db.set_setting("bovio_push_error", "")
    try:
        _bovio_push_once()                     # перший знімок — щоб дзеркало ожило
    except Exception:  # noqa: BLE001
        pass


@app.post("/api/bovio/pull")
def api_bovio_pull():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    _bovio_do_pull()
    return _ok(_bovio_cfg())


@app.post("/api/bovio/setup-pull")
def api_bovio_setup_pull():
    """Перший запуск: «Підключити ферму Bovio» — дозволено ЛИШЕ доки в базі
    немає жодного користувача (порожня установка). Користувачі приїдуть
    разом із базою ферми, далі — звичайний логін."""
    if SERVER_MODE:
        return jsonify({"ok": False, "error": "Доступно лише в локальному застосунку"}), 404
    if db.count_users() > 0:
        return jsonify({"ok": False,
                        "error": "Установка вже налаштована — підключення до Bovio "
                                 "доступне в Налаштуваннях."}), 403
    d = request.get_json(silent=True) or {}
    db.set_setting("bovio_url", str(d.get("url") or "").strip().rstrip("/"))
    db.set_setting("bovio_token", str(d.get("token") or "").strip())
    try:
        _bovio_do_pull()
    except Exception as exc:  # noqa: BLE001
        return jsonify({"ok": False, "error": str(exc)}), 502
    return _ok({})


@app.post("/api/bovio/push-now")
def api_bovio_push_now():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    try:
        ts = _bovio_push_once()
    except Exception as exc:  # noqa: BLE001
        db.set_setting("bovio_push_error", str(exc))
        return jsonify({"ok": False, "error": str(exc)}), 502
    return _ok({"last": ts})


def _satellite_push_once() -> dict:
    """Надіслати чергу операцій супутника на серверну ферму."""
    ops = db.satellite_pending(100)
    if not ops:
        return {"sent": 0}
    payload = json.dumps({"device": "sat-" + _bovio_device_id()[:12],
                          "ops": ops}, ensure_ascii=False).encode("utf-8")
    raw = _bovio_call_raw("/api/satellite/ops", data=payload, method="POST",
                          content_type="application/json")
    res = json.loads(raw.decode("utf-8", "replace"))
    if not res.get("ok"):
        raise RuntimeError(res.get("error") or "сервер відхилив операції")
    n = 0
    for r in (res.get("results") or []):
        oid = str(r.get("op_id") or "")
        if not oid:
            continue
        st = str(r.get("status") or "rejected")
        db.satellite_mark(oid, st, str(r.get("error") or r.get("conflict") or
                                       r.get("sale_no") or ""))
        n += 1
    db.set_setting("satellite_last", datetime.now().strftime("%Y-%m-%d %H:%M"))
    db.set_setting("satellite_error", "")
    db.bovio_log_add("ops", "цей ПК → сервер · надіслано операцій: %d" % n)
    return {"sent": n}


def _satellite_refresh() -> None:
    """Оновити локальну копію свіжим знімком із сервера (БЕЗ перехоплення
    господарства). Дозволено лише з ПОРОЖНЬОЮ чергою — інакше локальні
    несинхронізовані операції зникли б із виду."""
    st = db.satellite_stats()
    if st.get("pending"):
        raise RuntimeError("Спершу надішліть чергу (%d оп.) — потім оновлення."
                           % st["pending"])
    import gzip as _gz
    raw = _bovio_call_raw("/api/mirror/pull")     # БЕЗ claim!
    try:
        data = _gz.decompress(raw)
    except OSError:
        data = raw
    keep = {k: db.get_setting(k, "") for k in
            ("bovio_url", "bovio_token", "bovio_push_min", "bovio_device_id",
             "bovio_satellite", "satellite_last", "milk_form_adopted",
             "bovio_sat_auto_min", "milk_tg_on",    # кожен ПК тримає свій обмін із ботом
             # ЛІЦЕНЗІЯ — цього ПК, а не серверна: інакше кожне оновлення
             # копією підміняло б ключ (для ключа з привʼязкою до пристрою це
             # означало б «виданий для іншого ПК» і режим лише-читання, а на
             # сервері без ключа — «ознайомлювальний період»).
             "license_key", "install_date")}
    db.restore_from_bytes(data)
    for k, v in keep.items():
        db.set_setting(k, v)
    db.set_setting("mirror_mode", "0")
    db.set_setting("bovio_push_on", "0")   # супутник знімки НЕ пушить ніколи
    db.set_setting("satellite_refreshed",
                   datetime.now().strftime("%Y-%m-%d %H:%M"))
    db.bovio_log_add("refresh", "сервер → цей ПК · копія бази (%.1f МБ)"
                     % (len(data) / 1048576.0))


@app.get("/api/satellite/info")
def api_satellite_info():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    return _ok({"on": db.get_setting("bovio_satellite", "0") == "1",
                "stats": db.satellite_stats(),
                "last": db.get_setting("satellite_last", ""),
                "refreshed": db.get_setting("satellite_refreshed", ""),
                "error": db.get_setting("satellite_error", ""),
                "log": db.bovio_log(15)})


@app.post("/api/satellite/settings")
def api_satellite_settings():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    if "on" in d:
        db.set_setting("bovio_satellite", "1" if d.get("on") else "0")
        if d.get("on"):
            db.set_setting("bovio_push_on", "0")   # взаємовиключно зі знімками
    return _ok({"on": db.get_setting("bovio_satellite", "0") == "1"})


@app.post("/api/satellite/push-now")
def api_satellite_push_now():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    try:
        r = _satellite_push_once()
    except Exception as exc:  # noqa: BLE001
        db.set_setting("satellite_error", str(exc))
        return jsonify({"ok": False, "error": str(exc)}), 502
    return _ok(r)


@app.post("/api/satellite/refresh")
def api_satellite_refresh():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    try:
        _satellite_refresh()
    except Exception as exc:  # noqa: BLE001
        return jsonify({"ok": False, "error": str(exc)}), 502
    return _ok({"refreshed": db.get_setting("satellite_refreshed", "")})


def _profeed_forward_once() -> dict:
    """Переслати на серверну ферму нові/змінені звіти Profeed з локальної теки.
    Стан «що вже надіслано» — sha1 кожного файлу в setting profeed_fwd_state:
    файл дописався (Profeed оновлює звіт протягом дня) → поїде ще раз,
    сервер ідемпотентний."""
    import hashlib
    d = (db.get_setting("feed_profeed_dir", "") or "").strip()
    if not d:
        return {"sent": 0, "reason": "теку звітів не налаштовано"}
    p = Path(d).expanduser()
    if not p.exists():
        return {"sent": 0, "reason": "теки не існує"}
    try:
        state = json.loads(db.get_setting("profeed_fwd_state", "") or "{}")
    except Exception:  # noqa: BLE001
        state = {}
    sent = 0
    for f in sorted(p.glob("*.xls*")):
        if f.name.endswith(".tmp"):
            continue
        try:
            data = f.read_bytes()
        except OSError:
            continue                       # файл саме пишеться — наступним колом
        if not data or len(data) > 20 * 1024 * 1024:
            continue
        h = hashlib.sha1(data).hexdigest()
        if state.get(f.name) == h:
            continue
        raw = _bovio_call_raw("/api/profeed/upload", data=data, method="POST",
                              content_type="application/octet-stream",
                              extra_headers={"X-Bovio-Filename": f.name})
        res = json.loads(raw.decode("utf-8", "replace"))
        if not res.get("ok"):
            raise RuntimeError(res.get("error") or ("файл %s відхилено" % f.name))
        state[f.name] = h
        sent += 1
    db.set_setting("profeed_fwd_state", json.dumps(state, ensure_ascii=False))
    db.set_setting("profeed_fwd_last", datetime.now().strftime("%Y-%m-%d %H:%M"))
    db.set_setting("profeed_fwd_error", "")
    if sent:
        db.bovio_log_add("profeed", "цей ПК → сервер · звітів Profeed: %d" % sent)
    return {"sent": sent}


@app.get("/api/bovio/profeed-fwd")
def api_profeed_fwd_info():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    return _ok({"on": db.get_setting("bovio_profeed_fwd", "0") == "1",
                "last": db.get_setting("profeed_fwd_last", ""),
                "error": db.get_setting("profeed_fwd_error", ""),
                "dir": db.get_setting("feed_profeed_dir", "")})


@app.post("/api/bovio/profeed-fwd")
def api_profeed_fwd_set():
    g = _bovio_admin_guard()
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    if "on" in d:
        db.set_setting("bovio_profeed_fwd", "1" if d.get("on") else "0")
    if d.get("now"):
        try:
            r = _profeed_forward_once()
        except Exception as exc:  # noqa: BLE001
            db.set_setting("profeed_fwd_error", str(exc))
            return jsonify({"ok": False, "error": str(exc)}), 502
        return _ok(r)
    return _ok({"on": db.get_setting("bovio_profeed_fwd", "0") == "1"})


def _start_profeed_forward() -> None:
    """Фоновий курʼєр звітів Profeed → серверна ферма (лише локальний режим)."""
    def loop():
        while True:
            time.sleep(600)
            try:
                if db.get_setting("bovio_profeed_fwd", "0") == "1":
                    _profeed_forward_once()
            except Exception as exc:  # noqa: BLE001
                try:
                    db.set_setting("profeed_fwd_error", str(exc)[:200])
                except Exception:  # noqa: BLE001
                    pass
    import threading
    threading.Thread(target=loop, daemon=True, name="profeed-fwd").start()


def _start_satellite_push() -> None:
    """Фонове надсилання черги супутника (лише локальний режим)."""
    def loop():
        last_ref = time.time()
        while True:
            time.sleep(60)
            try:
                if db.get_setting("bovio_satellite", "0") != "1":
                    continue
                if db.satellite_stats().get("pending"):
                    _satellite_push_once()
                # Обмін у ДВА боки сам: коли черга порожня — раз на N хвилин
                # тягнемо свіжу копію з сервера (те саме, що кнопка «⟳ Оновити
                # дані з сервера»). Роман 2026-09-08: «оновлюються автоматом
                # з сервером в дві сторони».
                try:
                    every = max(2, int(db.get_setting("bovio_sat_auto_min", "10") or 10))
                except ValueError:
                    every = 10
                if (time.time() - last_ref >= every * 60
                        and not db.satellite_stats().get("pending")):
                    _satellite_refresh()
                    last_ref = time.time()
                    db.set_setting("satellite_error", "")
            except Exception as exc:  # noqa: BLE001
                try:
                    db.set_setting("satellite_error", str(exc))
                    db.bovio_log_add("error", str(exc), ok=False)
                except Exception:  # noqa: BLE001
                    pass
    import threading
    threading.Thread(target=loop, daemon=True, name="satellite-push").start()


def _start_bovio_push() -> None:
    """Фоновий пуш знімків бази на серверну ферму (лише локальний режим)."""
    def loop():
        while True:
            time.sleep(60)
            try:
                cfg = _bovio_cfg()
                if not cfg["push_on"]:
                    continue
                last = cfg["last"]
                if last:
                    try:
                        dt = datetime.strptime(last, "%Y-%m-%d %H:%M")
                        if (datetime.now() - dt).total_seconds() < cfg["push_min"] * 60:
                            continue
                    except ValueError:
                        pass
                _bovio_push_once()
            except Exception as exc:  # noqa: BLE001
                try:
                    db.set_setting("bovio_push_error", str(exc))
                except Exception:  # noqa: BLE001
                    pass
    import threading
    threading.Thread(target=loop, daemon=True, name="bovio-push").start()




@app.get("/api/database/backup-dir")
def api_database_backup_dir_get():
    """Поточна папка резервних копій + чи можна її змінювати з UI."""
    return _ok({
        "path": str(db.backup_dir()),
        "default": str(db.default_backup_dir()),
        "locked": db.backup_dir_is_locked(),   # задано змінною середовища
        "saved": db.get_setting("backup_dir", ""),
    })


def _native_pick_folder(prompt: str = "Виберіть папку") -> tuple[str, Optional[str]]:
    """Нативний діалог вибору папки на боці сервера. Повертає (шлях, помилка).
    Порожній шлях без помилки = користувач скасував."""
    if sys.platform == "darwin":
        osa = (
            'tell application "System Events"\n'
            '    activate\n'
            f'    set theFolder to choose folder with prompt "{prompt}"\n'
            'end tell\n'
            'POSIX path of theFolder\n'
        )
        try:
            res = subprocess.run(["osascript", "-"], input=osa,
                                 capture_output=True, text=True, timeout=300)
        except Exception as exc:  # noqa: BLE001
            return "", f"Не вдалося відкрити діалог: {exc}. Впишіть шлях вручну."
        return (res.stdout or "").strip().rstrip("/"), None

    # Windows / Linux — tkinter, з примусовим виведенням наперед.
    script = (
        "import tkinter as tk\n"
        "from tkinter import filedialog\n"
        "r = tk.Tk(); r.withdraw()\n"
        "try:\n"
        "    r.attributes('-topmost', True); r.update()\n"
        "except Exception:\n"
        "    pass\n"
        f"p = filedialog.askdirectory(title={prompt!r})\n"
        "print(p or '')\n"
        "r.destroy()\n"
    )
    try:
        res = subprocess.run([sys.executable, "-c", script],
                             capture_output=True, text=True, timeout=300)
    except Exception as exc:  # noqa: BLE001
        return "", f"Не вдалося відкрити діалог: {exc}. Впишіть шлях вручну."
    lines = [ln for ln in (res.stdout or "").splitlines() if ln.strip()]
    path = lines[-1].strip() if lines else ""
    if not path and res.returncode != 0 and "tkinter" in (res.stderr or "").lower():
        return "", "На цьому комп'ютері немає графічного діалогу. Впишіть шлях вручну."
    return path, None


def _native_pick_file(prompt: str = "Виберіть файл") -> tuple[str, Optional[str]]:
    """Нативний діалог вибору файлу на боці сервера. Повертає (шлях, помилка).
    Порожній шлях без помилки = скасовано."""
    if sys.platform == "darwin":
        osa = (
            'tell application "System Events"\n'
            '    activate\n'
            f'    set theFile to choose file with prompt "{prompt}"\n'
            'end tell\n'
            'POSIX path of theFile\n'
        )
        try:
            res = subprocess.run(["osascript", "-"], input=osa,
                                 capture_output=True, text=True, timeout=300)
        except Exception as exc:  # noqa: BLE001
            return "", f"Не вдалося відкрити діалог: {exc}. Впишіть шлях вручну."
        return (res.stdout or "").strip(), None

    script = (
        "import tkinter as tk\n"
        "from tkinter import filedialog\n"
        "r = tk.Tk(); r.withdraw()\n"
        "try:\n"
        "    r.attributes('-topmost', True); r.update()\n"
        "except Exception:\n"
        "    pass\n"
        f"p = filedialog.askopenfilename(title={prompt!r}, "
        "filetypes=[('Excel','*.xlsx *.xlsm *.xls'), ('Усі файли','*.*')])\n"
        "print(p or '')\n"
        "r.destroy()\n"
    )
    try:
        res = subprocess.run([sys.executable, "-c", script],
                             capture_output=True, text=True, timeout=300)
    except Exception as exc:  # noqa: BLE001
        return "", f"Не вдалося відкрити діалог: {exc}. Впишіть шлях вручну."
    lines = [ln for ln in (res.stdout or "").splitlines() if ln.strip()]
    path = lines[-1].strip() if lines else ""
    if not path and res.returncode != 0 and "tkinter" in (res.stderr or "").lower():
        return "", "На цьому комп'ютері немає графічного діалогу. Впишіть шлях вручну."
    return path, None


@app.post("/api/pick-file")
def api_pick_file():
    """Вибрати файл через системний діалог (для полів шляху до Excel)."""
    path, err = _native_pick_file("Виберіть файл Excel")
    if err:
        return _err(err)
    return _ok({"path": path, "cancelled": not path})


@app.post("/api/database/pick-folder")
def api_database_pick_folder():
    """Вибрати папку для резервних копій через системний діалог."""
    if db.backup_dir_is_locked():
        return _err("Шлях задано змінною середовища VET_BACKUP_DIR — змінити не можна.")
    path, err = _native_pick_folder("Виберіть папку для резервних копій")
    if err:
        return _err(err)
    return _ok({"path": path, "cancelled": not path})


@app.post("/api/database/backup-dir")
def api_database_backup_dir_set():
    """Змінити папку резервних копій. Порожній шлях — повернути до типового."""
    if db.backup_dir_is_locked():
        return _err("Шлях задано змінною середовища VET_BACKUP_DIR — "
                    "змінити з інтерфейсу не можна.")
    data = request.get_json(silent=True) or {}
    raw = (data.get("path") or "").strip()
    if not raw:
        db.set_setting("backup_dir", "")
        return _ok({"path": str(db.backup_dir())})
    p = Path(raw).expanduser()
    # Перевіряємо, що папку можна створити й у неї можна писати.
    try:
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".write_test"
        test.write_text("ok", encoding="utf-8")
        test.unlink()
    except OSError as exc:
        return _err(f"Папка недоступна для запису: {exc}")
    db.set_setting("backup_dir", str(p))
    return _ok({"path": str(p)})


@app.get("/api/online-users")
def api_online_users():
    """Хто зараз онлайн (активні за останні ~3 хв)."""
    me = session.get("user_id")
    items = []
    for u in db.online_users(180):
        items.append({
            "id": u["id"],
            "name": u.get("full_name") or u.get("username") or "—",
            "role": u.get("role"),
            "is_me": u["id"] == me,
        })
    return _ok({"items": items})


@app.get("/api/version")
def api_version():
    """Версія додатка, версія структури БД та історія оновлень."""
    info = db.version_info(APP_VERSION)
    info["staged"] = updater.staged_info()   # підготовлене оновлення (або None)
    return _ok(info)


# ----------------------------------------------------- оновлення додатка

@app.get("/api/update/source")
def api_update_source_get():
    return _ok({
        "local": (db.get_setting("update_local_dir", "") or "").strip(),
        "default": DEFAULT_UPDATE_SOURCE,
        "effective": _effective_update_source(),
    })


@app.post("/api/update/source")
def api_update_source_set():
    data = request.get_json(silent=True) or {}
    db.set_setting("update_local_dir", (data.get("source") or "").strip())
    return _ok({
        "local": (db.get_setting("update_local_dir", "") or "").strip(),
        "default": DEFAULT_UPDATE_SOURCE,
        "effective": _effective_update_source(),
    })


@app.post("/api/update/pick-source-folder")
def api_update_pick_source_folder():
    """Вибрати папку-джерело оновлень через системний діалог."""
    path, err = _native_pick_folder("Виберіть папку з файлами оновлення")
    if err:
        return _err(err)
    return _ok({"path": path, "cancelled": not path})


@app.post("/api/update/check")
def api_update_check():
    """Перевірити джерело: чи є новіша версія."""
    source = _effective_update_source()
    res = updater.check_update(source, APP_VERSION)
    if not res.get("ok"):
        return _err(res.get("error", "Не вдалося перевірити оновлення."))
    _update_avail_cache.update(source=source, at=time.time(), result=res)
    return _ok(res)


# Легкий кеш авто-перевірки, щоб бейдж не читав/не качав джерело щоразу.
_update_avail_cache = {"source": None, "at": 0.0, "result": None}


@app.get("/api/update/available")
def api_update_available():
    """Тиха перевірка для показчика в меню. Кеш короткий для локальної папки
    (перевірка дешева) і довший для URL (щоб не качати щоразу)."""
    if SERVER_MODE:
        return _ok({"available": False})   # хмару оновлює адміністратор сервера
    source = _effective_update_source()
    if not source:
        return _ok({"available": False})
    is_url = source.strip().lower().startswith(("http://", "https://"))
    ttl = 120 if is_url else 15
    c = _update_avail_cache
    now = time.time()
    if c["source"] == source and c["result"] is not None and (now - c["at"]) < ttl:
        res = c["result"]
    else:
        res = updater.check_update(source, APP_VERSION)
        c.update(source=source, at=now, result=res)
    if not res.get("ok"):
        return _ok({"available": False, "error": res.get("error"),
                    "staged": bool(updater.staged_info())})
    return _ok({"available": bool(res.get("available")),
                "latest": res.get("latest"), "current": res.get("current"),
                "staged": bool(updater.staged_info())})


@app.post("/api/update/apply")
def api_update_apply():
    """Підготувати (застейджити) оновлення. Застосується при перезапуску."""
    source = _effective_update_source()
    data = request.get_json(silent=True) or {}
    res = updater.stage_update(source, APP_VERSION,
                               allow_same=bool(data.get("allow_same")))
    if not res.get("ok"):
        return _err(res.get("error", "Не вдалося підготувати оновлення."))
    return _ok({"app_version": res.get("app_version"),
                "message": "Оновлення підготовлено. Перезапустіть сервер, "
                           "щоб застосувати (буде зроблено копію коду й бази)."})


def _restart_marker() -> Path:
    """Файл-прохання «перезапусти мене»: сервер не може надійно перезапустити
    себе сам під лаунчером (на Windows execv міняє PID і трей губить процес),
    тож просимо лаунчер. Якщо ніхто не відгукнувся — перезапускаємось самі."""
    from vet_pharmacy import web_db
    return web_db._local_data_dir() / "restart.flag"


def _self_restart_later(delay: float = 1.5) -> None:
    """Перезапуск застосунку після встановлення оновлення (Роман 2026-09-09:
    «було б гарно, якби і сервер на локальному ПК автоматом перезапустився»).

    Спершу лишаємо мітку — новий лаунчер підхопить її і перезапустить сервер
    рідним способом (трей і далі керує процесом). Якщо за кілька секунд мітка
    на місці (старий лаунчер або запуск без нього) — стартуємо себе самі."""
    import threading

    def run() -> None:
        time.sleep(delay)
        mark = _restart_marker()
        try:
            mark.parent.mkdir(parents=True, exist_ok=True)
            mark.write_text(datetime.now().isoformat(timespec="seconds"),
                            encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        for _ in range(12):            # ~6 с на реакцію лаунчера
            time.sleep(0.5)
            if not mark.exists():
                return                 # лаунчер перезапускає — нам більше нічого робити
        try:
            mark.unlink(missing_ok=True)
        except Exception:  # noqa: BLE001
            pass
        here = Path(__file__).resolve().parent
        port = os.environ.get("FARM_HTTP_PORT", "5050")
        # Окремий процес-«піднімач»: чекає, поки цей сервер справді звільнить
        # порт, і аж тоді стартує новий. Через execv так не виходить — відкриті
        # сокети успадковуються, і новий сервер стає в тінь старого (перевірено:
        # порт лишався за мертвим сокетом, сторінка не відповідала).
        code = (
            "import socket,subprocess,sys,os,time\n"
            "port=int(sys.argv[1]); exe=sys.argv[2]; script=sys.argv[3]; cwd=sys.argv[4]\n"
            "for _ in range(120):\n"
            "    time.sleep(0.5)\n"
            "    try:\n"
            "        socket.create_connection(('127.0.0.1', port), 0.5).close()\n"
            "    except OSError:\n"
            "        break\n"
            "kw={}\n"
            "if os.name=='nt':\n"
            "    kw['creationflags']=(getattr(subprocess,'DETACHED_PROCESS',0)"
            "|getattr(subprocess,'CREATE_NO_WINDOW',0))\n"
            "subprocess.Popen([exe,script,'--no-browser','--port',str(port)],cwd=cwd,**kw)\n")
        try:
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = (getattr(subprocess, "DETACHED_PROCESS", 0)
                                       | getattr(subprocess, "CREATE_NO_WINDOW", 0))
            else:
                kw["start_new_session"] = True
            subprocess.Popen([sys.executable, "-c", code, port, sys.executable,
                              str(here / "start_server.py"), str(here)],
                             close_fds=True, **kw)
        except Exception:  # noqa: BLE001
            pass
        os._exit(0)                    # звільняємо порт — «піднімач» підхопить

    threading.Thread(target=run, daemon=True, name="self-restart").start()


@app.post("/api/update/restart")
def api_update_restart():
    """Перезапустити застосунок, щоб підготовлене оновлення застосувалось."""
    # Оновлення СВОГО компʼютера — не дані ферми, тож доступне будь-якому
    # користувачу (Роман 2026-09-09: «кожен працює окремо», у працівника може
    # не бути адміністратора під рукою).
    if SERVER_MODE:
        return _err("У хмарі оновлення робить адміністратор сервера.", 404)
    if not updater.staged_info():
        return _err("Немає підготовленого оновлення.")
    _self_restart_later()
    return _ok({"restarting": True})


@app.post("/api/update/cancel")
def api_update_cancel():
    updater.cancel_staged()
    return _ok()


def _start_update_notify() -> None:
    """Фонове сповіщення в Telegram про доступне оновлення — один раз на версію.
    Використовує той самий бот/чат, що й щоденний дайджест."""
    import threading

    def loop():
        time.sleep(60)  # не гальмувати старт
        while True:
            try:
                if db.get_setting("notify_updates", "1") == "1":
                    source = _effective_update_source()
                    token = db.get_setting("notify_tg_token", "")
                    chat = db.get_setting("notify_tg_chat", "")
                    if source and token and chat:
                        res = updater.check_update(source, APP_VERSION)
                        if res.get("ok"):
                            _update_avail_cache.update(
                                source=source, at=time.time(), result=res)
                            latest = str(res.get("latest") or "")
                            already = db.get_setting("notify_update_last", "")
                            if res.get("available") and latest and already != latest:
                                notes = (res.get("notes") or "").strip()
                                msg = (f"🆕 Доступне оновлення {latest}\n"
                                       f"Поточна версія: {res.get('current')}")
                                if notes:
                                    msg += f"\n\nЩо нового:\n{notes}"
                                msg += "\n\nВстановити: Налаштування → Оновлення."
                                ok, _m = db.send_telegram(token, chat, msg)
                                if ok:
                                    db.set_setting("notify_update_last", latest)
            except Exception:  # noqa: BLE001
                pass
            time.sleep(300)  # кожні 5 хв

    threading.Thread(target=loop, daemon=True, name="update-notify").start()


def _profeed_every_min() -> int:
    """Періодичність автозавантаження у хвилинах (1…1440)."""
    raw = (db.get_setting("profeed_api_every_min", "") or "").strip()
    if not raw:                       # сумісність зі старим значенням у годинах
        try:
            raw = str(int(float(db.get_setting("profeed_api_every_h", "1") or 1)) * 60)
        except (TypeError, ValueError):
            raw = "60"
    try:
        return max(1, min(1440, int(float(raw))))
    except (TypeError, ValueError):
        return 60


def _profeed_window() -> tuple:
    """Вікно активності автозавантаження (з, по) у форматі HH:MM.
    Порожні значення = цілодобово."""
    a = (db.get_setting("profeed_api_from", "") or "").strip()[:5]
    b = (db.get_setting("profeed_api_to", "") or "").strip()[:5]
    return (a, b)


def _profeed_in_window(when: datetime, win: tuple = None) -> bool:
    """Чи потрапляє момент у дозволене вікно (підтримує перехід через північ)."""
    a, b = win if win is not None else _profeed_window()
    if not a or not b or a == b:
        return True
    cur = when.strftime("%H:%M")
    return (a <= cur <= b) if a < b else (cur >= a or cur <= b)


def _profeed_window_bounds(now_dt: datetime):
    """(start, end) вікна, що МІСТИТЬ now_dt, або None (немає вікна / поза ним)."""
    a, b = _profeed_window()
    if not a or not b or a == b:
        return None
    try:
        ah, am = (int(x) for x in a.split(":"))
        bh, bm = (int(x) for x in b.split(":"))
    except (TypeError, ValueError):
        return None
    for shift in (0, -1):                          # сьогодні або вікно з учора
        start = (now_dt + timedelta(days=shift)).replace(
            hour=ah, minute=am, second=0, microsecond=0)
        end = start.replace(hour=bh, minute=bm, second=0, microsecond=0)
        if end <= start:                           # вікно через північ
            end += timedelta(days=1)
        if start <= now_dt <= end:
            return (start, end)
    return None


def _profeed_prev_slot(last_ts: float, every_min: int, now: float = None):
    """timestamp останнього слоту сітки, що вже НАСТАВ (<= зараз) у поточному
    вікні. None — якщо зараз поза вікном або вікна немає."""
    every = max(1, int(every_min or 60)) * 60
    now = now if now is not None else time.time()
    now_dt = datetime.fromtimestamp(now)
    wb = _profeed_window_bounds(now_dt)
    if not wb:
        return None
    start, _end = wb
    k = int((now - start.timestamp()) // every)    # скільки повних кроків минуло
    return start.timestamp() + k * every


def _profeed_due(last_ts: float, every_min: int, now: float = None) -> bool:
    """Чи НАСТАВ час автозавантаження (стійко до затримки перевірки).

    Без вікна — коли минув інтервал від останнього запуску. З вікном — коли
    в поточному вікні є слот сітки <= зараз, для якого ще не було завантаження
    (last_ts < цей слот)."""
    now = now if now is not None else time.time()
    a, b = _profeed_window()
    if not a or not b or a == b:                   # без вікна
        every = max(1, int(every_min or 60)) * 60
        return (not last_ts) or (now - last_ts) >= every
    if not _profeed_in_window(datetime.fromtimestamp(now), (a, b)):
        return False
    slot = _profeed_prev_slot(last_ts, every_min, now)
    if slot is None:
        return False
    return last_ts < slot - 1                       # ще не тягнули для цього слоту


def _profeed_next_ts(last_ts: float, every_min: int) -> float:
    """Час НАСТУПНОГО запуску (для показу). Якщо час уже настав — «зараз»."""
    every = max(1, int(every_min or 60)) * 60
    now = time.time()
    if _profeed_due(last_ts, every_min, now):
        return now
    a, b = _profeed_window()
    if not a or not b or a == b:
        return max((last_ts + every) if last_ts else now, now)
    try:
        ah, am = (int(x) for x in a.split(":"))
        bh, bm = (int(x) for x in b.split(":"))
    except (TypeError, ValueError):
        return max((last_ts + every) if last_ts else now, now)
    now_dt = datetime.fromtimestamp(now)
    # шукаємо перший слот сітки строго ПІСЛЯ «зараз» у найближчому вікні
    for shift in range(0, 3):
        start = (now_dt + timedelta(days=shift)).replace(
            hour=ah, minute=am, second=0, microsecond=0)
        end = start.replace(hour=bh, minute=bm, second=0, microsecond=0)
        if end <= start:
            end += timedelta(days=1)
        if now < start.timestamp():                 # вікно ще попереду
            return start.timestamp()
        if now <= end.timestamp():                  # ми всередині — наступний слот
            k = int((now - start.timestamp()) // every) + 1
            slot = start.timestamp() + k * every
            if slot <= end.timestamp():
                return slot
        # інакше — вікно вже минуло, беремо початок наступного
    return now + every


def _profeed_api_cfg() -> dict:
    """Налаштування доступу до Profeed API (пароль назовні не віддаємо)."""
    return {
        "email": (db.get_setting("profeed_api_email", "") or "").strip(),
        "password": db.get_setting("profeed_api_pass", "") or "",
        "farm": (db.get_setting("profeed_api_farm", "") or "").strip(),
        "report": (db.get_setting("profeed_api_report", "") or "").strip(),
        "language": (db.get_setting("profeed_api_lang", "uk") or "uk").strip(),
        "token": db.get_setting("profeed_api_token", "") or "",
        "auto": (db.get_setting("profeed_api_auto", "0") or "0") == "1",
        # періодичність у ХВИЛИНАХ (старе налаштування в годинах — переносимо)
        "every_min": _profeed_every_min(),
        # аварійний режим «без перевірки сертифіката» — з UI прибрано; лишається
        # лише як прихована опція в базі (profeed_api_insecure=1) на крайній випадок
        "insecure": (db.get_setting("profeed_api_insecure", "0") or "0") == "1",
        "yday": (db.get_setting("profeed_api_yday", "1") or "1") == "1",
        "fname": (db.get_setting("profeed_api_fname", "") or "").strip(),
        "from": _profeed_window()[0],
        "to": _profeed_window()[1],
        "last": (db.get_setting("profeed_api_last", "") or "").strip(),
        "status": (db.get_setting("profeed_api_status", "") or "").strip(),
    }


def _profeed_state() -> dict:
    """Стан завантажень по днях: {'today': {...}, 'yesterday': {...}}."""
    try:
        return json.loads(db.get_setting("profeed_api_state", "") or "{}") or {}
    except Exception:  # noqa: BLE001
        return {}


def profeed_fetch_now(do_import: bool = True, user_id=None,
                      source: str = "auto") -> dict:
    """Завантажити звіт Profeed за СЬОГОДНІ (і за ВЧОРА, якщо увімкнено) —
    кожен день окремим файлом — та одразу списати нові заміси.
    Повертає {items: [{slot, day, name, replaced, error}], imported}."""
    import profeed_api

    cfg = _profeed_api_cfg()
    profeed_api.INSECURE = bool(cfg.get("insecure"))
    folder = (db.get_setting("feed_profeed_dir", "") or "").strip()
    if not folder:
        raise profeed_api.ProfeedError("Спершу вкажіть теку звітів Profeed.")
    if not cfg["email"] or not cfg["password"]:
        raise profeed_api.ProfeedError("Вкажіть email і пароль Profeed.")
    if not cfg["farm"] or not cfg["report"]:
        raise profeed_api.ProfeedError("Вкажіть ферму (farm) і код звіту.")

    today = date.today()
    days = [("today", today.isoformat())]
    if cfg.get("yday"):
        days.append(("yesterday", (today - timedelta(days=1)).isoformat()))
    state, items, ok_any = _profeed_state(), [], False
    now_s = f"{datetime.now():%Y-%m-%d %H:%M}"
    for slot, day in days:
        rec = {"slot": slot, "day": day, "at": now_s}
        try:
            res = profeed_api.download(cfg, day, day, folder)
            if res.get("token") and res["token"] != cfg["token"]:
                db.set_setting("profeed_api_token", res["token"])
                cfg["token"] = res["token"]
            rec.update({"name": res.get("name", ""), "replaced": res.get("replaced"),
                        "size": res.get("size", 0), "ok": True,
                        "path": res.get("file", "")})   # повний шлях — видно в журналі
            ok_any = True
        except Exception as exc:  # noqa: BLE001
            rec.update({"ok": False, "error": str(exc)})
        state[slot] = rec
        items.append(rec)

    imported = 0
    if do_import and ok_any:
        try:
            imp = db.auto_writeoff_feedings(user_id=user_id) or {}
            imported = int(imp.get("done_count") or 0)
            if imp.get("error"):
                for r in items:
                    r.setdefault("import_error", imp["error"])
        except Exception as exc:  # noqa: BLE001
            for r in items:
                r.setdefault("import_error", str(exc))
    if not cfg.get("yday"):
        state.pop("yesterday", None)
    state["imported"] = imported
    state["at"] = now_s
    db.set_setting("profeed_api_state", json.dumps(state, ensure_ascii=False))
    try:                                  # журнал завантажень (контроль виконання)
        db.profeed_log_add([dict(r, imported=imported) for r in items], source)
    except Exception:  # noqa: BLE001
        pass
    err = next((r.get("error") for r in items if r.get("error")), "")
    db.set_setting("profeed_api_status",
                   f"{now_s} · списано замісів: {imported}"
                   + (f" · помилка: {err}" if err else ""))
    # мітка часу останнього завантаження — оновлюємо ТУТ (і для ручного, і для
    # автоматичного), щоб розклад «наступного запуску» рахувався від реального
    # завантаження, а не лише від фонового циклу.
    db.set_setting("profeed_api_last_ts", str(time.time()))
    db.set_setting("profeed_api_last", now_s)
    if not ok_any:                       # обидва дні впали — це помилка
        raise profeed_api.ProfeedError(err or "Не вдалося завантажити звіти.")
    return {"items": items, "imported": imported, "at": now_s}


@app.get("/api/feed/profeed-api/config")
def api_profeed_api_cfg_get():
    c = _profeed_api_cfg()
    c.pop("token", None)
    c["has_password"] = bool(c.pop("password", ""))
    c["dir"] = (db.get_setting("feed_profeed_dir", "") or "").strip()
    # коли планувальник забере звіт наступного разу
    try:
        last_ts = float(db.get_setting("profeed_api_last_ts", "0") or 0)
    except (TypeError, ValueError):
        last_ts = 0.0
    nxt = _profeed_next_ts(last_ts, c["every_min"])
    c["next_ts"] = int(nxt)
    c["next_at"] = f"{datetime.fromtimestamp(nxt):%Y-%m-%d %H:%M}"
    c["now_ts"] = int(time.time())
    return _ok({"config": c, "state": _profeed_state()})


@app.post("/api/feed/profeed-api/config")
def api_profeed_api_cfg_set():
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    db.set_setting("profeed_api_email", (d.get("email") or "").strip())
    if d.get("password"):                       # порожнє поле — пароль не міняємо
        db.set_setting("profeed_api_pass", d.get("password"))
        db.set_setting("profeed_api_token", "")     # логін змінився — токен скидаємо
    db.set_setting("profeed_api_farm", str(d.get("farm") or "").strip())
    db.set_setting("profeed_api_report", (d.get("report") or "").strip())
    # мова звіту завжди українська — під неї налаштований розбір заголовків
    db.set_setting("profeed_api_lang", "uk")
    db.set_setting("profeed_api_auto", "1" if d.get("auto") else "0")
    try:
        every = max(1, min(1440, int(float(d.get("every_min") or 60))))
    except (TypeError, ValueError):
        every = 60
    db.set_setting("profeed_api_every_min", str(every))
    if "insecure" in d:                   # з UI не надсилається; лише сумісність
        db.set_setting("profeed_api_insecure", "1" if d.get("insecure") else "0")
    db.set_setting("profeed_api_yday", "1" if d.get("yday") else "0")
    db.set_setting("profeed_api_fname", (d.get("fname") or "").strip())
    db.set_setting("profeed_api_from", (d.get("from") or "").strip()[:5])
    db.set_setting("profeed_api_to", (d.get("to") or "").strip()[:5])
    return _ok({"saved": True})


@app.get("/api/feed/profeed-api/log")
def api_profeed_api_log():
    """Журнал завантажень звітів (час, день, файл, статус)."""
    try:
        lim = int(request.args.get("limit") or 15)     # журнали — 15 записів
    except (TypeError, ValueError):
        lim = 15
    try:
        items = db.profeed_log_list(lim)
        # якщо розмір у журналі не записано (старі записи) — беремо з файлу в теці
        folder = (db.get_setting("feed_profeed_dir", "") or "").strip()
        if folder:
            for it in items:
                if not it.get("size") and it.get("name"):
                    try:
                        it["size"] = Path(folder, it["name"]).stat().st_size
                    except Exception:  # noqa: BLE001
                        pass
        return _ok({"items": items})
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/feed/profeed-api/test")
def api_profeed_api_test():
    """Перевірити доступ: логін/токен без завантаження звіту."""
    import profeed_api
    cfg = _profeed_api_cfg()
    profeed_api.INSECURE = bool(cfg.get("insecure"))
    try:
        tok = profeed_api.ensure_token(cfg["email"], cfg["password"], cfg["token"])
        db.set_setting("profeed_api_token", tok)
        return _ok({"ok": True, "note": "Доступ до Profeed працює."})
    except profeed_api.ProfeedError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


@app.post("/api/feed/profeed-api/fetch")
def api_profeed_api_fetch():
    """Завантажити звіт зараз (за період) + за потреби одразу списати."""
    import profeed_api
    g = _manage_guard("feed")
    if g is not None:
        return g
    d = request.get_json(silent=True) or {}
    try:
        res = profeed_fetch_now(bool(d.get("do_import", True)),
                                session.get("user_id"), "вручну")
        return _ok(res)
    except profeed_api.ProfeedError as exc:
        return _err(str(exc))
    except Exception as exc:  # noqa: BLE001
        return _err(f"Помилка: {exc}")


def _start_profeed_fetch() -> None:
    """Періодичне автозавантаження звіту Profeed за ПОТОЧНИЙ день (і за вчора,
    якщо увімкнено) з перезаписом файлу і списанням нових замісів. Звіт за добу
    доповнюється, тому щоразу забираємо свіжу версію. Керується
    profeed_api_auto / profeed_api_every_min (хвилини)."""
    import threading

    def loop():
        while True:
            try:
                time.sleep(20)
                cfg = _profeed_api_cfg()
                if not cfg["auto"]:
                    continue
                now = datetime.now()
                try:
                    last_ts = float(db.get_setting("profeed_api_last_ts", "0") or 0)
                except (TypeError, ValueError):
                    last_ts = 0.0
                # «Чи настав час?» — стійко до того, що перевірка спрацьовує на
                # кілька секунд ПІСЛЯ рівного слоту (напр. 10:00:05, а не 10:00:00).
                if not _profeed_due(last_ts, cfg.get("every_min") or 60):
                    continue
                try:
                    profeed_fetch_now(True, None, "авто")   # сам оновлює last_ts/last
                except Exception as exc:  # noqa: BLE001
                    db.set_setting("profeed_api_status",
                                   f"{now:%Y-%m-%d %H:%M} · помилка: {exc}")
                    # позначаємо спробу, щоб не «молотити» щохвилини при збої
                    db.set_setting("profeed_api_last_ts", str(time.time()))
                    db.set_setting("profeed_api_last", f"{now:%Y-%m-%d %H:%M}")
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="profeed-fetch").start()


def _start_feed_autowriteoff() -> None:
    """Автосписання годівлі раз на день: списує нові роздачі зі звітів Profeed
    (тека з налаштувань), ідемпотентно. Керується налаштуванням
    feed_auto_writeoff (за замовчуванням увімкнено). Не навантажує систему —
    прохід лише раз на добу після заданого часу."""
    import threading

    def loop():
        while True:
            try:
                time.sleep(60)
                if (db.get_setting("feed_auto_writeoff", "1") or "1") != "1":
                    continue
                if not (db.get_setting("feed_profeed_dir", "") or "").strip():
                    continue
                target = db.get_setting("feed_writeoff_time", "06:30")
                now = datetime.now()
                cur, today = now.strftime("%H:%M"), now.strftime("%Y-%m-%d")
                if cur >= target and db.get_setting("feed_writeoff_last", "") != today:
                    try:
                        db.auto_writeoff_feedings()
                    finally:
                        db.set_setting("feed_writeoff_last", today)
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="feed-writeoff").start()


def _start_feed_pool_auto() -> None:
    """«Розподіл залишків як попереднього дня» — раз на 10 хв.

    Залишки приходять із колонки звіту Profeed самі, а розподіл пулу (куди
    пішов залишок) лишався ручним кроком: із 03.09 у клієнта 400 кг/день
    висіли нерозподіленими і рахувались утилізацією. Автоматика повторює
    останній напрямок; ручний розподіл не чіпає."""
    import threading

    def loop():
        time.sleep(120)
        while True:
            try:
                if (db.get_setting("feed_pool_auto", "1") or "1") == "1":
                    done = db.feed_pool_autodist()
                    if done:
                        db.set_setting(
                            "feed_pool_auto_last",
                            "%s · днів: %d" % (datetime.now().strftime("%Y-%m-%d %H:%M"),
                                               len(done)))
            except Exception:  # noqa: BLE001
                pass
            time.sleep(600)
    threading.Thread(target=loop, daemon=True, name="feed-pool-auto").start()


if not SERVER_MODE:
    _start_update_notify()      # пакетні оновлення — лише локальні ферми
_start_milk_notify()
_start_wh_notify()
def _start_milk_excel_sync() -> None:
    """Фонове оновлення молока з Excel у БД — раз на 10 хвилин, щоб дані
    підтягувались самі, а не лише при відкритті сторінок молока."""
    import threading

    def loop():
        time.sleep(90)                      # дати застосунку спокійно піднятись
        while True:
            try:
                _milk_ingest("", "")
            except Exception:  # noqa: BLE001
                pass
            time.sleep(600)

    threading.Thread(target=loop, daemon=True).start()


if not SERVER_MODE or ONEDRIVE_ROOT:
    _start_milk_excel_sync()   # Excel: диск клієнта або тека OneDrive на сервері
_start_tg_milk_sync()      # обмін із Telegram-ботом на сервері
_start_feed_auto()         # автосписання таблиць видачі кормів
_start_feed_pool_auto()    # розподіл залишків «як попереднього дня'
if not SERVER_MODE:
    _start_bovio_push()    # знімки бази → серверне дзеркало (якщо увімкнено)
    _start_satellite_push()  # черга операцій супутника → серверна ферма
    _start_profeed_forward()  # курʼєр звітів Profeed → серверна ферма
_start_feed_autowriteoff()
_start_profeed_fetch()
# Локальний Telegram-бот вимкнено: персонал і бот переїхали на сервер
# (webhook). Один токен не можна опитувати локально й через webhook водночас.


def _updates_inbox_dir() -> Path:
    """Папка-приймач оновлень. Якщо джерело — локальна папка, беремо її;
    інакше (URL або порожньо) — локальна FarmDB/releases."""
    src = (db.get_setting("update_local_dir", "") or "").strip()
    if src and not src.lower().startswith(("http://", "https://")):
        p = Path(src).expanduser()
        if p.suffix.lower() == ".zip":      # якщо вказали окремий файл — беремо його папку
            p = p.parent
        return p
    return updater.STATE_DIR / "releases"


@app.post("/api/update/upload")
def api_update_upload():
    """Прийняти файл farm_update_*.zip (напр. з пошти), скопіювати його в папку
    оновлень — далі працює звичайний механізм (перевірка/показчик/Оновити)."""
    f = request.files.get("file")
    if not f or not f.filename:
        return _err("Файл не вибрано")
    if not f.filename.lower().endswith(".zip"):
        return _err("Потрібен файл оновлення .zip (farm_update_…).")
    tmp = Path(tempfile.gettempdir()) / f"upload_update_{secrets.token_hex(4)}.zip"
    try:
        f.save(tmp)
        # перевіряємо, що це справді пакет оновлення, і дізнаємось версію
        manifest = updater._read_manifest_from_zip(tmp)
        if not manifest or not str(manifest.get("app_version", "")).strip():
            return _err("Це не схоже на файл оновлення (немає update.json).")
        version = str(manifest["app_version"]).strip()
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:
                return _err("Файл пошкоджено (zip).")
            if not any(n.startswith("code/") and not n.endswith("/") for n in z.namelist()):
                return _err("У файлі немає коду (папки code/).")
        inbox = _updates_inbox_dir()
        inbox.mkdir(parents=True, exist_ok=True)
        dest = inbox / f"farm_update_{version}.zip"
        dest.write_bytes(tmp.read_bytes())
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося обробити файл: {exc}")
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    # якщо локальну папку ще не задано — фіксуємо цю папку як локальне джерело
    cur = (db.get_setting("update_local_dir", "") or "").strip()
    if not cur:
        db.set_setting("update_local_dir", str(inbox))
    return _ok({"app_version": version, "source": str(inbox),
                "message": "Файл додано до папки оновлень."})


# ----------------------------------------------------- ліцензія

def _activate_license(key: str) -> tuple[bool, str]:
    """Перевіряє ключ і прив'язку до компанії, зберігає. (ok, помилка)."""
    key = (key or "").strip()
    if not key:
        return False, "Вставте ліцензійний ключ."
    data = licensing.verify_token(key)
    if not data:
        return False, "Ключ недійсний — підпис не збігається."
    # Привязка до ПК: якщо у ключі є код активації — він має збігатися з кодом
    # цього ПК. (Старі ключі без коду — проходять, для сумісності.)
    sn = str(data.get("sn", "")).strip()
    if sn:
        try:
            local = licensing.activation_code()
        except Exception:  # noqa: BLE001
            local = ""
        if local and sn != local:
            return False, ("Ключ виданий для іншого ПК — код активації не "
                           "збігається. Перевірте, що ключ зробили саме під цей ПК.")
    lic_company = str(data.get("company", "")).strip()
    cfg = (db.get_setting("company_name", "") or "").strip()
    if cfg:
        if cfg.casefold() != lic_company.casefold():
            return False, (f"Ключ виданий для компанії «{lic_company}», "
                           f"а у програмі вказано «{cfg}». Перевірте назву.")
    elif lic_company:
        # перша активація задає «Мою компанію» з ключа
        db.set_setting("company_name", lic_company)
    db.set_setting("license_key", key)
    return True, ""


@app.get("/api/license")
def api_license_get():
    return _ok(_license_status())


@app.post("/api/license")
def api_license_set():
    data = request.get_json(silent=True) or {}
    ok, err = _activate_license(data.get("key") or "")
    if not ok:
        return _err(err)
    return _ok(_license_status())


@app.post("/api/license/upload")
def api_license_upload():
    f = request.files.get("file")
    if not f or not f.filename:
        return _err("Файл не вибрано")
    try:
        key = f.read().decode("utf-8", "ignore").strip()
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося прочитати файл: {exc}")
    ok, err = _activate_license(key)
    if not ok:
        return _err(err)
    return _ok(_license_status())


@app.post("/api/license/company")
def api_license_company():
    """Встановити/змінити «Мою компанію» (для прив'язки ліцензії)."""
    data = request.get_json(silent=True) or {}
    db.set_setting("company_name", (data.get("company") or "").strip())
    return _ok(_license_status())


# ----------------------------------------------------- аналітика (Power BI)

_POWERBI_README = """Аналітика для Power BI
======================
Ці CSV-файли — готова до аналізу «зірчаста схема». Підключення:

Power BI → Отримати дані → OneDrive/SharePoint (папка) або «Текст/CSV».
Зв'яжіть таблиці за ключами:
  fact_moves.product_id   → dim_products.product_id
  fact_moves.block_id     → dim_blocks.id
  fact_moves.recipient_id → dim_recipients.id
  fact_moves.supplier_id  → dim_suppliers.id
  fact_moves.batch_id     → dim_batches.batch_id

Файли:
  fact_moves.csv     — усі рухи (прихід/видача/списання/повернення).
                       qty_signed / total_signed уже зі знаком (+прихід, −видача).
  stock_current.csv  — поточні залишки й вартість по товарах.
  dim_*.csv          — довідники.
  meta.csv           — час експорту й кількість рядків.
  dictionary_uk.csv  — українські назви всіх колонок (для перейменування
                       полів у Power BI: Таблиця → Колонка (en) → Українська назва).

Колонка branch: «Аптека» / «Матеріали».
Кодування UTF-8 (з BOM). Оновлюється автоматично за розкладом.
"""


def _analytics_dir_locked() -> bool:
    return bool(os.environ.get("VET_ANALYTICS_DIR"))


@app.get("/api/analytics/info")
def api_analytics_info():
    d = db.analytics_dir()
    files = []
    try:
        for p in sorted(d.glob("*.csv")):
            files.append({"name": p.name, "size": p.stat().st_size})
    except OSError:
        pass
    return _ok({
        "dir": str(d),
        "default": str(db.default_analytics_dir()),
        "locked": _analytics_dir_locked(),
        "enabled": db.get_setting("analytics_enabled", "0") == "1",
        "interval_min": db.get_setting("analytics_interval_min", "20"),
        "last_export": db.get_setting("analytics_last_export", ""),
        "files": files,
    })


@app.post("/api/analytics/dir")
def api_analytics_dir_set():
    if _analytics_dir_locked():
        return _err("Шлях задано змінною середовища VET_ANALYTICS_DIR.")
    data = request.get_json(silent=True) or {}
    raw = (data.get("path") or "").strip()
    if not raw:
        db.set_setting("analytics_dir", "")
        return _ok({"dir": str(db.analytics_dir())})
    p = Path(raw).expanduser()
    try:
        p.mkdir(parents=True, exist_ok=True)
        t = p / ".write_test"; t.write_text("ok", encoding="utf-8"); t.unlink()
    except OSError as exc:
        return _err(f"Папка недоступна для запису: {exc}")
    db.set_setting("analytics_dir", str(p))
    return _ok({"dir": str(p)})


@app.post("/api/analytics/pick-dir")
def api_analytics_pick_dir():
    path, err = _native_pick_folder("Виберіть папку для аналітики (в OneDrive)")
    if err:
        return _err(err)
    return _ok({"path": path, "cancelled": not path})


@app.post("/api/analytics/toggle")
def api_analytics_toggle():
    data = request.get_json(silent=True) or {}
    db.set_setting("analytics_enabled", "1" if data.get("enabled") else "0")
    if data.get("interval_min"):
        db.set_setting("analytics_interval_min", str(data.get("interval_min")))
    return _ok({"enabled": db.get_setting("analytics_enabled", "0") == "1"})


@app.post("/api/analytics/export-now")
def api_analytics_export_now():
    try:
        res = db.export_analytics()
    except Exception as exc:  # noqa: BLE001
        return _err(f"Не вдалося експортувати: {exc}")
    return _ok(res)


@app.get("/api/notify/info")
def api_notify_info():
    """Поточні налаштування сповіщень (без показу повного токена)."""
    g = db.get_setting
    token = g("notify_tg_token", "")
    return _ok({
        "enabled": g("notify_enabled", "0") == "1",
        "time": g("notify_time", "08:00"),
        "chat_id": g("notify_tg_chat", ""),
        "has_token": bool(token),
        "token_hint": (token[:6] + "…" + token[-4:]) if len(token) > 12 else "",
        "expiry_days": g("notify_expiry_days", "30"),
        "inc_low": g("notify_inc_low", "1") == "1",
        "inc_expiring": g("notify_inc_expiring", "1") == "1",
        "inc_expired": g("notify_inc_expired", "1") == "1",
        "inc_daily": g("notify_inc_daily", "0") == "1",
        "branch_pharmacy": g("notify_branch_pharmacy", "1") == "1",
        "branch_materials": g("notify_branch_materials", "1") == "1",
        "updates": g("notify_updates", "1") == "1",
        "last_sent": g("notify_last_sent", ""),
    })


@app.post("/api/notify/settings")
def api_notify_settings():
    data = request.get_json(silent=True) or {}
    s = db.set_setting
    s("notify_enabled", "1" if data.get("enabled") else "0")
    if "time" in data:
        s("notify_time", str(data.get("time") or "08:00")[:5])
    if "chat_id" in data:
        s("notify_tg_chat", str(data.get("chat_id") or "").strip())
    # токен оновлюємо лише якщо передали непорожній (щоб не затерти збережений)
    tok = (data.get("token") or "").strip()
    if tok:
        s("notify_tg_token", tok)
    if data.get("clear_token"):
        s("notify_tg_token", "")
    if "expiry_days" in data:
        try:
            s("notify_expiry_days", str(int(data.get("expiry_days") or 30)))
        except (TypeError, ValueError):
            pass
    for k, key in (("inc_low", "notify_inc_low"),
                   ("inc_expiring", "notify_inc_expiring"),
                   ("inc_expired", "notify_inc_expired"),
                   ("inc_daily", "notify_inc_daily"),
                   ("branch_pharmacy", "notify_branch_pharmacy"),
                   ("branch_materials", "notify_branch_materials"),
                   ("updates", "notify_updates")):
        if k in data:
            s(key, "1" if data.get(k) else "0")
    return _ok()


@app.post("/api/notify/test")
def api_notify_test():
    """Надіслати тестовий дайджест негайно."""
    # дозволяємо передати токен/chat прямо із форми (ще не збережені)
    data = request.get_json(silent=True) or {}
    tok = (data.get("token") or "").strip()
    chat = (data.get("chat_id") or "").strip()
    if tok:
        db.set_setting("notify_tg_token", tok)
    if chat:
        db.set_setting("notify_tg_chat", chat)
    ok, msg = db.send_digest_now(test=True)
    if not ok:
        return _err(f"Не вдалося надіслати: {msg}")
    return _ok({"message": "Надіслано"})


@app.post("/api/milk/delete-day")
def api_milk_delete_day():
    """Видалити день надою/продажу з БД (для ручних записів)."""
    data = request.get_json(silent=True) or {}
    which = (data.get("which") or "yields").strip()
    day = (data.get("day") or "")[:10]
    if not day:
        return _err("Не вказано день")
    if which == "sales":
        db.delete_milk_sales_day(day)
    else:
        db.delete_milk_day(day)
    return _ok()


@app.post("/api/milk/register/update")
def api_milk_register_update():
    """Редагування комірки реєстру (лише ручні записи): kg / amount / by."""
    data = request.get_json(silent=True) or {}
    which = (data.get("which") or "yields").strip()
    day = (data.get("day") or "")[:10]
    field = (data.get("field") or "").strip()
    value = data.get("value")
    shift = data.get("shift") or 1
    if not day or field not in ("kg", "amount", "by"):
        return _err("Невірні дані")
    ok = db.update_milk_register_field(which, day, field, value, shift)
    return _ok() if ok else _err("Запис не знайдено")


@app.get("/milk/photo/<path:name>")
def milk_photo(name):
    """Фото лічильника, надіслане ботом (для показу на сторінках молока)."""
    from vet_pharmacy import web_db
    safe = os.path.basename(str(name))
    fp = web_db._local_data_dir() / "milk_photos" / safe
    if not safe or not fp.exists():
        abort(404)
    return send_file(str(fp))


@app.get("/api/database/backups")
def api_database_backups_list():
    """Список наявних резервних копій (від найновіших)."""
    return _ok({"items": db.list_backups()})


@app.get("/api/database/backups/<name>")
def api_database_backup_file(name: str):
    """Завантажити конкретну резервну копію з backups/."""
    # пускаємо тільки наші формати імен — захист від виходу за теку
    if "/" in name or "\\" in name or ".." in name or not name.endswith(".db"):
        abort(404)
    if not (name.startswith("workcenter_") or name.startswith("vet_pharmacy_") or name.startswith("pre_restore_")
            or name.startswith("pre_update_")):
        abort(404)
    path = db.backup_dir() / name
    if not path.exists():
        abort(404)
    return send_file(path, mimetype="application/x-sqlite3",
                     as_attachment=True, download_name=name)


@app.post("/api/database/restore")
def api_database_restore():
    """Відновлення бази з завантаженого файлу."""
    f = request.files.get("file")
    if not f or not f.filename:
        return _err("Файл не вибрано")
    try:
        db.restore_from_bytes(f.read())
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


# --- Користувачі (адмін) ---

@app.get("/api/users")
def api_users_list():
    return _ok({"items": db.list_users()})


@app.post("/api/users")
def api_users_create():
    data = request.get_json(silent=True) or {}
    try:
        uid = db.add_user(
            username=data.get("username", ""),
            password=data.get("password", ""),
            role=data.get("role", "user"),
            full_name=data.get("full_name", ""))
    except ValueError as exc:
        return _err(str(exc))
    return _ok({"id": uid})


@app.put("/api/users/<int:user_id>")
def api_users_update(user_id: int):
    data = request.get_json(silent=True) or {}
    fields = {}
    if "username" in data:
        fields["username"] = (data["username"] or "").strip()
    if "role" in data:
        if data["role"] not in ("admin", "user"):
            return _err("Невірна роль")
        if user_id == session.get("user_id") and data["role"] != "admin":
            return _err("Не можна знизити роль власному акаунту.")
        if data["role"] != "admin":
            other_admins = [u for u in db.list_users()
                            if u["role"] == "admin" and u["is_active"]
                            and u["id"] != user_id]
            if not other_admins:
                return _err("Має лишитися хоча б один адміністратор.")
        fields["role"] = data["role"]
    if "full_name" in data:
        fields["full_name"] = (data["full_name"] or "").strip()
    if "is_active" in data:
        active = 1 if data["is_active"] else 0
        if not active and user_id == session.get("user_id"):
            return _err("Не можна деактивувати свій акаунт.")
        fields["is_active"] = active
    try:
        db.update_user(user_id, **fields)
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


@app.post("/api/users/<int:user_id>/password")
def api_users_set_password(user_id: int):
    data = request.get_json(silent=True) or {}
    try:
        db.set_user_password(user_id, data.get("password", ""))
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


@app.post("/api/account/password")
def api_account_password():
    """Зміна власного пароля. Вимагає правильний поточний пароль."""
    data = request.get_json(silent=True) or {}
    current = data.get("current") or ""
    new_pwd = data.get("new") or ""
    user = db.get_user(session.get("user_id"))
    if not user:
        return _err("Сесію завершено", 401)
    # перевірка поточного пароля
    if not db.verify_password(user["username"], current):
        return _err("Невірний поточний пароль.")
    if len(new_pwd) < 4:
        return _err("Новий пароль має містити щонайменше 4 символи.")
    if new_pwd == current:
        return _err("Новий пароль повинен відрізнятися від поточного.")
    try:
        db.set_user_password(user["id"], new_pwd)
    except ValueError as exc:
        return _err(str(exc))
    return _ok()


@app.post("/api/users/<int:user_id>/restore")
def api_users_restore(user_id: int):
    user = db.get_user(user_id)
    if not user:
        return _err("Користувача не знайдено", 404)
    db.restore_user(user_id)
    return _ok()


@app.get("/api/users/<int:user_id>/branches")
def api_user_branches_get(user_id: int):
    """Дозволені гілки користувача (для галочок у картці)."""
    if not db.get_user(user_id):
        return _err("Користувача не знайдено", 404)
    return _ok({"allowed_ids": db.list_user_branch_ids(user_id),
                "levels": db.user_branch_levels(user_id),
                "work_place": db.user_work_place(user_id)})


@app.post("/api/users/<int:user_id>/branches")
def api_user_branches_set(user_id: int):
    if not db.get_user(user_id):
        return _err("Користувача не знайдено", 404)
    data = request.get_json(silent=True) or {}
    # Новий формат — {гілка: рівень}; старий (перелік гілок) теж приймаємо.
    db.set_user_branches(user_id, data.get("levels") or data.get("branch_ids", []))
    if "work_place" in data:
        try:
            db.set_user_work_place(user_id, data.get("work_place") or "any")
        except ValueError as exc:
            return _err(str(exc))
    return _ok()


@app.get("/api/users/<int:user_id>/offline-branches")
def api_user_offline_get(user_id: int):
    """Гілки, де користувачу дозволено офлайн-роботу (для галочок)."""
    if not db.get_user(user_id):
        return _err("Користувача не знайдено", 404)
    return _ok({"offline_ids": db.list_user_offline_branch_ids(user_id)})


@app.post("/api/users/<int:user_id>/offline-branches")
def api_user_offline_set(user_id: int):
    if not db.get_user(user_id):
        return _err("Користувача не знайдено", 404)
    data = request.get_json(silent=True) or {}
    db.set_user_offline_branches(user_id, data.get("branch_ids", []))
    return _ok()


# ── Офлайн-синхронізація (Етап 0: реєстрація пристрою + знімок) ─────────────
def _user_may_offline(user_id, branch: str) -> bool:
    """Чи може поточний користувач працювати офлайн із гілкою.
    Адмін — завжди; інші — за явним дозволом (галочки)."""
    if not user_id:
        return False
    u = db.get_user(user_id)
    if u and u.get("role") == "admin":
        return True
    return db.user_can_offline(user_id, branch)


@app.post("/api/sync/device")
def api_sync_device():
    """Реєстрація/оновлення телефону. Прив'язується до поточного користувача."""
    data = request.get_json(silent=True) or {}
    device_id = (data.get("device_id") or "").strip()
    if not device_id:
        return _err("Немає device_id")
    db.register_device(device_id, data.get("name", ""), session.get("user_id"))
    return _ok({"device_id": device_id})


@app.get("/api/sync/snapshot")
def api_sync_snapshot():
    """Знімок даних для офлайн-роботи по поточній гілці.
    Дозволено, лише якщо користувач має офлайн-право на цю гілку."""
    cat = _inv_category() or "pharmacy"
    uid = session.get("user_id")
    if not _user_may_offline(uid, cat):
        return _err("Немає дозволу на офлайн-роботу з цією гілкою. "
                    "Зверніться до адміністратора.", 403)
    snap = db.build_offline_snapshot(cat)
    return _ok({"snapshot": snap})


@app.post("/api/sync/push")
def api_sync_push():
    """Прийняти чергу офлайн-операцій з телефону й застосувати на сервері.
    Дозволено лише користувачу з офлайн-правом на цю гілку."""
    cat = _inv_category() or "pharmacy"
    uid = session.get("user_id")
    if not _user_may_offline(uid, cat):
        return _err("Немає дозволу на офлайн-роботу з цією гілкою. "
                    "Зверніться до адміністратора.", 403)
    data = request.get_json(silent=True) or {}
    device_id = (data.get("device_id") or "").strip()
    if device_id:
        db.register_device(device_id, data.get("device_name", ""), uid)
    res = db.apply_sync_ops(device_id, uid, data.get("ops", []), category=cat)
    return _ok(res)


def _is_admin() -> bool:
    u = db.get_user(session["user_id"]) if "user_id" in session else None
    return bool(u and u.get("role") == "admin")


@app.get("/api/sync/conflicts")
def api_sync_conflicts():
    """Перелік офлайн-операцій, що потребують уваги (конфлікт/відхилення). Адмін."""
    if not _is_admin():
        return _err("Лише для адміністратора.", 403)
    return _ok({"items": db.list_sync_conflicts(), "count": db.count_sync_conflicts()})


@app.post("/api/sync/conflicts/<op_id>/resolve")
def api_sync_conflict_resolve(op_id: str):
    if not _is_admin():
        return _err("Лише для адміністратора.", 403)
    if db.resolve_sync_conflict(op_id):
        return _ok({})
    return _err("Запис не знайдено", 404)


@app.delete("/api/users/<int:user_id>")
def api_users_delete(user_id: int):
    if user_id == session.get("user_id"):
        return _err("Не можна видалити свій акаунт.")
    user = db.get_user(user_id)
    if user and user["role"] == "admin" and user["is_active"]:
        other_admins = [u for u in db.list_users()
                        if u["role"] == "admin" and u["is_active"]
                        and u["id"] != user_id]
        if not other_admins:
            return _err("Не можна видалити останнього адміністратора.")
    db.delete_user(user_id)
    return _ok()


# ======================================== дублювання маршрутів під /m та /f
# Гілки «Матеріали» (/m) і «Годівля» (/f) використовують ті самі в'юхи й
# шаблони, що й аптека. Категорія обліку визначається у в'юхах через
# _inv_category(), тож достатньо зареєструвати ті самі вʼюхи під префіксом.
_BRANCH_PREFIXES = (("/m", "m_"), ("/f", "f_"))


def _register_branch_prefixes():
    # Базові маршрути = усі, крім статики й уже префіксованих
    base = []
    for rule in list(app.url_map.iter_rules()):
        ep = rule.endpoint
        if ep == "static" or any(ep.startswith(epref) for _, epref in _BRANCH_PREFIXES):
            continue
        if any(rule.rule == pref or rule.rule.startswith(pref + "/")
               for pref, _ in _BRANCH_PREFIXES):
            continue
        base.append(rule)
    for pref, epref in _BRANCH_PREFIXES:
        seen = set()
        for rule in base:
            ep = rule.endpoint
            if ep in seen:
                continue
            seen.add(ep)
            methods = sorted(m for m in rule.methods if m not in ("HEAD", "OPTIONS"))
            app.add_url_rule(pref + rule.rule, endpoint=epref + ep,
                             view_func=app.view_functions[ep], methods=methods)


_register_branch_prefixes()


# ===================================================================== main

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    debug = os.environ.get("DEBUG", "0") == "1"
    print(f"Облік ферми (web): http://{host}:{port}")
    app.run(host=host, port=port, debug=debug)
