/* Service Worker — Облік ферми (PWA).
   Кешуємо статику (CSS/JS/іконки), щоб застосунок ставився на телефон і
   швидко відкривався. /api/* НЕ кешуються — дані завжди свіжі. Робота без
   мережі тут НЕ передбачена (офлайн-режим прибрано 2026-09-21): при обриві
   звʼязку показуємо зрозумілу сторінку «Немає звʼязку».

   Важливо: сторінки підключають статику з ?v=… (проти кешу при оновленні).
   Тому при пошуку в кеші використовуємо ignoreSearch — інакше офлайн
   /static/css/app.css?v=123 не знаходив би передкешований /static/css/app.css
   і сторінка ламалась би без мережі. */
const CACHE = 'farm-shell-v771';
const ASSETS = [
    '/static/css/app.css',
    '/static/js/app.js',
    '/static/js/camera-scan.js',
    '/static/js/vendor/zxing.min.js',
    '/static/favicon.svg',
    '/static/icons/icon-192.png',
    '/static/icons/icon-512.png',
    '/static/manifest.webmanifest'
];

self.addEventListener('install', (e) => {
    e.waitUntil(
        caches.open(CACHE)
            // кешуємо поштучно — щоб збій одного ресурсу не зривав решту
            .then((c) => Promise.all(
                ASSETS.map((u) => c.add(u).catch(() => null))))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (e) => {
    e.waitUntil((async () => {
        // Navigation Preload: браузер починає мережевий запит ще ДО пробудження
        // service worker. Це обходить баг iOS, коли після кількох годин у фоні
        // власний fetch() у SW «залипає» і навігація завжди падала в офлайн.
        try {
            if (self.registration.navigationPreload) {
                await self.registration.navigationPreload.enable();
            }
        } catch (e) { /* не підтримується — не страшно */ }
        try {
            const ks = await caches.keys();
            await Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
        } catch (e) { /* ignore */ }
        await self.clients.claim();
    })());
});

// Пошук у кеші, що ігнорує ?v=… (інакше офлайн були б промахи).
function cacheMatch(req) {
    return caches.match(req, { ignoreSearch: true });
}

// Покласти свіжу копію в кеш (мовчки).
function putInCache(req, resp) {
    if (resp && resp.status === 200) {
        const cp = resp.clone();
        caches.open(CACHE).then((cache) => cache.put(req, cp));
    }
    return resp;
}

// Сторінка «Немає звʼязку» — щоб Safari НІКОЛИ не показував свою
// «не може відкрити сторінку». Працювати без мережі застосунок не вміє.
function offlineStub() {
    return new Response(
        '<!doctype html><html lang="uk"><head><meta charset="utf-8">'
        + '<meta name="viewport" content="width=device-width,initial-scale=1">'
        + '<title>Немає звʼязку</title></head>'
        + '<body style="font-family:system-ui,-apple-system,Arial;padding:28px;text-align:center;color:#1c2430">'
        + '<h2>Немає звʼязку</h2><p>Застосунок не бачить ферму.</p>'
        + '<p>Перевірте інтернет або Wi-Fi і спробуйте ще раз.</p>'
        + '<p><a href="/">Спробувати ще раз</a></p></body></html>',
        { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
}

// Запасний варіант навігації без мережі. ГАРАНТОВАНО повертає Response:
// кешовану сторінку, якщо вона є, інакше «Немає звʼязку».
async function offlineFallback(req, url) {
    try {
        var exact = await cacheMatch(req);
        if (exact) return exact;
    } catch (e) { /* ignore */ }
    return offlineStub();
}

// fetch із таймаутом — щоб «мертве» зʼєднання (сервер вимкнено, але Wi-Fi є)
// не лишало білий екран, поки браузер чекає відповіді. Після таймауту —
// віддаємо кешовану офлайн-сторінку.
function fetchTimeout(req, ms) {
    return new Promise((resolve, reject) => {
        let done = false;
        const t = setTimeout(() => { if (!done) { done = true; reject(new Error('timeout')); } }, ms);
        fetch(req).then(
            (r) => { if (!done) { done = true; clearTimeout(t); resolve(r); } },
            (e) => { if (!done) { done = true; clearTimeout(t); reject(e); } }
        );
    });
}

self.addEventListener('fetch', (e) => {
    const req = e.request;
    if (req.method !== 'GET') return;
    const url = new URL(req.url);
    if (url.origin !== self.location.origin) return;
    if (url.pathname.startsWith('/api/')) return;     // дані — завжди з мережі

    // Офлайн-сторінка (це і start_url застосунку): CACHE-FIRST — миттєво з
    // пристрою, навіть при холодному старті без сервера (жодного очікування
    // мережі → немає білого екрана). Свіжу копію тихо оновлюємо у фоні.

    // Статика.
    //
    // Файли з ?v=… (сторінкові скрипти й стилі) шукаємо в кеші ТОЧНО, разом із
    // версією. Новий ?v= — це промах кешу, тож свіжий файл завантажиться одразу.
    // Раніше тут стояв ignoreSearch, і він зводив нанівець сам сенс версії:
    // браузер віддавав стару копію попри змінений ?v=, тому оновлення коду
    // доїжджали лише через раз. Офлайн не постраждав — якщо мережі немає,
    // повертаємось до пошуку без урахування версії.
    //
    // Файли без ?v= (іконки, маніфест) лишаються cache-first, як і були.
    if (url.pathname.startsWith('/static/')) {
        const versioned = url.searchParams.has('v');
        e.respondWith((async () => {
            if (versioned) {
                const exact = await caches.match(req);      // з урахуванням ?v=
                if (exact) return exact;
                try {
                    return putInCache(req, await fetch(req));
                } catch (err) {
                    return (await cacheMatch(req)) || fetch(req);
                }
            }
            const hit = await cacheMatch(req);
            if (hit) { fetch(req).then((resp) => putInCache(req, resp)).catch(() => {}); return hit; }
            try {
                return putInCache(req, await fetch(req));
            } catch (err) {
                return (await cacheMatch(req)) || fetch(req);
            }
        })());
        return;
    }

    // Будь-яка навігація (відкриття/оновлення/перехід у застосунок):
    //  1) спершу беремо navigation preload (запит, що його почав сам браузер —
    //     він НЕ залежить від «сонного» SW, тож обходить баг iOS, коли через
    //     кілька годин у фоні застосунок застрягав в офлайні);
    //  2) якщо preload недоступний — звичайний мережевий запит з таймаутом 8 с;
    //  3) лише при справжньому збої/відсутності мережі — кешована офлайн-сторінка.
    if (req.mode === 'navigate') {
        e.respondWith((async () => {
            try {
                const pre = await e.preloadResponse;
                if (pre) { putInCache(req, pre.clone()); return pre; }
            } catch (err) { /* ignore — підемо у звичайний fetch */ }
            try {
                return await fetchTimeout(req, 8000);
            } catch (err) {
                return offlineFallback(req, url);
            }
        })());
        return;
    }
});
