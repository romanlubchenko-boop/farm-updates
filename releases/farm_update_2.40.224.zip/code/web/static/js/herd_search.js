/* ============ Центральний пошук тварини ============
   Роман 2026-09-15: «центральне поле пошуку тварин по різним критеріям —
   номер, кличка, номер UIN, транспондер». Живе в шапці всіх сторінок
   гілки стада: набрав будь-який із номерів → вибрав → картка тварини.

   Що саме шукається, вирішує конструктор параметрів (галочка «шукати»),
   тож завтрашній «номер чипа» запрацює без правки коду. */
(function () {
    const box = document.getElementById('hSearch');
    if (!box) return;                       // не гілка стада — модуль мовчить
    const inp = document.getElementById('hSearchInp');
    const list = document.getElementById('hSearchList');
    let items = [];
    let hot = 0;
    let timer = null;
    let seq = 0;                            // відповіді можуть прийти не в тому порядку

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
        (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

    const SEX = { F: '♀', M: '♂' };
    // у стаді — без позначки; показуємо лише тих, кого вже немає

    function render() {
        if (!items.length) {
            list.innerHTML = '<div class="hs-empty">Нічого не знайшли</div>';
            list.hidden = false;
            return;
        }
        list.innerHTML = items.map((a, i) => {
            // назва статусу — з конструктора (сервер віддає її разом із твариною)
            const st = (a.status && a.status !== 'active') ? String(a.status_label || a.status).toLowerCase() : '';
            // показуємо, ЧИМ збіглося: інакше незрозуміло, чому знайшлась
            // саме ця тварина (шукали транспондер — бачимо бирку)
            const hit = (a.hit_label && !a.hit_is_tag)
                ? `<span class="hs-hit">${esc(a.hit_label)}: ${esc(a.hit_value)}</span>` : '';
            return `<div class="hs-row${i === hot ? ' hot' : ''}" data-i="${i}">
                <span class="hs-tag">${esc(a.tag)}</span>
                <span class="hs-sex hs-${a.sex === 'M' ? 'm' : 'f'}">${SEX[a.sex] || ''}</span>
                <span class="hs-name">${esc(a.name || '')}</span>
                ${hit}
                <span class="hs-grp">${esc(a.group_name || '')}</span>
                ${st ? `<span class="hs-st">${esc(st)}</span>` : ''}
            </div>`;
        }).join('');
        list.hidden = false;
        list.querySelectorAll('.hs-row').forEach((r) => {
            r.onclick = () => go(items[+r.dataset.i]);
        });
    }

    /* Знайшли — поле одразу чисте й з курсором (Роман 2026-10-02: «ввів номер,
       Enter — перейшло на картку, номер із поля зник і одразу фокус у цьому ж
       полі для нової тварини»). Перехід на іншу сторінку лишає позначку, і
       там курсор стає в пошук сам. */
    const FOCUS_KEY = 'herd:search_focus';
    function go(a) {
        if (!a) return;
        close();
        clearTimeout(timer); timer = null;
        seq++;                                // запізніла відповідь не відкриє список знову
        inp.value = '';
        if (window.herdNav) window.herdNav.setCurrent(a);
        if (window.herdCardGo) {               // вже на картці — лише вміст
            window.herdCardGo(a.id);
            inp.focus();
            setTimeout(() => { if (document.activeElement !== inp) inp.focus(); }, 300);
            return;
        }
        try { sessionStorage.setItem(FOCUS_KEY, '1'); } catch (e) { /* ignore */ }
        location.href = '/herd/animals/' + a.id;   // окрема сторінка картки
    }
    // прийшли сюди з пошуку — курсор у поле для наступного номера
    try {
        if (sessionStorage.getItem(FOCUS_KEY)) {
            sessionStorage.removeItem(FOCUS_KEY);
            inp.focus();
            // картка дочитує дані й може перехопити фокус — повертаємо, якщо ніхто не друкує деінде
            setTimeout(() => {
                const ae = document.activeElement;
                if (ae === document.body || !ae || ae === inp) inp.focus();
            }, 600);
        }
    } catch (e) { /* ignore */ }

    /* Enter, поки підказки ще не прийшли: шукаємо одразу й ідемо на точний
       збіг номера, а як немає — на єдину знайдену; кілька — показуємо перелік */
    async function enterNow(q) {
        clearTimeout(timer); timer = null;
        const my = ++seq;
        let got = [];
        try {
            const r = await fetch('/api/herd/search?q=' + encodeURIComponent(q),
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            got = (d && d.items) || [];
        } catch (e) { return; }
        if (my !== seq) return;
        const exact = got.find((a) => String(a.tag).toLowerCase() === q.toLowerCase());
        if (exact || got.length === 1) { go(exact || got[0]); return; }
        items = got; hot = 0; render();
    }

    function close() { list.hidden = true; items = []; hot = 0; }

    async function search(q) {
        const my = ++seq;
        try {
            const r = await fetch('/api/herd/search?q=' + encodeURIComponent(q),
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            if (my !== seq) return;          // прийшла відповідь на старіший запит
            items = (d && d.items) || [];
            hot = 0;
            render();
        } catch (e) { /* мережа впала — просто не показуємо підказок */ }
    }

    inp.addEventListener('input', () => {
        const q = inp.value.trim();
        clearTimeout(timer);
        if (q.length < 1) { timer = null; close(); return; }
        timer = setTimeout(() => { timer = null; search(q); }, 180);
    });

    inp.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { close(); inp.blur(); return; }
        if (e.key === 'Enter' && (list.hidden || !items.length || timer)) {
            const q = inp.value.trim();
            e.preventDefault();
            if (q) enterNow(q);
            return;
        }
        if (list.hidden || !items.length) return;
        if (e.key === 'ArrowDown') { hot = Math.min(hot + 1, items.length - 1); render(); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { hot = Math.max(hot - 1, 0); render(); e.preventDefault(); }
        else if (e.key === 'Enter') { e.preventDefault(); go(items[hot]); }
    });

    inp.addEventListener('focus', () => { if (items.length) list.hidden = false; });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#hSearch')) close();
    });
    // Ctrl/Cmd+K — стати в пошук із будь-якого місця гілки
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            // смужку на цій сторінці сховали — спершу показати, інакше в сховане поле не стати
            const bar = document.getElementById('hBar'), show = document.getElementById('hBarShow');
            if (bar && bar.hidden && show) show.click();
            inp.focus(); inp.select();
        }
    });
})();


/* ============ Перемикач тварин «◄ ►» ============
   Роман 2026-09-15: «додай перемикач вправо вліво, де можна перейти на іншу
   тварину, ніби як перемикач дат, тільки тварин» + «перемикати по вибраним
   фільтрам». Тож гортання йде тим самим списком, що показує реєстр: обмежив
   секцією чи статусом — гортаєш саме їх, а не все стадо.

   Поточна тварина живе між сторінками (localStorage): відкрив картку з
   календаря — і на «Русі поголів'я» перемикач уже показує її. */
(function () {
    const bar = document.getElementById('hNav');
    if (!bar) return;                       // не гілка стада — модуль мовчить
    const prevBtn = document.getElementById('hNavPrev');
    const nextBtn = document.getElementById('hNavNext');
    const curEl = document.getElementById('hNavCur');
    const scopeEl = document.getElementById('hNavScope');

    const CUR_KEY = 'herd:current';         // {id, tag, name} останньої тварини
    const FLT_KEY = 'herd:filters';         // фільтри реєстру (пише herd_animals.js)

    let list = [];
    let cur = null;                         // {id, tag, name}

    const jget = (store, key) => {
        try { return JSON.parse(store.getItem(key) || 'null'); } catch (e) { return null; }
    };
    const jset = (store, key, val) => {
        try { store.setItem(key, JSON.stringify(val)); } catch (e) { /* повне сховище */ }
    };

    const FLT_KEYS = ['q', 'status', 'sex', 'group_id'];

    function filters() {
        return jget(localStorage, FLT_KEY) || {};
    }

    function query() {
        const f = filters();
        const p = new URLSearchParams();
        FLT_KEYS.forEach((k) => { if (f[k]) p.set(k, f[k]); });
        return p.toString();
    }

    /* Назва вибірки, якою гортаємо: щоб людина бачила, ЧОМУ наступна саме ця
       (а не дивувалась, що з 1943 тварин стрілка веде через одну). */
    // «Живі · Вибулі · Усі» — тими самими словами, що й на перемикачі (реєстр
    // підписує «active» як «В стаді», і лічильник казав не те, що натиснули)
    const LIVE_WORD = { active: 'Живі', gone: 'Вибулі', '': 'Усі' };
    function scopeName() {
        const f = filters();
        const parts = [];
        parts.push(LIVE_WORD[f.status || ''] || f.status_name || 'статус');
        if (f.group_id) parts.push(f.group_name
            || (window.herdLabel ? herdLabel('group', 'група') : 'група').toLowerCase());
        if (f.sex) parts.push(f.sex === 'M' ? '♂' : '♀');
        if (f.q) parts.push('«' + f.q + '»');
        return parts.join(' · ');
    }

    function idx() {
        if (!cur) return -1;
        return list.findIndex((a) => String(a.id) === String(cur.id));
    }

    function render() {
        const i = idx();
        if (cur) {
            // номер — окремим елементом, щоб виділити його кольором
            curEl.textContent = '';
            if (cur.tag) {
                const t = document.createElement('b');
                t.className = 'hnav-tag';
                t.textContent = cur.tag;
                curEl.appendChild(t);
                // нерозривний пробіл: у flex-полі звичайний на краю тексту зникає
                if (cur.name) curEl.appendChild(document.createTextNode('\u00a0· ' + cur.name));
            } else {
                curEl.textContent = '…';    // бирка ще не приїхала
            }
            curEl.href = '/herd/animals/' + cur.id;
            curEl.classList.remove('is-empty');
        } else {
            curEl.textContent = 'оберіть тварину';
            curEl.removeAttribute('href');
            curEl.classList.add('is-empty');
        }
        // Лічильник — словами (Роман 2026-10-02: «496 із 614 — хоча повинно тільки
        // живих»; то був НОМЕР поточної серед усіх): «Живі: 495 гол. · 7-а з них».
        // Клік по ньому — перелік цих тварин.
        const scope = scopeName();
        const loaded = list.length || LIST_OK;
        scopeEl.hidden = !loaded;
        if (loaded) {
            const who = (cur && cur.tag) || 'ця';      // поточна тварина — з номером, не «ця»
            const where = !cur ? '' : (i >= 0 ? ` · ${who} — ${i + 1}-а з них` : ` · ${who} не з них`);
            scopeEl.innerHTML = '';
            scopeEl.append(`${scope}: ${list.length} гол.${where}`);
            const ch = document.createElement('span');
            ch.className = 'hnav-scope-ch';
            ch.textContent = rollOpen() ? '▴' : '▾';
            scopeEl.appendChild(ch);
        }
        const none = !list.length;
        prevBtn.disabled = none;
        nextBtn.disabled = none;
    }

    let LIST_OK = false;                     // список прочитано (навіть порожній)
    async function loadList() {
        const qs = query();
        const key = 'herd:navlist2:' + qs;
        const hit = jget(sessionStorage, key);
        if (hit && hit.length !== undefined) { list = hit; LIST_OK = true; render(); return; }
        try {
            const r = await fetch('/api/herd/animals/nav?' + qs,
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            list = (d && d.items) || [];
            LIST_OK = true;
            jset(sessionStorage, key, list);
        } catch (e) { list = []; }
        render();
    }

    /* ПЕРЕЛІК ВИБІРКИ під смужкою (Роман 2026-10-02: «немає чіткого розуміння, що
       повинно показати… де мені передивитися вибулих» → «показує перелік»).
       Клік по «Живі · Вибулі · Усі» чи по лічильнику розгортає тварин, яких
       гортають стрілки: живі — із секцією, вибулі — статус, дата й причина.
       Рядки — свіжі з сервера (у памʼяті сесії лише номер і кличка). */
    const roll = document.getElementById('hRoll');
    const rollOpen = () => !!(roll && !roll.hidden);
    const dmy = (d) => (/^\d{4}-\d{2}-\d{2}/.test(d || '') ? d.slice(8, 10) + '.' + d.slice(5, 7) + '.' + d.slice(0, 4) : (d || ''));
    let ROLL_SEQ = 0;
    async function rollShow() {
        if (!roll) return;
        const seq = ++ROLL_SEQ;
        roll.hidden = false;
        render();
        roll.innerHTML = '<div class="hroll-empty">Читаю перелік…</div>';
        let items = null;
        try {
            const r = await fetch('/api/herd/animals/nav?' + query(),
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            items = (d && d.items) || [];
        } catch (e) { items = null; }
        if (seq !== ROLL_SEQ || roll.hidden) return;
        if (!items) { roll.innerHTML = '<div class="hroll-empty">Перелік не прочитався — спробуйте ще раз</div>'; return; }
        list = items.map((a) => ({ id: a.id, tag: a.tag, name: a.name }));
        jset(sessionStorage, 'herd:navlist2:' + query(), list);
        render();
        const esc = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
        const head = `<div class="hroll-head"><b>${esc(scopeName())}</b> · ${items.length} гол.`
            + '<button type="button" class="hroll-x" data-close="1" title="Закрити (Esc)">✕</button></div>';
        if (!items.length) { roll.innerHTML = head + '<div class="hroll-empty">Нікого</div>'; return; }
        const gone = items.some((a) => a.status !== 'active');
        const grp = items.some((a) => a.grp);             // у вибулих секції немає — колонку не малюємо
        roll.innerHTML = head + '<div class="hroll-body"><table class="hroll-t"><thead><tr>'
            + '<th>№</th><th>Кличка</th>' + (gone ? '<th>Статус</th><th>Вибула</th><th>Причина</th>' : '')
            + (grp ? '<th>Секція</th>' : '') + '</tr></thead><tbody>'
            + items.map((a) => `<tr data-go="${a.id}"${cur && String(cur.id) === String(a.id) ? ' class="is-cur"' : ''}>`
                + `<td class="t">${esc(a.tag)}</td><td>${esc(a.name)}</td>`
                + (gone ? `<td>${esc(a.st || '')}</td><td class="d">${esc(dmy(a.out))}</td><td>${esc(a.why || '')}</td>` : '')
                + (grp ? `<td>${esc(a.grp || '')}</td>` : '') + '</tr>').join('')
            + '</tbody></table></div>';
        const row = roll.querySelector('tr.is-cur');
        const body = roll.querySelector('.hroll-body');
        if (row && body) body.scrollTop = row.offsetTop - body.clientHeight / 2;
    }
    function rollHide() {
        if (!roll || roll.hidden) return;
        roll.hidden = true;
        ROLL_SEQ++;
        render();
    }
    if (roll) {
        roll.addEventListener('click', (e) => {
            if (e.target.closest('[data-close]')) { rollHide(); return; }
            const tr = e.target.closest('tr[data-go]');
            if (!tr) return;
            const a = list.find((x) => String(x.id) === tr.dataset.go);
            rollHide();
            if (a) goTo(a);
        });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && rollOpen()) rollHide(); });
        document.addEventListener('mousedown', (e) => {
            if (rollOpen() && !e.target.closest('#hRoll, #hNavScope, #hLive')) rollHide();
        });
    }
    scopeEl.addEventListener('click', () => (rollOpen() ? rollHide() : rollShow()));

    /* Крок стрілкою. Тварина поза поточною вибіркою (фільтри змінили після
       того, як її відкрили) — заходимо з краю: «◄» на останню, «►» на першу. */
    function step(d) {
        if (!list.length) return;
        const i = idx();
        let n;
        if (i < 0) n = d > 0 ? 0 : list.length - 1;
        else n = (i + d + list.length) % list.length;
        const a = list[n];
        if (!a) return;
        goTo(a);
    }
    function goTo(a) {
        cur = { id: a.id, tag: a.tag, name: a.name };
        jset(localStorage, CUR_KEY, cur);
        // на самій картці міняємо ЛИШЕ її вміст: перезавантаження сторінки
        // заради сусідньої тварини гасило екран і тягло всю обгортку заново
        if (window.herdCardGo) { render(); window.herdCardGo(a.id); return; }
        location.href = '/herd/animals/' + a.id;
    }

    prevBtn.addEventListener('click', () => step(-1));
    nextBtn.addEventListener('click', () => step(1));

    /* Перемикач «Живі · Вибулі · Усі» — кого гортати стрілками. Пише в ті
       самі фільтри, що й реєстр, тож добір скрізь один. «Вибулі» це не
       один статус, а всі, крім тих, що в стаді, — сервер знає слово gone. */
    const live = document.getElementById('hLive');
    function markLive() {
        if (!live) return;
        const cur = (filters().status || '');
        live.querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', (b.dataset.s || '') === cur));
    }
    if (live) {
        live.addEventListener('click', (e) => {
            const b = e.target.closest('.seg-btn');
            if (!b) return;
            live.querySelectorAll('.seg-btn').forEach((x) => x.classList.toggle('was-active', x === b && x.classList.contains('is-active')));
            const f = filters();
            f.status = b.dataset.s || '';
            f.status_name = b.textContent.trim();
            if (!f.status) delete f.status_name;
            jset(localStorage, FLT_KEY, f);
            markLive();
            // панель добору спершу приймає новий вибір у свої поля, і лише
            // потім обидві сторони читають список — інакше вона перепише
            // його старим
            // сторінки, що показують власний список тварин (панель добору
            // на картці, таблиця реєстру), спершу приймають новий вибір —
            // інакше вони лишаються зі старим фільтром або переписують
            // спільний список
            const others = [window.herdSide, window.herdRegistry]
                .filter((x) => x && x.reload).map((x) => x.reload());
            // той самий вибір ще раз при відкритому переліку — згорнути; інакше
            // одразу показати, КОГО тепер гортаємо
            const again = rollOpen() && b.classList.contains('was-active');
            Promise.all(others).then(loadList, loadList).then(() => (again ? rollHide() : rollShow()));
        });
        markLive();
    }

    // Поточна тварина: сторінка картки задає її сама, решта — з памʼяті.
    const m = location.pathname.match(/^\/herd\/animals\/(\d+)/);
    if (m) {
        const id = parseInt(m[1], 10);
        const was = jget(localStorage, CUR_KEY);
        cur = (was && String(was.id) === String(id)) ? was : { id: id, tag: '', name: '' };
        jset(localStorage, CUR_KEY, cur);
    } else {
        cur = jget(localStorage, CUR_KEY);
    }
    render();

    // Список даємо іншим модулям оновлювати (реєстр уже має свіжі дані —
    // навіщо питати сервер удруге) і дізнаватись, кого зараз гортаємо.
    window.herdNav = {
        setCurrent(a) {
            if (!a || !a.id) return;
            cur = { id: a.id, tag: a.tag || '', name: a.name || '' };
            jset(localStorage, CUR_KEY, cur);
            render();
        },
        /* Кого картка має підвезти наперед: сусіди зліва й справа. */
        neighbours(id) {
            const i = list.findIndex((a) => String(a.id) === String(id));
            if (i < 0) return [];
            const n = list.length;
            return [list[(i + 1) % n], list[(i - 1 + n) % n]]
                .filter(Boolean).map((a) => a.id)
                .filter((x) => String(x) !== String(id));
        },
        cacheList(items) {
            list = (items || []).map((a) => ({ id: a.id, tag: a.tag, name: a.name }));
            jset(sessionStorage, 'herd:navlist2:' + query(), list);
            render();
        },
        reload: loadList,
    };

    loadList().then(async () => {
        // Підпис картки, відкритої прямим посиланням. Бирку беремо зі списку,
        // а якщо тварини там немає (вона поза вибіркою) — питаємо сервер.
        // ⚠️ Без цього в полі світився ВНУТРІШНІЙ номер запису і читався як
        // номер тварини — груба підміна: 1011 замість бирки 20204.
        if (!cur || cur.tag) return;
        const a = list.find((x) => String(x.id) === String(cur.id));
        if (a) { window.herdNav.setCurrent(a); return; }
        try {
            const r = await fetch('/api/herd/animals/' + cur.id,
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            if (d && d.tag) window.herdNav.setCurrent({ id: cur.id, tag: d.tag, name: d.name });
        } catch (e) { /* не дісталися — краще без підпису, ніж чужий номер */ }
    });
})();

/* Смужку пошуку й перемикача тварин можна сховати на сторінці, де вона не потрібна
   (Роман 2026-09-29: «зробити панель приховати показати»). Вибір — окремо для кожної
   сторінки (картки тварин — одна сторінка); повертає її лупа в шапці. */
(function () {
    const bar = document.getElementById('hBar');
    const hide = document.getElementById('hBarHide');
    const show = document.getElementById('hBarShow');
    if (!bar || !hide || !show) return;
    const key = 'herd:bar_off:' + location.pathname.replace(/\/\d+(?=\/|$)/g, '/#');
    function set(off) {
        bar.hidden = off;
        show.hidden = !off;
        try { if (off) localStorage.setItem(key, '1'); else localStorage.removeItem(key); } catch (e) { /* ignore */ }
    }
    hide.addEventListener('click', () => set(true));
    show.addEventListener('click', () => {
        set(false);
        const inp = document.getElementById('hSearchInp');
        if (inp) inp.focus();
    });
})();
