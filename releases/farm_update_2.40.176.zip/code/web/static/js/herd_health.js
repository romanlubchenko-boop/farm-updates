/* ЗДОРОВ’Я СТАДА — ВАКЦИНАЦІЯ (Роман 2026-10-01: «окремий блок вакцинація тварин — прописувати схему вакцинації й
   впроваджувати в списки» → обрав: строк кроку — від віку чи від події; проведено — подія й тварина зникає зі списку;
   аптеку поки не списуємо).
   📌 Крок — ЛИШЕ РЯДОК ФОРМУЛИ (Роман 2026-10-01: «всі дані фільтрація від строки формул… прибрати від чого рахувати;
      залишити крок, препарат, доза, активний/неактивний; кроки перетягувати вверх-вниз»): клік по кроку — його FILTER(…)
      у стандартному рядку формули під пошуком тварини, Enter — записати. У рядку кроку: ⠿ (тягнути) · назва · препарат ·
      доза · формула (тихо) · активний / неактивний · ✕. Схема — лише назва й кроки.
   📌 Хто кому вже зроблено — подія «Вакцинація» з полем __vstep «схема:крок» (сервер: /api/herd/vacc → done).
   📌 Кому час — рахуємо тут, на живих тваринах: «зараз» (у вікні), «прострочено» (до 30 днів по вікну), «скоро» (до 14
      днів до вікна). «Провести» — груповий запис події тим, кого відмічено. */
'use strict';
(function () {
const $ = (id) => document.getElementById(id);
if (!$('hhDue')) return;

let PARAMS = [], SCHEMES = [], EVENT = null, ANIMALS = [];
let SEL = '';                                         // схема, чия умова «Кого» — у рядку формули вгорі
const OPEN = new Set();                              // розгорнуті кроки (до першого рендера — усі, де є «зараз»)
let FIRST = true;

const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const parseD = (s) => {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const dm = (d) => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
const dmy = (d) => `${dm(d)}.${d.getFullYear()}`;
const sk = (sc, st) => `${sc.id}:${st.id}`;
const WD = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'нд'];

/* ---------- хто кому час ---------- */
/* рахунок — спільний із мовою списків (herd_vacc.js): одна схема — одні числа скрізь */
const V = window.herdVacc;
const whoQ = (sc) => V.whoQ(sc);
const needKeys = () => V.deps();
const stateOf = (a, sc, st, t0) => V.stateOf(a, sc, st, t0);
function computeDue() {
    const t0 = today();
    const out = [];
    SCHEMES.forEach((sc) => {
        if (!sc.steps.some((st) => !st.off)) return;
        const q = whoQ(sc);
        const whoAll = q.error ? [] : ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters));
        sc.steps.forEach((st) => {
            if (st.off) return;                       // неактивний крок — не рахується
            const who = st.fx ? ANIMALS : whoAll;     // крок-формула сам каже, кого брати
            const rows = [];
            const day = V.dayOf(st, t0);             // найближчий день проведення кроку
            who.forEach((a) => { const s = stateOf(a, sc, st, day); if (s) rows.push(Object.assign({ a }, s)); });
            if (!rows.length) return;
            const rank = { late: 0, now: 1, soon: 2 };
            rows.sort((p, r) => rank[p.st] - rank[r.st] || String(p.a.tag).localeCompare(String(r.a.tag), 'uk', { numeric: true }));
            out.push({ sc, st, rows, day });
        });
    });
    return out;
}

/* ---------- «До вакцинації» ---------- */
const stLabel = (r) => (r.st === 'now' ? 'зараз' : r.st === 'late' ? `прострочено на ${r.n} дн.` : `через ${r.n} дн.`);
function renderDue() {
    V.setSchemes(SCHEMES);                         // правки схеми — одразу в спільному рахунку
    const box = $('hhDue');
    if (!SCHEMES.length) {
        $('hhSum').textContent = '';
        box.innerHTML = '<div class="hh-empty">Схем вакцинації ще немає — додайте нижче «+ схема».</div>';
        return;
    }
    if (SCHEMES.every((sc) => sc.steps.every((st) => st.off))) {
        $('hhSum').textContent = 'усі кроки неактивні';
        box.innerHTML = '<div class="hh-empty">Усі кроки неактивні — увімкніть потрібні нижче.</div>';
        return;
    }
    const list = computeDue();
    let now = 0, late = 0, soon = 0;
    list.forEach((g) => g.rows.forEach((r) => { if (r.st === 'now') now++; else if (r.st === 'late') late++; else soon++; }));
    $('hhSum').innerHTML = list.length
        ? `зараз <b>${now}</b>` + (late ? ` · прострочено <b>${late}</b>` : '') + (soon ? ` · скоро ${soon}` : '')
        : 'нікому — усе зроблено';
    if (!list.length) { box.innerHTML = '<div class="hh-empty">Зараз нікого: кому за схемами час — уже вакциновані.</div>'; return; }
    if (FIRST) { list.forEach((g) => { if (g.rows.some((r) => r.st !== 'soon')) OPEN.add(sk(g.sc, g.st)); }); FIRST = false; }
    box.innerHTML = list.map((g) => {
        const key = sk(g.sc, g.st);
        const c = (s) => g.rows.filter((r) => r.st === s).length;
        const open = OPEN.has(key);
        // за замовчуванням — лише «зараз»: прострочених могли колоти без запису, їх відмічають свідомо
        const pick = g.rows.filter((r) => r.st === 'now').length;
        const pills = [['late', c('late'), 'прострочено'], ['now', c('now'), 'зараз'], ['soon', c('soon'), 'скоро']]
            .filter((p) => p[1]).map((p) => `<span class="hh-pill ${p[0]}" title="${p[2]}">${p[1]} ${p[2]}</span>`).join('');
        const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
        return `<div class="hh-step" data-k="${escapeHtml(key)}">
            <div class="hh-sh" data-tog="${escapeHtml(key)}">
                <span class="hh-chev">${open ? '▾' : '▸'}</span>
                <span class="nm">${escapeHtml(g.st.name)}</span>
                ${drug ? `<span class="dr">${escapeHtml(drug)}</span>` : ''}
                <span class="sc">${escapeHtml(g.sc.name)}</span>
                ${(g.st.days || []).length ? `<span class="hh-day" title="Найближчий день проведення кроку">на ${WD[V.wdOf(g.day) - 1]} ${dm(g.day)}</span>` : ''}
                <span class="cnt">${pills}</span>
                <button type="button" class="btn btn-primary btn-sm" data-go="${escapeHtml(key)}"${pick ? '' : ' disabled'}>Провести · <span data-n>${pick}</span></button>
            </div>
            ${open ? `<table class="hh-tbl"><thead><tr><th class="ck"><input type="checkbox" data-all${pick ? ' checked' : ''}></th>
                <th>Номер</th><th class="hide-sm">Кличка</th><th>Вікно</th><th>Стан</th></tr></thead><tbody>
                ${g.rows.map((r) => `<tr><td class="ck"><input type="checkbox" data-id="${r.a.id}"${r.st === 'now' ? ' checked' : ''}></td>
                    <td><a href="/herd/animals/${r.a.id}">${escapeHtml(r.a.tag || '')}</a></td>
                    <td class="hide-sm">${escapeHtml(r.a.name || '')}</td>
                    <td>${dm(r.w1)}–${dmy(r.w2)}</td>
                    <td><span class="hh-st ${r.st}">${stLabel(r)}</span></td></tr>`).join('')}
                </tbody></table>` : ''}
        </div>`;
    }).join('');
    box._list = list;
}
function picked(card, g) {
    const boxes = card.querySelectorAll('input[data-id]');
    if (!boxes.length) return g.rows.filter((r) => r.st === 'now').map((r) => r.a.id);   // згорнуто — лише «зараз»
    return [...boxes].filter((b) => b.checked).map((b) => +b.dataset.id);
}
function paintN(card, g) {
    const n = picked(card, g).length;
    const btn = card.querySelector('[data-go]');
    btn.querySelector('[data-n]').textContent = n;
    btn.disabled = !n;
}
$('hhDue').addEventListener('click', async (e) => {
    const box = $('hhDue');
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = (box._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (!g) return;
    const go = e.target.closest('[data-go]');
    if (go) { e.stopPropagation(); conduct(g, picked(card, g)); return; }
    if (e.target.closest('input, a')) return;
    if (e.target.closest('[data-tog]')) {
        if (OPEN.has(card.dataset.k)) OPEN.delete(card.dataset.k); else OPEN.add(card.dataset.k);
        renderDue();
    }
});
$('hhDue').addEventListener('change', (e) => {
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = ($('hhDue')._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (e.target.matches('[data-all]')) card.querySelectorAll('input[data-id]').forEach((b) => { b.checked = e.target.checked; });
    if (g) paintN(card, g);
});

let BUSY = false;
async function conduct(g, ids) {
    if (BUSY || !ids.length) return;
    if (!EVENT) { toast('Немає події «Вакцинація» — заведіть її в Конструкторі', 'error'); return; }
    const date = $('hhDate').value || iso(today());
    const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
    const ok = await confirmAction(`Внести «${EVENT.name}»${drug ? ` (${drug})` : ''} — крок «${g.st.name}» — ${ids.length} `
        + `${ids.length === 1 ? 'тварині' : 'тваринам'} за ${dmy(parseD(date))}?`, { ok: 'Провести', okClass: 'btn-primary' });
    if (!ok) return;
    BUSY = true;
    try {
        const inputs = { __vstep: sk(g.sc, g.st) };
        if (EVENT.drug_key) inputs[EVENT.drug_key] = g.st.drug || g.st.name;
        const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: ids, event_id: EVENT.id, event_date: date, inputs,
            note: [g.st.name, g.st.dose].filter(Boolean).join(' · '),
        });
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося провести', 'error'); return; }
        const bad = (r.failed || []).length, dup = (r.dupes || []).length;
        toast(`Проведено: ${r.applied || 0}` + (bad ? ` · не вдалося ${bad}: ${(r.failed || []).slice(0, 3).map((x) => `${x.tag} — ${x.error}`).join('; ')}` : '')
            + (dup ? ` · ${dup} уже мали цю подію щойно` : ''), bad ? 'error' : 'success');
        await loadDone();
        renderDue();
        renderHist();
    } finally { BUSY = false; }
}

/* ---------- «Проведені вакцинації»: одне проведення (день · крок чи препарат) — рядок; 15 останніх ---------- */
const HIST_OPEN = new Set();
function renderHist() {
    const byId = new Map(ANIMALS.map((a) => [a.id, a]));
    const groups = new Map();
    V.done().forEach((ev) => {
        const a = byId.get(ev.a);
        if (!a) return;
        const so = V.stepOf(a, ev);
        const key = `${ev.d}|${so ? sk(so.sc, so.st) : 'g:' + (ev.g || '')}`;
        if (!groups.has(key)) groups.set(key, { d: ev.d, so, g: ev.g, rows: [] });
        groups.get(key).rows.push(a);
    });
    const list = [...groups.values()].sort((x, y) => (x.d < y.d ? 1 : x.d > y.d ? -1 : 0));
    const total = list.reduce((t, g) => t + g.rows.length, 0);
    $('hhHistSum').textContent = list.length ? `${total} гол. · ${list.length} ${(list.length % 10 >= 1 && list.length % 10 <= 4 && !(list.length % 100 >= 11 && list.length % 100 <= 14)) ? 'проведення' : 'проведень'}` : '';
    if (!list.length) { $('hhHist').innerHTML = '<div class="hh-empty">Ще нічого не проведено.</div>'; return; }
    const shown = list.slice(0, 15);
    $('hhHist').innerHTML = `<table><thead><tr><th>Дата</th><th>Крок</th><th>Препарат</th><th class="hide-sm">Схема</th><th class="num">Голів</th></tr></thead><tbody>`
        + shown.map((g) => {
            const key = `${g.d}|${g.so ? sk(g.so.sc, g.so.st) : g.g}`;
            const open = HIST_OPEN.has(key);
            const drug = g.so ? [g.so.st.drug, g.so.st.dose].filter(Boolean).join(' · ') : (g.g || '');
            const tags = g.rows.slice().sort((x, y) => String(x.tag).localeCompare(String(y.tag), 'uk', { numeric: true }));
            return `<tr class="hh-hr" data-h="${escapeHtml(key)}"><td>${dmy(parseD(g.d))}</td>
                <td>${g.so ? `<b>${escapeHtml(g.so.st.name)}</b>` : '<span class="mute">поза схемою</span>'}</td>
                <td>${escapeHtml(drug)}</td><td class="hide-sm mute">${g.so ? escapeHtml(g.so.sc.name) : ''}</td>
                <td class="num">${g.rows.length} ${open ? '▾' : '▸'}</td></tr>`
                + (open ? `<tr><td colspan="5" class="tags">${tags.map((a) => `<a href="/herd/animals/${a.id}" title="${escapeHtml(a.name || '')}">${escapeHtml(a.tag || '')}</a>`).join('')}</td></tr>` : '');
        }).join('') + '</tbody></table>'
        + (list.length > 15 ? `<div class="hh-empty">Показано 15 останніх із ${list.length}.</div>` : '');
}
$('hhHist').addEventListener('click', (e) => {
    const tr = e.target.closest('tr.hh-hr');
    if (!tr) return;
    if (HIST_OPEN.has(tr.dataset.h)) HIST_OPEN.delete(tr.dataset.h); else HIST_OPEN.add(tr.dataset.h);
    renderHist();
});

/* ---------- схеми: назва + кроки; крок — рядок формули ---------- */
const stepCount = (st) => {                       // скільки тварин підходить під формулу сьогодні
    const q = V.stepQ(st);
    return q.error ? null : ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters)).length;
};
function stepRow(sc, st) {
    const key = sk(sc, st);
    const q = st.fx ? V.stepQ(st) : null;
    const fxt = st.fx || '— клацніть і впишіть FILTER(…) у рядку формули вгорі';
    return `<tr data-st="${escapeHtml(st.id)}" class="${st.off ? 'is-off' : ''}${key === SEL ? ' is-sel' : ''}">
        <td class="hh-grip" title="Тягніть, щоб переставити крок">⠿</td>
        <td><input class="hh-in w-sn" data-f="name" value="${escapeHtml(st.name || '')}" placeholder="Хіпра 1" maxlength="40"></td>
        <td><input class="hh-in w-drug" data-f="drug" value="${escapeHtml(st.drug || '')}" placeholder="Хіпрабовіс 4" maxlength="60"></td>
        <td><input class="hh-in w-rem" data-f="rem" value="${escapeHtml(st.rem || '')}" placeholder="1-hiprabovis 4-3 ml" maxlength="80"
            title="Ремарка — так її покаже список у «Примітці» (FILTER(vacc=[крок]))"></td>
        <td><input class="hh-in w-dose" data-f="dose" value="${escapeHtml(st.dose || '')}" placeholder="3 мл" maxlength="20"></td>
        <td class="hh-days" title="Дні проведення кроку; жодного — щодня">${WD.map((w, i) => `<button type="button" data-wd="${i + 1}" class="${(st.days || []).includes(i + 1) ? 'is-on' : ''}">${w}</button>`).join('')}</td>
        <td class="hh-fxc${q && q.error ? ' is-bad' : ''}${st.fx ? '' : ' is-empty'}" title="${escapeHtml(q && q.error ? q.error : 'Формула кроку — клацніть, і вона відкриється в рядку формули вгорі')}">${escapeHtml(fxt)}</td>
        <td><button type="button" class="hh-act${st.off ? '' : ' is-on'}" data-act title="Неактивний крок у «До вакцинації» і в vacc не рахується">${st.off ? 'неактивний' : 'активний'}</button></td>
        <td><button type="button" class="hh-x" data-delst title="Прибрати крок">✕</button></td></tr>`;
}
function renderSchemes() {
    const box = $('hhSchemes');
    if (!SCHEMES.length) { box.innerHTML = '<div class="hh-empty">Натисніть «+ схема»: назва і кроки — препарат, доза й формула, кому.</div>'; return; }
    box.innerHTML = SCHEMES.map((sc) => `<div class="hh-sch" data-sc="${escapeHtml(sc.id)}">
        <div class="hh-sch-head">
            <span class="hh-grip" data-sgrip title="Тягніть, щоб переставити схему">⠿</span>
            <input class="hh-in w-name" data-sf="name" value="${escapeHtml(sc.name || '')}" placeholder="Назва схеми" maxlength="60">
            <span class="hh-wn">${sc.steps.length} ${sc.steps.length === 1 ? 'крок' : (sc.steps.length % 10 >= 2 && sc.steps.length % 10 <= 4 && !(sc.steps.length % 100 >= 12 && sc.steps.length % 100 <= 14)) ? 'кроки' : 'кроків'}</span>
            <button type="button" class="hh-link" data-addst>+ крок</button>
            <button type="button" class="hh-x" data-delsc title="Видалити схему">✕</button>
        </div>
        <table class="hh-steps"><thead><tr><th></th><th>Крок</th><th>Препарат</th><th>Ремарка</th><th>Доза</th><th>Дні</th><th class="hh-fxh">Кому — формула</th><th></th><th></th></tr></thead>
            <tbody>${sc.steps.map((st) => stepRow(sc, st)).join('')}</tbody></table>
    </div>`).join('');
}
const scOf = (el) => SCHEMES.find((x) => x.id === el.closest('[data-sc]').dataset.sc);
const stOf = (sc, el) => sc.steps.find((x) => x.id === el.closest('[data-st]').dataset.st);

let SAVE_T = 0, SAVE_SEQ = 0;
function saveSoon() { clearTimeout(SAVE_T); $('hhSaved').textContent = 'зберігаю…'; $('hhSaved').classList.remove('is-bad'); SAVE_T = setTimeout(save, 500); }
async function save() {
    const my = ++SAVE_SEQ;
    const r = await apiSend('/api/herd/vacc/schemes', 'POST', { schemes: SCHEMES }).catch(() => null);
    if (my !== SAVE_SEQ) return;
    if (!r || r.ok === false) {
        $('hhSaved').textContent = '⚠ ' + ((r && r.error) || 'не збереглося');
        $('hhSaved').classList.add('is-bad');
        return;
    }
    // сервер дає id новим — беремо їх, решту лишаємо як є (фокус у полі не губимо)
    (r.schemes || []).forEach((s2, i) => {
        const s1 = SCHEMES[i];
        if (!s1) return;
        const was = SEL;
        if (s1.id !== s2.id) {
            const el = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"]`);
            if (SEL.startsWith(s1.id + ':')) SEL = s2.id + SEL.slice(s1.id.length);
            s1.id = s2.id;
            if (el) el.dataset.sc = s2.id;
        }
        (s2.steps || []).forEach((t2, j) => {
            const t1 = s1.steps[j];
            if (t1 && t1.id !== t2.id) {
                if (was === `${s1.id}:${t1.id}` || SEL === `${s1.id}:${t1.id}`) SEL = `${s1.id}:${t2.id}`;
                const tr = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"] [data-st="${CSS.escape(t1.id)}"]`);
                t1.id = t2.id;
                if (tr) tr.dataset.st = t2.id;
            }
        });
    });
    $('hhSaved').textContent = 'збережено';
    setTimeout(() => { if (my === SAVE_SEQ && !$('hhSaved').classList.contains('is-bad')) $('hhSaved').textContent = ''; }, 1500);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderDue();
    renderHist();                                  // назви кроків у журналі — свіжі
}
let NID = 0;
const nid = (p) => p + Date.now().toString(36) + (++NID);
function newStep(sc) {
    const last = sc.steps[sc.steps.length - 1];
    return { id: nid('k'), name: `Крок ${sc.steps.length + 1}`, drug: last ? last.drug : '', rem: '', dose: last ? last.dose : '',
        off: 0, fx: last && last.fx ? last.fx : '', days: last && last.days ? last.days.slice() : [] };     // формулу попереднього — щоб лише поправити дні
}
function selectStep(sc, st, focusFx) {
    SEL = sk(sc, st);
    $('hhSchemes').querySelectorAll('tr[data-st]').forEach((tr) => {
        tr.classList.toggle('is-sel', `${tr.closest('[data-sc]').dataset.sc}:${tr.dataset.st}` === SEL);
    });
    fxRender();
    if (focusFx && FX) FX.focus();
}
$('hhAddScheme').addEventListener('click', () => {
    let name = 'Нова схема', i = 1;
    while (SCHEMES.some((s) => s.name === name)) name = `Нова схема ${++i}`;
    const sc = { id: nid('v'), name, who: '', off: 0, steps: [] };
    sc.steps.push(newStep(sc));
    SCHEMES.push(sc);
    SEL = sk(sc, sc.steps[0]);
    renderSchemes();
    fxRender();
    saveSoon();
    const els = document.querySelectorAll('#hhSchemes .w-name');
    const el = els[els.length - 1];
    if (el) { el.focus(); el.select(); }
});
$('hhSchemes').addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('[data-addst]')) {
        const sc = scOf(t);
        const st = newStep(sc);
        sc.steps.push(st);
        SEL = sk(sc, st);
        renderSchemes();
        fxRender();
        saveSoon();
        if (FX) FX.focus();
        return;
    }
    if (t.closest('[data-delst]')) {
        const sc = scOf(t);
        const id = t.closest('[data-st]').dataset.st;
        if (sc.steps.some((x) => x.base === 'step' && x.prev === id && !x.fx)) { toast('Від цього кроку рахується інший — спершу перепишіть той формулою', 'error'); return; }
        const st = stOf(sc, t);
        if (!await confirmAction(`Прибрати крок «${st.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Прибрати' })) return;
        sc.steps = sc.steps.filter((x) => x.id !== id);
        renderSchemes();
        fxRender();
        saveSoon();
        return;
    }
    if (t.closest('[data-delsc]')) {
        const sc = scOf(t);
        if (!await confirmAction(`Видалити схему «${sc.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Видалити' })) return;
        SCHEMES = SCHEMES.filter((x) => x !== sc);
        renderSchemes();
        fxRender();
        saveSoon();
        return;
    }
    if (t.closest('[data-wd]')) {                       // день проведення кроку
        const sc = scOf(t);
        const st = stOf(sc, t);
        const d = +t.closest('[data-wd]').dataset.wd;
        const ds = new Set(st.days || []);
        if (ds.has(d)) ds.delete(d); else ds.add(d);
        st.days = [...ds].sort();
        t.closest('[data-wd]').classList.toggle('is-on', ds.has(d));
        saveSoon();
        return;
    }
    if (t.closest('[data-act]')) {
        const sc = scOf(t);
        const st = stOf(sc, t);
        st.off = st.off ? 0 : 1;
        renderSchemes();
        saveSoon();
        return;
    }
    const tr = t.closest('tr[data-st]');
    if (tr && !t.closest('.hh-grip')) {                // клік по кроку — його формула в рядку вгорі
        const sc = scOf(t);
        selectStep(sc, stOf(sc, t), !!t.closest('.hh-fxc'));
    }
});
$('hhSchemes').addEventListener('focusin', (e) => {
    const tr = e.target.closest('tr[data-st]');
    if (!tr) return;
    const sc = scOf(tr);
    if (`${sc.id}:${tr.dataset.st}` !== SEL) selectStep(sc, stOf(sc, tr), false);
});
$('hhSchemes').addEventListener('change', (e) => {
    const t = e.target;
    const sc = scOf(t);
    if (!sc) return;
    if (t.dataset.sf) { sc[t.dataset.sf] = t.value.trim(); saveSoon(); return; }
    const tr = t.closest('[data-st]');
    if (!tr || !t.dataset.f) return;
    const st = stOf(sc, t);
    st[t.dataset.f] = t.value.trim();
    if (t.dataset.f === 'name') fxRender();
    saveSoon();
});
$('hhSchemes').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches('input.hh-in')) { e.preventDefault(); e.target.blur(); }
});

/* перетягування кроків угору-вниз за ⠿ (у межах своєї схеми) */
let DRAG = null, SDRAG = null;                    // крок у схемі · схема цілком
$('hhSchemes').addEventListener('mousedown', (e) => {
    const g = e.target.closest('.hh-grip');
    if (!g) return;
    if (g.dataset.sgrip !== undefined) g.closest('.hh-sch').draggable = true;
    else g.closest('tr').draggable = true;
});
$('hhSchemes').addEventListener('dragstart', (e) => {
    const box = e.target.closest && e.target.closest('.hh-sch');
    if (box && box === e.target && box.draggable) {      // схема — переставляємо цілком
        SDRAG = box.dataset.sc;
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', SDRAG); } catch (er) { /* ignore */ }
        box.classList.add('is-drag');
        return;
    }
    const tr = e.target.closest && e.target.closest('tr[data-st]');
    if (!tr || !tr.draggable) return;
    DRAG = { sc: tr.closest('[data-sc]').dataset.sc, st: tr.dataset.st };
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', DRAG.st); } catch (er) { /* ignore */ }
    tr.classList.add('is-drag');
});
const dropClear = () => $('hhSchemes').querySelectorAll('.drop-before, .drop-after').forEach((x) => x.classList.remove('drop-before', 'drop-after'));
$('hhSchemes').addEventListener('dragover', (e) => {
    if (SDRAG) {
        const box = e.target.closest('.hh-sch');
        if (!box) return;
        e.preventDefault();
        dropClear();
        const r = box.getBoundingClientRect();
        box.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
        return;
    }
    if (!DRAG) return;
    const tr = e.target.closest('tr[data-st]');
    if (!tr || tr.closest('[data-sc]').dataset.sc !== DRAG.sc) return;
    e.preventDefault();
    dropClear();
    const r = tr.getBoundingClientRect();
    tr.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
});
$('hhSchemes').addEventListener('drop', (e) => {
    if (SDRAG) {
        const box = e.target.closest('.hh-sch');
        if (!box) return;
        e.preventDefault();
        const moving = SCHEMES.find((x) => x.id === SDRAG);
        const target = SCHEMES.find((x) => x.id === box.dataset.sc);
        if (moving && target && moving !== target) {
            const after = box.classList.contains('drop-after');
            const rest = SCHEMES.filter((x) => x !== moving);
            rest.splice(rest.indexOf(target) + (after ? 1 : 0), 0, moving);
            SCHEMES = rest;
            renderSchemes();
            saveSoon();
        }
        return;
    }
    if (!DRAG) return;
    const tr = e.target.closest('tr[data-st]');
    if (!tr || tr.closest('[data-sc]').dataset.sc !== DRAG.sc) return;
    e.preventDefault();
    const sc = SCHEMES.find((x) => x.id === DRAG.sc);
    const after = tr.classList.contains('drop-after');
    const moving = sc.steps.find((x) => x.id === DRAG.st);
    const target = sc.steps.find((x) => x.id === tr.dataset.st);
    if (moving && target && moving !== target) {
        const rest = sc.steps.filter((x) => x !== moving);
        rest.splice(rest.indexOf(target) + (after ? 1 : 0), 0, moving);
        sc.steps = rest;
        renderSchemes();
        saveSoon();
    }
});
// натиснули ⠿ і відпустили без перетягування — рядок і схема знову звичайні (інакше поля в них тягнулись би)
document.addEventListener('mouseup', () => {
    if (DRAG || SDRAG) return;
    $('hhSchemes').querySelectorAll('[draggable="true"]').forEach((x) => { x.draggable = false; });
});
$('hhSchemes').addEventListener('dragend', () => {
    dropClear();
    $('hhSchemes').querySelectorAll('[draggable="true"]').forEach((x) => { x.draggable = false; x.classList.remove('is-drag'); });
    DRAG = null; SDRAG = null;
});

/* ---------- рядок формули вгорі: формула вибраного кроку ---------- */
let FX = null;
const FX_PH = 'FILTER(lact=0 rc<9 days_life between 49 55) — кому цей крок; Enter — записати';
const selPair = () => {
    for (const sc of SCHEMES) for (const st of sc.steps) if (sk(sc, st) === SEL) return { sc, st };
    return null;
};
function fxMsg(t, bad) { $('hhFxMsg').textContent = t || ''; $('hhFxMsg').classList.toggle('bad', !!bad); }
function fxShown(st) { return st.fx ? window.herdQuery.canon(st.fx) : ''; }
function fxNote(pr) {
    if (!pr) return '';
    if (!pr.st.fx) return `Крок «${pr.st.name}» — впишіть, кому: FILTER(…)`;
    const n = stepCount(pr.st);
    return n === null ? '' : `Крок «${pr.st.name}» (${pr.sc.name}) — під формулу зараз підходить ${n} гол.`;
}
function fxRender() {
    if (!FX) {
        FX = herdFxEdit($('hhFx'), {
            params: () => PARAMS,
            groups: () => [...new Set(ANIMALS.map((a) => a.group_name).filter(Boolean))],
            acts: ['FILTER'],
            placeholder: FX_PH,
            onEnter: () => fxApply(),
            onInput: () => { $('hhFx').classList.remove('is-bad'); fxMsg(''); },
        });
        FX.input.addEventListener('blur', () => { const pr = selPair(); if (pr && FX.get().trim() !== fxShown(pr.st)) fxApply(); });
    }
    const pr = selPair();
    FX.input.disabled = !pr;
    FX.input.placeholder = pr ? FX_PH : 'Клацніть крок схеми — його формула відкриється тут';
    FX.set(pr ? fxShown(pr.st) : '');
    $('hhFx').classList.remove('is-bad');
    fxMsg(fxNote(pr));
}
async function fxApply() {
    const pr = selPair();
    if (!pr) return;
    let text = window.herdQuery.canon(FX.get());
    if (text && !/^FILTER\s*\(/i.test(text)) {
        if (/\(/.test(text)) { $('hhFx').classList.add('is-bad'); fxMsg('Крок — лише FILTER(…): BODY і VIEW тут не потрібні', true); return; }
        text = `FILTER(${text})`;
    }
    if (text) {
        const q = window.herdQuery.parse(text, PARAMS);
        if (q.error) { $('hhFx').classList.add('is-bad'); fxMsg(q.error, true); return; }
        if ((q.keys || []).includes('vacc')) { $('hhFx').classList.add('is-bad'); fxMsg('Формула кроку не може залежати від vacc', true); return; }
        if (q.cols.length || q.groups.length || q.sorts.length || (q.extra || []).length || q.aggs.length) {
            $('hhFx').classList.add('is-bad'); fxMsg('Крок — лише FILTER(…) з умовами', true); return;
        }
    }
    if (text === (pr.st.fx || '')) { FX.set(fxShown(pr.st)); return; }
    pr.st.fx = text;
    // формула замінює давнє «від чого рахувати»
    ['base', 'prev', 'from', 'to'].forEach((k) => { delete pr.st[k]; });
    FX.set(fxShown(pr.st));
    V.setSchemes(SCHEMES);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderSchemes();
    fxMsg(fxNote(pr) + ' — записано');
    saveSoon();
}
/* рядок формули тримається вгорі під час прокрутки — як у «Роботі зі стадом» і Календарі */
(function () {
    const bar = $('hhFxTop');
    const topbar = document.querySelector('.topbar');
    if (!bar) return;
    let TOP = null, IO = null;
    const barTop = () => (topbar && getComputedStyle(topbar).position === 'sticky' ? topbar.offsetHeight : 0);
    function place() {
        const t = barTop();
        if (t === TOP) return;
        TOP = t;
        bar.style.top = (t - 1) + 'px';
        if (!window.IntersectionObserver) return;
        if (IO) IO.disconnect();
        IO = new IntersectionObserver(([en]) => { bar.classList.toggle('is-stuck', en.intersectionRatio < 1); },
            { threshold: [1], rootMargin: `${-t}px 0px 0px 0px` });
        IO.observe(bar);
    }
    place();
    window.addEventListener('resize', place);
    if (window.ResizeObserver && topbar) new ResizeObserver(place).observe(topbar);
}());

/* ---------- дані ---------- */
let LOADED = new Set();
async function loadAnimals() {
    const keys = needKeys().filter((k) => PARAMS.some((p) => p.key === k));
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(','))).catch(() => null);
    if (!r || !r.ok) { toast('Стадо не прочиталось — оновіть сторінку', 'error'); return; }
    ANIMALS = r.items || [];
    LOADED = new Set(needKeys());
}
async function loadDone() {
    const r = await V.load();
    if (!r) return false;
    EVENT = r.event || null;
    return r;
}
/* СТАН СТОРІНКИ ПЕРЕЖИВАЄ ОНОВЛЕННЯ (Роман 2026-10-01): вибраний крок, розгорнуті картки й рядки журналу, дата
   вакцинації (лише сьогоднішня — завтра знову сьогодні) і прокрутка */
const STATE_KEY = 'herd:health_state';
function stateSave() {
    try {
        localStorage.setItem(STATE_KEY, JSON.stringify({ sel: SEL, open: [...OPEN], hist: [...HIST_OPEN],
            date: { on: iso(today()), v: $('hhDate').value } }));
        sessionStorage.setItem(STATE_KEY + ':scroll', String(window.scrollY));
    } catch (e) { /* ignore */ }
}
function stateLoad() {
    let st = null;
    try { st = JSON.parse(localStorage.getItem(STATE_KEY) || 'null'); } catch (e) { st = null; }
    if (!st) return;
    if (st.sel) SEL = st.sel;
    if (Array.isArray(st.open)) { st.open.forEach((k) => OPEN.add(k)); FIRST = false; }
    if (Array.isArray(st.hist)) st.hist.forEach((k) => HIST_OPEN.add(k));
    if (st.date && st.date.on === iso(today()) && st.date.v) $('hhDate').value = st.date.v;
}
let SAVE_ST = 0;
const stateSoon = () => { clearTimeout(SAVE_ST); SAVE_ST = setTimeout(stateSave, 250); };
window.addEventListener('scroll', stateSoon, { passive: true });
window.addEventListener('pagehide', stateSave);
document.addEventListener('click', stateSoon);
$('hhDate').addEventListener('change', stateSoon);
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
function scrollRestore() {
    let y = 0;
    try { y = +sessionStorage.getItem(STATE_KEY + ':scroll') || 0; } catch (e) { y = 0; }
    if (!y) return;
    // над сторінкою ще довантажуються банери — доганяємо позицію кілька разів, доки людина сама не прокрутила
    let user = false;
    const stop = () => { user = true; };
    ['wheel', 'touchstart', 'keydown', 'mousedown'].forEach((ev) => window.addEventListener(ev, stop, { once: true, passive: true }));
    [0, 150, 400, 800, 1500, 2500].forEach((ms) => setTimeout(() => { if (!user) window.scrollTo(0, y); }, ms));
}
async function boot() {
    $('hhDate').value = iso(today());
    stateLoad();
    const [ev, v] = await Promise.all([apiGet('/api/herd/events?lite=1').catch(() => null), loadDone()]);
    if (!ev || !ev.ok || !v) { $('hhSum').textContent = 'Не вдалося завантажити'; return; }
    PARAMS = ev.params || [];
    V.use({ params: () => PARAMS });
    window.HERD_CONSTS = ev.consts || [];
    SCHEMES = V.normSchemes((v.schemes || []).map((s) => Object.assign({ steps: [] }, JSON.parse(JSON.stringify(s)))));
    // давні кроки (від дати + дні) — одразу формулою, коли її можна скласти (дні життя, DIM); записується з першою правкою
    SCHEMES.forEach((sc) => sc.steps.forEach((st) => {
        if (st.fx) return;
        const f = V.fxOfLegacy(sc, st);
        if (f) { st.fx = f; ['base', 'prev', 'from', 'to'].forEach((k) => { delete st[k]; }); }
    }));
    if (!selPair() && SCHEMES.length && SCHEMES[0].steps.length) SEL = sk(SCHEMES[0], SCHEMES[0].steps[0]);
    V.setSchemes(SCHEMES);
    await loadAnimals();
    renderSchemes();
    fxRender();
    renderDue();
    renderHist();
    scrollRestore();
}
boot();
})();
