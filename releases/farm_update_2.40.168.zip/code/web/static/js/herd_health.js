/* ЗДОРОВ’Я СТАДА — ВАКЦИНАЦІЯ (Роман 2026-10-01: «окремий блок вакцинація тварин — прописувати схему вакцинації й
   впроваджувати в списки» → обрав: строк кроку — від віку чи від події; проведено — подія й тварина зникає зі списку;
   аптеку поки не списуємо).
   📌 Схема: кого (умови мовою списків, напр. lact=0) і кроки: препарат, доза, від чого рахувати, вікно днів.
      age — днів життя · calving — днів після отелу · due — днів до очікуваного отелу · dryoff — днів після запуску ·
      step — днів після того, як провели попередній крок (ревакцинація).
   📌 Хто кому вже зроблено — подія «Вакцинація» з полем __vstep «схема:крок» (сервер: /api/herd/vacc → done).
   📌 Кому час — рахуємо тут, на живих тваринах: «зараз» (у вікні), «прострочено» (до 30 днів по вікну), «скоро» (до 14
      днів до вікна). «Провести» — груповий запис події тим, кого відмічено. */
'use strict';
(function () {
const $ = (id) => document.getElementById(id);
if (!$('hhDue')) return;

const BASES = [
    ['age', 'днів життя'], ['calving', 'днів після отелу'], ['due', 'днів до отелу'],
    ['dryoff', 'днів після запуску'], ['step', 'днів після кроку'],
];
// дата, від якої рахується крок, — з параметрів тварини

let PARAMS = [], SCHEMES = [], EVENT = null, ANIMALS = [];
const OPEN = new Set();                              // розгорнуті кроки (до першого рендера — усі, де є «зараз»)
let FIRST = true;

const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const parseD = (s) => {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const dm = (d) => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
const dmy = (d) => `${dm(d)}.${d.getFullYear()}`;
const sk = (sc, st) => `${sc.id}:${st.id}`;

/* ---------- хто кому час ---------- */
/* рахунок — спільний із мовою списків (herd_vacc.js): одна схема — одні числа скрізь */
const V = window.herdVacc;
const whoQ = (sc) => V.whoQ(sc);
const needKeys = () => V.deps();
const stateOf = (a, sc, st, t0) => V.stateOf(a, sc, st, t0);
function computeDue() {
    const t0 = today();
    const out = [];
    SCHEMES.forEach((sc) => {
        if (sc.off) return;
        const q = whoQ(sc);
        if (q.error) return;
        const who = ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters));
        sc.steps.forEach((st) => {
            const rows = [];
            who.forEach((a) => { const s = stateOf(a, sc, st, t0); if (s) rows.push(Object.assign({ a }, s)); });
            if (!rows.length) return;
            const rank = { late: 0, now: 1, soon: 2 };
            rows.sort((p, r) => rank[p.st] - rank[r.st] || String(p.a.tag).localeCompare(String(r.a.tag), 'uk', { numeric: true }));
            out.push({ sc, st, rows });
        });
    });
    return out;
}

/* ---------- «До вакцинації» ---------- */
const xLabel = (st, x) => (st.base === 'age' ? `${x} дн. життя` : st.base === 'due' ? `за ${x} дн. до отелу`
    : st.base === 'calving' ? `${x} дн. після отелу` : st.base === 'dryoff' ? `${x} дн. після запуску` : `${x} дн. після кроку`);
const stLabel = (r) => (r.st === 'now' ? 'зараз' : r.st === 'late' ? `прострочено на ${r.n} дн.` : `через ${r.n} дн.`);
function renderDue() {
    V.setSchemes(SCHEMES);                         // правки схеми — одразу в спільному рахунку
    const box = $('hhDue');
    if (!SCHEMES.length) {
        $('hhSum').textContent = '';
        box.innerHTML = '<div class="hh-empty">Схем вакцинації ще немає — додайте нижче «+ схема».</div>';
        return;
    }
    const list = computeDue();
    let now = 0, late = 0, soon = 0;
    list.forEach((g) => g.rows.forEach((r) => { if (r.st === 'now') now++; else if (r.st === 'late') late++; else soon++; }));
    $('hhSum').innerHTML = list.length
        ? `зараз <b>${now}</b>` + (late ? ` · прострочено <b>${late}</b>` : '') + (soon ? ` · скоро ${soon}` : '')
        : 'нікому — усе зроблено';
    if (!list.length) { box.innerHTML = '<div class="hh-empty">Зараз нікого: кому за схемами час — уже вакциновані.</div>'; return; }
    if (FIRST) { list.forEach((g) => { if (g.rows.some((r) => r.st !== 'soon')) OPEN.add(sk(g.sc, g.st)); }); FIRST = false; }
    box.innerHTML = list.map((g) => {
        const key = sk(g.sc, g.st);
        const c = (s) => g.rows.filter((r) => r.st === s).length;
        const open = OPEN.has(key);
        // за замовчуванням — лише «зараз»: прострочених могли колоти без запису, їх відмічають свідомо
        const pick = g.rows.filter((r) => r.st === 'now').length;
        const pills = [['late', c('late'), 'прострочено'], ['now', c('now'), 'зараз'], ['soon', c('soon'), 'скоро']]
            .filter((p) => p[1]).map((p) => `<span class="hh-pill ${p[0]}" title="${p[2]}">${p[1]} ${p[2]}</span>`).join('');
        const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
        return `<div class="hh-step" data-k="${escapeHtml(key)}">
            <div class="hh-sh" data-tog="${escapeHtml(key)}">
                <span class="hh-chev">${open ? '▾' : '▸'}</span>
                <span class="nm">${escapeHtml(g.st.name)}</span>
                ${drug ? `<span class="dr">${escapeHtml(drug)}</span>` : ''}
                <span class="sc">${escapeHtml(g.sc.name)}</span>
                <span class="cnt">${pills}</span>
                <button type="button" class="btn btn-primary btn-sm" data-go="${escapeHtml(key)}"${pick ? '' : ' disabled'}>Провести · <span data-n>${pick}</span></button>
            </div>
            ${open ? `<table class="hh-tbl"><thead><tr><th class="ck"><input type="checkbox" data-all${pick ? ' checked' : ''}></th>
                <th>Номер</th><th class="hide-sm">Кличка</th><th>Строк</th><th class="hide-sm">Вікно</th><th>Стан</th></tr></thead><tbody>
                ${g.rows.map((r) => `<tr><td class="ck"><input type="checkbox" data-id="${r.a.id}"${r.st === 'now' ? ' checked' : ''}></td>
                    <td><a href="/herd/animals/${r.a.id}">${escapeHtml(r.a.tag || '')}</a></td>
                    <td class="hide-sm">${escapeHtml(r.a.name || '')}</td>
                    <td>${escapeHtml(xLabel(g.st, r.x))}</td>
                    <td class="hide-sm">${dm(r.w1)}–${dmy(r.w2)}</td>
                    <td><span class="hh-st ${r.st}">${stLabel(r)}</span></td></tr>`).join('')}
                </tbody></table>` : ''}
        </div>`;
    }).join('');
    box._list = list;
}
function picked(card, g) {
    const boxes = card.querySelectorAll('input[data-id]');
    if (!boxes.length) return g.rows.filter((r) => r.st === 'now').map((r) => r.a.id);   // згорнуто — лише «зараз»
    return [...boxes].filter((b) => b.checked).map((b) => +b.dataset.id);
}
function paintN(card, g) {
    const n = picked(card, g).length;
    const btn = card.querySelector('[data-go]');
    btn.querySelector('[data-n]').textContent = n;
    btn.disabled = !n;
}
$('hhDue').addEventListener('click', async (e) => {
    const box = $('hhDue');
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = (box._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (!g) return;
    const go = e.target.closest('[data-go]');
    if (go) { e.stopPropagation(); conduct(g, picked(card, g)); return; }
    if (e.target.closest('input, a')) return;
    if (e.target.closest('[data-tog]')) {
        if (OPEN.has(card.dataset.k)) OPEN.delete(card.dataset.k); else OPEN.add(card.dataset.k);
        renderDue();
    }
});
$('hhDue').addEventListener('change', (e) => {
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = ($('hhDue')._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (e.target.matches('[data-all]')) card.querySelectorAll('input[data-id]').forEach((b) => { b.checked = e.target.checked; });
    if (g) paintN(card, g);
});

let BUSY = false;
async function conduct(g, ids) {
    if (BUSY || !ids.length) return;
    if (!EVENT) { toast('Немає події «Вакцинація» — заведіть її в Конструкторі', 'error'); return; }
    const date = $('hhDate').value || iso(today());
    const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
    const ok = await confirmAction(`Внести «${EVENT.name}»${drug ? ` (${drug})` : ''} — крок «${g.st.name}» — ${ids.length} `
        + `${ids.length === 1 ? 'тварині' : 'тваринам'} за ${dmy(parseD(date))}?`, { ok: 'Провести', okClass: 'btn-primary' });
    if (!ok) return;
    BUSY = true;
    try {
        const inputs = { __vstep: sk(g.sc, g.st) };
        if (EVENT.drug_key) inputs[EVENT.drug_key] = g.st.drug || g.st.name;
        const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: ids, event_id: EVENT.id, event_date: date, inputs,
            note: [g.st.name, g.st.dose].filter(Boolean).join(' · '),
        });
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося провести', 'error'); return; }
        const bad = (r.failed || []).length, dup = (r.dupes || []).length;
        toast(`Проведено: ${r.applied || 0}` + (bad ? ` · не вдалося ${bad}: ${(r.failed || []).slice(0, 3).map((x) => `${x.tag} — ${x.error}`).join('; ')}` : '')
            + (dup ? ` · ${dup} уже мали цю подію щойно` : ''), bad ? 'error' : 'success');
        await loadDone();
        renderDue();
    } finally { BUSY = false; }
}

/* ---------- схеми ---------- */
const sel = (opts, v, cls) => `<select class="hh-in ${cls}">${opts.map(([k, l]) => `<option value="${escapeHtml(k)}"${k === v ? ' selected' : ''}>${escapeHtml(l)}</option>`).join('')}</select>`;
function whoNote(sc) {
    if (!String(sc.who || '').trim()) return '<span class="ok">усе стадо</span>';
    const q = whoQ(sc);
    if (q.error) return `<span class="msg">⚠ ${escapeHtml(q.error)}</span>`;
    const n = ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters)).length;
    return `<span class="ok">зараз ${n} гол.</span>`;
}
function stepRow(sc, st, i) {
    const prevs = sc.steps.slice(0, i).map((x) => [x.id, x.name || '—']);
    const dueB = st.base === 'due';
    return `<tr data-st="${escapeHtml(st.id)}">
        <td><input class="hh-in w-sn" data-f="name" value="${escapeHtml(st.name || '')}" placeholder="Хіпра 1" maxlength="40"></td>
        <td><input class="hh-in w-drug" data-f="drug" value="${escapeHtml(st.drug || '')}" placeholder="Хіпрабовіс 4" maxlength="60"></td>
        <td><input class="hh-in w-dose" data-f="dose" value="${escapeHtml(st.dose || '')}" placeholder="3 мл" maxlength="20"></td>
        <td class="hh-base">${sel(BASES.filter((b) => b[0] !== 'step' || prevs.length), st.base, 'w-base" data-f="base')}${st.base === 'step' ? sel(prevs, st.prev, 'w-prev" data-f="prev') : ''}</td>
        <td><span class="sep">${dueB ? 'за' : 'з'}</span><input class="hh-in w-d" data-f="from" inputmode="numeric" value="${st.from}"><span class="sep">по</span><input class="hh-in w-d" data-f="to" inputmode="numeric" value="${st.to}"><span class="sep">${dueB ? 'дн.' : 'день'}</span></td>
        <td><button type="button" class="hh-x" data-delst title="Прибрати крок">✕</button></td></tr>`;
}
function renderSchemes() {
    const box = $('hhSchemes');
    if (!SCHEMES.length) { box.innerHTML = '<div class="hh-empty">Натисніть «+ схема»: назва, кого вакцинуємо, і кроки — препарат, доза, коли.</div>'; return; }
    box.innerHTML = SCHEMES.map((sc) => `<div class="hh-sch${sc.off ? ' is-off' : ''}" data-sc="${escapeHtml(sc.id)}">
        <div class="hh-sch-head">
            <input class="hh-in w-name" data-sf="name" value="${escapeHtml(sc.name || '')}" placeholder="Назва схеми" maxlength="60">
            <span class="lab">Кого</span>
            <input class="hh-in w-who" data-sf="who" value="${escapeHtml(sc.who || '')}" placeholder="lact=0 — молодняк; порожньо — усе стадо" spellcheck="false"
                title="Умови мовою списків «Роботи зі стадом»">
            <span class="hh-wn" data-whonote>${whoNote(sc)}</span>
            <label class="hh-off" title="Схема на паузі — у «До вакцинації» не рахується"><input type="checkbox" data-sf="off"${sc.off ? ' checked' : ''}> пауза</label>
            <button type="button" class="hh-link" data-addst>+ крок</button>
            <button type="button" class="hh-x" data-delsc title="Видалити схему">✕</button>
        </div>
        <table class="hh-steps"><thead><tr><th>Крок</th><th>Препарат</th><th>Доза</th><th>Від чого рахувати</th><th>Коли</th><th></th></tr></thead>
            <tbody>${sc.steps.map((st, i) => stepRow(sc, st, i)).join('')}</tbody></table>
    </div>`).join('');
}
const scOf = (el) => SCHEMES.find((x) => x.id === el.closest('[data-sc]').dataset.sc);

let SAVE_T = 0, SAVE_SEQ = 0;
function saveSoon() { clearTimeout(SAVE_T); $('hhSaved').textContent = 'зберігаю…'; $('hhSaved').classList.remove('is-bad'); SAVE_T = setTimeout(save, 500); }
async function save() {
    const my = ++SAVE_SEQ;
    const bad = SCHEMES.find((sc) => whoQ(sc).error);   // бита умова «Кого» — не пишемо, доки не виправлять
    if (bad) {
        $('hhSaved').textContent = `⚠ «${bad.name}»: виправте умову «Кого» — не збережено`;
        $('hhSaved').classList.add('is-bad');
        return;
    }
    const r = await apiSend('/api/herd/vacc/schemes', 'POST', { schemes: SCHEMES }).catch(() => null);
    if (my !== SAVE_SEQ) return;
    if (!r || r.ok === false) {
        $('hhSaved').textContent = '⚠ ' + ((r && r.error) || 'не збереглося');
        $('hhSaved').classList.add('is-bad');
        return;
    }
    // сервер дає id новим — беремо їх, решту лишаємо як є (фокус у полі не губимо)
    (r.schemes || []).forEach((s2, i) => {
        const s1 = SCHEMES[i];
        if (!s1) return;
        if (s1.id !== s2.id) { const el = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"]`); s1.id = s2.id; if (el) el.dataset.sc = s2.id; }
        (s2.steps || []).forEach((t2, j) => { if (s1.steps[j] && s1.steps[j].id !== t2.id) s1.steps[j].id = t2.id; });
    });
    $('hhSaved').textContent = 'збережено';
    setTimeout(() => { if (my === SAVE_SEQ && !$('hhSaved').classList.contains('is-bad')) $('hhSaved').textContent = ''; }, 1500);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderDue();
}
let NID = 0;
const nid = (p) => p + Date.now().toString(36) + (++NID);
$('hhAddScheme').addEventListener('click', () => {
    let name = 'Нова схема', i = 1;
    while (SCHEMES.some((s) => s.name === name)) name = `Нова схема ${++i}`;
    SCHEMES.push({ id: nid('v'), name, who: '', off: 0, steps: [{ id: nid('k'), name: 'Крок 1', drug: '', dose: '', base: 'age', prev: '', from: 0, to: 7 }] });
    renderSchemes();
    saveSoon();
    const els = document.querySelectorAll('#hhSchemes .w-name');
    const el = els[els.length - 1];
    if (el) { el.focus(); el.select(); }
});
$('hhSchemes').addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('[data-addst]')) {
        const sc = scOf(t);
        const last = sc.steps[sc.steps.length - 1];
        sc.steps.push({ id: nid('k'), name: `Крок ${sc.steps.length + 1}`, drug: last ? last.drug : '', dose: last ? last.dose : '',
            base: last ? 'step' : 'age', prev: last ? last.id : '', from: last ? 21 : 0, to: last ? 28 : 7 });
        renderSchemes();
        saveSoon();
        return;
    }
    if (t.closest('[data-delst]')) {
        const sc = scOf(t);
        const id = t.closest('[data-st]').dataset.st;
        if (sc.steps.some((x) => x.base === 'step' && x.prev === id)) { toast('Від цього кроку рахується інший — спершу змініть той', 'error'); return; }
        sc.steps = sc.steps.filter((x) => x.id !== id);
        renderSchemes();
        saveSoon();
        return;
    }
    if (t.closest('[data-delsc]')) {
        const sc = scOf(t);
        if (!await confirmAction(`Видалити схему «${sc.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Видалити' })) return;
        SCHEMES = SCHEMES.filter((x) => x !== sc);
        renderSchemes();
        saveSoon();
    }
});
$('hhSchemes').addEventListener('change', (e) => {
    const t = e.target;
    const sc = scOf(t);
    if (!sc) return;
    if (t.dataset.sf) {
        sc[t.dataset.sf] = t.type === 'checkbox' ? (t.checked ? 1 : 0) : t.value.trim();
        if (t.dataset.sf === 'who') {
            sc.who = window.herdQuery.canon(sc.who);
            t.value = sc.who;
            const q = whoQ(sc);
            t.classList.toggle('is-bad', !!q.error);
            const note = t.closest('.hh-sch').querySelector('[data-whonote]');
            if (q.error) { note.innerHTML = whoNote(sc); return; }       // биту умову не пишемо
            if ((q.keys || []).some((k) => !LOADED.has(k))) loadAnimals().then(() => { note.innerHTML = whoNote(sc); renderDue(); });
            else note.innerHTML = whoNote(sc);
        }
        if (t.dataset.sf === 'off') t.closest('.hh-sch').classList.toggle('is-off', !!sc.off);
        saveSoon();
        return;
    }
    const tr = t.closest('[data-st]');
    if (!tr || !t.dataset.f) return;
    const st = sc.steps.find((x) => x.id === tr.dataset.st);
    const f = t.dataset.f;
    if (f === 'from' || f === 'to') {
        const n = parseInt(t.value, 10);
        if (!Number.isFinite(n)) { t.classList.add('is-bad'); return; }
        t.classList.remove('is-bad');
        st[f] = n;
    } else st[f] = t.value.trim();
    if (f === 'base') {
        if (st.base === 'step' && !st.prev) st.prev = (sc.steps[sc.steps.indexOf(st) - 1] || {}).id || '';
        renderSchemes();
    }
    if (f === 'name') renderSchemes();
    saveSoon();
});
$('hhSchemes').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches('input.hh-in')) { e.preventDefault(); e.target.blur(); }
});

/* ---------- дані ---------- */
let LOADED = new Set();
async function loadAnimals() {
    const keys = needKeys().filter((k) => PARAMS.some((p) => p.key === k));
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(','))).catch(() => null);
    if (!r || !r.ok) { toast('Стадо не прочиталось — оновіть сторінку', 'error'); return; }
    ANIMALS = r.items || [];
    LOADED = new Set(needKeys());
}
async function loadDone() {
    const r = await V.load();
    if (!r) return false;
    EVENT = r.event || null;
    return r;
}
async function boot() {
    $('hhDate').value = iso(today());
    const [ev, v] = await Promise.all([apiGet('/api/herd/events?lite=1').catch(() => null), loadDone()]);
    if (!ev || !ev.ok || !v) { $('hhSum').textContent = 'Не вдалося завантажити'; return; }
    PARAMS = ev.params || [];
    V.use({ params: () => PARAMS });
    window.HERD_CONSTS = ev.consts || [];
    SCHEMES = (v.schemes || []).map((s) => Object.assign({ steps: [] }, s));
    V.setSchemes(SCHEMES);
    await loadAnimals();
    renderSchemes();
    renderDue();
}
boot();
})();
