/* ВАКЦИНАЦІЯ ЗА СХЕМАМИ — ОДИН РАХУНОК ДЛЯ СТОРІНКИ «ЗДОРОВ’Я» І ДЛЯ СПИСКІВ (Роман 2026-10-01: «прописувати схему
   вакцинації й впроваджувати в списки»).
   📌 У мові списків — віртуальний параметр `vacc` («Вакцинація зараз»): кроки схем, які тварині зараз у своєму вікні й
      ще не проведені. `FILTER(vacc=[Хіпра 1])` — кому зараз «Хіпра 1»; `BODY(… vacc)` — колонка «крок (препарат · доза)».
   📌 Проведено — подія «Вакцинація»: зі сторінки «Здоров’я» вона несе крок (__vstep); внесена деінде (груповий ввід,
      картка) зараховується кроку, якщо препарат той самий і дата — у вікні кроку ± 7 днів.
   📌 Дані — /api/herd/vacc (схеми, подія, проведені); на старті — з памʼяті браузера, потім свіжі, і подія
      «herdvacc:ready» — сторінка перераховує списки. */
'use strict';
(function () {
const BASE_KEY = { age: 'birth_date', calving: 'last_calving', due: 'expected_calving', dryoff: 'last_dryoff' };
const LATE_MAX = 30, SOON_MAX = 14, NEAR = 7;
const MEM = 'herd:vacc';
let SCHEMES = [], EVENT = null, BY_STEP = new Map(), BY_DRUG = new Map();
let paramsOf = () => [];
const MEMO = new Map();                          // id тварини → {t, v}
const QMEMO = new Map();                         // умова «кого» → розбір

const parseD = (s) => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const sk = (sc, st) => `${sc.id}:${st.id}`;
const norm = (s) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');

function setData(d) {
    SCHEMES = (d && d.schemes) || [];
    EVENT = (d && d.event) || null;
    setDone((d && d.done) || []);
}
function setSchemes(list) { SCHEMES = list || []; QMEMO.clear(); MEMO.clear(); }
function setDone(done) {
    BY_STEP = new Map(); BY_DRUG = new Map();
    done.forEach((x) => {
        if (x.s) {                               // останнє проведення кроку в тварини
            const k = x.a + '|' + x.s;
            if (!BY_STEP.has(k) || BY_STEP.get(k) < x.d) BY_STEP.set(k, x.d);
        }
        if (x.g) {
            const k = x.a + '|' + norm(x.g);
            if (!BY_DRUG.has(k)) BY_DRUG.set(k, []);
            BY_DRUG.get(k).push(x.d);
        }
    });
    MEMO.clear();
}

function whoQ(sc) {
    const w = String(sc.who || '').trim();
    if (!w) return { filters: [], keys: [] };
    const key = w + '\u0001' + paramsOf().length;
    if (!QMEMO.has(key)) {
        const q = window.herdQuery.parse(`FILTER(${w})`, paramsOf());
        // «кого» через саму вакцинацію — коло, не рахуємо
        QMEMO.set(key, q.error ? q : (q.keys.includes('vacc') ? { error: 'умова «Кого» не може містити vacc' } : q));
    }
    return QMEMO.get(key);
}
function deps() {
    const ks = new Set(Object.values(BASE_KEY));
    SCHEMES.forEach((sc) => { const q = whoQ(sc); (q.keys || []).forEach((k) => ks.add(k)); });
    return [...ks];
}
function baseOf(a, sc, st) {
    if (st.base === 'step') {
        const prev = sc.steps.find((x) => x.id === st.prev);
        const d = prev && doneOn(a, sc, prev);
        return d ? parseD(d) : null;
    }
    return parseD((a.p || {})[BASE_KEY[st.base]] || (st.base === 'age' ? a.birth_date : ''));
}
/* вікно кроку для тварини: [w1, w2] або null */
function windowOf(a, sc, st) {
    const b = baseOf(a, sc, st);
    if (!b) return null;
    return st.base === 'due' ? { b, w1: addD(b, -st.to), w2: addD(b, -st.from) } : { b, w1: addD(b, st.from), w2: addD(b, st.to) };
}
/* дата, коли крок проведено (останнє проведення), або '' */
function doneOn(a, sc, st) {
    const tagged = BY_STEP.get(a.id + '|' + sk(sc, st)) || '';
    if (tagged) return tagged;
    if (!st.drug || st.base === 'step') return '';
    const ds = BY_DRUG.get(a.id + '|' + norm(st.drug));
    if (!ds) return '';
    const w = windowOf(a, sc, st);
    if (!w) return '';
    const lo = addD(w.w1, -NEAR), hi = addD(w.w2, NEAR);
    return ds.filter((d) => { const x = parseD(d); return x && x >= lo && x <= hi; }).sort().pop() || '';
}
/* стан кроку: null — не стосується; {st: now|late|soon, x, w1, w2, n} */
function stateOf(a, sc, st, t0) {
    const w = windowOf(a, sc, st);
    if (!w) return null;
    const done = doneOn(a, sc, st);
    if (done) {
        const dd = parseD(done);
        // за віком — раз на життя; від події — у цьому вікні (ця лактація, цей запуск, ця тільність)
        if (st.base === 'age' || (dd && dd >= addD(w.w1, -LATE_MAX))) return null;
    }
    const due = st.base === 'due';
    const x = due ? diff(w.b, t0) : diff(t0, w.b);
    if (t0 < w.w1) { const n = diff(w.w1, t0); return n <= SOON_MAX ? { st: 'soon', x, w1: w.w1, w2: w.w2, n } : null; }
    if (t0 > w.w2) { const n = diff(t0, w.w2); return n <= LATE_MAX ? { st: 'late', x, w1: w.w1, w2: w.w2, n } : null; }
    return { st: 'now', x, w1: w.w1, w2: w.w2, n: 0 };
}
/* кроки, які тварині зараз (для vacc): [{sc, st}] */
function nowSteps(a) {
    const t0 = today();
    const m = MEMO.get(a.id);
    if (m && m.t === +t0 && m.p === a.p) return m.v;
    const out = [];
    SCHEMES.forEach((sc) => {
        if (sc.off) return;
        const q = whoQ(sc);
        if (q.error || !window.herdQuery.passes(a, q.filters)) return;
        sc.steps.forEach((st) => { const s = stateOf(a, sc, st, t0); if (s && s.st === 'now') out.push({ sc, st }); });
    });
    MEMO.set(a.id, { t: +t0, p: a.p, v: out });
    return out;
}

window.herdQuery.virtual('vacc', {
    param: { key: 'vacc', label: 'Вакцинація зараз', short: 'vacc', dtype: 'text', virtual: true,
        get choices() {
            const seen = new Set();
            return SCHEMES.filter((sc) => !sc.off).flatMap((sc) => sc.steps.map((st) => st.name))
                .filter((n) => !seen.has(n) && seen.add(n)).map((n) => ({ value: n, label: n }));
        } },
    deps,
    val: (a) => nowSteps(a).map((x) => x.st.name),
    lab: (a) => nowSteps(a).map((x) => x.st.name + ([x.st.drug, x.st.dose].filter(Boolean).length
        ? ` (${[x.st.drug, x.st.dose].filter(Boolean).join(' · ')})` : '')).join('; '),
});

let LOADING = null;
function load() {
    if (!LOADING) {
        LOADING = (async () => {
            const r = await apiGet('/api/herd/vacc').catch(() => null);
            if (!r || !r.ok) return false;
            setData(r);
            try { localStorage.setItem(MEM, JSON.stringify({ schemes: r.schemes, event: r.event, done: r.done })); } catch (e) { /* ignore */ }
            document.dispatchEvent(new CustomEvent('herdvacc:ready'));
            return r;
        })().finally(() => { LOADING = null; });
    }
    return LOADING;
}
try { const m = JSON.parse(localStorage.getItem(MEM) || 'null'); if (m) setData(m); } catch (e) { /* ignore */ }

window.herdVacc = {
    use(cfg) { if (cfg && cfg.params) { paramsOf = cfg.params; QMEMO.clear(); MEMO.clear(); } },
    load, setData, setSchemes, setDone, whoQ, deps, stateOf, windowOf, doneOn, nowSteps,
    schemes: () => SCHEMES, event: () => EVENT, sk, BASE_KEY, LATE_MAX, SOON_MAX,
};
}());
