/* ═══ ПАНЕЛІ «ОГЛЯДУ» І ПОСИЛАННЯ «[Назва]» — СПІЛЬНИЙ МОДУЛЬ ═══
   (аналіз складених панелей 2026-09-26, пакет 3)
   Тут живе все, що РАХУЄ й ПОКАЗУЄ панелі та розгортає посилання на
   збережений звіт: розбір формули на показники («;», «|», «/»), точний
   пошук звіту за назвою, підрахунок одного показника і формат його показу.
   Функції чисті — світ (списки, панелі, параметри стада) дає сторінка:

       window.herdPanels.use({ lists: () => …, tiles: () => …, params: () => … });

   Навіщо окремим файлом:
   • одне місце правди: сторінку стада, а згодом і Календар (#302), рахує
     ТОЙ САМИЙ розбір — два розбори одного мовчки розходяться (урок qRows,
     2.39.82);
   • node-тести (tests/panels_test.mjs) вантажать модуль як є, а не
     вирізають функції зі сторінки. */
'use strict';

(function () {
    const W = { lists: () => [], tiles: () => [], params: () => [] };
    function use(o) { Object.assign(W, o || {}); }
    // «=» на початку формули (у сховищі він є, у рядку формули — ні)
    const noEq = (t) => String(t === null || t === undefined ? '' : t).replace(/^\s*=\s*/, '');

    /* ─── ДОБІР І АГРЕГАЦІЯ ─── */

    /* Тварини формули: основний добір ПЛЮС додаткові блоки FILTER2(…)
       (Роман 2026-09-24: «фільтр 2, який додає до основного списку»). Свої умови
       ЗАМІНЮЮТЬ умову основного на той самий параметр — так само, як «додатковий
       список» у Календарі; хто вже вище — не повторюється.
       📌 Рахунок живе ТУТ, в одному місці: таблиця, рейка списків і плитки
       «Огляду» мусять давати однакове число. `mark` — куди таблиця записує,
       кого додав який блок. */
    function qRows(q, items, mark) {
        const out = items.filter((a) => window.herdQuery.passes(a, q.filters));
        if (!(q.extra || []).length) return out;
        const seen = new Set(out.map((a) => a.id));
        q.extra.forEach((e, i) => {
            if (!e.filters || !e.filters.length) return;
            const flt = window.herdQuery.extraFilters(q.filters, e.filters);
            const name = e.name || `Додаткові ${i + 2}`;
            items.forEach((a) => {
                if (seen.has(a.id) || !window.herdQuery.passes(a, flt)) return;
                seen.add(a.id);
                if (mark) mark.set(a.id, name);
                out.push(a);
            });
        });
        return out;
    }

    /* одне число агрегації: cnt · avg · sum · min · max */
    function aggValue(a, rows) {
        if (a.fn === 'cnt') {
            return a.key
                ? rows.filter((x) => {
                    const v = (x.p || {})[a.key];
                    return !(v === null || v === undefined || v === '');
                }).length
                : rows.length;
        }
        const nums = rows.map((x) => {
            const raw = (x.p || {})[a.key];
            const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
            return Number.isFinite(n) ? n : null;
        }).filter((n) => n !== null);
        if (!nums.length) return null;
        if (a.fn === 'sum') return nums.reduce((t, n) => t + n, 0);
        if (a.fn === 'min') return Math.min(...nums);
        if (a.fn === 'max') return Math.max(...nums);
        return nums.reduce((t, n) => t + n, 0) / nums.length;
    }

    /* ─── БУДОВА ФОРМУЛИ: «/», «;», «|» ─── */

    /* «A / B» — частка (Роман 2026-09-19): дві формули через «/» поза дужками,
       напр. FILTER(lact>0 rc>=5) / FILTER(lact>0) — частка тільних серед фуражних.
       Повертає [чисельник, знаменник] або null. «/» у назвах (milk/lkd) — у дужках. */
    function splitRatio(text) {
        const src = String(text || '').replace(/^\s*=/, '');
        let depth = 0, sq = 0;
        for (let i = 0; i < src.length; i++) {
            const c = src[i];
            // «/» у НАЗВІ теж не ділить: звіт може зватись «Молоко/гол»; а круглі
            // дужки в назві («1) Дійні») — не дужки дії
            if (c === '[') sq += 1;
            else if (c === ']') sq = Math.max(0, sq - 1);
            else if (sq) continue;
            else if (c === '(') depth += 1;
            else if (c === ')') depth -= 1;
            else if (c === '/' && depth === 0) {
                const a = src.slice(0, i).trim(), b = src.slice(i + 1).trim();
                return a && b ? ['=' + a, '=' + b] : null;
            }
        }
        return null;
    }

    /* ОСНОВНІ та ДРУГОРЯДНІ показники панелі (Роман 2026-09-26: «можна задати,
       що цей показник основний, а другорядний буде під ними й меншим шрифтом»).
       Пишуться через «|»: `[Фуражні] ; [Дійні] | [avg DIM]`. Риска шукається
       лише ПОЗА дужками, тож «|» у значеннях фільтра її не зачіпає. */
    function splitTiers(text) {
        const src = String(text || '').replace(/^\s*=/, '');
        let depth = 0, sq = 0;
        for (let i = 0; i < src.length; i++) {
            const c = src[i];
            if (c === '[') sq += 1;
            else if (c === ']') sq = Math.max(0, sq - 1);
            else if (sq) continue;
            else if (c === '(') depth += 1;
            else if (c === ')') depth -= 1;
            else if (c === '|' && !depth) {
                return { main: src.slice(0, i).trim(), sub: src.slice(i + 1).trim() };
            }
        }
        return { main: src.trim(), sub: '' };
    }

    /* КІЛЬКА ПОКАЗНИКІВ В ОДНІЙ ПАНЕЛІ (Роман 2026-09-26: «тільні плюс
       сухостій 94 — і це 44,3 %… комбінування двох, може й трьох показників в
       одну панель»). Показники пишуться через «;»; кожен — звичайна формула
       (число) або частка «A / B» (відсоток). На плитці вони стоять ПОРУЧ, кожен
       зі своїм числом; посилання «[Назва]» підписує себе назвою того звіту. */
    function splitParts(text) {
        const src = String(text || '').replace(/^\s*=/, '');
        const out = [];
        let depth = 0, sq = 0, last = 0;
        for (let i = 0; i < src.length; i++) {
            const c = src[i];
            if (c === '[') sq += 1;
            else if (c === ']') sq = Math.max(0, sq - 1);
            else if (sq) continue;
            else if (c === '(') depth += 1;
            else if (c === ')') depth -= 1;
            else if (c === ';' && !depth) { out.push(src.slice(last, i).trim()); last = i + 1; }
        }
        out.push(src.slice(last).trim());
        const parts = out.filter(Boolean).map((x) => '=' + x);
        return parts.length ? parts : ['=' + src.trim()];
    }

    /* усі показники обох рівнів одним переліком */
    function fxAllParts(text) {
        const tr = splitTiers(text);
        return [...(tr.main ? splitParts(tr.main) : []),
            ...(tr.sub ? splitParts(tr.sub) : [])];
    }

    /* ═══ ПОСИЛАННЯ НА ВЖЕ ЗБЕРЕЖЕНИЙ ЗВІТ ═══
       Роман 2026-09-26: «я введу формулу — тільних тварин, кількість — і розділю
       її на вже наявний звіт, наприклад на корів фуражних».
       Частина формули, яка складається САМЕ з «[Назва]», — це збережений список
       (вкладка «Списки») або панель «Огляду»; застосунок підставляє його формулу.
       📌 Чому лише ціла частина, а не будь-де: у квадратних дужках пишеться й
       назва ПАРАМЕТРА («[Днів з осіменіння]>=35»), тож розрізняємо за місцем —
       параметр завжди стоїть усередині FILTER/BODY/VIEW і має поруч умову.
       ⚠️ ПОСИЛАННЯ ШУКАЄМО ЛИШЕ ТОЧНОЮ НАЗВОЮ (аналіз 2026-09-26, Н1). Доти
       звіт знаходився й за початком чи шматком назви — і щойно «Сухостій»
       перейменовували чи прибирали, «[Сухостій]» у складених панелях мовчки
       чіплявся за «Тілні + сухостій»: підпис той самий, число чуже, жодного
       знаку. Тепер немає точного збігу — чесна помилка з підказкою «мабуть, …».
       Набране скорочення рядок формули сам доповнює до повної назви на Enter
       (refCanon), тож набирати коротко й далі можна. */
    const refKey = (s) => String(s === null || s === undefined ? '' : s).trim()
        .replace(/\s+/g, ' ').toLowerCase();
    /* усі звіти, на які можна послатись: списки й панелі — ОДИН простір назв */
    function refAll() {
        return [...(W.lists() || []).map((L) => ({ kind: 'list', name: String(L.name || ''), formula: L.formula, obj: L })),
            // `obj` — сам звіт: з панелі беремо ФОРМАТ ЧИСЛА, коли на неї посилаються
            ...(W.tiles() || []).map((T) => ({ kind: 'tile', name: String(T.name || ''), formula: T.formula, obj: T }))];
    }
    function refLookup(name) {
        const n = refKey(name);
        if (!n) return null;
        const eq = refAll().filter((x) => refKey(x.name) === n);
        if (eq.length === 1) return eq[0];
        if (eq.length > 1) {
            // однакова назва в списку й панелі (з давніх часів) — не вгадуємо
            const what = [...new Set(eq.map((x) => (x.kind === 'list' ? 'список' : 'панель')))].join(' і ');
            return { many: `«${eq[0].name}» — так звуться ${eq.length} звіти (${what}); перейменуйте зайвий` };
        }
        return null;
    }
    /* лише для ПІДКАЗКИ й доповнення скорочення: однозначний збіг ЗА ПОЧАТКОМ
       назви. За шматком — ні: для прибраної «Сухостій» він радив би «Тілні +
       сухостій», тобто зовсім інший показник */
    function refGuess(name) {
        const n = refKey(name);
        if (!n) return '';
        const st = refAll().filter((x) => refKey(x.name).startsWith(n));
        return st.length === 1 ? st[0].name : '';
    }
    /* «[Назва]» → «Назва»; не посилання — порожній рядок */
    const refName = (text) => {
        const m = noEq(String(text || '')).trim().match(/^\[([^\[\]]+)\]$/);
        return m ? m[1].trim() : '';
    };
    /* набране скорочення «[Дійн]» → «[Дійні]», коли збіг однозначний — і лише
       ЗА ПОЧАТКОМ назви. Лише поза дужками дії: «[Назва]» усередині FILTER — це
       параметр, не звіт. ⚠️ Посилання, що вже стояло в збереженій формулі
       (`keep`), не чіпаємо: якщо воно зламалось (звіт перейменували чи
       прибрали), доповнення мовчки перенацілило б його на інший звіт — рівно те,
       від чого рятує точний пошук. */
    function refCanon(text, keep) {
        const kept = String(keep || '');
        const src = String(text || '');
        let out = '', depth = 0, changed = false;
        for (let i = 0; i < src.length; i++) {
            const c = src[i];
            if (c === '(') depth += 1;
            else if (c === ')') depth = Math.max(0, depth - 1);
            else if (c === '[' && !depth) {
                const j = src.indexOf(']', i);
                if (j > i) {
                    const inner = src.slice(i + 1, j);
                    const g = (refLookup(inner) || kept.includes(`[${inner}]`)) ? '' : refGuess(inner);
                    out += g ? `[${g}]` : src.slice(i, j + 1);
                    if (g) changed = true;
                    i = j;
                    continue;
                }
            }
            out += c;
        }
        return changed ? out : src;
    }
    /* «[Назва]» → формула того звіту. Посилання в посиланні теж розгортаємо, але
       коло («А через Б знову на А») називаємо вголос, а не крутимо вічно.
       `kind` — чий текст зрештою рахуємо: у СПИСКУ (перелік тварин) число — це
       кількість, навіть якщо в його VIEW стоїть avg (аналіз 2026-09-26, Н10). */
    function refExpand(text, seen) {
        let t = noEq(String(text || '')).trim();
        const path = seen || [];
        let kind = '';
        for (let i = 0; i < 6; i++) {
            const nm = refName(t);
            if (!nm) return { text: t, kind };
            const key = refKey(nm);
            if (path.includes(key)) return { error: `звіт «${nm}» посилається сам на себе` };
            const r = refLookup(nm);
            if (r && r.many) return { error: r.many };
            if (!r) {
                const g = refGuess(nm);
                return { error: `немає звіту «${nm}»` + (g ? ` — мабуть, «${g}»?` : '') };
            }
            const f = noEq(String(r.formula || '')).trim();
            // порожня панель рахувала б УСЕ стадо як звичайний показник (Н8)
            if (!f) return { error: `панель «${r.name}» ще порожня` };
            // складена в складеній давала оманливу «не зрозумілу умову» (Н7)
            if (fxAllParts(f).length > 1) return { error: `«${r.name}» — складена панель: послатись можна лише на її показники` };
            path.push(key);
            kind = r.kind;
            t = f;
        }
        return { error: 'забагато посилань одне на одне' };
    }
    /* частини формули з розгорнутими посиланнями: [чисельник] або [чисельник, знаменник] */
    function fxSides(text) {
        // ⚠️ СПЕРШУ розгортаємо посилання і ЛИШЕ ТОДІ ділимо на «A / B»: звіт, на
        // який посилаємось, сам може бути часткою («% тільних»), а в рядку
        // «[% Тільних]» жодного «/» не видно — воно всередині дужок
        const top = refExpand(text);
        if (top.error) return { error: top.error };
        const rp = splitRatio(top.text);
        const out = [], cnt = [];
        for (const part of (rp || [top.text])) {
            const r = refExpand(part);
            if (r.error) return { error: r.error };
            if (splitRatio(r.text)) return { error: 'частку не можна ділити на частку' };
            out.push(r.text);
            // бік, що веде на СПИСОК, рахується кількістю тварин
            cnt.push(r.kind === 'list' || (!rp && top.kind === 'list'));
        }
        return { sides: out, ratio: !!rp, cnt };
    }
    /* УСЯ формула — без помилок? Enter-автозбереження доти дивилось лише на
       ПЕРШИЙ показник (решта перевірялась пізніше, коли стадо дочитається), тож
       биту другу частину можна було зберегти (аналіз 2026-09-26) */
    function fxCheck(text) {
        for (const part of fxAllParts(text)) {
            const fx = fxSides(part);
            if (fx.error) return fx.error;
            for (const s of fx.sides) {
                const q = window.herdQuery.parse(s, W.params());
                if (q.error) return q.error;
            }
        }
        return '';
    }
    /* чиїх тварин показує таблиця: ПЕРШОГО показника (частка — її чисельника).
       Той самий вибір і для «Групового вводу» — доти туди йшов увесь рядок, і
       зі складеної панелі він не розумів нічого (Н13) */
    const tableFx = (text) => fxSides(fxAllParts(text)[0] || '');
    /* чи є в рядку посилання на збережений звіт (щоб не «причісувати» його
       в розгорнуту формулу — інакше посилання мовчки зникло б із рядка) */
    function fxHasRef(text) {
        return fxAllParts(text).some((part) =>
            (splitRatio(part) || [part]).some((p) => !!refName(p)));
    }
    /* хто посилається на звіт — тим самим точним порівнянням, яким рахуємо */
    function refDependents(name, selfObj) {
        const k = refKey(name);
        const out = [];
        const scan = (x) => {
            if (!x || x === selfObj) return;
            const hit = fxAllParts(x.formula || '').some((p) => (splitRatio(p) || [p])
                .some((s) => refKey(refName(s)) === k));
            if (hit) out.push(x);
        };
        (W.tiles() || []).forEach(scan);
        (W.lists() || []).forEach(scan);
        return out;
    }
    /* чи зайнята назва іншим звітом — у СПІЛЬНОМУ просторі списків і панелей */
    function refTaken(name, kind, id) {
        const k = refKey(name);
        const hit = refAll().find((x) => refKey(x.name) === k
            && !(x.kind === kind && String(x.obj.id) === String(id)));
        return hit || null;
    }
    /* id, якого ще немає (доти «'w' + кількість + назва» повторювались) */
    function newId(prefix, coll) {
        const have = new Set((coll || []).map((x) => String(x.id)));
        let id = '';
        do {
            id = prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        } while (have.has(id));
        return id;
    }

    /* ─── ЧИСЛО ПОКАЗНИКА ─── */

    /* Число панелі: кількість тих, хто пройшов FILTER, або — якщо у формулі є
       VIEW(avg|sum|min|max <параметр>) — середнє/сума/мін/макс серед них
       (Роман 2026-09-19: «якісні показники» — середній надій, середні дні лактації…).
       `cnt` — рахувати саме КІЛЬКІСТЬ: так рахується посилання на СПИСОК (це
       перелік тварин), навіть якщо в його VIEW стоїть avg — доти «[Контрольне
       доїння]» у панелі давало 164,5 (середні дні), а в рейці той самий список — 42 */
    function metricOf(q, items, cnt) {
        const rows = qRows(q, items);
        const ag = cnt ? null : (q.aggs || []).find((x) => x.fn !== 'cnt' || x.key);
        if (!ag) return { v: rows.length, auto: 0, cnt: true };
        const v = aggValue(ag, rows);
        return { v, auto: ag.fn === 'avg' || (v !== null && !Number.isInteger(v)) ? 1 : 0, cnt: false };
    }
    /* частка двох формул: кількість / кількість — у відсотках, інакше — просте ділення */
    function ratioOf(qa, qb, items, cnt) {
        const a = metricOf(qa, items, cnt && cnt[0]), b = metricOf(qb, items, cnt && cnt[1]);
        const pct = a.cnt && b.cnt;
        const v = (a.v === null || !b.v) ? null : (a.v / b.v) * (pct ? 100 : 1);
        return { v, auto: pct ? 1 : 2, pct, a: a.v, b: b.v };
    }
    /* ОДИН ПОКАЗНИК — ОДНЕ ЧИСЛО АБО ОДНА ПОМИЛКА (аналіз 2026-09-26, Н6).
       Доти помилка будь-якої частини гасила ВСЮ складену панель: плитка
       «Корови всього:» лишалась із самою назвою, без «—» і без пояснення, а в
       роботі біля битої частини не було ✕. Тепер бита частина — це `{err}` на
       своєму місці, решта показників стоять як стояли. */
    function partCount(part, tier, items) {
        const lab = refName(part);              // посилання підписує себе назвою
        const fx = fxSides(part);               // «[Назва]» → формула того звіту
        if (fx.error) return { err: fx.error, label: lab, tier };
        const qs = fx.sides.map((f) => window.herdQuery.parse(f, W.params()));
        const bad = qs.find((q) => q.error);
        if (bad) return { err: bad.error, label: lab, tier };
        if (fx.ratio) return Object.assign(ratioOf(qs[0], qs[1], items, fx.cnt), { label: lab, tier });
        const m = metricOf(qs[0], items, fx.cnt[0]);
        return { v: m.v, auto: m.auto, label: lab, tier };
    }
    /* значення панелі на заданому переліку тварин. Один показник — як доти (або
       рядок помилки); кілька — у `parts`, де бита частина стоїть своїм `{err}`. */
    function ovCountOn(formula, items) {
        const tiers = splitTiers(formula);
        const vals = [];
        for (const [src, tier] of [[tiers.main, ''], [tiers.sub, 'sub']]) {
            if (!src) continue;
            for (const part of splitParts(src)) vals.push(partCount(part, tier, items));
        }
        if (!vals.length) return null;
        if (vals.length === 1) return vals[0].err ? vals[0].err : vals[0];
        return Object.assign({}, vals.find((x) => !x.err) || {}, { parts: vals });
    }

    /* ─── ЯК ПОКАЗАТИ ─── */

    /* ЧИЇМ ФОРМАТОМ ПОКАЗУВАТИ ПОКАЗНИК — ОДНЕ ПРАВИЛО (аналіз 2026-09-26, Н9).
       Доти те саме число виглядало по-різному на плитці, у рейці й під рядком
       формули (три копії логіки), а частка першою в панелі показувала «60
       (66,7 %)», другою — «66,7 %». Тепер:
       • показник-ПОСИЛАННЯ — як налаштована ТА панель (Роман 2026-09-26:
         «параметри відображення числа не передаються…»);
       • одинокий показник — власне налаштування панелі головніше за джерело
         (доти 2.40.48 перебивала його форматом джерела);
       • свій, набраний формулою показник — за налаштуваннями цієї панелі.
       Формат читається під час показу, а не береться з памʼяті браузера — інакше
       після зміни «знаків» перший кадр показував би старий. */
    function partFmt(x, t, composite) {
        const f = { dec: '', sep: true, show: '' };
        const take = (o) => {
            if (!o) return;
            if (o.dec !== undefined && o.dec !== null && o.dec !== '') f.dec = String(o.dec);
            if (o.sep === false) f.sep = false;
            if (o.show) f.show = o.show;
        };
        if (x.label) {
            const r = refLookup(x.label);
            if (r && r.kind === 'tile') take(r.obj);
            if (!composite) take(t);
        } else take(t);
        return f;
    }
    /* КОЛІР ШРИФТУ ПОКАЗНИКА — ТИМ САМИМ ПРАВИЛОМ, що й формат числа (Роман
       2026-09-27: «колір шрифта не успадковується при комбінуванні
       показників»): показник-посилання у складеній — кольором ТІЄЇ панелі;
       одинока панель — власний колір головніший, без нього — колір джерела;
       свій, набраний формулою показник — '' (тоді діє колір самої плитки).
       Лише справжній #rrggbb — рядок іде в style=. */
    function partInk(x, t, composite) {
        const hex = (c) => (/^#[0-9a-f]{6}$/i.test(String(c || '')) ? String(c) : '');
        if (!x || !x.label) return '';
        const r = refLookup(x.label);
        const src = r && r.kind === 'tile' ? hex(r.obj.color) : '';
        return composite ? src : (hex(t && t.color) || src);
    }
    /* показник → що написати: { v — число, sub — друге число дрібним, lab, tier, err, ink } */
    function partView(x, t, composite) {
        if (typeof x === 'number') x = { v: x, auto: 0 };
        if (!x || typeof x !== 'object' || x.err) {
            return { v: '—', sub: '', lab: (x && x.label) || '', tier: (x && x.tier) || '',
                err: (x && x.err) || (typeof x === 'string' ? x : '') };
        }
        const f = partFmt(x, t, composite);
        const ink = partInk(x, t, composite);
        const dec = f.dec !== '' ? Number(f.dec) : null;
        const num = (v, auto, pct) => ((v === null || v === undefined) ? '—'
            : Number(v).toLocaleString('uk-UA', { minimumFractionDigits: dec === null ? auto : dec,
                maximumFractionDigits: dec === null ? auto : dec, useGrouping: f.sep !== false })
                + (pct ? ' %' : ''));
        const base = { lab: x.label || '', tier: x.tier || '', err: '', ink };
        if (x.a !== undefined) {                // частка «A / B»: є і кількість, і частка
            const share = num(x.v, x.auto, x.pct);
            const md = f.show || 'pct';
            if (md === 'pct') return Object.assign(base, { v: share, sub: '' });
            // кількість голів — завжди ціла («55,0 голів» не буває); знаки після
            // коми стосуються самої частки
            const cnt = (x.a === null || x.a === undefined) ? '—'
                : Number(x.a).toLocaleString('uk-UA', { maximumFractionDigits: x.pct ? 0 : 1,
                    useGrouping: f.sep !== false });
            return Object.assign(base, { v: cnt, sub: md === 'both' ? share : '' });
        }
        return Object.assign(base, { v: num(x.v, x.auto, x.pct), sub: '' });
    }
    /* Показники панелі ОКРЕМИМИ блоками — для плитки «Огляду»: Роман
       2026-09-26 (скрін плитки «212 / Дійн 187 / Корови»): «панель повинна
       комбінувати показники — фуражні 212, дійні 187 — вони повинні бути ПОРУЧ».
       Кожен блок: число + свій підпис (назва показника, якщо це посилання). */
    function ovBlocks(n, t) {
        if (n === null || n === undefined) return null;
        if (typeof n === 'string') return [partView({ err: n }, t, false)];
        const parts = (n && n.parts) || [n];
        return parts.map((x) => partView(x, t, parts.length > 1));
    }
    /* те саме одним рядком — для бічного переліку й простої плитки: головне
       число і дрібний рядок під ним. У складеній підпис ПЕРШОГО числа стоїть
       першим у дрібному рядку — доти перше число в рейці було без підпису (Н22) */
    function ovParts(n, t) {
        const b = ovBlocks(n, t);
        if (!b) return { main: '', sub: '' };
        if (b.length === 1) return { main: b[0].v, sub: b[0].sub };
        const first = b[0];
        return { main: first.v,
            sub: [first.lab + (first.sub ? ' ' + first.sub : ''),
                ...b.slice(1).map((x) => (x.lab ? x.lab + ' ' : '') + x.v + (x.sub ? ' (' + x.sub + ')' : ''))]
                .filter(Boolean).join(' · ') };
    }

    /* ─── СКЛАДЕНА ПАНЕЛЬ: ЗІБРАНА КЛІКАМИ З ІНШИХ ─── */

    /* назви показників, з яких зібрана панель (у порядку, з рівнями);
       null — панель набрана формулою, а не зібрана з посилань */
    function ovmPicksOf(t) {
        const tr = splitTiers(t ? t.formula : '');
        const out = [];
        for (const [src, tier] of [[tr.main, ''], [tr.sub, 'sub']]) {
            if (!src) continue;
            for (const part of splitParts(src)) {
                const nm = refName(part);
                if (!nm) return null;              // не з самих посилань — не наша
                out.push({ name: nm, tier });
            }
        }
        return out;
    }
    const ovmFormulaOf = (picks) => {
        const m = picks.filter((x) => x.tier !== 'sub').map((x) => `[${x.name}]`);
        const sub = picks.filter((x) => x.tier === 'sub').map((x) => `[${x.name}]`);
        if (!m.length && !sub.length) return '';
        return '=' + m.join(' ; ') + (sub.length ? ' | ' + sub.join(' ; ') : '');
    };
    /* панель, зібрану кліками з кількох показників, Enter у «Роботі зі стадом»
       НЕ перезаписує (одинока чи порожня — звичайна, їх правлять формулою) */
    function ovGuarded(t) {
        const picks = ovmPicksOf(t);
        return !!(picks && (picks.length > 1 || (picks.length === 1 && picks[0].tier === 'sub')));
    }
    /* СКЛАДЕНА ПАНЕЛЬ — зібрана з показників: самі посилання (зокрема й
       порожня, щойно заведена «+», і одинока «[X]») або кілька показників
       через «;» / «|». Решта — ПОКАЗНИКИ: панель із формулою добору чи часткою
       («[A] / [B]» — теж показник). Роман 2026-09-27: складених у бічних
       переліках немає, і схованими вони не бувають — «комбіновані панелі або
       є, або немає». */
    function ovIsComposite(t) {
        return !!(t && (ovmPicksOf(t) || fxAllParts(t.formula).length > 1));
    }
    /* чи стоїть панель на «Огляді»: показник — поки не схований оком,
       складена — завжди */
    const ovShown = (t) => !!t && (!t.hidden || ovIsComposite(t));
    /* чому цей показник НЕ покласти в панель, що в роботі ('' — можна) */
    function ovmWhyNot(t, self) {
        if (!t) return '';
        if (self && String(t.id) === String(self.id)) return 'Це сама панель, яку збираєте';
        if (!String(t.formula || '').trim()) return 'Панель ще порожня — нема що показувати';
        if (ovIsComposite(t)) return 'Складену панель у складену не вкласти — беріть її показники';
        return '';
    }
    /* СКЛАДОВІ — панелі, на які посилається ІНША панель (id рядками). «Показати
       всі» їх на «Огляд» не викладає: вони вже стоять усередині складених, а
       окремими плитками лише засмічують сторінку (аналіз 2026-09-26, Н17) */
    function ovComponentIds() {
        const tiles = W.tiles() || [];
        const byKey = new Map(tiles.map((t) => [refKey(t.name), t]));
        const out = new Set();
        tiles.forEach((t) => fxAllParts(t.formula || '').forEach((part) => {
            (splitRatio(part) || [part]).forEach((side) => {
                const hit = byKey.get(refKey(refName(side)));
                if (hit && hit !== t) out.add(String(hit.id));
            });
        }));
        return out;
    }

    /* РОЗДІЛ «ОГЛЯДУ» ЦІЛИМ БЛОКОМ (Роман 2026-09-27: «категорії хочу
       передвигати»): розділ стоїть там, де його ПЕРША панель, тож переносимо
       всі його панелі разом (і сховані). Решта розділів стають суцільними
       блоками в тому ж порядку; усередині розділу порядок не міняється.
       Повертає НОВИЙ масив; те саме робить сервер (дія «secmove»). */
    function ovSecMove(tiles, sec, target, after) {
        const key = (s) => String(s === null || s === undefined ? '' : s).trim();
        const order = [], groups = new Map();
        (tiles || []).forEach((t) => {
            const k = key(t.section);
            if (!groups.has(k)) { groups.set(k, []); order.push(k); }
            groups.get(k).push(t);
        });
        const s = key(sec), g = key(target);
        if (!groups.has(s) || !groups.has(g) || s === g) return (tiles || []).slice();
        order.splice(order.indexOf(s), 1);
        order.splice(order.indexOf(g) + (after ? 1 : 0), 0, s);
        return order.flatMap((k) => groups.get(k));
    }

    window.herdPanels = { use, qRows, aggValue, splitRatio, splitTiers, splitParts, fxAllParts,
        refKey, refAll, refLookup, refGuess, refName, refCanon, refExpand, fxSides, fxCheck,
        tableFx, fxHasRef, refDependents, refTaken, newId, metricOf, ratioOf, partCount,
        ovCountOn, partFmt, partInk, partView, ovBlocks, ovParts, ovmPicksOf, ovmFormulaOf, ovGuarded,
        ovmWhyNot, ovIsComposite, ovShown, ovComponentIds, ovSecMove };
}());
