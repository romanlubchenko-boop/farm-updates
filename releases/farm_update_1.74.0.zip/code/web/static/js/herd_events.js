/* Налаштування типів подій: коло відтворення + людські картки + майстер
   речень + самоперевірка. Старий конструктор ефектів живе в «Розширено». */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const $ = (id) => document.getElementById(id);
let EVENTS = [], PARAMS = [], CATS = {}, MODES = {};
let editing = null;
let WORK = [];          // робочий список ефектів відкритої картки

const ARG_MODES = new Set(['const', 'inc']);   // авто-режими зі звичайним полем значення

async function load() {
    const r = await apiGet('/api/herd/events');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    EVENTS = r.events || [];
    PARAMS = (r.params || []).filter((p) => !(p.formula || '').trim())   // обчислювані не міняємо
        .sort((a, b) => (a.label || '').localeCompare(b.label || '', 'uk'));
    fillParamDatalist();
    CATS = r.categories || {};
    MODES = r.modes || {};
    render();
    renderCycle();
}

function paramByKey(k) { return PARAMS.find((p) => p.key === k); }
function paramByLabel(lbl) {
    const s = (lbl || '').trim();
    return PARAMS.find((p) => (p.label || '') === s);
}
function codeLabel(paramKey, val) {
    const p = paramByKey(paramKey);
    const ch = (p && p.choices) || [];
    const c = ch.find((x) => String(x.value) === String(val));
    return c ? c.label : (val || '—');
}
function fillParamDatalist() {
    const dl = $('eeParamDL'); if (!dl) return;
    dl.innerHTML = PARAMS.map((p) =>
        `<option value="${escapeHtml(p.label)}"></option>`).join('');
}

/* ═══════════ КОЛО ВІДТВОРЕННЯ ═══════════ */
/* хто виконує кроки циклу — визначаємо за ефектами (не за назвами) */
function cycleRoles() {
    const roles = { set: {}, branch: null };
    EVENTS.filter((e) => e.is_active).forEach((e) => {
        (e.effects || []).forEach((f) => {
            if (f.param_key !== 'repro_code') return;
            if (f.mode === 'const' && ['2', '4', '6', '9'].includes(String(f.arg).trim())) {
                if (!roles.set[String(f.arg).trim()]) roles.set[String(f.arg).trim()] = e;
            } else if (f.mode === 'when') {
                const s = parseWhenSpec(f.arg);
                const vals = s.rules.map((r) => String(r.val));
                if (vals.includes('5') && vals.includes('3')) roles.branch = e;
            }
        });
    });
    return roles;
}

function renderCycle() {
    const svg = $('evCycle'); if (!svg) return;
    const R = cycleRoles();
    // вузли: код → позиція
    const N = {
        '0': { x: 70,  y: 55,  t: 'Телиця',     c: '0' },
        '4': { x: 250, y: 140, t: 'Осіменена',  c: '4' },
        '3': { x: 250, y: 265, t: 'Ялова',      c: '3' },
        '5': { x: 470, y: 140, t: 'Тільна',     c: '5' },
        '6': { x: 660, y: 140, t: 'Сухостій',   c: '6' },
        '2': { x: 660, y: 265, t: 'Новотільна', c: '2' },
    };
    const ev4 = R.set['4'], ev6 = R.set['6'], ev2 = R.set['2'], br = R.branch;
    // ребра: [з, до, подія, підпис-додаток, зсув підпису]
    // [з, до, подія, підпис-додаток, зсув підпису, зсув точок кріплення по x]
    const edges = [
        ['0', '4', ev4, '', [-14, -16], 0],
        ['4', '5', br, 'тільна', [0, -14], 0],
        ['4', '3', br, 'ялова', [78, 3], -26],
        ['3', '4', ev4, 'повтор', [-64, 3], 0],
        ['5', '6', ev6, '', [0, -14], 0],
        ['6', '2', ev2, '', [14, 3], 0],
        ['2', '4', ev4, 'через 60 дн', [0, 16], 26],
    ];
    const W = 118, H = 44;
    let defs = `<defs><marker id="cycArr" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#9fb4cf"/></marker>
        <marker id="cycArrBad" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#e5484d"/></marker></defs>`;
    const port = (n, side) => {   // точка на межі прямокутника
        const p = N[n];
        if (side === 'l') return [p.x - W / 2, p.y];
        if (side === 'r') return [p.x + W / 2, p.y];
        if (side === 't') return [p.x, p.y - H / 2];
        return [p.x, p.y + H / 2];
    };
    let g = '', labels = '';
    edges.forEach(([a, b, ev, extra, lo, dx]) => {
        const A = N[a], B = N[b];
        let p1, p2, path, mid;
        const shift = (pt) => [pt[0] + (dx || 0), pt[1]];
        if (a === '2' && b === '4') {          // довга дуга низом
            p1 = port(a, 'b'); p2 = shift(port(b, 'b'));
            path = `M${p1[0]},${p1[1]} C ${p1[0]},324 ${p2[0]},324 ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, 314];
        } else if (a === '3' && b === '4') {   // повтор: дужка ліворуч
            p1 = port(a, 'l'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} C ${p1[0] - 70},${p1[1]} ${p2[0] - 70},${p2[1]} ${p2[0]},${p2[1]}`;
            mid = [p1[0] - 56, (p1[1] + p2[1]) / 2];
        } else if (A.y === B.y) {
            p1 = port(a, 'r'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, p1[1]];
        } else if (A.x === B.x) {
            p1 = shift(port(a, 'b')); p2 = shift(port(b, 't'));
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [p1[0], (p1[1] + p2[1]) / 2];
        } else {                               // діагональ (телиця → осіменена)
            p1 = port(a, 'b'); p2 = port(b, 't');
            path = `M${p1[0]},${p1[1]} C ${p1[0]},${p1[1] + 40} ${p2[0]},${p2[1] - 40} ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2];
        }
        const ok = !!ev;
        g += `<path class="cyc-edge${ok ? '' : ' bad'}" d="${path}"
                marker-end="url(#${ok ? 'cycArr' : 'cycArrBad'})"></path>`;
        const name = ok ? ev.name : 'немає події!';
        const lbl = extra ? `${name} · ${extra}` : name;
        labels += `<text class="cyc-lbl${ok ? '' : ' bad'}" x="${mid[0] + lo[0]}" y="${mid[1] + lo[1]}"
                text-anchor="middle" ${ok ? `data-ev="${ev.id}"` : ''}>${escapeHtml(lbl)}</text>`;
    });
    let nodes = '';
    Object.values(N).forEach((n) => {
        nodes += `<g class="cyc-node ok">
            <rect x="${n.x - W / 2}" y="${n.y - H / 2}" width="${W}" height="${H}" rx="10"></rect>
            <text x="${n.x}" y="${n.y + 1}" text-anchor="middle">${escapeHtml(n.t)}</text>
            <text class="cyc-code" x="${n.x}" y="${n.y + 15}" text-anchor="middle">код ${n.c}</text>
        </g>`;
    });
    svg.innerHTML = defs + g + nodes + labels;
    svg.querySelectorAll('.cyc-lbl[data-ev]').forEach((t) => t.addEventListener('click', () => {
        const ev = EVENTS.find((x) => String(x.id) === t.dataset.ev);
        if (ev) openEdit(ev);
    }));
}

/* ═══════════ КАРТКИ ПОДІЙ ═══════════ */
/* людське речення для одного ефекту */
function sentence(e) {
    const p = paramByKey(e.param_key);
    const lbl = p ? p.label : (e.param_label || e.param_key);
    if (!p) return null;   // нечинний ефект — не шумимо в списку, видно в картці
    if (e.param_key === 'group' && e.mode === 'const') return null;   // показується бейджем «→ секція»
    if (e.mode === 'input') return null;                              // показується бейджем «питає»
    if (e.mode === 'event_date') return `записує дату події → <b>${escapeHtml(lbl)}</b>`;
    if (e.mode === 'const') return `ставить <b>${escapeHtml(lbl)}</b> = ${escapeHtml(codeLabel(e.param_key, e.arg))}`;
    if (e.mode === 'inc') return `<b>${escapeHtml(lbl)}</b> ${+e.arg >= 0 ? '+' : ''}${escapeHtml(e.arg)}`;
    if (e.mode === 'clear') return `очищає <b>${escapeHtml(lbl)}</b>`;
    if (e.mode === 'when') {
        const s = parseWhenSpec(e.arg);
        const parts = s.rules.filter((r) => r.if).map((r) => {
            const a = codeLabel(r.if, r.eq), b = codeLabel(e.param_key, r.val);
            return a === b ? a : `${a} → ${b}`;   // однакові підписи не дублюємо
        });
        if (s.default) parts.push(`інакше → ${codeLabel(e.param_key, s.default)}`);
        return `<b>${escapeHtml(lbl)}</b> — за відповіддю: ${escapeHtml(parts.join(' · '))}`;
    }
    return null;
}

function render() {
    $('evCount').textContent = EVENTS.length ? `· ${EVENTS.length}` : '';
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    let html = '';
    order.forEach((cat) => {
        const list = bySec[cat];
        if (!list || !list.length) return;
        html += `<div class="evx-cat">${escapeHtml(CATS[cat] || cat)}</div>`;
        list.forEach((e) => {
            const sents = (e.effects || []).map(sentence).filter(Boolean);
            const asks = (e.effects || []).filter((f) => f.mode === 'input')
                .map((f) => { const p = paramByKey(f.param_key); return p ? p.label : f.param_key; });
            const sec = (e.effects || []).find((f) => f.param_key === 'group' && f.mode === 'const');
            html += `<div class="evx-card${e.is_active ? '' : ' off'}" data-id="${e.id}">
                <div class="hd"><b>${escapeHtml(e.name)}</b>
                    ${e.is_active ? '' : '<span class="ev-badge">вимкнена</span>'}
                    <span class="ev-badge ${e.is_standard ? 'std' : 'cus'}">${e.is_standard ? 'системна' : 'створена'}</span></div>
                ${sents.length ? `<div class="sent">${sents.join('<br>')}</div>` : ''}
                <div class="opts">
                    ${asks.map((a) => `<span class="opt ask">питає: ${escapeHtml(a)}</span>`).join('')}
                    ${sec ? `<span class="opt sec">→ секція ${escapeHtml(sec.arg)}</span>` : ''}
                    ${e.attach_to ? `<span class="opt">у вікні «${escapeHtml((EVENTS.find((x) => x.key === e.attach_to) || {}).name || e.attach_to)}»</span>` : ''}
                </div>
            </div>`;
        });
    });
    $('evCards').innerHTML = html || '<div class="empty" style="padding:14px">Немає подій</div>';
    $('evCards').querySelectorAll('.evx-card').forEach((c) => c.addEventListener('click', () => {
        const ev = EVENTS.find((x) => String(x.id) === c.dataset.id);
        if (ev) openEdit(ev);
    }));
}

/* ═══════════ САМОПЕРЕВІРКА ═══════════ */
$('evSelftestBtn').addEventListener('click', async () => {
    const out = $('evSelftestOut');
    out.hidden = false;
    out.innerHTML = '<div class="text-mute">Проганяю тестову тварину по колу…</div>';
    const r = await apiSend('/api/herd/repro-selftest', 'POST', {});
    if (!r || !r.ok) { out.innerHTML = `<div class="evx-verdict bad">Помилка: ${escapeHtml((r && r.error) || '')}</div>`; return; }
    const ok = r.checks.every((c) => c.ok);
    out.innerHTML = `<div class="evx-verdict ${ok ? 'ok' : 'bad'}">${ok
        ? '✅ Алгоритм виконується, коло замкнене' : '⚠ Знайдено проблеми — дивіться червоні рядки'}</div>`
        + r.checks.map((c) => `<div class="row ${c.ok ? 'ok' : 'bad'}">
            <span class="m">${c.ok ? '✓' : '✗'}</span>
            <span>${escapeHtml(c.label)}</span>
            ${c.note ? `<span class="note">· ${escapeHtml(c.note)}</span>` : ''}
        </div>`).join('');
});

/* ═══════════ ПРОСТИЙ РЕЖИМ: РЕЧЕННЯ ═══════════ */
const SECTIONS = () => ((paramByKey('group') || {}).choices || []);

function paramOptionsHtml(sel, filter) {
    return PARAMS.filter(filter || (() => true)).map((p) =>
        `<option value="${p.key}"${p.key === sel ? ' selected' : ''}>${escapeHtml(p.label)}</option>`).join('');
}
function valueCtl(paramKey, val, cls) {
    const p = paramByKey(paramKey);
    const ch = (p && p.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ${cls}"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ${cls} sm" value="${escapeHtml(val || '')}">`;
}

/* один ефект → рядок-речення (повертає '', якщо в простому режимі не редагується) */
function sentRow(e, i) {
    const isGroup = e.param_key === 'group' && e.mode === 'const';
    const kind = isGroup ? 'group' : e.mode;
    const pk = e.param_key;
    // параметр обчислюваний або видалений → дія нічого не робить
    if (!isGroup && pk && !paramByKey(pk)) {
        return `<div class="evx-sent-row" data-i="${i}" data-kind="dead">
            <span class="t" style="text-decoration:line-through; color:#b6bec9">нечинна дія:
            параметр «${escapeHtml(pk)}» обчислюється сам або видалений</span>
            <button type="button" class="rm" title="Прибрати">✕</button></div>`;
    }
    let inner = '';
    if (kind === 'group') {
        inner = `<span class="t">переводить у секцію</span>
            <select class="ref-select" data-f="arg"><option value="">— оберіть —</option>
            ${SECTIONS().map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(e.arg) ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')}
            </select>`;
    } else if (kind === 'event_date') {
        inner = `<span class="t">записує дату події в</span>
            <select class="ref-select" data-f="param">${paramOptionsHtml(pk, (p) => p.dtype === 'date')}</select>`;
    } else if (kind === 'const') {
        inner = `<span class="t">ставить</span>
            <select class="ref-select" data-f="param">${paramOptionsHtml(pk, (p) => p.key !== 'group')}</select>
            <span class="t">=</span> ${valueCtl(pk, e.arg, 'v-arg')}`;
    } else if (kind === 'input') {
        inner = `<span class="t">питає в оператора</span>
            <select class="ref-select" data-f="param">${paramOptionsHtml(pk)}</select>
            <span class="t">за замовч.</span> ${valueCtl(pk, e.arg, 'v-arg')}`;
    } else if (kind === 'inc') {
        inner = `<span class="t">додає до</span>
            <select class="ref-select" data-f="param">${paramOptionsHtml(pk, (p) => ['int', 'float', 'number'].includes(p.dtype))}</select>
            <span class="t">+</span><input type="text" class="ref-select sm v-arg" value="${escapeHtml(e.arg || '1')}">`;
    } else if (kind === 'clear') {
        inner = `<span class="t">очищає</span>
            <select class="ref-select" data-f="param">${paramOptionsHtml(pk)}</select>`;
    } else if (kind === 'when') {
        const p = paramByKey(pk);
        const s = parseWhenSpec(e.arg);
        const txt = s.rules.filter((r) => r.if).map((r) => {
            const ifp = paramByKey(r.if);
            return `${(ifp && ifp.label) || r.if} = ${codeLabel(r.if, r.eq)} → ${codeLabel(pk, r.val)}`;
        }).join('; ');
        inner = `<span class="t">розгалуження:</span>
            <span class="when-txt"><b>${escapeHtml(p ? p.label : pk)}</b> — якщо ${escapeHtml(txt)}${s.default ? `; інакше → ${escapeHtml(codeLabel(pk, s.default))}` : ''}</span>
            <span class="t">(редагується в «Розширено»)</span>`;
    } else {
        return '';
    }
    return `<div class="evx-sent-row" data-i="${i}" data-kind="${kind}">${inner}
        <button type="button" class="rm" title="Прибрати">✕</button></div>`;
}

function renderSimple() {
    const box = $('eeSent');
    box.innerHTML = WORK.map((e, i) => sentRow(e, i)).join('')
        || '<div class="text-mute" style="font-size:12.5px">Подія поки нічого не робить — додайте дію нижче.</div>';
    // редагування на місці
    box.querySelectorAll('.evx-sent-row').forEach((row) => {
        const i = +row.dataset.i;
        const e = WORK[i];
        row.querySelectorAll('[data-f="param"]').forEach((sel) => sel.addEventListener('change', () => {
            e.param_key = sel.value;
            if (e.mode === 'const' || e.mode === 'input') renderSimple();   // поле значення залежить від параметра
        }));
        const arg = row.querySelector('.v-arg, [data-f="arg"]');
        if (arg) arg.addEventListener('change', () => { e.arg = arg.value; });
        if (arg && arg.tagName === 'INPUT') arg.addEventListener('input', () => { e.arg = arg.value; });
        row.querySelector('.rm').addEventListener('click', () => { WORK.splice(i, 1); renderSimple(); });
    });
}

$('eeAddKind').addEventListener('change', () => {
    const k = $('eeAddKind').value;
    $('eeAddKind').value = '';
    if (!k) return;
    if (k === 'group') WORK.push({ param_key: 'group', mode: 'const', arg: '' });
    else if (k === 'event_date') {
        const p = PARAMS.find((x) => x.dtype === 'date');
        WORK.push({ param_key: p ? p.key : '', mode: 'event_date', arg: '' });
    } else if (k === 'inc') {
        const p = PARAMS.find((x) => ['int', 'float', 'number'].includes(x.dtype));
        WORK.push({ param_key: p ? p.key : '', mode: 'inc', arg: '1' });
    } else {
        WORK.push({ param_key: PARAMS[0] ? PARAMS[0].key : '', mode: k, arg: '' });
    }
    renderSimple();
});

/* ═══════════ РОЗШИРЕНИЙ РЕЖИМ (старий конструктор) ═══════════ */
function autoModeOptions(sel) {
    return Object.entries(MODES).filter(([k]) => k !== 'input').map(([k, v]) =>
        `<option value="${k}"${k === sel ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
}
function argControlHtml(param, val) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        const opts = '<option value="">—</option>' + ch.map((c) =>
            `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('');
        return `<select class="ref-select ee-arg">${opts}</select>`;
    }
    return `<input type="text" class="ref-select ee-arg" placeholder="значення" value="${escapeHtml(val || '')}">`;
}
function paramSelectHtml(sel, cls) {
    return `<select class="ref-select ${cls}"><option value="">— параметр —</option>`
        + PARAMS.map((p) => `<option value="${escapeHtml(p.key)}"${p.key === sel ? ' selected' : ''}>${escapeHtml(p.label)}</option>`).join('')
        + '</select>';
}
function valControlHtml(param, val, cls) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ${cls}"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ${cls}" value="${escapeHtml(val || '')}" placeholder="значення" style="width:88px">`;
}
function parseWhenSpec(arg) {
    let d = {};
    try { if (arg && arg.trim().startsWith('{')) d = JSON.parse(arg); } catch (e) { d = {}; }
    if (d && Array.isArray(d.rules)) {
        return {
            rules: d.rules.map((r) => ({ if: r.if || '', eq: r.eq || '', val: r.val || '' })),
            default: d.default || '',
        };
    }
    if (d && (d.if || d.eq || d.val)) {
        if (!d.if) return { rules: [], default: d.val || '' };
        return { rules: [{ if: d.if, eq: d.eq || '', val: d.val || '' }], default: '' };
    }
    return { rules: [], default: '' };
}
function whenRuleLineHtml(targetParam, r) {
    const ifParam = paramByKey(r.if);
    return `<div class="ee-when-line" data-role="rule">`
        + `<span class="ee-op">якщо</span> ${paramSelectHtml(r.if, 'ee-if')} `
        + `<span class="ee-op">=</span> ${valControlHtml(ifParam, r.eq, 'ee-ifval')} `
        + `<span class="ee-op">→</span> ${valControlHtml(targetParam, r.val, 'ee-val')}`
        + `<button type="button" class="ee-line-del" title="Прибрати умову">✕</button></div>`;
}
function whenDefaultLineHtml(targetParam, val) {
    return `<div class="ee-when-line ee-when-def" data-role="default">`
        + `<span class="ee-op">інакше</span> <span class="ee-op">→</span> `
        + `${valControlHtml(targetParam, val, 'ee-val')}</div>`;
}
function whenBlockHtml(targetParam, arg) {
    const spec = parseWhenSpec(arg);
    const rules = spec.rules.length ? spec.rules : [{ if: '', eq: '', val: '' }];
    const lines = rules.map((r) => whenRuleLineHtml(targetParam, r)).join('')
        + whenDefaultLineHtml(targetParam, spec.default);
    return `<div class="ee-when"><div class="ee-when-lines">${lines}</div>`
        + `<button type="button" class="ee-when-add">+ ще «якщо»</button></div>`;
}
function readWhenBlock(scope) {
    const rules = [];
    scope.querySelectorAll('.ee-when-line[data-role="rule"]').forEach((l) => {
        rules.push({
            if: (l.querySelector('.ee-if') || {}).value || '',
            eq: (l.querySelector('.ee-ifval') || {}).value || '',
            val: (l.querySelector('.ee-val') || {}).value || '',
        });
    });
    const dl = scope.querySelector('.ee-when-line[data-role="default"] .ee-val');
    return { rules, default: dl ? dl.value : '' };
}
function argHtmlFor(param, mode, ask, val) {
    if (!ask && mode === 'when') return whenBlockHtml(param, val);
    return argControlHtml(param, val);
}
function effRow(e) {
    e = e || { param_key: '', mode: 'const', arg: '' };
    const ask = e.mode === 'input';
    const autoMode = ask ? 'const' : (e.mode || 'const');
    const div = document.createElement('div');
    div.className = 'ev-eff-row';
    const curParam = paramByKey(e.param_key);
    div.innerHTML =
        `<input type="text" class="ref-select ee-param" list="eeParamDL" placeholder="пошук параметра…"
             value="${escapeHtml(curParam ? curParam.label : '')}" autocomplete="off">
         <label class="ee-ask" title="Питати значення в оператора під час події">
             <input type="checkbox" class="ee-ask-cb" ${ask ? 'checked' : ''}> Питати</label>
         <select class="ref-select ee-mode">${autoModeOptions(autoMode)}</select>
         <span class="ee-arg-wrap"></span>
         <button type="button" class="ev-eff-del" title="Прибрати">✕</button>`;
    const askCb = div.querySelector('.ee-ask-cb');
    const modeSel = div.querySelector('.ee-mode');
    const paramSel = div.querySelector('.ee-param');
    const argWrap = div.querySelector('.ee-arg-wrap');
    const isWhenMode = () => !askCb.checked && modeSel.value === 'when';
    const sync = () => {
        const asking = askCb.checked;
        modeSel.disabled = asking;
        const argInp = div.querySelector('.ee-arg');
        if (argInp) {
            const showArg = asking || ARG_MODES.has(modeSel.value);
            argInp.style.visibility = showArg ? '' : 'hidden';
            if (argInp.tagName === 'INPUT') argInp.placeholder = asking ? 'за замовч. (необовʼязково)' : 'значення';
        }
    };
    const renderArg = (val) => {
        const tgt = paramByLabel(paramSel.value) || curParam;
        div.classList.toggle('has-when', isWhenMode());
        argWrap.innerHTML = argHtmlFor(tgt, askCb.checked ? 'input' : modeSel.value, askCb.checked, val);
        sync();
    };
    const keepWhen = () => renderArg(isWhenMode() ? JSON.stringify(readWhenBlock(argWrap)) : '');
    paramSel.addEventListener('change', keepWhen);
    paramSel.addEventListener('input', keepWhen);
    askCb.addEventListener('change', () => renderArg(''));
    modeSel.addEventListener('change', () => renderArg(''));
    argWrap.addEventListener('click', (ev) => {
        if (ev.target.closest('.ee-when-add')) {
            const s = readWhenBlock(argWrap); s.rules.push({ if: '', eq: '', val: '' });
            renderArg(JSON.stringify(s));
        } else if (ev.target.closest('.ee-line-del')) {
            const line = ev.target.closest('.ee-when-line');
            const idx = [...argWrap.querySelectorAll('.ee-when-line[data-role="rule"]')].indexOf(line);
            const s = readWhenBlock(argWrap); s.rules.splice(idx, 1);
            renderArg(JSON.stringify(s));
        }
    });
    argWrap.addEventListener('change', (ev) => {
        if (ev.target.classList.contains('ee-if')) renderArg(JSON.stringify(readWhenBlock(argWrap)));
    });
    div.querySelector('.ev-eff-del').addEventListener('click', () => div.remove());
    renderArg(e.arg);
    return div;
}
function collectEffects() {
    const out = [];
    document.querySelectorAll('#eeEffects .ev-eff-row').forEach((r) => {
        const p = paramByLabel(r.querySelector('.ee-param').value);
        const pk = p ? p.key : '';
        if (!pk) return;
        const asking = r.querySelector('.ee-ask-cb').checked;
        const mode = asking ? 'input' : r.querySelector('.ee-mode').value;
        let arg = '';
        if (mode === 'when') {
            const s = readWhenBlock(r.querySelector('.ee-arg-wrap'));
            const rules = s.rules.filter((x) => x.if);
            if (!rules.length && !s.default) return;
            arg = JSON.stringify({ rules, default: s.default });
        } else if (asking || ARG_MODES.has(mode)) {
            const el = r.querySelector('.ee-arg');
            arg = el ? el.value.trim() : '';
        }
        out.push({ param_key: pk, mode, arg });
    });
    return out;
}

/* ═══════════ МОДАЛ ═══════════ */
let advOpen = false;
function renderAdvanced() {
    const box = $('eeEffects'); box.innerHTML = '';
    WORK.forEach((e) => box.appendChild(effRow(e)));
    if (!WORK.length) box.appendChild(effRow(null));
}
function syncFromAdvanced() { if (advOpen) WORK = collectEffects(); }

function openEdit(ev) {
    editing = ev;
    const isNew = !ev;
    advOpen = false;
    $('eeAdvanced').hidden = true;
    $('eeSimple').hidden = false;
    $('eeAdvToggle').textContent = 'Розширено ▸';
    $('eeTitle').textContent = isNew ? 'Нова подія' : ('Подія: ' + ev.name);
    $('eeName').value = isNew ? '' : ev.name;
    $('eeCat').innerHTML = Object.entries(CATS).map(([k, v]) =>
        `<option value="${k}"${(!isNew && ev.category === k) ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
    $('eeActive').checked = isNew ? true : !!ev.is_active;
    $('eeShowPanel').checked = isNew ? true : (ev.show_on_panel === undefined ? true : !!ev.show_on_panel);
    const attSel = ev ? (ev.attach_to || '') : '';
    $('eeAttach').innerHTML = '<option value="">— окрема подія —</option>' +
        EVENTS.filter((x) => !ev || x.id !== ev.id).map((x) =>
            `<option value="${escapeHtml(x.key)}"${x.key === attSel ? ' selected' : ''}>${escapeHtml(x.name)}</option>`).join('');
    WORK = (isNew ? [] : (ev.effects || [])).map((e) =>
        ({ param_key: e.param_key, mode: e.mode, arg: e.arg }));
    renderSimple();
    $('eeDelBtn').style.display = (isNew ? false : (!ev.is_standard || window.canManage('herd'))) ? '' : 'none';
    $('evEditModal').hidden = false;
    $('eeName').focus();
}

$('eeAdvToggle').addEventListener('click', () => {
    if (advOpen) {           // розширений → простий: забираємо зміни конструктора
        WORK = collectEffects();
        renderSimple();
    } else {
        renderAdvanced();
    }
    advOpen = !advOpen;
    $('eeAdvanced').hidden = !advOpen;
    $('eeSimple').hidden = advOpen;
    $('eeAdvToggle').textContent = advOpen ? '◂ Простий вигляд' : 'Розширено ▸';
});

async function saveEdit() {
    const isNew = !editing;
    const name = $('eeName').value.trim();
    if (!name) { toast('Вкажіть назву', 'warn'); $('eeName').focus(); return; }
    syncFromAdvanced();
    const effects = WORK.filter((e) => e.param_key);
    const payload = {
        name, category: $('eeCat').value, is_active: $('eeActive').checked,
        show_on_panel: $('eeShowPanel').checked,
        attach_to: $('eeAttach').value || '',
        is_standard: isNew ? 0 : (editing.is_standard ? 1 : 0),
        effects,
    };
    const url = isNew ? '/api/herd/events' : ('/api/herd/events/' + editing.id);
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('evEditModal').hidden = true;
    toast(isNew ? 'Додано' : 'Збережено', 'success');
    load();
}

async function delEdit() {
    const ev = editing;
    if (!ev) { $('evEditModal').hidden = true; return; }
    if (ev.is_standard && !window.canManage('herd')) { toast('Системну подію видаляє лише адмін', 'warn'); return; }
    if (!confirm(`Видалити подію «${ev.name}»?`)) return;
    const r = await apiSend('/api/herd/events/' + ev.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('evEditModal').hidden = true;
    load();
}

$('evAddBtn').addEventListener('click', () => openEdit(null));
$('eeAddEff').addEventListener('click', () => $('eeEffects').appendChild(effRow(null)));
$('eeSaveBtn').addEventListener('click', saveEdit);
$('eeDelBtn').addEventListener('click', delEdit);
document.querySelectorAll('#evEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('evEditModal').hidden = true; }));
document.addEventListener('herd-params-changed', () => { if ($('evCards')) load(); });
if ($('evCards')) load();
})();
