"""Розширений модуль роботи з базою для web-версії ветаптеки.

Перевикористовує таблиці існуючого SQLite (products / stock_batches / stock_moves),
але додає:
- ціни (price_in, price_out) у партіях;
- зручні методи для звітів та попереджень про терміни придатності;
- API-сумісні словники замість dataclass-ів.
"""

from __future__ import annotations

import os
import sys
import csv
import json
import math
import re
import shutil
import sqlite3
import time
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Any, Optional

# Версія СТРУКТУРИ бази. Підвищуй на 1, коли змінюєш схему так, що потрібна
# міграція. При підвищенні програма САМА робить копію БД перед міграцією —
# щоб після оновлення нічого не «розсипалось» і був відкат.
SCHEMA_VERSION = 6

# Папка з кодом/даними у OneDrive — тут лежать стара база та бекапи.
APP_DATA_DIR = Path(__file__).resolve().parent.parent / "data"
LEGACY_DB_PATH = APP_DATA_DIR / "vet_pharmacy.db"
# Сумісність зі старим іменем
DB_PATH = LEGACY_DB_PATH


def _local_data_dir() -> Path:
    """Локальна папка даних поза OneDrive (WAL з хмарою не уживається)."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "FarmDB"


def _resolve_path(db_path: Path | None) -> Path:
    if db_path is not None:
        return Path(db_path)
    env_path = os.environ.get("VET_DB_PATH")
    if env_path:
        return Path(env_path)
    # За замовчуванням — ЛОКАЛЬНА база (не OneDrive), незалежно від способу запуску.
    return _local_data_dir() / "workcenter.db"


class WebInventoryDB:
    def __init__(self, db_path: Path | None = None) -> None:
        self.db_path = _resolve_path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        # Перейменування БД: стара назва vet_pharmacy.db → нова workcenter.db.
        # Якщо нової ще нема, а поряд лежить стара локальна — переносимо її
        # (разом зі службовими файлами WAL), щоб не загубити дані.
        old_local = self.db_path.parent / "vet_pharmacy.db"
        if not self.db_path.exists() and old_local.exists():
            for suff in ("", "-wal", "-shm", "-journal"):
                src = Path(str(old_local) + suff)
                dst = Path(str(self.db_path) + suff)
                if src.exists():
                    try:
                        src.rename(dst)
                    except OSError:
                        try:
                            shutil.copy2(src, dst)
                        except OSError:
                            pass
        # Одноразовий перенос: якщо локальної бази ще нема, але в OneDrive є
        # стара — копіюємо її, щоб не загубити дані й не починати з порожньої.
        if (not self.db_path.exists() and LEGACY_DB_PATH.exists()
                and self.db_path.resolve() != LEGACY_DB_PATH.resolve()):
            try:
                shutil.copy2(LEGACY_DB_PATH, self.db_path)
            except OSError:
                pass
        self._init_db()
        self._pre_upgrade_backup()   # копія ПЕРЕД зміною схеми (відкат)
        self._migrate()
        self._relax_blocks_unique()       # blocks: (name,category)→(name,category,herd_kind)
        self._finalize_schema_version()   # зафіксувати нову версію схеми
        self._create_indexes()
        self._seed_demo()
        self._seed_expense_categories()
        self._seed_feed_once()
        self._cleanup_auto_water_once()   # прибрати авто-приходи води (одноразово)
        self._cleanup_empty_blocks_once() # прибрати старі безіменні блоки
        self._fix_receipt_dates_once()    # прихід → датою документа (одноразово)
        self._start_auto_backup()
        self._start_auto_analytics()
        self._start_auto_notify()
        self._start_auto_ingest()
        # Легке оновлення статистики планувальника запитів (для великих обсягів).
        try:
            with self._connect() as conn:
                conn.execute("PRAGMA optimize")
                jm = conn.execute("PRAGMA journal_mode").fetchone()
        except Exception:  # noqa: BLE001
            jm = None
        on_cloud = "OneDrive" in str(self.db_path) or "CloudStorage" in str(self.db_path)
        print(f"[DB] жива база: {self.db_path}")
        print(f"[DB] журнал: {jm[0] if jm else '?'}"
              + ("  ⚠ База в OneDrive — для надійності винесіть її локально!" if on_cloud else ""))

    def _fix_receipt_dates_once(self) -> None:
        """Одноразово: перенести приходи на ДАТУ ДОКУМЕНТА.

        До 1.61.7 прихід записував рух і партію моментом введення, а вказана
        людиною дата приходу лягала лише в `stock_batches.receipt_date` і в
        розрахунках не бралася. Через це накладна, внесена заднім числом,
        «зʼявлялась на складі» в день введення: залишки на дату, звіти руху й
        собівартість за минулі періоди були зсунуті, а корм міг стояти в мінусі
        доти, доки прихід не «наздоганяв» списання (у клієнта так розійшлися
        80 зі 126 приходів, подекуди на 200+ днів).

        Правимо ЛИШЕ `created_at` руху й партії, кількості та суми не чіпаємо.
        Час доби зберігаємо — щоб порядок операцій усередині дня не змінився.
        Перед правкою — копія бази; маркер не дає виконатись двічі."""
        try:
            if self.get_setting("receipt_dates_migrated", "") == "1":
                return
            with self._connect() as conn:
                rows = conn.execute(
                    "SELECT m.id AS mid, b.id AS bid, b.receipt_date AS rd, "
                    "       m.created_at AS mts, b.created_at AS bts "
                    "  FROM stock_moves m "
                    "  JOIN stock_batches b ON b.id = m.batch_id "
                    " WHERE m.move_type = 'IN' "
                    "   AND COALESCE(b.receipt_date, '') <> '' "
                    "   AND substr(m.created_at, 1, 10) <> b.receipt_date").fetchall()
                if not rows:
                    self.set_setting("receipt_dates_migrated", "1")
                    return
                # копія бази перед зміною історії — як при апгрейді схеми
                try:
                    self._pre_upgrade_backup()
                except Exception:  # noqa: BLE001
                    pass
                n = 0
                for r in rows:
                    day = str(r["rd"])[:10]
                    try:
                        date.fromisoformat(day)
                    except Exception:  # noqa: BLE001
                        continue          # зіпсована дата — краще не чіпати
                    conn.execute(
                        "UPDATE stock_moves SET created_at = ? || substr(created_at, 11) "
                        " WHERE id = ?", (day, r["mid"]))
                    conn.execute(
                        "UPDATE stock_batches SET created_at = ? || substr(created_at, 11) "
                        " WHERE id = ?", (day, r["bid"]))
                    n += 1
            self.set_setting("receipt_dates_migrated", "1")
            self.set_setting("receipt_dates_migrated_n", str(n))
            print(f"[DB] приходи перенесено на дату документа: {n}")
        except Exception as exc:  # noqa: BLE001
            print(f"[DB] міграція дат приходу пропущена: {exc}")

    def _cleanup_auto_water_once(self) -> None:
        """Одноразово прибрати автоматичні приходи води (note='Вода (годівля)'),
        які створювало старе списання. Видаляємо рух IN і його партію-0."""
        try:
            if self.get_setting("water_autoreceipt_cleaned", "") == "1":
                return
            with self._connect() as conn:
                rows = conn.execute(
                    "SELECT id, batch_id FROM stock_moves "
                    "WHERE move_type='IN' AND note='Вода (годівля)'").fetchall()
                # Партію не видаляємо (на неї можуть посилатися списання) —
                # обнуляємо її залишок, а сам прихід прибираємо з журналу.
                for r in rows:
                    if r["batch_id"]:
                        conn.execute("UPDATE stock_batches SET qty=0 WHERE id=?",
                                     (r["batch_id"],))
                conn.execute("DELETE FROM stock_moves "
                             "WHERE move_type='IN' AND note='Вода (годівля)'")
            self.set_setting("water_autoreceipt_cleaned", "1")
        except Exception:  # noqa: BLE001
            pass

    def _cleanup_empty_blocks_once(self) -> None:
        """Одноразово деактивувати старі блоки без назви (застарілий мотлох, що
        показувався у «Не розподілено»). Нові блоки без назви створити не можна."""
        try:
            if self.get_setting("empty_blocks_cleaned", "") == "1":
                return
            with self._connect() as conn:
                conn.execute(
                    "UPDATE blocks SET is_active=0 "
                    "WHERE is_active=1 AND COALESCE(TRIM(name),'')=''")
            self.set_setting("empty_blocks_cleaned", "1")
        except Exception:  # noqa: BLE001
            pass

    def _create_indexes(self) -> None:
        """Індекси на «гарячі» колонки — щоб запити лишались швидкими навіть
        на мільйонах рядків (звіти, останні операції, надходження тощо)."""
        stmts = [
            # рухи складу
            "CREATE INDEX IF NOT EXISTS ix_moves_product   ON stock_moves(product_id)",
            "CREATE INDEX IF NOT EXISTS ix_moves_batch     ON stock_moves(batch_id)",
            "CREATE INDEX IF NOT EXISTS ix_moves_saleno    ON stock_moves(sale_no)",
            "CREATE INDEX IF NOT EXISTS ix_moves_type      ON stock_moves(move_type)",
            "CREATE INDEX IF NOT EXISTS ix_moves_created   ON stock_moves(created_at)",
            "CREATE INDEX IF NOT EXISTS ix_moves_type_date ON stock_moves(move_type, created_at)",
            # індекс по даті-дню — щоб фільтри звітів substr(created_at,1,10) були миттєвими
            "CREATE INDEX IF NOT EXISTS ix_moves_day       ON stock_moves(substr(created_at,1,10))",
            # партії
            "CREATE INDEX IF NOT EXISTS ix_batches_product ON stock_batches(product_id)",
            "CREATE INDEX IF NOT EXISTS ix_batches_supp    ON stock_batches(supplier_id)",
            "CREATE INDEX IF NOT EXISTS ix_batches_expires ON stock_batches(expires_on)",
            # товари
            "CREATE INDEX IF NOT EXISTS ix_products_cat    ON products(category)",
            "CREATE INDEX IF NOT EXISTS ix_products_code   ON products(code)",
            # каталог препаратів/матеріалів
            "CREATE INDEX IF NOT EXISTS ix_catalog_cat     ON catalog(category)",
            "CREATE INDEX IF NOT EXISTS ix_catalog_barcode ON catalog(barcode)",
            "CREATE INDEX IF NOT EXISTS ix_catalog_name    ON catalog(name COLLATE NOCASE)",
        ]
        with self._connect() as conn:
            for s in stmts:
                try:
                    conn.execute(s)
                except Exception:  # noqa: BLE001 — напр. стара версія SQLite без виразних індексів
                    pass

    # ------------------------------------------------------------------ infra

    def _connect(self) -> sqlite3.Connection:
        # timeout=30 — драйвер сам чекає до 30 с на знятті блокування, а не
        # кидає одразу "database is locked".
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        # Вибір журналу залежить від платформи:
        #  • Windows / Linux (локальний диск) — WAL: швидший і стабільний.
        #  • macOS — DELETE: WAL тримає службовий файл -shm (memory-mapping),
        #    який на Mac ламається після сну (екран потух → системний сон) і
        #    кидає "unable to open database file". DELETE -shm не використовує.
        # Перевизначити вручну: змінна VET_JOURNAL_MODE = wal | delete.
        desired = os.environ.get("VET_JOURNAL_MODE", "").strip().lower()
        if desired not in ("wal", "delete", "truncate"):
            desired = "delete" if sys.platform == "darwin" else "wal"
        try:
            got = connection.execute(f"PRAGMA journal_mode = {desired}").fetchone()
            if not (got and str(got[0]).lower() == desired):
                connection.execute("PRAGMA journal_mode = DELETE")  # запасний
        except sqlite3.OperationalError:
            try:
                connection.execute("PRAGMA journal_mode = DELETE")
            except sqlite3.OperationalError:
                pass
        try:
            connection.execute("PRAGMA busy_timeout = 30000")
            connection.execute("PRAGMA synchronous = NORMAL")
        except sqlite3.OperationalError:
            pass
        # Власна реалізація LOWER, що правильно опускає регістр Unicode
        # (українські, кириличні символи). Стандартний SQLite-LOWER працює
        # лише з ASCII, тому пошук «Бровермектин» по запиту «бровер» давав
        # порожній результат.
        connection.create_function(
            "ulower", 1, lambda s: s.lower() if isinstance(s, str) else s,
            deterministic=True,
        )
        return connection

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    barcode TEXT NOT NULL UNIQUE,
                    unit TEXT NOT NULL DEFAULT 'шт',
                    min_stock REAL NOT NULL DEFAULT 0,
                    supplier TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS stock_batches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    lot_number TEXT NOT NULL DEFAULT '',
                    expires_on TEXT,
                    qty REAL NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS stock_moves (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    batch_id INTEGER,
                    barcode TEXT NOT NULL,
                    move_type TEXT NOT NULL,
                    qty REAL NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id),
                    FOREIGN KEY(batch_id) REFERENCES stock_batches(id)
                );

                CREATE TABLE IF NOT EXISTS suppliers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    created_at TEXT NOT NULL,
                    UNIQUE(name, category)
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    user_id INTEGER,
                    action TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT '',
                    summary TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS blocks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    created_at TEXT NOT NULL,
                    herd_kind TEXT NOT NULL DEFAULT '',
                    subgroup TEXT NOT NULL DEFAULT '',
                    herd_group_id INTEGER,
                    UNIQUE(name, category, herd_kind)
                );

                CREATE TABLE IF NOT EXISTS recipients (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    created_at TEXT NOT NULL,
                    UNIQUE(name, category)
                );

                CREATE TABLE IF NOT EXISTS expense_categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category_id INTEGER,
                    amount REAL NOT NULL,
                    expense_date TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(category_id) REFERENCES expense_categories(id)
                );

                CREATE TABLE IF NOT EXISTS app_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'user',
                    full_name TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS user_blocks (
                    user_id INTEGER NOT NULL,
                    block_id INTEGER NOT NULL,
                    PRIMARY KEY (user_id, block_id)
                );

                CREATE TABLE IF NOT EXISTS user_branches (
                    user_id INTEGER NOT NULL,
                    branch_id TEXT NOT NULL,
                    PRIMARY KEY (user_id, branch_id)
                );

                CREATE TABLE IF NOT EXISTS catalog (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    barcode TEXT NOT NULL DEFAULT '',
                    name TEXT NOT NULL,
                    unit TEXT NOT NULL DEFAULT 'шт',
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS sync_devices (
                    device_id    TEXT PRIMARY KEY,
                    name         TEXT NOT NULL DEFAULT '',
                    last_user_id INTEGER,
                    last_seen    TEXT
                );

                CREATE TABLE IF NOT EXISTS user_offline_branches (
                    user_id   INTEGER NOT NULL,
                    branch_id TEXT NOT NULL,
                    PRIMARY KEY (user_id, branch_id)
                );

                CREATE TABLE IF NOT EXISTS sync_ops (
                    op_id      TEXT PRIMARY KEY,
                    device_id  TEXT,
                    user_id    INTEGER,
                    type       TEXT NOT NULL,
                    status     TEXT NOT NULL DEFAULT 'applied',
                    sale_no    TEXT NOT NULL DEFAULT '',
                    conflict   TEXT NOT NULL DEFAULT '',
                    client_ts  TEXT,
                    applied_at TEXT
                );
                """
            )

    def _relax_blocks_unique(self) -> None:
        """Послаблюємо унікальність blocks: (name,category) → (name,category,herd_kind),
        щоб однакові назви блоків могли існувати окремо в Корів і в Молодняку.
        SQLite не вміє ALTER CONSTRAINT — перебудовуємо таблицю (id зберігаємо,
        тож block_id у stock_moves / rx_schemes лишається чинним). Власна конекція з
        foreign_keys=OFF: цю PRAGMA не можна змінювати всередині транзакції.
        Ідемпотентно: якщо новий UNIQUE уже на місці — нічого не робимо."""
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            brow = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='blocks'").fetchone()
            bsql = (brow["sql"] if brow else "") or ""
            if not bsql:
                return                              # таблиці ще немає
            norm = bsql.replace(" ", "").replace("\n", "").lower()
            if "unique(name,category,herd_kind)" in norm:
                return                              # уже перебудовано
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(blocks)").fetchall()}
            cat_expr = "category" if "category" in cols else "'pharmacy'"
            created_expr = "created_at" if "created_at" in cols else "''"
            kind_expr = "herd_kind" if "herd_kind" in cols else "''"
            conn.execute("PRAGMA foreign_keys = OFF")
            conn.execute("BEGIN")
            conn.execute(
                """CREATE TABLE blocks_new (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    created_at TEXT NOT NULL DEFAULT '',
                    herd_kind TEXT NOT NULL DEFAULT '',
                    UNIQUE(name, category, herd_kind)
                )""")
            conn.execute(
                f"""INSERT INTO blocks_new
                        (id, name, notes, is_active, category, created_at, herd_kind)
                    SELECT id, name, COALESCE(notes,''), COALESCE(is_active,1),
                           COALESCE({cat_expr},'pharmacy'), COALESCE({created_expr},''),
                           COALESCE({kind_expr},'')
                    FROM blocks""")
            conn.execute("DROP TABLE blocks")
            conn.execute("ALTER TABLE blocks_new RENAME TO blocks")
            conn.execute("COMMIT")
        except Exception:                            # noqa: BLE001
            try:
                conn.execute("ROLLBACK")
            except Exception:                        # noqa: BLE001
                pass
            raise
        finally:
            conn.close()

    def _migrate(self) -> None:
        """Додаємо колонки, яких ще немає (ціни, накладна, ПДВ, націнка)."""
        with self._connect() as conn:
            # блок працівника (гілка «Персонал»), 0 = не розподілено
            try:
                cols_staff = {r["name"] for r in conn.execute("PRAGMA table_info(staff)").fetchall()}
                if cols_staff and "block_id" not in cols_staff:
                    conn.execute("ALTER TABLE staff ADD COLUMN block_id INTEGER NOT NULL DEFAULT 0")
                # табельний номер — унікальний ID працівника (не переприсвоюється:
                # звільнення+повернення = новий номер). Стабільний при зміні
                # імені/Telegram/телефону.
                if cols_staff and "full_name" not in cols_staff:
                    conn.execute("ALTER TABLE staff ADD COLUMN full_name TEXT NOT NULL DEFAULT ''")
                if cols_staff and "gender" not in cols_staff:
                    conn.execute("ALTER TABLE staff ADD COLUMN gender TEXT NOT NULL DEFAULT ''")
                # Telegram-адмін: цей працівник схвалює нових користувачів бота
                if cols_staff and "tg_admin" not in cols_staff:
                    conn.execute("ALTER TABLE staff ADD COLUMN tg_admin INTEGER NOT NULL DEFAULT 0")
                if cols_staff and "staff_code" not in cols_staff:
                    conn.execute("ALTER TABLE staff ADD COLUMN staff_code TEXT NOT NULL DEFAULT ''")
                    n = conn.execute(
                        "SELECT COALESCE(MAX(CAST(staff_code AS INTEGER)),0) FROM staff "
                        "WHERE staff_code GLOB '[0-9]*'").fetchone()[0] or 0
                    for r in conn.execute(
                            "SELECT id FROM staff WHERE staff_code='' ORDER BY id").fetchall():
                        n += 1
                        conn.execute("UPDATE staff SET staff_code=? WHERE id=?",
                                     ("%04d" % n, r["id"]))
                # обчислювані кроки циклу (тривалість) — мітки двох time-кроків
                cols_rs = {r["name"] for r in conn.execute("PRAGMA table_info(role_steps)").fetchall()}
                if cols_rs and "calc_from" not in cols_rs:
                    conn.execute("ALTER TABLE role_steps ADD COLUMN calc_from TEXT NOT NULL DEFAULT ''")
                if cols_rs and "calc_to" not in cols_rs:
                    conn.execute("ALTER TABLE role_steps ADD COLUMN calc_to TEXT NOT NULL DEFAULT ''")
                # разів на день ОКРЕМО на процес (0 = глобальне «Доїнь на день»)
                cols_wp = {r["name"] for r in conn.execute("PRAGMA table_info(work_processes)").fetchall()}
                if cols_wp and "shifts_per_day" not in cols_wp:
                    conn.execute("ALTER TABLE work_processes ADD COLUMN "
                                 "shifts_per_day INTEGER NOT NULL DEFAULT 0")
            except Exception:  # noqa: BLE001
                pass
            cols_products = {row["name"] for row in conn.execute("PRAGMA table_info(products)").fetchall()}
            if "markup_pct" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN markup_pct REAL NOT NULL DEFAULT 0")
            if "sale_price" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN sale_price REAL NOT NULL DEFAULT 0")
            if "code" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN code TEXT NOT NULL DEFAULT ''")
            if "category" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN category TEXT NOT NULL DEFAULT 'pharmacy'")

            # Коди товарів → 6 знаків (000012): вирівнюємо наявні чисто-числові
            # коди, коротші за 6, доповнюючи нулями зліва. Число не змінюється,
            # лише вид. Нечислові й уже довші коди не чіпаємо. Ідемпотентно
            # (повторний запуск нічого не оновлює — length вже = 6).
            conn.execute(
                "UPDATE products SET code = printf('%06d', CAST(code AS INTEGER)) "
                "WHERE code <> '' AND code NOT GLOB '*[^0-9]*' AND length(code) < 6")

            # Норма витрати для прогнозу замовлень (на медикамент) — additive.
            # doza на 1 голову (в одиниці dose_unit: мл/мг/таб), інтервал «раз на
            # N днів», pack_content — скільки тих самих одиниць у 1 складській уп.
            if "dose_per_head" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN dose_per_head REAL NOT NULL DEFAULT 0")
            if "dose_unit" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN dose_unit TEXT NOT NULL DEFAULT ''")
            if "dose_interval_days" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN dose_interval_days INTEGER NOT NULL DEFAULT 0")
            if "pack_content" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN pack_content REAL NOT NULL DEFAULT 0")
            # Виключення з замовлення: товар не бере участі у «До замовлення».
            if "exclude_from_order" not in cols_products:
                conn.execute("ALTER TABLE products ADD COLUMN exclude_from_order INTEGER NOT NULL DEFAULT 0")

            # Поголів'я по гілці — для прогнозу потреби. Зараз source='manual'
            # (вводиться вручну). У майбутньому окремий модуль «Управління стада»
            # (гілка herd) писатиме сюди з source='herd', під'єднуючись до різних
            # гілок, а прогноз читатиме звідси без змін.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS branch_livestock (
                    category TEXT PRIMARY KEY,
                    headcount REAL NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT 'manual',
                    updated_at TEXT NOT NULL DEFAULT ''
                )"""
            )

            # Схеми лікування/профілактики: назва + блок + поголів'я; рядки —
            # медикамент, доза на голову, одиниця, період (day/week/month).
            # Потреба зводиться до місячної й перераховується у флакони/штуки
            # через products.pack_content. Прогноз замовлення будується зі схем.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS rx_schemes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL DEFAULT '',
                    block_id INTEGER,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    headcount REAL NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS rx_scheme_lines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scheme_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    dose_per_head REAL NOT NULL DEFAULT 0,
                    dose_unit TEXT NOT NULL DEFAULT '',
                    times_per INTEGER NOT NULL DEFAULT 1,
                    basis TEXT NOT NULL DEFAULT 'head',
                    period TEXT NOT NULL DEFAULT 'day',
                    created_at TEXT NOT NULL DEFAULT '',
                    FOREIGN KEY(scheme_id) REFERENCES rx_schemes(id)
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_rx_lines_scheme "
                         "ON rx_scheme_lines(scheme_id)")

            # ---- Годівля: рецепти комбікормів і документи виробництва ----
            # Рецепт прив'язаний до товару-комбікорму (К2/К4/К5/К7 у категорії
            # 'feed'). Рядки зберігають кг НА ЗАМІС — використовуються як
            # ПРОПОРЦІЇ: при виробництві масштабуються під фактичний випуск.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS feed_recipes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS feed_recipe_lines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    recipe_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    qty_kg REAL NOT NULL DEFAULT 0,
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(recipe_id) REFERENCES feed_recipes(id)
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_feed_rl_recipe "
                         "ON feed_recipe_lines(recipe_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_feed_recipes_prod "
                         "ON feed_recipes(product_id)")
            # Документ виробництва комбікорму. src_key — ключ ідемпотентності
            # імпорту з Profeed («№партії»), щоб повторний імпорт не задвоїв
            # виробництво; для ручних документів порожній.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS feed_productions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    doc_no TEXT NOT NULL DEFAULT '',
                    prod_date TEXT NOT NULL DEFAULT '',
                    product_id INTEGER NOT NULL,
                    qty_out REAL NOT NULL DEFAULT 0,
                    cost_total REAL NOT NULL DEFAULT 0,
                    price_per_kg REAL NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT 'manual',
                    src_key TEXT NOT NULL DEFAULT '',
                    note TEXT NOT NULL DEFAULT '',
                    user_id INTEGER,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_feed_prod_srckey "
                         "ON feed_productions(src_key) WHERE src_key <> ''")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_feed_prod_date "
                         "ON feed_productions(prod_date)")
            # Склад КОЖНОЇ виробленої партії: план (зі зразка, перерахований на
            # випуск) і факт (скільки реально завантажили). Різниця план/факт —
            # це точність виготовлення; ціна береться фактична, за партіями.
            conn.execute("""CREATE TABLE IF NOT EXISTS feed_production_lines (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    production_id INTEGER NOT NULL,
                    product_id    INTEGER NOT NULL,
                    qty_plan      REAL NOT NULL DEFAULT 0,
                    qty_fact      REAL NOT NULL DEFAULT 0,
                    price         REAL NOT NULL DEFAULT 0,
                    cost          REAL NOT NULL DEFAULT 0,
                    sort_order    INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(production_id) REFERENCES feed_productions(id)
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_feed_pl_prod "
                         "ON feed_production_lines(production_id)")
            # Собівартість без ПДВ — для наявних баз додаємо окремо.
            cols_fp = {r["name"] for r in
                       conn.execute("PRAGMA table_info(feed_productions)").fetchall()}
            if "cost_total_no_vat" not in cols_fp:
                conn.execute("ALTER TABLE feed_productions "
                             "ADD COLUMN cost_total_no_vat REAL NOT NULL DEFAULT 0")
            if "price_per_kg_no_vat" not in cols_fp:
                conn.execute("ALTER TABLE feed_productions "
                             "ADD COLUMN price_per_kg_no_vat REAL NOT NULL DEFAULT 0")
            cols_pl = {r["name"] for r in
                       conn.execute("PRAGMA table_info(feed_production_lines)").fetchall()}
            if "cost_no_vat" not in cols_pl:
                conn.execute("ALTER TABLE feed_production_lines "
                             "ADD COLUMN cost_no_vat REAL NOT NULL DEFAULT 0")
            # Зіставлення кодів Profeed із товарами; ignored=1 — не списувати (H2O).
            conn.execute("""CREATE TABLE IF NOT EXISTS feed_map (
                    profeed_code TEXT PRIMARY KEY,
                    feed_name    TEXT NOT NULL DEFAULT '',
                    product_id   INTEGER,
                    ignored      INTEGER NOT NULL DEFAULT 0
                )"""
            )
            # Кратність (times_per) та тип розрахунку (basis: head=на голову,
            # time=на період без поголів'я) — для наявних баз.
            cols_rxl = {r["name"] for r in conn.execute("PRAGMA table_info(rx_scheme_lines)").fetchall()}
            if "times_per" not in cols_rxl:
                conn.execute("ALTER TABLE rx_scheme_lines ADD COLUMN times_per INTEGER NOT NULL DEFAULT 1")
            if "basis" not in cols_rxl:
                conn.execute("ALTER TABLE rx_scheme_lines ADD COLUMN basis TEXT NOT NULL DEFAULT 'head'")
            # Ручний порядок схем (перетягуванням). Для наявних баз — нумеруємо
            # в межах кожної категорії за поточним показом (блок, назва).
            cols_rxs = {r["name"] for r in conn.execute("PRAGMA table_info(rx_schemes)").fetchall()}
            if "sort_order" not in cols_rxs:
                conn.execute("ALTER TABLE rx_schemes ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0")
                seen: dict[str, int] = {}
                for r in conn.execute(
                        "SELECT s.id, s.category FROM rx_schemes s "
                        "LEFT JOIN blocks b ON b.id = s.block_id WHERE s.is_active = 1 "
                        "ORDER BY s.category, b.name COLLATE NOCASE, s.name COLLATE NOCASE").fetchall():
                    n = seen.get(r["category"], 0) + 1
                    seen[r["category"]] = n
                    conn.execute("UPDATE rx_schemes SET sort_order=? WHERE id=?", (n, r["id"]))
            # Джерело поголів'я схеми: manual | group | move (+ id групи/типу).
            if "hc_source" not in cols_rxs:
                conn.execute("ALTER TABLE rx_schemes ADD COLUMN hc_source TEXT NOT NULL DEFAULT 'manual'")
            if "hc_ref_id" not in cols_rxs:
                conn.execute("ALTER TABLE rx_schemes ADD COLUMN hc_ref_id INTEGER")

            # Управління стада: класифікація груп (Дійні, Запуск, Отел, 1 осім. —
            # за управлінням користувача) + помісячні цифри поголів'я по роках.
            # Глобально (одне стадо для всіх гілок), тож без category.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_groups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL DEFAULT '',
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT '',
                    profeed_block_id INTEGER,
                    herd_kind TEXT NOT NULL DEFAULT '',
                    subgroup TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_counts (
                    group_id INTEGER NOT NULL,
                    year INTEGER NOT NULL,
                    month INTEGER NOT NULL,
                    headcount REAL NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (group_id, year, month),
                    FOREIGN KEY(group_id) REFERENCES herd_groups(id)
                )"""
            )
            # ---- Персонал ВИНЕСЕНО на окремий сервер (webhook-бот + портал).
            # Локально таблиці персоналу/ролей/процесів більше не створюємо
            # і одноразово прибираємо (діти → батьки; дані вже на сервері).
            for _t in ("process_answers", "process_runs",
                       "process_run_participants", "process_steps",
                       "role_answers", "role_runs", "role_steps",
                       "staff_extra_roles", "work_process_roles",
                       "work_processes", "work_roles", "staff_absence",
                       "staff_blocks", "staff"):
                conn.execute(f"DROP TABLE IF EXISTS {_t}")

            # Періоди секцій: секція діє з дати по дату з певним статусом і
            # поголів'ям (секція може змінитися з дійної на сухостійну). Порожня
            # date_to = чинний (відкритий) період. Дає поденну точність.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_section_periods (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    section_id INTEGER NOT NULL,
                    date_from TEXT NOT NULL DEFAULT '',
                    date_to TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT '',
                    herd_kind TEXT NOT NULL DEFAULT '',
                    subgroup TEXT NOT NULL DEFAULT '',
                    profeed_group TEXT NOT NULL DEFAULT '',
                    headcount REAL NOT NULL DEFAULT 0,
                    eat_coef REAL NOT NULL DEFAULT 1,
                    FOREIGN KEY(section_id) REFERENCES herd_groups(id)
                )"""
            )
            # Журнал роздач годівлі з Profeed: секція («Група»), завантажено/роздано
            # кг і поголів'я зі звіту — для аналітики (поголів'я авто, втрати).
            conn.execute(
                """CREATE TABLE IF NOT EXISTS feeding_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    src_key TEXT NOT NULL UNIQUE,
                    op_date TEXT NOT NULL DEFAULT '',
                    group_label TEXT NOT NULL DEFAULT '',
                    block_id INTEGER,
                    ration TEXT NOT NULL DEFAULT '',
                    kg_loaded REAL NOT NULL DEFAULT 0,
                    kg_loaded_all REAL NOT NULL DEFAULT 0,
                    kg_distributed REAL NOT NULL DEFAULT 0,
                    headcount REAL NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            # Повний знімок замісу для читання руху годівлі з БД (без файлів
            # Profeed): додаткові метрики + перелік кормів. Заповнюється при
            # фіксації списання. Дозволяє архівувати/видаляти старі звіти.
            _fe_cols = {r["name"] for r in conn.execute(
                "PRAGMA table_info(feeding_events)").fetchall()}
            for _c in ("plan_loaded", "dry_loaded", "plan_distributed",
                       "dry_distributed", "leftover"):
                if _c not in _fe_cols:
                    conn.execute(
                        f"ALTER TABLE feeding_events ADD COLUMN {_c} REAL NOT NULL DEFAULT 0")
            if "file_ts" not in _fe_cols:      # час зміни файлу-джерела (для «останнє перемагає»)
                conn.execute(
                    "ALTER TABLE feeding_events ADD COLUMN file_ts TEXT NOT NULL DEFAULT ''")
            if "mixer" not in _fe_cols:        # значення колонки «Міксер» з Profeed (номер змішувача)
                conn.execute(
                    "ALTER TABLE feeding_events ADD COLUMN mixer TEXT NOT NULL DEFAULT ''")
            conn.execute(
                """CREATE TABLE IF NOT EXISTS feeding_event_ings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    src_key TEXT NOT NULL,
                    name TEXT NOT NULL DEFAULT '',
                    code TEXT NOT NULL DEFAULT '',
                    plan REAL NOT NULL DEFAULT 0,
                    kg REAL NOT NULL DEFAULT 0,
                    dry REAL NOT NULL DEFAULT 0
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_fei_src ON feeding_event_ings(src_key)")
            # Одне правило: у вже збережених знімках H2O/H₂O → «Вода»
            conn.execute(
                "UPDATE feeding_event_ings SET name='Вода' "
                "WHERE lower(name) IN ('h2o','h₂o')")
            # Рух поголів'я: типи руху (Отел, Запуск, Осіменіння, Вибуття… — за
            # управлінням користувача) + журнал подій по місяцях (з групи → в групу).
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_move_types (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL DEFAULT '',
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_move_counts (
                    type_id INTEGER NOT NULL,
                    year INTEGER NOT NULL,
                    month INTEGER NOT NULL,
                    headcount REAL NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (type_id, year, month),
                    FOREIGN KEY(type_id) REFERENCES herd_move_types(id)
                )"""
            )

            # ── Поголівний облік (реєстр тварин) ─────────────────────────────
            # Кожна тварина — окрема картка за биркою. Родовід: dam_tag (мама),
            # sire_code (тато/бик). status: active/sold/culled/dead. group_id —
            # поточна секція (herd_groups). Репро-показники (тільність, отел…)
            # рахуються з подій, не зберігаються тут.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_animals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tag TEXT NOT NULL DEFAULT '',
                    name TEXT NOT NULL DEFAULT '',
                    sex TEXT NOT NULL DEFAULT 'F',
                    birth_date TEXT NOT NULL DEFAULT '',
                    breed TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'active',
                    group_id INTEGER,
                    dam_tag TEXT NOT NULL DEFAULT '',
                    sire_code TEXT NOT NULL DEFAULT '',
                    source TEXT NOT NULL DEFAULT '',
                    entry_date TEXT NOT NULL DEFAULT '',
                    exit_date TEXT NOT NULL DEFAULT '',
                    exit_reason TEXT NOT NULL DEFAULT '',
                    lactation_no INTEGER NOT NULL DEFAULT 0,
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_ha_tag ON herd_animals(tag)")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_ha_status ON herd_animals(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_ha_group ON herd_animals(group_id)")
            # Універсальна стрічка подій тварини (репро/здоров'я/рух/продукт./інше)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_animal_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    animal_id INTEGER NOT NULL,
                    event_date TEXT NOT NULL DEFAULT '',
                    category TEXT NOT NULL DEFAULT 'other',
                    event_type TEXT NOT NULL DEFAULT '',
                    value REAL NOT NULL DEFAULT 0,
                    ref_tag TEXT NOT NULL DEFAULT '',
                    details TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    user_id INTEGER,
                    FOREIGN KEY(animal_id) REFERENCES herd_animals(id)
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_hae_animal "
                         "ON herd_animal_events(animal_id, event_date)")
            # подія памʼятає тип із довідника і введені значення (2026-08-30):
            # без цього видалення/правка події не можуть чесно перерахувати
            # параметри тварини з ланцюга подій
            cols_ha = {r[1] for r in conn.execute("PRAGMA table_info(herd_animals)")}
            if "lactation_base" not in cols_ha:
                # базова лактація: значення з імпорту/ручного вводу; отели-події
                # додаються ЗВЕРХУ — перерахунок скидає до бази й програє події
                conn.execute("ALTER TABLE herd_animals "
                             "ADD COLUMN lactation_base INTEGER NOT NULL DEFAULT 0")
                conn.execute("UPDATE herd_animals SET lactation_base = lactation_no")
            cols_hae = {r[1] for r in conn.execute(
                "PRAGMA table_info(herd_animal_events)")}
            if "event_def_id" not in cols_hae:
                conn.execute("ALTER TABLE herd_animal_events "
                             "ADD COLUMN event_def_id INTEGER")
            if "inputs_json" not in cols_hae:
                conn.execute("ALTER TABLE herd_animal_events "
                             "ADD COLUMN inputs_json TEXT NOT NULL DEFAULT ''")

            # ── Гнучкі параметри тварин (стандартні + власні, типізовані) ────
            # dtype: number|text|date|select|bool|ref_animal|computed
            # options — JSON-список для select; formula — id вбудованого
            # обчислення для computed (age|dim|days_preg|expected_calving|
            # service_period). section — група на картці.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_param_defs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL UNIQUE,
                    label TEXT NOT NULL DEFAULT '',
                    dtype TEXT NOT NULL DEFAULT 'text',
                    unit TEXT NOT NULL DEFAULT '',
                    options TEXT NOT NULL DEFAULT '',
                    formula TEXT NOT NULL DEFAULT '',
                    section TEXT NOT NULL DEFAULT 'Інше',
                    is_standard INTEGER NOT NULL DEFAULT 0,
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_param_values (
                    animal_id INTEGER NOT NULL,
                    param_id INTEGER NOT NULL,
                    value TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (animal_id, param_id)
                )"""
            )
            _pd_cols = {r["name"] for r in conn.execute(
                "PRAGMA table_info(herd_param_defs)").fetchall()}
            if "short" not in _pd_cols:      # скорочена назва параметра
                conn.execute("ALTER TABLE herd_param_defs ADD COLUMN short TEXT NOT NULL DEFAULT ''")
            self._seed_herd_params(conn)
            # «computed» більше не тип даних, а ознака (formula != ''); мігруємо сіяні
            conn.execute("UPDATE herd_param_defs SET dtype='date' "
                         "WHERE dtype='computed' AND formula='expected_calving'")
            conn.execute("UPDATE herd_param_defs SET dtype='int' WHERE dtype='computed'")
            # старі аліаси → канонічні типи (без дублів у списку)
            conn.execute("UPDATE herd_param_defs SET dtype='float' WHERE dtype='number'")
            conn.execute("UPDATE herd_param_defs SET dtype='list' WHERE dtype='select'")
            conn.execute("UPDATE herd_param_defs SET dtype='cod' WHERE dtype='code'")
            # родовід: «Останній бик» осіменіння — текст (зовнішній бик)
            conn.execute("UPDATE herd_param_defs SET dtype='text' "
                         "WHERE key='last_bull' AND dtype='ref_animal'")
            # статус тільності — довідник відповідностей до репрод. коду
            conn.execute(
                "UPDATE herd_param_defs SET dtype='text', formula=? "
                "WHERE key='preg_status' AND (formula IS NULL OR formula='')",
                ('{"op":"code_label","a":"repro_code","fallback":""}',))

            # ── Події, що змінюють параметри тварин ─────────────────────────
            # Тип події (Отел, Осіменіння…) має набір ефектів: який параметр і
            # як змінити. mode: const|input|event_date|inc|clear.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_event_defs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL DEFAULT '',
                    category TEXT NOT NULL DEFAULT 'other',
                    is_standard INTEGER NOT NULL DEFAULT 0,
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT ''
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS herd_event_effects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id INTEGER NOT NULL,
                    param_key TEXT NOT NULL DEFAULT '',
                    mode TEXT NOT NULL DEFAULT 'const',
                    arg TEXT NOT NULL DEFAULT '',
                    sort_order INTEGER NOT NULL DEFAULT 0
                )"""
            )
            conn.execute("CREATE INDEX IF NOT EXISTS ix_hee_event "
                         "ON herd_event_effects(event_id)")
            # Ознака «народження теляти» — подія дозволяє одразу реєструвати приплід
            _ecols = {r["name"] for r in conn.execute(
                "PRAGMA table_info(herd_event_defs)").fetchall()}
            if "births" not in _ecols:
                conn.execute("ALTER TABLE herd_event_defs ADD COLUMN births "
                             "INTEGER NOT NULL DEFAULT 0")
            # Показувати подію на панелі внесення (окремо від «Активна»)
            if "show_on_panel" not in _ecols:
                conn.execute("ALTER TABLE herd_event_defs ADD COLUMN show_on_panel "
                             "INTEGER NOT NULL DEFAULT 1")
            # Прив'язка події: показувати її у вікні іншої події (key батька).
            # Напр. «Народження» прив'язана до «Отел» → питання приплоду у вікні Отелу.
            if "attach_to" not in _ecols:
                conn.execute("ALTER TABLE herd_event_defs ADD COLUMN attach_to "
                             "TEXT NOT NULL DEFAULT ''")
            self._seed_herd_events(conn)
            self._seed_herd_logic_v2(conn)
            # відкат помилкового перейменування: «Отел» — окрема подія
            conn.execute("UPDATE herd_event_defs SET name='Отел' "
                         "WHERE key='calving' AND name='Народження'")
            # Отел сам приплід НЕ реєструє — це робить окрема подія «Народження»
            conn.execute("UPDATE herd_event_defs SET births=0 WHERE key='calving'")
            # «Народження» — окрема подія з приплодом, прив'язана до Отелу
            conn.execute("UPDATE herd_event_defs SET births=1, attach_to='calving' "
                         "WHERE key='birth'")
            # правило «за статтю» для репрокоду теляти — якщо ефектів ще немає
            _brow = conn.execute(
                "SELECT id FROM herd_event_defs WHERE key='birth'").fetchone()
            if _brow and not conn.execute(
                    "SELECT 1 FROM herd_event_effects WHERE event_id=?",
                    (_brow["id"],)).fetchone():
                conn.execute(
                    "INSERT INTO herd_event_effects (event_id,param_key,mode,arg,"
                    "sort_order) VALUES (?,?,?,?,0)",
                    (_brow["id"], "repro_code", "when",
                     '{"rules":[{"if":"sex","eq":"F","val":"0"},'
                     '{"if":"sex","eq":"M","val":"7"}],"default":""}'))
            # прибрати зайвий input-ефект «Стать» на «Народженні»: стать теляти
            # збирається у блоці приплоду, окреме поле «питати» дублює й плутає
            conn.execute(
                "DELETE FROM herd_event_effects WHERE mode='input' AND param_key='sex' "
                "AND event_id IN (SELECT id FROM herd_event_defs WHERE key='birth')")
            # злити роздільні when-ефекти одного параметра в один (масив правил)
            self._merge_when_effects(conn)

            # Гілка «Управління фінансами»: довідник статей витрат/доходів
            conn.execute(
                """CREATE TABLE IF NOT EXISTS finance_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL DEFAULT 'expense',
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL DEFAULT '')""")
            # Джерело даних статті — окремий Excel-файл (шлях/посилання + мапінг)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS finance_sources (
                    item_id INTEGER PRIMARY KEY,
                    path TEXT NOT NULL DEFAULT '',
                    sheet TEXT NOT NULL DEFAULT '',
                    header_row INTEGER NOT NULL DEFAULT 1,
                    date_col TEXT NOT NULL DEFAULT '',
                    amount_col TEXT NOT NULL DEFAULT '')""")
            # Кілька колонок сум на одну статтю (як показники молока): JSON-список
            # [{label,unit,col}]. amount_col лишається як 1-ша колонка (сумісність).
            cols_fs = {r["name"] for r in conn.execute("PRAGMA table_info(finance_sources)").fetchall()}
            if "metrics_json" not in cols_fs:
                conn.execute("ALTER TABLE finance_sources ADD COLUMN metrics_json TEXT NOT NULL DEFAULT ''")
            # Авто-розбивка (pivot): стовпець суми + виміри (resource, category…)
            # → застосунок сам робить стовпець на кожне значення виміру.
            if "pivot_json" not in cols_fs:
                conn.execute("ALTER TABLE finance_sources ADD COLUMN pivot_json TEXT NOT NULL DEFAULT ''")
            # «Розподіл на дні»: місячну суму ділити на к-сть днів місяця й ставити на кожен день
            if "spread" not in cols_fs:
                conn.execute("ALTER TABLE finance_sources ADD COLUMN spread INTEGER NOT NULL DEFAULT 0")
            # Зафіксовані рядки Excel у БД (як молоко): звіт читає З БАЗИ, Excel — лише джерело імпорту
            conn.execute(
                """CREATE TABLE IF NOT EXISTS finance_rows (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id INTEGER NOT NULL,
                    op_date TEXT NOT NULL DEFAULT '',
                    cells_json TEXT NOT NULL DEFAULT '')""")
            conn.execute("CREATE INDEX IF NOT EXISTS ix_finance_rows_item ON finance_rows(item_id)")

            # Розподіл блоку на корів / молодняк (центр витрат). Видача пише
            # block_id; за herd_kind блоку зводимо витрати «Корови / Молодняк».
            # '' = не розподілено. Additive — наявні блоки лишаються ''.
            cols_blocks = {r["name"] for r in conn.execute("PRAGMA table_info(blocks)").fetchall()}
            if "herd_kind" not in cols_blocks:
                conn.execute("ALTER TABLE blocks ADD COLUMN herd_kind TEXT NOT NULL DEFAULT ''")
            # Підгрупа (Дійні / Сухостій / Телята…) — 2-й рівень між групою й блоком
            if "subgroup" not in cols_blocks:
                conn.execute("ALTER TABLE blocks ADD COLUMN subgroup TEXT NOT NULL DEFAULT ''")
            # Звʼязок секції-блоку з групою стада (звідки береться поголівʼя)
            if "herd_group_id" not in cols_blocks:
                conn.execute("ALTER TABLE blocks ADD COLUMN herd_group_id INTEGER")
            # Секція стада → секція роздачі Profeed (блок). Кілька секцій стада
            # можуть годуватися з однієї роздачі (many-to-one).
            cols_hg = {r["name"] for r in conn.execute("PRAGMA table_info(herd_groups)").fetchall()}
            if "profeed_block_id" not in cols_hg:
                conn.execute("ALTER TABLE herd_groups ADD COLUMN profeed_block_id INTEGER")
            # Категорія секції згідно довідника: група (cow/young) + підгрупа
            if "herd_kind" not in cols_hg:
                conn.execute("ALTER TABLE herd_groups ADD COLUMN herd_kind TEXT NOT NULL DEFAULT ''")
            if "subgroup" not in cols_hg:
                conn.execute("ALTER TABLE herd_groups ADD COLUMN subgroup TEXT NOT NULL DEFAULT ''")
            # Мітка роздачі Profeed (Група-1…), до якої привʼязана секція
            if "profeed_group" not in cols_hg:
                conn.execute("ALTER TABLE herd_groups ADD COLUMN profeed_group TEXT NOT NULL DEFAULT ''")
            # Період секції несе статус: група (cow/young) + підгрупа на дати з-по
            cols_hsp = {r["name"] for r in conn.execute(
                "PRAGMA table_info(herd_section_periods)").fetchall()}
            if cols_hsp:
                if "herd_kind" not in cols_hsp:
                    conn.execute("ALTER TABLE herd_section_periods ADD COLUMN herd_kind TEXT NOT NULL DEFAULT ''")
                if "subgroup" not in cols_hsp:
                    conn.execute("ALTER TABLE herd_section_periods ADD COLUMN subgroup TEXT NOT NULL DEFAULT ''")
                if "profeed_group" not in cols_hsp:
                    conn.execute("ALTER TABLE herd_section_periods ADD COLUMN profeed_group TEXT NOT NULL DEFAULT ''")
                # коефіцієнт споживання на голову (корова=1.0, нетель<1) для
                # поділу однієї Profeed-групи між підкатегоріями
                if "eat_coef" not in cols_hsp:
                    conn.execute("ALTER TABLE herd_section_periods ADD COLUMN eat_coef REAL NOT NULL DEFAULT 1")

            cols_batches = {row["name"] for row in conn.execute("PRAGMA table_info(stock_batches)").fetchall()}
            for col, ddl in [
                ("price_in",         "ALTER TABLE stock_batches ADD COLUMN price_in REAL NOT NULL DEFAULT 0"),
                ("price_out",        "ALTER TABLE stock_batches ADD COLUMN price_out REAL NOT NULL DEFAULT 0"),
                ("price_in_no_vat",  "ALTER TABLE stock_batches ADD COLUMN price_in_no_vat REAL NOT NULL DEFAULT 0"),
                ("vat_rate",         "ALTER TABLE stock_batches ADD COLUMN vat_rate REAL NOT NULL DEFAULT 20"),
                ("markup_pct",       "ALTER TABLE stock_batches ADD COLUMN markup_pct REAL NOT NULL DEFAULT 0"),
                ("invoice_number",   "ALTER TABLE stock_batches ADD COLUMN invoice_number TEXT NOT NULL DEFAULT ''"),
                ("invoice_date",     "ALTER TABLE stock_batches ADD COLUMN invoice_date TEXT NOT NULL DEFAULT ''"),
                ("receipt_date",     "ALTER TABLE stock_batches ADD COLUMN receipt_date TEXT NOT NULL DEFAULT ''"),
                ("supplier_id",      "ALTER TABLE stock_batches ADD COLUMN supplier_id INTEGER"),
                ("sort_order",       "ALTER TABLE stock_batches ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0"),
            ]:
                if col not in cols_batches:
                    conn.execute(ddl)
            # Одне правило: сам товар H2O/H₂O у складі → «Вода».
            conn.execute(
                "UPDATE products SET name='Вода' "
                "WHERE lower(name) IN ('h2o','h₂o')")
            # Вода безкоштовна — обнуляємо ціни її партій, щоб не роздувати
            # суму/баланс складу (велика кількість × ціна).
            conn.execute(
                "UPDATE stock_batches SET price_in=0, price_in_no_vat=0, price_out=0 "
                "WHERE product_id IN (SELECT id FROM products "
                "WHERE lower(name) IN ('h2o','h₂o','вода') AND category='feed')")

            cols_moves = {row["name"] for row in conn.execute("PRAGMA table_info(stock_moves)").fetchall()}
            if "price" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN price REAL NOT NULL DEFAULT 0")
            if "total" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN total REAL NOT NULL DEFAULT 0")
            if "sale_no" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN sale_no TEXT NOT NULL DEFAULT ''")
            if "cash_given" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN cash_given REAL NOT NULL DEFAULT 0")
            if "user_id" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN user_id INTEGER")
            if "original_sale_no" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN "
                             "original_sale_no TEXT NOT NULL DEFAULT ''")
            # Видача на ферму: куди (блок) і кому (отримувач) видано препарат
            if "block_id" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN block_id INTEGER")
            if "recipient_id" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN recipient_id INTEGER")
            # Списання корму «не на годівлю» (напр. солома-підстилка): лягає у
            # витрати складу, але НЕ рахується як спожитий корм і не йде у ₴/л.
            if "not_feed" not in cols_moves:
                conn.execute("ALTER TABLE stock_moves ADD COLUMN "
                             "not_feed INTEGER NOT NULL DEFAULT 0")

            # Журнал дій користувачів — для наявних баз (additive)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    user_id INTEGER,
                    action TEXT NOT NULL,
                    category TEXT NOT NULL DEFAULT '',
                    summary TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                )"""
            )

            # Довідники блоків і отримувачів — для наявних баз (additive)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS blocks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS recipients (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                )"""
            )
            # Розділення довідників за гілками: додаємо category і робимо
            # унікальність у межах категорії (name+category) замість глобальної.
            # FK на ці таблиці немає, тож перебудова безпечна; id зберігаються.
            for _ref in ("suppliers", "blocks", "recipients"):
                _cols = {row["name"] for row in
                         conn.execute(f"PRAGMA table_info({_ref})").fetchall()}
                if "category" in _cols:
                    continue
                conn.executescript(f"""
                    CREATE TABLE {_ref}__new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        notes TEXT NOT NULL DEFAULT '',
                        is_active INTEGER NOT NULL DEFAULT 1,
                        category TEXT NOT NULL DEFAULT 'pharmacy',
                        created_at TEXT NOT NULL,
                        UNIQUE(name, category)
                    );
                    INSERT INTO {_ref}__new (id, name, notes, is_active, category, created_at)
                        SELECT id, name, notes, is_active, 'pharmacy', created_at FROM {_ref};
                    DROP TABLE {_ref};
                    ALTER TABLE {_ref}__new RENAME TO {_ref};
                """)

            # Права користувачів на роботу по блоках (для наявних баз)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS user_blocks (
                    user_id INTEGER NOT NULL,
                    block_id INTEGER NOT NULL,
                    PRIMARY KEY (user_id, block_id)
                )"""
            )
            # Доступ користувачів до гілок виробництва
            conn.execute(
                """CREATE TABLE IF NOT EXISTS user_branches (
                    user_id INTEGER NOT NULL,
                    branch_id TEXT NOT NULL,
                    PRIMARY KEY (user_id, branch_id)
                )"""
            )
            # Налаштування додатка (ключ-значення): напр. шлях до бекапів
            conn.execute(
                """CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL DEFAULT ''
                )"""
            )

            cols_users = {row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
            if "last_seen" not in cols_users:
                conn.execute("ALTER TABLE users ADD COLUMN last_seen TEXT NOT NULL DEFAULT ''")
            if "is_online" not in cols_users:
                conn.execute("ALTER TABLE users ADD COLUMN is_online INTEGER NOT NULL DEFAULT 0")

            # Старим продажам/списанням без номера операції присвоюємо sale_no,
            # групуючи рухи за часом операції — щоб вони з'явилися в журналі.
            self._backfill_sale_no(conn)

            # Каталог препаратів/матеріалів — для наявних баз: створюємо таблицю
            # й один раз наповнюємо з уже наявних товарів складу, щоб довідник
            # не був порожнім одразу після оновлення.
            conn.execute(
                """CREATE TABLE IF NOT EXISTS catalog (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL DEFAULT 'pharmacy',
                    barcode TEXT NOT NULL DEFAULT '',
                    name TEXT NOT NULL,
                    unit TEXT NOT NULL DEFAULT 'шт',
                    created_at TEXT NOT NULL
                )"""
            )
            # Якщо таблиця ще зі старою схемою (UNIQUE(barcode,category) + barcode
            # NOT NULL) — пересоздаємо без обмеження, щоб дозволити записи лише з
            # назвою (без штрихкоду). Запускається один раз (далі UNIQUE немає).
            cat_sql = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='catalog'"
            ).fetchone()
            if cat_sql and "UNIQUE" in (cat_sql[0] or ""):
                conn.executescript(
                    """
                    CREATE TABLE catalog__new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        category TEXT NOT NULL DEFAULT 'pharmacy',
                        barcode TEXT NOT NULL DEFAULT '',
                        name TEXT NOT NULL,
                        unit TEXT NOT NULL DEFAULT 'шт',
                        created_at TEXT NOT NULL
                    );
                    INSERT INTO catalog__new (id, category, barcode, name, unit, created_at)
                        SELECT id, category, barcode, name, unit, created_at FROM catalog;
                    DROP TABLE catalog;
                    ALTER TABLE catalog__new RENAME TO catalog;
                    """
                )
            self._seed_catalog_from_products(conn)

            # Офлайн-синхронізація — для наявних баз (additive)
            conn.execute(
                """CREATE TABLE IF NOT EXISTS sync_devices (
                    device_id    TEXT PRIMARY KEY,
                    name         TEXT NOT NULL DEFAULT '',
                    last_user_id INTEGER,
                    last_seen    TEXT
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS user_offline_branches (
                    user_id   INTEGER NOT NULL,
                    branch_id TEXT NOT NULL,
                    PRIMARY KEY (user_id, branch_id)
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS sync_ops (
                    op_id      TEXT PRIMARY KEY,
                    device_id  TEXT,
                    user_id    INTEGER,
                    type       TEXT NOT NULL,
                    status     TEXT NOT NULL DEFAULT 'applied',
                    sale_no    TEXT NOT NULL DEFAULT '',
                    conflict   TEXT NOT NULL DEFAULT '',
                    client_ts  TEXT,
                    applied_at TEXT
                )"""
            )

    def _seed_catalog_from_products(self, conn) -> None:
        """Разове наповнення каталогу з наявних товарів (по штрихкоду+гілці).

        Виконується один раз (прапорець у app_meta). Далі кожен новий товар
        додається в каталог автоматично в add_product, а ручні зміни каталогу
        не перезатираються."""
        flag = conn.execute(
            "SELECT value FROM app_meta WHERE key = 'catalog_seeded'").fetchone()
        if flag and str(flag[0]) == "1":
            return
        conn.execute(
            "INSERT INTO catalog (category, barcode, name, unit, created_at) "
            "SELECT COALESCE(NULLIF(TRIM(p.category), ''), 'pharmacy'), p.barcode, p.name, "
            "       COALESCE(NULLIF(TRIM(p.unit), ''), 'шт'), p.created_at "
            "FROM products p "
            "WHERE p.is_active = 1 AND TRIM(p.barcode) <> '' "
            "AND NOT EXISTS (SELECT 1 FROM catalog c "
            "                WHERE c.barcode = p.barcode "
            "                AND c.category = COALESCE(NULLIF(TRIM(p.category), ''), 'pharmacy'))"
        )
        conn.execute(
            "INSERT INTO app_meta (key, value) VALUES ('catalog_seeded', '1') "
            "ON CONFLICT(key) DO UPDATE SET value = '1'")

    @staticmethod
    def _backfill_sale_no(conn: sqlite3.Connection) -> None:
        """Присвоює sale_no старим продажам/списанням, де його ще немає.
        Рухи однієї операції мають однаковий created_at — групуємо по ньому.
        Ідемпотентно: чіпає лише рядки з порожнім sale_no.
        """
        row = conn.execute(
            "SELECT COALESCE(MAX(CAST(sale_no AS INTEGER)), 0) "
            "FROM stock_moves WHERE sale_no <> ''"
        ).fetchone()
        n = int(row[0])
        groups = conn.execute(
            "SELECT created_at, move_type FROM stock_moves "
            "WHERE move_type IN ('OUT', 'WRITE_OFF') AND sale_no = '' "
            "GROUP BY created_at, move_type ORDER BY MIN(id)"
        ).fetchall()
        for g in groups:
            n += 1
            conn.execute(
                "UPDATE stock_moves SET sale_no = ? "
                "WHERE move_type = ? AND created_at = ? AND sale_no = ''",
                (str(n), g["move_type"], g["created_at"]),
            )

    def _seed_demo(self) -> None:
        with self._connect() as conn:
            count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
            cleared = conn.execute(
                "SELECT 1 FROM app_meta WHERE key = 'demo_seeded'").fetchone()
            # не наповнюємо демо, якщо товари вже є або базу свідомо очищали
            if count or cleared:
                return
            now = self._now()
            demos = [
                ("Вакцина BioTest A", "4820000000011", "фл", 5, "BioTest", "Холодове зберігання"),
                ("Антибіотик VetCure 50", "4820000000028", "уп", 3, "VetCure", "Для стаціонару"),
                ("Шприц 5 мл", "4820000000035", "шт", 20, "MedSupply", "Розхідник"),
            ]
            conn.executemany(
                "INSERT INTO products (name, barcode, unit, min_stock, supplier, notes, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                [(n, b, u, m, s, nt, now) for n, b, u, m, s, nt in demos],
            )
        # стартові залишки
        self.receive_stock("4820000000011", 12, "LOT-VA-001", "2027-02-01",
                           price_in=180.0, price_out=320.0, markup_pct=78,
                           supplier_name="Початковий облік", invoice_number="ЗАЛИШОК-0",
                           note="Стартовий залишок")
        self.receive_stock("4820000000028", 7, "LOT-AB-001", "2026-08-15",
                           price_in=95.0, price_out=190.0, markup_pct=100,
                           supplier_name="Початковий облік", invoice_number="ЗАЛИШОК-0",
                           note="Стартовий залишок")
        self.receive_stock("4820000000035", 50, "LOT-SY-001", "2029-01-01",
                           price_in=2.0, price_out=5.0, markup_pct=150,
                           supplier_name="Початковий облік", invoice_number="ЗАЛИШОК-0",
                           note="Стартовий залишок")
        self._meta_set("demo_seeded", "1")

    def _seed_expense_categories(self) -> None:
        """Стартові статті витрат (один раз, якщо їх ще немає)."""
        with self._connect() as conn:
            count = conn.execute("SELECT COUNT(*) FROM expense_categories").fetchone()[0]
            if count:
                return
            now = self._now()
            defaults = [
                "Заробітна плата", "Комунальні послуги", "Оренда приміщення",
                "Податки та збори", "Реклама", "Інше",
            ]
            conn.executemany(
                "INSERT INTO expense_categories (name, created_at) VALUES (?, ?)",
                [(n, now) for n in defaults],
            )

    # ------------------------------------------------------------------ meta / службове

    def _meta_get(self, key: str) -> Optional[str]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT value FROM app_meta WHERE key = ?", (key,)).fetchone()
        return row[0] if row else None

    def _meta_set(self, key: str, value: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO app_meta (key, value) VALUES (?, ?)",
                (key, str(value)))

    # ------------------------------------------------------------------ резервне копіювання

    # ---- налаштування додатка (ключ-значення) ----

    def get_setting(self, key: str, default: str = "") -> str:
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT value FROM app_settings WHERE key = ?", (key,)
                ).fetchone()
            return row["value"] if row else default
        except sqlite3.OperationalError:
            return default

    def set_setting(self, key: str, value: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO app_settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value or ""),
            )

    # ── Клички приплоду (автогенерація за літерою матері) ────────────────
    def get_calf_names(self) -> dict[str, list]:
        try:
            d = json.loads(self.get_setting("herd_calf_names") or "{}")
        except Exception:  # noqa: BLE001
            d = {}
        return {
            "F": [str(x).strip() for x in (d.get("F") or []) if str(x).strip()],
            "M": [str(x).strip() for x in (d.get("M") or []) if str(x).strip()],
        }

    def set_calf_names(self, f_list, m_list) -> None:
        self.set_setting("herd_calf_names", json.dumps({
            "F": [str(x).strip() for x in (f_list or []) if str(x).strip()],
            "M": [str(x).strip() for x in (m_list or []) if str(x).strip()],
        }, ensure_ascii=False))

    def _next_calf_name(self, dam_name: str, sex: str, taken=None) -> str:
        """Кличка теляти за літерою матері: перша невикористана кличка зі списку
        відповідної статі, що починається з тієї ж літери; інакше — будь-яка вільна."""
        names = self.get_calf_names().get("M" if str(sex).upper() == "M" else "F", [])
        if not names:
            return ""
        letter = ""
        for ch in (dam_name or ""):
            if ch.isalpha():
                letter = ch.upper()
                break
        used = set(taken or [])
        try:
            with self._connect() as conn:
                for r in conn.execute(
                        "SELECT name FROM herd_animals WHERE name<>''").fetchall():
                    used.add((r["name"] or "").strip())
        except Exception:  # noqa: BLE001
            pass

        def _pick(pool):
            for nm in pool:
                if nm not in used:
                    return nm
            return ""
        same = [n for n in names if letter and n[:1].upper() == letter]
        return _pick(same) or _pick(names)

    # ── Фінанси: довідник статей витрат/доходів ──────────────────────────
    def list_finance_items(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(
                "SELECT id,name,kind,sort_order,is_active FROM finance_items "
                "ORDER BY sort_order, id").fetchall()]

    def add_finance_item(self, name: str, kind: str = "expense") -> dict[str, Any]:
        name = (name or "").strip()
        if not name:
            raise ValueError("Вкажіть назву статті.")
        kind = "income" if str(kind) == "income" else "expense"
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id FROM finance_items WHERE lower(name)=lower(?) AND kind=?",
                (name, kind)).fetchone()
            if row:
                return {"id": int(row["id"])}
            nxt = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0)+1 FROM finance_items").fetchone()[0]
            cur = conn.execute(
                "INSERT INTO finance_items (name,kind,sort_order,is_active,created_at) "
                "VALUES (?,?,?,1,?)", (name, kind, nxt, self._now()))
            return {"id": int(cur.lastrowid)}

    def update_finance_item(self, item_id: int, data: dict) -> dict[str, Any]:
        fields = {}
        if "name" in data:
            fields["name"] = (data.get("name") or "").strip()
        if "kind" in data:
            fields["kind"] = "income" if str(data.get("kind")) == "income" else "expense"
        if "is_active" in data:
            fields["is_active"] = 1 if data.get("is_active") else 0
        if not fields:
            return {"id": int(item_id)}
        sets = ", ".join(f"{k}=?" for k in fields)
        with self._connect() as conn:
            conn.execute(f"UPDATE finance_items SET {sets} WHERE id=?",
                         (*fields.values(), int(item_id)))
        return {"id": int(item_id)}

    def delete_finance_item(self, item_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            conn.execute("DELETE FROM finance_items WHERE id=?", (int(item_id),))
        return {"deleted": int(item_id)}

    def reorder_finance_items(self, order: list) -> dict[str, Any]:
        with self._connect() as conn:
            for i, iid in enumerate(order or []):
                conn.execute("UPDATE finance_items SET sort_order=? WHERE id=?",
                             (i, int(iid)))
        return {"ok": True}

    @staticmethod
    def _fin_first_col(metrics: list) -> str:
        """Перша реальна колонка Excel серед показників (для сумісності amount_col)."""
        for m in metrics or []:
            if not isinstance(m, dict):
                continue
            for k in ("cols", "col", "num_cols", "num_col", "den_cols", "den_col"):
                v = m.get(k)
                if isinstance(v, list):
                    for c in v:
                        if (c or "").strip():
                            return c.strip()
                elif (v or "").strip():
                    return v.strip()
        return ""

    def get_finance_source(self, item_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            r = conn.execute(
                "SELECT path,sheet,header_row,date_col,amount_col,metrics_json,pivot_json,spread "
                "FROM finance_sources WHERE item_id=?", (int(item_id),)).fetchone()
        if not r:
            return {"path": "", "sheet": "", "header_row": 1, "date_col": "",
                    "amount_col": "", "metrics": [], "pivot": {}, "spread": 0}
        d = dict(r)
        try:
            mets = json.loads(d.pop("metrics_json", "") or "[]")
        except Exception:  # noqa: BLE001
            mets = []
        if not isinstance(mets, list):
            mets = []
        mets = [m for m in mets if isinstance(m, dict)]
        try:
            piv = json.loads(d.pop("pivot_json", "") or "{}")
        except Exception:  # noqa: BLE001
            piv = {}
        if not isinstance(piv, dict):
            piv = {}
        if isinstance(piv.get("dims"), list):
            piv["dims"] = [str(x).strip() for x in piv["dims"] if str(x).strip()]
        has_pivot = bool((piv.get("value_col") or "").strip() and piv.get("dims"))
        # сумісність зі старим форматом (лише amount_col) — один показник «Сума»,
        # але НЕ коли ввімкнена авто-розбивка (там сума йде з pivot)
        if not mets and not has_pivot and (d.get("amount_col") or "").strip():
            mets = [{"key": "amount", "label": "Сума", "unit": "₴",
                     "type": "money", "agg": "sum", "cols": [d["amount_col"].strip()]}]
        d["metrics"] = mets
        d["pivot"] = piv
        d.pop("pivot_json", None)
        return d

    def set_finance_source(self, item_id: int, data: dict) -> dict[str, Any]:
        # показники — у форматі молока (list dict з key/label/unit/type/agg/cols…)
        mets = data.get("metrics")
        mets = [m for m in mets if isinstance(m, dict) and (m.get("label") or "").strip()] \
            if isinstance(mets, list) else []
        first_col = self._fin_first_col(mets)
        if not first_col and (data.get("amount_col") or "").strip():
            first_col = (data.get("amount_col") or "").strip()
        # авто-розбивка: {value_col, unit, type, dims:[...]}
        piv = data.get("pivot") if isinstance(data.get("pivot"), dict) else {}
        pivot = {}
        vcol = (piv.get("value_col") or "").strip()
        dims = [str(x).strip() for x in (piv.get("dims") or []) if str(x).strip()]
        if vcol and dims:
            pivot = {"value_col": vcol, "unit": (piv.get("unit") or "₴").strip(),
                     "type": (piv.get("type") or "money").strip(), "dims": dims}
        if not first_col and vcol:
            first_col = vcol
        spread = 1 if data.get("spread") else 0
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO finance_sources (item_id,path,sheet,header_row,"
                "date_col,amount_col,metrics_json,pivot_json,spread) VALUES (?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(item_id) DO UPDATE SET path=excluded.path, "
                "sheet=excluded.sheet, header_row=excluded.header_row, "
                "date_col=excluded.date_col, amount_col=excluded.amount_col, "
                "metrics_json=excluded.metrics_json, pivot_json=excluded.pivot_json, "
                "spread=excluded.spread",
                (int(item_id), (data.get("path") or "").strip(),
                 (data.get("sheet") or "").strip(),
                 int(self._to_float(data.get("header_row"), 1)) or 1,
                 (data.get("date_col") or "").strip(),
                 first_col, json.dumps(mets, ensure_ascii=False),
                 json.dumps(pivot, ensure_ascii=False), spread))
        return {"ok": True}

    def set_finance_rows(self, item_id: int, rows: list) -> int:
        """Зафіксувати рядки статті в БД (перезаписати). rows=[{date, cells:{col:val}}].
        Зберігаємо ВСІ колонки рядка (зокрема resource/category) → розбивка з БД."""
        with self._connect() as conn:
            conn.execute("DELETE FROM finance_rows WHERE item_id=?", (int(item_id),))
            conn.executemany(
                "INSERT INTO finance_rows (item_id,op_date,cells_json) VALUES (?,?,?)",
                [(int(item_id), (r.get("date") or "")[:10],
                  json.dumps(r.get("cells") or {}, ensure_ascii=False, default=str))
                 for r in rows])
        return len(rows)

    def get_finance_rows(self, item_id: int) -> list:
        """Зафіксовані рядки статті: [{op_date, cells:{col:val}}]."""
        with self._connect() as conn:
            rr = conn.execute(
                "SELECT op_date,cells_json FROM finance_rows WHERE item_id=? ORDER BY op_date",
                (int(item_id),)).fetchall()
        out = []
        for r in rr:
            try:
                cells = json.loads(r["cells_json"] or "{}")
            except Exception:  # noqa: BLE001
                cells = {}
            out.append({"op_date": r["op_date"], "cells": cells})
        return out

    # ── Синхронізація на сервер аналітики (ingest) ───────────────────────
    def build_ingest_snapshot(self) -> dict[str, Any]:
        """Знімок усіх таблиць БД для відправки на сервер аналітики.
        {table: {columns:[...], rows:[[...],...]}}. blob→None (у нас їх немає)."""
        # не відправляємо конфіг/секрети та службові таблиці — лише робочі дані:
        #   app_settings/app_meta — токени, ліцензія, налаштування;
        #   users та user_* — логіни й хеші паролів;
        #   sync_* — службова синхронізація пристроїв;
        #   audit_log — журнал дій; recipients — адресати сповіщень.
        skip = {
            "app_settings", "app_meta",
            "users", "user_blocks", "user_branches", "user_offline_branches",
            "sync_devices", "sync_ops", "audit_log", "recipients",
        }
        out: dict[str, Any] = {}
        with self._connect() as conn:
            tabs = [r["name"] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' "
                "AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
            for t in tabs:
                if t in skip:
                    continue
                cols = [r["name"] for r in conn.execute(
                    f'PRAGMA table_info("{t}")').fetchall()]
                rows = []
                for r in conn.execute(f'SELECT * FROM "{t}"').fetchall():
                    rows.append([(None if isinstance(v, (bytes, bytearray)) else v)
                                 for v in tuple(r)])
                out[t] = {"columns": cols, "rows": rows}
        return out

    def push_ingest(self, url: str = "", token: str = "", client_id: str = "",
                    app_version: str = "", force: bool = False) -> tuple[bool, str]:
        """Надіслати знімок БД на сервер аналітики.

        Протокол сервера (`/api/ingest`, lib/ingest.js): окремий POST на кожну
        таблицю у форматі {"table":…, "key":"id", "rows":[{…}]}, звичайний JSON,
        заголовок X-Ingest-Token. Схему клієнта визначає токен. Upsert по ключу
        `id` ідемпотентний — повторна відправка того самого рядка не дублює.

        Синхронізуються лише таблиці, що ЗМІНИЛИСЬ від останнього успішного
        надсилання (порівняння за хешем). force=True — надіслати всі.
        Порожні аргументи беруться з налаштувань app_settings.
        """
        import urllib.request, urllib.error, ssl, hashlib
        url = (url or self.get_setting("ingest_url", "")).strip()
        token = (token or self.get_setting("ingest_token", "")).strip()
        client_id = (client_id or self.get_setting("ingest_client_id", "")).strip()
        if not url or not token:
            return False, "Не вказано адресу сервера або токен"
        if not client_id:
            return False, "Вкажіть ідентифікатор ферми (обовʼязково — різні клієнти)"

        snap = self.build_ingest_snapshot()
        BATCH = 2000            # рядків в одному запиті (нижче серверного ліміту 5000)
        headers = {
            "Content-Type": "application/json",
            "X-Ingest-Token": token, "User-Agent": "FarmApp-ingest",
        }

        def _post(ctx, table, key, rows):
            nonlocal sent_bytes
            data = json.dumps({"table": table, "key": key, "rows": rows},
                              ensure_ascii=False).encode("utf-8")
            sent_bytes += len(data)
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=60, context=ctx) as resp:
                return resp.read().decode("utf-8", "replace")[:300]

        # SSL: спершу з перевіркою; при помилці сертифіката переходимо на
        # неперевірений контекст і далі шлемо ним (як було в старій версії).
        ctx = ssl.create_default_context()
        unverified = False
        sent_tables = sent_rows = sent_bytes = 0
        skipped: list[str] = []
        # потаблична детекція змін: хеш вмісту від останнього успіху
        try:
            old_hashes = json.loads(self.get_setting("ingest_table_hashes", "") or "{}")
            if not isinstance(old_hashes, dict):
                old_hashes = {}
        except Exception:  # noqa: BLE001
            old_hashes = {}
        new_hashes = dict(old_hashes)
        unchanged = 0

        def _send(table, key, rows):
            nonlocal ctx, unverified
            while True:
                try:
                    return _post(ctx, table, key, rows)
                except urllib.error.HTTPError:
                    raise                      # 4xx/5xx — обробляємо зовні
                except urllib.error.URLError as exc:
                    reason = getattr(exc, "reason", None)
                    if not unverified and (isinstance(reason, ssl.SSLError)
                            or "CERTIFICATE_VERIFY" in str(reason).upper()):
                        ctx = ssl._create_unverified_context()
                        unverified = True
                        continue
                    raise

        def _send_prune(table, key, keys):
            """Надіслати серверу ПОВНИЙ перелік наявних ключів таблиці, щоб він
            видалив рядки, яких уже немає (обробка видалень; порожній перелік →
            видалити всі рядки таблиці). Best-effort: якщо сервер ще не підтримує
            prune, помилку глушить викликач — поточна синхронізація не ламається."""
            data = json.dumps({"table": table, "key": key, "keys": keys,
                               "prune": True}, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers=headers,
                                         method="POST")
            with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
                return resp.read().decode("utf-8", "replace")[:300]

        # Ключ для сервера: типово 'id'. Для таблиць з іншим одноколонковим
        # ключем — його назва; для таблиць зі складеним ключем — кортеж колонок,
        # з якого будуємо стабільний синтетичний 'sync_key' (склейка через SEP).
        KEYS = {
            "branch_livestock": "category",
            "feed_map": "profeed_code",
            "herd_counts": ("group_id", "year", "month"),
            "herd_move_counts": ("type_id", "year", "month"),
            "herd_param_values": ("animal_id", "param_id"),
            "feeding_milk": ("section", "day"),
            "milk_daily": "day",
            "milk_sales_daily": "day",
            "milk_yield_shifts": ("day", "shift"),
            "herd_daily": ("day", "grp"),
            "feeding_leftover": ("section", "day"),
            "feeding_pool_dest": ("day", "dest"),
            "feeding_leftover_dest": ("section", "day", "dest"),
            "finance_sources": "item_id",     # ключ статті — item_id, не id
        }
        SEP = "\x1f"                 # роздільник частин складеного ключа

        try:
            for table, blk in snap.items():
                cols = blk["columns"]
                spec = KEYS.get(table, "id")
                rows = [dict(zip(cols, r)) for r in blk["rows"]]
                # хеш вмісту таблиці — щоб слати лише за наявності змін.
                # (рахуємо і для ПОРОЖНІХ таблиць — щоб зловити видалення всіх
                #  рядків і надіслати серверу порожній prune-перелік)
                thash = hashlib.sha256(json.dumps(
                    [cols, blk["rows"]], ensure_ascii=False, default=str,
                    sort_keys=True).encode("utf-8")).hexdigest()
                if not force and old_hashes.get(table) == thash:
                    unchanged += 1
                    continue
                if isinstance(spec, tuple):    # складений ключ → синтетичний sync_key
                    if not all(c in cols for c in spec):
                        skipped.append(table)
                        continue
                    key = "sync_key"
                    for r in rows:
                        r[key] = SEP.join(
                            "" if r.get(c) is None else str(r.get(c)) for c in spec)
                else:                          # одноколонковий ключ ('id' або інший)
                    key = spec
                    if key not in cols:
                        skipped.append(table)
                        continue
                for i in range(0, len(rows), BATCH):
                    chunk = rows[i:i + BATCH]
                    txt = _send(table, key, chunk)
                    try:
                        resp = json.loads(txt)
                    except ValueError:
                        resp = {}
                    if isinstance(resp, dict) and resp.get("error"):
                        raise RuntimeError(f"{table}: {resp['error']}")
                    sent_rows += (resp.get("written") if isinstance(resp, dict)
                                  else None) or len(chunk)
                # ОБРОБКА ВИДАЛЕНЬ: після upsert шлемо повний перелік ключів, що
                # лишились, — сервер видаляє все інше (і всі рядки, якщо таблиця
                # спорожніла). Best-effort: старий сервер без prune → ігноруємо.
                try:
                    _send_prune(table, key, [r.get(key) for r in rows])
                except Exception:  # noqa: BLE001
                    pass
                sent_tables += 1
                new_hashes[table] = thash
            def _hsize(n):
                for unit in ("Б", "КБ", "МБ", "ГБ"):
                    if n < 1024 or unit == "ГБ":
                        return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
                    n /= 1024
                return f"{n:.1f} ГБ"
            ok = True
            if sent_tables == 0:
                msg = "Змін немає — не надсилалось"
            else:
                msg = f"{sent_tables} табл., {sent_rows} рядків, {_hsize(sent_bytes)}"
                if unchanged:
                    msg += f" (без змін: {unchanged})"
            if skipped:
                msg += f"; пропущено без id: {', '.join(skipped)}"
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "replace")[:300]
            except Exception:  # noqa: BLE001
                pass
            ok, msg = False, f"HTTP {exc.code}: {exc.reason} {detail}".strip()
        except Exception as exc:  # noqa: BLE001
            ok, msg = False, str(exc)

        # запис результату
        now = self._now()
        self.set_setting("ingest_last_at", now)
        self.set_setting("ingest_last_result",
                         ("OK · " if ok else "Помилка · ") + msg)
        if ok:                                # оновлюємо хеші лише при успіху
            self.set_setting("ingest_table_hashes",
                             json.dumps(new_hashes, ensure_ascii=False))
        # історія синхронізацій — останні 15 записів
        try:
            hist = json.loads(self.get_setting("ingest_history", "") or "[]")
            if not isinstance(hist, list):
                hist = []
        except Exception:  # noqa: BLE001
            hist = []
        hist.insert(0, {"at": now, "ok": ok, "msg": msg})
        self.set_setting("ingest_history", json.dumps(hist[:15], ensure_ascii=False))
        summary = f"{'Надіслано' if ok else 'Не вдалось'}: {msg}"
        return ok, summary

    def default_backup_dir(self) -> Path:
        return APP_DATA_DIR / "backups"

    def backup_dir(self) -> Path:
        # Пріоритет: змінна середовища > збережене налаштування > типове.
        env = os.environ.get("VET_BACKUP_DIR")
        if env:
            return Path(env)
        saved = self.get_setting("backup_dir", "")
        if saved.strip():
            return Path(saved.strip())
        return self.default_backup_dir()

    def backup_dir_is_locked(self) -> bool:
        """True, якщо шлях задано змінною середовища (з UI не змінити)."""
        return bool(os.environ.get("VET_BACKUP_DIR"))

    # ---- аналітика для Power BI (експорт CSV) ----

    def default_analytics_dir(self) -> Path:
        return APP_DATA_DIR / "analytics"

    def analytics_dir(self) -> Path:
        env = os.environ.get("VET_ANALYTICS_DIR")
        if env:
            return Path(env)
        saved = self.get_setting("analytics_dir", "")
        if saved.strip():
            return Path(saved.strip())
        return self.default_analytics_dir()

    _BRANCH_LABEL = {"pharmacy": "Аптека", "materials": "Матеріали", "feed": "Корми"}
    _HERD_LABEL = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}
    _MOVE_LABEL = {"IN": "Прихід", "OUT": "Видача",
                   "WRITE_OFF": "Списання", "RETURN": "Повернення"}

    # Українські назви колонок для кожної таблиці експорту (для Power BI).
    _UK_NAMES = {
        "fact_moves": {
            "move_id": "№ руху", "datetime": "Дата і час", "date": "Дата",
            "move_type": "Тип (код)", "move_label": "Тип",
            "product_id": "ID товару", "product_name": "Товар", "barcode": "Штрихкод",
            "category": "Гілка (код)", "branch": "Гілка",
            "qty": "Кількість", "qty_signed": "Кількість (зі знаком)",
            "price": "Ціна", "total": "Сума", "total_signed": "Сума (зі знаком)",
            "batch_id": "ID партії", "lot": "Партія", "expires_on": "Термін придатності",
            "block_id": "ID блоку", "block_name": "Блок",
            "recipient_id": "ID отримувача", "recipient_name": "Отримувач",
            "supplier_id": "ID постачальника", "supplier_name": "Постачальник",
            "invoice_number": "Накладна", "sale_no": "№ операції",
            "user_id": "ID користувача", "user_login": "Користувач", "note": "Примітка",
        },
        "dim_products": {
            "product_id": "ID товару", "name": "Назва", "barcode": "Штрихкод",
            "code": "Код", "unit": "Одиниця", "category": "Гілка (код)",
            "branch": "Гілка", "min_stock": "Мін. залишок", "supplier": "Постачальник",
        },
        "dim_blocks": {"id": "ID", "name": "Назва", "category": "Гілка (код)", "branch": "Гілка"},
        "dim_recipients": {"id": "ID", "name": "Назва", "category": "Гілка (код)", "branch": "Гілка"},
        "dim_suppliers": {"id": "ID", "name": "Назва", "category": "Гілка (код)", "branch": "Гілка"},
        "dim_batches": {
            "batch_id": "ID партії", "product_id": "ID товару", "category": "Гілка (код)",
            "lot": "Партія", "expires_on": "Термін придатності", "receipt_date": "Дата приходу",
            "qty_remaining": "Залишок партії", "price_in": "Ціна з ПДВ",
            "price_in_no_vat": "Ціна без ПДВ", "vat_rate": "Ставка ПДВ, %",
            "invoice_number": "Накладна", "supplier_id": "ID постачальника",
        },
        "stock_current": {
            "product_id": "ID товару", "name": "Назва", "barcode": "Штрихкод",
            "category": "Гілка (код)", "branch": "Гілка", "unit": "Одиниця",
            "min_stock": "Мін. залишок", "qty_on_hand": "Залишок",
            "value_no_vat": "Вартість без ПДВ", "value_with_vat": "Вартість з ПДВ",
            "below_min": "Нижче мінімуму",
        },
        "meta": {"key": "Ключ", "value": "Значення"},
    }

    _SALE_PREFIX = {"OUT": "ВВ-", "WRITE_OFF": "ВС-", "RETURN": "ПВ-"}

    @staticmethod
    def _derive_prices(price_no_vat, price_with_vat, vat_rate):
        """Узгоджені ціни без/з ПДВ: якщо одну не задано — рахуємо за ставкою."""
        pnv = float(price_no_vat or 0)
        pv = float(price_with_vat or 0)
        vat = float(vat_rate or 0)
        if not pnv and pv:
            pnv = round(pv / (1 + vat / 100), 4) if vat else pv
        if not pv and pnv:
            pv = round(pnv * (1 + vat / 100), 4) if vat else pnv
        return pnv, pv

    @classmethod
    def _sale_no_label(cls, sale_no, move_type) -> str:
        s = str(sale_no or "").strip()
        if not s:
            return ""
        return cls._SALE_PREFIX.get(move_type, "") + s

    @staticmethod
    def _write_csv(path: Path, header: list, rows: list) -> None:
        # Для Power BI/Excel (укр. локаль): роздільник колонок — ';',
        # десятковий роздільник у числах — кома. UTF-8 з BOM для кирилиці.
        def cell(v):
            if isinstance(v, bool):
                return "так" if v else ""
            if isinstance(v, float):
                if v == int(v):
                    return str(int(v))
                return ("%.4f" % v).rstrip("0").rstrip(".").replace(".", ",")
            if isinstance(v, int):
                return str(v)
            return "" if v is None else str(v)
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(header)
            for row in rows:
                w.writerow([cell(c) for c in row])

    def _export_feeding_csv(self, d: Path, counts: dict) -> None:
        """ОДИН CSV годівлі для Power BI — відтворює сторінку «Рух годівлі по
        секціях». Грань: (Дата × Секція × Корм). Показники по кормах (план/факт/
        суха/сума) сумуються по будь-якому зрізу. Денні показники секції (голів,
        роздано, залишок, спожито, молоко) кладемо ЛИШЕ в перший рядок корму дня,
        решта — 0, щоб SUM не подвоював. Категорія/Підкатегорія — з довідника
        секцій стада (домінантна на дату), щоб будувати зрізи Корови/Молодняк."""
        KIND = {"cow": "Корови", "young": "Молодняк"}
        by_label: dict[str, list] = {}
        for s in self.list_herd_sections():
            s_lbl = (s.get("profeed_group") or "").strip()
            for p in (s.get("periods") or []):
                lbl = (p.get("profeed_group") or "").strip() or s_lbl
                if lbl:
                    by_label.setdefault(lbl, []).append(p)

        def cat_sub(label, day):
            best, best_w = None, -1.0
            for p in by_label.get(label, []):
                df = (p.get("date_from") or "")[:10]
                dt = (p.get("date_to") or "")[:10]
                if (df and day < df) or (dt and day > dt):
                    continue
                h = max(0.0, self._to_float(p.get("headcount"), 0))
                c = self._to_float(p.get("eat_coef"), 1) or 1.0
                w = (h * c) if h > 0 else c
                if w > best_w:
                    best_w = w
                    best = (KIND.get(p.get("herd_kind") or "", "") or "Без категорії",
                            (p.get("subgroup") or "").strip() or "—")
            return best or ("Без категорії", "—")

        tree = self.feeding_tree("feed", "", "")
        rows = []
        for s in (tree.get("sections") or []):
            for dy in (s.get("days") or []):
                sec, day = dy.get("section", ""), dy.get("date", "")
                cat, sub = cat_sub(sec, day)
                ings = dy.get("ingredients") or []
                for i, it in enumerate(ings):
                    first = (i == 0)   # денні показники — лише в перший рядок дня
                    rows.append([
                        day, sec, cat, sub, it.get("name", ""), it.get("code", ""),
                        # по кормах (сумуються скрізь)
                        it.get("plan", 0), it.get("kg", 0), it.get("dry", 0),
                        it.get("sum") or 0,
                        # денні показники секції (лише перший рядок; далі 0)
                        dy.get("heads", 0) if first else 0,
                        dy.get("plan_distributed", 0) if first else 0,
                        dy.get("distributed", 0) if first else 0,
                        dy.get("leftover", 0) if first else 0,
                        dy.get("refed_in", 0) if first else 0,
                        dy.get("consumed", 0) if first else 0,
                        dy.get("dry_consumed", 0) if first else 0,
                        (dy.get("milk") or 0) if first else 0,
                        dy.get("ration", "") if first else "",
                    ])
        self._write_csv(d / "korma_rukh.csv",
            ["Дата", "Секція", "Категорія", "Підкатегорія", "Корм", "Код",
             "План кг", "Факт кг", "Суха кг", "Сума ₴",
             "Голів", "План роздачі", "Роздано", "Залишок ЗМР", "Отримано з пулу",
             "Спожито", "Суха спожито", "Молоко, кг", "Раціон"], rows)
        counts["korma_rukh"] = len(rows)

    def export_analytics(self, dest_dir: Optional[Path] = None) -> dict[str, Any]:
        """Готові звіти CSV для Power BI/Excel (укр. заголовки):
        1_sklad, 2_nadhodzhennya, 3_vydacha_spysannia — аптека + матеріали;
        1_sklad_kormy, 2_nadhodzhennya_kormy, 3_vydacha_kormy — ОКРЕМО корми.
        Старі/дубльовані файли в папці прибираються автоматично."""
        d = Path(dest_dir) if dest_dir else self.analytics_dir()
        d.mkdir(parents=True, exist_ok=True)
        counts = {}
        with self._connect() as conn:
            # ---- залишки на складі (для звіту 1) ----
            stock = conn.execute(
                """SELECT p.name, p.barcode, p.category, p.unit, p.min_stock,
                          COALESCE(SUM(b.qty), 0) AS qty_on_hand,
                          COALESCE(SUM(b.qty * b.price_in), 0) AS value_with_vat,
                          COALESCE(SUM(b.qty * b.price_in_no_vat), 0) AS value_no_vat
                   FROM products p LEFT JOIN stock_batches b ON b.product_id = p.id
                   WHERE p.is_active = 1 GROUP BY p.id ORDER BY p.name COLLATE NOCASE"""
            ).fetchall()

            # 1) Склад із залишками та сумами з/без ПДВ (вода — залишок 0).
            # Корми вигружаємо ОКРЕМО від аптеки/матеріалів (файли з «_kormy»).
            sklad_rows, sklad_feed = [], []
            for s in stock:
                water = self._is_water(s["name"])
                qty = 0.0 if water else float(s["qty_on_hand"] or 0)
                v_nv = 0.0 if water else round(float(s["value_no_vat"] or 0), 2)
                v_v = 0.0 if water else round(float(s["value_with_vat"] or 0), 2)
                mn = float(s["min_stock"] or 0)
                row = [self._BRANCH_LABEL.get(s["category"], s["category"]),
                       s["name"], s["barcode"], s["unit"], qty, v_nv, v_v, mn,
                       "" if water else ("так" if qty <= mn else "")]
                (sklad_feed if s["category"] == "feed" else sklad_rows).append(row)
            sklad_hdr = ["Гілка", "Товар", "Штрихкод", "Одиниця", "Залишок",
                         "Сума залишку без ПДВ", "Сума залишку з ПДВ",
                         "Мін. залишок", "Нижче мінімуму"]
            self._write_csv(d / "1_sklad.csv", sklad_hdr, sklad_rows)
            self._write_csv(d / "1_sklad_kormy.csv", sklad_hdr, sklad_feed)
            counts["1_sklad"] = len(sklad_rows)
            counts["1_sklad_kormy"] = len(sklad_feed)

            # 2) Усі надходження (прихід)
            ins = conn.execute(
                """SELECT m.created_at, b.invoice_number, b.invoice_date,
                          sup.name AS supplier, p.category, p.name, p.barcode, p.unit,
                          b.lot_number, b.expires_on, m.qty,
                          b.price_in_no_vat, b.price_in, b.vat_rate, u.username
                   FROM stock_moves m
                   JOIN products p ON p.id = m.product_id
                   LEFT JOIN stock_batches b ON b.id = m.batch_id
                   LEFT JOIN suppliers sup ON sup.id = b.supplier_id
                   LEFT JOIN users u ON u.id = m.user_id
                   WHERE m.move_type = 'IN'
                     AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%')
                   ORDER BY m.created_at, m.id"""
            ).fetchall()
            in_rows, in_feed = [], []
            for r in ins:
                if self._is_water(r["name"]):
                    continue                   # вода необмежена — прихід не показуємо
                qty = float(r["qty"] or 0)
                pnv, pv = self._derive_prices(r["price_in_no_vat"], r["price_in"], r["vat_rate"])
                row = [
                    r["created_at"], (r["created_at"] or "")[:10],
                    r["invoice_number"] or "", r["invoice_date"] or "",
                    r["supplier"] or "", self._BRANCH_LABEL.get(r["category"], r["category"]),
                    r["name"], r["barcode"], r["unit"],
                    r["lot_number"] or "", r["expires_on"] or "", qty,
                    pnv, pv, round(qty * pnv, 2), round(qty * pv, 2),
                    float(r["vat_rate"] or 0), r["username"] or "",
                ]
                (in_feed if r["category"] == "feed" else in_rows).append(row)
            in_hdr = ["Дата і час", "Дата", "Накладна", "Дата накладної", "Постачальник",
                      "Гілка", "Товар", "Штрихкод", "Одиниця", "Партія", "Термін",
                      "Кількість", "Ціна без ПДВ", "Ціна з ПДВ",
                      "Сума без ПДВ", "Сума з ПДВ", "ПДВ, %", "Користувач"]
            self._write_csv(d / "2_nadhodzhennya.csv", in_hdr, in_rows)
            self._write_csv(d / "2_nadhodzhennya_kormy.csv", in_hdr, in_feed)
            counts["2_nadhodzhennya"] = len(in_rows)
            counts["2_nadhodzhennya_kormy"] = len(in_feed)

            # 3) Уся видача та списання
            outs = conn.execute(
                """SELECT m.created_at, m.sale_no, m.move_type, p.category, p.name,
                          p.barcode, p.unit, m.qty, bl.name AS block,
                          bl.herd_kind AS herd_kind, rc.name AS recipient,
                          b.price_in_no_vat, b.price_in, b.vat_rate, m.total, m.note, u.username
                   FROM stock_moves m
                   JOIN products p ON p.id = m.product_id
                   LEFT JOIN stock_batches b ON b.id = m.batch_id
                   LEFT JOIN blocks bl ON bl.id = m.block_id
                   LEFT JOIN recipients rc ON rc.id = m.recipient_id
                   LEFT JOIN users u ON u.id = m.user_id
                   WHERE m.move_type IN ('OUT', 'WRITE_OFF')
                   ORDER BY m.created_at, m.id"""
            ).fetchall()
            out_rows, out_feed = [], []
            for r in outs:
                qty = float(r["qty"] or 0)
                pnv, pv = self._derive_prices(r["price_in_no_vat"], r["price_in"], r["vat_rate"])
                herd = self._HERD_LABEL.get(r["herd_kind"], "")
                note = r["note"] or ""
                nl = note.lower()
                if r["move_type"] == "OUT":
                    purpose = "Видача"
                elif nl.startswith("годівля"):
                    purpose = "Годівля"
                elif "підстилка" in nl:
                    purpose = "Підстилка"
                else:
                    purpose = "Списання"
                row = [
                    r["created_at"], (r["created_at"] or "")[:10],
                    self._sale_no_label(r["sale_no"], r["move_type"]),
                    self._MOVE_LABEL.get(r["move_type"], r["move_type"]), purpose,
                    self._BRANCH_LABEL.get(r["category"], r["category"]),
                    r["name"], r["barcode"], r["unit"], qty,
                    r["block"] or "", herd, r["recipient"] or "",
                    pnv, pv, round(qty * pnv, 2), round(qty * pv, 2),
                    float(r["vat_rate"] or 0), r["username"] or "", note,
                ]
                (out_feed if r["category"] == "feed" else out_rows).append(row)
            out_hdr = ["Дата і час", "Дата", "№ операції", "Тип", "Призначення", "Гілка", "Товар",
                       "Штрихкод", "Одиниця", "Кількість", "Блок", "Група стада", "Кому",
                       "Ціна без ПДВ", "Ціна з ПДВ", "Сума без ПДВ", "Сума з ПДВ",
                       "ПДВ, %", "Користувач", "Примітка"]
            self._write_csv(d / "3_vydacha_spysannia.csv", out_hdr, out_rows)
            self._write_csv(d / "3_vydacha_kormy.csv", out_hdr, out_feed)
            counts["3_vydacha_spysannia"] = len(out_rows)
            counts["3_vydacha_kormy"] = len(out_feed)

        # ---- Годівля: ОДИН звіт korma_rukh.csv для відтворення сторінки «Рух
        # годівлі по секціях» у Power BI (грань Дата×Секція×Корм; числа з тих
        # самих функцій, що й сторінка).
        try:
            self._export_feeding_csv(d, counts)
        except Exception:  # noqa: BLE001
            pass                                    # годівля не має ламати експорт

        # Прибрати застарілі/дубльовані вигрузки попередніх версій.
        for old in ("fact_moves.csv", "dim_products.csv", "dim_blocks.csv",
                    "dim_recipients.csv", "dim_suppliers.csv", "dim_batches.csv",
                    "stock_current.csv", "dictionary_uk.csv", "meta.csv",
                    "README_PowerBI.txt",
                    "korma_sekcii_dni.csv", "korma_sekcii_korma.csv",
                    "korma_kategorii.csv"):
            try:
                (d / old).unlink()
            except OSError:
                pass

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.set_setting("analytics_last_export", now)
        return {"dir": str(d), "exported_at": now, "counts": counts}

    def _start_auto_analytics(self) -> None:
        """Фоновий експорт аналітики за таймером (якщо ввімкнено в налаштуваннях).
        Інтервал — analytics_interval_min (за замовч. 20 хв)."""
        import threading

        def _enabled() -> bool:
            return self.get_setting("analytics_enabled", "0") == "1"

        def _interval() -> float:
            try:
                return max(5.0, float(self.get_setting("analytics_interval_min", "20"))) * 60.0
            except ValueError:
                return 1200.0

        def loop():
            while True:
                try:
                    time.sleep(_interval())
                    if _enabled():
                        self.export_analytics()
                except Exception:  # noqa: BLE001
                    pass
        threading.Thread(target=loop, daemon=True, name="analytics-export").start()
        # одразу при старті, якщо ввімкнено
        try:
            if _enabled():
                self.export_analytics()
        except Exception:  # noqa: BLE001
            pass

    # ---- проактивні сповіщення (дайджест у Telegram) ----

    @staticmethod
    def _nfmt(v: Any) -> str:
        try:
            f = float(v)
            return str(int(f)) if f == int(f) else f"{f:g}"
        except (TypeError, ValueError):
            return str(v or "")

    @staticmethod
    def _ndate(iso: str) -> str:
        s = str(iso or "")
        return f"{s[8:10]}.{s[5:7]}.{s[0:4]}" if len(s) >= 10 else s

    _NOTIFY_BRANCHES = (("pharmacy", "Аптека"), ("materials", "Матеріали"))

    def _branch_daily_summary(self, category: str, day: str) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT "
                "COALESCE(SUM(CASE WHEN m.move_type='OUT' THEN m.total END),0) AS out_sum, "
                "SUM(CASE WHEN m.move_type='OUT' THEN 1 END) AS out_cnt, "
                "SUM(CASE WHEN m.move_type='IN'  THEN 1 END) AS in_cnt "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "WHERE substr(m.created_at,1,10)=? AND p.category=?",
                (day, category),
            ).fetchone()
        return dict(row)

    def build_notification_text(self, *, force_all: bool = False) -> str:
        """Сформувати текст дайджесту згідно з налаштуваннями змісту, з
        розбивкою по гілках (Аптека / Матеріали)."""
        g = self.get_setting
        inc_low  = force_all or g("notify_inc_low", "1") == "1"
        inc_exp  = force_all or g("notify_inc_expiring", "1") == "1"
        inc_expd = force_all or g("notify_inc_expired", "1") == "1"
        inc_day  = force_all or g("notify_inc_daily", "0") == "1"
        try:
            days = int(g("notify_expiry_days", "30"))
        except ValueError:
            days = 30

        # Обрані гілки (за замовчуванням — обидві)
        branches = [(c, lbl) for c, lbl in self._NOTIFY_BRANCHES
                    if force_all or g(f"notify_branch_{c}", "1") == "1"]
        if not branches:
            branches = list(self._NOTIFY_BRANCHES)

        lines = [f"📋 Дайджест складу · {date.today().strftime('%d.%m.%Y')}"]
        yday = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")

        for cat, label in branches:
            lines.append("")
            lines.append(f"━━━ {label} ━━━")

            if inc_low:
                low = [p for p in self.list_products(category=cat)
                       if p["total_qty"] <= p["min_stock"]]
                if low:
                    lines.append(f"⚠️ Низькі залишки ({len(low)}):")
                    for p in low[:20]:
                        lines.append(f"• {p['name']} — {self._nfmt(p['total_qty'])} "
                                     f"(мін {self._nfmt(p['min_stock'])})")
                    if len(low) > 20:
                        lines.append(f"…ще {len(low) - 20}")
                else:
                    lines.append("✅ Низьких залишків немає")

            if inc_exp or inc_expd:
                batches = self.expiring_batches(days, category=cat)
                expiring = [b for b in batches if not b["expired"]]
                expired  = [b for b in batches if b["expired"]]
                if inc_exp:
                    if expiring:
                        lines.append(f"⏳ Скоро прострочиться (≤{days} дн., {len(expiring)}):")
                        for b in expiring[:20]:
                            lines.append(f"• {b['name']} — до {self._ndate(b['expires_on'])} "
                                         f"({b['days_left']} дн., {self._nfmt(b['qty'])})")
                        if len(expiring) > 20:
                            lines.append(f"…ще {len(expiring) - 20}")
                    else:
                        lines.append(f"✅ Нічого не прострочиться у межах {days} дн.")
                if inc_expd:
                    if expired:
                        lines.append(f"❌ Прострочені ({len(expired)}):")
                        for b in expired[:20]:
                            lines.append(f"• {b['name']} — термін {self._ndate(b['expires_on'])} "
                                         f"({self._nfmt(b['qty'])})")
                        if len(expired) > 20:
                            lines.append(f"…ще {len(expired) - 20}")
                    else:
                        lines.append("✅ Прострочених немає")

            if inc_day:
                r = self._branch_daily_summary(cat, yday)
                lines.append(f"📊 За {self._ndate(yday)}: видач {int(r['out_cnt'] or 0)} "
                             f"на {self._nfmt(r['out_sum'] or 0)} ₴, "
                             f"надходжень {int(r['in_cnt'] or 0)}")

        return "\n".join(lines)

    def send_telegram(self, token: str, chat_id: str, text: str) -> tuple[bool, str]:
        """Надіслати повідомлення через Telegram Bot API (без сторонніх бібліотек).

        На багатьох ПК антивірус/корпоративний проксі підміняє TLS-сертифікат
        (self-signed у ланцюжку), і стандартна перевірка падає. Тому: спершу
        пробуємо звичайне захищене з'єднання; якщо помилка саме перевірки
        сертифіката — повторюємо без жорсткої перевірки (локальна машина)."""
        import urllib.request, urllib.parse, urllib.error, ssl
        token = (token or "").strip()
        chat_id = (chat_id or "").strip()
        if not token or not chat_id:
            return False, "Не вказано токен бота або chat_id"
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = urllib.parse.urlencode({
            "chat_id": chat_id, "text": text,
            "disable_web_page_preview": "true",
        }).encode()

        def _post(ctx) -> tuple[bool, str]:
            req = urllib.request.Request(url, data=data)
            with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
                body = json.loads(resp.read().decode())
            if body.get("ok"):
                return True, "OK"
            return False, str(body.get("description") or "Помилка Telegram")

        try:
            return _post(ssl.create_default_context())
        except urllib.error.HTTPError as exc:
            return False, f"HTTP {exc.code}: {exc.reason}"
        except urllib.error.URLError as exc:
            # Помилка перевірки TLS-сертифіката (антивірус/проксі підміняє
            # сертифікат) приходить загорнутою в URLError → повтор без перевірки.
            reason = getattr(exc, "reason", None)
            if isinstance(reason, ssl.SSLError) or "CERTIFICATE_VERIFY" in str(reason).upper():
                try:
                    return _post(ssl._create_unverified_context())
                except Exception as exc2:  # noqa: BLE001
                    return False, str(exc2)
            return False, str(exc)
        except ssl.SSLError:
            try:
                return _post(ssl._create_unverified_context())
            except Exception as exc:  # noqa: BLE001
                return False, str(exc)
        except Exception as exc:  # noqa: BLE001
            return False, str(exc)

    def send_digest_now(self, *, test: bool = False) -> tuple[bool, str]:
        """Зібрати дайджест і відправити у налаштований канал негайно."""
        text = self.build_notification_text()
        if test:
            text = "🔔 Тестове повідомлення\n\n" + text
        return self.send_telegram(
            self.get_setting("notify_tg_token", ""),
            self.get_setting("notify_tg_chat", ""),
            text,
        )

    def _start_auto_notify(self) -> None:
        """Фонова розсилка дайджесту раз на день о заданій годині (notify_time)."""
        import threading

        def loop():
            while True:
                try:
                    time.sleep(30)
                    if self.get_setting("notify_enabled", "0") != "1":
                        continue
                    target = self.get_setting("notify_time", "08:00")
                    now = datetime.now()
                    cur = now.strftime("%H:%M")
                    today = now.strftime("%Y-%m-%d")
                    # відправляємо при першому тіку о/після заданого часу за день
                    if cur >= target and self.get_setting("notify_last_sent", "") != today:
                        ok, _msg = self.send_digest_now()
                        if ok:
                            self.set_setting("notify_last_sent", today)
                except Exception:  # noqa: BLE001
                    pass
        threading.Thread(target=loop, daemon=True, name="auto-notify").start()

    def _start_auto_ingest(self) -> None:
        """Фонова синхронізація на сервер аналітики.

        Логіка «майже наживо»: монітор змін БД (PRAGMA data_version) будить пуш
        через DEBOUNCE секунд після останньої зміни; плюс періодичний фолбек
        кожні ingest_auto_min хв. Пуш шле лише таблиці, що змінились."""
        import threading

        DEBOUNCE = 30          # затримка після останньої зміни, с
        TICK = 5               # частота перевірки, с

        def loop():
            time.sleep(20)                     # дати застосунку піднятися
            mon = None                         # окреме зʼєднання для data_version
            last_ver = None
            dirty_since = None
            last_periodic = 0.0
            while True:
                try:
                    if mon is None:
                        mon = sqlite3.connect(str(self.db_path), timeout=5)
                    now = time.time()
                    auto = self.get_setting("ingest_auto", "0") == "1"
                    configured = (self.get_setting("ingest_url", "").strip()
                                  and self.get_setting("ingest_token", "").strip()
                                  and self.get_setting("ingest_client_id", "").strip())
                    # розклад: удень частіше, вночі рідше
                    day_from = self.get_setting("ingest_day_from", "06:00")
                    day_to = self.get_setting("ingest_day_to", "22:00")
                    try:
                        day_min = int(self._to_float(self.get_setting("ingest_day_min", "10"), 10))
                    except Exception:  # noqa: BLE001
                        day_min = 10
                    try:
                        night_min = int(self._to_float(self.get_setting("ingest_night_min", "60"), 60))
                    except Exception:  # noqa: BLE001
                        night_min = 60
                    cur_hm = datetime.now().strftime("%H:%M")
                    if day_from <= day_to:
                        is_day = day_from <= cur_hm < day_to
                    else:                      # вікно через північ
                        is_day = cur_hm >= day_from or cur_hm < day_to
                    interval = max(60, (day_min if is_day else night_min) * 60)
                    # виявлення зміни БД (зростає при комітах з інших зʼєднань)
                    try:
                        ver = mon.execute("PRAGMA data_version").fetchone()[0]
                    except Exception:  # noqa: BLE001
                        ver = None
                    if ver is not None:
                        if last_ver is None:
                            last_ver = ver
                        elif ver != last_ver:
                            last_ver = ver
                            dirty_since = now
                    # рішення надіслати: дебаунс після зміни або періодичний фолбек
                    do_push = False
                    if auto and configured:
                        # дебаунс «майже наживо» — лише вдень; вночі — раз на інтервал
                        if is_day and dirty_since and (now - dirty_since) >= DEBOUNCE:
                            do_push = True
                        elif (now - last_periodic) >= interval:
                            do_push = True
                    if do_push:
                        self.push_ingest()     # лише змінені таблиці
                        last_periodic = now
                        dirty_since = None
                        try:                   # поглинаємо власні записи (settings)
                            last_ver = mon.execute("PRAGMA data_version").fetchone()[0]
                        except Exception:  # noqa: BLE001
                            pass
                except Exception:  # noqa: BLE001
                    try:
                        if mon is not None:
                            mon.close()
                    except Exception:  # noqa: BLE001
                        pass
                    mon = None
                time.sleep(TICK)
        threading.Thread(target=loop, daemon=True, name="auto-ingest").start()

    # ---- версіонування та безпечне оновлення ----

    def _ensure_settings_table(self) -> None:
        """Гарантуємо наявність app_settings ще ДО міграцій (для версій)."""
        try:
            with self._connect() as conn:
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS app_settings ("
                    "key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '')")
        except sqlite3.OperationalError:
            pass

    def _append_upgrade_history(self, kind: str, frm: str, to: str) -> None:
        """Дописати запис в історію оновлень (JSON-список у app_settings)."""
        try:
            hist = self.get_upgrade_history()
            hist.append({
                "kind": kind,             # 'schema' | 'app'
                "from": frm, "to": to,
                "date": self._now(),
            })
            self.set_setting("upgrade_history", json.dumps(hist, ensure_ascii=False))
        except Exception:  # noqa: BLE001
            pass

    def get_upgrade_history(self) -> list[dict[str, Any]]:
        raw = self.get_setting("upgrade_history", "")
        if not raw:
            return []
        try:
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        except (ValueError, TypeError):
            return []

    def _pre_upgrade_backup(self) -> None:
        """ПЕРЕД міграцією: якщо версія схеми підвищується — робимо копію БД,
        щоб був відкат. Перший запуск (версії ще немає) — просто пропускаємо."""
        self._ensure_settings_table()
        stored = (self.get_setting("schema_version", "") or "").strip()
        if not stored:
            return                       # перша поява версіонування — без копії
        try:
            if int(stored) < SCHEMA_VERSION:
                try:
                    self.create_backup_file(prefix=f"pre_update_schema{stored}_to{SCHEMA_VERSION}")
                except Exception:  # noqa: BLE001
                    pass               # копія не критична — не блокуємо запуск
        except ValueError:
            pass

    def _finalize_schema_version(self) -> None:
        """ПІСЛЯ міграцій: фіксуємо поточну версію схеми й пишемо історію."""
        stored = (self.get_setting("schema_version", "") or "").strip()
        if stored != str(SCHEMA_VERSION):
            if stored:                   # це справжнє оновлення (не перший старт)
                self._append_upgrade_history("schema", stored, str(SCHEMA_VERSION))
            self.set_setting("schema_version", str(SCHEMA_VERSION))

    def record_app_version(self, app_version: str) -> None:
        """Зафіксувати версію коду. При зміні — лог в історію (структура вже
        захищена копією за schema_version)."""
        app_version = (app_version or "").strip()
        if not app_version:
            return
        stored = (self.get_setting("app_version", "") or "").strip()
        if stored != app_version:
            if stored:
                self._append_upgrade_history("app", stored, app_version)
            self.set_setting("app_version", app_version)

    def version_info(self, app_version: str = "") -> dict[str, Any]:
        hist = self.get_upgrade_history()
        last = hist[-1]["date"] if hist else ""
        return {
            "app_version": app_version or self.get_setting("app_version", ""),
            "schema_version": int(self.get_setting("schema_version", "0") or 0),
            "schema_latest": SCHEMA_VERSION,
            "last_update": last,
            "history": list(reversed(hist)),   # найновіші перші
        }

    def list_backups(self) -> list[dict[str, Any]]:
        """Список резервних копій у backups/ (найновіші перші)."""
        bdir = self.backup_dir()
        if not bdir.exists():
            return []
        items = []
        for p in sorted(bdir.glob("*.db"), reverse=True):
            try:
                st = p.stat()
                items.append({
                    "name": p.name,
                    "size": st.st_size,
                    "modified": datetime.fromtimestamp(
                        st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                })
            except OSError:
                continue
        return items

    def checkpoint(self) -> None:
        """Зливає WAL у основний файл бази — щоб «сирий» файл .db був актуальним
        (напр., перед прямим завантаженням файлу як копії)."""
        try:
            with self._connect() as conn:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:  # noqa: BLE001
            pass

    def create_backup_file(self, prefix: str = "workcenter") -> Path:
        """Створює резервну копію поточної бази в backups/. Повертає шлях.
        prefix='pre_update_...' — копія перед оновленням (не ротується)."""
        bdir = self.backup_dir()
        bdir.mkdir(parents=True, exist_ok=True)
        now = datetime.now()
        ts = now.strftime('%Y-%m-%d_%H-%M-%S') + f"-{now.microsecond // 1000:03d}"
        name = f"{prefix}_{ts}.db"
        dest = bdir / name
        src = sqlite3.connect(self.db_path)
        dst = sqlite3.connect(dest)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        return dest

    def _latest_backup_age_seconds(self) -> Optional[float]:
        """Скільки секунд тому створена остання копія (або None, якщо немає)."""
        bdir = self.backup_dir()
        if not bdir.exists():
            return None
        files = list(bdir.glob("workcenter_*.db")) + list(bdir.glob("vet_pharmacy_*.db"))
        if not files:
            return None
        newest_mtime = max(p.stat().st_mtime for p in files)
        return time.time() - newest_mtime

    def _rotate_backups(self, keep: int) -> None:
        """Лишаємо `keep` найновіших звичайних копій (нові + старі за іменем)."""
        bdir = self.backup_dir()
        if not bdir.exists():
            return
        files = sorted(list(bdir.glob("workcenter_*.db")) + list(bdir.glob("vet_pharmacy_*.db")),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        for old in files[keep:]:
            try:
                old.unlink()
            except OSError:
                pass

    def _start_auto_backup(self, interval_hours: float = 4,
                           keep: int = 30) -> None:
        """Авто-копіювання у три моменти:
        (1) при запуску — якщо остання копія старша за інтервал;
        (2) у фоні — кожні interval_hours годин;
        (3) при коректному завершенні процесу (atexit).
        Тримає `keep` найновіших копій."""
        import threading
        import atexit
        interval_sec = float(interval_hours) * 3600.0

        def safe(fn):
            try:
                fn()
            except Exception:  # noqa: BLE001
                pass  # авто-копія не критична — не валимо процес

        # 1) копія при старті, якщо немає свіжої
        age = self._latest_backup_age_seconds()
        if age is None or age >= interval_sec:
            safe(self.create_backup_file)
        safe(lambda: self._rotate_backups(keep))

        # 2) фоновий потік-таймер
        def loop():
            while True:
                try:
                    time.sleep(interval_sec)
                    self.create_backup_file()
                    self._rotate_backups(keep)
                except Exception:  # noqa: BLE001
                    pass
        threading.Thread(target=loop, daemon=True,
                         name="vet-backup").start()

        # 3) копія при коректному завершенні (Ctrl+C, штатний exit)
        def on_exit():
            safe(self.create_backup_file)
            safe(lambda: self._rotate_backups(keep))
        atexit.register(on_exit)

    def restore_from_bytes(self, data: bytes) -> None:
        """Відновлення поточної бази з вмісту файлу. Безпечне: спершу
        робить копію поточного стану, потім записує новий файл, перевіряє
        його та застосовує міграції. При помилці — повертає попередню базу."""
        if not data.startswith(b"SQLite format 3\x00"):
            raise ValueError(
                "Файл не є базою даних SQLite. Виберіть валідний файл копії.")
        bdir = self.backup_dir()
        bdir.mkdir(parents=True, exist_ok=True)
        pre_path = bdir / (
            f"pre_restore_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.db")
        # перед-відновлювальна копія
        try:
            src = sqlite3.connect(self.db_path)
            dst = sqlite3.connect(pre_path)
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
        except Exception as exc:  # noqa: BLE001
            raise ValueError(
                f"Не вдалося створити перед-відновлювальну копію: {exc}")
        def _load(path: Path) -> None:
            """Перенести ВМІСТ файлу path у робочу базу через SQLite backup API.

            Чому не можна просто перезаписати файл: база працює в режимі WAL,
            і поряд живуть службові -wal/-shm. Якщо підмінити .db «з-під» них,
            SQLite застосує до нового файлу ЧУЖИЙ журнал і впаде з
            «database disk image is malformed» — навіть коли сама копія ціла.
            Видаляти ці файли теж не можна (при відкритих зʼєднаннях це дає
            «disk I/O error»). backup API виконує заміну вмісту коректно."""
            src = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            try:
                if src.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                    raise ValueError("копія не проходить перевірку цілісності")
                dst = sqlite3.connect(self.db_path)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
            finally:
                src.close()

        tmp_path = bdir / "restore_tmp.db"
        try:
            tmp_path.write_bytes(data)
            try:
                _load(tmp_path)
                self._migrate()
            except Exception as exc:  # noqa: BLE001
                try:                      # відкат на попередній стан
                    _load(pre_path)
                except Exception:  # noqa: BLE001
                    pass
                raise ValueError(
                    f"Файл бази пошкоджений або несумісний — відкочено: {exc}")
        finally:
            try:
                tmp_path.unlink()
            except OSError:
                pass

    # ------------------------------------------------------------------ користувачі / автентифікація

    def count_users(self) -> int:
        with self._connect() as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM users WHERE is_active = 1"
            ).fetchone()[0]

    def list_users(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, username, role, full_name, is_active, created_at, "
                "       last_seen, is_online "
                "FROM users ORDER BY created_at"
            ).fetchall()
        return [dict(r) for r in rows]

    def touch_user(self, user_id: int) -> None:
        """Оновлює час останньої активності користувача. Будь-який запит
        від залогіненого користувача також піднімає прапор is_online — це
        автоматично перетворює залогінених на «онлайн» після міграції."""
        if not user_id:
            return
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET last_seen = ?, is_online = 1 WHERE id = ?",
                (self._now(), user_id))

    def mark_user_online(self, user_id: int) -> None:
        """Позначає користувача як залогіненого (онлайн)."""
        if not user_id:
            return
        with self._connect() as conn:
            conn.execute("UPDATE users SET is_online = 1, last_seen = ? WHERE id = ?",
                         (self._now(), user_id))

    def mark_user_offline(self, user_id: int) -> None:
        """Позначає користувача як офлайн (після Вийти)."""
        if not user_id:
            return
        with self._connect() as conn:
            conn.execute("UPDATE users SET is_online = 0 WHERE id = ?",
                         (user_id,))

    def online_users(self, window_seconds: int = 180) -> list[dict[str, Any]]:
        """Користувачі, активні за останні window_seconds (за last_seen).
        Будь-який запит оновлює last_seen, тож відкрита вкладка = онлайн."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, username, full_name, role, last_seen FROM users "
                "WHERE is_active = 1 AND is_online = 1 AND last_seen <> '' "
                "AND last_seen >= datetime('now', 'localtime', ?) "
                "ORDER BY (full_name = '' OR full_name IS NULL), "
                "         full_name COLLATE NOCASE, username COLLATE NOCASE",
                (f"-{int(window_seconds)} seconds",),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_user(self, user_id: int) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, username, password_hash, role, full_name, is_active, created_at, last_seen, is_online "
                "FROM users WHERE id = ?", (user_id,),
            ).fetchone()
        return dict(row) if row else None

    def get_user_by_username(self, username: str) -> Optional[dict[str, Any]]:
        u = (username or "").strip()
        if not u:
            return None
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, username, password_hash, role, full_name, is_active, created_at, last_seen, is_online "
                "FROM users WHERE username = ? COLLATE NOCASE", (u,),
            ).fetchone()
        return dict(row) if row else None

    def add_user(self, username: str, password: str, role: str = "user",
                 full_name: str = "") -> int:
        from werkzeug.security import generate_password_hash
        username = (username or "").strip()
        if not username:
            raise ValueError("Логін обовʼязковий.")
        if not password or len(password) < 4:
            raise ValueError("Пароль має містити щонайменше 4 символи.")
        if role not in ("admin", "user"):
            role = "user"
        if self.get_user_by_username(username):
            raise ValueError(f"Користувач «{username}» вже існує.")
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO users (username, password_hash, role, full_name, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (username, generate_password_hash(password), role,
                 (full_name or "").strip(), self._now()))
            return int(cur.lastrowid)

    def set_user_password(self, user_id: int, password: str) -> None:
        from werkzeug.security import generate_password_hash
        if not password or len(password) < 4:
            raise ValueError("Пароль має містити щонайменше 4 символи.")
        with self._connect() as conn:
            conn.execute(
                "UPDATE users SET password_hash = ? WHERE id = ?",
                (generate_password_hash(password), user_id))

    def update_user(self, user_id: int, **fields: Any) -> None:
        allowed = {"username", "role", "full_name", "is_active"}
        # перевірка унікальності логіну, якщо змінюється
        if "username" in fields:
            new_username = (fields["username"] or "").strip()
            if not new_username:
                raise ValueError("Логін обовʼязковий.")
            with self._connect() as conn:
                dup = conn.execute(
                    "SELECT 1 FROM users WHERE username = ? COLLATE NOCASE AND id <> ?",
                    (new_username, user_id)).fetchone()
            if dup:
                raise ValueError(
                    f"Користувач з логіном «{new_username}» вже існує.")
            fields["username"] = new_username
        sets, params = [], []
        for key, value in fields.items():
            if key in allowed:
                sets.append(f"{key} = ?")
                params.append(value)
        if not sets:
            return
        params.append(user_id)
        with self._connect() as conn:
            conn.execute(
                f"UPDATE users SET {', '.join(sets)} WHERE id = ?", params)

    def delete_user(self, user_id: int) -> None:
        """М'яке видалення: користувач стає неактивним (is_active=0).
        Так зберігається історія рухів і ім'я, а акаунт можна відновити."""
        with self._connect() as conn:
            conn.execute("UPDATE users SET is_active = 0, is_online = 0 WHERE id = ?",
                         (user_id,))

    def restore_user(self, user_id: int) -> None:
        """Відновлення неактивного користувача."""
        with self._connect() as conn:
            conn.execute("UPDATE users SET is_active = 1 WHERE id = ?", (user_id,))

    # --- права користувачів на роботу по блоках ---

    def list_user_block_ids(self, user_id: int) -> list[int]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT block_id FROM user_blocks WHERE user_id = ?", (user_id,)
            ).fetchall()
        return [int(r["block_id"]) for r in rows]

    def set_user_blocks(self, user_id: int, block_ids: list) -> None:
        """Повністю замінює перелік дозволених блоків користувача."""
        ids = []
        for b in (block_ids or []):
            try:
                ids.append(int(b))
            except (TypeError, ValueError):
                continue
        with self._connect() as conn:
            conn.execute("DELETE FROM user_blocks WHERE user_id = ?", (user_id,))
            conn.executemany(
                "INSERT OR IGNORE INTO user_blocks (user_id, block_id) VALUES (?, ?)",
                [(user_id, bid) for bid in ids],
            )

    def allowed_blocks_for(self, user_id: int) -> list[dict[str, Any]]:
        """Блоки, доступні користувачу. Якщо обмежень не задано — усі.
        (Фактичне рішення «адмін бачить усе» приймається на рівні API.)"""
        allowed = set(self.list_user_block_ids(user_id))
        blocks = self.list_blocks()
        if not allowed:
            return blocks
        return [b for b in blocks if b["id"] in allowed]

    # --- доступ користувачів до гілок виробництва ---

    def list_user_branch_ids(self, user_id: int) -> list[str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT branch_id FROM user_branches WHERE user_id = ?", (user_id,)
            ).fetchall()
        return [str(r["branch_id"]) for r in rows]

    def set_user_branches(self, user_id: int, branch_ids: list) -> None:
        """Повністю замінює перелік дозволених гілок користувача."""
        ids = [str(b).strip() for b in (branch_ids or []) if str(b).strip()]
        with self._connect() as conn:
            conn.execute("DELETE FROM user_branches WHERE user_id = ?", (user_id,))
            conn.executemany(
                "INSERT OR IGNORE INTO user_branches (user_id, branch_id) VALUES (?, ?)",
                [(user_id, bid) for bid in ids],
            )

    # -------------------------------------------------- офлайн-доступ і пристрої

    def list_user_offline_branch_ids(self, user_id: int) -> list[str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT branch_id FROM user_offline_branches WHERE user_id = ?",
                (user_id,)).fetchall()
        return [str(r["branch_id"]) for r in rows]

    def set_user_offline_branches(self, user_id: int, branch_ids: list) -> None:
        """Повністю замінює перелік гілок, де користувачу дозволено офлайн."""
        ids = [str(b).strip() for b in (branch_ids or []) if str(b).strip()]
        with self._connect() as conn:
            conn.execute("DELETE FROM user_offline_branches WHERE user_id = ?",
                         (user_id,))
            conn.executemany(
                "INSERT OR IGNORE INTO user_offline_branches (user_id, branch_id) "
                "VALUES (?, ?)", [(user_id, bid) for bid in ids])

    def user_can_offline(self, user_id: int, branch_id: str) -> bool:
        branch_id = (branch_id or "").strip()
        if not branch_id:
            return False
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM user_offline_branches WHERE user_id = ? AND branch_id = ?",
                (int(user_id), branch_id)).fetchone()
        return bool(row)

    def register_device(self, device_id: str, name: str = "",
                        user_id: Optional[int] = None) -> None:
        device_id = (device_id or "").strip()
        if not device_id:
            return
        name = (name or "").strip()
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO sync_devices (device_id, name, last_user_id, last_seen) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(device_id) DO UPDATE SET "
                "  name = CASE WHEN excluded.name <> '' THEN excluded.name ELSE sync_devices.name END, "
                "  last_user_id = excluded.last_user_id, last_seen = excluded.last_seen",
                (device_id, name, user_id, self._now()))

    def list_devices(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT d.device_id, d.name, d.last_user_id, d.last_seen, u.username "
                "FROM sync_devices d LEFT JOIN users u ON u.id = d.last_user_id "
                "ORDER BY d.last_seen DESC").fetchall()
        return [dict(r) for r in rows]

    def build_offline_snapshot(self, category: str = "pharmacy") -> dict[str, Any]:
        """Знімок даних для офлайн-роботи телефону по конкретній гілці."""
        category = (category or "pharmacy").strip() or "pharmacy"
        products = [
            {"id": p["id"], "name": p["name"], "barcode": p["barcode"],
             "code": p.get("code", ""), "unit": p.get("unit", ""),
             "total_qty": p.get("total_qty", 0), "min_stock": p.get("min_stock", 0),
             "sale_price": p.get("sale_price", 0)}
            for p in self.list_products(category=category)
        ]
        return {
            "branch": category,
            "server_time": self._now(),
            "token": self._now(),
            "products": products,
            "catalog": self.list_catalog(category),
            "blocks": self.list_blocks(category),
            "recipients": self.list_recipients(category),
            "suppliers": self.list_suppliers(category),
        }

    def verify_password(self, username: str,
                        password: str) -> Optional[dict[str, Any]]:
        from werkzeug.security import check_password_hash
        user = self.get_user_by_username(username)
        if not user or not user.get("is_active"):
            return None
        if check_password_hash(user["password_hash"], password):
            u = dict(user)
            u.pop("password_hash", None)
            return u
        return None

    def clear_database(self) -> None:
        """Повністю очищає базу: товари, партії, рухи, постачальники,
        витрати та статті витрат. Демо-дані більше не повертаються при
        перезапуску. Стандартні статті витрат відновлюються."""
        with self._connect() as conn:
            for table in ("stock_moves", "stock_batches", "products",
                          "suppliers", "expenses", "expense_categories"):
                conn.execute("DELETE FROM " + table)
            conn.execute(
                "INSERT OR REPLACE INTO app_meta (key, value) "
                "VALUES ('demo_seeded', '1')")
        # повертаємо стандартні статті витрат
        self._seed_expense_categories()

    # ------------------------------------------------------------------ економіка

    def list_expense_categories(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name FROM expense_categories "
                "WHERE is_active = 1 ORDER BY name COLLATE NOCASE"
            ).fetchall()
        return [dict(r) for r in rows]

    def add_expense_category(self, name: str) -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Назва статті обов'язкова.")
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, is_active FROM expense_categories WHERE LOWER(name) = LOWER(?)",
                (name,),
            ).fetchone()
            if row:
                # реактивуємо, якщо була прихована
                conn.execute(
                    "UPDATE expense_categories SET is_active = 1, name = ? WHERE id = ?",
                    (name, row["id"]),
                )
                return int(row["id"])
            cur = conn.execute(
                "INSERT INTO expense_categories (name, created_at) VALUES (?, ?)",
                (name, self._now()),
            )
            return int(cur.lastrowid)

    def delete_expense_category(self, category_id: int) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE expense_categories SET is_active = 0 WHERE id = ?", (category_id,)
            )

    def add_expense(self, category_id: int | None, amount: float,
                    expense_date: str, note: str = "") -> int:
        amount = float(amount or 0)
        if amount <= 0:
            raise ValueError("Сума витрати має бути більшою за 0.")
        expense_date = (expense_date or "").strip() or self._now()[:10]
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO expenses (category_id, amount, expense_date, note, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (category_id, amount, expense_date, (note or "").strip(), self._now()),
            )
            return int(cur.lastrowid)

    def delete_expense(self, expense_id: int) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))

    def list_expenses(self, date_from: str = "", date_to: str = "") -> list[dict[str, Any]]:
        sql = (
            "SELECT e.id, e.amount, e.expense_date, e.note, "
            "       COALESCE(c.name, 'Без статті') AS category "
            "FROM expenses e "
            "LEFT JOIN expense_categories c ON c.id = e.category_id "
            "WHERE 1=1 "
        )
        params: list[Any] = []
        if date_from:
            sql += "AND e.expense_date >= ? "
            params.append(date_from)
        if date_to:
            sql += "AND e.expense_date <= ? "
            params.append(date_to)
        sql += "ORDER BY e.expense_date DESC, e.id DESC"
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def economics_summary(self, date_from: str = "", date_to: str = "") -> dict[str, Any]:
        """Аналітика заробітку за період: виручка, собівартість, прибуток,
        списання, операційні витрати, чистий прибуток."""
        with self._connect() as conn:
            # умова періоду для рухів (по даті created_at)
            mv_cond, mv_params = "", []
            if date_from:
                mv_cond += " AND substr(m.created_at, 1, 10) >= ?"
                mv_params.append(date_from)
            if date_to:
                mv_cond += " AND substr(m.created_at, 1, 10) <= ?"
                mv_params.append(date_to)

            revenue = conn.execute(
                "SELECT COALESCE(SUM(m.total), 0) FROM stock_moves m "
                "WHERE m.move_type = 'OUT'" + mv_cond, mv_params,
            ).fetchone()[0]
            cogs = conn.execute(
                "SELECT COALESCE(SUM(m.qty * b.price_in), 0) FROM stock_moves m "
                "JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'OUT'" + mv_cond, mv_params,
            ).fetchone()[0]
            writeoff = conn.execute(
                "SELECT COALESCE(SUM(m.qty * b.price_in), 0) FROM stock_moves m "
                "JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'WRITE_OFF'" + mv_cond, mv_params,
            ).fetchone()[0]

            # ефективна ціна закупки без ПДВ за одиницю; для старих партій,
            # де її не зберігали, — обчислюємо за ставкою ПДВ партії
            no_vat_price = (
                "(CASE WHEN b.price_in_no_vat > 0 THEN b.price_in_no_vat "
                "WHEN b.vat_rate > 0 THEN b.price_in / (1 + b.vat_rate / 100.0) "
                "ELSE b.price_in END)"
            )
            cogs_no_vat = conn.execute(
                "SELECT COALESCE(SUM(m.qty * " + no_vat_price + "), 0) FROM stock_moves m "
                "JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'OUT' " + "AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%')" + mv_cond, mv_params,
            ).fetchone()[0]
            writeoff_no_vat = conn.execute(
                "SELECT COALESCE(SUM(m.qty * " + no_vat_price + "), 0) FROM stock_moves m "
                "JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'WRITE_OFF'" + mv_cond, mv_params,
            ).fetchone()[0]
            # вхідний ПДВ — із приходів за період
            input_vat = conn.execute(
                "SELECT COALESCE(SUM(m.qty * (b.price_in - " + no_vat_price + ")), 0) "
                "FROM stock_moves m JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'IN' " + "AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%')" + mv_cond, mv_params,
            ).fetchone()[0]

            sales_count = conn.execute(
                "SELECT COUNT(DISTINCT sale_no) FROM stock_moves m "
                "WHERE m.move_type = 'OUT' AND m.sale_no <> ''" + mv_cond, mv_params,
            ).fetchone()[0]

            # витрати за період
            ex_cond, ex_params = "", []
            if date_from:
                ex_cond += " AND e.expense_date >= ?"
                ex_params.append(date_from)
            if date_to:
                ex_cond += " AND e.expense_date <= ?"
                ex_params.append(date_to)
            expenses_total = conn.execute(
                "SELECT COALESCE(SUM(e.amount), 0) FROM expenses e WHERE 1=1" + ex_cond,
                ex_params,
            ).fetchone()[0]
            by_cat = conn.execute(
                "SELECT COALESCE(c.name, 'Без статті') AS category, "
                "       SUM(e.amount) AS total "
                "FROM expenses e LEFT JOIN expense_categories c ON c.id = e.category_id "
                "WHERE 1=1" + ex_cond + " GROUP BY e.category_id ORDER BY total DESC",
                ex_params,
            ).fetchall()

        revenue = round(revenue or 0, 2)
        cogs = round(cogs or 0, 2)
        writeoff = round(writeoff or 0, 2)
        expenses_total = round(expenses_total or 0, 2)
        gross_profit = round(revenue - cogs, 2)
        net_profit = round(gross_profit - writeoff - expenses_total, 2)

        # --- показники без ПДВ та суми ПДВ ---
        cogs_no_vat = round(cogs_no_vat or 0, 2)
        writeoff_no_vat = round(writeoff_no_vat or 0, 2)
        input_vat = round(input_vat or 0, 2)
        # виручка без ПДВ — за припущенням стандартної ставки 20%
        revenue_no_vat = round(revenue / 1.2, 2)
        output_vat = round(revenue - revenue_no_vat, 2)
        gross_profit_no_vat = round(revenue_no_vat - cogs_no_vat, 2)
        net_profit_no_vat = round(
            gross_profit_no_vat - writeoff_no_vat - expenses_total, 2)
        vat_balance = round(output_vat - input_vat, 2)

        return {
            "revenue": revenue,
            "cogs": cogs,
            "gross_profit": gross_profit,
            "writeoff_loss": writeoff,
            "expenses_total": expenses_total,
            "net_profit": net_profit,
            "sales_count": int(sales_count or 0),
            "by_category": [dict(r) for r in by_cat],
            # без ПДВ / ПДВ
            "revenue_no_vat": revenue_no_vat,
            "cogs_no_vat": cogs_no_vat,
            "gross_profit_no_vat": gross_profit_no_vat,
            "writeoff_no_vat": writeoff_no_vat,
            "net_profit_no_vat": net_profit_no_vat,
            "output_vat": output_vat,
            "input_vat": input_vat,
            "vat_balance": vat_balance,
        }

    # ------------------------------------------------------------------ products

    def list_products(self, search: str = "", category: Optional[str] = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            base = """
                SELECT p.id, p.name, p.barcode, p.code, p.unit, p.min_stock, p.supplier, p.notes,
                       p.markup_pct, p.sale_price,
                       p.dose_per_head, p.dose_unit, p.dose_interval_days, p.pack_content,
                       p.exclude_from_order,
                       COALESCE(SUM(b.qty), 0) AS total_qty,
                       COALESCE(SUM(b.qty * b.price_in), 0) AS stock_value_in,
                       COALESCE(SUM(b.qty * (CASE
                           WHEN b.price_in_no_vat > 0 THEN b.price_in_no_vat
                           WHEN b.vat_rate > 0 THEN b.price_in / (1 + b.vat_rate / 100.0)
                           ELSE b.price_in END)), 0) AS stock_value_in_nv,
                       COALESCE(SUM(b.qty * b.price_out), 0) AS stock_value_out,
                       MIN(CASE WHEN b.qty > 0 THEN b.expires_on END) AS nearest_expiry
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id
                WHERE p.is_active = 1
            """
            params: list[Any] = []
            if category:
                base += " AND p.category = ?"
                params.append(category)
            if search:
                base += " AND (p.name LIKE ? OR p.barcode LIKE ? OR p.supplier LIKE ?)"
                like = f"%{search.strip()}%"
                params += [like, like, like]
            base += " GROUP BY p.id ORDER BY p.name"
            rows = conn.execute(base, params).fetchall()

        result = []
        for r in rows:
            d = dict(r)
            tq = d.get("total_qty") or 0
            sv_in = d.pop("stock_value_in", 0) or 0
            sv_in_nv = d.pop("stock_value_in_nv", 0) or 0
            sv_out = d.pop("stock_value_out", 0) or 0
            # середньозважені ціни по наявних партіях — 4 знаки після коми
            d["avg_price_in"] = round(sv_in / tq, 4) if tq else 0
            d["avg_price_in_no_vat"] = round(sv_in_nv / tq, 4) if tq else 0
            d["avg_price_out"] = round(sv_out / tq, 4) if tq else 0
            d["stock_value"] = round(sv_in, 2)          # вартість залишку за закупкою (з ПДВ)
            d["stock_value_no_vat"] = round(sv_in_nv, 2)  # вартість залишку без ПДВ
            d["stock_value_sale"] = round(sv_out, 2)    # вартість залишку за продажем
            # Вода необмежена: залишок і всі суми завжди 0.
            if str(d.get("name", "")).strip().lower() in self._WATER_NAMES:
                d["total_qty"] = 0
                d["avg_price_in"] = d["avg_price_in_no_vat"] = d["avg_price_out"] = 0
                d["stock_value"] = d["stock_value_no_vat"] = d["stock_value_sale"] = 0
            result.append(d)
        return result

    def export_feed_arrivals(self) -> list[dict[str, Any]]:
        """Повний прихід кормів (усі надходження з усіма даними) для перенесення
        в іншу базу: назва, одиниця, партія, термін, кількість (оригінальна з
        приходу), ціни, ПДВ, постачальник, накладна, дата приходу. Вода — ні."""
        out = []
        with self._connect() as conn:
            rows = conn.execute(
                """SELECT p.name AS name, p.unit AS unit, p.min_stock AS min_stock,
                          b.lot_number AS lot, b.expires_on AS expires, m.qty AS qty,
                          b.price_in_no_vat AS pnv, b.price_in AS pv, b.vat_rate AS vat,
                          s.name AS supplier, b.invoice_number AS invoice,
                          COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)) AS rdate
                   FROM stock_moves m
                   JOIN products p ON p.id = m.product_id AND p.category='feed'
                   LEFT JOIN stock_batches b ON b.id = m.batch_id
                   LEFT JOIN suppliers s ON s.id = b.supplier_id
                   WHERE m.move_type = 'IN'
                   ORDER BY rdate, m.id""").fetchall()
        for r in rows:
            if self._is_water(r["name"]):
                continue
            out.append({
                "name": r["name"], "unit": r["unit"] or "кг",
                "lot": r["lot"] or "", "expires": r["expires"] or "",
                "qty": round(float(r["qty"] or 0), 3),
                "price_no_vat": round(float(r["pnv"] or 0), 4),
                "price_vat": round(float(r["pv"] or 0), 4),
                "vat": float(r["vat"] or 0),
                "supplier": r["supplier"] or "",
                "invoice": r["invoice"] or "",
                "receipt_date": r["rdate"] or "",
                "min_stock": float(r["min_stock"] or 0),
            })
        return out

    def import_feed_arrivals(self, rows: list) -> dict[str, Any]:
        """Занести прихід кормів (кожен рядок — окреме надходження) із усіма
        даними. Зіставлення за НАЗВОЮ в межах кормів; немає товару — створюємо
        (категорія=корма). Кожен рядок → окрема партія приходу."""
        cat = "feed"
        existing = {(p.get("name", "") or "").strip().lower(): p
                    for p in self.list_products(category=cat)}
        added_products = added_batches = 0
        errors = []
        for i, r in enumerate(rows or [], start=1):
            name = (r.get("name") or "").strip()
            if not name:
                continue
            qty = self._to_float(r.get("qty"), 0)
            unit = (r.get("unit") or "кг").strip() or "кг"
            try:
                p = existing.get(name.lower())
                if not p:
                    pid = self.add_product(
                        name=name, barcode="", unit=unit,
                        min_stock=self._to_float(r.get("min_stock"), 0),
                        supplier="", notes="",
                        code=self.generate_product_code(cat), category=cat)
                    p = self.get_product(pid)
                    existing[name.lower()] = p
                    added_products += 1
                if qty > 0:
                    self.receive_stock(
                        p["barcode"], qty,
                        (r.get("lot") or "").strip(),
                        (r.get("expires") or "").strip() or None,
                        price_in_no_vat=self._to_float(r.get("price_no_vat"), 0),
                        price_in=self._to_float(r.get("price_vat"), 0),
                        vat_rate=self._to_float(r.get("vat"), 20) or 20,
                        supplier_name=(r.get("supplier") or "").strip() or "Перенесення",
                        invoice_number=(r.get("invoice") or "").strip() or "Перенесення",
                        receipt_date=(r.get("receipt_date") or "").strip())
                    added_batches += 1
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{name} ({r.get('receipt_date','')}): {exc}")
        return {"products": added_products, "batches": added_batches,
                "errors": errors}

    def get_product_by_barcode(self, barcode: str) -> Optional[dict[str, Any]]:
        b = (barcode or "").strip()
        if not b:
            return None
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT p.id, p.name, p.barcode, p.code, p.unit, p.min_stock, p.supplier, p.notes,
                       p.markup_pct, p.sale_price, p.category,
                       COALESCE(SUM(b.qty), 0) AS total_qty
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id
                WHERE p.barcode = ? AND p.is_active = 1
                GROUP BY p.id
                """,
                (b,),
            ).fetchone()
        return dict(row) if row else None

    def add_product(self, name: str, barcode: str, unit: str, min_stock: float,
                    supplier: str, notes: str, code: str = "",
                    category: str = "pharmacy",
                    dose_per_head: float = 0, dose_unit: str = "",
                    dose_interval_days: int = 0, pack_content: float = 0,
                    exclude_from_order: int = 0) -> int:
        name = (name or "").strip()
        barcode = (barcode or "").strip()
        code = (code or "").strip()
        category = (category or "pharmacy").strip() or "pharmacy"
        if not name:
            raise ValueError("Назва товару обов'язкова.")
        if not barcode:
            # Штрихкод необов'язковий: якщо порожній — призначаємо тимчасовий
            # внутрішній код (EAN-13, префікс 20–29). Реальний штрихкод можна
            # внести пізніше на складі (редагування товару).
            barcode = self.generate_internal_barcode()
        if code and not code.isdigit():
            raise ValueError("Код товару має містити лише цифри.")
        with self._connect() as conn:
            if code and conn.execute(
                    "SELECT 1 FROM products WHERE code = ? AND is_active = 1",
                    (code,)).fetchone():
                raise ValueError(f"Товар з кодом «{code}» вже існує.")
            cur = conn.execute(
                "INSERT INTO products (name, barcode, code, unit, min_stock, supplier, notes, created_at, category, "
                "dose_per_head, dose_unit, dose_interval_days, pack_content, exclude_from_order) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (name, barcode, code, (unit or "шт").strip(),
                 float(min_stock or 0),
                 (supplier or "").strip(), (notes or "").strip(), self._now(), category,
                 self._to_float(dose_per_head, 0), (dose_unit or "").strip(),
                 int(self._to_float(dose_interval_days, 0)), self._to_float(pack_content, 0),
                 1 if str(exclude_from_order) in ("1", "True", "true", "on") else 0),
            )
            # Кожен новий товар одразу потрапляє в каталог (довідник препаратів),
            # щоб надалі скан того ж штрихкоду його впізнавав навіть без залишку.
            self._catalog_upsert(conn, category, barcode, name,
                                 (unit or "шт").strip())
            return int(cur.lastrowid)

    # -------------------------------------------------- каталог (довідник)
    # Записи каталогу можуть бути ЛИШЕ з назвою (без штрихкоду) — напр. тисячі
    # назв із держреєстру. Штрихкод прив'язується пізніше при першому скані.

    def _catalog_upsert(self, conn, category: str, barcode: str,
                        name: str, unit: str) -> int:
        """Додати/оновити запис каталогу в межах відкритого з'єднання.

        Дедуплікація: за штрихкодом (якщо є), інакше за назвою (без урахування
        регістру для латиниці + точний збіг для кирилиці)."""
        barcode = (barcode or "").strip()
        name = (name or "").strip()
        unit = (unit or "шт").strip() or "шт"
        category = (category or "pharmacy").strip() or "pharmacy"
        if not name:
            return 0
        row = None
        if barcode:
            row = conn.execute(
                "SELECT id FROM catalog WHERE barcode = ? AND barcode <> '' "
                "AND category = ?", (barcode, category)).fetchone()
        if row is None:
            row = conn.execute(
                "SELECT id FROM catalog WHERE category = ? AND barcode = '' "
                "AND name = ? COLLATE NOCASE", (category, name)).fetchone()
        if row:
            # Якщо знайшли запис без штрихкоду, а зараз він є — прив'яжемо його.
            conn.execute(
                "UPDATE catalog SET name = ?, unit = ?, "
                "barcode = CASE WHEN ? <> '' THEN ? ELSE barcode END WHERE id = ?",
                (name, unit, barcode, barcode, row["id"]))
            return int(row["id"])
        cur = conn.execute(
            "INSERT INTO catalog (category, barcode, name, unit, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (category, barcode, name, unit, self._now()))
        return int(cur.lastrowid)

    def get_catalog_by_barcode(self, barcode: str,
                               category: str = "pharmacy") -> Optional[dict[str, Any]]:
        b = (barcode or "").strip()
        if not b:
            return None
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, category, barcode, name, unit, created_at FROM catalog "
                "WHERE barcode = ? AND barcode <> '' AND category = ? LIMIT 1",
                (b, category),
            ).fetchone()
        return dict(row) if row else None

    def get_catalog_by_name(self, name: str,
                            category: str = "pharmacy") -> Optional[dict[str, Any]]:
        n = (name or "").strip()
        if not n:
            return None
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, category, barcode, name, unit, created_at FROM catalog "
                "WHERE category = ? AND name = ? COLLATE NOCASE LIMIT 1",
                (category, n)).fetchone()
        return dict(row) if row else None

    def list_catalog(self, category: str = "pharmacy",
                     q: str = "", limit: int = 0) -> list[dict[str, Any]]:
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, category, barcode, name, unit, created_at FROM catalog "
                "WHERE category = ? ORDER BY name COLLATE NOCASE",
                (category,)).fetchall()
        items = [dict(r) for r in rows]
        q = (q or "").strip().casefold()
        if q:
            # Фільтр у Python — щоб коректно працювало і для кирилиці
            # (SQLite LIKE регістронезалежний лише для латиниці).
            items = [it for it in items
                     if q in (it["name"] or "").casefold()
                     or q in (it["barcode"] or "").casefold()]
        if limit and limit > 0:
            items = items[:limit]
        return items

    def catalog_count(self, category: str = "pharmacy") -> int:
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM catalog WHERE category = ?",
                (category,)).fetchone()
        return int(row["n"]) if row else 0

    def upsert_catalog_item(self, barcode: str, name: str, unit: str,
                            category: str = "pharmacy") -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Назва обов'язкова.")
        with self._connect() as conn:
            return self._catalog_upsert(conn, category, barcode, name, unit)

    def bulk_import_catalog(self, items: list[dict[str, Any]],
                            category: str = "pharmacy") -> dict[str, int]:
        """Масовий імпорт у каталог (тисячі рядків в одній транзакції).

        items: список {name, barcode?, unit?}. Дедуплікація — за штрихкодом
        (якщо є), інакше за назвою. Повертає лічильники."""
        category = (category or "pharmacy").strip() or "pharmacy"
        now = self._now()
        added = updated = skipped = 0
        with self._connect() as conn:
            bc_map: dict[str, int] = {}
            name_map: dict[str, int] = {}
            for r in conn.execute(
                    "SELECT id, barcode, name FROM catalog WHERE category = ?",
                    (category,)):
                if r["barcode"]:
                    bc_map[r["barcode"]] = r["id"]
                else:
                    name_map.setdefault((r["name"] or "").strip().casefold(), r["id"])
            for it in items:
                name = (str(it.get("name") or "")).strip()
                if not name:
                    skipped += 1
                    continue
                bc = (str(it.get("barcode") or "")).strip()
                unit = (str(it.get("unit") or "")).strip() or "шт"
                key_id = None
                if bc and bc in bc_map:
                    key_id = bc_map[bc]
                elif not bc and name.casefold() in name_map:
                    key_id = name_map[name.casefold()]
                if key_id:
                    conn.execute(
                        "UPDATE catalog SET name = ?, unit = ?, "
                        "barcode = CASE WHEN ? <> '' THEN ? ELSE barcode END WHERE id = ?",
                        (name, unit, bc, bc, key_id))
                    updated += 1
                else:
                    cur = conn.execute(
                        "INSERT INTO catalog (category, barcode, name, unit, created_at) "
                        "VALUES (?, ?, ?, ?, ?)", (category, bc, name, unit, now))
                    nid = int(cur.lastrowid)
                    if bc:
                        bc_map[bc] = nid
                    else:
                        name_map[name.casefold()] = nid
                    added += 1
        return {"added": added, "updated": updated, "skipped": skipped,
                "total": added + updated}

    def clear_catalog(self, category: str = "pharmacy") -> int:
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM catalog WHERE category = ?", (category,))
            return cur.rowcount

    def delete_catalog_item(self, item_id: int,
                            category: str = "pharmacy") -> bool:
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            cur = conn.execute(
                "DELETE FROM catalog WHERE id = ? AND category = ?",
                (int(item_id), category))
            return cur.rowcount > 0

    # ===================================== прогноз замовлень (план потреби)

    @staticmethod
    def _to_float(v, default: float = 0.0) -> float:
        """М'який парсер числа: приймає кому/крапку, порожнє → default."""
        try:
            s = str(v).strip().replace(",", ".")
            return float(s) if s else float(default)
        except (TypeError, ValueError):
            return float(default)

    def get_branch_headcount(self, category: str) -> dict[str, Any]:
        """Поголів'я гілки (для норми «на голову»). source: manual/herd."""
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            row = conn.execute(
                "SELECT headcount, source, updated_at FROM branch_livestock "
                "WHERE category = ?", (category,)).fetchone()
        if not row:
            return {"headcount": 0.0, "source": "manual", "updated_at": ""}
        return {"headcount": float(row["headcount"] or 0),
                "source": row["source"] or "manual",
                "updated_at": row["updated_at"] or ""}

    def set_branch_headcount(self, category: str, headcount: float,
                             source: str = "manual") -> None:
        category = (category or "pharmacy").strip() or "pharmacy"
        hc = max(0.0, self._to_float(headcount, 0))
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO branch_livestock (category, headcount, source, updated_at) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(category) DO UPDATE SET headcount = excluded.headcount, "
                "source = excluded.source, updated_at = excluded.updated_at",
                (category, hc, (source or "manual"), self._now()))

    def get_order_settings(self) -> dict[str, float]:
        """Глобальні параметри замовлення: доставка і страховий запас (днів)."""
        return {"lead_days": self._to_float(self.get_setting("order_lead_days", "3"), 3),
                "buffer_days": self._to_float(self.get_setting("order_buffer_days", "7"), 7)}

    def set_order_settings(self, lead_days=None, buffer_days=None) -> None:
        if lead_days is not None:
            self.set_setting("order_lead_days", str(max(0.0, self._to_float(lead_days, 3))))
        if buffer_days is not None:
            self.set_setting("order_buffer_days", str(max(0.0, self._to_float(buffer_days, 7))))

    def order_forecast(self, category: str = "pharmacy") -> dict[str, Any]:
        """Прогноз потреби й рекомендація замовлення (замовлення раз на місяць).

        Норма = доза_на_голову × поголів'я ÷ N днів → дози/день, переводиться в
        упаковки через вміст_упаковки. Мін. залишок = витрата/день × (доставка +
        буфер); замовити = округл.вгору(витрата/день × (30 + доставка + буфер) −
        залишок), не менше 0, цілими упаковками."""
        category = (category or "pharmacy").strip() or "pharmacy"
        s = self.get_order_settings()
        lead, buf = s["lead_days"], s["buffer_days"]
        cover = 30.0 + lead + buf
        hc = self.get_branch_headcount(category)["headcount"]
        today = date.today()

        items = []
        for p in self.list_products("", category=category):
            if self._is_water(p.get("name")):
                continue                       # вода необмежена — не замовляється
            dose = self._to_float(p.get("dose_per_head"), 0)
            n = int(self._to_float(p.get("dose_interval_days"), 0))
            pack = self._to_float(p.get("pack_content"), 0)
            stock = self._to_float(p.get("total_qty"), 0)
            has_norm = dose > 0 and n > 0 and pack > 0
            packs_day = (dose * hc / n / pack) if (has_norm and hc > 0) else 0.0
            min_stock = round(packs_day * (lead + buf), 2)
            order_qty = max(0, math.ceil(packs_day * cover - stock)) if packs_day > 0 else 0
            days_left = int(stock / packs_day) if packs_day > 0 else None
            depletion = (today + timedelta(days=days_left)).isoformat() if days_left is not None else None
            urgent = bool(packs_day > 0 and stock < min_stock)
            items.append({
                "id": p.get("id"), "name": p.get("name"), "code": p.get("code"),
                "unit": p.get("unit"), "stock": round(stock, 2),
                "dose_per_head": dose, "dose_unit": p.get("dose_unit") or "",
                "dose_interval_days": n, "pack_content": pack,
                "use_per_day": round(packs_day, 3),
                "min_stock": min_stock, "order_qty": int(order_qty),
                "days_left": days_left, "depletion": depletion,
                "urgent": urgent, "has_norm": has_norm,
            })
        # Спершу термінові, далі за обсягом замовлення, потім за назвою
        items.sort(key=lambda x: (not x["urgent"], -(x["order_qty"] or 0),
                                  (x["name"] or "").lower()))
        return {"category": category, "headcount": hc,
                "lead_days": lead, "buffer_days": buf, "items": items}

    # ===================================== схеми лікування/профілактики

    # Множник періоду рядка схеми. «once» — разовий курс (без множення на дні);
    # day/week/month — постійна витрата (застосувань на місяць).
    _PERIOD_FACTOR = {"once": 1.0, "day": 30.0, "week": 30.0 / 7.0, "month": 1.0}
    # Об'ємні/вагові одиниці — без вмісту упаковки в флакони не перевести.
    _VOLUMETRIC_UNITS = {"мл", "ml", "г", "g"}

    def _herd_headcount(self, source: str, ref_id, year=None, month=None) -> float:
        """Поголів'я зі стада за джерелом схеми: для 'group' — залишок групи,
        для 'move' — кількість за типом руху. Беремо заданий місяць (або поточний);
        якщо порожній — найсвіжіший заповнений місяць ≤ заданого того ж року."""
        if not ref_id or source not in ("group", "move"):
            return 0.0
        now = datetime.now()
        y = int(year) if year else now.year
        m = int(month) if month else now.month
        if m < 1 or m > 12:
            m = now.month
        table = "herd_counts" if source == "group" else "herd_move_counts"
        key = "group_id" if source == "group" else "type_id"
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT headcount FROM {table} WHERE {key} = ? AND year = ? "
                "AND month <= ? ORDER BY month DESC", (int(ref_id), y, m)).fetchall()
        for r in rows:
            v = float(r["headcount"] or 0)
            if v > 0:
                return v
        return 0.0

    def list_schemes(self, category: str = "pharmacy",
                     hc_year=None, hc_month=None) -> list[dict[str, Any]]:
        """Схеми гілки разом із рядками (медикамент, доза, період).
        hc_year/hc_month — місяць, на який рахувати поголів'я зі стада."""
        category = (category or "pharmacy").strip() or "pharmacy"
        out = []
        with self._connect() as conn:
            srows = conn.execute(
                "SELECT s.id, s.name, s.block_id, s.headcount, s.hc_source, s.hc_ref_id, "
                "s.sort_order, b.name AS block_name "
                "FROM rx_schemes s LEFT JOIN blocks b ON b.id = s.block_id "
                "WHERE s.is_active = 1 AND s.category = ? "
                "ORDER BY s.sort_order, s.id", (category,)).fetchall()
            gnames = {r["id"]: r["name"] for r in conn.execute(
                "SELECT id, name FROM herd_groups WHERE is_active = 1").fetchall()}
            tnames = {r["id"]: r["name"] for r in conn.execute(
                "SELECT id, name FROM herd_move_types WHERE is_active = 1").fetchall()}
            for s in srows:
                lines = conn.execute(
                    "SELECT l.id, l.product_id, p.name AS product_name, p.unit, "
                    "p.pack_content, l.dose_per_head, l.dose_unit, l.times_per, l.basis, l.period "
                    "FROM rx_scheme_lines l JOIN products p ON p.id = l.product_id "
                    "WHERE l.scheme_id = ? ORDER BY l.id", (s["id"],)).fetchall()
                d = dict(s)
                d["lines"] = [dict(x) for x in lines]
                src = (s["hc_source"] or "manual")
                if src == "group":
                    d["hc_ref_name"] = gnames.get(s["hc_ref_id"], "—")
                elif src == "move":
                    d["hc_ref_name"] = tnames.get(s["hc_ref_id"], "—")
                else:
                    d["hc_ref_name"] = ""
                out.append(d)
        # Ефективне поголів'я: вручну → headcount; інакше — зі стада (поточний міс.).
        for d in out:
            src = d.get("hc_source") or "manual"
            if src in ("group", "move"):
                d["eff_headcount"] = self._herd_headcount(src, d.get("hc_ref_id"), hc_year, hc_month)
            else:
                d["eff_headcount"] = self._to_float(d.get("headcount"), 0)
        return out

    def save_scheme(self, scheme_id, name: str, block_id, headcount,
                    lines: list, category: str = "pharmacy",
                    hc_source: str = "manual", hc_ref_id=None) -> int:
        """Створити/оновити схему разом із рядками (рядки перезаписуються).
        hc_source: manual | group | move; hc_ref_id — id групи/типу руху."""
        category = (category or "pharmacy").strip() or "pharmacy"
        name = (name or "").strip()
        hc = max(0.0, self._to_float(headcount, 0))
        bid = int(block_id) if block_id else None
        src = (hc_source or "manual").strip()
        if src not in ("manual", "group", "move"):
            src = "manual"
        ref = None if src == "manual" else (int(hc_ref_id) if hc_ref_id else None)
        with self._connect() as conn:
            if scheme_id:
                sid = int(scheme_id)
                conn.execute("UPDATE rx_schemes SET name=?, block_id=?, headcount=?, "
                             "hc_source=?, hc_ref_id=? WHERE id=?",
                             (name, bid, hc, src, ref, sid))
                conn.execute("DELETE FROM rx_scheme_lines WHERE scheme_id=?", (sid,))
            else:
                nxt = conn.execute(
                    "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM rx_schemes "
                    "WHERE category = ? AND is_active = 1", (category,)).fetchone()[0]
                cur = conn.execute(
                    "INSERT INTO rx_schemes (name, block_id, category, headcount, "
                    "hc_source, hc_ref_id, sort_order, created_at) "
                    "VALUES (?,?,?,?,?,?,?,?)", (name, bid, category, hc, src, ref, int(nxt), self._now()))
                sid = int(cur.lastrowid)
            for ln in (lines or []):
                pid = ln.get("product_id")
                if not pid:
                    continue
                t = int(self._to_float(ln.get("times_per"), 1))
                basis = (ln.get("basis") or "head").strip()
                if basis not in ("head", "time"):
                    basis = "head"
                conn.execute(
                    "INSERT INTO rx_scheme_lines (scheme_id, product_id, dose_per_head, "
                    "dose_unit, times_per, basis, period, created_at) VALUES (?,?,?,?,?,?,?,?)",
                    (sid, int(pid), self._to_float(ln.get("dose_per_head"), 0),
                     (ln.get("dose_unit") or "").strip(), (t if t > 0 else 1), basis,
                     (ln.get("period") or "day").strip() or "day", self._now()))
        return sid

    def delete_scheme(self, scheme_id) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE rx_schemes SET is_active=0 WHERE id=?", (int(scheme_id),))

    def reorder_schemes(self, ordered_ids: list, category: str = "pharmacy") -> None:
        """Записати новий порядок схем (перетягуванням): sort_order = позиція."""
        category = (category or "pharmacy").strip() or "pharmacy"
        with self._connect() as conn:
            pos = 0
            for sid in (ordered_ids or []):
                try:
                    sid = int(sid)
                except (TypeError, ValueError):
                    continue
                pos += 1
                conn.execute(
                    "UPDATE rx_schemes SET sort_order=? "
                    "WHERE id=? AND category=? AND is_active=1", (pos, sid, category))

    # ----------------------------------------------------------- стадо (herd)
    # ================= ПЕРСОНАЛ (гілка «Персонал») =================
    def list_staff(self, include_inactive: bool = False) -> list[dict[str, Any]]:
        """Список працівників (за блоком, потім за порядком користувача)."""
        sql = ("SELECT s.id, s.staff_code, s.name, s.full_name, s.gender, s.role, "
               "s.tg_id, s.tg_admin, s.phone, s.note, s.is_active, s.sort_order, "
               "s.block_id, b.sort_order AS block_no, b.name AS block_name "
               "FROM staff s LEFT JOIN staff_blocks b "
               "ON b.id = s.block_id AND b.is_active = 1")
        if not include_inactive:
            sql += " WHERE s.is_active = 1"
        sql += (" ORDER BY CASE WHEN b.sort_order IS NULL THEN 1 ELSE 0 END, "
                "b.sort_order, s.sort_order, s.id")
        with self._connect() as conn:
            out = [dict(r) for r in conn.execute(sql).fetchall()]
            # додаткові ролі кожного працівника (основна — в полі role)
            extra: dict[int, list] = {}
            for x in conn.execute(
                    "SELECT x.staff_id, r.id AS rid, r.name FROM staff_extra_roles x "
                    "JOIN work_roles r ON r.id=x.role_id AND r.is_active=1 "
                    "ORDER BY r.name").fetchall():
                extra.setdefault(x["staff_id"], []).append(
                    {"id": x["rid"], "name": x["name"]})
            for s in out:
                s["extra_roles"] = extra.get(s["id"], [])
        return out

    def add_staff(self, name: str, role: str = "", tg_id: str = "",
                  phone: str = "", note: str = "", block_id: int = 0,
                  full_name: str = "", gender: str = "") -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Вкажіть ім'я працівника.")
        with self._connect() as conn:
            pos = conn.execute(
                "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM staff").fetchone()[0]
            # табельний номер = MAX+1 серед УСІХ (в т.ч. звільнених) → не переприсвоюється
            n = conn.execute(
                "SELECT COALESCE(MAX(CAST(staff_code AS INTEGER)),0) FROM staff "
                "WHERE staff_code GLOB '[0-9]*'").fetchone()[0] or 0
            code = "%04d" % (int(n) + 1)
            cur = conn.execute(
                "INSERT INTO staff(name, full_name, gender, role, tg_id, phone, note, "
                "is_active, sort_order, created_at, block_id, staff_code) "
                "VALUES(?,?,?,?,?,?,?,1,?,?,?,?)",
                (name, (full_name or "").strip(), (gender or "").strip(),
                 (role or "").strip(), (tg_id or "").strip(), (phone or "").strip(),
                 (note or "").strip(), pos, self._now(), int(block_id or 0), code))
            return cur.lastrowid

    def _merge_tg_duplicate(self, conn, keep_id: int, tg: str) -> None:
        """Обʼєднати бот-дублікат у наявний запис: якщо інший активний працівник
        має цей самий Telegram-ID, перенести його цикли на keep_id, адоптувати
        телефон/ПІБ (де порожньо) і деактивувати дубль. ID keep_id (і табельний
        номер) лишаються початковими."""
        keep_id = int(keep_id)
        tg = str(tg or "").strip()
        if not tg:
            return
        dups = conn.execute(
            "SELECT id, phone, full_name, name FROM staff "
            "WHERE tg_id=? AND is_active=1 AND id<>?", (tg, keep_id)).fetchall()
        for d in dups:
            conn.execute("UPDATE role_runs SET staff_id=? WHERE staff_id=?",
                         (keep_id, d["id"]))
            keep = conn.execute(
                "SELECT phone, full_name FROM staff WHERE id=?", (keep_id,)).fetchone()
            if not (keep["phone"] or "").strip() and (d["phone"] or "").strip():
                conn.execute("UPDATE staff SET phone=? WHERE id=?", (d["phone"], keep_id))
            if not (keep["full_name"] or "").strip() and (d["full_name"] or "").strip():
                conn.execute("UPDATE staff SET full_name=? WHERE id=?",
                             (d["full_name"], keep_id))
            conn.execute("UPDATE staff SET is_active=0, tg_id='' WHERE id=?", (d["id"],))

    def merge_staff(self, keep_id: int, drop_id: int) -> None:
        """Обʼєднати два записи: drop → keep. ID/табельний номер keep лишаються.
        Переносяться цикли; Telegram/телефон/ПІБ адоптуються, де в keep порожньо."""
        keep_id, drop_id = int(keep_id), int(drop_id)
        if keep_id == drop_id:
            return
        with self._connect() as conn:
            keep = conn.execute(
                "SELECT tg_id, phone, full_name FROM staff WHERE id=?", (keep_id,)).fetchone()
            drop = conn.execute(
                "SELECT tg_id, phone, full_name FROM staff WHERE id=?", (drop_id,)).fetchone()
            if not keep or not drop:
                raise ValueError("Запис не знайдено.")
            conn.execute("UPDATE role_runs SET staff_id=? WHERE staff_id=?",
                         (keep_id, drop_id))
            for col in ("tg_id", "phone", "full_name"):
                if not (keep[col] or "").strip() and (drop[col] or "").strip():
                    conn.execute(f"UPDATE staff SET {col}=? WHERE id=?",
                                 (drop[col], keep_id))
            conn.execute("UPDATE staff SET is_active=0, tg_id='' WHERE id=?", (drop_id,))

    def update_staff(self, staff_id: int, **fields) -> None:
        allowed = ("name", "full_name", "gender", "role", "tg_id", "phone", "note",
                   "is_active", "sort_order", "block_id", "tg_admin")
        sets, params = [], []
        for k in allowed:
            if k in fields and fields[k] is not None:
                v = fields[k]
                if k in ("name", "full_name", "gender", "role", "tg_id", "phone", "note"):
                    v = str(v).strip()
                if k in ("is_active", "sort_order", "block_id", "tg_admin"):
                    v = int(v)
                sets.append(f"{k}=?"); params.append(v)
        if not sets:
            return
        params.append(int(staff_id))
        with self._connect() as conn:
            conn.execute(f"UPDATE staff SET {', '.join(sets)} WHERE id=?", params)
            # якщо задали Telegram-ID — обʼєднати бот-дублікат у цей запис
            tg_val = fields.get("tg_id")
            if tg_val is not None and str(tg_val).strip():
                self._merge_tg_duplicate(conn, int(staff_id), str(tg_val).strip())

    def set_staff_phone_by_tg(self, tg_id: str, phone: str) -> int:
        """Записати телефон працівникам із таким Telegram-ID (той, хто поділився
        контактом у боті). Повертає кількість оновлених рядків."""
        tg = str(tg_id or "").strip()
        phone = str(phone or "").strip()
        if not tg or not phone:
            return 0
        with self._connect() as conn:
            cur = conn.execute("UPDATE staff SET phone=? WHERE tg_id=?", (phone, tg))
            return cur.rowcount

    def staff_by_tg(self, tg_id: str) -> Optional[dict[str, Any]]:
        tg = str(tg_id or "").strip()
        if not tg:
            return None
        with self._connect() as conn:
            r = conn.execute(
                "SELECT id, name, full_name, gender, role, tg_id, phone FROM staff "
                "WHERE tg_id=? AND is_active=1 LIMIT 1", (tg,)).fetchone()
        return dict(r) if r else None

    def set_staff_gender_by_tg(self, tg_id: str, gender: str) -> int:
        """Стать, яку працівник обирає сам у боті (Ч/Ж)."""
        tg = str(tg_id or "").strip()
        g = str(gender or "").strip()
        if not tg or g not in ("Ч", "Ж"):
            return 0
        with self._connect() as conn:
            cur = conn.execute("UPDATE staff SET gender=? WHERE tg_id=?", (g, tg))
            return cur.rowcount

    def set_staff_fullname_by_tg(self, tg_id: str, full_name: str) -> int:
        """Повне імʼя (ПІБ), яке працівник вводить сам у боті."""
        tg = str(tg_id or "").strip()
        full_name = str(full_name or "").strip()
        if not tg or not full_name:
            return 0
        with self._connect() as conn:
            cur = conn.execute("UPDATE staff SET full_name=? WHERE tg_id=?",
                               (full_name, tg))
            return cur.rowcount

    def delete_staff(self, staff_id: int) -> None:
        """М'яке видалення (is_active=0), щоб зберегти зв'язки з даними.
        ЗВІЛЬНЯЄМО Telegram-ID, щоб той самий працівник міг зайти в бот наново
        (інакше неактивний запис тримав би tg_id і повторний ввід ламався)."""
        with self._connect() as conn:
            conn.execute("UPDATE staff SET is_active=0, tg_id='' WHERE id=?",
                         (int(staff_id),))

    def staff_overview(self) -> dict[str, Any]:
        """Зведення для сторінки Огляду гілки «Персонал»."""
        today = self._now()[:10]
        with self._connect() as conn:
            staff_total = conn.execute(
                "SELECT COUNT(*) FROM staff WHERE is_active=1").fetchone()[0]
            staff_tg = conn.execute(
                "SELECT COUNT(*) FROM staff WHERE is_active=1 AND TRIM(tg_id)<>''"
            ).fetchone()[0]
            staff_phone = conn.execute(
                "SELECT COUNT(*) FROM staff WHERE is_active=1 AND TRIM(phone)<>''"
            ).fetchone()[0]
            roles_total = conn.execute(
                "SELECT COUNT(*) FROM work_roles WHERE is_active=1").fetchone()[0]
            runs_today = conn.execute(
                "SELECT COUNT(*) FROM role_runs WHERE substr(created_at,1,10)=?",
                (today,)).fetchone()[0]
            runs_week = conn.execute(
                "SELECT COUNT(*) FROM role_runs WHERE substr(created_at,1,10)>=?",
                (self._days_ago(6),)).fetchone()[0]
            last = conn.execute(
                "SELECT r.role_name, r.created_at, "
                "COALESCE(NULLIF(TRIM(s.name),''), r.staff_name) AS staff_name "
                "FROM role_runs r LEFT JOIN staff s ON s.id = r.staff_id AND s.is_active=1 "
                "ORDER BY r.id DESC LIMIT 1").fetchone()
        return {
            "staff_total": staff_total, "staff_tg": staff_tg,
            "staff_phone": staff_phone, "roles_total": roles_total,
            "runs_today": runs_today, "runs_week": runs_week,
            "last_run": dict(last) if last else None,
        }

    def _days_ago(self, n: int) -> str:
        from datetime import date, timedelta
        return (date.today() - timedelta(days=int(n))).isoformat()

    def autoclose_day_runs(self, stop_time: str = "23:00") -> int:
        """Після 23:00 добити незавершені цикли за сьогодні: незаповненим крокам
        типу «час» (зокрема «Стоп дня») поставити stop_time, решті — порожньо,
        щоб цикл вважався завершеним. Повертає к-сть закритих прогонів."""
        today = self._now()[:10]
        closed = 0
        with self._connect() as conn:
            runs = conn.execute(
                "SELECT id, role_id FROM role_runs "
                "WHERE substr(created_at,1,10)=?", (today,)).fetchall()
            for r in runs:
                rid, role_id = r["id"], r["role_id"]
                steps = conn.execute(
                    "SELECT label, kind, required FROM role_steps "
                    "WHERE role_id=? ORDER BY sort_order, id", (role_id,)).fetchall()
                total = len(steps)
                answered = conn.execute(
                    "SELECT COUNT(*) FROM role_answers WHERE run_id=?", (rid,)
                ).fetchone()[0]
                if total == 0 or answered >= total:
                    continue                       # немає кроків або вже завершено
                # добити кроки з answered-го до кінця (цикл послідовний)
                for i in range(answered, total):
                    st = steps[i]
                    val = stop_time if (st["kind"] == "time") else ""
                    conn.execute(
                        "INSERT INTO role_answers(run_id, label, kind, value, photo, "
                        "sort_order) VALUES(?,?,?,?,?,?)",
                        (rid, st["label"], st["kind"], val, "", i + 1))
                closed += 1
        return closed

    def staff_worklive(self, day: str = "") -> dict[str, Any]:
        """Стан працівників за день (за замовч. — сьогодні): у роботі/завершили +
        усі цикли. Для дашборда «Персонал»; day=YYYY-MM-DD — інша дата."""
        today = (day or "").strip() or self._now()[:10]
        with self._connect() as conn:
            # поточне імʼя й блок беремо зі staff (join), а не з фіксації в прогоні,
            # щоб перейменування працівника одразу відбивалось у дашборді
            runs = conn.execute(
                "SELECT r.id, r.role_id, r.role_name, r.staff_id, r.tg_id, r.created_at, "
                "COALESCE(NULLIF(TRIM(s.name),''), r.staff_name) AS staff_name, "
                "b.sort_order AS block_no, b.name AS block_name "
                "FROM role_runs r "
                "LEFT JOIN staff s ON s.id = r.staff_id AND s.is_active=1 "
                "LEFT JOIN staff_blocks b ON b.id = s.block_id AND b.is_active=1 "
                "WHERE substr(r.created_at,1,10)=? ORDER BY r.id DESC", (today,)
            ).fetchall()
            step_counts, out, seen = {}, [], set()
            runs_by_key = {}     # key → [{cells, complete, started}] (старіші→новіші)
            for r in runs:       # runs у порядку id DESC (новіші перші)
                key = r["staff_id"] or ("tg:" + (r["tg_id"] or ""))
                rid, role_id = r["id"], r["role_id"]
                if role_id not in step_counts:
                    step_counts[role_id] = conn.execute(
                        "SELECT COUNT(*) FROM role_steps WHERE role_id=? "
                        "AND kind<>'duration'", (role_id,)).fetchone()[0]
                total = step_counts[role_id] or 0
                ans = conn.execute(
                    "SELECT label, kind, value, photo FROM role_answers "
                    "WHERE run_id=? ORDER BY sort_order, id", (rid,)).fetchall()
                answered = sum(1 for a in ans if (a["kind"] or "") != "duration")
                complete = (total > 0 and answered >= total)
                runs_by_key.setdefault(key, []).insert(0, {   # insert(0) → хронологічно
                    "complete": complete,
                    "started": (r["created_at"] or "")[:16].replace("T", " "),
                    "cells": [{"label": a["label"], "value": a["value"] or "",
                               "photo": a["photo"] or ""} for a in ans],
                })
                if key in seen:          # для шапки картки — останній прогін
                    continue
                seen.add(key)
                out.append({
                    "run_id": rid, "role_name": r["role_name"],
                    "staff_id": r["staff_id"], "_key": key,
                    "staff_name": r["staff_name"] or ("TG " + (r["tg_id"] or "")),
                    "block_no": r["block_no"], "block_name": r["block_name"] or "",
                    "started": (r["created_at"] or "")[:16].replace("T", " "),
                    "answered": answered, "total": total,
                    "done": complete,
                    "answers": [dict(a) for a in ans],
                })
            import re as _re

            def _hm2min(v):
                m = _re.match(r"^(\d{1,2})[:.](\d{2})$", (v or "").strip())
                return int(m.group(1)) * 60 + int(m.group(2)) if m else 0
            for w in out:                # усі цикли працівника за день + лічильники
                rl = runs_by_key.get(w["_key"], [])
                for i, rr in enumerate(rl, 1):
                    rr["seq"] = i
                # сума робочих годин по працівнику (крок із «робоч» у назві)
                tot = 0
                for rr in rl:
                    for c in rr.get("cells", []):
                        if "робоч" in (c["label"] or "").lower():
                            tot += _hm2min(c["value"])
                w["runs"] = rl
                w["run_count"] = len(rl)
                w["done_count"] = sum(1 for rr in rl if rr["complete"])
                w["work_min"] = tot
                w["work_total"] = f"{tot // 60}:{tot % 60:02d}" if tot else ""
                w.pop("_key", None)
        active = sum(1 for w in out if not w["done"])
        return {"date": today, "active": active,
                "done": len(out) - active, "workers": out}

    def reorder_staff(self, order: list) -> None:
        with self._connect() as conn:
            for pos, sid in enumerate(order or []):
                try:
                    conn.execute("UPDATE staff SET sort_order=? WHERE id=?",
                                 (pos, int(sid)))
                except (TypeError, ValueError):
                    continue

    # -------------------------- Блоки персоналу (нумерований список) ---------
    def _reseq_staff_blocks(self, conn) -> None:
        """Перенумерувати активні блоки послідовно 1..N (за поточним порядком)."""
        rows = conn.execute(
            "SELECT id FROM staff_blocks WHERE is_active=1 ORDER BY sort_order, id"
        ).fetchall()
        for i, r in enumerate(rows, start=1):
            conn.execute("UPDATE staff_blocks SET sort_order=? WHERE id=?", (i, r["id"]))

    def list_staff_blocks(self, include_inactive: bool = False) -> list[dict[str, Any]]:
        sql = ("SELECT b.id, b.name, b.sort_order, "
               "(SELECT COUNT(*) FROM staff s WHERE s.block_id=b.id AND s.is_active=1) "
               "AS staff_count FROM staff_blocks b")
        if not include_inactive:
            sql += " WHERE b.is_active = 1"
        sql += " ORDER BY b.sort_order, b.id"
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(sql).fetchall()]

    def add_staff_block(self, name: str) -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Вкажіть назву блоку.")
        with self._connect() as conn:
            pos = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0)+1 FROM staff_blocks WHERE is_active=1"
            ).fetchone()[0]
            cur = conn.execute(
                "INSERT INTO staff_blocks(name, sort_order, is_active, created_at) "
                "VALUES(?,?,1,?)", (name, pos, self._now()))
            return cur.lastrowid

    def update_staff_block(self, block_id: int, name: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE staff_blocks SET name=? WHERE id=?",
                         (str(name or "").strip(), int(block_id)))

    def delete_staff_block(self, block_id: int) -> None:
        """М'яко видалити блок, зняти працівників (block_id=0), перенумерувати."""
        bid = int(block_id)
        with self._connect() as conn:
            conn.execute("UPDATE staff SET block_id=0 WHERE block_id=?", (bid,))
            conn.execute("UPDATE staff_blocks SET is_active=0 WHERE id=?", (bid,))
            self._reseq_staff_blocks(conn)

    def reorder_staff_blocks(self, order: list) -> None:
        """Новий порядок → номери 1..N послідовно."""
        with self._connect() as conn:
            pos = 0
            for bid in (order or []):
                try:
                    bid = int(bid)
                except (TypeError, ValueError):
                    continue
                pos += 1
                conn.execute("UPDATE staff_blocks SET sort_order=? "
                             "WHERE id=? AND is_active=1", (pos, bid))
            self._reseq_staff_blocks(conn)

    # ---------------------------- Ролі та цикли (гілка «Персонал») ----------
    _STEP_KINDS = ("number", "photo", "yesno", "text", "time", "shift", "duration")

    def list_work_roles(self, include_inactive: bool = False) -> list[dict[str, Any]]:
        """Ролі з к-стю кроків у циклі (за порядком користувача)."""
        sql = ("SELECT r.id, r.name, r.is_active, r.sort_order, "
               "(SELECT COUNT(*) FROM role_steps s WHERE s.role_id=r.id) AS step_count "
               "FROM work_roles r")
        if not include_inactive:
            sql += " WHERE r.is_active = 1"
        sql += " ORDER BY r.sort_order, r.id"
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(sql).fetchall()]

    def add_work_role(self, name: str) -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Вкажіть назву ролі.")
        with self._connect() as conn:
            pos = conn.execute(
                "SELECT COALESCE(MAX(sort_order), 0) + 1 FROM work_roles").fetchone()[0]
            cur = conn.execute(
                "INSERT INTO work_roles(name, is_active, sort_order, created_at) "
                "VALUES(?,1,?,?)", (name, pos, self._now()))
            return cur.lastrowid

    def update_work_role(self, role_id: int, **fields) -> None:
        allowed = ("name", "is_active", "sort_order")
        sets, params = [], []
        for k in allowed:
            if k in fields and fields[k] is not None:
                v = str(fields[k]).strip() if k == "name" else int(fields[k])
                sets.append(f"{k}=?"); params.append(v)
        if not sets:
            return
        params.append(int(role_id))
        with self._connect() as conn:
            conn.execute(f"UPDATE work_roles SET {', '.join(sets)} WHERE id=?", params)

    def delete_work_role(self, role_id: int) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE work_roles SET is_active=0 WHERE id=?", (int(role_id),))

    def reorder_work_roles(self, order: list) -> None:
        with self._connect() as conn:
            for pos, rid in enumerate(order or []):
                try:
                    conn.execute("UPDATE work_roles SET sort_order=? WHERE id=?",
                                 (pos, int(rid)))
                except (TypeError, ValueError):
                    continue

    def list_role_steps(self, role_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, label, kind, required, sort_order, calc_from, calc_to "
                "FROM role_steps WHERE role_id=? ORDER BY sort_order, id",
                (int(role_id),)).fetchall()
        return [dict(r) for r in rows]

    def save_role_steps(self, role_id: int, steps: list) -> None:
        """Замінити всі кроки ролі (список {label, kind, required, calc_from, calc_to})."""
        role_id = int(role_id)
        with self._connect() as conn:
            conn.execute("DELETE FROM role_steps WHERE role_id=?", (role_id,))
            pos = 0
            for st in (steps or []):
                label = str((st or {}).get("label") or "").strip()
                if not label:
                    continue
                kind = str((st or {}).get("kind") or "number").strip()
                if kind not in self._STEP_KINDS:
                    kind = "number"
                req = 1 if (st or {}).get("required", True) else 0
                cf = str((st or {}).get("calc_from") or "").strip()
                ct = str((st or {}).get("calc_to") or "").strip()
                pos += 1
                conn.execute(
                    "INSERT INTO role_steps(role_id, label, kind, required, sort_order, "
                    "calc_from, calc_to) VALUES(?,?,?,?,?,?,?)",
                    (role_id, label, kind, req, pos, cf, ct))

    def seed_default_roles(self) -> None:
        """Разово: приклад-цикл «Доярка» (щоб було з чого починати)."""
        with self._connect() as conn:
            # разова нормалізація назви кроку (для наявних БД), ідемпотентно
            conn.execute("UPDATE role_steps SET label='Зміна' "
                         "WHERE label='Зміна (яка за рахунком)'")
            conn.execute("UPDATE role_answers SET label='Зміна' "
                         "WHERE label='Зміна (яка за рахунком)'")
            # разово: повністю прибрати авто-доданий приклад-крок «Робочі години»
            # (його ніхто не замовляв — це був сід). Видаляємо і крок, і його
            # відповіді в журналі, щоб стовпець зник. Власні кроки користувача з
            # іншими назвами («Робочих год.» тощо) не чіпаємо.
            conn.execute(
                "DELETE FROM role_answers WHERE label='Робочі години'")
            conn.execute(
                "DELETE FROM role_steps WHERE kind='duration' AND label='Робочі години' "
                "AND calc_from='Старт дня' AND calc_to='Стоп дня'")
            has = conn.execute(
                "SELECT 1 FROM work_roles LIMIT 1").fetchone()
        if has:
            return
        rid = self.add_work_role("Доярка")
        self.save_role_steps(rid, [
            {"label": "Старт дня", "kind": "time", "required": True},
            {"label": "Зміна", "kind": "shift", "required": True},
            {"label": "Старт доїння", "kind": "time", "required": True},
            {"label": "Стоп доїння", "kind": "time", "required": True},
            {"label": "Надій, л", "kind": "number", "required": True},
            {"label": "Хворі корови", "kind": "text", "required": False},
            {"label": "Фото (за потреби)", "kind": "photo", "required": False},
            {"label": "Стоп дня", "kind": "time", "required": True},
        ])

    @staticmethod
    def _hhmm_dur(from_val: str, to_val: str) -> str:
        """Тривалість між двома ГГ:ХХ → 'Г:ХХ' (через північ = +24 год)."""
        import re as _re

        def _p(s):
            m = _re.match(r"^(\d{1,2})[:.](\d{2})$", (s or "").strip())
            if not m:
                return None
            h, mi = int(m.group(1)), int(m.group(2))
            return h * 60 + mi if (h <= 23 and mi <= 59) else None
        a, b = _p(from_val), _p(to_val)
        if a is None or b is None:
            return ""
        d = b - a
        if d < 0:
            d += 24 * 60
        return f"{d // 60}:{d % 60:02d}"

    def recompute_duration_answers(self, run_id: int | None = None) -> int:
        """Перерахувати обчислювані кроки (duration) для наявних прогонів:
        заповнити «Робочі години» тощо з уже введених from/to. Ідемпотентно.
        Якщо задано run_id — лише цей прогін."""
        n = 0
        with self._connect() as conn:
            dsteps = conn.execute(
                "SELECT role_id, label, sort_order, calc_from, calc_to FROM role_steps "
                "WHERE kind='duration'").fetchall()
            end_kw = ("стоп", "кінець", "кінц", "фініш", "завершен", "end")
            start_kw = ("старт", "початок", "поч", "start")
            for st in dsteps:
                if not (st["calc_from"] and st["calc_to"]):
                    continue
                sl, el = st["calc_from"], st["calc_to"]
                if (any(k in sl.lower() for k in end_kw)
                        and any(k in el.lower() for k in start_kw)):
                    sl, el = el, sl  # переставлені: початок→кінець
                if run_id is not None:
                    runs = conn.execute(
                        "SELECT id FROM role_runs WHERE role_id=? AND id=?",
                        (st["role_id"], run_id)).fetchall()
                else:
                    runs = conn.execute(
                        "SELECT id FROM role_runs WHERE role_id=?", (st["role_id"],)).fetchall()
                for r in runs:
                    rid = r["id"]
                    fv = conn.execute(
                        "SELECT value FROM role_answers WHERE run_id=? AND label=? LIMIT 1",
                        (rid, sl)).fetchone()
                    tv = conn.execute(
                        "SELECT value FROM role_answers WHERE run_id=? AND label=? LIMIT 1",
                        (rid, el)).fetchone()
                    dur = self._hhmm_dur((fv or {})["value"] if fv else "",
                                         (tv or {})["value"] if tv else "")
                    if not dur:
                        continue
                    cur = conn.execute(
                        "SELECT id, value FROM role_answers WHERE run_id=? AND label=? LIMIT 1",
                        (rid, st["label"])).fetchone()
                    if cur:
                        if (cur["value"] or "") != dur:
                            conn.execute("UPDATE role_answers SET value=? WHERE id=?",
                                         (dur, cur["id"]))
                            n += 1
                    else:
                        conn.execute(
                            "INSERT INTO role_answers(run_id, label, kind, value, photo, "
                            "sort_order) VALUES(?,?,?,?,'',?)",
                            (rid, st["label"], "duration", dur, st["sort_order"]))
                        n += 1
        return n

    # ── Робочі процеси (група ролей; напр. «Доїння») ─────────────────
    def process_shifts(self, process_id: int) -> int:
        """Разів на день для процесу: власне число або глобальне «Доїнь на день»."""
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT shifts_per_day FROM work_processes WHERE id=?",
                    (int(process_id),)).fetchone()
            own = int((row["shifts_per_day"] if row else 0) or 0)
        except Exception:  # noqa: BLE001
            own = 0
        if own > 0:
            return max(1, min(6, own))
        try:
            return max(1, min(6, int(self.get_setting("farm_shifts", "2") or "2")))
        except (TypeError, ValueError):
            return 2

    def list_work_processes(self) -> list[dict[str, Any]]:
        """Активні процеси з привʼязаними ролями."""
        with self._connect() as conn:
            procs = conn.execute(
                "SELECT id, name, sort_order, shifts_per_day FROM work_processes "
                "WHERE is_active=1 ORDER BY sort_order, id").fetchall()
            out = []
            for p in procs:
                links = conn.execute(
                    "SELECT r.id, r.name FROM work_process_roles pr "
                    "JOIN work_roles r ON r.id = pr.role_id AND r.is_active=1 "
                    "WHERE pr.process_id=? ORDER BY r.sort_order, r.id",
                    (p["id"],)).fetchall()
                sc = conn.execute(
                    "SELECT COUNT(*) FROM process_steps WHERE process_id=?",
                    (p["id"],)).fetchone()[0]
                out.append({"id": p["id"], "name": p["name"],
                            "sort_order": p["sort_order"],
                            "shifts_per_day": int(p["shifts_per_day"] or 0),
                            "role_ids": [r["id"] for r in links],
                            "role_names": [r["name"] for r in links],
                            "step_count": sc})
        return out

    def save_work_process(self, pid, name: str, role_ids=None,
                          shifts_per_day=None) -> int:
        """Створити/оновити процес. Якщо role_ids=None — ролі НЕ чіпаємо (зручно
        для авто-збереження лише назви); якщо список — замінюємо. Повертає id."""
        name = (name or "").strip()
        if not name:
            raise ValueError("Порожня назва процесу.")
        touch_roles = role_ids is not None
        ids = []
        for x in (role_ids or []):
            try:
                ids.append(int(x))
            except (TypeError, ValueError):
                pass
        with self._connect() as conn:
            pid = int(pid or 0)
            if pid:
                conn.execute("UPDATE work_processes SET name=? WHERE id=?", (name, pid))
            else:
                so = conn.execute(
                    "SELECT COALESCE(MAX(sort_order),0)+1 FROM work_processes "
                    "WHERE is_active=1").fetchone()[0]
                cur = conn.execute(
                    "INSERT INTO work_processes(name, sort_order, is_active, created_at) "
                    "VALUES(?,?,1,?)", (name, so, self._now()))
                pid = cur.lastrowid
            if shifts_per_day is not None:
                try:
                    spd = max(0, min(6, int(shifts_per_day or 0)))
                except (TypeError, ValueError):
                    spd = 0
                conn.execute("UPDATE work_processes SET shifts_per_day=? WHERE id=?",
                             (spd, pid))
            if touch_roles:
                conn.execute("DELETE FROM work_process_roles WHERE process_id=?", (pid,))
                for rid in ids:
                    conn.execute(
                        "INSERT OR IGNORE INTO work_process_roles(process_id, role_id) "
                        "VALUES(?,?)", (pid, rid))
        return pid

    def delete_work_process(self, pid) -> None:
        pid = int(pid)
        with self._connect() as conn:
            conn.execute("UPDATE work_processes SET is_active=0 WHERE id=?", (pid,))
            conn.execute("DELETE FROM work_process_roles WHERE process_id=?", (pid,))

    def work_process_status(self, day: str = "") -> list[dict[str, Any]]:
        """Статус виконання процесів за день (за замовч. — сьогодні): по кожному
        процесу — учасники + скільки в роботі / завершили. day=YYYY-MM-DD."""
        today = (day or "").strip() or self._now()[:10]
        procs = self.list_work_processes()
        with self._connect() as conn:
            for p in procs:
                rids = p["role_ids"]
                workers = []
                if rids:
                    ph = ",".join("?" * len(rids))
                    # працівники, чия ОСНОВНА або ДОДАТКОВА роль входить у процес
                    staff = conn.execute(
                        "SELECT DISTINCT s.id, s.name, s.role FROM staff s "
                        "LEFT JOIN work_roles r ON r.name = s.role AND r.is_active=1 "
                        "LEFT JOIN staff_extra_roles x ON x.staff_id = s.id "
                        f"WHERE s.is_active=1 AND (r.id IN ({ph}) OR x.role_id IN ({ph})) "
                        "ORDER BY s.name", rids + rids).fetchall()
                    for s in staff:
                        run = conn.execute(
                            "SELECT r.id, r.role_id FROM role_runs r "
                            "WHERE r.staff_id=? AND substr(r.created_at,1,10)=? "
                            "ORDER BY r.id DESC LIMIT 1", (s["id"], today)).fetchone()
                        status = "idle"
                        if run:
                            tot = conn.execute(
                                "SELECT COUNT(*) FROM role_steps WHERE role_id=? "
                                "AND kind<>'duration'", (run["role_id"],)).fetchone()[0]
                            ans = conn.execute(
                                "SELECT COUNT(*) FROM role_answers a "
                                "JOIN role_steps st ON st.role_id=? AND st.label=a.label "
                                "WHERE a.run_id=? AND a.kind<>'duration'",
                                (run["role_id"], run["id"])).fetchone()[0]
                            status = "done" if (tot > 0 and ans >= tot) else "active"
                        workers.append({"id": s["id"], "name": s["name"],
                                        "role": s["role"], "status": status})
                p["workers"] = workers
                p["active"] = sum(1 for w in workers if w["status"] == "active")
                p["done"] = sum(1 for w in workers if w["status"] == "done")
                p["total"] = len(workers)
                # спільні кроки процесу (колонки) + УСІ прогони (доїння) за сьогодні
                steps = conn.execute(
                    "SELECT label, kind, calc_from, calc_to FROM process_steps "
                    "WHERE process_id=? ORDER BY sort_order, id", (p["id"],)).fetchall()
                askable = [s["label"] for s in steps if s["kind"] != "duration"]
                runs = conn.execute(
                    "SELECT id FROM process_runs WHERE process_id=? AND run_date=? "
                    "ORDER BY id", (p["id"], today)).fetchall()
                run_list, done_runs = [], 0
                entered_ids = set()   # хто був задіяний у процесі сьогодні
                for i, r in enumerate(runs, 1):
                    amap = {}
                    who = []   # задіяні в ЦЬОМУ прогоні: зайшли в процес АБО вносили
                    for pt in conn.execute(
                            "SELECT staff_id, staff_name FROM process_run_participants "
                            "WHERE run_id=?", (r["id"],)).fetchall():
                        entered_ids.add(int(pt["staff_id"]))
                        nm = (pt["staff_name"] or "").strip()
                        if nm and nm not in who:
                            who.append(nm)
                    for a in conn.execute(
                            "SELECT label, value, staff_id, staff_name, photo "
                            "FROM process_answers WHERE run_id=?",
                            (r["id"],)).fetchall():
                        amap[a["label"]] = a["value"]
                        filled = ((a["value"] or "").strip()
                                  or (a["photo"] or "").strip())
                        if a["staff_id"] and filled:
                            entered_ids.add(int(a["staff_id"]))
                        nm = (a["staff_name"] or "").strip()
                        if nm and filled and nm not in who:
                            who.append(nm)
                    complete = bool(askable) and all(
                        (amap.get(l) or "") for l in askable)
                    if complete:
                        done_runs += 1
                    run_list.append({
                        "seq": i, "complete": complete,
                        "by": ", ".join(who),
                        "cells": [{"label": s["label"], "kind": s["kind"],
                                   "calc_from": s["calc_from"] or "",
                                   "calc_to": s["calc_to"] or "",
                                   "value": amap.get(s["label"], "")}
                                  for s in steps]})
                p["entered_ids"] = sorted(entered_ids)
                p["shifts"] = self.process_shifts(p["id"])
                p["runs"] = run_list
                p["done_runs"] = done_runs
                p["step_labels"] = [s["label"] for s in steps]
        return procs

    # ── Кроки процесу (спільні) + спільний денний прогін ─────────────
    def list_process_steps(self, process_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, label, kind, required, sort_order, calc_from, calc_to "
                "FROM process_steps WHERE process_id=? ORDER BY sort_order, id",
                (int(process_id),)).fetchall()
        return [dict(r) for r in rows]

    def save_process_steps(self, process_id: int, steps: list) -> None:
        process_id = int(process_id)
        with self._connect() as conn:
            conn.execute("DELETE FROM process_steps WHERE process_id=?", (process_id,))
            pos = 0
            for st in (steps or []):
                label = str((st or {}).get("label") or "").strip()
                if not label:
                    continue
                kind = str((st or {}).get("kind") or "number").strip()
                if kind not in self._STEP_KINDS:
                    kind = "number"
                req = 1 if (st or {}).get("required", True) else 0
                cf = str((st or {}).get("calc_from") or "").strip()
                ct = str((st or {}).get("calc_to") or "").strip()
                pos += 1
                conn.execute(
                    "INSERT INTO process_steps(process_id, label, kind, required, "
                    "sort_order, calc_from, calc_to) VALUES(?,?,?,?,?,?,?)",
                    (process_id, label, kind, req, pos, cf, ct))

    def process_today_run(self, process_id: int, create: bool = True) -> int:
        """Id спільного прогону процесу за сьогодні (створює за потреби)."""
        process_id = int(process_id)
        today = self._now()[:10]
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id FROM process_runs WHERE process_id=? AND run_date=? "
                "ORDER BY id DESC LIMIT 1", (process_id, today)).fetchone()
            if row:
                return int(row["id"])
            if not create:
                return 0
            cur = conn.execute(
                "INSERT INTO process_runs(process_id, run_date, created_at) "
                "VALUES(?,?,?)", (process_id, today, self._now()))
            return int(cur.lastrowid)

    def resume_process_for_staff(self, staff_id: int) -> Optional[dict[str, Any]]:
        """Незавершений прогін процесу СЬОГОДНІ, у якому працівник є учасником —
        для відновлення втраченої сесії процесу (після перезапуску бота)."""
        sid = int(staff_id or 0)
        if not sid:
            return None
        today = self._now()[:10]
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT r.id AS run_id, r.process_id, p.name "
                "FROM process_run_participants pp "
                "JOIN process_runs r ON r.id = pp.run_id AND r.run_date=? "
                "JOIN work_processes p ON p.id = r.process_id AND p.is_active=1 "
                "WHERE pp.staff_id=? ORDER BY r.id DESC", (today, sid)).fetchall()
            for row in rows:
                if not self._process_run_complete(conn, row["run_id"], row["process_id"]):
                    seq = conn.execute(
                        "SELECT COUNT(*) FROM process_runs WHERE process_id=? "
                        "AND run_date=? AND id<=?",
                        (row["process_id"], today, row["run_id"])).fetchone()[0]
                    return {"run_id": int(row["run_id"]),
                            "process_id": int(row["process_id"]),
                            "name": row["name"], "seq": int(seq or 1)}
        return None

    def _process_run_complete(self, conn, run_id: int, process_id: int) -> bool:
        """Чи всі НЕ-обчислювані кроки процесу заповнені у цьому прогоні."""
        need = [r["label"] for r in conn.execute(
            "SELECT label FROM process_steps WHERE process_id=? AND kind<>'duration'",
            (process_id,)).fetchall()]
        if not need:
            return True
        have = {a["label"] for a in conn.execute(
            "SELECT label FROM process_answers WHERE run_id=? "
            "AND (TRIM(value)<>'' OR TRIM(photo)<>'')", (run_id,)).fetchall()}
        return all(lbl in have for lbl in need)

    def process_shift_run(self, process_id: int, shifts: int,
                          create: bool = True) -> dict[str, Any]:
        """Прогін процесу на ПОТОЧНЕ доїння/зміну. Якщо останнє незавершене —
        продовжуємо його; якщо завершене й доїнь ще менше за `shifts` — нове;
        якщо всі доїння за добу зроблено — all_done=True (run_id=0)."""
        process_id = int(process_id)
        shifts = max(1, min(6, int(shifts or 1)))
        today = self._now()[:10]
        with self._connect() as conn:
            runs = conn.execute(
                "SELECT id FROM process_runs WHERE process_id=? AND run_date=? "
                "ORDER BY id", (process_id, today)).fetchall()
            n = len(runs)
            if n:
                last = runs[-1]["id"]
                if not self._process_run_complete(conn, last, process_id):
                    return {"run_id": int(last), "seq": n, "all_done": False}
            # останнє завершене або прогонів нема
            if n >= shifts:
                return {"run_id": 0, "seq": n, "all_done": True}
            if not create:
                return {"run_id": 0, "seq": n, "all_done": False}
            cur = conn.execute(
                "INSERT INTO process_runs(process_id, run_date, created_at) "
                "VALUES(?,?,?)", (process_id, today, self._now()))
            return {"run_id": int(cur.lastrowid), "seq": n + 1, "all_done": False}

    def process_run_join(self, run_id: int, staff_id: int, staff_name: str) -> None:
        """Зафіксувати, що працівник ЗАЙШОВ у прогін процесу (учасник)."""
        rid, sid = int(run_id or 0), int(staff_id or 0)
        if not (rid and sid):
            return
        with self._connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO process_run_participants(run_id, staff_id, "
                "staff_name) VALUES(?,?,?)", (rid, sid, staff_name or ""))

    def process_run_participants_tg(self, run_id: int) -> list[dict[str, Any]]:
        """Учасники прогону з їх Telegram-ID: [{staff_id, staff_name, tg_id}]."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.staff_id, p.staff_name, s.tg_id FROM process_run_participants p "
                "JOIN staff s ON s.id = p.staff_id AND s.is_active=1 "
                "WHERE p.run_id=? AND TRIM(COALESCE(s.tg_id,''))<>''",
                (int(run_id or 0),)).fetchall()
        return [dict(r) for r in rows]

    def process_run_answered_labels(self, run_id: int) -> set:
        if not run_id:
            return set()
        return {a["label"] for a in self.process_run_answers(int(run_id))}

    def record_process_answer_run(self, run_id: int, staff_id, staff_name,
                                  label, kind, value, photo, sort_order) -> None:
        """Записати відповідь у КОНКРЕТНИЙ прогін. Ідемпотентно за міткою, АЛЕ
        порожній наявний рядок (після «Пропустити» тощо) перезаписується —
        інакше внесене значення мовчки губилось і прогін не закривався."""
        rid = int(run_id)
        with self._connect() as conn:
            ex = conn.execute(
                "SELECT id, value, photo FROM process_answers "
                "WHERE run_id=? AND label=? LIMIT 1", (rid, label)).fetchone()
            if not ex:
                conn.execute(
                    "INSERT INTO process_answers(run_id, label, kind, value, photo, "
                    "staff_id, staff_name, sort_order) VALUES(?,?,?,?,?,?,?,?)",
                    (rid, label, kind, str(value), photo or "",
                     int(staff_id or 0), staff_name or "", int(sort_order or 0)))
            elif not ((ex["value"] or "").strip() or (ex["photo"] or "").strip()):
                # наявний рядок порожній → заповнюємо новим значенням
                conn.execute(
                    "UPDATE process_answers SET value=?, photo=?, staff_id=?, "
                    "staff_name=? WHERE id=?",
                    (str(value), photo or "", int(staff_id or 0),
                     staff_name or "", ex["id"]))

    def process_finalize_durations_run(self, process_id: int, run_id: int) -> None:
        """Порахувати обчислювані кроки у конкретному прогоні."""
        rid = int(run_id)
        if not rid:
            return
        steps = self.list_process_steps(process_id)
        ans = {a["label"]: a for a in self.process_run_answers(rid)}
        end_kw = ("стоп", "кінець", "кінц", "фініш", "завершен", "end")
        start_kw = ("старт", "початок", "поч", "start")
        with self._connect() as conn:
            for st in steps:
                if st["kind"] != "duration" or not (st["calc_from"] and st["calc_to"]):
                    continue
                sl, el = st["calc_from"], st["calc_to"]
                if (any(k in sl.lower() for k in end_kw)
                        and any(k in el.lower() for k in start_kw)):
                    sl, el = el, sl
                dur = self._hhmm_dur((ans.get(sl) or {}).get("value", ""),
                                     (ans.get(el) or {}).get("value", ""))
                if not dur:
                    continue
                cur = conn.execute(
                    "SELECT id FROM process_answers WHERE run_id=? AND label=? LIMIT 1",
                    (rid, st["label"])).fetchone()
                if cur:
                    conn.execute("UPDATE process_answers SET value=? WHERE id=?",
                                 (dur, cur["id"]))
                else:
                    conn.execute(
                        "INSERT INTO process_answers(run_id, label, kind, value, photo, "
                        "staff_id, staff_name, sort_order) VALUES(?,?,'duration',?,'',0,'',?)",
                        (rid, st["label"], dur, st["sort_order"]))

    def process_run_answers(self, run_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT label, kind, value, photo, staff_id, staff_name, sort_order "
                "FROM process_answers WHERE run_id=? ORDER BY sort_order, id",
                (int(run_id),)).fetchall()
        return [dict(r) for r in rows]

    def record_process_answer(self, process_id: int, staff_id, staff_name,
                              label, kind, value, photo, sort_order) -> int:
        """Записати відповідь у СПІЛЬНИЙ прогін (ідемпотентно за міткою — якщо
        крок уже виконано кимось, не дублюємо). Повертає run_id."""
        rid = self.process_today_run(process_id, create=True)
        with self._connect() as conn:
            ex = conn.execute(
                "SELECT 1 FROM process_answers WHERE run_id=? AND label=? LIMIT 1",
                (rid, label)).fetchone()
            if not ex:
                conn.execute(
                    "INSERT INTO process_answers(run_id, label, kind, value, photo, "
                    "staff_id, staff_name, sort_order) VALUES(?,?,?,?,?,?,?,?)",
                    (rid, label, kind, str(value), photo or "",
                     int(staff_id or 0), staff_name or "", int(sort_order or 0)))
        return rid

    def process_answered_labels(self, process_id: int) -> set:
        """Мітки кроків, уже виконані сьогодні (будь-ким) у процесі."""
        rid = self.process_today_run(process_id, create=False)
        if not rid:
            return set()
        return {a["label"] for a in self.process_run_answers(rid)}

    def process_finalize_durations(self, process_id: int) -> None:
        """Порахувати обчислювані (duration) кроки процесу в спільному прогоні."""
        rid = self.process_today_run(process_id, create=False)
        if not rid:
            return
        steps = self.list_process_steps(process_id)
        ans = {a["label"]: a for a in self.process_run_answers(rid)}
        end_kw = ("стоп", "кінець", "кінц", "фініш", "завершен", "end")
        start_kw = ("старт", "початок", "поч", "start")
        with self._connect() as conn:
            for st in steps:
                if st["kind"] != "duration" or not (st["calc_from"] and st["calc_to"]):
                    continue
                sl, el = st["calc_from"], st["calc_to"]
                if (any(k in sl.lower() for k in end_kw)
                        and any(k in el.lower() for k in start_kw)):
                    sl, el = el, sl
                dur = self._hhmm_dur((ans.get(sl) or {}).get("value", ""),
                                     (ans.get(el) or {}).get("value", ""))
                if not dur:
                    continue
                cur = conn.execute(
                    "SELECT id FROM process_answers WHERE run_id=? AND label=? LIMIT 1",
                    (rid, st["label"])).fetchone()
                if cur:
                    conn.execute("UPDATE process_answers SET value=? WHERE id=?",
                                 (dur, cur["id"]))
                else:
                    conn.execute(
                        "INSERT INTO process_answers(run_id, label, kind, value, photo, "
                        "staff_id, staff_name, sort_order) VALUES(?,?,'duration',?,'',0,'',?)",
                        (rid, st["label"], dur, st["sort_order"]))

    # ── Журнал процесів (редагування спільних прогонів) ──────────────
    def process_runs_last_day(self) -> str:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT run_date FROM process_runs ORDER BY run_date DESC LIMIT 1").fetchone()
        return (row["run_date"] if row else "") or ""

    def process_journal(self, day: str) -> list[dict[str, Any]]:
        """Для журналу: по кожному процесу з кроками — УСІ прогони (доїння) за day,
        колонки=кроки, кожен прогін окремим рядком (значення+хто+id для редагування)."""
        day = (day or "").strip()[:10]
        out = []
        with self._connect() as conn:
            procs = conn.execute(
                "SELECT id, name FROM work_processes WHERE is_active=1 "
                "ORDER BY sort_order, id").fetchall()
            for p in procs:
                steps = self.list_process_steps(p["id"])
                if not steps:
                    continue
                runs = conn.execute(
                    "SELECT id FROM process_runs WHERE process_id=? AND run_date=? "
                    "ORDER BY id", (p["id"], day)).fetchall()
                rlist = []
                for i, r in enumerate(runs, 1):
                    answers = {}
                    for a in conn.execute(
                            "SELECT id, label, kind, value, photo, staff_name, sort_order "
                            "FROM process_answers WHERE run_id=?", (r["id"],)).fetchall():
                        answers[a["label"]] = dict(a)
                    rlist.append({"run_id": r["id"], "seq": i, "answers": answers})
                out.append({"process_id": p["id"], "name": p["name"],
                            "run_date": day, "steps": steps, "runs": rlist})
        return out

    def update_process_answer(self, answer_id: int, value: str) -> int:
        """Коригування спільної відповіді процесу з перевіркою за типом. Повертає
        process_id (для перерахунку duration)."""
        import re as _re
        val = str(value or "").strip()
        with self._connect() as conn:
            row = conn.execute(
                "SELECT a.kind, a.run_id, r.process_id FROM process_answers a "
                "JOIN process_runs r ON r.id=a.run_id WHERE a.id=?",
                (int(answer_id),)).fetchone()
            if not row:
                raise ValueError("Відповідь не знайдено.")
            kind = (row["kind"] or "").strip()
            if val:
                if kind == "number":
                    v = val.replace(",", ".")
                    try:
                        float(v)
                    except ValueError:
                        raise ValueError("Має бути число.")
                    val = v
                elif kind == "shift":
                    if not val.isdigit():
                        raise ValueError("Зміна — ціле число.")
                elif kind == "time":
                    m = _re.match(r"^(\d{1,2})[:.](\d{2})$", val)
                    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
                        raise ValueError("Час у форматі ГГ:ХХ.")
                    val = f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
                elif kind == "yesno":
                    if val not in ("Так", "Ні"):
                        raise ValueError("Лише «Так» або «Ні».")
            conn.execute("UPDATE process_answers SET value=? WHERE id=?",
                         (val, int(answer_id)))
            return int(row["process_id"] or 0)

    def delete_process_run(self, run_id: int) -> None:
        rid = int(run_id)
        with self._connect() as conn:
            conn.execute("DELETE FROM process_answers WHERE run_id=?", (rid,))
            conn.execute("DELETE FROM process_runs WHERE id=?", (rid,))

    def staff_started_day(self, staff_id: int) -> bool:
        """Чи зафіксував працівник СТАРТ ДНЯ сьогодні — тобто у своєму циклі ролі
        відповів на ПЕРШИЙ (не обчислюваний) крок. True також, якщо у ролі нема
        кроків (нема що фіксувати)."""
        staff_id = int(staff_id or 0)
        if not staff_id:
            return True
        today = self._now()[:10]
        with self._connect() as conn:
            srow = conn.execute("SELECT role FROM staff WHERE id=?", (staff_id,)).fetchone()
            role_name = (srow["role"] if srow else "") or ""
            rrow = conn.execute(
                "SELECT id FROM work_roles WHERE name=? AND is_active=1 LIMIT 1",
                (role_name,)).fetchone()
            if not rrow:
                return True
            first = conn.execute(
                "SELECT label FROM role_steps WHERE role_id=? AND kind<>'duration' "
                "ORDER BY sort_order, id LIMIT 1", (rrow["id"],)).fetchone()
            if not first:
                return True
            ans = conn.execute(
                "SELECT 1 FROM role_answers a JOIN role_runs r ON r.id=a.run_id "
                "WHERE r.staff_id=? AND substr(r.created_at,1,10)=? AND a.label=? "
                "AND (TRIM(a.value)<>'' OR TRIM(a.photo)<>'') LIMIT 1",
                (staff_id, today, first["label"])).fetchone()
        return bool(ans)

    def worker_menu_state(self, staff_id: int) -> dict[str, Any]:
        """Повний стан робочого дня працівника для послідовного меню бота.
        Підтримує КІЛЬКА змін за день: кожен завершений цикл ролі = окрема зміна
        (напр. 4 год вранці + 4 год ввечері). Поля:
          started  — почато хоч одну зміну (є відкрита або завершена);
          active   — є ВІДКРИТА (незавершена) зміна зараз;
          finished — усі зміни завершено, відкритої немає;
          shifts_done — скільки змін завершено сьогодні;
          sessions — [{start, stop, dur}] по завершених змінах;
          processes — стан спільних процесів."""
        staff_id = int(staff_id or 0)
        today = self._now()[:10]
        out: dict[str, Any] = {
            "started": False, "active": False, "finished": False,
            "shifts_done": 0, "start_time": "", "stop_time": "", "work_dur": "",
            "role_name": "", "sessions": [], "history": [], "processes": [], "roles": []}
        if not staff_id:
            return out
        try:
            shifts = int(self.get_setting("farm_shifts", "2") or "2")
        except (TypeError, ValueError):
            shifts = 2
        end_kw = ("стоп", "кінець", "кінц", "фініш", "завершен", "end")
        start_kw = ("старт", "початок", "поч", "start")
        with self._connect() as conn:
            srow = conn.execute("SELECT role FROM staff WHERE id=?", (staff_id,)).fetchone()
            role_name = (srow["role"] if srow else "") or ""
            out["role_name"] = role_name
            rrow = conn.execute(
                "SELECT id FROM work_roles WHERE name=? AND is_active=1 LIMIT 1",
                (role_name,)).fetchone()
            role_id = rrow["id"] if rrow else 0
            steps = conn.execute(
                "SELECT label, kind, calc_from, calc_to FROM role_steps "
                "WHERE role_id=? ORDER BY sort_order, id", (role_id,)).fetchall() if role_id else []
            non_dur = [s for s in steps if s["kind"] != "duration"]
            dur_step = next((s for s in steps if s["kind"] == "duration"
                             and "робоч" in (s["label"] or "").lower()), None)
            runs = conn.execute(
                "SELECT id FROM role_runs WHERE staff_id=? AND substr(created_at,1,10)=? "
                "ORDER BY id", (staff_id, today)).fetchall()
            total_min = 0
            for run in runs:
                ans: dict[str, str] = {}
                for a in conn.execute(
                        "SELECT label, value, photo FROM role_answers WHERE run_id=?",
                        (run["id"],)).fetchall():
                    if (a["value"] or "").strip() or (a["photo"] or "").strip():
                        ans[a["label"]] = a["value"] or ""
                if not ans:
                    continue
                complete = bool(non_dur) and all(s["label"] in ans for s in non_dur)
                if complete:
                    out["started"] = True
                    out["shifts_done"] += 1
                    start_v = ans.get(non_dur[0]["label"], "") if non_dur else ""
                    stop_v = ans.get(non_dur[-1]["label"], "") if non_dur else ""
                    dur = ""
                    if dur_step:
                        sl, el = dur_step["calc_from"], dur_step["calc_to"]
                        if (any(k in (sl or "").lower() for k in end_kw)
                                and any(k in (el or "").lower() for k in start_kw)):
                            sl, el = el, sl
                        dur = self._hhmm_dur(ans.get(sl, ""), ans.get(el, ""))
                    if not dur:
                        dur = self._hhmm_dur(start_v, stop_v)
                    if dur:
                        h, m = dur.split(":")
                        total_min += int(h) * 60 + int(m)
                    out["sessions"].append({"start": start_v, "stop": stop_v, "dur": dur})
                    out["stop_time"] = stop_v
                    if not out["start_time"]:
                        out["start_time"] = start_v
                elif non_dur and non_dur[0]["label"] in ans:
                    out["started"] = True
                    out["active"] = True
                    if not out["start_time"]:
                        out["start_time"] = ans.get(non_dur[0]["label"], "")
            # НІЧНА ЗМІНА: якщо сьогодні немає відкритої зміни, але ВЧОРА лишилась
            # незавершена (старт є, стоп ні) — вважаємо її активною (через північ).
            if not out["active"] and non_dur:
                yday = (datetime.strptime(today, "%Y-%m-%d")
                        - timedelta(days=1)).strftime("%Y-%m-%d")
                yrun = conn.execute(
                    "SELECT id FROM role_runs WHERE staff_id=? AND substr(created_at,1,10)=? "
                    "ORDER BY id DESC LIMIT 1", (staff_id, yday)).fetchone()
                if yrun:
                    yans = {a["label"]: (a["value"] or "") for a in conn.execute(
                        "SELECT label, value, photo FROM role_answers WHERE run_id=? "
                        "AND (TRIM(value)<>'' OR TRIM(photo)<>'')", (yrun["id"],)).fetchall()}
                    started_y = non_dur[0]["label"] in yans
                    complete_y = all(s["label"] in yans for s in non_dur)
                    if started_y and not complete_y:
                        out["started"] = True
                        out["active"] = True
                        out["night"] = True
                        out["start_time"] = yans.get(non_dur[0]["label"], "")
            if not non_dur:
                out["started"] = True
            out["finished"] = (out["shifts_done"] > 0) and not out["active"]
            if total_min:
                out["work_dur"] = f"{total_min // 60}:{total_min % 60:02d}"
            # процеси — за УСІМА ролями працівника (основна + додаткові)
            all_rids = [role_id] if role_id else []
            rid_names = {}
            if role_id:
                rid_names[role_id] = role_name
            for x in conn.execute(
                    "SELECT x.role_id AS rid, r.name FROM staff_extra_roles x "
                    "JOIN work_roles r ON r.id=x.role_id AND r.is_active=1 "
                    "WHERE x.staff_id=?", (staff_id,)).fetchall():
                if x["rid"] not in all_rids:
                    all_rids.append(x["rid"])
                rid_names[x["rid"]] = x["name"]
            proc_rows = []
            pr_roles = {}   # process_id -> [role_id працівника, що ним володіє]
            if all_rids:
                ph = ",".join("?" * len(all_rids))
                seen_pid = set()
                for row in conn.execute(
                        "SELECT DISTINCT p.id, p.name, p.sort_order "
                        "FROM work_process_roles pr "
                        "JOIN work_processes p ON p.id=pr.process_id AND p.is_active=1 "
                        f"WHERE pr.role_id IN ({ph}) ORDER BY p.sort_order, p.id",
                        all_rids).fetchall():
                    if row["id"] not in seen_pid:
                        seen_pid.add(row["id"])
                        proc_rows.append(row)
                for row in conn.execute(
                        "SELECT process_id, role_id FROM work_process_roles "
                        f"WHERE role_id IN ({ph})", all_rids).fetchall():
                    pr_roles.setdefault(row["process_id"], []).append(row["role_id"])
            roles_with_proc = set()
            for pr in proc_rows:
                if not conn.execute("SELECT 1 FROM process_steps WHERE process_id=? LIMIT 1",
                                    (pr["id"],)).fetchone():
                    continue
                runs = conn.execute(
                    "SELECT id FROM process_runs WHERE process_id=? AND run_date=? ORDER BY id",
                    (pr["id"], today)).fetchall()
                done = 0
                open_run = False
                who: list = []       # хто у ВІДКРИТОМУ прогоні (зайшов/вносив)
                starter = ""         # хто вніс перший крок відкритого прогону
                for rr in runs:
                    if self._process_run_complete(conn, rr["id"], pr["id"]):
                        done += 1
                        continue
                    has_data = conn.execute(
                        "SELECT 1 FROM process_answers WHERE run_id=? "
                        "AND (TRIM(value)<>'' OR TRIM(photo)<>'') LIMIT 1",
                        (rr["id"],)).fetchone()
                    joined = conn.execute(
                        "SELECT staff_name FROM process_run_participants "
                        "WHERE run_id=? ORDER BY rowid", (rr["id"],)).fetchall()
                    if has_data or joined:
                        open_run = True
                        for j in joined:
                            nm = (j["staff_name"] or "").strip()
                            if nm and nm not in who:
                                who.append(nm)
                        for a in conn.execute(
                                "SELECT staff_name, value, photo FROM process_answers "
                                "WHERE run_id=? ORDER BY id", (rr["id"],)).fetchall():
                            if not ((a["value"] or "").strip()
                                    or (a["photo"] or "").strip()):
                                continue
                            nm = (a["staff_name"] or "").strip()
                            if nm and not starter:
                                starter = nm
                            if nm and nm not in who:
                                who.append(nm)
                p_shifts = self.process_shifts(pr["id"])
                prids = pr_roles.get(pr["id"], [])
                roles_with_proc.update(prids)
                out["processes"].append({
                    "id": pr["id"], "name": pr["name"], "done": done,
                    "shifts": p_shifts, "all_done": done >= p_shifts,
                    "open": open_run, "who": who, "starter": starter,
                    "role_ids": prids})
            # УСІ ролі працівника (для вибору ролі в боті, коли їх кілька)
            out["roles"] = [{"id": rid, "name": rid_names.get(rid, "")}
                            for rid in all_rids if rid_names.get(rid)]
        return out

    def admin_day_summary(self) -> dict[str, Any]:
        """Зведення за сьогодні для адміна в боті: скільки почали/завершили день,
        стан процесів (виконано/зміни). Список працівників у роботі й завершених."""
        today = self._now()[:10]
        out: dict[str, Any] = {"date": today, "started": 0, "finished": 0, "total": 0,
                               "active": [], "done": [], "idle": [], "processes": []}
        with self._connect() as conn:
            staff = conn.execute(
                "SELECT id, name, role FROM staff WHERE is_active=1 ORDER BY name").fetchall()
            role_ids: dict[str, int] = {}
            for r in conn.execute("SELECT id, name FROM work_roles WHERE is_active=1").fetchall():
                role_ids[r["name"]] = r["id"]
            role_first: dict[int, list] = {}
            for rid in set(role_ids.values()):
                fr = conn.execute(
                    "SELECT label FROM role_steps WHERE role_id=? AND kind<>'duration' "
                    "ORDER BY sort_order, id", (rid,)).fetchall()
                role_first[rid] = [x["label"] for x in fr]
            for s in staff:
                rid = role_ids.get(s["role"] or "")
                labels = role_first.get(rid or 0, [])
                if not labels:
                    continue
                out["total"] += 1
                run = conn.execute(
                    "SELECT id FROM role_runs WHERE staff_id=? AND substr(created_at,1,10)=? "
                    "ORDER BY id DESC LIMIT 1", (s["id"], today)).fetchone()
                got = set()
                if run:
                    got = {a["label"] for a in conn.execute(
                        "SELECT label FROM role_answers WHERE run_id=? "
                        "AND (TRIM(value)<>'' OR TRIM(photo)<>'')", (run["id"],)).fetchall()}
                started = labels[0] in got
                finished = all(lbl in got for lbl in labels)
                if finished:
                    out["finished"] += 1
                    out["done"].append(s["name"])
                elif started:
                    out["started"] += 1
                    out["active"].append(s["name"])
                else:
                    out["idle"].append(s["name"])
            end_kw2 = ("стоп", "кінець", "кінц", "фініш", "завершен", "end")
            start_kw2 = ("старт", "початок", "поч", "start")
            for p in conn.execute(
                    "SELECT id, name FROM work_processes WHERE is_active=1 "
                    "ORDER BY sort_order, id").fetchall():
                psteps = conn.execute(
                    "SELECT label, kind, calc_from, calc_to FROM process_steps "
                    "WHERE process_id=? ORDER BY sort_order, id", (p["id"],)).fetchall()
                if not psteps:
                    continue
                time_lbls = [s["label"] for s in psteps if s["kind"] == "time"]
                dur_lbls = [s for s in psteps if s["kind"] == "duration"]
                runs = conn.execute(
                    "SELECT id FROM process_runs WHERE process_id=? AND run_date=? ORDER BY id",
                    (p["id"], today)).fetchall()
                done, open_run, who, run_rows = 0, False, [], []
                for i, rr in enumerate(runs, 1):
                    amap = {}
                    who_run = []   # хто працював саме на ЦЬОМУ прогоні (зміні)
                    for pt in conn.execute(
                            "SELECT staff_name FROM process_run_participants "
                            "WHERE run_id=? ORDER BY rowid", (rr["id"],)).fetchall():
                        nm = (pt["staff_name"] or "").strip()
                        if nm and nm not in who_run:
                            who_run.append(nm)
                    for a in conn.execute(
                            "SELECT label, value, photo, staff_name FROM process_answers "
                            "WHERE run_id=?", (rr["id"],)).fetchall():
                        amap[a["label"]] = a["value"]
                        nm = (a["staff_name"] or "").strip()
                        if nm and ((a["value"] or "").strip() or (a["photo"] or "").strip()) \
                                and nm not in who_run:
                            who_run.append(nm)
                    for nm in who_run:
                        if nm not in who:
                            who.append(nm)
                    if self._process_run_complete(conn, rr["id"], p["id"]):
                        done += 1
                    elif any((amap.get(l) or "").strip() for l in amap):
                        open_run = True
                    # старт/стоп/тривалість цього прогону
                    start_v = amap.get(time_lbls[0], "") if time_lbls else ""
                    stop_v = amap.get(time_lbls[-1], "") if len(time_lbls) > 1 else ""
                    dur = ""
                    for ds in dur_lbls:
                        dur = (amap.get(ds["label"]) or "").strip()
                        if not dur:
                            sl, el = ds["calc_from"], ds["calc_to"]
                            if (any(k in (sl or "").lower() for k in end_kw2)
                                    and any(k in (el or "").lower() for k in start_kw2)):
                                sl, el = el, sl
                            dur = self._hhmm_dur(amap.get(sl, ""), amap.get(el, ""))
                        if dur:
                            break
                    if not dur and start_v and stop_v:
                        dur = self._hhmm_dur(start_v, stop_v)
                    if start_v or stop_v or who_run:
                        run_rows.append({"seq": i, "start": start_v, "stop": stop_v,
                                         "dur": dur, "who": who_run})
                out["processes"].append({"name": p["name"], "done": done,
                                         "open": open_run, "who": who,
                                         "runs": run_rows})
        return out

    def staff_extra_roles(self, staff_id: int) -> list[dict[str, Any]]:
        """Додаткові ролі працівника: [{id, name}, …]."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT r.id, r.name FROM staff_extra_roles x "
                "JOIN work_roles r ON r.id=x.role_id AND r.is_active=1 "
                "WHERE x.staff_id=? ORDER BY r.name", (int(staff_id),)).fetchall()
        return [dict(r) for r in rows]

    def set_staff_extra_roles(self, staff_id: int, role_ids: list) -> None:
        """Задати повний список додаткових ролей працівника."""
        sid = int(staff_id)
        ids = sorted({int(r) for r in (role_ids or []) if int(r or 0) > 0})
        with self._connect() as conn:
            conn.execute("DELETE FROM staff_extra_roles WHERE staff_id=?", (sid,))
            conn.executemany(
                "INSERT OR IGNORE INTO staff_extra_roles(staff_id, role_id) VALUES(?,?)",
                [(sid, rid) for rid in ids])

    def staff_all_role_ids(self, staff_id: int) -> list[int]:
        """Усі ролі працівника: основна (staff.role) + додаткові. [role_id, …]."""
        sid = int(staff_id or 0)
        if not sid:
            return []
        out = []
        with self._connect() as conn:
            srow = conn.execute("SELECT role FROM staff WHERE id=?", (sid,)).fetchone()
            if srow and (srow["role"] or "").strip():
                rr = conn.execute(
                    "SELECT id FROM work_roles WHERE name=? AND is_active=1 LIMIT 1",
                    (srow["role"],)).fetchone()
                if rr:
                    out.append(rr["id"])
            for x in conn.execute(
                    "SELECT x.role_id FROM staff_extra_roles x "
                    "JOIN work_roles r ON r.id=x.role_id AND r.is_active=1 "
                    "WHERE x.staff_id=?", (sid,)).fetchall():
                if x["role_id"] not in out:
                    out.append(x["role_id"])
        return out

    def processes_for_staff(self, staff_id: int) -> list[dict[str, Any]]:
        """Процеси з кроками за УСІМА ролями працівника (основна + додаткові)."""
        seen, out = set(), []
        for rid in self.staff_all_role_ids(staff_id):
            for p in self.processes_for_role(rid):
                if p["id"] not in seen:
                    seen.add(p["id"])
                    out.append(p)
        return out

    def processes_for_role(self, role_id: int) -> list[dict[str, Any]]:
        """Усі активні процеси з кроками, до яких належить роль. [{id,name},…]."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.id, p.name FROM work_process_roles pr "
                "JOIN work_processes p ON p.id = pr.process_id AND p.is_active=1 "
                "WHERE pr.role_id=? ORDER BY p.sort_order, p.id",
                (int(role_id),)).fetchall()
        out = []
        for r in rows:
            if self.list_process_steps(r["id"]):
                out.append({"id": r["id"], "name": r["name"]})
        return out

    def process_get(self, pid: int) -> Optional[dict[str, Any]]:
        """Процес із кроками за id (для запуску з кнопки). None, якщо нема кроків."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, name FROM work_processes WHERE id=? AND is_active=1",
                (int(pid),)).fetchone()
        if not row:
            return None
        steps = self.list_process_steps(row["id"])
        if not steps:
            return None
        return {"id": row["id"], "name": row["name"], "steps": steps}

    def process_by_role_id(self, role_id: int) -> Optional[dict[str, Any]]:
        """Процес (з кроками), до якого належить роль. Якщо роль у кількох
        процесах — беремо перший, що МАЄ кроки. None, якщо кроків ніде нема."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.id, p.name FROM work_process_roles pr "
                "JOIN work_processes p ON p.id = pr.process_id AND p.is_active=1 "
                "WHERE pr.role_id=? ORDER BY p.sort_order, p.id",
                (int(role_id),)).fetchall()
        for row in rows:
            steps = self.list_process_steps(row["id"])
            if steps:
                return {"id": row["id"], "name": row["name"], "steps": steps}
        return None

    def role_by_name(self, name: str) -> Optional[dict[str, Any]]:
        """Активна роль за назвою (для звʼязку staff.role → цикл)."""
        name = (name or "").strip()
        if not name:
            return None
        with self._connect() as conn:
            r = conn.execute(
                "SELECT id, name FROM work_roles WHERE name=? AND is_active=1 "
                "ORDER BY id LIMIT 1", (name,)).fetchone()
        return dict(r) if r else None

    # ---- прогони циклу (Telegram-опитування) ----
    def create_role_run(self, role_id: int, role_name: str, staff_id: int,
                        staff_name: str, tg_id: str) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO role_runs(role_id, role_name, staff_id, staff_name, "
                "tg_id, run_date, created_at) VALUES(?,?,?,?,?,?,?)",
                (int(role_id or 0), (role_name or "").strip(), int(staff_id or 0),
                 (staff_name or "").strip(), str(tg_id or "").strip(),
                 self._now()[:10], self._now()))
            return cur.lastrowid

    def add_role_answer(self, run_id: int, label: str, kind: str,
                       value: str = "", photo: str = "", sort_order: int = 0) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO role_answers(run_id, label, kind, value, photo, sort_order) "
                "VALUES(?,?,?,?,?,?)",
                (int(run_id), (label or "").strip(), (kind or "").strip(),
                 str(value or ""), (photo or "").strip(), int(sort_order or 0)))

    def set_role_answer_value(self, run_id: int, label: str, value: str) -> None:
        """Оновити значення відповіді за міткою (для обчислюваних кроків)."""
        with self._connect() as conn:
            conn.execute("UPDATE role_answers SET value=? WHERE run_id=? AND label=?",
                         (str(value or ""), int(run_id), (label or "").strip()))

    def delete_role_answer(self, run_id: int, label: str) -> None:
        """Прибрати відповідь кроку (для «Крок назад» — перевнесення з чистого)."""
        with self._connect() as conn:
            conn.execute("DELETE FROM role_answers WHERE run_id=? AND label=?",
                         (int(run_id or 0), (label or "").strip()))

    def delete_process_answer(self, run_id: int, label: str) -> None:
        """Прибрати відповідь спільного кроку процесу (для «Крок назад»)."""
        with self._connect() as conn:
            conn.execute("DELETE FROM process_answers WHERE run_id=? AND label=?",
                         (int(run_id or 0), (label or "").strip()))

    def list_role_runs(self, limit: int = 15, day: str = "") -> list[dict[str, Any]]:
        """Прогони з блоком працівника. Якщо day='РРРР-ММ-ДД' — лише за цей день
        (без ліміту 15), інакше — останні `limit` прогонів."""
        day = (day or "").strip()[:10]
        sel = ("SELECT r.id, r.role_name, r.staff_name, r.tg_id, r.run_date, "
               "r.created_at, r.staff_id, b.sort_order AS block_no, "
               "b.name AS block_name, "
               "(SELECT COUNT(*) FROM role_answers a WHERE a.run_id=r.id) AS n "
               "FROM role_runs r "
               "LEFT JOIN staff s ON s.id = r.staff_id AND s.is_active=1 "
               "LEFT JOIN staff_blocks b ON b.id = s.block_id AND b.is_active=1 ")
        with self._connect() as conn:
            if day:
                rows = conn.execute(
                    sel + "WHERE substr(r.created_at,1,10)=? ORDER BY r.id DESC",
                    (day,)).fetchall()
            else:
                rows = conn.execute(
                    sel + "ORDER BY r.id DESC LIMIT ?", (int(limit or 15),)).fetchall()
        return [dict(r) for r in rows]

    def role_runs_last_day(self) -> str:
        """Остання дата, за яку є прогони (для дефолту перемикача)."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT substr(created_at,1,10) d FROM role_runs "
                "ORDER BY created_at DESC LIMIT 1").fetchone()
        return (row["d"] if row else "") or ""

    def delete_role_run(self, run_id: int) -> None:
        """Видалити прогін циклу разом із його відповідями (адмін-чистка журналу)."""
        rid = int(run_id)
        with self._connect() as conn:
            conn.execute("DELETE FROM role_answers WHERE run_id=?", (rid,))
            conn.execute("DELETE FROM role_runs WHERE id=?", (rid,))

    def update_role_run(self, run_id: int, created_at: str = None,
                        staff_name: str = None) -> None:
        """Коригування шапки прогону адміном: дата/час (created_at) і хто (staff_name)."""
        sets, params = [], []
        if created_at is not None:
            ca = str(created_at).replace("T", " ").strip()
            if len(ca) == 16:            # 'РРРР-ММ-ДД ГГ:ХХ' → додати секунди
                ca += ":00"
            sets.append("created_at=?"); params.append(ca)
            sets.append("run_date=?"); params.append(ca[:10])
        if staff_name is not None:
            sets.append("staff_name=?"); params.append(str(staff_name).strip())
        if not sets:
            return
        params.append(int(run_id))
        with self._connect() as conn:
            conn.execute(f"UPDATE role_runs SET {', '.join(sets)} WHERE id=?", params)

    def find_incomplete_run(self, role_id: int, tg_id: str,
                           step_count: int) -> Optional[dict[str, Any]]:
        """Останній НЕзавершений прогін працівника за роллю за ОСТАННІ 2 ДНІ:
        має хоч одну відповідь, але менше, ніж кроків. Вікно 2 дні — щоб нічна
        зміна (через північ) закривалась наступного ранку (належить дню старту)."""
        today = self._now()[:10]
        yday = (datetime.strptime(today, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        with self._connect() as conn:
            r = conn.execute(
                "SELECT r.id, (SELECT COUNT(*) FROM role_answers a WHERE a.run_id=r.id) "
                "AS answered FROM role_runs r "
                "WHERE r.role_id=? AND r.tg_id=? AND substr(r.created_at,1,10)>=? "
                "ORDER BY r.id DESC LIMIT 1",
                (int(role_id), str(tg_id or "").strip(), yday)).fetchone()
        if not r:
            return None
        answered = int(r["answered"] or 0)
        if 0 < answered < int(step_count):
            return {"id": r["id"], "answered": answered}
        return None

    def role_run_answers(self, run_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, label, kind, value, photo, sort_order FROM role_answers "
                "WHERE run_id=? ORDER BY sort_order, id", (int(run_id),)).fetchall()
        return [dict(r) for r in rows]

    def update_role_answer(self, answer_id: int, value: str) -> int:
        """Коригування відповіді в журналі із перевіркою за типом кроку.
        Порожнє значення дозволено (очищення). Невірний формат → ValueError.
        Повертає run_id відповіді (для перерахунку обчислюваних кроків)."""
        import re as _re
        val = str(value or "").strip()
        with self._connect() as conn:
            row = conn.execute("SELECT kind, run_id FROM role_answers WHERE id=?",
                               (int(answer_id),)).fetchone()
            if not row:
                raise ValueError("Відповідь не знайдено.")
            kind = (row["kind"] or "").strip()
            if val:                       # порожнє = очистити, без перевірки
                if kind == "number":
                    v = val.replace(",", ".")
                    try:
                        float(v)
                    except ValueError:
                        raise ValueError("Має бути число.")
                    val = v
                elif kind == "shift":
                    if not val.isdigit():
                        raise ValueError("Зміна — ціле число.")
                    try:
                        nmax = int(self.get_setting("farm_shifts", "2") or "2")
                    except (TypeError, ValueError):
                        nmax = 2
                    nmax = max(1, min(3, nmax))
                    if not (1 <= int(val) <= nmax):
                        raise ValueError(f"Зміна від 1 до {nmax}.")
                elif kind == "time":
                    m = _re.match(r"^(\d{1,2})[:.](\d{2})$", val)
                    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
                        raise ValueError("Час у форматі ГГ:ХХ.")
                    val = f"{int(m.group(1)):02d}:{int(m.group(2)):02d}"
                elif kind == "yesno":
                    if val not in ("Так", "Ні"):
                        raise ValueError("Лише «Так» або «Ні».")
            conn.execute("UPDATE role_answers SET value=? WHERE id=?",
                         (val, int(answer_id)))
            return int(row["run_id"] or 0)

    def list_herd_groups(self) -> list[dict[str, Any]]:
        """Активні групи класифікації стада (за порядком користувача)."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name, sort_order, profeed_block_id, profeed_group, "
                "herd_kind, subgroup FROM herd_groups WHERE is_active = 1 "
                "ORDER BY sort_order, id").fetchall()
        return [dict(r) for r in rows]

    def get_herd_year(self, year) -> dict[str, Any]:
        """Групи + помісячні цифри за рік. counts: {'<gid>-<month>': headcount}."""
        try:
            year = int(year)
        except (TypeError, ValueError):
            year = 0
        groups = self.list_herd_groups()
        counts: dict[str, float] = {}
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT c.group_id, c.month, c.headcount FROM herd_counts c "
                "JOIN herd_groups g ON g.id = c.group_id "
                "WHERE c.year = ? AND g.is_active = 1", (year,)).fetchall()
        for r in rows:
            counts["%d-%d" % (r["group_id"], r["month"])] = r["headcount"]
        # Рух поголів'я — така сама сітка: типи (рядки) × місяці.
        mcounts: dict[str, float] = {}
        with self._connect() as conn:
            mrows = conn.execute(
                "SELECT c.type_id, c.month, c.headcount FROM herd_move_counts c "
                "JOIN herd_move_types t ON t.id = c.type_id "
                "WHERE c.year = ? AND t.is_active = 1", (year,)).fetchall()
        for r in mrows:
            mcounts["%d-%d" % (r["type_id"], r["month"])] = r["headcount"]
        return {"year": year, "groups": groups, "counts": counts,
                "move_types": self.list_move_types(), "move_counts": mcounts}

    # --- рух поголів'я: типи (рядки) × місяці — так само, як поголів'я ---
    def list_move_types(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name FROM herd_move_types WHERE is_active = 1 "
                "ORDER BY sort_order, id").fetchall()
        return [dict(r) for r in rows]

    def save_herd_moves(self, year, types: list, deleted: list = None) -> dict[str, Any]:
        """Зберегти типи руху (назви/порядок/додавання/видалення) і помісячні
        цифри за рік — дзеркало save_herd для груп поголів'я."""
        try:
            year = int(year)
        except (TypeError, ValueError):
            raise ValueError("Невірний рік")
        with self._connect() as conn:
            for tid in (deleted or []):
                try:
                    tid = int(tid)
                except (TypeError, ValueError):
                    continue
                conn.execute("UPDATE herd_move_types SET is_active = 0 WHERE id = ?", (tid,))
            pos = 0
            for t in (types or []):
                name = (t.get("name") or "").strip()
                if not name:
                    continue
                pos += 1
                tid = t.get("id")
                if tid:
                    tid = int(tid)
                    conn.execute("UPDATE herd_move_types SET name = ?, sort_order = ? WHERE id = ?",
                                 (name, pos, tid))
                else:
                    cur = conn.execute(
                        "INSERT INTO herd_move_types (name, sort_order, created_at) VALUES (?,?,?)",
                        (name, pos, self._now()))
                    tid = int(cur.lastrowid)
                counts = t.get("counts") or []
                for i in range(12):
                    val = max(0.0, self._to_float(counts[i], 0)) if i < len(counts) else 0.0
                    conn.execute(
                        "INSERT OR REPLACE INTO herd_move_counts "
                        "(type_id, year, month, headcount, updated_at) VALUES (?,?,?,?,?)",
                        (tid, year, i + 1, val, self._now()))
        return self.get_herd_year(year)

    def save_herd(self, year, groups: list, deleted: list = None) -> dict[str, Any]:
        """Зберегти класифікацію (назви/порядок/додавання/видалення) і помісячні
        цифри за рік одним викликом. groups: [{id|null, name, counts:[12]}].
        Порядок у списку визначає sort_order. Повертає свіжий стан року."""
        try:
            year = int(year)
        except (TypeError, ValueError):
            raise ValueError("Невірний рік")
        with self._connect() as conn:
            for gid in (deleted or []):
                try:
                    gid = int(gid)
                except (TypeError, ValueError):
                    continue
                conn.execute("UPDATE herd_groups SET is_active = 0 WHERE id = ?", (gid,))
            pos = 0
            for g in (groups or []):
                name = (g.get("name") or "").strip()
                if not name:
                    continue
                pos += 1
                gid = g.get("id")
                pb = g.get("profeed_block_id")
                pb = int(pb) if pb not in (None, "", 0, "0") else None
                if gid:
                    gid = int(gid)
                    conn.execute("UPDATE herd_groups SET name = ?, sort_order = ?, "
                                 "profeed_block_id = ? WHERE id = ?", (name, pos, pb, gid))
                else:
                    cur = conn.execute(
                        "INSERT INTO herd_groups (name, sort_order, created_at, profeed_block_id) "
                        "VALUES (?,?,?,?)", (name, pos, self._now(), pb))
                    gid = int(cur.lastrowid)
                counts = g.get("counts") or []
                for i in range(12):
                    val = max(0.0, self._to_float(counts[i], 0)) if i < len(counts) else 0.0
                    conn.execute(
                        "INSERT OR REPLACE INTO herd_counts "
                        "(group_id, year, month, headcount, updated_at) VALUES (?,?,?,?,?)",
                        (gid, year, i + 1, val, self._now()))
        return self.get_herd_year(year)

    # --- секції стада з періодами (поденне поголів'я + статус з-по) ---
    def list_herd_sections(self) -> list[dict[str, Any]]:
        """Секції стада + їх періоди (дата з-по, статус, поголів'я)."""
        sections = self.list_herd_groups()   # id, name, sort_order, profeed_block_id
        with self._connect() as conn:
            prows = conn.execute(
                "SELECT id, section_id, date_from, date_to, status, herd_kind, subgroup, "
                "profeed_group, headcount, eat_coef FROM herd_section_periods "
                "ORDER BY date_from, id").fetchall()
        by_sec: dict[int, list] = {}
        for r in prows:
            by_sec.setdefault(r["section_id"], []).append({
                "id": r["id"], "date_from": r["date_from"], "date_to": r["date_to"],
                "status": r["status"], "herd_kind": r["herd_kind"], "subgroup": r["subgroup"],
                "profeed_group": r["profeed_group"], "headcount": r["headcount"],
                "eat_coef": r["eat_coef"] if r["eat_coef"] is not None else 1})
        for s in sections:
            s["periods"] = by_sec.get(s["id"], [])
        return sections

    def save_herd_sections(self, sections: list, deleted: list = None) -> dict[str, Any]:
        """Зберегти секції + їх періоди одним викликом. sections: [{id|null, name,
        profeed_block_id, periods:[{date_from,date_to,status,headcount}]}].
        Періоди повністю перезаписуються для кожної секції."""
        # Блоки роздачі (Група-N) гарантуємо ДО відкриття транзакції — add_block
        # тримає власне зʼєднання, а вкладене писання у WAL дає «database locked».
        # Секція Profeed тепер задається в КОЖНОМУ періоді (з дати по дату).
        pb_by_label: dict[str, int] = {}
        for s in (sections or []):
            labels = [(s.get("profeed_group") or "").strip()]
            labels += [(p.get("profeed_group") or "").strip() for p in (s.get("periods") or [])]
            for pg in labels:
                if pg and pg not in pb_by_label:
                    pb_by_label[pg] = self.add_block(name=pg, category="feed")
        with self._connect() as conn:
            for sid in (deleted or []):
                try:
                    sid = int(sid)
                except (TypeError, ValueError):
                    continue
                conn.execute("UPDATE herd_groups SET is_active = 0 WHERE id = ?", (sid,))
                conn.execute("DELETE FROM herd_section_periods WHERE section_id = ?", (sid,))
            pos = 0
            for s in (sections or []):
                name = (s.get("name") or "").strip()
                if not name:
                    continue
                pos += 1
                # Секція вказує на роздачу Profeed за міткою (Група-1…). Блок
                # роздачі з такою назвою гарантуємо в довіднику — на нього
                # лягають списання й аналітика.
                pg = (s.get("profeed_group") or "").strip()
                pb = pb_by_label.get(pg) if pg else None
                sid = s.get("id")
                if sid:
                    sid = int(sid)
                    conn.execute("UPDATE herd_groups SET name=?, sort_order=?, "
                                 "profeed_group=?, profeed_block_id=? WHERE id=?",
                                 (name, pos, pg, pb, sid))
                else:
                    cur = conn.execute(
                        "INSERT INTO herd_groups (name, sort_order, created_at, "
                        "profeed_group, profeed_block_id) VALUES (?,?,?,?,?)",
                        (name, pos, self._now(), pg, pb))
                    sid = int(cur.lastrowid)
                conn.execute("DELETE FROM herd_section_periods WHERE section_id = ?", (sid,))
                for p in (s.get("periods") or []):
                    hc = max(0.0, self._to_float(p.get("headcount"), 0))
                    # eat_coef несе частку підкатегорії у групі (%). Порожнє = 0
                    # → рівний поділ між частками (голови додамо пізніше).
                    coef = max(0.0, self._to_float(p.get("eat_coef"), 0))
                    df = (p.get("date_from") or "").strip()[:10]
                    dt = (p.get("date_to") or "").strip()[:10]
                    st = (p.get("status") or "").strip()
                    kind = p.get("herd_kind") if p.get("herd_kind") in ("cow", "young") else ""
                    sub = (p.get("subgroup") or "").strip()
                    ppg = (p.get("profeed_group") or "").strip()
                    if not (df or dt or st or kind or sub or hc or coef or ppg):
                        continue
                    conn.execute(
                        "INSERT INTO herd_section_periods "
                        "(section_id, date_from, date_to, status, herd_kind, subgroup, "
                        "profeed_group, headcount, eat_coef) VALUES (?,?,?,?,?,?,?,?,?)",
                        (sid, df, dt, st, kind, sub, ppg, hc, coef))
        return {"sections": self.list_herd_sections()}

    def autocreate_sections_from_profeed(self, folder: str) -> dict[str, Any]:
        """Створити секції за роздачами Profeed. Скануємо звіти годівлі, беремо
        унікальні роздачі (Дійні, Сухостій, Молодняк, Телята…) і заводимо секцію
        на кожну (name = роздача, profeed_block_id = зіставлений блок). Наявні
        (за назвою) не дублюємо."""
        scan = self.scan_profeed_feedings(folder)
        if scan.get("error"):
            return scan
        existing = {(s["name"] or "").strip().casefold() for s in self.list_herd_groups()}
        seen, created = {}, []
        for it in scan.get("items", []):
            label = (it.get("group_label") or "").strip()
            if not label or label.casefold() in seen:
                continue
            seen[label.casefold()] = True
            if label.casefold() in existing:
                continue
            # Блок роздачі (Група-N) має існувати для списання й аналітики —
            # заводимо його в довіднику Годівлі, якщо ще немає, і лінкуємо секцію.
            bid = it.get("block_id") or self.add_block(name=label, category="feed")
            with self._connect() as conn:
                cur = conn.execute(
                    "INSERT INTO herd_groups (name, sort_order, created_at, "
                    "profeed_group, profeed_block_id) "
                    "VALUES (?, (SELECT COALESCE(MAX(sort_order),0)+1 FROM herd_groups), ?, ?, ?)",
                    (label, self._now(), label, bid))
                # Період за замовчуванням із міткою Profeed (без дат — діє завжди),
                # щоб секція одразу зіставлялась із роздачею.
                conn.execute(
                    "INSERT INTO herd_section_periods (section_id, profeed_group) "
                    "VALUES (?, ?)", (int(cur.lastrowid), label))
            created.append({"id": int(cur.lastrowid), "name": label,
                            "profeed_group": label, "profeed_block_id": bid})
        return {"created": created, "created_count": len(created),
                "sections": self.list_herd_sections()}

    # ── Поголівний облік (реєстр тварин) ────────────────────────────────
    ANIMAL_STATUSES = {
        "active": "В стаді", "sold": "Продано",
        "culled": "Вибракувано", "dead": "Загинуло",
    }
    _EVENT_CATS = {"repro", "health", "move", "prod", "other"}

    @staticmethod
    def _age_months(birth_date: str) -> Optional[float]:
        b = (birth_date or "").strip()[:10]
        if len(b) < 10:
            return None
        try:
            by, bm, bd = int(b[:4]), int(b[5:7]), int(b[8:10])
            today = date.today()
            months = (today.year - by) * 12 + (today.month - bm)
            if today.day < bd:
                months -= 1
            return max(0, months)
        except Exception:  # noqa: BLE001
            return None

    def _animal_row(self, r) -> dict[str, Any]:
        d = dict(r)
        d["status_label"] = self.ANIMAL_STATUSES.get(d.get("status"), d.get("status") or "")
        d["age_months"] = self._age_months(d.get("birth_date"))
        return d

    def list_animals(self, q: str = "", status: str = "", group_id=None,
                     sex: str = "") -> list[dict[str, Any]]:
        """Список тварин із фільтрами. group — назва секції."""
        where, params = [], []
        q = (q or "").strip()
        if q:
            where.append("(a.tag LIKE ? OR a.name LIKE ? OR a.dam_tag LIKE ? "
                         "OR a.sire_code LIKE ?)")
            params += [f"%{q}%"] * 4
        if status:
            where.append("a.status = ?"); params.append(status)
        if sex in ("F", "M"):
            where.append("a.sex = ?"); params.append(sex)
        if group_id:
            where.append("a.group_id = ?"); params.append(int(group_id))
        sql = ("SELECT a.*, g.name AS group_name FROM herd_animals a "
               "LEFT JOIN herd_groups g ON g.id = a.group_id")
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY CASE a.status WHEN 'active' THEN 0 ELSE 1 END, a.tag"
        with self._connect() as conn:
            return [self._animal_row(r) for r in conn.execute(sql, params).fetchall()]

    def herd_animal_stats(self) -> dict[str, Any]:
        """Зведення для шапки: усього в стаді, по статі, по секціях."""
        with self._connect() as conn:
            by_status = {r["status"]: r["c"] for r in conn.execute(
                "SELECT status, COUNT(*) c FROM herd_animals GROUP BY status").fetchall()}
            active = conn.execute(
                "SELECT COUNT(*) FROM herd_animals WHERE status='active'").fetchone()[0]
            cows = conn.execute(
                "SELECT COUNT(*) FROM herd_animals WHERE status='active' AND sex='F'"
            ).fetchone()[0]
        return {"active": active, "cows": cows, "by_status": by_status}

    def get_animal(self, animal_id: int) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            r = conn.execute(
                "SELECT a.*, g.name AS group_name FROM herd_animals a "
                "LEFT JOIN herd_groups g ON g.id = a.group_id WHERE a.id = ?",
                (int(animal_id),)).fetchone()
            if not r:
                return None
            d = self._animal_row(r)
            d["events"] = [dict(e) for e in conn.execute(
                "SELECT * FROM herd_animal_events WHERE animal_id = ? "
                "ORDER BY event_date DESC, id DESC", (int(animal_id),)).fetchall()]
            # Родовід: мама (за биркою), нащадки (де ця тварина — мама)
            dam = None
            if (d.get("dam_tag") or "").strip():
                dr = conn.execute("SELECT id, tag, name FROM herd_animals WHERE tag = ?",
                                  (d["dam_tag"].strip(),)).fetchone()
                dam = dict(dr) if dr else None
            d["dam"] = dam
            d["offspring"] = [dict(o) for o in conn.execute(
                "SELECT id, tag, name, sex, birth_date FROM herd_animals "
                "WHERE dam_tag = ? AND dam_tag <> '' ORDER BY birth_date DESC",
                (d.get("tag") or "\x00",)).fetchall()]
        return d

    def _animal_fields(self, data: dict) -> dict[str, Any]:
        sex = (data.get("sex") or "F").strip().upper()
        return {
            "tag": (data.get("tag") or "").strip(),
            "name": (data.get("name") or "").strip(),
            "sex": "M" if sex == "M" else "F",
            "birth_date": (data.get("birth_date") or "").strip()[:10],
            "breed": (data.get("breed") or "").strip(),
            "status": (data.get("status") or "active").strip() or "active",
            "group_id": int(data["group_id"]) if str(data.get("group_id") or "").strip().isdigit() else None,
            "dam_tag": (data.get("dam_tag") or "").strip(),
            "sire_code": (data.get("sire_code") or "").strip(),
            "source": (data.get("source") or "").strip(),
            "entry_date": (data.get("entry_date") or "").strip()[:10],
            "exit_date": (data.get("exit_date") or "").strip()[:10],
            "exit_reason": (data.get("exit_reason") or "").strip(),
            "lactation_no": int(self._to_float(data.get("lactation_no"), 0)),
            "notes": (data.get("notes") or "").strip(),
        }

    def add_animal(self, data: dict) -> dict[str, Any]:
        f = self._animal_fields(data)
        if not f["tag"]:
            raise ValueError("Вкажіть бирку (номер) тварини.")
        now = self._now()
        with self._connect() as conn:
            if conn.execute("SELECT 1 FROM herd_animals WHERE tag = ?", (f["tag"],)).fetchone():
                raise ValueError(f"Тварина з биркою «{f['tag']}» вже існує.")
            cols = ", ".join(f.keys())
            ph = ", ".join("?" for _ in f)
            cur = conn.execute(
                f"INSERT INTO herd_animals ({cols}, created_at, updated_at) "
                f"VALUES ({ph}, ?, ?)", (*f.values(), now, now))
            conn.execute("UPDATE herd_animals SET lactation_base=? WHERE id=?",
                         (f["lactation_no"], int(cur.lastrowid)))
            return {"id": int(cur.lastrowid)}

    def update_animal(self, animal_id: int, data: dict) -> dict[str, Any]:
        f = self._animal_fields(data)
        if not f["tag"]:
            raise ValueError("Вкажіть бирку (номер) тварини.")
        with self._connect() as conn:
            dup = conn.execute("SELECT 1 FROM herd_animals WHERE tag = ? AND id <> ?",
                               (f["tag"], int(animal_id))).fetchone()
            if dup:
                raise ValueError(f"Інша тварина з биркою «{f['tag']}» вже є.")
            sets = ", ".join(f"{k} = ?" for k in f)
            conn.execute(f"UPDATE herd_animals SET {sets}, updated_at = ? WHERE id = ?",
                         (*f.values(), self._now(), int(animal_id)))
            # людина виправила № лактації → це нова БАЗА: відняти вже
            # проведені отели, щоб перерахунок відтворював саме введене число
            calvings = conn.execute(
                "SELECT COUNT(*) FROM herd_animal_events e "
                "JOIN herd_event_defs d ON d.id=e.event_def_id "
                "WHERE e.animal_id=? AND d.key='calving'", (int(animal_id),)).fetchone()[0]
            conn.execute("UPDATE herd_animals SET lactation_base=? WHERE id=?",
                         (max(0, f["lactation_no"] - int(calvings)), int(animal_id)))
        return {"id": int(animal_id)}

    def set_animal_status(self, animal_id: int, status: str,
                          exit_date: str = "", exit_reason: str = "") -> dict[str, Any]:
        status = (status or "").strip()
        if status not in self.ANIMAL_STATUSES:
            raise ValueError("Невідомий статус.")
        with self._connect() as conn:
            conn.execute(
                "UPDATE herd_animals SET status=?, exit_date=?, exit_reason=?, updated_at=? "
                "WHERE id=?",
                (status, (exit_date or "").strip()[:10], (exit_reason or "").strip(),
                 self._now(), int(animal_id)))
        return {"id": int(animal_id), "status": status}

    def add_animal_event(self, animal_id: int, event_type: str, event_date: str = "",
                         category: str = "other", value=0, ref_tag: str = "",
                         details: str = "", user_id: Optional[int] = None,
                         event_def_id: Optional[int] = None,
                         inputs_json: str = "") -> dict[str, Any]:
        et = (event_type or "").strip()
        if not et:
            raise ValueError("Вкажіть тип події.")
        cat = category if category in self._EVENT_CATS else "other"
        with self._connect() as conn:
            if not conn.execute("SELECT 1 FROM herd_animals WHERE id=?",
                                (int(animal_id),)).fetchone():
                raise ValueError("Тварину не знайдено.")
            cur = conn.execute(
                "INSERT INTO herd_animal_events (animal_id, event_date, category, "
                "event_type, value, ref_tag, details, created_at, user_id, "
                "event_def_id, inputs_json) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (int(animal_id), (event_date or date.today().isoformat())[:10], cat, et,
                 self._to_float(value, 0), (ref_tag or "").strip(),
                 (details or "").strip(), self._now(), user_id,
                 int(event_def_id) if event_def_id else None, inputs_json or ""))
        return {"id": int(cur.lastrowid)}

    def frequent_event_defs(self, days: int = 30, limit: int = 5) -> list[int]:
        """Id найуживаніших типів подій за останні N днів — для закріплених
        «частих» плиток (менше кліків на щоденних операціях)."""
        edge = (date.today() - timedelta(days=days)).isoformat()
        with self._connect() as conn:
            return [int(r["event_def_id"]) for r in conn.execute(
                "SELECT event_def_id, COUNT(*) AS n FROM herd_animal_events "
                "WHERE event_def_id IS NOT NULL AND event_date >= ? "
                "GROUP BY event_def_id ORDER BY n DESC, event_def_id LIMIT ?",
                (edge, int(limit)))]

    def delete_animal_event(self, event_id: int) -> dict[str, Any]:
        with self._connect() as conn:
            ev = conn.execute("SELECT animal_id, event_def_id FROM herd_animal_events "
                              "WHERE id=?", (int(event_id),)).fetchone()
            conn.execute("DELETE FROM herd_animal_events WHERE id=?", (int(event_id),))
        res = {"deleted": int(event_id)}
        # подія з довідника міняла параметри → чесно перерахувати стан
        if ev and ev["event_def_id"]:
            res["recalc"] = self.recalc_animal_params(ev["animal_id"])
        return res

    def list_recent_events(self, limit: int = 100, q: str = "") -> list[dict[str, Any]]:
        """Стрічка останніх подій по всіх тваринах (для журналу подій)."""
        q = (q or "").strip()
        sql = ("SELECT e.*, a.tag AS animal_tag, a.name AS animal_name, "
               "COALESCE(NULLIF(u.full_name,''), u.username, '') AS user_name "
               "FROM herd_animal_events e "
               "JOIN herd_animals a ON a.id = e.animal_id "
               "LEFT JOIN users u ON u.id = e.user_id")
        params: list = []
        if q:
            sql += " WHERE a.tag LIKE ? OR a.name LIKE ? OR e.event_type LIKE ?"
            params += [f"%{q}%", f"%{q}%", f"%{q}%"]
        sql += " ORDER BY e.event_date DESC, e.id DESC LIMIT ?"
        params.append(int(limit))
        with self._connect() as conn:
            return [dict(r) for r in conn.execute(sql, params).fetchall()]

    def import_animals(self, rows: list) -> dict[str, Any]:
        """Імпорт тварин зі списку рядків (мапінг уже виконано на боці API).
        Зіставлення за биркою: якщо є — оновлюємо, немає — створюємо."""
        added = updated = skipped = 0
        errors = []
        with self._connect() as conn:
            for i, row in enumerate(rows or [], 1):
                f = self._animal_fields(row)
                if not f["tag"]:
                    skipped += 1
                    continue
                try:
                    ex = conn.execute("SELECT id FROM herd_animals WHERE tag=?",
                                      (f["tag"],)).fetchone()
                    now = self._now()
                    if ex:
                        sets = ", ".join(f"{k}=?" for k in f)
                        conn.execute(f"UPDATE herd_animals SET {sets}, updated_at=? WHERE id=?",
                                     (*f.values(), now, ex["id"]))
                        updated += 1
                    else:
                        cols = ", ".join(f.keys()); ph = ", ".join("?" for _ in f)
                        conn.execute(
                            f"INSERT INTO herd_animals ({cols}, created_at, updated_at) "
                            f"VALUES ({ph}, ?, ?)", (*f.values(), now, now))
                        added += 1
                except Exception as e:  # noqa: BLE001
                    errors.append(f"рядок {i}: {e}")
        return {"added": added, "updated": updated, "skipped": skipped,
                "errors": errors}

    # ── Гнучкі параметри тварин ──────────────────────────────────────────
    # date|text|int|float|bool|list|cod|ref_animal|computed
    # (legacy-аліаси: number→float, select→list, code→cod — приймаються при читанні)
    PARAM_DTYPES = ("date", "text", "int", "float", "bool", "list", "cod",
                    "ref_animal", "computed", "number", "select", "code")
    PARAM_SECTIONS = ("Основне", "Родовід", "Відтворення", "Здоров'я",
                      "Продуктивність", "Інше")
    # Параметри, привʼязані до ядра тварини (єдине джерело правди):
    # родовід + номер тварини (бирка)
    _CORE_PARAM_FIELDS = {"dam_tag": "dam_tag", "sire_code": "sire_code",
                          "tag": "tag",
                          # 2026-08-30: цикл керується подіями — Отел інкрементить
                          # лактацію, Вибуття закриває тварину
                          "lactation": "lactation_no", "status": "status",
                          "exit_date": "exit_date", "exit_reason": "exit_reason"}
    # Стандартні параметри (сід). (key, label, short, dtype, unit, options, formula, section)
    _STD_PARAMS = [
        ("tag", "Номер тварини", "№", "text", "", "", "", "Основне"),
        ("uin", "Ідентифікаційний номер (UA…)", "UIN", "text", "", "", "", "Основне"),
        ("sex", "Стать", "Стать", "code", "",
         '[{"c":"F","l":"Жіноча"},{"c":"M","l":"Чоловіча"}]', "", "Основне"),
        ("group", "Група", "Група", "list", "", "@sections", "", "Основне"),
        ("age_months", "Вік, міс", "Вік", "int", "міс", "", "age", "Основне"),
        ("live_weight", "Жива вага", "Вага", "float", "кг", "", "", "Основне"),
        ("bcs", "Вгодованість (BCS)", "BCS", "float", "бал", "", "", "Основне"),
        ("repro_code", "Репродуктивний код", "RC", "code", "",
         '[{"c":"0","l":"Телиця"},{"c":"1","l":"Бракова (не осіменяти)"},'
         '{"c":"2","l":"Новотільна"},{"c":"3","l":"Осіменена не тільна"},'
         '{"c":"4","l":"Осіменена"},{"c":"5","l":"Тільна"},{"c":"6","l":"Сухостій"},'
         '{"c":"7","l":"Бичок"},{"c":"8","l":"Переміщення з ферми"},'
         '{"c":"9","l":"Вибуття"}]', "", "Відтворення"),
        ("preg_status", "Статус тільності", "Тільність", "text", "", "",
         '{"op":"code_label","a":"repro_code","fallback":""}', "Відтворення"),
        ("dam_tag", "Мати", "Мати", "ref_animal", "", "", "", "Родовід"),
        ("sire_code", "Батько", "Батько", "ref_animal", "", "", "", "Родовід"),
        ("last_insem", "Дата ост. осіменіння", "Осімен.", "date", "", "", "", "Відтворення"),
        ("last_bull", "Останній бик (осім.)", "Бик", "text", "", "", "", "Відтворення"),
        ("last_calving", "Дата останнього отелу", "Отел", "date", "", "", "", "Відтворення"),
        ("insem_count", "Осіменінь (лактація)", "Осім.№", "int", "", "", "", "Відтворення"),
        ("days_preg", "Днів тільності", "Дн.тільн.", "int", "дн", "", "days_preg", "Відтворення"),
        ("expected_calving", "Очікуваний отел", "Очік.отел", "date", "", "", "expected_calving", "Відтворення"),
        ("service_period", "Сервіс-період", "Сервіс", "int", "дн", "", "service_period", "Відтворення"),
        ("last_vacc", "Остання вакцинація", "Вакц.", "date", "", "", "", "Здоров'я"),
        ("quarantine_until", "Карантин до", "Каран.", "date", "", "", "", "Здоров'я"),
        ("health_note", "Нотатка здоров'я", "Здоров'я", "text", "", "", "", "Здоров'я"),
        ("dim", "Днів у молоці (DIM)", "DIM", "int", "дн", "", "dim", "Продуктивність"),
        ("last_milk", "Останній контр. надій", "Надій", "number", "кг/дн", "", "", "Продуктивність"),
    ]

    def _seed_herd_params(self, conn: sqlite3.Connection) -> None:
        have = {r[0] for r in conn.execute(
            "SELECT key FROM herd_param_defs").fetchall()}
        now = self._now()
        for i, (key, label, short, dt, unit, opts, formula, sec) in enumerate(self._STD_PARAMS):
            if key in have:
                # бекфіл скороченої назви для вже засіяних стандартних
                conn.execute("UPDATE herd_param_defs SET short=? WHERE key=? AND short=''",
                             (short, key))
                continue
            conn.execute(
                "INSERT INTO herd_param_defs (key,label,short,dtype,unit,options,formula,"
                "section,is_standard,sort_order,is_active,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,1,?,1,?)",
                (key, label, short, dt, unit, opts, formula, sec, i, now))

    def list_param_defs(self, active_only: bool = False) -> list[dict[str, Any]]:
        sql = "SELECT * FROM herd_param_defs"
        if active_only:
            sql += " WHERE is_active=1"
        sql += " ORDER BY sort_order, id"
        with self._connect() as conn:
            out = []
            for r in conn.execute(sql).fetchall():
                d = dict(r)
                try:
                    d["options_list"] = json.loads(d.get("options") or "[]")
                except Exception:  # noqa: BLE001
                    d["options_list"] = []
                out.append(d)
            return out

    def _param_key_norm(self, label: str) -> str:
        import re as _re
        base = _re.sub(r"[^a-z0-9]+", "_", (label or "").strip().lower()).strip("_")
        return base or "param"

    def add_param_def(self, data: dict) -> dict[str, Any]:
        label = (data.get("label") or "").strip()
        if not label:
            raise ValueError("Вкажіть назву параметра.")
        dtype = (data.get("dtype") or "text").strip()
        if dtype not in self.PARAM_DTYPES:
            raise ValueError("Невідомий тип даних.")
        key = (data.get("key") or "").strip() or self._param_key_norm(label)
        section = (data.get("section") or "Інше").strip() or "Інше"
        opts = data.get("options")
        opts_json = json.dumps(opts, ensure_ascii=False) if isinstance(opts, list) \
            else (opts or "")
        with self._connect() as conn:
            # заборона дублікатів за назвою (без урахування регістру)
            if conn.execute("SELECT 1 FROM herd_param_defs "
                            "WHERE lower(label)=lower(?)", (label,)).fetchone():
                raise ValueError(f"Параметр «{label}» вже існує.")
            # унікальність ключа
            base = key; n = 2
            while conn.execute("SELECT 1 FROM herd_param_defs WHERE key=?",
                               (key,)).fetchone():
                key = f"{base}_{n}"; n += 1
            nxt = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0)+1 FROM herd_param_defs").fetchone()[0]
            short = (data.get("short") or "").strip() or label[:12]
            cur = conn.execute(
                "INSERT INTO herd_param_defs (key,label,short,dtype,unit,options,formula,"
                "section,is_standard,sort_order,is_active,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,0,?,1,?)",
                (key, label, short, dtype, (data.get("unit") or "").strip(), opts_json,
                 (data.get("formula") or "").strip(), section, nxt, self._now()))
            return {"id": int(cur.lastrowid), "key": key}

    def update_param_def(self, param_id: int, data: dict,
                         allow_type_change: bool = False) -> dict[str, Any]:
        fields = {}
        if "label" in data:
            fields["label"] = (data.get("label") or "").strip()
        if "short" in data:
            fields["short"] = (data.get("short") or "").strip()
        if "unit" in data:
            fields["unit"] = (data.get("unit") or "").strip()
        if "section" in data:
            fields["section"] = (data.get("section") or "Інше").strip() or "Інше"
        if "is_active" in data:
            fields["is_active"] = 1 if data.get("is_active") else 0
        if "sort_order" in data:
            fields["sort_order"] = int(self._to_float(data.get("sort_order"), 0))
        if "options" in data:
            opts = data.get("options")
            fields["options"] = json.dumps(opts, ensure_ascii=False) \
                if isinstance(opts, list) else (opts or "")
        with self._connect() as conn:
            row = conn.execute("SELECT is_standard,dtype FROM herd_param_defs WHERE id=?",
                               (int(param_id),)).fetchone()
            if not row:
                raise ValueError("Параметр не знайдено.")
            # заборона дублікатів за назвою (крім себе)
            if "label" in fields and conn.execute(
                    "SELECT 1 FROM herd_param_defs WHERE lower(label)=lower(?) AND id<>?",
                    (fields["label"], int(param_id))).fetchone():
                raise ValueError(f"Параметр «{fields['label']}» вже існує.")
            # тип власних міняємо завжди; стандартних — лише адмін (allow_type_change)
            if (not row["is_standard"]) or allow_type_change:
                if "dtype" in data and data["dtype"] in self.PARAM_DTYPES:
                    fields["dtype"] = data["dtype"]
                if "formula" in data:
                    fields["formula"] = (data.get("formula") or "").strip()
            # джерело: створений→системний — будь-хто; системний→створений — лише адмін
            if "is_standard" in data:
                new_std = 1 if data.get("is_standard") else 0
                if row["is_standard"] and not new_std and not allow_type_change:
                    raise ValueError("Зняти «системний» може лише адміністратор.")
                fields["is_standard"] = new_std
            if not fields:
                return {"id": int(param_id)}
            sets = ", ".join(f"{k}=?" for k in fields)
            conn.execute(f"UPDATE herd_param_defs SET {sets} WHERE id=?",
                         (*fields.values(), int(param_id)))
        return {"id": int(param_id)}

    def delete_param_def(self, param_id: int, allow_standard: bool = False) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT is_standard FROM herd_param_defs WHERE id=?",
                               (int(param_id),)).fetchone()
            if not row:
                raise ValueError("Параметр не знайдено.")
            if row["is_standard"] and not allow_standard:
                raise ValueError("Стандартний параметр може видалити лише адміністратор.")
            conn.execute("DELETE FROM herd_param_values WHERE param_id=?", (int(param_id),))
            conn.execute("DELETE FROM herd_param_defs WHERE id=?", (int(param_id),))
        return {"deleted": int(param_id)}

    def reorder_param_defs(self, order: list) -> dict[str, Any]:
        with self._connect() as conn:
            for i, pid in enumerate(order or []):
                conn.execute("UPDATE herd_param_defs SET sort_order=? WHERE id=?",
                             (i, int(pid)))
        return {"ok": True}

    @staticmethod
    def _days_between(a: str, b: str) -> Optional[int]:
        a = (a or "").strip()[:10]; b = (b or "").strip()[:10]
        if len(a) < 10 or len(b) < 10:
            return None
        try:
            from datetime import date as _d
            da = _d(int(a[:4]), int(a[5:7]), int(a[8:10]))
            dbb = _d(int(b[:4]), int(b[5:7]), int(b[8:10]))
            return (dbb - da).days
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _add_days(a: str, n: int) -> str:
        a = (a or "").strip()[:10]
        if len(a) < 10:
            return ""
        try:
            from datetime import date as _d, timedelta
            da = _d(int(a[:4]), int(a[5:7]), int(a[8:10])) + timedelta(days=n)
            return da.isoformat()
        except Exception:  # noqa: BLE001
            return ""

    GESTATION_DAYS = 280

    # Спец-операнди дат (крім параметрів типу «Дата»)
    _CORE_DATE_OPERANDS = {
        "__today__": None,          # сьогодні
        "birth_date": "birth_date", "entry_date": "entry_date",
        "exit_date": "exit_date", "last_calving": None,
    }

    def _resolve_date_operand(self, key: str, animal: dict, vals: dict,
                              today: str) -> str:
        key = (key or "").strip()
        if key == "__today__":
            return today
        if key in ("birth_date", "entry_date", "exit_date"):
            return (animal.get(key) or "")[:10]
        return (vals.get(key) or "")[:10]      # значення параметра типу «Дата»

    def _resolve_num_operand(self, key: str, animal: dict, vals: dict):
        """Число: літерал (напр. «14»), ядро (lactation_no) або параметр int/float.
        None — якщо порожньо/невідомо."""
        import re as _re
        key = (key or "").strip()
        if _re.fullmatch(r"-?\d+(?:[.,]\d+)?", key):     # конкретне число (5, 14, 3.5)
            return float(key.replace(",", "."))
        raw = animal.get(key) if key in ("lactation_no",) else vals.get(key)
        if raw in ("", None):
            return None
        try:
            return float(str(raw).replace(",", "."))
        except Exception:  # noqa: BLE001
            return None

    def _compute_param(self, formula: str, animal: dict, vals: dict,
                       opts_by_key: dict = None) -> Any:
        """Обчислює computed-параметр. Формула — або вбудований ключ
        (age/dim/…), або JSON-конфіг узагальненої операції:
        {"op":"date_diff","a":<operand>,"b":<operand>,"fallback":<val>}."""
        today = date.today().isoformat()
        f = (formula or "").strip()
        if f.startswith("{"):                  # узагальнена формула
            try:
                cfg = json.loads(f)
            except Exception:  # noqa: BLE001
                return None
            fb = cfg.get("fallback")
            fb = fb if (fb not in ("", None)) else None
            op = cfg.get("op")
            if op == "code_label":             # довідник: код → його мітка
                raw = vals.get(cfg.get("a"))
                if raw in ("", None):
                    return fb
                for o in (opts_by_key or {}).get(cfg.get("a"), []) or []:
                    if isinstance(o, dict) and str(o.get("c")) == str(raw):
                        return o.get("l") or fb
                return fb
            if op == "date_diff":
                da = self._resolve_date_operand(cfg.get("a"), animal, vals, today)
                db_ = self._resolve_date_operand(cfg.get("b"), animal, vals, today)
                d = self._days_between(db_, da)   # A − B (днів від B до A)
                return d if d is not None else fb
            if op in ("num_diff", "num_sum"):
                na = self._resolve_num_operand(cfg.get("a"), animal, vals)
                nb = self._resolve_num_operand(cfg.get("b"), animal, vals)
                if na is None or nb is None:
                    return fb
                r = (na - nb) if op == "num_diff" else (na + nb)
                return int(r) if r == int(r) else round(r, 4)
            if op in ("date_add", "date_sub"):    # дата ± число днів → дата
                da = self._resolve_date_operand(cfg.get("a"), animal, vals, today)
                nb = self._resolve_num_operand(cfg.get("b"), animal, vals)
                if len(da) < 10 or nb is None:
                    return fb
                res = self._add_days(da, int(nb) * (1 if op == "date_add" else -1))
                return res or fb
            return fb
        if formula == "age":
            return self._age_months(animal.get("birth_date"))
        if formula == "days_alive":
            d = self._days_between(animal.get("birth_date"), today)
            return d if (d is not None and d >= 0) else None
        if formula == "dim":
            lc = vals.get("last_calving")
            d = self._days_between(lc, today)
            return d if (d is not None and d >= 0) else None
        if formula == "days_preg":
            if (vals.get("preg_status") or "") != "Тільна":
                return None
            d = self._days_between(vals.get("last_insem"), today)
            return d if (d is not None and d >= 0) else None
        if formula == "expected_calving":
            li = vals.get("last_insem")
            if not li or (vals.get("preg_status") or "") not in ("Тільна", "Осіменена"):
                return None
            return self._add_days(li, self.GESTATION_DAYS)
        if formula == "service_period":
            return self._days_between(vals.get("last_calving"), vals.get("last_insem"))
        return None

    def _coerce_param(self, dtype: str, value) -> str:
        import re as _re
        v = "" if value is None else str(value).strip()
        if v == "":
            return ""
        if dtype == "int":
            return str(int(round(self._to_float(v.replace(",", "."), 0))))
        if dtype in ("float", "number"):
            f = self._to_float(v.replace(",", "."), 0)
            return str(int(f)) if f == int(f) else str(f)   # ціле без «.0»
        if dtype == "date":
            return v[:10]
        if dtype == "bool":
            return "1" if v.lower() in ("1", "true", "так", "yes", "on") else "0"
        if dtype in ("cod", "code"):
            m = _re.search(r"-?\d+", v)          # перше ціле (з «5 — Тільна» теж)
            if m:
                return m.group(0)
            # текстові коди (sold/culled/dead — статуси): літерний токен як є
            return v if _re.fullmatch(r"[A-Za-z_][\w-]*", v) else ""
        return v

    def get_animal_params(self, animal_id: int, animal: dict = None) -> list[dict[str, Any]]:
        """Значення всіх активних параметрів тварини (збережені + обчислені),
        згруповані за секціями, у порядку sort_order."""
        with self._connect() as conn:
            if animal is None:
                animal = dict(conn.execute("SELECT * FROM herd_animals WHERE id=?",
                                           (int(animal_id),)).fetchone() or {})
            defs = [dict(r) for r in conn.execute(
                "SELECT * FROM herd_param_defs WHERE is_active=1 "
                "ORDER BY sort_order, id").fetchall()]
            raw = {r["param_id"]: r["value"] for r in conn.execute(
                "SELECT param_id, value FROM herd_param_values WHERE animal_id=?",
                (int(animal_id),)).fetchall()}
            # усі секції (для показу поточної назви) + активні сьогодні (для списку)
            sec_rows = conn.execute(
                "SELECT id, name FROM herd_groups WHERE is_active=1 "
                "ORDER BY sort_order, id").fetchall()
            today = date.today().isoformat()
            active_rows = conn.execute(
                "SELECT g.name FROM herd_groups g "
                "JOIN herd_section_periods p ON p.section_id = g.id "
                "WHERE g.is_active=1 AND (p.date_from='' OR p.date_from<=?) "
                "AND (p.date_to='' OR p.date_to>=?) "
                "GROUP BY g.id ORDER BY g.sort_order, g.id", (today, today)).fetchall()
        sec_by_id = {r["id"]: r["name"] for r in sec_rows}
        sec_names = [r["name"] for r in active_rows]
        vals_by_key = {d["key"]: raw.get(d["id"], "") for d in defs}
        # опції за ключем (для code_label — довідник код→мітка)
        opts_by_key = {}
        for d in defs:
            if (d.get("options") or "") == "@sections":
                continue
            try:
                opts_by_key[d["key"]] = json.loads(d.get("options") or "[]")
            except Exception:  # noqa: BLE001
                opts_by_key[d["key"]] = []
        out = []
        for d in defs:
            fml = (d.get("formula") or "").strip()
            if fml:                              # обчислюване (є формула)
                val = self._compute_param(fml, animal, vals_by_key, opts_by_key)
            elif d["key"] == "group":            # Група — поточна секція тварини
                val = sec_by_id.get(animal.get("group_id"), "") or ""
            elif d["key"] in self._CORE_PARAM_FIELDS:   # родовід — з ядра тварини
                val = animal.get(self._CORE_PARAM_FIELDS[d["key"]]) or ""
            else:
                val = raw.get(d["id"], "")
            if (d.get("options") or "") == "@sections":  # динамічний список секцій
                opts = list(sec_names)
            else:
                try:
                    opts = json.loads(d.get("options") or "[]")
                except Exception:  # noqa: BLE001
                    opts = []
            # мітка значення для cod/code (код → назва, якщо задано)
            vlabel = ""
            if d["dtype"] in ("cod", "code") and str(val) != "":
                for o in opts:
                    if isinstance(o, dict) and str(o.get("c")) == str(val):
                        vlabel = o.get("l") or ""
                        break
            out.append({"id": d["id"], "key": d["key"], "label": d["label"],
                        "short": d.get("short") or "", "dtype": d["dtype"],
                        "unit": d["unit"], "section": d["section"],
                        "options": opts, "value": val, "value_label": vlabel,
                        "computed": bool(fml), "is_standard": d["is_standard"]})
        return out

    def set_animal_param(self, animal_id: int, key: str, value) -> dict[str, Any]:
        with self._connect() as conn:
            d = conn.execute("SELECT id,dtype,formula FROM herd_param_defs WHERE key=?",
                             (key,)).fetchone()
            if not d:
                raise ValueError("Невідомий параметр.")
            if (d["formula"] or "").strip():
                raise ValueError("Обчислюваний параметр не редагується.")
            val = self._coerce_param(d["dtype"], value)
            if key == "group":                      # Група → секція (group_id ядра)
                gid = None
                if str(val).strip():
                    row = conn.execute(
                        "SELECT id FROM herd_groups WHERE is_active=1 AND name=? "
                        "ORDER BY sort_order, id LIMIT 1", (str(val).strip(),)).fetchone()
                    gid = row["id"] if row else None
                conn.execute("UPDATE herd_animals SET group_id=?, updated_at=? WHERE id=?",
                             (gid, self._now(), int(animal_id)))
                return {"key": key, "value": val}
            if key in self._CORE_PARAM_FIELDS:      # родовід/цикл → у ядро тварини
                if key == "status" and str(val).strip() \
                        and str(val) not in self.ANIMAL_STATUSES:
                    raise ValueError("Невідомий статус тварини.")
                col = self._CORE_PARAM_FIELDS[key]
                conn.execute(f"UPDATE herd_animals SET {col}=?, updated_at=? WHERE id=?",
                             (val, self._now(), int(animal_id)))
                return {"key": key, "value": val}
            if val == "":
                conn.execute("DELETE FROM herd_param_values WHERE animal_id=? AND param_id=?",
                             (int(animal_id), d["id"]))
            else:
                conn.execute(
                    "INSERT INTO herd_param_values (animal_id,param_id,value,updated_at) "
                    "VALUES (?,?,?,?) ON CONFLICT(animal_id,param_id) DO UPDATE SET "
                    "value=excluded.value, updated_at=excluded.updated_at",
                    (int(animal_id), d["id"], val, self._now()))
        return {"key": key, "value": val}

    # ── Події, що змінюють параметри ────────────────────────────────────
    EVENT_MODES = ("const", "input", "event_date", "inc", "clear", "when")
    # (key, name, category, [(param_key, mode, arg)])
    _STD_EVENTS = [
        ("insem", "Осіменіння", "repro", [
            ("last_insem", "event_date", ""), ("last_bull", "input", ""),
            ("insem_count", "inc", "1"), ("repro_code", "const", "4"),
            ("preg_status", "const", "Осіменена")]),
        ("preg_check", "Перевірка тільності", "repro", [
            ("preg_status", "input", ""), ("repro_code", "input", "")]),
        ("preg_pos", "Тільна", "repro", [
            ("repro_code", "const", "5"), ("preg_status", "const", "Тільна")]),
        ("open_cow", "Ялова", "repro", [
            ("repro_code", "const", "3"), ("preg_status", "const", "Ялова")]),
        ("dryoff", "Запуск (сухостій)", "repro", [
            ("repro_code", "const", "6"), ("preg_status", "const", "Сухостій")]),
        ("calving", "Отел", "repro", [
            ("repro_code", "const", "2"), ("last_calving", "event_date", ""),
            ("insem_count", "const", "0"), ("preg_status", "const", "Ялова")]),
        # приплід; прив'язана до Отелу. Репрокод теляти — за статтю (правила «Якщо»)
        ("birth", "Народження", "repro", [
            ("repro_code", "when",
             '{"rules":[{"if":"sex","eq":"F","val":"0"},'
             '{"if":"sex","eq":"M","val":"7"}],"default":""}')]),
        ("weigh", "Зважування", "prod", [("live_weight", "input", "")]),
        ("milk_test", "Контрольний надій", "prod", [("last_milk", "input", "")]),
        ("vacc", "Вакцинація", "health", [("last_vacc", "event_date", "")]),
        ("treat", "Лікування", "health", [("health_note", "input", "")]),
        ("cull", "Вибуття", "move", [("repro_code", "const", "9")]),
    ]

    _LOGIC_PARAMS_V2 = [
        # (key, label, dtype, options, section, formula)
        ("lactation", "№ лактації", "int", "", "Основне", ""),
        ("status", "Статус", "cod",
         '[{"c":"active","l":"В стаді"},{"c":"sold","l":"Продано"},'
         '{"c":"culled","l":"Вибракувано"},{"c":"dead","l":"Загинула"}]',
         "Основне", ""),
        ("exit_date", "Дата вибуття", "date", "", "Основне", ""),
        ("exit_reason", "Причина вибуття", "text", "", "Основне", ""),
        ("preg_result", "Результат перевірки", "cod",
         '[{"c":"5","l":"Тільна"},{"c":"3","l":"Ялова"}]', "Відтворення", ""),
        ("last_preg_check", "Дата перевірки тільності", "date", "", "Відтворення", ""),
        ("last_dryoff", "Дата запуску", "date", "", "Відтворення", ""),
    ]
    # доливні ефекти повного циклу: (event_key, param_key, mode, arg)
    _LOGIC_EFFECTS_V2 = [
        ("calving", "lactation", "inc", "1"),
        ("calving", "insem_count", "const", "0"),
        ("dryoff", "last_dryoff", "event_date", ""),
        ("cull", "status", "input", "culled"),
        ("cull", "exit_date", "event_date", ""),
        ("cull", "exit_reason", "input", ""),
        ("preg_check", "preg_result", "input", ""),
        ("preg_check", "repro_code", "when",
         '{"rules":[{"if":"preg_result","eq":"5","val":"5"},'
         '{"if":"preg_result","eq":"3","val":"3"}],"default":""}'),
        ("preg_check", "last_preg_check", "event_date", ""),
    ]

    def _seed_herd_logic_v2(self, conn: sqlite3.Connection) -> None:
        """Доведення логіки циклу (2026-08-30, рішення Романа «налаштувати всю
        логіку»): Отел веде лактацію і обнуляє лічильник осіменінь, Вибуття
        закриває тварину (статус/дата/причина), Перевірка тільності — з
        вибором результату замість вводу кодів руками. Ідемпотентно ДОЛИВАЄ
        відсутнє, наявні кастомні ефекти не чіпає."""
        # параметри
        have_p = {r[0] for r in conn.execute("SELECT key FROM herd_param_defs")}
        now = self._now()
        for key, label, dt, opts, sec, fml in self._LOGIC_PARAMS_V2:
            if key in have_p:
                continue
            mx = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM herd_param_defs"
                              ).fetchone()[0]
            conn.execute(
                "INSERT INTO herd_param_defs (key,label,dtype,unit,options,formula,"
                "section,is_standard,sort_order,is_active,created_at,short) "
                "VALUES (?,?,?,?,?,?,?,1,?,1,?,?)",
                (key, label, dt, "", opts, fml, sec, mx + 1, now, key))
        # мапа key→id подій
        ev_by_key = {r["key"]: r["id"] for r in conn.execute(
            "SELECT id, key FROM herd_event_defs")}
        # «Перевірка тільності»: прибрати зламані старі ефекти (input на
        # обчислюваний preg_status / голий код цифрою)
        pc = ev_by_key.get("preg_check")
        if pc:
            conn.execute(
                "DELETE FROM herd_event_effects WHERE event_id=? AND mode='input' "
                "AND param_key IN ('preg_status','repro_code')", (pc,))
        for ekey, pk, mode, arg in self._LOGIC_EFFECTS_V2:
            eid = ev_by_key.get(ekey)
            if not eid:
                continue
            if conn.execute(
                    "SELECT 1 FROM herd_event_effects WHERE event_id=? AND param_key=?",
                    (eid, pk)).fetchone():
                continue                        # вже налаштовано (можливо, вручну)
            mx = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0) FROM herd_event_effects "
                "WHERE event_id=?", (eid,)).fetchone()[0]
            conn.execute(
                "INSERT INTO herd_event_effects (event_id,param_key,mode,arg,sort_order) "
                "VALUES (?,?,?,?,?)", (eid, pk, mode, arg, mx + 1))

    def _seed_herd_events(self, conn: sqlite3.Connection) -> None:
        have = {r[0] for r in conn.execute("SELECT key FROM herd_event_defs").fetchall()}
        now = self._now()
        for i, (key, name, cat, effs) in enumerate(self._STD_EVENTS):
            if key in have:
                continue
            cur = conn.execute(
                "INSERT INTO herd_event_defs (key,name,category,is_standard,"
                "sort_order,is_active,created_at) VALUES (?,?,?,1,?,1,?)",
                (key, name, cat, i, now))
            eid = int(cur.lastrowid)
            for j, (pk, mode, arg) in enumerate(effs):
                conn.execute(
                    "INSERT INTO herd_event_effects (event_id,param_key,mode,arg,sort_order) "
                    "VALUES (?,?,?,?,?)", (eid, pk, mode, arg, j))

    def _merge_when_effects(self, conn: sqlite3.Connection) -> None:
        """Кілька when-ефектів одного параметра в події → один ефект із масивом
        правил {rules,default}. Ідемпотентно (після злиття на параметр ≤1 when)."""
        eids = [r[0] for r in conn.execute(
            "SELECT DISTINCT event_id FROM herd_event_effects WHERE mode='when'").fetchall()]
        for eid in eids:
            rows = conn.execute(
                "SELECT id,param_key,arg FROM herd_event_effects "
                "WHERE event_id=? AND mode='when' ORDER BY sort_order,id",
                (int(eid),)).fetchall()
            by_pk: dict[str, list] = {}
            for r in rows:
                by_pk.setdefault(r["param_key"], []).append(r)
            for pk, lst in by_pk.items():
                if len(lst) <= 1:
                    continue
                rules: list = []
                default = ""
                for r in lst:
                    spec = self._parse_when_rules(r["arg"])
                    rules += spec["rules"]
                    if spec["default"]:
                        default = spec["default"]
                keep = lst[0]["id"]
                conn.execute(
                    "UPDATE herd_event_effects SET arg=? WHERE id=?",
                    (json.dumps({"rules": rules, "default": default}, ensure_ascii=False), keep))
                for r in lst[1:]:
                    conn.execute("DELETE FROM herd_event_effects WHERE id=?", (r["id"],))

    def list_event_defs(self, active_only: bool = False) -> list[dict[str, Any]]:
        with self._connect() as conn:
            sql = "SELECT * FROM herd_event_defs"
            if active_only:
                sql += " WHERE is_active=1"
            sql += " ORDER BY sort_order, id"
            defs = [dict(r) for r in conn.execute(sql).fetchall()]
            # мапа param_key → мітка/тип
            pmeta = {r["key"]: dict(r) for r in conn.execute(
                "SELECT key,label,short,dtype FROM herd_param_defs").fetchall()}
            for d in defs:
                effs = []
                for e in conn.execute(
                        "SELECT * FROM herd_event_effects WHERE event_id=? "
                        "ORDER BY sort_order, id", (d["id"],)).fetchall():
                    e = dict(e); pm = pmeta.get(e["param_key"], {})
                    e["param_label"] = pm.get("label") or e["param_key"]
                    e["param_dtype"] = pm.get("dtype") or ""
                    effs.append(e)
                d["effects"] = effs
        return defs

    def _get_param_value(self, conn, animal_id: int, key: str) -> str:
        if key in self._CORE_PARAM_FIELDS:       # ядро тварини (лактація тощо)
            r = conn.execute(
                "SELECT %s AS v FROM herd_animals WHERE id=?"
                % self._CORE_PARAM_FIELDS[key], (int(animal_id),)).fetchone()
            return "" if not r or r["v"] is None else str(r["v"])
        r = conn.execute(
            "SELECT v.value FROM herd_param_values v JOIN herd_param_defs d "
            "ON d.id=v.param_id WHERE v.animal_id=? AND d.key=?",
            (int(animal_id), key)).fetchone()
        return r["value"] if r else ""

    def _apply_when_effects(self, animal_id: int, effs, ctx: dict) -> list[str]:
        """Ефекти «Якщо»: кожен несе набір правил + дефолт. Перше правило,
        чия умова збіглася, задає значення; якщо жодне — дефолт («інакше»).
        ctx — відомі значення (введене при події / атрибути теляти);
        якщо в ctx немає — беремо поточне значення параметра тварини."""
        changed: list[str] = []
        for e in effs:
            if e["mode"] != "when":
                continue
            pk = e["param_key"]
            spec = self._parse_when_rules(e["arg"])
            chosen = None
            for r in spec["rules"]:
                if not r["if"]:
                    continue
                cond = ctx.get(r["if"], None)
                if cond in (None, ""):
                    with self._connect() as cw:
                        cond = self._get_param_value(cw, animal_id, r["if"])
                if str(cond) == r["eq"]:
                    chosen = r["val"]
                    break
            val = chosen if chosen is not None else spec["default"]
            if val not in (None, ""):
                try:
                    self.set_animal_param(animal_id, pk, val)
                    changed.append(pk)
                except Exception:  # noqa: BLE001
                    pass
        return changed

    def _apply_def_effects(self, animal_id: int, effs, inputs: dict,
                           ed: str) -> list[str]:
        """Застосувати ефекти типу події до параметрів тварини. Винесено з
        apply_event, бо потрібно і при ПЕРЕРАХУНКУ з ланцюга подій
        (recalc_animal_params) — після видалення/правки події."""
        changed: list[str] = []
        for e in effs:
            pk, mode, arg = e["param_key"], e["mode"], e["arg"]
            if mode == "const":
                val = arg
            elif mode == "event_date":
                val = ed
            elif mode == "input":
                val = inputs.get(pk, None)
                if val in (None, ""):
                    val = arg          # значення за замовчуванням, якщо не ввели
            elif mode == "clear":
                val = ""
            elif mode == "inc":
                with self._connect() as c2:
                    cur = self._to_float(self._get_param_value(c2, animal_id, pk), 0)
                val = str(cur + self._to_float(arg, 0))
            elif mode == "when":
                continue          # правила «Якщо» — окремим згрупованим проходом нижче
            else:
                continue
            if mode != "input" or (val != "" and val is not None):
                try:
                    self.set_animal_param(animal_id, pk, val)
                    changed.append(pk)
                except Exception:  # noqa: BLE001 — обчислювані/невідомі пропускаємо
                    pass
        # правила «Якщо» (усі разом, з варіантом за замовчуванням)
        changed += self._apply_when_effects(animal_id, effs, inputs)
        return changed

    def recalc_animal_params(self, animal_id: int) -> dict[str, Any]:
        """ЧЕСНЕ ВИПРАВЛЕННЯ (Роман 2026-08-30): параметри тварини =
        результат її ланцюга подій. Скидаємо всі параметри, якими керують
        ефекти подій (окрім ідентичності: sex/uin), і заново проводимо
        ефекти всіх подій тварини у хронології. Викликається після
        видалення чи правки події — стан завжди відповідає стрічці."""
        aid = int(animal_id)
        with self._connect() as conn:
            # ключі, якими керують події (звичайні ефекти + цілі правил «Якщо»)
            keys = {r["param_key"] for r in conn.execute(
                "SELECT DISTINCT param_key FROM herd_event_effects")}
            keys -= {"sex", "uin"}         # ідентичність ставиться при створенні
            # ядро циклу: базовий стан перед програванням подій
            conn.execute(
                "UPDATE herd_animals SET status='active', exit_date='', "
                "exit_reason='', lactation_no=lactation_base WHERE id=?", (aid,))
            keys -= set(self._CORE_PARAM_FIELDS)   # ядро скинули вище
            if keys:
                qmarks = ",".join("?" * len(keys))
                conn.execute(
                    "DELETE FROM herd_param_values WHERE animal_id=? AND param_id IN "
                    "(SELECT id FROM herd_param_defs WHERE key IN (%s))" % qmarks,
                    (aid, *keys))
            events = conn.execute(
                "SELECT * FROM herd_animal_events WHERE animal_id=? "
                "AND event_def_id IS NOT NULL ORDER BY event_date, id",
                (aid,)).fetchall()
        replayed = 0
        for ev in events:
            with self._connect() as conn:
                d = conn.execute("SELECT * FROM herd_event_defs WHERE id=?",
                                 (ev["event_def_id"],)).fetchone()
                effs = conn.execute(
                    "SELECT * FROM herd_event_effects WHERE event_id=? "
                    "ORDER BY sort_order, id", (ev["event_def_id"],)).fetchall() \
                    if d else []
            if not d:
                continue
            try:
                inputs = json.loads(ev["inputs_json"] or "{}")
            except Exception:  # noqa: BLE001
                inputs = {}
            self._apply_def_effects(aid, effs, inputs, (ev["event_date"] or "")[:10])
            replayed += 1
        return {"reset": len(keys), "replayed": replayed}

    def update_animal_event(self, event_id: int, event_date: str = None,
                            inputs: dict = None, details: str = None) -> dict[str, Any]:
        """Правка події (дата / введені значення / коментар) з чесним
        перерахунком параметрів тварини."""
        with self._connect() as conn:
            ev = conn.execute("SELECT * FROM herd_animal_events WHERE id=?",
                              (int(event_id),)).fetchone()
            if not ev:
                raise ValueError("Подію не знайдено.")
            sets, args = [], []
            if event_date:
                sets.append("event_date=?"); args.append(event_date[:10])
            if inputs is not None:
                sets.append("inputs_json=?"); args.append(json.dumps(inputs, ensure_ascii=False))
            if details is not None:
                sets.append("details=?"); args.append(details.strip())
            if sets:
                args.append(int(event_id))
                conn.execute("UPDATE herd_animal_events SET %s WHERE id=?"
                             % ", ".join(sets), args)
        res = {"updated": int(event_id)}
        if ev["event_def_id"]:
            res["recalc"] = self.recalc_animal_params(ev["animal_id"])
        return res

    def apply_event(self, animal_id: int, event_key: str = "", event_id: int = 0,
                    event_date: str = "", inputs: dict = None, note: str = "",
                    user_id: Optional[int] = None, calves: list = None) -> dict[str, Any]:
        """Провести подію: застосувати її ефекти до параметрів + записати
        в стрічку. inputs = {param_key: value} для ефектів mode='input'.
        calves — приплід для реєстрації (для «Отел»): [{tag,sex,name,uin,group_id}]."""
        inputs = inputs or {}
        ed = (event_date or date.today().isoformat())[:10]
        with self._connect() as conn:
            if event_id:
                d = conn.execute("SELECT * FROM herd_event_defs WHERE id=?",
                                 (int(event_id),)).fetchone()
            else:
                d = conn.execute("SELECT * FROM herd_event_defs WHERE key=?",
                                 (event_key,)).fetchone()
            if not d:
                raise ValueError("Тип події не знайдено.")
            effs = conn.execute(
                "SELECT * FROM herd_event_effects WHERE event_id=? ORDER BY sort_order, id",
                (d["id"],)).fetchall()
        changed = self._apply_def_effects(animal_id, effs, inputs, ed)
        # прив'язана подія-народження (attach_to=цей ключ): її ефекти на приплід
        # + її запис («Народження») пишемо на КОЖНЕ теля окремо
        calf_effs = list(effs)
        birth_def = None
        if calves:
            with self._connect() as ce:
                birth_def = ce.execute(
                    "SELECT * FROM herd_event_defs WHERE attach_to=? AND births=1 LIMIT 1",
                    (d["key"],)).fetchone()
                if birth_def:
                    for row in ce.execute(
                            "SELECT * FROM herd_event_effects WHERE event_id=?",
                            (birth_def["id"],)).fetchall():
                        calf_effs.append(row)
        # реєстрація приплоду (для подій з ознакою births)
        born = []
        stillborn = []          # мертвонароджені: лише стать (для обліку)
        assigned_names: list = []
        if calves:
            dam_tag = ""
            dam_name = ""
            with self._connect() as c3:
                r = c3.execute("SELECT tag,name FROM herd_animals WHERE id=?",
                               (int(animal_id),)).fetchone()
                dam_tag = r["tag"] if r else ""
                dam_name = (r["name"] if r else "") or ""
            for c in calves:
                if not c.get("alive", True):
                    stillborn.append((c.get("sex") or "").upper())
                    continue
                tag = (c.get("tag") or "").strip()
                if not tag:
                    continue
                # кличка: введена або автогенерація за літерою матері
                nm = (c.get("name") or "").strip()
                if not nm:
                    nm = self._next_calf_name(dam_name, c.get("sex") or "F", assigned_names)
                    if nm:
                        assigned_names.append(nm)
                try:
                    res = self.add_animal({
                        "tag": tag, "name": nm,
                        "sex": c.get("sex") or "F", "birth_date": ed,
                        "dam_tag": dam_tag, "source": "born", "entry_date": ed,
                        "group_id": c.get("group_id"),
                    })
                    cid = res.get("id")
                    if cid and (c.get("uin") or "").strip():
                        try:
                            self.set_animal_param(cid, "uin", c["uin"].strip())
                        except Exception:  # noqa: BLE001
                            pass
                    # правила «Якщо» — застосовуються до теляти за його атрибутами
                    # (стать/номер тощо). Напр.: якщо стать=F → репрокод=0.
                    if cid:
                        sx = (c.get("sex") or "F").upper()
                        try:
                            self.set_animal_param(cid, "sex", sx)
                        except Exception:  # noqa: BLE001
                            pass
                        self._apply_when_effects(cid, calf_effs, {
                            "sex": sx, "uin": (c.get("uin") or ""),
                            "tag": tag, "name": (c.get("name") or "")})
                        # окремий запис події «Народження» на самому теляті
                        if birth_def:
                            det = f"№ {tag}" + (f" — {nm}" if nm else "")
                            try:
                                self.add_animal_event(cid, birth_def["name"], ed,
                                                      birth_def["category"], details=det,
                                                      user_id=user_id,
                                                      event_def_id=int(birth_def["id"]))
                            except Exception:  # noqa: BLE001
                                pass
                    born.append({"id": cid, "tag": tag})
                except Exception as exc:  # noqa: BLE001
                    born.append({"tag": tag, "error": str(exc)})
        # запис у стрічку подій
        det = note or ""
        if born:
            kids = ", ".join(b["tag"] for b in born if b.get("id"))
            if kids:
                det = (det + " · " if det else "") + "приплід: " + kids
        if stillborn:
            f = sum(1 for s in stillborn if s == "F")
            m = sum(1 for s in stillborn if s == "M")
            parts = []
            if f:
                parts.append(f"Ж×{f}")
            if m:
                parts.append(f"Ч×{m}")
            txt = f"мертвонароджені: {len(stillborn)}" + (f" ({', '.join(parts)})" if parts else "")
            det = (det + " · " if det else "") + txt
        self.add_animal_event(animal_id, d["name"], ed, d["category"],
                              details=det, user_id=user_id,
                              event_def_id=int(d["id"]),
                              inputs_json=json.dumps(inputs, ensure_ascii=False))
        return {"event": d["name"], "changed": changed, "born": born,
                "stillborn": len(stillborn)}

    def apply_event_bulk(self, animal_ids: list, event_key: str = "", event_id: int = 0,
                         event_date: str = "", inputs: dict = None, note: str = "",
                         user_id: Optional[int] = None) -> dict[str, Any]:
        """Провести подію для кількох тварин (групове внесення)."""
        applied = 0
        errors = []
        for aid in animal_ids or []:
            try:
                self.apply_event(int(aid), event_key=event_key, event_id=event_id,
                                 event_date=event_date, inputs=inputs, note=note,
                                 user_id=user_id)
                applied += 1
            except Exception as exc:  # noqa: BLE001
                errors.append(str(exc))
        return {"applied": applied, "errors": errors}

    def animals_in_section(self, group_id: int, active_only: bool = True) -> list[int]:
        """ID тварин у секції (для групового внесення)."""
        sql = "SELECT id FROM herd_animals WHERE group_id = ?"
        params: list = [int(group_id)]
        if active_only:
            sql += " AND status = 'active'"
        with self._connect() as conn:
            return [r["id"] for r in conn.execute(sql, params).fetchall()]

    # ── CRUD типів подій та їх ефектів ───────────────────────────────────
    EVENT_CATEGORIES = {
        "repro": "Відтворення", "health": "Здоров'я", "move": "Рух",
        "prod": "Продуктивність", "other": "Інше",
    }
    EVENT_MODE_LABELS = {
        "const": "Задати значення", "input": "Ввести при події",
        "event_date": "Дата події", "inc": "Додати до числа", "clear": "Очистити",
        "when": "Якщо (умова → значення)",
    }

    @staticmethod
    def _parse_when_rules(arg: str) -> dict[str, Any]:
        """arg JSON. Новий формат: {"rules":[{"if","eq","val"},...],"default":val}.
        Старий (сумісність): {"if","eq","val"} — одне правило; без «if» — дефолт."""
        def _r(d):
            return {"if": str(d.get("if") or ""), "eq": str(d.get("eq") or ""),
                    "val": str(d.get("val") or "")}
        try:
            d = json.loads(arg or "{}")
        except Exception:  # noqa: BLE001
            return {"rules": [], "default": ""}
        if not isinstance(d, dict):
            return {"rules": [], "default": ""}
        if "rules" in d:
            rules = [_r(x) for x in (d.get("rules") or []) if isinstance(x, dict)]
            return {"rules": rules, "default": str(d.get("default") or "")}
        # старий формат — одне правило або дефолт
        if not (d.get("if") or ""):
            return {"rules": [], "default": str(d.get("val") or "")}
        return {"rules": [_r(d)], "default": ""}

    def _save_event_effects(self, conn, event_id: int, effects: list) -> None:
        conn.execute("DELETE FROM herd_event_effects WHERE event_id=?", (int(event_id),))
        for i, e in enumerate(effects or []):
            pk = (e.get("param_key") or "").strip()
            mode = (e.get("mode") or "const").strip()
            if not pk or mode not in self.EVENT_MODES:
                continue
            conn.execute(
                "INSERT INTO herd_event_effects (event_id,param_key,mode,arg,sort_order) "
                "VALUES (?,?,?,?,?)",
                (int(event_id), pk, mode, (e.get("arg") or "").strip(), i))

    def add_event_def(self, data: dict) -> dict[str, Any]:
        name = (data.get("name") or "").strip()
        if not name:
            raise ValueError("Вкажіть назву події.")
        cat = data.get("category")
        cat = cat if cat in self.EVENT_CATEGORIES else "other"
        key = (data.get("key") or "").strip() or self._param_key_norm(name)
        with self._connect() as conn:
            base = key; n = 2
            while conn.execute("SELECT 1 FROM herd_event_defs WHERE key=?",
                               (key,)).fetchone():
                key = f"{base}_{n}"; n += 1
            nxt = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0)+1 FROM herd_event_defs").fetchone()[0]
            cur = conn.execute(
                "INSERT INTO herd_event_defs (key,name,category,is_standard,sort_order,"
                "is_active,births,show_on_panel,attach_to,created_at) VALUES (?,?,?,0,?,1,?,?,?,?)",
                (key, name, cat, nxt, 1 if data.get("births") else 0,
                 0 if ("show_on_panel" in data and not data.get("show_on_panel")) else 1,
                 (data.get("attach_to") or "").strip(), self._now()))
            eid = int(cur.lastrowid)
            self._save_event_effects(conn, eid, data.get("effects") or [])
        return {"id": eid, "key": key}

    def update_event_def(self, event_id: int, data: dict,
                         allow_standard_change: bool = False) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT is_standard FROM herd_event_defs WHERE id=?",
                               (int(event_id),)).fetchone()
            if not row:
                raise ValueError("Подію не знайдено.")
            fields = {}
            if "name" in data:
                fields["name"] = (data.get("name") or "").strip()
            if "category" in data and data["category"] in self.EVENT_CATEGORIES:
                fields["category"] = data["category"]
            if "is_active" in data:
                fields["is_active"] = 1 if data.get("is_active") else 0
            if "births" in data:
                fields["births"] = 1 if data.get("births") else 0
            if "show_on_panel" in data:
                fields["show_on_panel"] = 1 if data.get("show_on_panel") else 0
            if "attach_to" in data:
                fields["attach_to"] = (data.get("attach_to") or "").strip()
            if "sort_order" in data:
                fields["sort_order"] = int(self._to_float(data.get("sort_order"), 0))
            if "is_standard" in data:
                new_std = 1 if data.get("is_standard") else 0
                if row["is_standard"] and not new_std and not allow_standard_change:
                    raise ValueError("Зняти «системний» може лише адміністратор.")
                fields["is_standard"] = new_std
            if fields:
                sets = ", ".join(f"{k}=?" for k in fields)
                conn.execute(f"UPDATE herd_event_defs SET {sets} WHERE id=?",
                             (*fields.values(), int(event_id)))
            if "effects" in data:
                self._save_event_effects(conn, int(event_id), data.get("effects") or [])
        return {"id": int(event_id)}

    def delete_event_def(self, event_id: int, allow_standard: bool = False) -> dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT is_standard FROM herd_event_defs WHERE id=?",
                               (int(event_id),)).fetchone()
            if not row:
                raise ValueError("Подію не знайдено.")
            if row["is_standard"] and not allow_standard:
                raise ValueError("Системну подію може видалити лише адміністратор.")
            conn.execute("DELETE FROM herd_event_effects WHERE event_id=?", (int(event_id),))
            conn.execute("DELETE FROM herd_event_defs WHERE id=?", (int(event_id),))
        return {"deleted": int(event_id)}

    def reorder_event_defs(self, order: list) -> dict[str, Any]:
        with self._connect() as conn:
            for i, eid in enumerate(order or []):
                conn.execute("UPDATE herd_event_defs SET sort_order=? WHERE id=?",
                             (i, int(eid)))
        return {"ok": True}

    def scheme_forecast(self, category: str = "pharmacy",
                        year=None, month=None) -> dict[str, Any]:
        """Поблочна потреба (флакони/штуки) за схемами + підсумок до замовлення.

        На рядок: дози = доза × разів(кратність) × поголів'я × множник періоду
        (разово=1 — курс без множення на дні; день=30, тиждень≈4.29, місяць=1);
        флакони = дози ÷ вміст упаковки (якщо заданий). Об'ємні одиниці (мл/г)
        без вмісту упаковки не рахуються — позначаються «задайте вміст».
        Потреба за блоком — сума рядків того блоку; замовити (по медикаменту,
        по всіх блоках) = округл.вгору(потреба − залишок), не менше 0."""
        category = (category or "pharmacy").strip() or "pharmacy"
        schemes = self.list_schemes(category, hc_year=year, hc_month=month)
        products_all = self.list_products("", category=category)
        stock = {p["id"]: self._to_float(p.get("total_qty"), 0) for p in products_all}
        prod_meta = {p["id"]: {"name": p.get("name"), "unit": p.get("unit") or "",
                               "barcode": (p.get("barcode") or "")} for p in products_all}
        # Товари, позначені «не брати участь у замовленні» — не показуємо в «До замовлення».
        excluded = {p["id"] for p in products_all if p.get("exclude_from_order")}

        by_block: dict[str, dict] = {}
        by_product: dict[int, dict] = {}
        needs_pack: dict[int, dict] = {}   # мл/г без вмісту упаковки — позначити
        for s in schemes:
            bname = s.get("block_name") or "Без блоку"
            hc = self._to_float(s.get("eff_headcount"), 0)
            for ln in s["lines"]:
                pid = ln["product_id"]
                dose = self._to_float(ln.get("dose_per_head"), 0)
                pack = self._to_float(ln.get("pack_content"), 0)
                times = self._to_float(ln.get("times_per"), 1)
                if times <= 0:
                    times = 1
                basis = (ln.get("basis") or "head")
                unit = (ln.get("dose_unit") or "").strip().lower()
                # «once» (разово) і невідомі — без множення на дні (×1).
                factor = self._PERIOD_FACTOR.get((ln.get("period") or "once"), 1.0)
                if dose <= 0:
                    continue
                if basis == "head" and hc <= 0:
                    continue
                # Об'ємна одиниця (мл/г) без вмісту упаковки — не рахуємо,
                # бо не можна перевести в флакони. Позначимо в підсумку.
                if pack <= 0 and unit in self._VOLUMETRIC_UNITS:
                    needs_pack[pid] = {"name": ln.get("product_name"),
                                       "unit": ln.get("unit") or ""}
                    continue
                mult = hc if basis == "head" else 1.0
                total = dose * times * mult * factor
                # Вміст упаковки заданий → у флаконах; інакше доза вже в складських
                # одиницях (табл/туба/шприц/шт) → потреба без ділення.
                packs = (total / pack) if pack > 0 else total
                blk = by_block.setdefault(bname, {})
                cell = blk.setdefault(pid, {"name": ln.get("product_name"),
                                            "unit": ln.get("unit") or "", "need": 0.0})
                cell["need"] += packs
                pr = by_product.setdefault(pid, {"name": ln.get("product_name"),
                                                 "unit": ln.get("unit") or "", "need": 0.0})
                pr["need"] += packs

        # Потреба — у цілих одиницях (флакон/упаковку не ділимо): округлюємо ВГОРУ.
        blocks_out = []
        for bname in sorted(by_block, key=lambda x: x.lower()):
            rows = [{"product_id": pid, "name": v["name"], "unit": v["unit"],
                     "need": math.ceil(v["need"]) if v["need"] > 0 else 0}
                    for pid, v in by_block[bname].items()]
            rows.sort(key=lambda x: (x["name"] or "").lower())
            blocks_out.append({"block": bname, "rows": rows})

        order_out = []
        seen_pids = set()
        for pid, v in by_product.items():
            if pid in excluded:
                continue
            need_w = math.ceil(v["need"]) if v["need"] > 0 else 0
            st = stock.get(pid, 0)
            order_out.append({"product_id": pid, "name": v["name"], "unit": v["unit"],
                              "barcode": (prod_meta.get(pid) or {}).get("barcode", ""),
                              "need": need_w, "stock": round(st, 2),
                              "order_qty": int(max(0, math.ceil(need_w - st))),
                              "in_scheme": True, "note": ""})
            seen_pids.add(pid)
        # Позиції, де не задано вмісту упаковки (мл/г) — у схемі, але без чисел.
        for pid, v in needs_pack.items():
            if pid in seen_pids or pid in excluded:
                continue
            order_out.append({"product_id": pid, "name": v["name"], "unit": v["unit"],
                              "barcode": (prod_meta.get(pid) or {}).get("barcode", ""),
                              "need": None, "stock": round(stock.get(pid, 0), 2),
                              "order_qty": None, "in_scheme": True, "note": "no_pack"})
            seen_pids.add(pid)
        # Решта товарів складу — НЕ задіяні в жодній схемі (показуємо всі).
        for p in products_all:
            pid = p["id"]
            if pid in seen_pids or pid in excluded:
                continue
            order_out.append({"product_id": pid, "name": p.get("name"),
                              "unit": p.get("unit") or "", "barcode": (p.get("barcode") or ""),
                              "need": None, "stock": round(stock.get(pid, 0), 2),
                              "order_qty": None, "in_scheme": False, "note": "not_in_scheme"})
        order_out.sort(key=lambda x: (x["name"] or "").lower())
        now = datetime.now()
        return {"category": category, "blocks": blocks_out, "order": order_out,
                "year": int(year) if year else now.year,
                "month": int(month) if (month and 1 <= int(month) <= 12) else now.month}

    def generate_product_code(self, category: Optional[str] = None) -> str:
        """Наступний вільний порядковий номенклатурний номер (000001, 000002 …).

        Нумерація НАСКРІЗНА по всіх товарах (аптека, матеріали, корми) —
        мінімум 6 знаків; якщо у базі вже є довший код, ширина росте під нього.
        Параметр category лишено на майбутнє (окремі нумерації по гілках)."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT code FROM products WHERE is_active = 1").fetchall()
        nums, width = [], 6
        for r in rows:
            c = (r[0] or "").strip()
            if c.isdigit():
                nums.append(int(c))
                width = max(width, len(c))
        nxt = (max(nums) + 1) if nums else 1
        return str(nxt).zfill(width)

    # -------------------------------------------------- генерація штрихкоду

    @staticmethod
    def _ean13_check_digit(digits12: str) -> int:
        """Контрольна (13-та) цифра штрихкоду EAN-13 за першими 12 цифрами."""
        s = 0
        for i, ch in enumerate(digits12):
            d = int(ch)
            s += d if i % 2 == 0 else d * 3
        return (10 - (s % 10)) % 10

    def generate_internal_barcode(self, prefix: str = "20") -> str:
        """Згенерувати унікальний внутрішній штрихкод EAN-13.

        Префікси 20–29 зарезервовані стандартом для внутрішнього
        використання, тож такий код не конфліктує зі штрихкодами
        виробників. Унікальність перевіряється по таблиці products.
        """
        import random
        body_len = 12 - len(prefix)          # кількість випадкових цифр
        with self._connect() as conn:
            for _ in range(60):
                payload = "".join(str(random.randint(0, 9))
                                  for _ in range(body_len))
                body = prefix + payload      # 12 цифр
                code = body + str(self._ean13_check_digit(body))
                taken = conn.execute(
                    "SELECT 1 FROM products WHERE barcode = ?", (code,),
                ).fetchone()
                if not taken:
                    return code
        raise RuntimeError("Не вдалося згенерувати унікальний штрихкод. "
                           "Спробуйте ще раз.")

    def get_product(self, product_id: int) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, name, barcode, code, unit, min_stock, supplier, notes, "
                "category, is_active FROM products WHERE id = ?",
                (int(product_id),)).fetchone()
        return dict(row) if row else None

    def update_product(self, product_id: int, **fields: Any) -> None:
        allowed = {"name", "barcode", "code", "unit", "min_stock", "supplier", "notes",
                   "dose_per_head", "dose_unit", "dose_interval_days", "pack_content",
                   "exclude_from_order"}
        # Прапорець виключення з замовлення → 0/1
        if "exclude_from_order" in fields:
            fields["exclude_from_order"] = 1 if str(fields.get("exclude_from_order")) in (
                "1", "True", "true", "on") else 0
        # Штрихкод необов'язковий: якщо передали порожній — призначаємо
        # внутрішній код (щоб не порушити NOT NULL/унікальність).
        if "barcode" in fields:
            bc = (str(fields.get("barcode") or "")).strip()
            fields["barcode"] = bc or self.generate_internal_barcode()
        sets, params = [], []
        for key, value in fields.items():
            if key in allowed and value is not None:
                sets.append(f"{key} = ?")
                params.append(value)
        if not sets:
            return
        params.append(product_id)
        with self._connect() as conn:
            code = (fields.get("code") or "").strip()
            if code and not code.isdigit():
                raise ValueError("Код товару має містити лише цифри.")
            if code and conn.execute(
                    "SELECT 1 FROM products WHERE code = ? AND id <> ? AND is_active = 1",
                    (code, product_id)).fetchone():
                raise ValueError(f"Товар з кодом «{code}» вже існує.")
            if "barcode" in fields:
                bc = fields["barcode"]
                if conn.execute(
                        "SELECT 1 FROM products WHERE barcode = ? AND id <> ?",
                        (bc, product_id)).fetchone():
                    raise ValueError(f"Товар зі штрихкодом «{bc}» вже існує.")
            conn.execute(f"UPDATE products SET {', '.join(sets)} WHERE id = ?", params)

    def delete_product(self, product_id: int) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE products SET is_active = 0 WHERE id = ?", (product_id,))

    # ------------------------------------------------------------------ націнка

    @staticmethod
    def _apply_product_sale_price(conn: sqlite3.Connection, product_id: int,
                                  sale_price: float) -> dict[str, float]:
        """Встановлює ЄДИНУ ціну продажу для товару та всіх його партій.
        Ціна продажу — головна (зберігається точно). Націнка % обчислюється
        автоматично від середньозваженої ціни закупки наявних партій.
        """
        sale_price = round(float(sale_price or 0), 2)
        agg = conn.execute(
            "SELECT COALESCE(SUM(qty), 0) AS tq, "
            "       COALESCE(SUM(qty * price_in), 0) AS sv "
            "FROM stock_batches WHERE product_id = ?",
            (product_id,),
        ).fetchone()
        tq = agg["tq"] or 0
        avg_cost = (agg["sv"] / tq) if tq else 0
        markup = round((sale_price / avg_cost - 1) * 100, 2) if avg_cost > 0 else 0
        conn.execute(
            "UPDATE products SET sale_price = ?, markup_pct = ? WHERE id = ?",
            (sale_price, markup, product_id),
        )
        # Ціна продажу єдина для всіх партій, а націнка % — індивідуальна:
        # вона рахується від ціни закупки КОНКРЕТНОЇ партії. Інакше для партій
        # із ціною, відмінною від середньої, націнка була б некоректною.
        conn.execute(
            """
            UPDATE stock_batches
            SET price_out = ?,
                markup_pct = CASE WHEN price_in > 0
                                  THEN ROUND((? / price_in - 1) * 100, 2)
                                  ELSE 0 END
            WHERE product_id = ?
            """,
            (sale_price, sale_price, product_id),
        )
        return {"sale_price": sale_price, "markup_pct": markup}

    def _avg_cost(self, conn: sqlite3.Connection, product_id: int) -> float:
        """Середньозважена ціна закупки наявних партій товару."""
        agg = conn.execute(
            "SELECT COALESCE(SUM(qty), 0) AS tq, "
            "       COALESCE(SUM(qty * price_in), 0) AS sv "
            "FROM stock_batches WHERE product_id = ?",
            (product_id,),
        ).fetchone()
        tq = agg["tq"] or 0
        return (agg["sv"] / tq) if tq else 0.0

    def set_product_markup(self, product_id: int, markup_pct: float) -> dict[str, Any]:
        """Змінити націнку товару. Націнка задає ціну продажу:
        ціна продажу = середня ціна закупки × (1 + націнка/100)."""
        markup_pct = float(markup_pct or 0)
        if markup_pct < 0:
            raise ValueError("Націнка не може бути від'ємною.")
        with self._connect() as conn:
            exists = conn.execute(
                "SELECT 1 FROM products WHERE id = ? AND is_active = 1", (product_id,)
            ).fetchone()
            if not exists:
                raise ValueError("Товар не знайдено.")
            sale_price = round(self._avg_cost(conn, product_id) * (1 + markup_pct / 100), 2)
            res = self._apply_product_sale_price(conn, product_id, sale_price)
        return {"product_id": product_id, **res}

    def set_product_sale_price(self, product_id: int, sale_price: float) -> dict[str, Any]:
        """Змінити ціну продажу товару напряму. Ціна продажу — головна
        величина: єдина для всіх партій; націнка % рахується автоматично."""
        sale_price = float(sale_price or 0)
        if sale_price < 0:
            raise ValueError("Ціна продажу не може бути від'ємною.")
        with self._connect() as conn:
            exists = conn.execute(
                "SELECT 1 FROM products WHERE id = ? AND is_active = 1", (product_id,)
            ).fetchone()
            if not exists:
                raise ValueError("Товар не знайдено.")
            res = self._apply_product_sale_price(conn, product_id, sale_price)
        return {"product_id": product_id, **res}

    # ------------------------------------------------------------------ suppliers

    def list_suppliers(self, category: Optional[str] = None) -> list[dict[str, Any]]:
        sql = ("SELECT id, name, notes, created_at FROM suppliers WHERE is_active = 1")
        params: list[Any] = []
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY name COLLATE NOCASE"
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def get_or_create_supplier(self, name: str, notes: str = "",
                               category: str = "pharmacy") -> Optional[int]:
        """Повертає id постачальника В МЕЖАХ КАТЕГОРІЇ. Якщо name порожнє — None.
        Дублі визначаються case-insensitive (з підтримкою юнікоду — кирилиця,
        діакритика тощо), бо SQLite LOWER() ASCII-only.
        """
        name = (name or "").strip()
        if not name:
            return None
        category = (category or "pharmacy").strip() or "pharmacy"
        normalized = name.casefold()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name FROM suppliers WHERE is_active = 1 AND category = ?",
                (category,),
            ).fetchall()
            for r in rows:
                if (r["name"] or "").casefold() == normalized:
                    return int(r["id"])
            try:
                cur = conn.execute(
                    "INSERT INTO suppliers (name, notes, category, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    (name, (notes or "").strip(), category, self._now()),
                )
                return int(cur.lastrowid)
            except sqlite3.IntegrityError:
                row = conn.execute(
                    "SELECT id FROM suppliers WHERE name = ? AND category = ?",
                    (name, category),
                ).fetchone()
                return int(row["id"]) if row else None

    def add_supplier(self, name: str, notes: str = "",
                     category: str = "pharmacy") -> int:
        """Явне додавання постачальника (для UI довідника)."""
        sid = self.get_or_create_supplier(name, notes, category)
        if sid is None:
            raise ValueError("Назва постачальника обов'язкова.")
        return sid

    def delete_supplier(self, supplier_id: int) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE suppliers SET is_active = 0 WHERE id = ?", (supplier_id,))

    # ------------------------------------------------------ блоки / отримувачі

    def _list_ref(self, table: str, category: Optional[str] = None) -> list[dict[str, Any]]:
        sql = f"SELECT id, name, notes, created_at FROM {table} WHERE is_active = 1"
        params: list[Any] = []
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY name COLLATE NOCASE"
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def _get_or_create_ref(self, table: str, name: str, notes: str = "",
                           category: str = "pharmacy") -> Optional[int]:
        """Спільна логіка довідника (блоки / отримувачі) В МЕЖАХ КАТЕГОРІЇ.
        None — якщо name порожнє."""
        name = (name or "").strip()
        if not name:
            return None
        category = (category or "pharmacy").strip() or "pharmacy"
        normalized = name.casefold()
        with self._connect() as conn:
            rows = conn.execute(
                f"SELECT id, name FROM {table} WHERE is_active = 1 AND category = ?",
                (category,),
            ).fetchall()
            for r in rows:
                if (r["name"] or "").casefold() == normalized:
                    return int(r["id"])
            try:
                cur = conn.execute(
                    f"INSERT INTO {table} (name, notes, category, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    (name, (notes or "").strip(), category, self._now()),
                )
                return int(cur.lastrowid)
            except sqlite3.IntegrityError:
                row = conn.execute(
                    f"SELECT id FROM {table} WHERE name = ? AND category = ?",
                    (name, category),
                ).fetchone()
                return int(row["id"]) if row else None

    def list_blocks(self, category: Optional[str] = None) -> list[dict[str, Any]]:
        # Як _list_ref, але додатково віддаємо herd_kind, subgroup і herd_group_id.
        sql = ("SELECT id, name, notes, created_at, herd_kind, subgroup, herd_group_id "
               "FROM blocks WHERE is_active = 1")
        params: list[Any] = []
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY name COLLATE NOCASE"
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def add_block(self, name: str, notes: str = "", category: str = "pharmacy",
                  herd_kind: str = "", subgroup: str = "") -> int:
        """Блок у межах групи (herd_kind) і підгрупи (subgroup). Однакові назви
        в різних групах — окремі блоки; повтор у тій самій групі повертає наявний."""
        name = (name or "").strip()
        if not name:
            raise ValueError("Назва блоку обов'язкова.")
        kind = herd_kind if herd_kind in ("cow", "young", "pig") else ""
        subgroup = (subgroup or "").strip()
        category = (category or "pharmacy").strip() or "pharmacy"
        normalized = name.casefold()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name FROM blocks WHERE is_active = 1 AND category = ? "
                "AND COALESCE(herd_kind,'') = ?", (category, kind)).fetchall()
            for r in rows:
                if (r["name"] or "").casefold() == normalized:
                    return int(r["id"])
            try:
                cur = conn.execute(
                    "INSERT INTO blocks (name, notes, category, created_at, herd_kind, subgroup) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (name, (notes or "").strip(), category, self._now(), kind, subgroup))
                return int(cur.lastrowid)
            except sqlite3.IntegrityError:
                # був м'яко видалений блок з такою назвою в цій групі — реактивуємо
                row = conn.execute(
                    "SELECT id FROM blocks WHERE name = ? AND category = ? "
                    "AND COALESCE(herd_kind,'') = ?", (name, category, kind)).fetchone()
                if row:
                    conn.execute("UPDATE blocks SET is_active = 1, notes = ?, subgroup = ? "
                                 "WHERE id = ?",
                                 ((notes or "").strip(), subgroup, int(row["id"])))
                    return int(row["id"])
                raise

    def set_block_kind(self, block_id: int, herd_kind: str = "") -> None:
        """Перенести блок у групу: 'cow' | 'young' | 'pig' | '' (не розподілено)."""
        kind = herd_kind if herd_kind in ("cow", "young", "pig") else ""
        with self._connect() as conn:
            try:
                conn.execute("UPDATE blocks SET herd_kind = ? WHERE id = ?", (kind, block_id))
            except sqlite3.IntegrityError:
                raise ValueError("Блок з такою назвою вже є в цій групі.")

    def set_block_subgroup(self, block_id: int, subgroup: str = "") -> None:
        """Призначити блоку підгрупу (2-й рівень: Дійні / Сухостій / Телята…)."""
        with self._connect() as conn:
            conn.execute("UPDATE blocks SET subgroup = ? WHERE id = ?",
                         ((subgroup or "").strip(), block_id))

    def set_block_herd_group(self, block_id: int, herd_group_id: Optional[int]) -> None:
        """Привʼязати секцію-блок до групи стада (звідки брати поголівʼя).
        None — звʼязок прибрано."""
        gid = int(herd_group_id) if herd_group_id not in (None, "", 0, "0") else None
        with self._connect() as conn:
            conn.execute("UPDATE blocks SET herd_group_id = ? WHERE id = ?", (gid, block_id))

    def current_herd_headcount(self, group_id: int) -> float:
        """Поточне поголівʼя секції = значення чинного періоду (на сьогодні)."""
        return self.section_headcount_on(group_id, date.today().isoformat())

    def section_headcount_on(self, section_id: int, day: str) -> float:
        """Поголівʼя секції на конкретну дату — з періоду, що її покриває
        (date_from <= day <= date_to; порожня date_to = відкритий період).
        Якщо періодів кілька — беремо з найпізнішим date_from."""
        day = (day or "").strip()[:10]
        with self._connect() as conn:
            row = conn.execute(
                "SELECT headcount FROM herd_section_periods WHERE section_id = ? "
                "AND (date_from = '' OR date_from <= ?) "
                "AND (date_to = '' OR date_to >= ?) "
                "ORDER BY date_from DESC LIMIT 1",
                (int(section_id), day, day)).fetchone()
        return float(row["headcount"]) if row else 0.0

    def active_section_names(self, day: str = "") -> list[str]:
        """Назви секцій, активних на дату (мають період, що покриває день).
        День порожній → сьогодні. Порядок — як у списку секцій."""
        day = (day or date.today().isoformat())[:10]
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT g.name FROM herd_groups g "
                "JOIN herd_section_periods p ON p.section_id = g.id "
                "WHERE g.is_active = 1 "
                "AND (p.date_from = '' OR p.date_from <= ?) "
                "AND (p.date_to = '' OR p.date_to >= ?) "
                "GROUP BY g.id ORDER BY g.sort_order, g.id", (day, day)).fetchall()
        return [r["name"] for r in rows]

    def delete_block(self, block_id: int) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE blocks SET is_active = 0 WHERE id = ?", (block_id,))

    def list_recipients(self, category: Optional[str] = None) -> list[dict[str, Any]]:
        return self._list_ref("recipients", category)

    def add_recipient(self, name: str, notes: str = "", category: str = "pharmacy") -> int:
        rid = self._get_or_create_ref("recipients", name, notes, category)
        if rid is None:
            raise ValueError("Імʼя отримувача обовʼязкове.")
        return rid

    def delete_recipient(self, recipient_id: int) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE recipients SET is_active = 0 WHERE id = ?", (recipient_id,))

    # ------------------------------------------------------------------ batches / moves

    def product_batches(self, product_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, lot_number, expires_on, qty, price_in, price_out, created_at
                FROM stock_batches
                WHERE product_id = ? AND qty > 0
                ORDER BY COALESCE(NULLIF(receipt_date, ''), substr(created_at, 1, 10)), created_at, id
                """,
                (product_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def product_batches_detail(self, product_id: int) -> list[dict[str, Any]]:
        """Партії товару з повними даними — для розкривного вмісту складу.
        received_qty = СУМА усіх IN-рухів (первинний прихід + всі корекції+).
        Окремий subquery, щоб LEFT JOIN не множив рядки при кількох рухах."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT b.id, b.lot_number, b.expires_on, b.qty,
                       b.price_in, b.price_in_no_vat, b.price_out, b.vat_rate,
                       b.receipt_date, b.invoice_number, b.created_at,
                       s.name AS supplier,
                       COALESCE(in_sum.received_qty, b.qty) AS received_qty
                FROM stock_batches b
                LEFT JOIN suppliers s ON s.id = b.supplier_id
                LEFT JOIN (
                    SELECT batch_id, SUM(qty) AS received_qty
                    FROM stock_moves WHERE move_type = 'IN'
                    GROUP BY batch_id
                ) in_sum ON in_sum.batch_id = b.id
                WHERE b.product_id = ? AND b.qty > 0
                ORDER BY COALESCE(NULLIF(b.receipt_date, ''), substr(b.created_at, 1, 10)) DESC,
                         b.created_at DESC
                """,
                (product_id,),
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            received = d["received_qty"] if d["received_qty"] is not None else d["qty"]
            d["received_qty"] = received
            d["consumed_qty"] = round(received - d["qty"], 4)
            result.append(d)
        return result

    def export_full(self, category: Optional[str] = None) -> list[dict[str, Any]]:
        """Повний зріз складу: рядок на кожну партію кожного товару.
        Товари без партій теж потрапляють (з порожніми полями партії)."""
        cat_clause = " AND p.category = ?" if category else ""
        cat_params = [category] if category else []
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT p.name, p.barcode, p.code, p.unit, p.min_stock,
                       p.markup_pct, p.sale_price, p.notes,
                       (SELECT COALESCE(SUM(qty), 0) FROM stock_batches
                        WHERE product_id = p.id) AS total_qty,
                       b.lot_number, b.expires_on, b.qty AS batch_qty,
                       b.price_in, b.price_in_no_vat, b.price_out, b.vat_rate,
                       b.receipt_date, b.invoice_number,
                       s.name AS supplier,
                       m.qty AS received_qty
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id AND b.qty > 0
                LEFT JOIN suppliers s ON s.id = b.supplier_id
                LEFT JOIN stock_moves m ON m.batch_id = b.id AND m.move_type = 'IN'
                WHERE p.is_active = 1{cat_clause}
                ORDER BY p.name COLLATE NOCASE,
                         COALESCE(b.expires_on, '9999-12-31'), b.created_at
                """,
                cat_params,
            ).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            if self._is_water(d.get("name")):   # вода: залишок завжди 0
                d["total_qty"] = 0
                d["batch_qty"] = 0
            out.append(d)
        return out

    def set_batch_expiry(self, batch_id: int, expires_on: str | None) -> dict[str, Any]:
        """Змінити термін придатності партії (з розкритого вмісту складу)."""
        expires_on = (expires_on or "").strip() or None
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE stock_batches SET expires_on = ? WHERE id = ?",
                (expires_on, batch_id),
            )
            if cur.rowcount == 0:
                raise ValueError("Партію не знайдено.")
        return {"batch_id": batch_id, "expires_on": expires_on}

    def receive_stock(
        self,
        barcode: str,
        qty: float,
        lot_number: str,
        expires_on: str | None,
        *,
        # ціни / ПДВ
        price_in_no_vat: float = 0,
        price_in: float = 0,            # ціна закупки з ПДВ (зберігається як основна)
        vat_rate: float = 20,
        markup_pct: float = 0,
        price_out: float = 0,           # ціна продажу (можна задати вручну,
                                        # інакше = price_in * (1 + markup/100))
        # дані накладної
        invoice_number: str = "",
        invoice_date: str = "",
        receipt_date: str = "",
        supplier_name: str = "",
        note: str = "",
        # додаткові (необов'язкові — для backward compat / зовнішнього виклику)
        price_out_override: float | None = None,
        user_id: Optional[int] = None,
    ) -> dict[str, Any]:
        product = self.get_product_by_barcode(barcode)
        if not product:
            raise ValueError("Товар зі штрихкодом не знайдено.")
        qty = float(qty or 0)
        if qty <= 0:
            raise ValueError("Кількість повинна бути більшою за 0.")

        # Фактична дата приходу — обов'язкова; якщо порожня, ставимо сьогодні
        receipt_date = (receipt_date or "").strip() or self._now()[:10]

        # Постачальник і номер накладної — обов'язкові
        if not (supplier_name or "").strip():
            raise ValueError("Вкажіть постачальника.")
        if not (invoice_number or "").strip():
            raise ValueError("Вкажіть номер накладної.")

        vat_rate = float(vat_rate or 0)
        markup_pct = float(markup_pct or 0)
        # Вода безкоштовна — прихід завжди за ціною 0 (щоб не роздувати баланс)
        if str(product.get("name", "")).strip().lower() in self._WATER_NAMES:
            price_in = price_in_no_vat = price_out = 0.0
            vat_rate = 0.0
        price_in_no_vat = float(price_in_no_vat or 0)
        price_in = float(price_in or 0)

        # Якщо вказана лише одна з пар цін — обчислити другу за ставкою ПДВ
        if price_in and not price_in_no_vat and vat_rate > 0:
            price_in_no_vat = round(price_in / (1 + vat_rate / 100), 4)
        elif price_in_no_vat and not price_in:
            price_in = round(price_in_no_vat * (1 + vat_rate / 100), 4)

        # Ціна закупки та ціна продажу — необов'язкові (некомерційна аптека).
        # Якщо ціну без ПДВ не задано, але є ціна з ПДВ без ставки — беремо як є.
        if price_in_no_vat <= 0 and price_in > 0:
            price_in_no_vat = price_in

        # Ціна продажу: пріоритет — явний override, інакше з націнки
        price_out = float(price_out or 0)
        if price_out_override is not None:
            price_out = float(price_out_override)
        if not price_out and price_in and markup_pct:
            price_out = round(price_in * (1 + markup_pct / 100), 2)
        # Якщо ціну продажу задано вручну, а націнку — ні: визначаємо націнку
        if price_out and price_in and not markup_pct:
            markup_pct = round((price_out / price_in - 1) * 100, 2)

        # get-or-create постачальника у категорії товару (гілка приходу)
        supplier_id = (self.get_or_create_supplier(
            supplier_name, category=product.get("category", "pharmacy"))
            if supplier_name else None)

        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO stock_batches (
                    product_id, lot_number, expires_on, qty,
                    price_in, price_in_no_vat, price_out,
                    vat_rate, markup_pct,
                    invoice_number, invoice_date, receipt_date,
                    supplier_id,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    product["id"], (lot_number or "").strip(),
                    (expires_on or None), qty,
                    price_in, price_in_no_vat, price_out,
                    vat_rate, markup_pct,
                    (invoice_number or "").strip(), (invoice_date or "").strip(),
                    (receipt_date or "").strip(),
                    supplier_id,
                    self._op_ts(receipt_date),
                ),
            )
            batch_id = cur.lastrowid

            # Ціна продажу — головна: останній введений price_out стає
            # єдиною ціною продажу всіх партій товару; націнка обчислюється.
            self._apply_product_sale_price(conn, product["id"], price_out)

            # Складаємо примітку до руху: номер накладної + користувацька примітка
            move_note = (note or "").strip()
            if invoice_number:
                inv_tag = f"Накл. {invoice_number.strip()}"
                move_note = f"{inv_tag} | {move_note}" if move_note else inv_tag

            conn.execute(
                """
                INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, qty,
                                         note, created_at, price, total, user_id)
                VALUES (?, ?, ?, 'IN', ?, ?, ?, ?, ?, ?)
                """,
                (product["id"], batch_id, product["barcode"], qty,
                 move_note, self._op_ts(receipt_date), price_in, qty * price_in, user_id),
            )
        return {
            "product": product,
            "batch_id": batch_id,
            "qty": qty,
            "price_in_no_vat": price_in_no_vat,
            "price_in": price_in,
            "price_out": price_out,
            "sum_no_vat": round(qty * price_in_no_vat, 4),
            "sum_with_vat": round(qty * price_in, 4),
            "vat_amount": round(qty * (price_in - price_in_no_vat), 4),
            "invoice_number": invoice_number,
            "invoice_date": invoice_date,
            "receipt_date": receipt_date,
            "supplier_id": supplier_id,
            "supplier_name": (supplier_name or "").strip(),
        }

    # ------------------------------------------- довідник кормів (сівба)
    # Корми з експорту Profeed: (назва, код Profeed, орієнтовна ціна ₴/кг).
    # Код Profeed — ключ зіставлення «Облік ферми» ↔ Profeed при імпорті.
    FEED_SEED = [
        ("Солома", "12089", 0.435), ("Силос кукурудзяний", "12090", 2.3007),
        ("Меляса", "12091", 6.60), ("Сіно", "", 0.65),
        ("Кукурудзяна дерть", "12110", 9.4192), ("Макуха соняшникова", "12100", 11.30),
        ("Макуха соєва", "12101", 20.60), ("Шрот ріпаковий", "12102", 13.30),
        ("Шрот соєвий", "12103", 20.004), ("Барда післяспиртова", "12113", 9.80),
        ("Сіль", "12105", 5.904), ("Крейда", "12106", 4.50),
        ("Сода", "12108", 22.00), ("Мікоцид", "12109", 300.00),
        ("Бустермол", "12111", 36.93), ("Фідпак Лакт", "12112", 69.98),
        ("Предстартер комбікорм", "", 21.00), ("Солома підстилка", "", 0.435),
    ]
    # Комбікорми: (назва, код Profeed, заміс кг, [(компонент, кг на заміс)])
    COMBI_SEED = [
        ("К2", "12093", 12.0, [
            ("Кукурудзяна дерть", 4.0), ("Шрот ріпаковий", 2.5), ("Макуха соєва", 2.0),
            ("Шрот соєвий", 1.2), ("Барда післяспиртова", 1.0),
            ("Макуха соняшникова", 0.5), ("Крейда", 0.3), ("Сода", 0.15),
            ("Сіль", 0.13), ("Бустермол", 0.1), ("Фідпак Лакт", 0.1), ("Мікоцид", 0.02)]),
        ("К4", "", 6.01, [
            ("Кукурудзяна дерть", 2.0), ("Шрот ріпаковий", 1.25), ("Макуха соєва", 1.0),
            ("Шрот соєвий", 0.6), ("Барда післяспиртова", 0.5),
            ("Макуха соняшникова", 0.25), ("Крейда", 0.15), ("Сода", 0.075),
            ("Сіль", 0.065), ("Бустермол", 0.05), ("Фідпак Лакт", 0.05),
            ("Мікоцид", 0.01)]),
        ("К5", "12096", 2.57, [
            ("Макуха соняшникова", 1.0), ("Шрот ріпаковий", 0.8), ("Макуха соєва", 0.5),
            ("Крейда", 0.15), ("Сіль", 0.1), ("Мікоцид", 0.02)]),
        ("К7", "12098", 1.88, [
            ("Макуха соняшникова", 1.0), ("Барда післяспиртова", 0.6),
            ("Сіль", 0.18), ("Крейда", 0.1)]),
    ]
    # Не корм — вода з міксера; у Profeed присутня, але списувати її не треба.
    FEED_IGNORE = [("H2O", "12088"), ("Вода", "")]

    def _seed_feed_once(self) -> None:
        """Один раз на базу наповнити довідник кормів (при першому запуску модуля).

        Прапорець у app_settings гарантує, що це станеться рівно один раз:
        якщо користувач потім видалить якийсь корм — він не повернеться.
        Помилка сівби не має завалювати старт застосунку."""
        try:
            if self.get_setting("feed_catalog_seeded") == "1":
                return
            self.seed_feed_catalog()
            self.set_setting("feed_catalog_seeded", "1")
        except Exception as exc:                      # noqa: BLE001
            print(f"[DB] сівба довідника кормів пропущена: {exc}")

    def seed_feed_catalog(self, user_id: Optional[int] = None) -> dict[str, Any]:
        """Заповнити довідник кормів відомими позиціями з експорту Profeed.

        Ідемпотентно: наявні корми не дублюються й не змінюються — додається
        лише те, чого немає. Разом із кормами створюється зіставлення кодів
        Profeed і рецепти комбікормів (як підказка для виробництва)."""
        added, mapped, recipes = [], 0, 0
        existing = {(p["name"] or "").strip().lower(): p["id"]
                    for p in self.list_products(category="feed")}

        def ensure(name: str, code: str) -> int:
            nonlocal mapped
            pid = existing.get(name.strip().lower())
            if pid is None:
                pid = self.add_product(name=name, barcode="", unit="кг", min_stock=0,
                                       supplier="", notes="", category="feed",
                                       code=self.generate_product_code("feed"))
                pid = pid if isinstance(pid, int) else pid["id"]
                existing[name.strip().lower()] = pid
                added.append(name)
            if code:
                with self._connect() as conn:
                    conn.execute(
                        "INSERT INTO feed_map (profeed_code, feed_name, product_id, ignored) "
                        "VALUES (?,?,?,0) ON CONFLICT(profeed_code) DO UPDATE SET "
                        "feed_name = excluded.feed_name, product_id = excluded.product_id",
                        (code, name, pid))
                mapped += 1
            return pid

        for name, code, _price in self.FEED_SEED:
            ensure(name, code)
        for name, code, _batch, lines in self.COMBI_SEED:
            pid = ensure(name, code)
            with self._connect() as conn:
                if conn.execute("SELECT 1 FROM feed_recipes WHERE product_id = ?",
                                (pid,)).fetchone():
                    continue
                cur = conn.execute(
                    "INSERT INTO feed_recipes (product_id, note, is_active, created_at) "
                    "VALUES (?,?,1,?)", (pid, "Імпорт зі «Структура КК»", self._now()))
                rid = cur.lastrowid
                for i, (cname, kg) in enumerate(lines):
                    cpid = existing.get(cname.strip().lower())
                    if cpid:
                        conn.execute(
                            "INSERT INTO feed_recipe_lines (recipe_id, product_id, qty_kg,"
                            " sort_order) VALUES (?,?,?,?)", (rid, cpid, kg, i))
            recipes += 1
        with self._connect() as conn:
            for name, code in self.FEED_IGNORE:
                if code:
                    conn.execute(
                        "INSERT INTO feed_map (profeed_code, feed_name, product_id, ignored) "
                        "VALUES (?,?,NULL,1) ON CONFLICT(profeed_code) DO UPDATE SET "
                        "ignored = 1", (code, name))
        return {"added": added, "added_count": len(added),
                "mapped": mapped, "recipes": recipes}

    # ------------------------------------------- виробництво комбікормів
    def next_production_doc_no(self) -> str:
        """Найменший вільний номер ВК-N.

        Рахувати як COUNT+1 не можна: після видалення документа кількість
        зменшується, і наступний номер збігся б із наявним (напр. лишились
        ВК-11, ВК-12 — а видача дала б знову ВК-12). Тому шукаємо першу
        «дірку» в послідовності: видалений ВК-10 повернеться саме як ВК-10."""
        import re
        with self._connect() as conn:
            rows = conn.execute("SELECT doc_no FROM feed_productions").fetchall()
        used = set()
        for r in rows:
            m = re.match(r"ВК-(\d+)$", str(r[0] or "").strip())
            if m:
                used.add(int(m.group(1)))
        n = 1
        while n in used:
            n += 1
        return f"ВК-{n}"

    def save_feed_recipe(self, *, product_id: Optional[int] = None,
                         name: str = "", lines: Optional[list] = None,
                         note: str = "") -> dict[str, Any]:
        """Створити або оновити рецепт комбікорму.

        Якщо product_id не задано — заводимо новий корм з такою назвою
        (комбікорм є звичайним товаром категорії feed, тому його можна
        оприбутковувати, списувати й бачити в залишках).
        Рядки рецепта завжди перезаписуються цілком — так простіше й
        передбачуваніше, ніж звіряти кожен окремо."""
        lines = [l for l in (lines or []) if float(l.get("qty_kg") or 0) > 0]
        if not lines:
            raise ValueError("Додайте хоча б один компонент із кількістю.")

        if product_id:
            prod = self.get_product(int(product_id))
            if not prod:
                raise ValueError("Комбікорм не знайдено.")
            product_id = int(product_id)
        else:
            name = (name or "").strip()
            if not name:
                raise ValueError("Вкажіть назву комбікорму.")
            dup = [p for p in self.list_products(category="feed")
                   if (p["name"] or "").strip().lower() == name.lower()]
            if dup:
                product_id = dup[0]["id"]        # такий корм уже є — чіпляємо рецепт
            else:
                pid = self.add_product(name=name, barcode="", unit="кг", min_stock=0,
                                       supplier="", notes="", category="feed",
                                       code=self.generate_product_code("feed"))
                product_id = pid if isinstance(pid, int) else pid["id"]

        if any(int(l["product_id"]) == product_id for l in lines):
            raise ValueError("Комбікорм не може бути власним компонентом.")

        with self._connect() as conn:
            row = conn.execute("SELECT id FROM feed_recipes WHERE product_id = ?",
                               (product_id,)).fetchone()
            if row:
                rid = row["id"]
                conn.execute("UPDATE feed_recipes SET note = ?, is_active = 1 "
                             "WHERE id = ?", (note, rid))
                conn.execute("DELETE FROM feed_recipe_lines WHERE recipe_id = ?", (rid,))
            else:
                rid = conn.execute(
                    "INSERT INTO feed_recipes (product_id, note, is_active, created_at) "
                    "VALUES (?,?,1,?)", (product_id, note, self._now())).lastrowid
            for i, l in enumerate(lines):
                conn.execute(
                    "INSERT INTO feed_recipe_lines (recipe_id, product_id, qty_kg,"
                    " sort_order) VALUES (?,?,?,?)",
                    (rid, int(l["product_id"]), float(l["qty_kg"]), i))
        return {"product_id": product_id, "recipe_id": rid, "lines": len(lines)}

    def delete_feed_recipe(self, product_id: int) -> None:
        """Прибрати рецепт. Сам корм лишається у довіднику — з ним могли
        бути операції, тож видаляти товар не можна."""
        with self._connect() as conn:
            row = conn.execute("SELECT id FROM feed_recipes WHERE product_id = ?",
                               (product_id,)).fetchone()
            if not row:
                return
            conn.execute("DELETE FROM feed_recipe_lines WHERE recipe_id = ?", (row["id"],))
            conn.execute("DELETE FROM feed_recipes WHERE id = ?", (row["id"],))

    def list_feed_recipes_full(self) -> list[dict[str, Any]]:
        """Усі рецепти з компонентами — довідник структури комбікормів.

        Крім кілограмів на заміс віддаємо частку кожного компонента у відсотках
        і залишок КК на складі: так видно і структуру, і наявність."""
        out = []
        for c in self.list_combifeeds():
            r = self.get_feed_recipe(c["id"])
            total = r["batch_kg"] or 0
            for l in r["lines"]:
                l["share_pct"] = round(l["qty_kg"] / total * 100, 2) if total else 0
            with self._connect() as conn:
                stock = conn.execute(
                    "SELECT COALESCE(SUM(qty), 0) FROM stock_batches WHERE product_id = ?",
                    (c["id"],)).fetchone()[0]
            out.append({**c, "batch_kg": r["batch_kg"], "lines": r["lines"],
                        "stock_qty": stock})
        return out

    def list_combifeeds(self) -> list[dict[str, Any]]:
        """Комбікорми — це корми, для яких заведено рецепт."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.id, p.code, p.name, r.id AS recipe_id, r.note "
                "FROM feed_recipes r JOIN products p ON p.id = r.product_id "
                "WHERE r.is_active = 1 ORDER BY p.name").fetchall()
        return [dict(r) for r in rows]

    def get_feed_recipe(self, product_id: int) -> dict[str, Any]:
        """Рецепт комбікорму з компонентами й поточними залишками.

        qty_kg — кілограми на один заміс; використовуються як пропорція:
        при виробництві масштабуються під фактичний випуск."""
        with self._connect() as conn:
            r = conn.execute(
                "SELECT id, product_id, note FROM feed_recipes "
                "WHERE product_id = ? AND is_active = 1", (product_id,)).fetchone()
            if not r:
                return {"recipe_id": None, "batch_kg": 0, "lines": []}
            lines = conn.execute(
                "SELECT l.product_id, p.name, p.code, l.qty_kg, "
                "  COALESCE((SELECT SUM(qty) FROM stock_batches b "
                "            WHERE b.product_id = l.product_id), 0) AS stock_qty, "
                "  COALESCE((SELECT SUM(b.qty * b.price_in) / NULLIF(SUM(b.qty), 0) "
                "            FROM stock_batches b WHERE b.product_id = l.product_id "
                "            AND b.qty > 0), 0) AS avg_price, "
                "  COALESCE((SELECT SUM(b.qty * COALESCE(NULLIF(b.price_in_no_vat,0), b.price_in)) "
                "            / NULLIF(SUM(b.qty), 0) FROM stock_batches b "
                "            WHERE b.product_id = l.product_id AND b.qty > 0), 0) AS avg_price_no_vat "
                "FROM feed_recipe_lines l JOIN products p ON p.id = l.product_id "
                "WHERE l.recipe_id = ? ORDER BY l.sort_order, l.id", (r["id"],)).fetchall()
        lines = [dict(x) for x in lines]
        return {"recipe_id": r["id"], "note": r["note"],
                "batch_kg": round(sum(x["qty_kg"] for x in lines), 6), "lines": lines}

    # ------------------------------------------- імпорт ГОДІВЛІ з Profeed
    # Суфікс міксера → мітка групи тварин (для пошуку блоку й підпису).
    _FEED_GROUP_HINT = [
        ("С1", "Сухостій-1", "Сухостій"), ("С2", "Сухостій-2", "Сухостій"),
        ("С", "Сухостій", "Сухостій"), ("Д", "Дійні", "Дійн"),
        ("М", "Молодняк", "Молодн"), ("Т", "Телята", "Теля"),
    ]

    @classmethod
    def _feed_group_from_mixer(cls, mixer: str):
        """Назва роздачі (групи) з «Міксер» → (код, підпис). Порожнє — якщо це
        не роздача (виробництво КК тощо).

        У Profeed роздачі звуться «Група-1», «Група-2»… — саме їх читаємо.
        Підтримуємо також старий формат «N-ша роздача/Д»."""
        import re
        s = str(mixer or "").strip()
        if not s:
            return "", ""
        # Виробництво комбікорму має «(К-N)» — це не роздача годівлі.
        if re.search(r"\(\s*К\s*-?\s*\d+\s*\)", s, re.IGNORECASE):
            return "", ""
        # Основний формат: «Група-1», «Група 2», «Group 3».
        m = re.search(r"груп[аи]\s*[-–—]?\s*(\d+)", s, re.IGNORECASE)
        if m:
            code = "Група-" + m.group(1)
            return code, code
        # Запасний (старий) формат: «… роздача / Х».
        m = re.search(r"роздача\s*/\s*([A-Za-zА-Яа-яІіЇїЄє0-9]+)", s, re.IGNORECASE)
        if m:
            suf = m.group(1).strip().upper().replace("C", "С")
            for code, label, _hint in cls._FEED_GROUP_HINT:
                if suf.startswith(code):
                    return code, label
            return suf, suf
        return "", ""

    def list_profeed_feed_groups(self, folder: str) -> dict[str, Any]:
        """Список секцій-роздач зі звітів Profeed — значення колонки «Група»
        на рядках «Вигрузка» (Група-1…Група-6, Сухостій-1, Телята 3-6…).
        Рядки виробництва комбікорму (міксер «…(К-N)») відкидаємо."""
        import glob
        import re
        import openpyxl
        folder = (folder or "").strip()
        p = Path(folder).expanduser()
        if not p.exists():
            return {"error": f"Теку не знайдено: {folder}", "groups": []}
        files = sorted(glob.glob(str(p / "*.xlsx")) + glob.glob(str(p / "*.xls")))
        if not files:
            return {"error": "У теці немає файлів .xlsx", "groups": []}
        labels: dict[str, bool] = {}
        kk = re.compile(r"\(\s*К\s*-?\s*\d+\s*\)", re.IGNORECASE)
        for fp in files:
            try:
                wb = openpyxl.load_workbook(fp, read_only=True, data_only=True)
            except Exception:  # noqa: BLE001
                continue
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                hi = next((i for i, r in enumerate(rows[:6])
                           if "Група" in {str(c).strip() for c in r if c}), None)
                if hi is None:
                    continue
                h = [str(c).strip() if c is not None else "" for c in rows[hi]]
                gi = h.index("Група")
                mi = h.index("Міксер") if "Міксер" in h else None
                for r in rows[hi + 1:]:
                    g = str(r[gi] or "").strip() if gi < len(r) else ""
                    if not g:
                        continue
                    mixer = str(r[mi] or "") if mi is not None and mi < len(r) else ""
                    if kk.search(mixer):        # роздача комбікорму — не секція
                        continue
                    labels[g] = True
            wb.close()
        groups = sorted(labels.keys(), key=lambda s: (len(s), s))
        return {"groups": groups, "count": len(groups), "files": len(files)}

    def scan_profeed_feedings(self, folder: str) -> dict[str, Any]:
        """Знайти у звітах Profeed роздачі кормів (годівлю), ще не списані.

        Одиниця роздачі — «№ партії» (усі рядки Загрузки + один рядок Вигрузки).
        Секція береться з колонки «Група» (Група-1…, Сухостій-1, Телята 3-6),
        поголів'я — з «Поголів'я в секції» (рядок Вигрузки). Компоненти для
        списання — інгредієнти рядків «Загрузка» за фактом (вода H2O — ні).
        Роздачі комбікорму («…(К-N)») пропускаємо. Ключ — «ГД-№партії»."""
        import glob
        import re as _re
        import openpyxl

        folder = (folder or "").strip()
        p = Path(folder).expanduser()
        if not p.exists():
            return {"error": f"Теку не знайдено: {folder}", "items": []}
        files = sorted(glob.glob(str(p / "*.xlsx")) + glob.glob(str(p / "*.xls")))
        if not files:
            return {"error": "У теці немає файлів .xlsx", "items": []}

        feeds = self.list_products(category="feed")
        by_name = {(f["name"] or "").strip().lower(): f for f in feeds}
        blocks = self.list_blocks(category="feed")
        kk_re = _re.compile(r"\(\s*К\s*-?\s*\d+\s*\)", _re.IGNORECASE)
        with self._connect() as conn:
            done = {r[0] for r in conn.execute(
                "SELECT DISTINCT sale_no FROM stock_moves "
                "WHERE sale_no LIKE 'ГД-%'").fetchall()}

        def find_block(label):
            lo = (label or "").strip().lower()
            for b in blocks:
                if lo and lo == (b["name"] or "").strip().lower():
                    return b
            for b in blocks:                       # частковий збіг
                if lo and lo in (b["name"] or "").lower():
                    return b
            return None

        HDR = {"Інгредієнт, назва", "№ партії", "Статус", "Група"}
        # № партії -> агрегат роздачі
        agg: dict[str, dict] = {}

        for fp in files:
            try:
                wb = openpyxl.load_workbook(fp, read_only=True, data_only=True)
            except Exception:  # noqa: BLE001
                continue
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                hi = next((i for i, r in enumerate(rows[:6])
                           if HDR <= {str(c).strip() for c in r if c}), None)
                if hi is None:
                    continue
                h = [str(c).strip() if c is not None else "" for c in rows[hi]]
                ix = {n: h.index(n) for n in
                      ("Дата", "Міксер", "№ партії", "Статус", "Інгредієнт, назва",
                       "Фактична кількість, кг", "Група", "Раціон, назва",
                       "Поголівʼя в секції") if n in h}
                need = ("№ партії", "Статус", "Група", "Інгредієнт, назва")
                if any(n not in ix for n in need):
                    continue

                def col(r, n):
                    j = ix.get(n)
                    return r[j] if j is not None and j < len(r) else None

                for r in rows[hi + 1:]:
                    part = str(col(r, "№ партії") or "").strip()
                    if not part:
                        continue
                    mixer = str(col(r, "Міксер") or "")
                    if kk_re.search(mixer):        # роздача КК — не годівля секції
                        continue
                    a = agg.setdefault(part, {
                        "date": "", "group_label": "", "ration": "",
                        "feeds": {}, "kg_loaded": 0.0, "kg_loaded_all": 0.0,
                        "kg_distributed": 0.0, "headcount": 0.0})
                    dt = col(r, "Дата")
                    if dt and not a["date"]:
                        a["date"] = str(dt)[:10]
                    status = str(col(r, "Статус") or "").strip().lower()
                    fact = self._to_float(col(r, "Фактична кількість, кг") or 0)
                    if status.startswith("загр"):          # інгредієнт у міксер
                        name = str(col(r, "Інгредієнт, назва") or "").strip()
                        if fact > 0:
                            a["kg_loaded_all"] += fact    # весь обсяг (з водою) — для втрат
                        if name and name.lower() not in self._PROFEED_SKIP and fact > 0:
                            a["feeds"][name] = a["feeds"].get(name, 0.0) + fact
                            a["kg_loaded"] += fact         # без води — для списання/вартості
                    elif status.startswith("вигр"):         # роздано секції
                        g = str(col(r, "Група") or "").strip()
                        if g:
                            a["group_label"] = g
                        a["ration"] = str(col(r, "Раціон, назва") or "").strip() or a["ration"]
                        a["kg_distributed"] += max(0.0, fact)
                        a["headcount"] = max(a["headcount"],
                                             self._to_float(col(r, "Поголівʼя в секції") or 0))
            wb.close()

        items = []
        for part, a in agg.items():
            if not a["group_label"] or not a["feeds"]:
                continue                            # неповна роздача
            src_key = f"ГД-{part}"
            if src_key in done:
                continue
            blk = find_block(a["group_label"])
            lines, total, unknown = [], 0.0, []
            for nm, q in sorted(a["feeds"].items()):
                prod = by_name.get(nm.lower())
                lines.append({"name": nm, "qty": round(q, 3),
                              "product_id": prod["id"] if prod else None,
                              "unknown": prod is None})
                total += q
                if not prod:
                    unknown.append(nm)
            items.append({
                "src_key": src_key, "date": a["date"], "part": part,
                "group_label": a["group_label"], "ration": a["ration"],
                "block_id": blk["id"] if blk else None,
                "block_name": blk["name"] if blk else "",
                "lines": lines, "total": round(total, 3),
                "kg_loaded": round(a["kg_loaded"], 3),
                "kg_loaded_all": round(a["kg_loaded_all"], 3),
                "kg_distributed": round(a["kg_distributed"], 3),
                "loss": round(a["kg_loaded_all"] - a["kg_distributed"], 3),
                "headcount": round(a["headcount"], 1),
                "unknown_feeds": sorted(set(unknown)),
            })
        return {"items": sorted(items, key=lambda x: (x["date"], x["group_label"], x["part"])),
                "count": len(items), "files": len(files)}

    def import_profeed_feedings(self, folder: str, src_keys: list,
                                user_id: Optional[int] = None) -> dict[str, Any]:
        """Списати обрані роздачі (годівлю) як WRITE_OFF, за днем і групою.
        Ідемпотентність — ключ ГД-дата-група у sale_no руху."""
        scan = self.scan_profeed_feedings(folder)
        if scan.get("error"):
            return scan
        want = set(src_keys or [])
        chosen = [it for it in scan["items"] if it["src_key"] in want]
        done, failed = [], []
        for it in chosen:
            comps = [{"product_id": l["product_id"], "qty": l["qty"]}
                     for l in it["lines"] if l["product_id"]]
            miss = [l["name"] for l in it["lines"] if not l["product_id"]]
            if miss:
                failed.append({"src_key": it["src_key"],
                               "error": "немає на складі: " + ", ".join(miss)})
                continue
            try:
                res = self.write_off_feeding(
                    src_key=it["src_key"], components=comps, op_date=it["date"],
                    block_id=it["block_id"],
                    note=f"Годівля Profeed · {it['group_label']}", user_id=user_id)
                if res.get("skipped"):
                    failed.append({"src_key": it["src_key"], "error": "вже списано"})
                else:
                    # журнал роздачі: секція, кг, поголів'я зі звіту
                    with self._connect() as conn:
                        conn.execute(
                            "INSERT OR IGNORE INTO feeding_events (src_key, op_date, "
                            "group_label, block_id, ration, kg_loaded, kg_loaded_all, "
                            "kg_distributed, headcount, created_at) "
                            "VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (it["src_key"], it["date"], it["group_label"], it["block_id"],
                             it.get("ration", ""), it.get("kg_loaded", 0),
                             it.get("kg_loaded_all", 0), it.get("kg_distributed", 0),
                             it.get("headcount", 0), self._now()))
                    done.append({**res, "group": it["group_label"], "date": it["date"]})
            except ValueError as exc:
                failed.append({"src_key": it["src_key"], "error": str(exc)})
        return {"done": done, "done_count": len(done), "failed": failed}

    def auto_writeoff_feedings(self, user_id: Optional[int] = None) -> dict[str, Any]:
        """Автосписання: зафіксувати всі ще не списані заміси рівно за «Рухом
        кормів» (той самий скан, що й аналітика). Ідемпотентно."""
        return self.writeoff_from_movements(user_id=user_id)

    def write_off_feeding(self, *, src_key: str, components: list, op_date: str = "",
                          block_id: Optional[int] = None, note: str = "",
                          user_id: Optional[int] = None,
                          allow_negative: bool = False) -> dict[str, Any]:
        """Списати корми годівлі за FIFO (move_type WRITE_OFF).

        src_key (ГД-№партії) — ключ ідемпотентності: повтор ігнорується.
        allow_negative=True — списуємо повний факт навіть якщо бракує залишку:
        решта йде «в мінус» (борг), який вирівняється майбутнім приходом.
        Інакше — «усе або нічого» (при нестачі — відкат)."""
        src_key = (src_key or "").strip()
        comps = [c for c in (components or []) if float(c.get("qty") or 0) > 0]
        if not comps:
            raise ValueError("Немає що списувати.")
        with self._connect() as conn:
            if src_key and conn.execute(
                    "SELECT 1 FROM stock_moves WHERE sale_no = ?", (src_key,)).fetchone():
                return {"skipped": True, "src_key": src_key}
            op_date = (op_date or "").strip()[:10] or date.today().isoformat()
            now = self._now()
            created = f"{op_date} {now[11:]}" if len(now) >= 19 else now
            cost = 0.0
            debt = []
            if not allow_negative:
                # «усе або нічого»: спершу перевіряємо, що всього вистачає
                for c in comps:
                    pid = int(c["product_id"]); need = float(c["qty"])
                    avail = conn.execute(
                        "SELECT COALESCE(SUM(qty),0) FROM stock_batches WHERE product_id=?",
                        (pid,)).fetchone()[0]
                    if (avail or 0) + 1e-6 < need:
                        nm = conn.execute("SELECT name FROM products WHERE id=?",
                                          (pid,)).fetchone()
                        raise ValueError(
                            f"Недостатньо «{nm[0] if nm else pid}»: треба {need:g}, є {avail:g}.")
            for c in comps:
                pid = int(c["product_id"]); need = float(c["qty"])
                pr = conn.execute("SELECT barcode FROM products WHERE id=?", (pid,)).fetchone()
                batches = conn.execute(
                    "SELECT id, qty, price_in FROM stock_batches WHERE product_id=? AND qty>0 "
                    "ORDER BY COALESCE(NULLIF(receipt_date,''), substr(created_at,1,10)), "
                    "created_at, id", (pid,)).fetchall()
                left = need
                last_price = 0.0
                for b in batches:
                    if left <= 1e-9:
                        break
                    use = min(left, b["qty"])
                    price = float(b["price_in"] or 0)
                    last_price = price
                    cost += use * price
                    conn.execute("UPDATE stock_batches SET qty=qty-? WHERE id=?",
                                 (use, b["id"]))
                    conn.execute(
                        "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,"
                        " qty, note, created_at, price, total, user_id, sale_no, block_id) "
                        "VALUES (?,?,?,'WRITE_OFF',?,?,?,?,?,?,?,?)",
                        (pid, b["id"], pr["barcode"] if pr else "", use, note, created,
                         price, round(use * price, 2), user_id, src_key, block_id))
                    left = round(left - use, 6)
                if left > 1e-6 and allow_negative:
                    # борг: створюємо партію-мінус (qty від'ємна) за останньою/сер. ціною
                    if last_price <= 0:
                        row = conn.execute(
                            "SELECT COALESCE(SUM(qty*price_in),0) v, COALESCE(SUM(qty),0) q "
                            "FROM stock_batches WHERE product_id=?", (pid,)).fetchone()
                        last_price = (row["v"] / row["q"]) if row and row["q"] else 0.0
                    cur = conn.execute(
                        "INSERT INTO stock_batches (product_id, lot_number, qty, price_in, "
                        "price_in_no_vat, vat_rate, created_at) VALUES (?,?,?,?,?,?,?)",
                        (pid, "БОРГ", -left, last_price, last_price, 0, created))
                    conn.execute(
                        "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,"
                        " qty, note, created_at, price, total, user_id, sale_no, block_id) "
                        "VALUES (?,?,?,'WRITE_OFF',?,?,?,?,?,?,?,?)",
                        (pid, int(cur.lastrowid), pr["barcode"] if pr else "", left,
                         (note + " · борг").strip(" ·"), created, last_price,
                         round(left * last_price, 2), user_id, src_key, block_id))
                    cost += left * last_price
                    debt.append({"product_id": pid, "qty": round(left, 3)})
        return {"src_key": src_key, "components": len(comps),
                "cost": round(cost, 2), "debt": debt}

    # ---- Списання годівлі з «Руху кормів» (той самий скан, що й аналітика) ----
    _WATER_NAMES = {"h2o", "h₂o", "вода"}

    @classmethod
    def _is_water(cls, name) -> bool:
        """Вода необмежена: у всіх звітах залишок = 0, у балансі не враховується."""
        return str(name or "").strip().lower() in cls._WATER_NAMES

    def _feed_product_id(self, conn, name, code):
        # Серед кількох збігів обираємо товар із залишком/рухом (реальний), а не
        # порожній засіяний дубль — інакше списання зробить борг не на той товар.
        rank = ("ORDER BY (SELECT COALESCE(SUM(qty),0) FROM stock_batches "
                "WHERE product_id=p.id) DESC, "
                "(SELECT COUNT(*) FROM stock_moves WHERE product_id=p.id) DESC, p.id")
        code = (code or "").strip()
        if code:
            r = conn.execute("SELECT p.id FROM products p WHERE p.code=? AND "
                             "p.category='feed' AND p.is_active=1 " + rank,
                             (code,)).fetchone()
            if r:
                return r["id"]
        nm = (name or "").strip()
        if nm:
            r = conn.execute("SELECT p.id FROM products p WHERE lower(p.name)=lower(?) "
                             "AND p.category='feed' AND p.is_active=1 " + rank,
                             (nm,)).fetchone()
            if r:
                return r["id"]
        return None

    def _ensure_feed_product(self, name, code):
        """ID корму гілки «Годівля» за кодом/назвою; якщо немає — створюємо."""
        with self._connect() as conn:
            pid = self._feed_product_id(conn, name, code)
        if pid:
            return pid, False
        c = (code or "").strip()
        try:
            pid = self.add_product(name=name, barcode="", unit="кг", min_stock=0,
                                   supplier="", notes="Створено автоматично (годівля)",
                                   code=c if c.isdigit() else "", category="feed")
        except ValueError:
            pid = self.add_product(name=name, barcode="", unit="кг", min_stock=0,
                                   supplier="", notes="Створено автоматично (годівля)",
                                   category="feed")
        return pid, True

    def merge_feed_duplicates(self, category: str = "feed") -> dict[str, Any]:
        """Об'єднати кормові товари-дублікати (однакова назва) в один: партії та
        рухи переносимо на основний, решту деактивуємо. Основний — з найбільшим
        залишком (реальний, а не порожній засіяний). Стан складу зберігається
        точно (сума партій не змінюється)."""
        import re as _re

        def norm(s):
            return _re.sub(r"\s+", " ", (s or "").strip()).casefold()

        merged = 0
        groups: dict[str, list] = {}
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.id, p.name, p.code, "
                "(SELECT COALESCE(SUM(qty),0) FROM stock_batches WHERE product_id=p.id) AS q, "
                "(SELECT COUNT(*) FROM stock_moves WHERE product_id=p.id) AS mv "
                "FROM products p WHERE p.category=? AND p.is_active=1",
                (category,)).fetchall()
            for r in rows:
                groups.setdefault(norm(r["name"]), []).append(r)
            details = []
            for nm, lst in groups.items():
                if len(lst) < 2:
                    continue
                # основний: більший залишок → більше рухів → менший id
                lst = sorted(lst, key=lambda r: (-(r["q"] or 0), -(r["mv"] or 0), r["id"]))
                primary = lst[0]
                pid = primary["id"]
                for dup in lst[1:]:
                    did = dup["id"]
                    conn.execute("UPDATE stock_batches SET product_id=? WHERE product_id=?",
                                 (pid, did))
                    conn.execute("UPDATE stock_moves SET product_id=? WHERE product_id=?",
                                 (pid, did))
                    conn.execute(
                        "UPDATE products SET is_active=0, "
                        "notes=TRIM(COALESCE(notes,'')||' · об''єднано у #'||?) WHERE id=?",
                        (pid, did))
                    merged += 1
                details.append({"name": primary["name"], "kept_id": pid,
                                "removed": len(lst) - 1})
            conn.commit()
        return {"merged": merged, "groups": details}

    def undo_all_feeding_writeoffs(self, category: str = "feed") -> dict[str, Any]:
        """Скасувати ВСІ зафіксовані списання годівлі (ключі ГД-…): повертаємо
        кількість на партії, видаляємо рухи WRITE_OFF, борг-партії та журнал
        feeding_events. Стан складу повертається до стану ДО списань. Після
        цього можна списати заново (виправленим зіставленням)."""
        with self._connect() as conn:
            moves = conn.execute(
                "SELECT batch_id, qty FROM stock_moves "
                "WHERE sale_no LIKE 'ГД-%' AND move_type='WRITE_OFF'").fetchall()
            for m in moves:
                if m["batch_id"] is not None:
                    conn.execute("UPDATE stock_batches SET qty = qty + ? WHERE id=?",
                                 (m["qty"], m["batch_id"]))
            n_moves = conn.execute(
                "DELETE FROM stock_moves WHERE sale_no LIKE 'ГД-%'").rowcount
            # борг-партії, що обнулилися після повернення
            n_debt = conn.execute(
                "DELETE FROM stock_batches WHERE lot_number='БОРГ' "
                "AND ABS(qty) < 0.001").rowcount
            # журнал зафіксованих замісів
            n_ev = conn.execute("DELETE FROM feeding_events").rowcount
            # авто-створені корми без залишку й без рухів → деактивувати
            n_prod = conn.execute(
                "UPDATE products SET is_active=0 WHERE category=? AND is_active=1 "
                "AND notes LIKE 'Створено автоматично%' "
                "AND id NOT IN (SELECT DISTINCT product_id FROM stock_moves "
                "               WHERE product_id IS NOT NULL) "
                "AND COALESCE((SELECT SUM(ABS(qty)) FROM stock_batches "
                "              WHERE product_id=products.id),0) < 0.001",
                (category,)).rowcount
            conn.commit()
        return {"moves": n_moves, "debt_batches": n_debt,
                "events": n_ev, "deactivated": n_prod}

    def _receive_water_zero(self, product_id, qty, op_date):
        """Оприбуткувати воду за ціною 0 (щоб заміс балансувався, коштувала 0)."""
        with self._connect() as conn:
            pr = conn.execute("SELECT barcode FROM products WHERE id=?",
                              (product_id,)).fetchone()
            cur = conn.execute(
                "INSERT INTO stock_batches (product_id, lot_number, qty, price_in, "
                "price_in_no_vat, vat_rate, receipt_date, created_at) VALUES (?,?,?,?,?,?,?,?)",
                (product_id, "H2O", qty, 0, 0, 0, op_date, self._now()))
            conn.execute(
                "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, qty, "
                "note, created_at, price, total, user_id, sale_no, block_id) "
                "VALUES (?,?,?,'IN',?,?,?,?,?,?,?,?)",
                (product_id, int(cur.lastrowid), pr["barcode"] if pr else "", qty,
                 "Вода (годівля)", op_date, 0, 0, None, "", None))

    def writeoff_from_movements(self, folder: str = "", date_from: str = "",
                                date_to: str = "", parts: list = None,
                                user_id: Optional[int] = None) -> dict[str, Any]:
        """Зафіксувати списання рівно за «Рухом кормів»: для кожного замісу
        (№ партії) списуємо Завантажено-факт по інгредієнтах зі складу (FIFO,
        на дату годівлі). Вода — оприбутковується за 0. Нестача — «в мінус»
        (борг). Ідемпотентно (ключ ГД-№партії). Джерело — scan_feeding_movements,
        тобто те саме, що малює таблиця руху."""
        folder = (folder or self.get_setting("feed_profeed_dir", "") or "").strip()
        if not folder:
            return {"error": "Не вказано теку звітів Profeed.", "done_count": 0}
        scan = self.scan_feeding_movements(folder)
        if scan.get("error"):
            return {"error": scan["error"], "done_count": 0}
        df = (date_from or "").strip()[:10]
        dt = (date_to or "").strip()[:10]
        want = set(parts) if parts else None
        with self._connect() as conn:
            done = {r[0] for r in conn.execute(
                "SELECT DISTINCT sale_no FROM stock_moves "
                "WHERE sale_no LIKE 'ГД-%'").fetchall()}
        done_count = 0
        created_products = 0
        debt_lines = 0
        for part, a in scan["parts"].items():
            if not a.get("group") or not a.get("date"):
                continue
            if df and a["date"] < df:
                continue
            if dt and a["date"] > dt:
                continue
            if want is not None and part not in want:
                continue
            src_key = f"ГД-{part}"
            if src_key in done:
                continue
            blk_id = self.add_block(name=a["group"], category="feed")
            comps = []
            for it in a.get("ing", {}).values():
                qty = round(float(it.get("kg") or 0), 3)
                if qty <= 0:
                    continue
                # Воду списуємо з наявного залишку (вона вже оприбуткована на
                # склад вручну) — автоматично НЕ оприбутковуємо.
                pid, made = self._ensure_feed_product(it.get("name", ""), it.get("code", ""))
                if made:
                    created_products += 1
                comps.append({"product_id": pid, "qty": qty})
            if not comps:
                continue
            res = self.write_off_feeding(
                src_key=src_key, components=comps, op_date=a["date"], block_id=blk_id,
                note=f"Годівля · {a['group']}", user_id=user_id, allow_negative=True)
            if res.get("skipped"):
                continue
            debt_lines += len(res.get("debt", []))
            with self._connect() as conn:
                self._store_feeding_snapshot(conn, src_key, a, blk_id)
            done_count += 1
        return {"done_count": done_count, "created_products": created_products,
                "debt_lines": debt_lines}

    def _store_feeding_snapshot(self, conn, src_key: str, a: dict,
                                block_id: Optional[int] = None) -> None:
        """Зберегти знімок замісу (метрики + перелік кормів) у БД — для читання
        руху годівлі без файлів Profeed. Складу НЕ чіпає."""
        conn.execute(
            "INSERT INTO feeding_events (src_key, op_date, group_label, "
            "block_id, ration, kg_loaded, kg_loaded_all, kg_distributed, headcount, "
            "plan_loaded, dry_loaded, plan_distributed, dry_distributed, leftover, "
            "file_ts, mixer, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(src_key) DO UPDATE SET "
            "op_date=excluded.op_date, group_label=excluded.group_label, "
            "block_id=COALESCE(excluded.block_id, feeding_events.block_id), "
            "ration=excluded.ration, kg_loaded=excluded.kg_loaded, "
            "kg_loaded_all=excluded.kg_loaded_all, kg_distributed=excluded.kg_distributed, "
            "headcount=excluded.headcount, plan_loaded=excluded.plan_loaded, "
            "dry_loaded=excluded.dry_loaded, plan_distributed=excluded.plan_distributed, "
            "dry_distributed=excluded.dry_distributed, leftover=excluded.leftover, "
            "file_ts=excluded.file_ts, "
            "mixer=CASE WHEN excluded.mixer != '' THEN excluded.mixer ELSE feeding_events.mixer END",
            (src_key, a.get("date", ""), a.get("group", ""), block_id,
             a.get("ration", ""), round(a.get("loaded", 0), 3), round(a.get("loaded", 0), 3),
             round(a.get("distributed", 0), 3), round(a.get("heads", 0), 1),
             round(a.get("plan_loaded", 0), 3), round(a.get("dry_loaded", 0), 3),
             round(a.get("plan_distributed", 0), 3), round(a.get("dry_distributed", 0), 3),
             round(a.get("leftover", 0), 3), a.get("_file_ts", ""),
             a.get("mixer", ""), self._now()))
        conn.execute("DELETE FROM feeding_event_ings WHERE src_key=?", (src_key,))
        for it in a.get("ing", {}).values():
            nm = str(it.get("name", "") or "")
            if nm.strip().lower() in self._WATER_NAMES:   # H2O/H₂O → «Вода»
                nm = "Вода"
            conn.execute(
                "INSERT INTO feeding_event_ings (src_key, name, code, plan, kg, dry) "
                "VALUES (?,?,?,?,?,?)",
                (src_key, nm, it.get("code", ""),
                 round(it.get("plan", 0), 4), round(it.get("kg", 0), 4),
                 round(it.get("dry", 0), 4)))

    def list_feeding_files(self) -> dict[str, Any]:
        """Список файлів звітів Profeed у робочій теці: назва, розмір, діапазон
        дат (із назви файлу) — для вибору при архівації."""
        import glob
        import os
        import re as _re
        folder = (self.get_setting("feed_profeed_dir", "") or "").strip()
        p = Path(folder).expanduser()
        if not folder or not p.exists():
            return {"files": [], "folder": folder, "note": "Не вказано теку звітів Profeed."}
        dre = _re.compile(r"(\d{4}-\d{2}-\d{2})")
        out = []
        for fp in sorted(glob.glob(str(p / "*.xlsx")) + glob.glob(str(p / "*.xls"))):
            nm = os.path.basename(fp)
            try:
                sz = os.path.getsize(fp)
            except OSError:
                sz = 0
            ds = sorted(dre.findall(nm))
            out.append({"name": nm, "size": sz,
                        "date_from": ds[0] if ds else "", "date_to": ds[-1] if ds else ""})
        out.sort(key=lambda f: (f["date_from"] or "", f["name"]))
        arch = p / "_archive"
        archived = len(glob.glob(str(arch / "*.xlsx")) + glob.glob(str(arch / "*.xls"))) \
            if arch.exists() else 0
        with self._connect() as conn:
            db_events = conn.execute("SELECT COUNT(*) FROM feeding_events").fetchone()[0]
        return {"files": out, "folder": folder, "archive_dir": str(arch),
                "archived_count": archived, "db_events": db_events}

    def archive_feeding_files(self, names: list) -> dict[str, Any]:
        """Архівувати вибрані файли: зберегти їх дані в БД (знімок замісів, без
        складу) і перенести самі файли в підпапку «_archive». Невибрані —
        лишаються в теці для роботи. Дані архівованих читаються з БД."""
        import shutil
        folder = (self.get_setting("feed_profeed_dir", "") or "").strip()
        p = Path(folder).expanduser()
        sel = {str(n).strip() for n in (names or []) if str(n).strip()}
        if not sel:
            return {"error": "Не вибрано файлів."}
        if not p.exists():
            return {"error": "Теку не знайдено."}
        scan = self.scan_feeding_movements(str(p))
        stored = 0
        with self._connect() as conn:
            for part, a in scan.get("parts", {}).items():
                fs = a.get("_files") or set()
                if fs and fs <= sel:            # заміс повністю з вибраних файлів
                    self._store_feeding_snapshot(conn, "ГД-" + part, a)
                    stored += 1
            conn.commit()
        arch = p / "_archive"
        try:
            arch.mkdir(exist_ok=True)
        except OSError as exc:
            return {"error": f"Не вдалося створити теку архіву: {exc}"}
        moved = 0
        for nm in sorted(sel):
            src = p / nm
            if src.exists() and src.is_file():
                try:
                    shutil.move(str(src), str(arch / nm))
                    moved += 1
                except OSError:
                    continue
        self._scan_cache = None                 # скидаємо кеш парсингу
        return {"stored": stored, "moved": moved}

    def scan_feeding_movements(self, folder: str) -> dict[str, Any]:
        """Рух годівлі прямо зі звітів Profeed (без імпорту/списання).
        На кожну роздачу (№ партії) збираємо: секцію («Група»), поголів'я,
        план/факт завантаження, суху речовину, роздано, залишки та перелік
        завантажених інгредієнтів (для цін і загальнозмішаного раціону)."""
        import glob
        import os
        import re as _re
        import openpyxl
        # Одноразове прибирання старих знімків без дати в ключі партії (через них
        # партія №N за різні дні зливалась). Файловий скан нижче відтворить їх
        # коректно з датою в ключі.
        if self.get_setting("feed_partkey_v2") != "1":
            try:
                with self._connect() as _c0:
                    _c0.execute("DELETE FROM feeding_event_ings WHERE src_key NOT LIKE '%|%'")
                    _c0.execute("DELETE FROM feeding_events WHERE src_key NOT LIKE '%|%'")
                    _c0.commit()
            except Exception:  # noqa: BLE001
                pass
            self.set_setting("feed_partkey_v2", "1")
        folder = (folder or "").strip()
        p = Path(folder).expanduser()
        if not p.exists():
            db_only = self._merge_db_parts({})
            if db_only:
                return {"parts": db_only, "files": 0}
            return {"error": f"Теку не знайдено: {folder}", "parts": {}}
        files = sorted(glob.glob(str(p / "*.xlsx")) + glob.glob(str(p / "*.xls")))
        if not files:
            db_only = self._merge_db_parts({})
            if db_only:
                return {"parts": db_only, "files": 0}
            return {"error": "У теці немає файлів .xlsx", "parts": {}}
        # Кеш: якщо склад файлів і їх дати змін не змінились — не перечитуємо
        # (Excel читається повільно, а сторінка відкривається часто).
        try:
            sig = tuple((f, os.path.getmtime(f), os.path.getsize(f)) for f in files)
        except OSError:
            sig = None
        cache = getattr(self, "_scan_cache", None)
        if sig is not None and cache is not None and cache[0] == (str(p), sig):
            return {"parts": self._merge_db_parts(dict(cache[1])),
                    "files": len(files)}
        kk = _re.compile(r"\(\s*К\s*-?\s*\d+\s*\)", _re.IGNORECASE)
        HDR = {"Інгредієнт, назва", "№ партії", "Статус", "Група"}

        def _new():
            return {"date": "", "group": "", "ration": "", "heads": 0.0,
                    "plan_loaded": 0.0, "loaded": 0.0,
                    "dry_loaded": 0.0, "plan_distributed": 0.0, "distributed": 0.0,
                    "dry_distributed": 0.0, "leftover": 0.0, "ing": {},
                    "_files": set(), "_file_ts": ""}

        parts: dict[str, dict] = {}
        for fp in files:
            _fname = os.path.basename(fp)
            try:
                _fmtime = datetime.fromtimestamp(
                    os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M:%S")
            except OSError:
                _fmtime = ""
            try:
                wb = openpyxl.load_workbook(fp, read_only=True, data_only=True)
            except Exception:  # noqa: BLE001
                continue
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                hi = next((i for i, r in enumerate(rows[:6])
                           if HDR <= {str(c).strip() for c in r if c}), None)
                if hi is None:
                    continue
                h = [str(c).strip() if c is not None else "" for c in rows[hi]]
                ix = {n: h.index(n) for n in
                      ("Дата", "Міксер", "№ партії", "Статус", "Група",
                       "Інгредієнт, назва", "Інгредієнт, код",
                       "Планова кількість, кг", "Фактична кількість, кг",
                       "Фактична суха, кг", "Раціон, назва",
                       "Поголівʼя в секції", "Залишки, кг") if n in h}
                if any(n not in ix for n in ("№ партії", "Статус", "Група")):
                    continue

                def col(r, n):
                    j = ix.get(n)
                    return r[j] if j is not None and j < len(r) else None

                # Дата аркуша (звіт Profeed — за один день). Ключ партії робимо
                # складеним «дата|№», щоб однакові № партії за різні дні НЕ зливались.
                _sheet_date = ""
                for _r in rows[hi + 1:]:
                    _dv = col(_r, "Дата")
                    if _dv:
                        _sheet_date = str(_dv)[:10]
                        break

                for r in rows[hi + 1:]:
                    part = str(col(r, "№ партії") or "").strip()
                    if not part or kk.search(str(col(r, "Міксер") or "")):
                        continue
                    dkey = str(col(r, "Дата") or "").strip()[:10] or _sheet_date
                    pkey = (dkey + "|" + part) if dkey else (_fname + "|" + part)
                    a = parts.setdefault(pkey, _new())
                    a["_files"].add(_fname)
                    if _fmtime > a["_file_ts"]:
                        a["_file_ts"] = _fmtime
                    if dkey and not a["date"]:
                        a["date"] = dkey
                    mx = str(col(r, "Міксер") or "").strip()
                    if mx and not a.get("mixer"):
                        a["mixer"] = mx
                    status = str(col(r, "Статус") or "").strip().lower()
                    fact = self._to_float(col(r, "Фактична кількість, кг") or 0)
                    plan = self._to_float(col(r, "Планова кількість, кг") or 0)
                    dry = self._to_float(col(r, "Фактична суха, кг") or 0)
                    if status.startswith("загр"):
                        if fact > 0:
                            a["loaded"] += fact
                            a["plan_loaded"] += plan
                            a["dry_loaded"] += dry
                            nm = str(col(r, "Інгредієнт, назва") or "").strip()
                            code = str(col(r, "Інгредієнт, код") or "").strip()
                            # Одне правило: H2O/H₂O → «Вода»
                            if nm.lower() in self._WATER_NAMES:
                                nm = "Вода"
                            if nm:
                                key = code or nm
                                it = a["ing"].setdefault(
                                    key, {"name": nm, "code": code,
                                          "plan": 0.0, "kg": 0.0, "dry": 0.0})
                                it["plan"] += plan
                                it["kg"] += fact
                                it["dry"] += dry
                    elif status.startswith("вигр"):
                        g = str(col(r, "Група") or "").strip()
                        if g:
                            a["group"] = g
                        a["ration"] = str(col(r, "Раціон, назва") or "").strip() or a["ration"]
                        a["plan_distributed"] += max(0.0, plan)
                        a["distributed"] += max(0.0, fact)
                        a["dry_distributed"] += max(0.0, dry)
                        a["leftover"] += max(0.0, self._to_float(col(r, "Залишки, кг") or 0))
                        a["heads"] = max(a["heads"], self._to_float(col(r, "Поголівʼя в секції") or 0))
            wb.close()
        # Авто-фіксація в БД: кожен файловий заміс зберігається знімком (метрики,
        # залишки, корми). Так дані не залежать від файлів — навіть якщо файл
        # видалять поза застосунком, рух годівлі та залишки лишаться в базі.
        self._autosave_feeding_snapshots(parts)
        if sig is not None:
            self._scan_cache = ((str(p), sig), parts)   # кеш лише файлового парсингу
        return {"parts": self._merge_db_parts(dict(parts)), "files": len(files)}

    def _autosave_feeding_snapshots(self, parts: dict) -> None:
        """Зберегти знімки файлових замісів у БД (upsert за № партії). Викликається
        при свіжому парсингу Profeed — робить базу довговічним джерелом даних."""
        if not parts:
            return
        try:
            with self._connect() as conn:
                for part, a in parts.items():
                    if not (a.get("date") and a.get("group")):
                        continue                       # неповний заміс — пропускаємо
                    self._store_feeding_snapshot(conn, "ГД-" + part, a)
                conn.commit()
        except Exception:  # noqa: BLE001
            pass                                       # фіксація не має ламати скан

    def _merge_db_parts(self, parts: dict) -> dict:
        """Додати до файлових замісів ті, що є лише в БД (архівовані/видалені
        звіти Profeed): читаємо з feeding_events + feeding_event_ings. Файлові
        мають пріоритет (не перезаписуємо). Ключ — № партії (src_key без «ГД-»)."""
        try:
            with self._connect() as conn:
                evs = conn.execute(
                    "SELECT src_key, op_date, group_label, ration, kg_loaded, "
                    "kg_distributed, headcount, plan_loaded, dry_loaded, "
                    "plan_distributed, dry_distributed, leftover, file_ts "
                    "FROM feeding_events").fetchall()
                if not evs:
                    return parts
                ings: dict[str, list] = {}
                for r in conn.execute(
                        "SELECT src_key, name, code, plan, kg, dry "
                        "FROM feeding_event_ings").fetchall():
                    ings.setdefault(r["src_key"], []).append(r)
        except Exception:  # noqa: BLE001
            return parts
        for e in evs:
            part = e["src_key"][3:] if e["src_key"].startswith("ГД-") else e["src_key"]
            if part in parts:                        # файл має пріоритет
                continue
            ing = {}
            for it in ings.get(e["src_key"], []):
                key = (it["code"] or "").strip() or it["name"]
                ing[key] = {"name": it["name"], "code": it["code"],
                            "plan": it["plan"] or 0, "kg": it["kg"] or 0,
                            "dry": it["dry"] or 0}
            parts[part] = {
                "date": e["op_date"], "group": e["group_label"],
                "ration": e["ration"] or "", "heads": e["headcount"] or 0,
                "plan_loaded": e["plan_loaded"] or 0, "loaded": e["kg_loaded"] or 0,
                "dry_loaded": e["dry_loaded"] or 0,
                "plan_distributed": e["plan_distributed"] or 0,
                "distributed": e["kg_distributed"] or 0,
                "dry_distributed": e["dry_distributed"] or 0,
                "leftover": e["leftover"] or 0, "ing": ing,
                "_file_ts": e["file_ts"] if "file_ts" in e.keys() else ""}
        return parts

    def list_feeding_log(self, category: str = "feed", date_from: str = "",
                         date_to: str = "") -> dict[str, Any]:
        """Рух годівлі по секціях за днями: (день, секція) — поголів'я зі звіту,
        завантажено/роздано кг, втрати. Читаємо прямо зі звітів Profeed (тека з
        налаштувань), тож дані є навіть без імпорту/списання."""
        date_from = (date_from or "").strip()[:10]
        date_to = (date_to or "").strip()[:10]
        folder = self.get_setting("feed_profeed_dir", "").strip()
        if not folder:
            return {"items": [], "note": "Не вказано теку звітів Profeed (сторінка «Виробництво КК»).",
                    "date_from": date_from, "date_to": date_to}
        scan = self.scan_feeding_movements(folder)
        if scan.get("error"):
            return {"items": [], "error": scan["error"], "date_from": date_from, "date_to": date_to}
        # агрегуємо роздачі по (день, група)
        agg: dict[tuple, dict] = {}
        for part, a in scan["parts"].items():
            if not a["group"] or not a["date"]:
                continue
            if date_from and a["date"] < date_from:
                continue
            if date_to and a["date"] > date_to:
                continue
            k = (a["date"], a["group"])
            g = agg.setdefault(k, {"date": a["date"], "group": a["group"], "ration": set(),
                                   "loaded": 0.0, "distributed": 0.0, "heads": 0.0, "feedings": 0})
            g["loaded"] += a["loaded"]
            g["distributed"] += a["distributed"]
            g["heads"] = max(g["heads"], a["heads"])
            g["feedings"] += 1
            if a["ration"]:
                g["ration"].add(a["ration"])
        items = []
        for (d, grp), g in sorted(agg.items(), key=lambda kv: (kv[0][0], kv[0][1]), reverse=True):
            heads = g["heads"]
            items.append({
                "date": g["date"], "section": g["group"], "group_label": g["group"],
                "headcount": round(heads, 1),
                "kg_loaded": round(g["loaded"], 1),
                "kg_distributed": round(g["distributed"], 1),
                "loss_kg": round(g["loaded"] - g["distributed"], 1),
                "kg_head": round(g["distributed"] / heads, 1) if heads else None,
                "feedings": g["feedings"], "rations": ", ".join(sorted(g["ration"])),
            })
        return {"items": items, "date_from": date_from, "date_to": date_to}

    # ---- Молоко по секціях (ручне внесення) ----------------------------
    def _ensure_feeding_milk(self, conn: sqlite3.Connection) -> None:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feeding_milk ("
            " section TEXT NOT NULL, day TEXT NOT NULL, milk_kg REAL NOT NULL DEFAULT 0,"
            " PRIMARY KEY(section, day))")

    def set_feeding_milk(self, section: str, day: str, milk_kg: float) -> dict[str, Any]:
        section = str(section or "").strip()
        day = str(day or "").strip()[:10]
        if not section or not day:
            raise ValueError("Потрібні секція і дата.")
        val = max(0.0, self._to_float(milk_kg or 0))
        with self._connect() as conn:
            self._ensure_feeding_milk(conn)
            if val > 0:
                conn.execute(
                    "INSERT INTO feeding_milk(section, day, milk_kg) VALUES(?,?,?) "
                    "ON CONFLICT(section, day) DO UPDATE SET milk_kg=excluded.milk_kg",
                    (section, day, val))
            else:
                conn.execute("DELETE FROM feeding_milk WHERE section=? AND day=?",
                             (section, day))
        return {"section": section, "day": day, "milk_kg": val}

    def _ensure_milk_daily(self, conn: sqlite3.Connection) -> None:
        """Кеш денного надою {день: кг} з Excel-модуля молока — щоб надій
        синхронізувався на сервер (для конверсії корму в аналітиці)."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_daily ("
            " day TEXT PRIMARY KEY, kg REAL NOT NULL DEFAULT 0,"
            " updated_at TEXT NOT NULL DEFAULT '')")
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(milk_daily)").fetchall()}
        if "l" not in cols:
            conn.execute("ALTER TABLE milk_daily ADD COLUMN l REAL NOT NULL DEFAULT 0")
        # cols_json — суми ВСІХ колонок метрик надою за день (щоб сторінка Надоїв
        # показувала будь-яку метрику: залік, з коефіцієнтом тощо, а не лише kg/l).
        if "cols_json" not in cols:
            conn.execute("ALTER TABLE milk_daily ADD COLUMN cols_json TEXT NOT NULL DEFAULT ''")
        # source — джерело запису: '' = Excel-імпорт, 'manual' = ручний ввід
        # (Telegram-бот). Ручні дні НЕ перезаписуються Excel-імпортом.
        if "source" not in cols:
            conn.execute("ALTER TABLE milk_daily ADD COLUMN source TEXT NOT NULL DEFAULT ''")
        # photo — імʼя файлу фото лічильника (для ручного вводу), опційно.
        if "photo" not in cols:
            conn.execute("ALTER TABLE milk_daily ADD COLUMN photo TEXT NOT NULL DEFAULT ''")
        # entered_by — імʼя учасника (Telegram), який вніс ручний запис.
        if "entered_by" not in cols:
            conn.execute("ALTER TABLE milk_daily ADD COLUMN entered_by TEXT NOT NULL DEFAULT ''")

    def set_milk_daily(self, day_map: dict, manual: bool = False) -> int:
        """Зберегти денний надій у БД (upsert по дню). day_map — {день: кг}
        АБО {день: {kg, l, cols, photo}} (kg — надій для звітів = feed_milk_col;
        cols — {назва_колонки: сума} для всіх метрик надою сторінки Надоїв).
        manual=True → джерело 'manual' (ручний ввід ботом), пише photo.
        manual=False (Excel-імпорт) → НЕ чіпає дні, збережені вручну."""
        if not day_map:
            return 0
        now = self._now()
        n = 0
        with self._connect() as conn:
            self._ensure_milk_daily(conn)
            for d, v in day_map.items():
                d = str(d or "")[:10]
                if not d:
                    continue
                if not manual:
                    cur = conn.execute(
                        "SELECT source, kg, l FROM milk_daily WHERE day=?", (d,)).fetchone()
                    if cur and (cur["source"] or "") == "manual":
                        continue  # ручний день — Excel не перезаписує
                    # Excel тимчасово віддає нулі (кеш формул порожній після
                    # стороннього запису, до першого збереження в Excel) —
                    # НЕ затираємо наявні ненульові дані дня нулями.
                    _kg0 = self._to_float((v.get("kg") if isinstance(v, dict) else v) or 0)
                    _l0 = self._to_float((v.get("l") if isinstance(v, dict) else 0) or 0)
                    if cur and not _kg0 and not _l0 and \
                            (self._to_float(cur["kg"] or 0) or self._to_float(cur["l"] or 0)):
                        continue
                cj = ""
                photo = ""
                by = ""
                if isinstance(v, dict):
                    kg = self._to_float(v.get("kg") or 0)
                    lt = self._to_float(v.get("l") or 0)
                    photo = str(v.get("photo") or "")
                    by = str(v.get("by") or "")
                    if v.get("cols"):
                        try:
                            cj = json.dumps(v["cols"], ensure_ascii=False)
                        except Exception:  # noqa: BLE001
                            cj = ""
                else:
                    kg = self._to_float(v or 0)
                    lt = 0.0
                src = "manual" if manual else ""
                conn.execute(
                    "INSERT INTO milk_daily(day, kg, l, cols_json, source, photo, entered_by, updated_at) "
                    "VALUES(?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(day) DO UPDATE SET kg=excluded.kg, l=excluded.l, "
                    "cols_json=excluded.cols_json, source=excluded.source, "
                    "photo=CASE WHEN excluded.photo!='' THEN excluded.photo ELSE milk_daily.photo END, "
                    "entered_by=CASE WHEN excluded.entered_by!='' THEN excluded.entered_by ELSE milk_daily.entered_by END, "
                    "updated_at=excluded.updated_at",
                    (d, max(0.0, kg), max(0.0, lt), cj, src, photo, by, now))
                n += 1
        return n

    # ---- Надій по ЗМІНАХ доїння (1/2/3) — джерело правди для ручного надою.
    #      milk_daily.kg для ручного дня = СУМА змін цього дня.
    def _ensure_milk_yield_shifts(self, conn: sqlite3.Connection) -> None:
        existed = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name='milk_yield_shifts'").fetchone()
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_yield_shifts ("
            " day TEXT NOT NULL, shift INTEGER NOT NULL DEFAULT 1,"
            " kg REAL NOT NULL DEFAULT 0, photo TEXT NOT NULL DEFAULT '',"
            " entered_by TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL DEFAULT '',"
            " PRIMARY KEY(day, shift))")
        if not existed:
            # одноразовий бекфіл: наявні ручні дні → зміна 1
            self._ensure_milk_daily(conn)
            conn.execute(
                "INSERT OR IGNORE INTO milk_yield_shifts"
                "(day,shift,kg,photo,entered_by,updated_at) "
                "SELECT day,1,kg,photo,entered_by,updated_at FROM milk_daily "
                "WHERE source='manual' AND kg>0")

    def _recompute_milk_manual_day(self, conn: sqlite3.Connection, day: str) -> None:
        day = str(day)[:10]
        rows = conn.execute(
            "SELECT kg, photo, entered_by, updated_at FROM milk_yield_shifts "
            "WHERE day=? ORDER BY shift", (day,)).fetchall()
        self._ensure_milk_daily(conn)
        if not rows:
            conn.execute("DELETE FROM milk_daily WHERE day=? AND source='manual'", (day,))
            return
        total = sum((r["kg"] or 0) for r in rows)
        photo = next((r["photo"] for r in rows if r["photo"]), "")
        latest = max(rows, key=lambda r: (r["updated_at"] or ""))
        by = latest["entered_by"] or ""
        conn.execute(
            "INSERT INTO milk_daily(day,kg,l,cols_json,source,photo,entered_by,updated_at) "
            "VALUES(?,?,0,'','manual',?,?,?) "
            "ON CONFLICT(day) DO UPDATE SET kg=excluded.kg, source='manual', "
            "photo=excluded.photo, entered_by=excluded.entered_by, "
            "updated_at=excluded.updated_at",
            (day, total, photo, by, latest["updated_at"] or self._now()))

    def set_milk_yield_shift(self, day: str, shift, kg, photo: str = "",
                             by: str = "") -> bool:
        """Ручний надій за зміну (upsert по день+зміна) + перерахунок дня."""
        day = str(day or "")[:10]
        if not day:
            return False
        try:
            shift = int(shift or 1)
        except (TypeError, ValueError):
            shift = 1
        now = self._now()
        with self._connect() as conn:
            self._ensure_milk_yield_shifts(conn)
            conn.execute(
                "INSERT INTO milk_yield_shifts(day,shift,kg,photo,entered_by,updated_at) "
                "VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(day,shift) DO UPDATE SET kg=excluded.kg, "
                "photo=CASE WHEN excluded.photo!='' THEN excluded.photo ELSE milk_yield_shifts.photo END, "
                "entered_by=CASE WHEN excluded.entered_by!='' THEN excluded.entered_by ELSE milk_yield_shifts.entered_by END, "
                "updated_at=excluded.updated_at",
                (day, shift, max(0.0, self._to_float(kg)), str(photo or ""),
                 str(by or ""), now))
            self._recompute_milk_manual_day(conn, day)
        return True

    def delete_milk_yield_shift(self, day: str, shift) -> bool:
        """Видалити один запис надою (день+зміна) + перерахунок дня."""
        day = str(day or "")[:10]
        try:
            shift = int(shift or 1)
        except (TypeError, ValueError):
            shift = 1
        with self._connect() as conn:
            self._ensure_milk_yield_shifts(conn)
            conn.execute("DELETE FROM milk_yield_shifts WHERE day=? AND shift=?",
                         (day, shift))
            self._recompute_milk_manual_day(conn, day)
        return True

    def milk_yield_shifts_list(self, date_from: str = "", date_to: str = "") -> list:
        """Ручний надій по змінах: [{day, shift, kg, photo, by, at}], новіші зверху."""
        out = []
        with self._connect() as conn:
            self._ensure_milk_yield_shifts(conn)
            q = ("SELECT day,shift,kg,photo,entered_by,updated_at "
                 "FROM milk_yield_shifts")
            cond, args = [], []
            if date_from:
                cond.append("day>=?"); args.append(date_from[:10])
            if date_to:
                cond.append("day<=?"); args.append(date_to[:10])
            if cond:
                q += " WHERE " + " AND ".join(cond)
            q += " ORDER BY day DESC, shift"
            for r in conn.execute(q, args).fetchall():
                out.append({"day": str(r["day"])[:10], "shift": r["shift"],
                            "kg": r["kg"] or 0, "photo": r["photo"] or "",
                            "by": r["entered_by"] or "", "at": r["updated_at"] or ""})
        return out

    def set_milk_manual_yield(self, day: str, kg: float, photo: str = "",
                              by: str = "", shift=1) -> int:
        """Ручний надій (Telegram-бот): kg + фото + хто вніс + зміна (дефолт 1)."""
        return 1 if self.set_milk_yield_shift(day, shift, kg, photo, by) else 0

    def delete_milk_day(self, day: str) -> bool:
        """Видалити день надою з БД (усі зміни + денний агрегат)."""
        day = str(day)[:10]
        with self._connect() as conn:
            self._ensure_milk_daily(conn)
            self._ensure_milk_yield_shifts(conn)
            conn.execute("DELETE FROM milk_yield_shifts WHERE day=?", (day,))
            conn.execute("DELETE FROM milk_daily WHERE day=?", (day,))
        return True

    def milk_yields_rows(self, date_from: str = "", date_to: str = "") -> list:
        """Денний надій із БД як рядки під milk_excel.aggregate. Кожен рядок містить
        суми всіх колонок метрик надою (з cols_json) + milk_total_kg/milk_total_l як
        запасні ключі — щоб будь-яка метрика (напр. залік) показувалась на сторінці."""
        import datetime as _dt
        out = []
        with self._connect() as conn:
            self._ensure_milk_daily(conn)
            q = "SELECT * FROM milk_daily"
            cond, args = [], []
            if date_from:
                cond.append("day >= ?"); args.append(date_from[:10])
            if date_to:
                cond.append("day <= ?"); args.append(date_to[:10])
            if cond:
                q += " WHERE " + " AND ".join(cond)
            q += " ORDER BY day"
            for r in conn.execute(q, args).fetchall():
                try:
                    d = _dt.datetime.strptime(str(r["day"])[:10], "%Y-%m-%d").date()
                except ValueError:
                    continue
                keys = r.keys()
                row = {"date": d,
                       "milk_total_kg": r["kg"] or 0,
                       "milk_total_l": (r["l"] if "l" in keys else 0) or 0,
                       "source": (r["source"] if "source" in keys else "") or "",
                       "photo": (r["photo"] if "photo" in keys else "") or "",
                       "entered_by": (r["entered_by"] if "entered_by" in keys else "") or "",
                       "at": (r["updated_at"] if "updated_at" in keys else "") or ""}
                cj = r["cols_json"] if "cols_json" in keys else ""
                if cj:
                    try:
                        row.update(json.loads(cj))   # усі колонки метрик надою
                    except Exception:  # noqa: BLE001
                        pass
                out.append(row)
        return out

    def _ensure_milk_sales_daily(self, conn: sqlite3.Connection) -> None:
        """Кеш денного ПРОДАЖУ молока з Excel-модуля (кг, ціни, суми, ПДВ) —
        щоб продаж синхронізувався на сервер (там немає доступу до Excel)."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_sales_daily ("
            " day TEXT PRIMARY KEY, kg REAL NOT NULL DEFAULT 0,"
            " price_nv REAL NOT NULL DEFAULT 0, sum_nv REAL NOT NULL DEFAULT 0,"
            " price_v REAL NOT NULL DEFAULT 0, sum_v REAL NOT NULL DEFAULT 0,"
            " vat REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT '')")
        cols = {r["name"] for r in conn.execute(
            "PRAGMA table_info(milk_sales_daily)").fetchall()}
        for c in ("l", "kg_fat", "kg_prot"):
            if c not in cols:
                conn.execute(f"ALTER TABLE milk_sales_daily ADD COLUMN {c} REAL NOT NULL DEFAULT 0")
        # cols_json — суми ВСІХ колонок метрик продажу за день (залік, ціна тощо),
        # щоб сторінка Продажу показувала будь-яку метрику, а не лише фіксовані.
        if "cols_json" not in cols:
            conn.execute("ALTER TABLE milk_sales_daily ADD COLUMN cols_json TEXT NOT NULL DEFAULT ''")
        if "source" not in cols:
            conn.execute("ALTER TABLE milk_sales_daily ADD COLUMN source TEXT NOT NULL DEFAULT ''")
        if "photo" not in cols:
            conn.execute("ALTER TABLE milk_sales_daily ADD COLUMN photo TEXT NOT NULL DEFAULT ''")
        if "entered_by" not in cols:
            conn.execute("ALTER TABLE milk_sales_daily ADD COLUMN entered_by TEXT NOT NULL DEFAULT ''")

    def set_milk_sales_daily(self, rows: list, manual: bool = False) -> int:
        """Зберегти денний продаж молока у БД (upsert по дню). rows — список
        {day, kg, l, kg_fat, kg_prot, price_nv, sum_nv, price_v, sum_v, vat,
        cols, photo}. cols — {назва_колонки: сума} для всіх метрик Продажу.
        manual=True → джерело 'manual' (ручний ввід ботом), пише photo.
        manual=False (Excel) → НЕ чіпає дні, збережені вручну."""
        if not rows:
            return 0
        now = self._now()
        n = 0
        with self._connect() as conn:
            self._ensure_milk_sales_daily(conn)
            for r in rows:
                d = str(r.get("day") or "")[:10]
                if not d:
                    continue
                if not manual:
                    cur = conn.execute(
                        "SELECT source, kg, l, sum_v FROM milk_sales_daily WHERE day=?",
                        (d,)).fetchone()
                    if cur and (cur["source"] or "") == "manual":
                        continue
                    # порожній кеш формул Excel → нулі: не затирати наявні дані
                    _z = not (self._to_float(r.get("kg") or 0)
                              or self._to_float(r.get("l") or 0)
                              or self._to_float(r.get("sum_v") or 0))
                    if cur and _z and (self._to_float(cur["kg"] or 0)
                                       or self._to_float(cur["l"] or 0)
                                       or self._to_float(cur["sum_v"] or 0)):
                        continue
                cj = ""
                if r.get("cols"):
                    try:
                        cj = json.dumps(r["cols"], ensure_ascii=False)
                    except Exception:  # noqa: BLE001
                        cj = ""
                src = "manual" if manual else ""
                photo = str(r.get("photo") or "")
                by = str(r.get("by") or "")
                conn.execute(
                    "INSERT INTO milk_sales_daily(day, kg, l, kg_fat, kg_prot, "
                    "  price_nv, sum_nv, price_v, sum_v, vat, cols_json, source, photo, entered_by, updated_at) "
                    "  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(day) DO UPDATE SET kg=excluded.kg, l=excluded.l, "
                    "  kg_fat=excluded.kg_fat, kg_prot=excluded.kg_prot, "
                    "  price_nv=excluded.price_nv, sum_nv=excluded.sum_nv, "
                    "  price_v=excluded.price_v, sum_v=excluded.sum_v, "
                    "  vat=excluded.vat, cols_json=excluded.cols_json, "
                    "  source=excluded.source, "
                    "  photo=CASE WHEN excluded.photo!='' THEN excluded.photo ELSE milk_sales_daily.photo END, "
                    "  entered_by=CASE WHEN excluded.entered_by!='' THEN excluded.entered_by ELSE milk_sales_daily.entered_by END, "
                    "  updated_at=excluded.updated_at",
                    (d, self._to_float(r.get("kg") or 0),
                     self._to_float(r.get("l") or 0),
                     self._to_float(r.get("kg_fat") or 0),
                     self._to_float(r.get("kg_prot") or 0),
                     self._to_float(r.get("price_nv") or 0),
                     self._to_float(r.get("sum_nv") or 0),
                     self._to_float(r.get("price_v") or 0),
                     self._to_float(r.get("sum_v") or 0),
                     self._to_float(r.get("vat") or 0), cj, src, photo, by, now))
                n += 1
        return n

    def set_milk_manual_sale(self, day: str, kg: float, price: float,
                             photo: str = "", by: str = "") -> int:
        """Ручний продаж за день (Telegram-бот): kg + ціна/кг (без ПДВ) +
        фото + хто вніс. sum_nv = kg × price."""
        kg = self._to_float(kg); price = self._to_float(price)
        return self.set_milk_sales_daily([{
            "day": day, "kg": kg, "price_nv": price,
            "sum_nv": round(kg * price, 2), "photo": photo, "by": by,
        }], manual=True)

    def delete_milk_sales_day(self, day: str) -> bool:
        """Видалити день продажу з БД (для ручних записів)."""
        with self._connect() as conn:
            self._ensure_milk_sales_daily(conn)
            conn.execute("DELETE FROM milk_sales_daily WHERE day=?", (str(day)[:10],))
        return True

    def update_milk_register_field(self, which: str, day: str,
                                   field: str, value, shift=1) -> bool:
        """Редагування одного запису реєстру (лише ручні, source='manual').
        which: 'yields'|'sales'; field: 'kg'|'amount'|'by'.
        Надій — по зміні (day+shift). Продаж: зміна kg → sum_nv=kg×price;
        зміна amount → price=amount/kg."""
        day = str(day or "")[:10]
        if not day:
            return False
        if which == "yields":
            try:
                shift = int(shift or 1)
            except (TypeError, ValueError):
                shift = 1
            with self._connect() as conn:
                self._ensure_milk_yield_shifts(conn)
                r = conn.execute("SELECT kg FROM milk_yield_shifts "
                                 "WHERE day=? AND shift=?", (day, shift)).fetchone()
                if not r:
                    return False
                if field == "by":
                    conn.execute("UPDATE milk_yield_shifts SET entered_by=? "
                                 "WHERE day=? AND shift=?", (str(value), day, shift))
                elif field == "kg":
                    conn.execute("UPDATE milk_yield_shifts SET kg=? "
                                 "WHERE day=? AND shift=?",
                                 (self._to_float(value), day, shift))
                else:
                    return False
                self._recompute_milk_manual_day(conn, day)
            return True
        with self._connect() as conn:
            if which == "sales":
                self._ensure_milk_sales_daily(conn)
                r = conn.execute("SELECT kg, price_nv FROM milk_sales_daily "
                                 "WHERE day=? AND source='manual'", (day,)).fetchone()
                if not r:
                    return False
                if field == "by":
                    conn.execute("UPDATE milk_sales_daily SET entered_by=? "
                                 "WHERE day=? AND source='manual'", (str(value), day))
                elif field == "kg":
                    kg = self._to_float(value)
                    price = r["price_nv"] or 0
                    conn.execute("UPDATE milk_sales_daily SET kg=?, sum_nv=? "
                                 "WHERE day=? AND source='manual'",
                                 (kg, round(kg * price, 2), day))
                elif field == "amount":
                    amt = self._to_float(value)
                    kg = r["kg"] or 0
                    price = round(amt / kg, 4) if kg else 0
                    conn.execute("UPDATE milk_sales_daily SET sum_nv=?, price_nv=? "
                                 "WHERE day=? AND source='manual'", (amt, price, day))
                else:
                    return False
            else:
                self._ensure_milk_daily(conn)
                r = conn.execute("SELECT day FROM milk_daily "
                                 "WHERE day=? AND source='manual'", (day,)).fetchone()
                if not r:
                    return False
                if field == "by":
                    conn.execute("UPDATE milk_daily SET entered_by=? "
                                 "WHERE day=? AND source='manual'", (str(value), day))
                elif field == "kg":
                    conn.execute("UPDATE milk_daily SET kg=? "
                                 "WHERE day=? AND source='manual'",
                                 (self._to_float(value), day))
                else:
                    return False
        return True

    # ─────────────────── НАЛАШТОВУВАНА ФОРМА ОБЛІКУ МОЛОКА ───────────────────
    # Форма = впорядкований набір полів (як цикл ролі в персоналі). Запис
    # ведеться за ключем ДАТА + ЗМІНА (ранок/вечір) — так вимагає ТЗ клієнта:
    # доїння може почати одна людина, а показники якості дозаповнити інша.
    MILK_FIELD_KINDS = ("number", "text", "time", "photo", "yesno", "duration",
                        "shift", "date", "formula")

    def _ensure_milk_forms(self, conn: sqlite3.Connection) -> None:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_forms ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " name TEXT NOT NULL DEFAULT '',"
            " note TEXT NOT NULL DEFAULT '',"
            " per_shift INTEGER NOT NULL DEFAULT 1,"   # 1 = запис на дату+зміну
            " sort_order INTEGER NOT NULL DEFAULT 0,"
            " is_active INTEGER NOT NULL DEFAULT 1,"
            " created_at TEXT NOT NULL DEFAULT '')")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_form_fields ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " form_id INTEGER NOT NULL,"
            " label TEXT NOT NULL DEFAULT '',"
            " kind TEXT NOT NULL DEFAULT 'number',"
            " unit TEXT NOT NULL DEFAULT '',"
            " required INTEGER NOT NULL DEFAULT 1,"
            " sort_order INTEGER NOT NULL DEFAULT 0,"
            " calc_from TEXT NOT NULL DEFAULT '',"
            " calc_to TEXT NOT NULL DEFAULT '',"
            " note TEXT NOT NULL DEFAULT '')")
        # formula — вираз для типу «Формула»: інші колонки в квадратних дужках,
        # напр. «[Літри] + [Молоко поза лічильником]» або «[Кілограми] * 0.97».
        _fc = {r["name"] for r in conn.execute(
            "PRAGMA table_info(milk_form_fields)").fetchall()}
        if "formula" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN formula TEXT "
                         "NOT NULL DEFAULT ''")
        # in_header — показувати підсумок цієї колонки в шапці дня
        if "in_header" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN in_header INTEGER "
                         "NOT NULL DEFAULT 0")
        # decimals — скільки знаків після коми показувати (-1 = як введено)
        if "decimals" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN decimals INTEGER "
                         "NOT NULL DEFAULT -1")
        # total_mode — як рахувати «Всього за день» для колонки-формули:
        # 'sum' (додати значення змін) або 'formula' (порахувати вираз від сум)
        if "total_mode" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN total_mode TEXT "
                         "NOT NULL DEFAULT 'sum'")
        # section — до якої таблиці належить колонка:
        # 'shift' (зміни надою) або 'sale' (відвантаження молока)
        if "section" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN section TEXT "
                         "NOT NULL DEFAULT 'shift'")
        # auto_dot — кома ставиться сама після N цифр (напр. жир: 355 → 3,55)
        if "auto_dot" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN auto_dot INTEGER "
                         "NOT NULL DEFAULT 0")
        # default_value — чим заповнювати порожню клітинку (напр. молзавод «Кагма»).
        # Це ЛИШЕ підказка при вводі: у базу пишеться значення рядка, тож зміна
        # або скасування дефолта не чіпає вже внесену історію.
        if "default_value" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN default_value TEXT "
                         "NOT NULL DEFAULT ''")
        # visible — показувати колонку в таблиці. Прихована колонка НЕ видаляється:
        # значення лишаються в базі й далі беруть участь у формулах.
        if "visible" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN visible INTEGER "
                         "NOT NULL DEFAULT 1")
        # total_formula — окремий вираз для рядка «Всього за день»
        # (напр. середній жир = [Жир кг] / [Продано кг], рахується від денних сум)
        if "total_formula" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN total_formula TEXT "
                         "NOT NULL DEFAULT ''")
        # width — ширина колонки в пікселях (памʼятається в БД, а не в браузері)
        if "width" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN width INTEGER "
                         "NOT NULL DEFAULT 0")
        # ask_tg — цю колонку бот питає в Telegram (формули не питаються ніколи)
        if "ask_tg" not in _fc:
            conn.execute("ALTER TABLE milk_form_fields ADD COLUMN ask_tg INTEGER "
                         "NOT NULL DEFAULT 0")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_form_runs ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " form_id INTEGER NOT NULL,"
            " run_date TEXT NOT NULL DEFAULT '',"
            " shift TEXT NOT NULL DEFAULT '',"        # am | pm | '' (без змін)
            " created_at TEXT NOT NULL DEFAULT '',"
            " created_by TEXT NOT NULL DEFAULT '',"
            " UNIQUE(form_id, run_date, shift))")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS milk_form_values ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " run_id INTEGER NOT NULL,"
            " label TEXT NOT NULL DEFAULT '',"
            " kind TEXT NOT NULL DEFAULT '',"
            " value TEXT NOT NULL DEFAULT '',"
            " photo TEXT NOT NULL DEFAULT '',"
            " sort_order INTEGER NOT NULL DEFAULT 0,"
            " entered_by TEXT NOT NULL DEFAULT '',"
            " updated_at TEXT NOT NULL DEFAULT '',"
            " UNIQUE(run_id, label))")

    def list_milk_forms(self) -> list[dict[str, Any]]:
        """Форми обліку молока з кількістю полів."""
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            rows = conn.execute(
                "SELECT f.id, f.name, f.note, f.per_shift, f.sort_order, f.is_active, "
                "  (SELECT COUNT(*) FROM milk_form_fields x WHERE x.form_id=f.id) AS field_count "
                "FROM milk_forms f WHERE f.is_active=1 "
                "ORDER BY f.sort_order, f.id").fetchall()
        return [dict(r) for r in rows]

    def save_milk_form(self, form_id: int = 0, name: str = "", note: str = "",
                       per_shift: bool = True) -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("Вкажіть назву форми.")
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            if form_id:
                conn.execute(
                    "UPDATE milk_forms SET name=?, note=?, per_shift=? WHERE id=?",
                    (name, (note or "").strip(), 1 if per_shift else 0, int(form_id)))
                return int(form_id)
            pos = conn.execute(
                "SELECT COALESCE(MAX(sort_order),0)+1 FROM milk_forms").fetchone()[0]
            cur = conn.execute(
                "INSERT INTO milk_forms(name, note, per_shift, sort_order, is_active, "
                "created_at) VALUES(?,?,?,?,1,?)",
                (name, (note or "").strip(), 1 if per_shift else 0, pos, self._now()))
            return int(cur.lastrowid)

    def delete_milk_form(self, form_id: int) -> None:
        """Мʼяке видалення форми (записи лишаються)."""
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            conn.execute("UPDATE milk_forms SET is_active=0 WHERE id=?", (int(form_id),))

    def reorder_milk_forms(self, order: list) -> None:
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            for i, fid in enumerate([int(x) for x in (order or []) if str(x).isdigit()], 1):
                conn.execute("UPDATE milk_forms SET sort_order=? WHERE id=?", (i, fid))

    def list_milk_form_fields(self, form_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            rows = conn.execute(
                "SELECT id, label, kind, unit, required, sort_order, calc_from, calc_to, "
                "       note, formula, in_header, decimals, total_mode, section, auto_dot, "
                "       default_value, visible, total_formula, width, ask_tg "
                "FROM milk_form_fields WHERE form_id=? ORDER BY sort_order, id",
                (int(form_id),)).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def _milk_dec(v) -> int:
        """Знаків після коми: -1 = як введено, інакше 0…6."""
        try:
            d = int(v)
        except (TypeError, ValueError):
            return -1
        return -1 if d < 0 else min(6, d)

    # ── Обчислення формул колонок (той самий синтаксис, що й на сторінці) ──
    # Власний розбір виразу, БЕЗ eval: числа, [Назва колонки], + - * / ^ %,
    # дужки, порівняння = <> < > <= >=, функції SUM AVG MIN MAX ROUND ROUNDUP
    # ROUNDDOWN ABS INT SQRT IF. Потрібне, щоб рядки, внесені ботом у Telegram,
    # мали заповнені обчислювані колонки — а не лише те, що спитали в людини.
    _FX_FUNCS = {
        "SUM": lambda a: sum(a),
        "AVG": lambda a: (sum(a) / len(a)) if a else 0.0,
        "AVERAGE": lambda a: (sum(a) / len(a)) if a else 0.0,
        "MIN": lambda a: min(a) if a else 0.0,
        "MAX": lambda a: max(a) if a else 0.0,
        "ROUND": lambda a: round(a[0], int(a[1]) if len(a) > 1 else 0),
        "ROUNDUP": lambda a: math.ceil(a[0] * 10 ** int(a[1] if len(a) > 1 else 0))
                             / 10 ** int(a[1] if len(a) > 1 else 0),
        "ROUNDDOWN": lambda a: math.floor(a[0] * 10 ** int(a[1] if len(a) > 1 else 0))
                               / 10 ** int(a[1] if len(a) > 1 else 0),
        "ABS": lambda a: abs(a[0]),
        "INT": lambda a: float(math.floor(a[0])),
        "SQRT": lambda a: math.sqrt(a[0]),
        "IF": lambda a: (a[1] if len(a) > 1 else 1.0) if a[0] else (a[2] if len(a) > 2 else 0.0),
    }

    @staticmethod
    def _fx_num(v) -> float:
        """«1 234,5» → 1234.5 (пробіли-роздільники тисяч знімаємо)."""
        t = str(v if v is not None else "").replace("\u00a0", "").replace(" ", "")
        t = t.replace(",", ".")
        try:
            return float(t)
        except (TypeError, ValueError):
            return 0.0

    @classmethod
    def _fx_tokens(cls, src: str) -> list:
        s, i, out = str(src or ""), 0, []
        while i < len(s):
            c = s[i]
            if c.isspace():
                i += 1
                continue
            if c == "[":
                j = s.find("]", i)
                if j < 0:
                    raise ValueError("не закрито «]»")
                out.append(("ref", s[i + 1:j].strip()))
                i = j + 1
                continue
            m = re.match(r"[0-9]+([.,][0-9]+)?|[.][0-9]+", s[i:])
            if m:
                out.append(("num", float(m.group(0).replace(",", "."))))
                i += len(m.group(0))
                continue
            if c.isalpha() or c == "_":
                j = i
                while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                    j += 1
                out.append(("fn", s[i:j].upper()))
                i = j
                continue
            if s[i:i + 2] in ("<=", ">=", "<>"):
                out.append(("op", s[i:i + 2]))
                i += 2
                continue
            if c in "+-*/^%(),;=<>":
                out.append(("op", c))
                i += 1
                continue
            raise ValueError("невідомий символ «%s»" % c)
        return out

    @classmethod
    def _fx_parse(cls, src: str):
        tk = cls._fx_tokens(src)
        pos = {"i": 0}

        def peek():
            return tk[pos["i"]] if pos["i"] < len(tk) else None

        def eat(v):
            t = peek()
            if t and t[0] == "op" and t[1] == v:
                pos["i"] += 1
                return True
            return False

        def expr():
            left = add()
            t = peek()
            if t and t[0] == "op" and t[1] in ("=", "<>", "<", ">", "<=", ">="):
                pos["i"] += 1
                return ("cmp", t[1], left, add())
            return left

        def add():
            left = mul()
            while True:
                if eat("+"):
                    left = ("bin", "+", left, mul())
                elif eat("-"):
                    left = ("bin", "-", left, mul())
                else:
                    return left

        def mul():
            left = power()
            while True:
                if eat("*"):
                    left = ("bin", "*", left, power())
                elif eat("/"):
                    left = ("bin", "/", left, power())
                else:
                    return left

        def power():
            left = unary()
            if eat("^"):
                return ("bin", "^", left, power())
            return left

        def unary():
            if eat("-"):
                return ("neg", unary())
            if eat("+"):
                return unary()
            node = atom()
            while eat("%"):
                node = ("pct", node)
            return node

        def atom():
            t = peek()
            if not t:
                raise ValueError("вираз обірвано")
            if t[0] == "num":
                pos["i"] += 1
                return ("num", t[1])
            if t[0] == "ref":
                pos["i"] += 1
                return ("ref", t[1])
            if t[0] == "fn":
                pos["i"] += 1
                name = t[1]
                if name not in cls._FX_FUNCS:
                    raise ValueError("невідома функція %s" % name)
                if not eat("("):
                    raise ValueError("%s — потрібні дужки" % name)
                args = []
                if not eat(")"):
                    while True:
                        args.append(expr())
                        if eat(",") or eat(";"):
                            continue
                        if eat(")"):
                            break
                        raise ValueError("не закрито дужку у %s" % name)
                return ("fn", name, args)
            if eat("("):
                node = expr()
                if not eat(")"):
                    raise ValueError("не закрито «)»")
                return node
            raise ValueError("несподіване «%s»" % str(t[1]))

        root = expr()
        if pos["i"] < len(tk):
            raise ValueError("зайве «%s»" % str(tk[pos["i"]][1]))
        return root

    @classmethod
    def _fx_run(cls, node, vals: dict) -> float:
        kind = node[0]
        if kind == "num":
            return node[1]
        if kind == "ref":
            if node[1] not in vals:
                raise ValueError("немає колонки «%s»" % node[1])
            return cls._fx_num(vals[node[1]])
        if kind == "neg":
            return -cls._fx_run(node[1], vals)
        if kind == "pct":
            return cls._fx_run(node[1], vals) / 100.0
        if kind == "bin":
            a, b = cls._fx_run(node[2], vals), cls._fx_run(node[3], vals)
            if node[1] == "+":
                return a + b
            if node[1] == "-":
                return a - b
            if node[1] == "*":
                return a * b
            if node[1] == "/":
                if not b:
                    raise ValueError("ділення на нуль")
                return a / b
            return a ** b
        if kind == "cmp":
            a, b = cls._fx_run(node[2], vals), cls._fx_run(node[3], vals)
            ok = {"=": a == b, "<>": a != b, "<": a < b, ">": a > b,
                  "<=": a <= b, ">=": a >= b}[node[1]]
            return 1.0 if ok else 0.0
        if kind == "fn":
            return float(cls._FX_FUNCS[node[1]]([cls._fx_run(x, vals) for x in node[2]]))
        raise ValueError("вираз")

    @classmethod
    def milk_calc_formula(cls, expr: str, vals: dict):
        """Значення виразу або None, якщо порахувати не вдалось."""
        if not str(expr or "").strip():
            return None
        try:
            v = cls._fx_run(cls._fx_parse(expr), vals)
        except Exception:  # noqa: BLE001 — будь-яка помилка = порожня клітинка
            return None
        if v != v or v in (float("inf"), float("-inf")):
            return None
        return round(v, 3)

    def milk_orphan_values(self, form_id: int) -> list:
        """Значення, що лежать під назвами колонок, яких у формі вже немає
        (лишаються після перейменування/видалення колонки)."""
        form_id = int(form_id or 0)
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            return [dict(r) for r in conn.execute(
                "SELECT v.label AS label, COUNT(*) AS cnt FROM milk_form_values v "
                "JOIN milk_form_runs r ON r.id = v.run_id "
                "WHERE r.form_id=? AND v.label NOT IN "
                "  (SELECT label FROM milk_form_fields WHERE form_id=?) "
                "GROUP BY v.label ORDER BY v.label", (form_id, form_id)).fetchall()]

    def milk_prune_orphans(self, form_id: int) -> int:
        """Видалити значення під назвами, яких у формі вже немає. Викликається
        ЛИШЕ вручну (кнопкою) — щоб збереження колонок ніколи не терло дані."""
        form_id = int(form_id or 0)
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            cur = conn.execute(
                "DELETE FROM milk_form_values WHERE run_id IN "
                "  (SELECT id FROM milk_form_runs WHERE form_id=?) "
                "AND label NOT IN (SELECT label FROM milk_form_fields WHERE form_id=?)",
                (form_id, form_id))
            dropped = int(cur.rowcount or 0)
            conn.execute(
                "DELETE FROM milk_form_runs WHERE form_id=? AND id NOT IN "
                "  (SELECT run_id FROM milk_form_values)", (form_id,))
            return dropped

    def save_milk_col_widths(self, form_id: int, widths: dict) -> int:
        """Запамʼятати ширину колонок у БД: {id поля: пікселі}."""
        form_id = int(form_id or 0)
        done = 0
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            for fid, px in (widths or {}).items():
                try:
                    fid_i, px_i = int(fid), int(float(px))
                except (TypeError, ValueError):
                    continue
                if px_i <= 0:
                    continue
                conn.execute("UPDATE milk_form_fields SET width=? WHERE id=? AND form_id=?",
                             (min(1200, px_i), fid_i, form_id))
                done += 1
        return done

    def milk_move_values(self, form_id: int, src: str, dst: str) -> int:
        """Перенести значення зі старої назви (`src`) у колонку `dst`.
        Потрібно, коли колонку перейменували старою версією — дані лишились
        під попередньою назвою. Повертає, скільки значень перенесено."""
        form_id, src, dst = int(form_id or 0), str(src or "").strip(), str(dst or "").strip()
        if not (form_id and src and dst) or src == dst:
            return 0
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            runs = "(SELECT id FROM milk_form_runs WHERE form_id=?)"
            # у прогонах, де є старе значення, звільняємо місце під нову назву
            conn.execute(
                "DELETE FROM milk_form_values WHERE run_id IN " + runs + " AND label=? "
                "AND run_id IN (SELECT run_id FROM milk_form_values WHERE label=?)",
                (form_id, dst, src))
            cur = conn.execute(
                "UPDATE milk_form_values SET label=? WHERE run_id IN " + runs + " AND label=?",
                (dst, form_id, src))
            return int(cur.rowcount or 0)

    def save_milk_form_fields(self, form_id: int, fields: list) -> int:
        """Замінити всі поля форми (як save_role_steps у персоналі).
        ПЕРЕЙМЕНУВАННЯ: колонка впізнається за `id`, тому внесені дані переїжджають
        під нову назву (`milk_form_values.label` оновлюється). Дані НІКОЛИ не
        видаляються автоматично — прибрати значення зниклих колонок можна лише
        вручну через milk_prune_orphans(). Повертає 0 (лишено для сумісності)."""
        form_id = int(form_id)
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            # ── ПЕРЕЙМЕНУВАННЯ: колонку впізнаємо за id, тож дані не пропадають ──
            old_map = {int(r["id"]): r["label"] for r in conn.execute(
                "SELECT id, label FROM milk_form_fields WHERE form_id=?", (form_id,)).fetchall()}
            renames = []
            for fl in (fields or []):
                lb = str((fl or {}).get("label") or "").strip()
                fid_ = int((fl or {}).get("id") or 0)
                if lb and fid_ in old_map and old_map[fid_] != lb:
                    renames.append((old_map[fid_], lb))
            if renames:
                runs = "(SELECT id FROM milk_form_runs WHERE form_id=?)"
                # два кроки через тимчасову мітку — щоб пережити навіть обмін назвами
                for i, (o, _n) in enumerate(renames):
                    conn.execute(
                        "UPDATE milk_form_values SET label=? WHERE run_id IN " + runs
                        + " AND label=?", ("\x00rn%d" % i, form_id, o))
                for i, (_o, nn) in enumerate(renames):
                    conn.execute(
                        "DELETE FROM milk_form_values WHERE run_id IN " + runs
                        + " AND label=?", (form_id, nn))
                    conn.execute(
                        "UPDATE milk_form_values SET label=? WHERE run_id IN " + runs
                        + " AND label=?", (nn, form_id, "\x00rn%d" % i))
            conn.execute("DELETE FROM milk_form_fields WHERE form_id=?", (form_id,))
            pos = 0
            for fl in (fields or []):
                label = str((fl or {}).get("label") or "").strip()
                if not label:
                    continue
                kind = str((fl or {}).get("kind") or "number").strip()
                if kind not in self.MILK_FIELD_KINDS:
                    kind = "number"
                pos += 1
                keep_id = int((fl or {}).get("id") or 0)
                keep_id = keep_id if keep_id in old_map else None
                conn.execute(
                    "INSERT INTO milk_form_fields(id, form_id, label, kind, unit, required, "
                    "sort_order, calc_from, calc_to, note, formula, in_header, decimals, "
                    "total_mode, section, auto_dot, default_value, visible, total_formula, "
                    "width, ask_tg) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (keep_id, form_id, label, kind, str((fl or {}).get("unit") or "").strip(),
                     1 if (fl or {}).get("required", True) else 0, pos,
                     str((fl or {}).get("calc_from") or "").strip(),
                     str((fl or {}).get("calc_to") or "").strip(),
                     str((fl or {}).get("note") or "").strip(),
                     str((fl or {}).get("formula") or "").strip(),
                     1 if (fl or {}).get("in_header") else 0,
                     self._milk_dec((fl or {}).get("decimals")),
                     (str((fl or {}).get("total_mode") or "")
                      if str((fl or {}).get("total_mode") or "") in ("formula", "own")
                      else "sum"),
                     "sale" if str((fl or {}).get("section") or "") == "sale" else "shift",
                     max(0, min(4, int((fl or {}).get("auto_dot") or 0))),
                     str((fl or {}).get("default_value") or "").strip(),
                     0 if (fl or {}).get("visible") is False else 1,
                     str((fl or {}).get("total_formula") or "").strip(),
                     max(0, min(1200, int((fl or {}).get("width") or 0))),
                     1 if ((fl or {}).get("ask_tg") and kind != "formula") else 0))
            # НІЧОГО не видаляємо: значення прибраних колонок лишаються в базі,
            # доки користувач сам не натисне «Прибрати» (milk_prune_orphans).
            return 0

    def seed_milk_form(self) -> int:
        """Створити типову форму обліку молока, якщо жодної ще немає:
        Дата → Зміна → літри / кілограми / поза лічильником / мастит /
        випойка бикам / випойка теличкам."""
        forms = self.list_milk_forms()
        if forms:
            return int(forms[0]["id"])
        fid = self.save_milk_form(name="Облік молока", per_shift=True)
        self.save_milk_form_fields(fid, [
            {"label": "Літри", "kind": "number", "unit": "л"},
            {"label": "Кілограми", "kind": "number", "unit": "кг"},
            {"label": "Молоко поза лічильником", "kind": "number", "unit": "л"},
            {"label": "Мастит", "kind": "number", "unit": "л"},
            {"label": "Випойка бикам", "kind": "number", "unit": "л"},
            {"label": "Випойка теличкам", "kind": "number", "unit": "л"},
        ])
        return fid

    def milk_entry_grid(self, form_id: int, days: int) -> dict[str, Any]:
        """Сітка вводу: рядки — дні (останні N), у кожному дні — зміни зі
        значеннями полів форми. Ключ запису — форма + дата + зміна."""
        form_id = int(form_id or 0)
        days = max(1, min(120, int(days or 14)))
        today = self._now()[:10]
        dlist = [(datetime.strptime(today, "%Y-%m-%d") - timedelta(days=i)).strftime("%Y-%m-%d")
                 for i in range(days)]
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            frow = conn.execute(
                "SELECT id, name, per_shift FROM milk_forms WHERE id=? AND is_active=1",
                (form_id,)).fetchone()
            if not frow:
                return {"form": None, "fields": [], "shifts": [], "rows": []}
            fields = [dict(r) for r in conn.execute(
                "SELECT id, label, kind, unit, required, sort_order, calc_from, calc_to, "
                "       formula, in_header, decimals, total_mode, section, auto_dot, "
                "       default_value, visible, total_formula, width, ask_tg "
                "FROM milk_form_fields WHERE form_id=? ORDER BY sort_order, id",
                (form_id,)).fetchall()]
            sale_fields = [f for f in fields if (f.get("section") or "shift") == "sale"]
            fields = [f for f in fields if (f.get("section") or "shift") != "sale"]
            shifts = ([{"key": "am", "label": "Зміна 1"}, {"key": "pm", "label": "Зміна 2"}]
                      if frow["per_shift"] else [{"key": "", "label": "За добу"}])
            vals: dict = {}
            for r in conn.execute(
                    "SELECT r.run_date AS d, r.shift AS sh, v.label AS lb, v.value AS val, "
                    "       v.photo AS ph, v.entered_by AS by "
                    "FROM milk_form_runs r JOIN milk_form_values v ON v.run_id=r.id "
                    "WHERE r.form_id=? AND r.run_date>=?", (form_id, dlist[-1])).fetchall():
                vals.setdefault((r["d"], r["sh"] or ""), {})[r["lb"]] = {
                    "value": r["val"] or "", "photo": r["ph"] or "", "by": r["by"] or ""}
            # ключі рядків продажу (shift = 'sale:<n>') за кожну дату
            sale_keys: dict = {}
            for r in conn.execute(
                    "SELECT run_date AS d, shift AS sh FROM milk_form_runs "
                    "WHERE form_id=? AND run_date>=? AND shift LIKE 'sale:%' "
                    "ORDER BY id", (form_id, dlist[-1])).fetchall():
                sale_keys.setdefault(r["d"], []).append(r["sh"])
        rows = []
        for d in dlist:
            sh_data = {}
            for sh in shifts:
                cells = vals.get((d, sh["key"]), {})
                sh_data[sh["key"]] = {
                    "values": {f["label"]: (cells.get(f["label"], {}).get("value", ""))
                               for f in fields},
                    "filled": any((cells.get(f["label"], {}).get("value", "") or "").strip()
                                  for f in fields),
                }
            sales = []
            for key in sale_keys.get(d, []):
                cells = vals.get((d, key), {})
                sales.append({
                    "key": key,
                    "values": {f["label"]: (cells.get(f["label"], {}).get("value", ""))
                               for f in sale_fields},
                })
            rows.append({"date": d, "shifts": sh_data, "sales": sales})
        return {"form": {"id": frow["id"], "name": frow["name"],
                         "per_shift": bool(frow["per_shift"])},
                "fields": fields, "sale_fields": sale_fields,
                "shifts": shifts, "rows": rows, "days": days}

    def milk_add_sale_run(self, form_id: int, run_date: str, entered_by: str = "") -> str:
        """Додати порожній рядок відвантаження на дату. Повертає ключ рядка."""
        form_id = int(form_id or 0)
        run_date = str(run_date or "")[:10]
        if not (form_id and run_date):
            raise ValueError("Не вказано форму або дату.")
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            used = {r["shift"] for r in conn.execute(
                "SELECT shift FROM milk_form_runs WHERE form_id=? AND run_date=? "
                "AND shift LIKE 'sale:%'", (form_id, run_date)).fetchall()}
            n = 1
            while ("sale:%d" % n) in used:
                n += 1
            key = "sale:%d" % n
            conn.execute(
                "INSERT INTO milk_form_runs(form_id, run_date, shift, created_at, created_by) "
                "VALUES(?,?,?,?,?)", (form_id, run_date, key, self._now(), entered_by or ""))
            return key

    def milk_sale_runs_since(self, form_id: int, day_from: str) -> list[dict[str, Any]]:
        """Рядки продажу (sale:N) з датами >= day_from разом зі значеннями —
        для дозаповнення порожніх клітинок Excel даними, введеними через
        Telegram. Повертає [{date, n, values:{label:value}}]."""
        form_id = int(form_id or 0)
        day_from = str(day_from or "")[:10]
        out: list[dict[str, Any]] = []
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            runs = conn.execute(
                "SELECT id, run_date, shift FROM milk_form_runs WHERE form_id=? "
                "AND run_date>=? AND shift LIKE 'sale:%' ORDER BY run_date, shift",
                (form_id, day_from)).fetchall()
            for r in runs:
                try:
                    n = int(str(r["shift"]).split(":", 1)[1])
                except (IndexError, ValueError):
                    continue
                vals = {v["label"]: v["value"] for v in conn.execute(
                    "SELECT label, value FROM milk_form_values WHERE run_id=?",
                    (r["id"],)).fetchall()
                    if str(v["value"] or "").strip()}
                if vals:
                    out.append({"date": r["run_date"], "n": n, "values": vals})
        return out

    def milk_shift_runs_since(self, form_id: int, day_from: str) -> list[dict[str, Any]]:
        """Змінні рядки (am/pm) з датами >= day_from зі значеннями — для
        дозаповнення Excel «Виробництво» (лише порожні клітинки)."""
        form_id = int(form_id or 0)
        day_from = str(day_from or "")[:10]
        out: list[dict[str, Any]] = []
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            for r in conn.execute(
                    "SELECT id, run_date, shift FROM milk_form_runs WHERE form_id=? "
                    "AND run_date>=? AND shift IN ('am','pm') ORDER BY run_date, shift",
                    (form_id, day_from)).fetchall():
                vals = {v["label"]: v["value"] for v in conn.execute(
                    "SELECT label, value FROM milk_form_values WHERE run_id=?",
                    (r["id"],)).fetchall() if str(v["value"] or "").strip()}
                if vals:
                    out.append({"date": r["run_date"],
                                "n": 1 if r["shift"] == "am" else 2,
                                "values": vals})
        return out

    def milk_delete_run(self, form_id: int, run_date: str, shift: str) -> int:
        """Прибрати рядок (разом зі значеннями). Використовується для продажу."""
        form_id = int(form_id or 0)
        run_date = str(run_date or "")[:10]
        shift = str(shift or "").strip()
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            row = conn.execute(
                "SELECT id FROM milk_form_runs WHERE form_id=? AND run_date=? AND shift=?",
                (form_id, run_date, shift)).fetchone()
            if not row:
                return 0
            conn.execute("DELETE FROM milk_form_values WHERE run_id=?", (int(row["id"]),))
            conn.execute("DELETE FROM milk_form_runs WHERE id=?", (int(row["id"]),))
            return 1

    def save_milk_entry(self, form_id: int, run_date: str, shift: str,
                        values: dict, entered_by: str = "") -> int:
        """Зберегти значення однієї зміни (upsert за формою+датою+зміною).
        Порожні значення прибираються — щоб «filled» був чесним."""
        form_id = int(form_id or 0)
        run_date = str(run_date or "")[:10]
        shift = str(shift or "").strip()
        if not (form_id and run_date):
            raise ValueError("Не вказано форму або дату.")
        now = self._now()
        with self._connect() as conn:
            self._ensure_milk_forms(conn)
            row = conn.execute(
                "SELECT id FROM milk_form_runs WHERE form_id=? AND run_date=? AND shift=?",
                (form_id, run_date, shift)).fetchone()
            if row:
                run_id = int(row["id"])
            else:
                cur = conn.execute(
                    "INSERT INTO milk_form_runs(form_id, run_date, shift, created_at, created_by) "
                    "VALUES(?,?,?,?,?)", (form_id, run_date, shift, now, entered_by or ""))
                run_id = int(cur.lastrowid)
            order = {r["label"]: r["sort_order"] for r in conn.execute(
                "SELECT label, sort_order FROM milk_form_fields WHERE form_id=?",
                (form_id,)).fetchall()}
            for label, val in (values or {}).items():
                label = str(label or "").strip()
                if not label:
                    continue
                sval = "" if val is None else str(val).strip()
                if sval == "":
                    conn.execute("DELETE FROM milk_form_values WHERE run_id=? AND label=?",
                                 (run_id, label))
                    continue
                conn.execute(
                    "INSERT INTO milk_form_values(run_id, label, kind, value, photo, "
                    " sort_order, entered_by, updated_at) VALUES(?,?,'',?,'',?,?,?) "
                    "ON CONFLICT(run_id, label) DO UPDATE SET value=excluded.value, "
                    " entered_by=excluded.entered_by, updated_at=excluded.updated_at",
                    (run_id, label, sval, int(order.get(label, 0)), entered_by or "", now))
            # ── колонки-формули рахуємо ТУТ, а не в браузері: тоді рядок,
            #    внесений ботом у Telegram, теж повний
            self._milk_fill_formulas(conn, form_id, run_id, shift, entered_by, now)
        return run_id

    def _milk_fill_formulas(self, conn, form_id: int, run_id: int, shift: str,
                            entered_by: str, now: str) -> None:
        """Заповнити обчислювані колонки рядка від його ж значень.
        Кілька проходів — формула може спиратись на іншу формулу."""
        want = "sale" if str(shift or "").startswith("sale:") else "shift"
        fields = [dict(r) for r in conn.execute(
            "SELECT label, kind, formula, sort_order, section FROM milk_form_fields "
            "WHERE form_id=? ORDER BY sort_order, id", (form_id,)).fetchall()]
        fields = [f for f in fields if (f.get("section") or "shift") == want]
        fx = [f for f in fields if (f.get("kind") or "") == "formula"]
        if not fx:
            return
        vals = {f["label"]: "" for f in fields}
        for r in conn.execute("SELECT label, value FROM milk_form_values WHERE run_id=?",
                              (run_id,)).fetchall():
            vals[r["label"]] = r["value"] or ""
        for _ in range(len(fx) + 1):
            changed = False
            for f in fx:
                got = self.milk_calc_formula(f.get("formula") or "", vals)
                txt = "" if got is None else ("%g" % got)
                if str(vals.get(f["label"]) or "") == txt:
                    continue
                vals[f["label"]] = txt
                changed = True
                if txt == "":
                    conn.execute("DELETE FROM milk_form_values WHERE run_id=? AND label=?",
                                 (run_id, f["label"]))
                else:
                    conn.execute(
                        "INSERT INTO milk_form_values(run_id, label, kind, value, photo, "
                        " sort_order, entered_by, updated_at) VALUES(?,?,'',?,'',?,?,?) "
                        "ON CONFLICT(run_id, label) DO UPDATE SET value=excluded.value, "
                        " updated_at=excluded.updated_at",
                        (run_id, f["label"], txt, int(f.get("sort_order") or 0),
                         entered_by or "", now))
            if not changed:
                break

    def milk_kg_map(self, date_from: str = "", date_to: str = "") -> dict:
        """Надій для звітів {день: кг} — беремо milk_daily.kg (це вибрана колонка
        надою = залік), НЕ з cols_json (там milk_total_kg = сира кг)."""
        out = {}
        with self._connect() as conn:
            self._ensure_milk_daily(conn)
            q = "SELECT day, kg FROM milk_daily"
            cond, args = [], []
            if date_from:
                cond.append("day >= ?"); args.append(date_from[:10])
            if date_to:
                cond.append("day <= ?"); args.append(date_to[:10])
            if cond:
                q += " WHERE " + " AND ".join(cond)
            for r in conn.execute(q, args).fetchall():
                out[str(r["day"])[:10]] = r["kg"] or 0
        return out

    def milk_sales_rows(self, date_from: str = "", date_to: str = "") -> list:
        """Денний продаж із БД як рядки під milk_excel.aggregate:
        [{'date', 'sale_milk_kg', 'sale_milk_l', 'kgFat', 'kgProtein',
          '_amount_nv', '_amount_v', '_vat'}]."""
        import datetime as _dt
        out = []
        with self._connect() as conn:
            self._ensure_milk_sales_daily(conn)
            q = ("SELECT day, kg, l, kg_fat, kg_prot, sum_nv, sum_v, vat, cols_json, "
                 "source, photo, entered_by, updated_at FROM milk_sales_daily")
            cond, args = [], []
            if date_from:
                cond.append("day >= ?"); args.append(date_from[:10])
            if date_to:
                cond.append("day <= ?"); args.append(date_to[:10])
            if cond:
                q += " WHERE " + " AND ".join(cond)
            q += " ORDER BY day"
            for r in conn.execute(q, args).fetchall():
                try:
                    d = _dt.datetime.strptime(str(r["day"])[:10], "%Y-%m-%d").date()
                except ValueError:
                    continue
                keys = r.keys()
                row = {"date": d,
                       "sale_milk_kg": r["kg"] or 0,
                       "sale_milk_l": r["l"] or 0,
                       "kgFat": r["kg_fat"] or 0,
                       "kgProtein": r["kg_prot"] or 0,
                       "_amount_nv": r["sum_nv"] or 0,
                       "_amount_v": r["sum_v"] or 0,
                       "_vat": r["vat"] or 0,
                       "source": (r["source"] if "source" in keys else "") or "",
                       "photo": (r["photo"] if "photo" in keys else "") or "",
                       "entered_by": (r["entered_by"] if "entered_by" in keys else "") or "",
                       "at": (r["updated_at"] if "updated_at" in keys else "") or ""}
                cj = r["cols_json"] if "cols_json" in r.keys() else ""
                if cj:
                    try:
                        row.update(json.loads(cj))   # усі колонки метрик продажу
                    except Exception:  # noqa: BLE001
                        pass
                out.append(row)
        return out

    def milk_sales_day(self, day: str) -> Optional[dict]:
        """Один день продажу з БД (для Звіту-2). None, якщо немає."""
        day = str(day or "")[:10]
        if not day:
            return None
        with self._connect() as conn:
            self._ensure_milk_sales_daily(conn)
            r = conn.execute(
                "SELECT kg, l, kg_fat, kg_prot, price_nv, sum_nv, price_v, "
                "sum_v, vat FROM milk_sales_daily WHERE day = ?", (day,)).fetchone()
            if not r:
                return None
            kg = r["kg"] or 0
            if kg <= 0 and (r["sum_nv"] or 0) <= 0:
                return None
            return {"kg": round(kg, 1),
                    "sum_nv": round(r["sum_nv"] or 0, 2),
                    "price_nv": round(r["price_nv"] or 0, 4) or None,
                    "sum_v": round(r["sum_v"] or 0, 2),
                    "price_v": round(r["price_v"] or 0, 4) or None,
                    "vat": round(r["vat"] or 0, 2)}

    def _ensure_herd_daily(self, conn: sqlite3.Connection) -> None:
        """Кеш поголів'я по днях × групах з Excel «Управління стада» — щоб
        поголів'я синхронізувалось на сервер (там немає доступу до Excel)."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS herd_daily ("
            " day TEXT NOT NULL, grp TEXT NOT NULL, label TEXT NOT NULL DEFAULT '',"
            " heads REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT '',"
            " PRIMARY KEY(day, grp))")

    def set_herd_daily(self, rows: list) -> int:
        """Зберегти поголів'я по днях×групах у БД (upsert по (day, grp)).
        rows: список {day, grp, label, heads}."""
        if not rows:
            return 0
        now = self._now()
        n = 0
        with self._connect() as conn:
            self._ensure_herd_daily(conn)
            for r in rows:
                d = str(r.get("day") or "")[:10]
                g = str(r.get("grp") or "").strip()
                if not d or not g:
                    continue
                conn.execute(
                    "INSERT INTO herd_daily(day, grp, label, heads, updated_at) "
                    "VALUES(?,?,?,?,?) ON CONFLICT(day, grp) DO UPDATE SET "
                    "label=excluded.label, heads=excluded.heads, "
                    "updated_at=excluded.updated_at",
                    (d, g, str(r.get("label") or g),
                     max(0.0, self._to_float(r.get("heads") or 0)), now))
                n += 1
        return n

    def herd_daily_on(self, day: str = "") -> dict:
        """Поголів'я по групах на дату з БД (останній наявний день ≤ day).
        Повертає {day, values:{grp: heads}}."""
        day = (day or "").strip()[:10]
        with self._connect() as conn:
            self._ensure_herd_daily(conn)
            if day:
                row = conn.execute(
                    "SELECT MAX(day) AS d FROM herd_daily WHERE day <= ?",
                    (day,)).fetchone()
            else:
                row = conn.execute(
                    "SELECT MAX(day) AS d FROM herd_daily").fetchone()
            best = row["d"] if row else None
            if not best:
                return {"day": "", "values": {}}
            vals = {}
            for r in conn.execute(
                    "SELECT grp, heads FROM herd_daily WHERE day = ?", (best,)):
                vals[r["grp"]] = int(round(r["heads"] or 0))
            return {"day": best, "values": vals}

    def herd_cowdays(self, date_from: str = "", date_to: str = "",
                     grp: str = "d_cow") -> dict:
        """Голово-дні з управління стада за період: сума heads по днях для групи
        (за замовч. дійні d_cow). Повертає {cowdays, days, avg}."""
        f = (date_from or "").strip()[:10]
        t = (date_to or "").strip()[:10]
        with self._connect() as conn:
            self._ensure_herd_daily(conn)
            q = "SELECT day, SUM(heads) AS h FROM herd_daily WHERE grp = ?"
            args = [grp]
            if f:
                q += " AND day >= ?"; args.append(f)
            if t:
                q += " AND day <= ?"; args.append(t)
            q += " GROUP BY day"
            rows = conn.execute(q, args).fetchall()
        cowdays = sum(float(r["h"] or 0) for r in rows)
        days = len(rows)
        return {"cowdays": round(cowdays, 1), "days": days,
                "avg": round(cowdays / days, 1) if days else 0.0}

    def _ensure_feeding_leftover(self, conn: sqlite3.Connection) -> None:
        """Ручний залишок ЗМР (загально змішаного раціону) у годівниці по
        (секція/група, дата). У Profeed поле «Залишки, кг» часто 0 — тому
        оператор вносить фактичний залишок вручну; спожито = роздача − залишок."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feeding_leftover ("
            " section TEXT NOT NULL, day TEXT NOT NULL, qty_kg REAL NOT NULL DEFAULT 0,"
            " PRIMARY KEY(section, day))")
        cols = {r["name"] for r in conn.execute(
            "PRAGMA table_info(feeding_leftover)").fetchall()}
        if "updated_at" not in cols:      # мітка часу ручного введення (для «останнє перемагає»)
            conn.execute(
                "ALTER TABLE feeding_leftover ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''")
            # наявні ручні залишки — це найсвіжіша дія оператора: даємо їм поточний
            # час, щоб вони лишались чинними, поки файл не відредагують пізніше.
            conn.execute("UPDATE feeding_leftover SET updated_at=? WHERE updated_at=''",
                         (self._now(),))

    def set_feeding_leftover(self, section: str, day: str, qty_kg: float) -> dict[str, Any]:
        section = str(section or "").strip()
        day = str(day or "").strip()[:10]
        if not section or not day:
            raise ValueError("Потрібні секція і дата.")
        val = max(0.0, self._to_float(qty_kg or 0))
        with self._connect() as conn:
            self._ensure_feeding_leftover(conn)
            if val > 0:
                conn.execute(
                    "INSERT INTO feeding_leftover(section, day, qty_kg, updated_at) "
                    "VALUES(?,?,?,?) ON CONFLICT(section, day) DO UPDATE SET "
                    "qty_kg=excluded.qty_kg, updated_at=excluded.updated_at",
                    (section, day, val, self._now()))
            else:
                conn.execute("DELETE FROM feeding_leftover WHERE section=? AND day=?",
                             (section, day))
        return {"section": section, "day": day, "qty_kg": val}

    # Куди дівся залишок: назва групи-отримувача або «Утилізація» (втрата).
    FEED_DISPOSAL = "Утилізація"

    def _ensure_feeding_pool_dest(self, conn: sqlite3.Connection) -> None:
        """Розподіл ЗАГАЛЬНОГО пулу залишків за дату: залишки всіх груп
        збираються в пул, а він роздається на певні групи (додається до їх
        спожито) та в «Утилізація». Ключ — тільки дата (джерело не важливе)."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feeding_pool_dest ("
            " day TEXT NOT NULL, dest TEXT NOT NULL, qty REAL NOT NULL DEFAULT 0,"
            " PRIMARY KEY(day, dest))")

    def set_feeding_pool_dest(self, day: str, dests: list) -> dict[str, Any]:
        """Замінити розподіл пулу залишків на дату. dests — список {dest, qty};
        dest = назва групи або «Утилізація»."""
        day = str(day or "").strip()[:10]
        if not day:
            raise ValueError("Потрібна дата.")
        clean = {}
        for d in (dests or []):
            dn = str((d or {}).get("dest") or "").strip()
            q = max(0.0, self._to_float((d or {}).get("qty") or 0))
            if not dn or q <= 0:
                continue
            clean[dn] = clean.get(dn, 0.0) + q
        with self._connect() as conn:
            self._ensure_feeding_pool_dest(conn)
            conn.execute("DELETE FROM feeding_pool_dest WHERE day=?", (day,))
            for dn, q in clean.items():
                conn.execute(
                    "INSERT INTO feeding_pool_dest(day, dest, qty) VALUES(?,?,?)",
                    (day, dn, q))
        return {"day": day, "dests": [{"dest": k, "qty": v} for k, v in clean.items()]}

    def _ensure_feeding_leftover_dest(self, conn: sqlite3.Connection) -> None:
        """Розподіл залишку ЗМР: скільки і куди пішов залишок групи на дату —
        іншій групі (повторне згодовування) або в «Утилізація» (втрата)."""
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feeding_leftover_dest ("
            " section TEXT NOT NULL, day TEXT NOT NULL, dest TEXT NOT NULL,"
            " qty REAL NOT NULL DEFAULT 0, PRIMARY KEY(section, day, dest))")

    def set_feeding_leftover_dest(self, section: str, day: str,
                                  dests: list) -> dict[str, Any]:
        """Замінити розподіл залишку для (секція, дата). dests — список
        {dest, qty}; dest = назва групи або «Утилізація». Нульові — прибираємо."""
        section = str(section or "").strip()
        day = str(day or "").strip()[:10]
        if not section or not day:
            raise ValueError("Потрібні секція і дата.")
        clean = {}
        for d in (dests or []):
            dn = str((d or {}).get("dest") or "").strip()
            q = max(0.0, self._to_float((d or {}).get("qty") or 0))
            if not dn or q <= 0:
                continue
            if dn == section:
                raise ValueError("Не можна передати залишок тій самій групі.")
            clean[dn] = clean.get(dn, 0.0) + q
        with self._connect() as conn:
            self._ensure_feeding_leftover_dest(conn)
            conn.execute("DELETE FROM feeding_leftover_dest WHERE section=? AND day=?",
                         (section, day))
            for dn, q in clean.items():
                conn.execute(
                    "INSERT INTO feeding_leftover_dest(section, day, dest, qty) "
                    "VALUES(?,?,?,?)", (section, day, dn, q))
        return {"section": section, "day": day,
                "dests": [{"dest": k, "qty": v} for k, v in clean.items()]}

    def _feed_cost_map(self, conn: sqlite3.Connection, category: str) -> dict[str, float]:
        """Середньозважена собівартість БЕЗ ПДВ за кг для інгредієнтів складу
        гілки: ключі — код товару та назва (нижній регістр). Ціна без ПДВ —
        price_in_no_vat, з відкатом до price_in/(1+ставка) чи price_in.

        Вага — кількість ПРИХОДУ (IN-рухи на партію), а не поточний залишок,
        щоб ціна корму НЕ мінялась після списань (списання зменшує залишок і
        додає борг-партії, тож сума руху лишається стабільною)."""
        no_vat = ("(CASE WHEN b.price_in_no_vat > 0 THEN b.price_in_no_vat "
                  "WHEN b.vat_rate > 0 THEN b.price_in / (1 + b.vat_rate / 100.0) "
                  "ELSE b.price_in END)")
        # 1) стабільна ціна — за кількістю приходу (IN-рухи по кожній партії)
        rows = conn.execute(
            "SELECT p.code AS code, p.name AS name, "
            "       COALESCE(SUM(inm.rq),0) AS q, "
            "       COALESCE(SUM(inm.rq*" + no_vat + "),0) AS v "
            "FROM products p "
            "JOIN stock_batches b ON b.product_id=p.id "
            "JOIN (SELECT batch_id, SUM(qty) AS rq FROM stock_moves "
            "      WHERE move_type='IN' AND batch_id IS NOT NULL GROUP BY batch_id) inm "
            "     ON inm.batch_id=b.id "
            "WHERE p.is_active=1 AND p.category=? GROUP BY p.id",
            (category,)).fetchall()
        m: dict[str, float] = {}
        seen = set()
        for r in rows:
            q = r["q"] or 0
            cost = (r["v"] / q) if q else 0.0
            if not cost:
                continue
            seen.add((r["code"], r["name"]))
            if r["code"]:
                m["c:" + str(r["code"]).strip()] = cost
            if r["name"]:
                m["n:" + str(r["name"]).strip().lower()] = cost
        # 2) відкат для товарів без приходів (напр. старі дані) — поточний залишок
        rows2 = conn.execute(
            "SELECT p.code AS code, p.name AS name, "
            "       COALESCE(SUM(b.qty),0) AS q, "
            "       COALESCE(SUM(b.qty*" + no_vat + "),0) AS v "
            "FROM products p LEFT JOIN stock_batches b ON b.product_id=p.id "
            "WHERE p.is_active=1 AND p.category=? GROUP BY p.id",
            (category,)).fetchall()
        for r in rows2:
            if (r["code"], r["name"]) in seen:
                continue
            q = r["q"] or 0
            cost = (r["v"] / q) if q else 0.0
            if not cost:
                continue
            if r["code"]:
                m.setdefault("c:" + str(r["code"]).strip(), cost)
            if r["name"]:
                m.setdefault("n:" + str(r["name"]).strip().lower(), cost)
        return m

    @staticmethod
    def _ratio_acc(fact, plan):
        """Точність = менше/більше × 100 (план 50, факт 55 → 90.9%).
        Завжди ≤ 100%. None, якщо плану немає."""
        fact = float(fact or 0)
        plan = float(plan or 0)
        hi = max(fact, plan)
        if plan <= 0 or hi <= 0:
            return None
        return min(fact, plan) / hi * 100

    def feeding_day(self, day: str = "") -> dict[str, Any]:
        """Роздачі за конкретний день: кожен заміс (src_key) секції з
        привʼязкою до категорії/підкатегорії стада на цю дату. № роздачі —
        порядок замісів секції за номером документа ГД (він зростає
        хронологічно). Порожня дата → останній день з даними.
        Той самий контракт віддає портал (/api/feedday) — дизайн 1:1."""
        with self._connect() as conn:
            if not day:
                r = conn.execute("SELECT MAX(op_date) FROM feeding_events").fetchone()
                day = (r[0] or "") if r else ""
            if not day:
                return {"date": "", "n_max": 0, "rows": []}
            ev = {r["src_key"]: dict(r) for r in conn.execute(
                "SELECT src_key, group_label, ration, plan_loaded, kg_loaded,"
                "       plan_distributed, kg_distributed, headcount, file_ts, mixer"
                "  FROM feeding_events WHERE op_date = ?", (day,))}
            ings_by_key: dict[str, list] = {}
            if ev:
                qs = ",".join("?" * len(ev))
                for ir in conn.execute(
                        "SELECT src_key, name, code, plan, kg FROM feeding_event_ings "
                        "WHERE src_key IN (%s)" % qs, list(ev.keys())):
                    ings_by_key.setdefault(ir["src_key"], []).append(dict(ir))
            # Залишки кормів за день + розподіл (використання в групи / утилізація)
            self._ensure_feeding_leftover(conn)
            self._ensure_feeding_pool_dest(conn)
            self._ensure_feeding_leftover_dest(conn)
            lo_total = (conn.execute(
                "SELECT COALESCE(SUM(qty_kg), 0) FROM feeding_leftover WHERE day = ?",
                (day,)).fetchone()[0]) or 0
            dest_agg: dict[str, float] = {}
            for dr in conn.execute(
                    "SELECT dest, SUM(qty) AS q FROM feeding_leftover_dest "
                    "WHERE day = ? GROUP BY dest", (day,)):
                dest_agg[dr["dest"]] = dest_agg.get(dr["dest"], 0) + (dr["q"] or 0)
            for dr in conn.execute(
                    "SELECT dest, SUM(qty) AS q FROM feeding_pool_dest "
                    "WHERE day = ? GROUP BY dest", (day,)):
                dest_agg[dr["dest"]] = dest_agg.get(dr["dest"], 0) + (dr["q"] or 0)
            lo_util = round(dest_agg.get("Утилізація", 0), 1)
            lo_used = round(sum(v for k, v in dest_agg.items()
                                if k != "Утилізація"), 1)
            leftover = {"total": round(lo_total, 1), "used": lo_used, "util": lo_util,
                        "dests": [{"dest": k, "qty": round(v, 1)}
                                  for k, v in sorted(dest_agg.items()) if abs(v) > 1e-4]}
            # Корм з початку місяця: сума фактичних кг по кожному корму з 1-го
            # числа місяця обраного дня до цього дня включно.
            month_start = (day[:7] + "-01") if len(day) >= 7 else day
            month_by_feed: dict[str, float] = {}
            for mr in conn.execute(
                    "SELECT i.name AS name, SUM(i.kg) AS kg "
                    "FROM feeding_event_ings i "
                    "JOIN feeding_events e ON e.src_key = i.src_key "
                    "WHERE e.op_date >= ? AND e.op_date <= ? GROUP BY i.name",
                    (month_start, day)):
                month_by_feed[(mr["name"] or "—")] = round(mr["kg"] or 0, 1)
            # Молоко (по заліку) — за день і з початку місяця (з milk_daily).
            milk_day = 0.0
            milk_month = 0.0
            try:
                mrow = conn.execute(
                    "SELECT kg FROM milk_daily WHERE day = ?", (day,)).fetchone()
                milk_day = round(((mrow[0] or 0) if mrow else 0), 1)
                mm = conn.execute(
                    "SELECT COALESCE(SUM(kg), 0) FROM milk_daily "
                    "WHERE day >= ? AND day <= ?", (month_start, day)).fetchone()
                milk_month = round(((mm[0] or 0) if mm else 0), 1)
            except Exception:  # noqa: BLE001 — таблиці ще нема / порожня
                pass
            per = [dict(r) for r in conn.execute(
                "SELECT p.profeed_group, p.herd_kind, p.subgroup, p.headcount,"
                "       p.eat_coef, p.date_from, p.date_to"
                "  FROM herd_section_periods p"
                "  JOIN herd_groups g ON g.id = p.section_id"
                " WHERE g.is_active = 1")]
        kind = {"cow": "Корови", "young": "Молодняк"}

        def classify(label: str) -> tuple[str, str]:
            best, bw = None, -1.0
            for p in per:
                if (p.get("profeed_group") or "") != label:
                    continue
                if p.get("date_from") and str(p["date_from"])[:10] > day:
                    continue
                if p.get("date_to") and str(p["date_to"])[:10] < day:
                    continue
                w = (p.get("headcount") or 0) * (p.get("eat_coef") or 1)
                if w > bw:
                    bw, best = w, p
            if not best:
                return "Без категорії", "—"
            return (kind.get(best.get("herd_kind") or "", "Без категорії"),
                    best.get("subgroup") or "—")

        def doc_no(key: str) -> int:
            digits = "".join(ch for ch in str(key or "") if ch.isdigit())
            return int(digits) if digits else 0

        by_sec: dict[str, list] = {}
        for e in ev.values():
            by_sec.setdefault(e["group_label"], []).append(e)
        rows: list[dict[str, Any]] = []
        for label, lst in by_sec.items():
            lst.sort(key=lambda e: (doc_no(e.get("src_key")),
                                    str(e.get("file_ts") or "")))
            cat, sub = classify(label)
            for i, e in enumerate(lst):
                plan = e.get("plan_loaded") or 0
                fact = e.get("kg_loaded") or 0
                acc = (round(min(fact, plan) / max(fact, plan) * 100, 1)
                       if plan > 0 and fact > 0 else None)
                ings = []
                for it in ings_by_key.get(e.get("src_key"), []):
                    p = it.get("plan") or 0
                    f = it.get("kg") or 0
                    ia = (round(min(f, p) / max(f, p) * 100, 1)
                          if p > 0 and f > 0 else None)
                    ings.append({"name": it.get("name") or "—",
                                 "plan": round(p, 1), "fact": round(f, 1),
                                 "dev": round(f - p, 1), "acc": ia})
                rows.append({
                    "n": i + 1, "section": label,
                    "mixer": e.get("mixer") or "",
                    "ration": e.get("ration") or "",
                    "category": cat, "subgroup": sub,
                    "plan": round(plan, 1), "fact": round(fact, 1),
                    "dev": round(fact - plan, 1), "acc": acc,
                    "dist": round(e.get("kg_distributed") or 0, 1),
                    "plan_dist": round(e.get("plan_distributed") or 0, 1),
                    "heads": e.get("headcount"), "ings": ings,
                    "_dn": doc_no(e.get("src_key")),
                })
        # Глобальний № роздачі за день = порядок замісу за номером ГД (src_key)
        # серед усіх замісів дня. Так матриця має наскрізну нумерацію 1..N,
        # де одна секція може зʼявитись двічі (напр. роздачі 3 і 10 — Група-3).
        for seq, r in enumerate(sorted(rows, key=lambda x: x.get("_dn", 0)), 1):
            r["seq"] = seq
        for r in rows:
            r.pop("_dn", None)
        rows.sort(key=lambda r: r["seq"])
        return {"date": day,
                "n_max": max((r["n"] for r in rows), default=0),
                "seq_max": len(rows), "rows": rows,
                "month_from": month_start, "month_by_feed": month_by_feed,
                "milk_day": milk_day, "milk_month": milk_month,
                "leftover": leftover}

    def feeding_last_day(self) -> str:
        """Остання дата, за якою РЕАЛЬНО є рух годівлі — з того самого джерела,
        що й feeding_tree (scan теки Profeed + DB-частини), щоб дефолт «День»
        не потрапляв на порожню дату. Fallback — feeding_events. '' якщо порожньо."""
        try:
            folder = self.get_setting("feed_profeed_dir", "").strip()
            if folder:
                scan = self.scan_feeding_movements(folder)
                parts = scan.get("parts") or {}
                days = [str((v or {}).get("date") or "")[:10] for v in parts.values()]
                days = [d for d in days if d]
                if days:
                    return max(days)
        except Exception:
            pass
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT MAX(op_date) FROM feeding_events "
                    "WHERE op_date != ''").fetchone()
            return (row[0] or "")[:10] if row else ""
        except Exception:
            return ""

    def feeding_tree(self, category: str = "feed", date_from: str = "",
                     date_to: str = "") -> dict[str, Any]:
        """Ієрархія руху годівлі: Секція → Дата → метрики + інгредієнти.
        Ціни — середня собівартість без ПДВ зі складу гілки; молоко — ручне
        (таблиця feeding_milk), конверсія рахується, коли молоко внесене."""
        date_from = (date_from or "").strip()[:10]
        date_to = (date_to or "").strip()[:10]
        folder = self.get_setting("feed_profeed_dir", "").strip()
        if not folder:
            return {"sections": [], "note": "Не вказано теку звітів Profeed (сторінка «Виробництво КК»).",
                    "date_from": date_from, "date_to": date_to}
        scan = self.scan_feeding_movements(folder)
        if scan.get("error"):
            return {"sections": [], "error": scan["error"],
                    "date_from": date_from, "date_to": date_to}
        # ціни + ручне молоко + вже списані заміси (ГД-№партії)
        no_vat_b = ("(CASE WHEN b.price_in_no_vat > 0 THEN b.price_in_no_vat "
                    "WHEN b.vat_rate > 0 THEN b.price_in / (1 + b.vat_rate / 100.0) "
                    "ELSE b.price_in END)")
        with self._connect() as conn:
            cost = self._feed_cost_map(conn, category)
            self._ensure_feeding_milk(conn)
            milk_rows = conn.execute("SELECT section, day, milk_kg FROM feeding_milk").fetchall()
            self._ensure_feeding_leftover(conn)
            left_rows = conn.execute(
                "SELECT section, day, qty_kg, updated_at FROM feeding_leftover").fetchall()
            self._ensure_feeding_pool_dest(conn)
            pool_rows = conn.execute(
                "SELECT day, dest, qty FROM feeding_pool_dest").fetchall()
            done = {r[0][3:] for r in conn.execute(
                "SELECT DISTINCT sale_no FROM stock_moves WHERE sale_no LIKE 'ГД-%'").fetchall()}
            # FIFO-черга приходів на кожен товар (для собівартості по днях):
            # (кількість приходу, ціна без ПДВ) у порядку дат надходження.
            fifo_supply: dict[int, list] = {}
            for r in conn.execute(
                    "SELECT b.product_id AS pid, m.qty AS q, " + no_vat_b + " AS pnv "
                    "FROM stock_moves m JOIN stock_batches b ON b.id=m.batch_id "
                    "JOIN products p ON p.id=b.product_id "
                    "WHERE m.move_type='IN' AND m.batch_id IS NOT NULL AND p.category=? "
                    "ORDER BY COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)), "
                    "m.id", (category,)).fetchall():
                fifo_supply.setdefault(r["pid"], []).append(
                    [float(r["q"] or 0), float(r["pnv"] or 0)])
            # резолвер інгредієнт → id товару (за кодом/назвою)
            pid_by_code: dict[str, int] = {}
            pid_by_name: dict[str, int] = {}
            for r in conn.execute(
                    "SELECT id, code, name FROM products "
                    "WHERE category=? AND is_active=1", (category,)).fetchall():
                if r["code"]:
                    pid_by_code[str(r["code"]).strip()] = r["id"]
                # Python .lower() (а не SQL lower) — щоб кирилиця теж зводилась
                nm = str(r["name"] or "").strip().lower()
                if nm:
                    pid_by_name[nm] = r["id"]
        milk = {(r["section"], r["day"]): r["milk_kg"] for r in milk_rows}
        # ручний залишок ЗМР по (секція, дата): кількість + час введення.
        # Правило «останнє редагування перемагає» — порівнюємо з часом файлу.
        manual_left = {(r["section"], r["day"]):
                       (float(r["qty_kg"] or 0),
                        (r["updated_at"] if "updated_at" in r.keys() else "") or "")
                       for r in left_rows}

        # агрегуємо роздачі по (секція, дата)
        agg: dict[tuple, dict] = {}
        for part, a in scan["parts"].items():
            if not a["group"] or not a["date"]:
                continue
            if date_from and a["date"] < date_from:
                continue
            if date_to and a["date"] > date_to:
                continue
            k = (a["group"], a["date"])
            g = agg.get(k)
            if g is None:
                g = agg[k] = {"section": a["group"], "date": a["date"],
                              "plan_loaded": 0.0, "loaded": 0.0, "dry_loaded": 0.0,
                              "plan_distributed": 0.0, "distributed": 0.0,
                              "dry_distributed": 0.0, "leftover": 0.0,
                              "heads": 0.0, "feedings": 0, "ration": set(), "ing": {},
                              "parts": set(), "parts_done": set(), "file_ts": ""}
            ft = a.get("_file_ts", "") or ""
            if ft > g["file_ts"]:
                g["file_ts"] = ft            # найсвіжіший час файлу-джерела секції/дня
            g["parts"].add(part)
            if part in done:
                g["parts_done"].add(part)
            g["plan_loaded"] += a["plan_loaded"]
            g["loaded"] += a["loaded"]
            g["dry_loaded"] += a["dry_loaded"]
            g["plan_distributed"] += a["plan_distributed"]
            g["distributed"] += a["distributed"]
            g["dry_distributed"] += a["dry_distributed"]
            # Залишок ЗМР по секції за день — СУМА залишків усіх роздач цієї
            # секції (дві роздачі із залишками 43 і 43 → 86).
            g["leftover"] += a["leftover"]
            g["heads"] = max(g["heads"], a["heads"])
            g["feedings"] += 1
            if a["ration"]:
                g["ration"].add(a["ration"])
            for key, it in a["ing"].items():
                agg_it = g["ing"].setdefault(
                    key, {"name": it["name"], "code": it["code"],
                          "plan": 0.0, "kg": 0.0, "dry": 0.0})
                agg_it["plan"] += it["plan"]
                agg_it["kg"] += it["kg"]
                agg_it["dry"] += it["dry"]

        # «Останнє редагування перемагає»: ручний залишок застосовуємо лише коли
        # він новіший за час файлу-джерела (або файлу вже немає). Інакше лишаємо
        # значення з файлу. Обмежуємо роздачею, щоб спожито не стало від'ємним.
        for k, g in agg.items():
            mv = manual_left.get(k)
            if mv is not None and mv[1] >= (g.get("file_ts") or ""):
                g["leftover"] = min(mv[0], g["distributed"])

        # Залишки груп збираються у ПУЛ за дату, далі пул роздається на певні
        # групи (додається до їх спожито) і в «Утилізація». Суха речовина
        # перенесеного корму — за середньою пропорцією пулу (СР/кг).
        pool_kg: dict[str, float] = {}          # дата → сумарний залишок (пул)
        pool_dry: dict[str, float] = {}         # дата → сумарна СР залишку
        for k, g in agg.items():
            lo = g["leftover"]
            if lo <= 0:
                continue
            day = k[1]
            pool_kg[day] = pool_kg.get(day, 0.0) + lo
            ratio = (g["dry_distributed"] / g["distributed"]
                     if g["distributed"] else 0.0)
            pool_dry[day] = pool_dry.get(day, 0.0) + lo * ratio

        refed_in: dict[tuple, float] = {}       # (секція,дата) → кг отримано з пулу
        refed_in_dry: dict[tuple, float] = {}   # (секція,дата) → СР отримано
        disposal_day: dict[str, float] = {}     # дата → кг в утилізацію
        pool_dest_by_day: dict[str, list] = {}  # дата → [{dest, qty}]
        for r in pool_rows:
            day = r["day"]
            # Розподіл пулу враховуємо ЛИШЕ в межах періоду звіту — щоб він
            # звірявся з тим самим пулом (pool_kg теж за період). Інакше розподіл
            # за дату поза періодом порівнюється з порожнім пулом → фальшива
            # «перероздача» у банері «До уваги».
            if (date_from and day < date_from) or (date_to and day > date_to):
                continue
            dst = str(r["dest"]).strip()
            qty = float(r["qty"] or 0)
            if qty <= 0:
                continue
            pool_dest_by_day.setdefault(day, []).append({"dest": dst, "qty": round(qty, 1)})
            if dst == self.FEED_DISPOSAL:
                disposal_day[day] = disposal_day.get(day, 0.0) + qty
                continue
            tgt = (dst, day)
            refed_in[tgt] = refed_in.get(tgt, 0.0) + qty
            pr = (pool_dry.get(day, 0.0) / pool_kg[day]) if pool_kg.get(day) else 0.0
            refed_in_dry[tgt] = refed_in_dry.get(tgt, 0.0) + qty * pr

        def price_of(it):
            c = 0.0
            if it["code"]:
                c = cost.get("c:" + str(it["code"]).strip(), 0.0)
            if not c and it["name"]:
                c = cost.get("n:" + str(it["name"]).strip().lower(), 0.0)
            return c

        def resolve_pid(it):
            code = str(it.get("code") or "").strip()
            if code and code in pid_by_code:
                return pid_by_code[code]
            nm = str(it.get("name") or "").strip().lower()
            return pid_by_name.get(nm)

        # FIFO-собівартість без ПДВ на кожен (секція, дата, корм): проходимо
        # споживання у хронологічному порядку й тягнемо з черги приходів товару
        # (найстаріші партії — першими). Нестача → за останньою ціною (борг).
        #
        # ВАЖЛИВО: чергу проганяємо по ВСІЙ історії годівлі (усі дати зі звітів),
        # а не лише по відфільтрованому періоду — інакше при фільтрі «7 днів»
        # черга не «прокручена» попереднім споживанням і свіжі дні беруть стару
        # ціну. Показуємо потім лише відфільтровані дні, але собівартість у них
        # уже правильна.
        fifo_cost: dict[tuple, float] = {}
        last_price: dict[int, float] = {}
        full_ing: dict[tuple, dict] = {}
        for _part, _a in scan["parts"].items():
            if not _a.get("group") or not _a.get("date"):
                continue
            for key, it in _a["ing"].items():
                e = full_ing.setdefault(
                    (_a["group"], _a["date"], key),
                    {"name": it["name"], "code": it["code"], "kg": 0.0})
                e["kg"] += it.get("kg") or 0
        events = [(dt_k, sec_k, key, it)
                  for (sec_k, dt_k, key), it in full_ing.items()]
        events.sort(key=lambda e: (e[0], e[1], str(e[2])))
        for dt_k, sec_k, key, it in events:
            kg = float(it.get("kg") or 0)
            pid = resolve_pid(it)
            q = fifo_supply.get(pid) if pid is not None else None
            cost_nv = 0.0
            if q:
                need = kg
                while need > 1e-9 and q:
                    lot = q[0]
                    use = min(need, lot[0])
                    cost_nv += use * lot[1]
                    last_price[pid] = lot[1]
                    lot[0] -= use
                    need = round(need - use, 6)
                    if lot[0] <= 1e-9:
                        q.pop(0)
                if need > 1e-9:                       # нестача — за останньою/сер. ціною
                    lp = last_price.get(pid) or price_of(it)
                    cost_nv += need * lp
            else:
                cost_nv = kg * price_of(it)           # відкат: середня ціна
            fifo_cost[(sec_k, dt_k, key)] = cost_nv

        # ── Гроші йдуть за кормом ────────────────────────────────────────
        # Вартість завантаженого раціону групи (сума FIFO по інгредієнтах).
        # Залишок, який група віддала в пул, забирає з собою пропорційну
        # вартість; одержувач отримує кг + ₴; на утилізацію — збиток.
        # База = ration_sum (сума ОКРУГЛЕНИХ по інгредієнту сум), щоб «Завантажено»
        # = «Спожито» + перенос + утилізація сходились до копійки.
        group_cost_raw: dict[tuple, float] = {}
        for _k, _g in agg.items():
            group_cost_raw[_k] = sum(
                round(fifo_cost.get((_g["section"], _g["date"], key), 0.0), 2)
                for key in _g["ing"])
        left_cost: dict[tuple, float] = {}       # (секція,дата) → ₴ відданого залишку
        pool_cost: dict[str, float] = {}         # дата → ₴ пулу залишків
        for _k, _g in agg.items():
            lo = _g["leftover"]
            # база — завантажені кг (саме їм відповідає вартість раціону),
            # щоб ціна залишку за кг = собівартість міксу за кг.
            loaded_kg = sum((it.get("kg") or 0) for it in _g["ing"].values())
            if lo <= 0 or loaded_kg <= 0:
                continue
            lc = group_cost_raw.get(_k, 0.0) * (min(lo, loaded_kg) / loaded_kg)
            left_cost[_k] = lc
            pool_cost[_k[1]] = pool_cost.get(_k[1], 0.0) + lc
        refed_in_cost: dict[tuple, float] = {}   # (секція,дата) → ₴ з пулу
        disposal_cost: dict[str, float] = {}     # дата → ₴ в утилізацію (збиток)
        for r in pool_rows:
            day = r["day"]
            if (date_from and day < date_from) or (date_to and day > date_to):
                continue
            qty = float(r["qty"] or 0)
            if qty <= 0:
                continue
            per_kg = (pool_cost.get(day, 0.0) / pool_kg[day]) if pool_kg.get(day) else 0.0
            dst = str(r["dest"]).strip()
            if dst == self.FEED_DISPOSAL:
                disposal_cost[day] = disposal_cost.get(day, 0.0) + qty * per_kg
            else:
                tgt = (dst, day)
                refed_in_cost[tgt] = refed_in_cost.get(tgt, 0.0) + qty * per_kg

        def day_obj(g):
            heads = g["heads"]
            distributed = g["distributed"]
            leftover = g["leftover"]
            k = (g["section"], g["date"])
            r_in = refed_in.get(k, 0.0)          # отримано з пулу залишків
            # Гроші за кормом: спожито ₴ = вартість завантаженого − віддане в
            # пул + отримане з пулу.
            g_cost = group_cost_raw.get(k, 0.0)
            lc = left_cost.get(k, 0.0)
            ri_cost = refed_in_cost.get(k, 0.0)
            consumed_sum = g_cost - lc + ri_cost
            # Спожито і СР рахуємо від ЗАВАНТАЖЕНОГО (не від роздано).
            loaded_kg = sum((it.get("kg") or 0) for it in g["ing"].values())
            dry_loaded = sum((it.get("dry") or 0) for it in g["ing"].values())
            # Спожито групою = (завантажено − залишок) + отримане з пулу залишків.
            base_consumed = max(0.0, loaded_kg - leftover)
            consumed = base_consumed + r_in
            # СР спожито ~ пропорційно до спожитого + СР перенесеного корму
            dry_consumed = (dry_loaded * (base_consumed / loaded_kg)
                            if loaded_kg else 0.0) + refed_in_dry.get(k, 0.0)
            plan_dist = g["plan_distributed"]
            acc_dist = self._ratio_acc(distributed, plan_dist)
            m_kg = milk.get((g["section"], g["date"]))
            conv = (m_kg / dry_consumed) if (m_kg and dry_consumed) else None
            ings = []
            r_sum = 0.0
            acc_vals = []   # точності по кожному корму → усереднюємо
            for key, it in sorted(g["ing"].items(), key=lambda kv: -kv[1]["kg"]):
                # Собівартість FIFO цього корму в цей день (реальні партії).
                cost_nv = fifo_cost.get((g["section"], g["date"], key), 0.0)
                kg = it["kg"]
                pr = (cost_nv / kg) if (cost_nv and kg) else 0.0
                # округлюємо суму рядка й ЇЇ ж додаємо до підсумку, щоб сума по
                # інгредієнтах точно = ration_sum = підсумкам інших таблиць
                s = round(cost_nv, 2) if cost_nv else 0.0
                r_sum += s
                i_acc = self._ratio_acc(it["kg"], it["plan"])
                if i_acc is not None:
                    acc_vals.append(i_acc)
                ings.append({"name": it["name"], "code": it["code"],
                             # кількості — 4 знаки після коми
                             "plan": round(it["plan"], 4),
                             "kg": round(it["kg"], 4), "dry": round(it["dry"], 4),
                             "dev": round(it["kg"] - it["plan"], 4),
                             "acc": round(i_acc, 1) if i_acc is not None else None,
                             # ціна без ПДВ (FIFO) — 4 знаки після коми
                             "price": round(pr, 4) if pr else None,
                             "sum": s if pr else None})
            # Точність замісу — середнє з точностей окремих кормів (щоб відхилення
            # по інгредієнтах не гасилися у підсумку план/факт).
            accuracy = (sum(acc_vals) / len(acc_vals)) if acc_vals else None
            # Завантаження = СУМА округлених інгредієнтів (а не окреме округлення
            # сирого підсумку) — щоб «Рух по секціях», «По категоріях» і «По
            # кормах» давали однаковий план/факт (без розбіжності округлення).
            sum_plan = round(sum(i["plan"] for i in ings), 4)
            sum_kg = round(sum(i["kg"] for i in ings), 4)
            sum_dry = round(sum(i["dry"] for i in ings), 4)
            return {
                "date": g["date"], "section": g["section"], "feedings": g["feedings"],
                "heads": round(heads, 0),
                "plan_loaded": sum_plan,
                "loaded": sum_kg,
                "plan_distributed": round(plan_dist, 1),
                "distributed": round(distributed, 1),
                "dev": round(distributed - plan_dist, 1),
                "dev_load": round(sum_kg - sum_plan, 4),
                "accuracy": round(accuracy, 1) if accuracy is not None else None,
                "acc_dist": round(acc_dist, 1) if acc_dist is not None else None,
                "dry": sum_dry,
                "leftover": round(leftover, 1),
                "leftover_pct": round(leftover / distributed * 100, 1) if distributed else None,
                # скільки корму група отримала з пулу залишків (додається до спожито)
                "refed_in": round(r_in, 1),
                "consumed": round(consumed, 1),
                "consumed_head": round(consumed / heads, 1) if heads else None,
                "kg_head": round(distributed / heads, 1) if heads else None,
                "dry_head": round(sum_dry / heads, 1) if heads else None,
                "dry_consumed": round(dry_consumed, 1),
                "milk": round(m_kg, 1) if m_kg else None,
                "conv": round(conv, 2) if conv is not None else None,
                "ration": ", ".join(sorted(g["ration"])),
                "ration_sum": round(r_sum, 2) if r_sum else None,
                # гроші йдуть за кормом (перенос залишку)
                "consumed_sum": round(consumed_sum, 2) if consumed_sum else None,
                "refed_in_sum": round(ri_cost, 2) if ri_cost else None,
                "leftover_sum": round(lc, 2) if lc else None,
                "ingredients": ings,
                # статус фіксації списання: усі заміси дня списані / частково / ні
                "written_off": ("done" if g["parts"] and g["parts"] <= g["parts_done"]
                                else ("partial" if g["parts_done"] else "no")),
            }

        # групуємо дні по секціях
        by_sec: dict[str, list] = {}
        for g in agg.values():
            by_sec.setdefault(g["section"], []).append(day_obj(g))
        sections = []
        for sec in sorted(by_sec.keys()):
            days = sorted(by_sec[sec], key=lambda d: d["date"], reverse=True)
            s_loaded = sum(d["loaded"] for d in days)
            s_plan = sum(d["plan_loaded"] for d in days)
            s_plan_dist = sum(d["plan_distributed"] for d in days)
            s_dist = sum(d["distributed"] for d in days)
            s_dry = sum(d["dry"] for d in days)
            s_left = sum(d["leftover"] for d in days)
            s_cons = sum(d["consumed"] for d in days)
            s_refed_in = sum(d.get("refed_in") or 0 for d in days)
            s_hd = sum((d["heads"] or 0) for d in days)  # голово-дні
            s_milk = sum((d["milk"] or 0) for d in days)
            # СР спожито = Σ по днях (уже з урахуванням перенесеного корму);
            # СР розподілена — по агрегату секції.
            s_dry_consumed = sum((d.get("dry_consumed") or 0) for d in days)
            s_dry_dist = 0.0
            for g in agg.values():
                if g["section"] != sec:
                    continue
                s_dry_dist += g["dry_distributed"]
            s_sum = sum((d["ration_sum"] or 0) for d in days)
            s_consumed_sum = sum((d.get("consumed_sum") or 0) for d in days)
            s_refed_in_sum = sum((d.get("refed_in_sum") or 0) for d in days)
            s_leftover_sum = sum((d.get("leftover_sum") or 0) for d in days)
            conv = (s_milk / s_dry_consumed) if (s_milk and s_dry_consumed) else None
            sections.append({
                "section": sec, "days_count": len(days),
                "heads_days": round(s_hd, 0),
                "plan_loaded": round(s_plan, 4), "loaded": round(s_loaded, 4),
                "dev_load": round(s_loaded - s_plan, 4),
                "plan_distributed": round(s_plan_dist, 1), "distributed": round(s_dist, 1),
                "dev": round(s_dist - s_plan_dist, 1),
                "accuracy": (lambda v: round(sum(v) / len(v), 1) if v else None)(
                    [d["accuracy"] for d in days if d["accuracy"] is not None]),
                "acc_dist": (lambda a: round(a, 1) if a is not None else None)(
                    self._ratio_acc(s_dist, s_plan_dist)),
                "dry": round(s_dry, 4), "leftover": round(s_left, 1),
                "leftover_pct": round(s_left / s_dist * 100, 1) if s_dist else None,
                "refed_in": round(s_refed_in, 1),
                "consumed": round(s_cons, 1),
                "consumed_head": round(s_cons / s_hd, 1) if s_hd else None,
                "kg_head": round(s_dist / s_hd, 1) if s_hd else None,
                "dry_head": round(s_dry_dist / s_hd, 1) if s_hd else None,
                "heads_last": days[0]["heads"] if days else None,
                "milk": round(s_milk, 1) if s_milk else None,
                "milk_head": round(s_milk / s_hd, 1) if s_hd and s_milk else None,
                "conv": round(conv, 2) if conv is not None else None,
                "sum": round(s_sum, 2) if s_sum else None,
                "consumed_sum": round(s_consumed_sum, 2) if s_consumed_sum else None,
                "refed_in_sum": round(s_refed_in_sum, 2) if s_refed_in_sum else None,
                "leftover_sum": round(s_leftover_sum, 2) if s_leftover_sum else None,
                "written_off": ("done" if days and all(d["written_off"] == "done" for d in days)
                                else ("partial" if any(d["written_off"] != "no" for d in days)
                                      else "no")),
                "days": days,
            })
        # Канонічні підсумки ₴ (сума ОКРУГЛЕНИХ денних значень) — щоб «Разом»
        # в усіх звітах збігався до копійки незалежно від групування.
        _all_days = [d for s in sections for d in s["days"]]
        total_loaded_sum = round(sum((d.get("ration_sum") or 0) for d in _all_days), 2)
        # Канонічні підсумки перекидань пулу: округлюємо СУМУ СИРИХ значень (а не
        # суму вже округлених по секціях) — щоб «Разом» не накопичував копійчаний
        # дрейф. При збалансованому пулі «віддано» = «отримано» точно.
        # Сумуємо ОКРУГЛЕНІ денні значення (а не сирі left_cost/refed_in_cost) —
        # так канонічний «Разом» = сумі рядків по категоріях/секціях (ті теж
        # сумують округлені денні), тож рядок Корови = Разом до копійки.
        total_leftover_sum = round(
            sum((d.get("leftover_sum") or 0) for d in _all_days), 2)   # віддано в пул
        total_refed_in_sum = round(
            sum((d.get("refed_in_sum") or 0) for d in _all_days), 2)   # отримано з пулу
        # Утилізація (збиток) = віддано в пул − повернуто з пулу (та сама облікова
        # тотожність, що й «Спожито») → «Утилізація» і «перенос» скрізь однакові.
        _disposal_sum = round(total_leftover_sum - total_refed_in_sum, 2)
        # якщо фактично утилізовано ~0 кг (весь залишок перенесено), обнуляємо й
        # копійку від округлення FIFO-цін, щоб не показувати «Утилізація 0,01 ₴»
        if sum(disposal_day.values()) <= 0.05:
            _disposal_sum = 0.0
        # Спожито = завантажено − віддано + отримано (облікова тотожність; враховує
        # і утилізацію, і нерозподілений залишок). Так base «Спожито ₴» + бейджі
        # ± сходяться до копійки, і всі 4 таблиці дають однаковий підсумок.
        total_consumed_sum = round(
            total_loaded_sum - total_leftover_sum + total_refed_in_sum, 2)
        return {"sections": sections, "date_from": date_from, "date_to": date_to,
                # розподіл пулу залишків по датах (для панелі введення)
                "pool_dest": pool_dest_by_day,
                "pool_kg": {d: round(v, 1) for d, v in pool_kg.items()},
                # канонічні підсумки ₴
                "total_loaded_sum": total_loaded_sum,
                "total_consumed_sum": total_consumed_sum,
                "total_leftover_sum": total_leftover_sum,
                "total_refed_in_sum": total_refed_in_sum,
                # утилізація: кг та збиток ₴ (по днях і всього за період)
                "disposal_by_day": {d: round(v, 1) for d, v in disposal_day.items()},
                "disposal_sum_by_day": {d: round(v, 2) for d, v in disposal_cost.items()},
                "disposal_kg": round(sum(disposal_day.values()), 1),
                "disposal_sum": _disposal_sum}

    def feed_usage_by_category(self, category: str = "feed", date_from: str = "",
                               date_to: str = "",
                               milk_by_day: dict = None) -> dict[str, Any]:
        """Використання кормів по категоріях стада (Корови/Молодняк) і
        підкатегоріях. Кожен день роздачі відносимо до Категорії/Підкатегорії
        секції (за періодами з налаштувань секцій) і зводимо: план/факт
        завантаження й роздачі, залишки, споживання, суху речовину.

        Молоко береться з модуля «Виробництво молока» (денний надій
        milk_by_day = {дата: кг}) і розноситься на ЛАКТУЮЧІ секції (Корови,
        окрім сухостою) пропорційно спожитій сухій речовині; конверсія
        = молоко / спожита СР."""
        import re as _re
        tree = self.feeding_tree(category, date_from, date_to)
        if tree.get("note") or tree.get("error"):
            return {"categories": [], "note": tree.get("note"), "error": tree.get("error"),
                    "date_from": tree.get("date_from", ""), "date_to": tree.get("date_to", "")}
        KIND = {"cow": "Корови", "young": "Молодняк"}
        # мітка роздачі Profeed (Група-N) → періоди. Мітка задається в періоді
        # (з дати по дату); для старих даних — відкат на мітку секції.
        by_label: dict[str, list] = {}
        for s in self.list_herd_sections():
            s_lbl = (s.get("profeed_group") or "").strip()
            for p in (s.get("periods") or []):
                lbl = (p.get("profeed_group") or "").strip() or s_lbl
                if lbl:
                    p = dict(p)                       # копія — щоб не мутувати спільний
                    p["_section"] = (s.get("name") or "").strip() or "Без секції"
                    by_label.setdefault(lbl, []).append(p)

        def resolve_shares(label, day):
            """Частки однієї Profeed-групи на дату: список
            (категорія, підкатегорія, вага 0..1, голів_частки, секція_стада).
            Вага = голів × коеф споживання, нормована. Якщо частка одна —
            вага 1. Голів_частки: власне поголів'я частки (для СР/гол)."""
            ms = []
            for p in by_label.get(label, []):
                df = (p.get("date_from") or "")[:10]
                dt = (p.get("date_to") or "")[:10]
                if df and day < df:
                    continue
                if dt and day > dt:
                    continue
                ms.append(p)
            if not ms:
                return [("Без категорії", "—", 1.0, None, "Без секції")]
            heads = [max(0.0, self._to_float(p.get("headcount"), 0)) for p in ms]
            coefs = [self._to_float(p.get("eat_coef"), 1) or 1.0 for p in ms]
            if all(h > 0 for h in heads):
                wts = [h * c for h, c in zip(heads, coefs)]   # голів × коеф
            else:
                wts = list(coefs)                             # коеф = пряма частка
            tot = sum(wts)
            if tot <= 0:                       # нічого не задано — рівний поділ
                wts = [1.0] * len(ms); tot = float(len(ms))
            out = []
            for p, w in zip(ms, wts):
                cat = KIND.get(p.get("herd_kind") or "", "") or "Без категорії"
                sub = (p.get("subgroup") or "").strip() or "—"
                hc = max(0.0, self._to_float(p.get("headcount"), 0))
                out.append((cat, sub, w / tot, hc or None,
                            p.get("_section") or "Без секції"))
            return out

        FIELDS = ("pl_l", "l", "pl_d", "d", "lo", "con", "dry", "milk", "sum", "hd",
                  "con_sum", "ri_sum", "give_sum")

        def new_acc():
            return {k: 0.0 for k in FIELDS}

        def add(a, dd, w=1.0, head_day=None):
            a["pl_l"] += (dd.get("plan_loaded") or 0) * w
            a["l"] += (dd.get("loaded") or 0) * w
            a["pl_d"] += (dd.get("plan_distributed") or 0) * w
            a["d"] += (dd.get("distributed") or 0) * w
            a["lo"] += (dd.get("leftover") or 0) * w
            a["con"] += (dd.get("consumed") or 0) * w
            a["dry"] += (dd.get("dry_consumed") or 0) * w
            a["sum"] += (dd.get("ration_sum") or 0) * w
            # гроші йдуть за кормом (перенос залишку між секціями)
            a["con_sum"] += (dd.get("consumed_sum") or 0) * w
            a["ri_sum"] += (dd.get("refed_in_sum") or 0) * w
            a["give_sum"] += (dd.get("leftover_sum") or 0) * w
            a["hd"] += head_day if head_day is not None else ((dd.get("heads") or 0) * w)
            # молоко НЕ беремо з дня — його рознесемо з модуля молока нижче

        def acc(fact, plan):
            a = self._ratio_acc(fact, plan)
            return round(a, 1) if a is not None else None

        def metrics(a):
            return {
                "plan_loaded": round(a["pl_l"], 4), "loaded": round(a["l"], 4),
                "dev_load": round(a["l"] - a["pl_l"], 4), "acc_load": acc(a["l"], a["pl_l"]),
                "plan_dist": round(a["pl_d"], 1), "dist": round(a["d"], 1),
                "dev_dist": round(a["d"] - a["pl_d"], 1), "acc_dist": acc(a["d"], a["pl_d"]),
                "leftover": round(a["lo"], 1),
                "leftover_pct": round(a["lo"] / a["d"] * 100, 1) if a["d"] else None,
                "consumed": round(a["con"], 1), "dry": round(a["dry"], 1),
                "milk": round(a["milk"], 1) if a["milk"] else None,
                "conv": round(a["milk"] / a["dry"], 2) if (a["milk"] and a["dry"]) else None,
                "sum": round(a["sum"], 2),
                "consumed_sum": round(a["con_sum"], 2),
                "refed_in_sum": round(a["ri_sum"], 2) or None,
                "leftover_sum": round(a["give_sum"], 2) or None,
                # метрики «на голову» (за голово-днями періоду)
                "heads_days": round(a["hd"], 0),
                "dry_head": round(a["dry"] / a["hd"], 2) if a["hd"] else None,
                "consumed_head": round(a["con"] / a["hd"], 1) if a["hd"] else None,
                "milk_head": round(a["milk"] / a["hd"], 1) if (a["hd"] and a["milk"]) else None,
            }

        # лактуюча = Корови, окрім сухостою/запуску (за назвою підкатегорії)
        dry_re = _re.compile(r"сухост|запуск|dry", _re.IGNORECASE)

        def is_lactating(cat, sub):
            return cat == "Корови" and not dry_re.search(sub or "")

        def merge_ing(store, day_d, w=1.0):
            for it in (day_d.get("ingredients") or []):
                key = it.get("code") or it.get("name")
                g = store.setdefault(key, {"name": it.get("name", ""),
                                           "code": it.get("code", ""), "plan": 0.0,
                                           "kg": 0.0, "dry": 0.0, "sum": 0.0, "has_price": False})
                g["plan"] += (it.get("plan") or 0) * w
                g["kg"] += (it.get("kg") or 0) * w
                g["dry"] += (it.get("dry") or 0) * w
                if it.get("sum") is not None:
                    g["sum"] += it["sum"] * w; g["has_price"] = True

        agg: dict[tuple, dict] = {}
        hsec_agg: dict[str, dict] = {}      # секція «Управління стада» → акумулятор
        lact_by_day: dict[str, list] = {}   # дата → [(tot_acc, day_acc, dry_дня)]
        for s in tree["sections"]:
            for d in s["days"]:
                for cat, sub, w, hc, sname in resolve_shares(s["section"], d["date"]):
                    head_day = hc if hc else ((d.get("heads") or 0) * w)
                    a = agg.setdefault((cat, sub), {"tot": new_acc(), "days": {}})
                    da = a["days"].setdefault(d["date"], new_acc())
                    da.setdefault("_ing", {})
                    add(a["tot"], d, w, head_day)
                    add(da, d, w, head_day)
                    merge_ing(da["_ing"], d, w)
                    # паралельно — по секціях управління стада (+ розклад по датах)
                    hs = hsec_agg.setdefault(sname, {"tot": new_acc(), "days": {}, "ing": {},
                                                     "cat": cat, "sub": sub, "rations": set()})
                    if (d.get("ration") or "").strip():
                        hs["rations"].add(d["ration"].strip())
                    hsd = hs["days"].setdefault(d["date"], new_acc())
                    hsd.setdefault("_ing", {})
                    add(hs["tot"], d, w, head_day)
                    add(hsd, d, w, head_day)
                    merge_ing(hs["ing"], d, w)
                    merge_ing(hsd["_ing"], d, w)
                    if is_lactating(cat, sub):
                        lact_by_day.setdefault(d["date"], []).append(
                            (a["tot"], da, (d.get("dry_consumed") or 0) * w))

        # Ручна годівля (видача OUT корму на групу вручну, not_feed=0, лише ВРХ) —
        # окрема підкатегорія «Ручна годівля» в межах Корови/Молодняк. Так і
        # «Рух годівлі», і плитки «Огляду» беруть її з ОДНОГО джерела й сходяться.
        # Додаємо лише спожиті кг/₴ (без плану/СР/молока — вони не з роздавача).
        man_total_sum = 0.0
        for mr in self._manual_feed_by_cat(date_from, date_to):
            mcat = mr["cat"]; mkg = mr["kg"]; msum = mr["sum_nv"]
            a = agg.setdefault((mcat, "Ручна годівля"), {"tot": new_acc(), "days": {}})
            # ручна годівля: завантажено = спожито (без плану/втрат/СР)
            a["tot"]["con"] += mkg
            a["tot"]["con_sum"] += msum
            a["tot"]["l"] += mkg
            a["tot"]["sum"] += msum
            man_total_sum += msum
            da = a["days"].setdefault(mr["date"], new_acc())
            da.setdefault("_ing", {})
            da["con"] += mkg
            da["con_sum"] += msum
            da["l"] += mkg
            da["sum"] += msum
            key = mr["code"] or mr["name"]
            g = da["_ing"].setdefault(key, {"name": mr["name"], "code": mr["code"],
                                            "plan": 0.0, "kg": 0.0, "dry": 0.0,
                                            "sum": 0.0, "has_price": False})
            g["kg"] += mkg
            g["sum"] += msum
            g["has_price"] = True

        # рознесення денного надою по лактуючих (пропорційно спожитій СР)
        milk_by_day = milk_by_day or {}
        for day, lst in lact_by_day.items():
            m = self._to_float(milk_by_day.get(day) or 0)
            if m <= 0:
                continue
            totdry = sum(x[2] for x in lst) or 0
            for tot_acc, day_acc, dry in lst:
                share = (dry / totdry) if totdry else (1.0 / len(lst))
                tot_acc["milk"] += m * share
                day_acc["milk"] += m * share

        def ing_list(store):
            out = []
            for g in sorted(store.values(), key=lambda x: -x["kg"]):
                a_ = self._ratio_acc(g["kg"], g["plan"])
                pr = (g["sum"] / g["kg"]) if (g["has_price"] and g["kg"]) else None
                out.append({
                    "name": g["name"], "code": g["code"],
                    "plan": round(g["plan"], 1), "kg": round(g["kg"], 1),
                    "dry": round(g["dry"], 1),
                    # без плану — відхилення не показуємо (напр. ручна годівля)
                    "dev": round(g["kg"] - g["plan"], 1) if g["plan"] else None,
                    "acc": round(a_, 1) if a_ is not None else None,
                    "price": round(pr, 4) if pr else None,
                    "sum": round(g["sum"], 2) if g["has_price"] else None})
            return out

        def acc_mean(store):
            """Точність замісу — середнє з точностей окремих кормів."""
            vals = [self._ratio_acc(g["kg"], g["plan"])
                    for g in store.values() if g["plan"]]
            vals = [v for v in vals if v is not None]
            return round(sum(vals) / len(vals), 1) if vals else None

        def merge_store(dst, src):
            for k, g in src.items():
                d = dst.setdefault(k, {"name": g["name"], "code": g["code"], "plan": 0.0,
                                       "kg": 0.0, "dry": 0.0, "sum": 0.0, "has_price": False})
                d["plan"] += g["plan"]; d["kg"] += g["kg"]; d["dry"] += g["dry"]
                d["sum"] += g["sum"]; d["has_price"] = d["has_price"] or g["has_price"]

        cats: dict[str, dict] = {}
        for (cat, sub), a in agg.items():
            c = cats.setdefault(cat, {"category": cat, "tot": new_acc(), "subs": [], "ing": {}})
            for k in FIELDS:
                c["tot"][k] += a["tot"][k]
            days = []
            sub_ing: dict = {}
            for dt, dv in a["days"].items():
                merge_store(sub_ing, dv.get("_ing", {}))
                dm = metrics(dv)
                dm["acc_load"] = acc_mean(dv.get("_ing", {}))
                days.append({"date": dt, **dm, "ingredients": ing_list(dv.get("_ing", {}))})
            days.sort(key=lambda x: x["date"], reverse=True)
            merge_store(c["ing"], sub_ing)
            sm = metrics(a["tot"])
            sm["acc_load"] = acc_mean(sub_ing)
            c["subs"].append({"subgroup": sub, "_kg": a["tot"]["con"], **sm, "days": days})
        out = []
        for c in sorted(cats.values(), key=lambda x: -x["tot"]["con"]):
            c["subs"].sort(key=lambda x: -x["_kg"])
            cm = metrics(c["tot"])
            cm["acc_load"] = acc_mean(c["ing"])
            out.append({"category": c["category"], **cm, "subs": c["subs"]})
        # секції «Управління стада» — той самий факт завантаження, лише інша
        # ознака групування (одна Profeed-група може ділитись на кілька секцій)
        hsecs = []
        for name, a in hsec_agg.items():
            days = []
            for dt, dv in a["days"].items():
                dm = metrics(dv)
                dm["acc_load"] = acc_mean(dv.get("_ing", {}))
                days.append({"date": dt, **dm, "ingredients": ing_list(dv.get("_ing", {}))})
            days.sort(key=lambda x: x["date"], reverse=True)
            sm = metrics(a["tot"])
            sm["acc_load"] = acc_mean(a["ing"])
            hsecs.append({"section": name, "cat": a.get("cat", ""), "sub": a.get("sub", ""),
                          "ration": ", ".join(sorted(a.get("rations") or [])),
                          **sm, "days": days})
        hsecs.sort(key=lambda x: -(x["loaded"] or 0))
        total_kg = sum(c["tot"]["con"] for c in cats.values()) or 0.0
        total_sum = sum(c["tot"]["sum"] for c in cats.values()) or 0.0
        total_consumed_sum = sum(c["tot"]["con_sum"] for c in cats.values()) or 0.0
        return {"categories": out, "herd_sections": hsecs,
                "total_kg": round(total_kg, 1),
                # ₴-підсумки приколюємо до канонічних з дерева, щоб «По категоріях»/
                # «По секціях стада» = «Рух по секціях» = «По кормах» до копійки
                # (без дрейфу округлення перекидань пулу).
                "total_sum": tree.get("total_loaded_sum", round(total_sum, 2)),
                # канонічний (Profeed, БЕЗ ручної) — для «По секціях стада»/секцій/кормів
                "total_consumed_sum": tree.get("total_consumed_sum", round(total_consumed_sum, 2)),
                # з ручною годівлею — лише для «По категоріях» (там є підкат. «Ручна годівля»)
                "total_consumed_cats_sum": round(
                    (tree.get("total_consumed_sum") or round(total_consumed_sum, 2))
                    + man_total_sum, 2),
                "total_leftover_sum": tree.get("total_leftover_sum", 0),
                "total_refed_in_sum": tree.get("total_refed_in_sum", 0),
                # утилізація (збиток) — з того самого дерева, для звірки підсумків
                "disposal_kg": tree.get("disposal_kg", 0),
                "disposal_sum": tree.get("disposal_sum", 0),
                "date_from": tree.get("date_from", ""), "date_to": tree.get("date_to", "")}

    def feed_usage_by_ingredient(self, category: str = "feed", date_from: str = "",
                                 date_to: str = "") -> dict[str, Any]:
        """Витрата кожного корму з розкладкою Корм → Категорія (Корови/Молодняк)
        → Підкатегорія → Дата. Витрата = завантажений факт (кг), що пішов зі
        складу; відносимо до Категорії/Підкатегорії секції за періодами (як у
        feed_usage_by_category). Частка — доля корму, що припала на категорію /
        підкатегорію / дату (від сумарної витрати цього корму).

        Точність завантаження — СЕРЕДНЄ значення точностей окремих завантажень
        (кожен день секції = одне завантаження цього корму, точн. = менше/більше
        × 100). Тобто зведена точність = середнє арифметичне, а не відношення
        сум факту/плану."""
        import re as _re
        tree = self.feeding_tree(category, date_from, date_to)
        if tree.get("note") or tree.get("error"):
            return {"ingredients": [], "note": tree.get("note"), "error": tree.get("error"),
                    "date_from": tree.get("date_from", ""), "date_to": tree.get("date_to", "")}

        def _norm_ing(s):
            return _re.sub(r"\s+", " ", (s or "").strip()).casefold()

        KIND = {"cow": "Корови", "young": "Молодняк"}
        by_label: dict[str, list] = {}
        for s in self.list_herd_sections():
            s_lbl = (s.get("profeed_group") or "").strip()
            for p in (s.get("periods") or []):
                lbl = (p.get("profeed_group") or "").strip() or s_lbl
                if lbl:
                    by_label.setdefault(lbl, []).append(p)

        def resolve_shares(label, day):
            """Частки Profeed-групи на дату: (категорія, підкатегорія, вага 0..1).
            Вага = голів × коеф споживання, нормована; одна частка → вага 1."""
            ms = []
            for p in by_label.get(label, []):
                df = (p.get("date_from") or "")[:10]
                dt = (p.get("date_to") or "")[:10]
                if df and day < df:
                    continue
                if dt and day > dt:
                    continue
                ms.append(p)
            if not ms:
                return [("Без категорії", "—", 1.0)]
            heads = [max(0.0, self._to_float(p.get("headcount"), 0)) for p in ms]
            coefs = [self._to_float(p.get("eat_coef"), 1) or 1.0 for p in ms]
            wts = ([h * c for h, c in zip(heads, coefs)]
                   if all(h > 0 for h in heads) else list(coefs))
            tot = sum(wts)
            if tot <= 0:
                wts = [1.0] * len(ms); tot = float(len(ms))
            out = []
            for p, w in zip(ms, wts):
                cat = KIND.get(p.get("herd_kind") or "", "") or "Без категорії"
                sub = (p.get("subgroup") or "").strip() or "—"
                out.append((cat, sub, w / tot))
            return out

        def node():
            # accs — точності окремих завантажень (для середнього)
            return {"plan": 0.0, "kg": 0.0, "dry": 0.0, "sum": 0.0,
                    "has_price": False, "accs": []}

        def bump(n, it, acc, w=1.0):
            n["plan"] += (it.get("plan") or 0) * w
            n["kg"] += (it.get("kg") or 0) * w
            n["dry"] += (it.get("dry") or 0) * w
            if it.get("sum") is not None:
                n["sum"] += it["sum"] * w; n["has_price"] = True
            if acc is not None:
                n["accs"].append(acc)

        ing: dict = {}
        for s in tree["sections"]:
            for d in s["days"]:
                shares = resolve_shares(s["section"], d["date"])
                day = d["date"]
                for it in (d.get("ingredients") or []):
                    # Групуємо за НАЗВОЮ (нормалізованою), бо той самий корм у
                    # різних звітах Profeed може мати різний код — інакше він
                    # роздвоюється на кілька рядків.
                    key = _norm_ing(it.get("name")) or it.get("code")
                    # точність цього завантаження (день × секція × корм)
                    acc = self._ratio_acc(it.get("kg"), it.get("plan"))
                    g = ing.setdefault(key, {"name": it.get("name", ""),
                                             "code": it.get("code", ""), "tot": node(),
                                             "cats": {}})
                    for cat, sub, w in shares:
                        bump(g["tot"], it, acc, w)
                        c = g["cats"].setdefault(cat, {"tot": node(), "subs": {}})
                        bump(c["tot"], it, acc, w)
                        sb = c["subs"].setdefault(sub, {"tot": node(), "days": {}})
                        bump(sb["tot"], it, acc, w)
                        dn = sb["days"].setdefault(day, node())
                        bump(dn, it, acc, w)

        # Ручна годівля (видача OUT корму вручну) — окрема підкатегорія «Ручна
        # годівля» під кожним кормом/категорією. Без плану/СР/точності.
        for mr in self._manual_feed_by_cat(date_from, date_to):
            key = _norm_ing(mr["name"]) or mr["code"]
            g = ing.setdefault(key, {"name": mr["name"], "code": mr["code"],
                                     "tot": node(), "cats": {}})
            it = {"plan": 0, "kg": mr["kg"], "dry": 0, "sum": mr["sum_nv"]}
            cat = mr["cat"]; sub = "Ручна годівля"; day = mr["date"]
            bump(g["tot"], it, None)
            c = g["cats"].setdefault(cat, {"tot": node(), "subs": {}})
            bump(c["tot"], it, None)
            sb = c["subs"].setdefault(sub, {"tot": node(), "days": {}})
            bump(sb["tot"], it, None)
            dn = sb["days"].setdefault(day, node())
            bump(dn, it, None)

        def price(n):
            # ціна без ПДВ — 4 знаки після коми
            return round(n["sum"] / n["kg"], 4) if (n["has_price"] and n["kg"]) else None

        def share(part_kg, whole_kg):
            return round(part_kg / whole_kg * 100, 1) if whole_kg else None

        def macc(n):
            """Зведена точність = середнє точностей окремих завантажень."""
            a = n["accs"]
            return round(sum(a) / len(a), 1) if a else None

        def met(n, whole_kg):
            return {"plan": round(n["plan"], 4), "kg": round(n["kg"], 4),
                    "dev": round(n["kg"] - n["plan"], 4) if n["plan"] else None,
                    "dry": round(n["dry"], 4),
                    "sum": round(n["sum"], 2) if n["has_price"] else None,
                    "price": price(n), "share": share(n["kg"], whole_kg),
                    "acc": macc(n)}

        out = []
        for g in sorted(ing.values(), key=lambda x: -x["tot"]["kg"]):
            tot_kg = g["tot"]["kg"]
            cats = []
            for cname, c in g["cats"].items():
                subs = []
                for sn, sd in c["subs"].items():
                    days = [{"date": dt, **met(dn, tot_kg)}
                            for dt, dn in sd["days"].items()]
                    days.sort(key=lambda x: x["date"], reverse=True)
                    subs.append({"subgroup": sn, **met(sd["tot"], tot_kg), "days": days})
                subs.sort(key=lambda x: -(x["kg"] or 0))
                cats.append({"category": cname, **met(c["tot"], tot_kg), "subs": subs})
            cats.sort(key=lambda x: -(x["kg"] or 0))
            out.append({"name": g["name"], "code": g["code"],
                        **met(g["tot"], tot_kg), "cats": cats})
        # складський залишок корму по датах (для режиму «просто по датах»)
        stock_map = self._feed_stock_by_date(date_from, date_to)
        # реальний вхідний ПДВ з приходу корму за період (податковий кредит)
        pvat_map = self.feed_purchase_vat_by_name(date_from, date_to)
        for item in out:
            item["stock_by_date"] = stock_map.get(_norm_ing(item["name"]), {})
            item["purchase_vat"] = pvat_map.get(_norm_ing(item["name"]), 0.0)
        total_kg = sum(g["tot"]["kg"] for g in ing.values()) or 0.0
        total_sum = sum(g["tot"]["sum"] for g in ing.values()) or 0.0
        return {"ingredients": out, "total_kg": round(total_kg, 1),
                "total_sum": round(total_sum, 2),
                "date_from": tree.get("date_from", ""), "date_to": tree.get("date_to", "")}

    def feeding_analytics(self, category: str = "feed",
                          date_from: str = "", date_to: str = "") -> dict[str, Any]:
        """Аналітика годівлі по секціях за період.

        Бере списання годівлі (stock_moves WRITE_OFF, sale_no LIKE 'ГД-%'),
        зводить по блоку-секції: згодовано кг, собівартість з/без ПДВ, кількість
        днів годівлі. Поголівʼя — з привʼязаної групи стада (поточне число).
        Метрики на голову рахуються за днями, коли секцію реально годували."""
        date_from = (date_from or "").strip()[:10]
        date_to = (date_to or "").strip()[:10]
        cond, params = ["m.move_type = 'WRITE_OFF'", "m.sale_no LIKE 'ГД-%'"], []
        if date_from:
            cond.append("substr(m.created_at,1,10) >= ?"); params.append(date_from)
        if date_to:
            cond.append("substr(m.created_at,1,10) <= ?"); params.append(date_to)
        where = " AND ".join(cond)
        with self._connect() as conn:
            rows = conn.execute(
                f"""SELECT b.id AS block_id, b.name AS block_name, b.herd_kind,
                          b.subgroup, b.herd_group_id,
                          COUNT(DISTINCT substr(m.created_at,1,10)) AS days,
                          SUM(m.qty) AS kg,
                          SUM(m.total) AS cost_vat,
                          SUM(m.qty * COALESCE(NULLIF(sb.price_in_no_vat,0), m.price)) AS cost_nv
                     FROM stock_moves m
                     JOIN blocks b ON b.id = m.block_id AND b.category = ?
                     LEFT JOIN stock_batches sb ON sb.id = m.batch_id
                    WHERE {where}
                    GROUP BY b.id
                    ORDER BY b.herd_kind DESC, b.subgroup, b.name COLLATE NOCASE""",
                [category] + params).fetchall()
        # Джерело поголів'я: 'profeed' — зі звітів (feeding_events), 'herd' —
        # з секцій стада (періоди). Перемикач у налаштуваннях.
        source = (self.get_setting("feed_headcount_source", "profeed") or "profeed").strip()

        ev_cond, ev_params = ["1=1"], []
        if date_from:
            ev_cond.append("op_date >= ?"); ev_params.append(date_from)
        if date_to:
            ev_cond.append("op_date <= ?"); ev_params.append(date_to)
        with self._connect() as conn:
            evs = conn.execute(
                f"SELECT block_id, op_date, kg_loaded_all, kg_distributed, headcount "
                f"FROM feeding_events WHERE {' AND '.join(ev_cond)}", ev_params).fetchall()
            hg = conn.execute(
                "SELECT id, profeed_block_id FROM herd_groups "
                "WHERE is_active = 1 AND profeed_block_id IS NOT NULL").fetchall()
            drows = conn.execute(
                f"""SELECT m.block_id AS bid, substr(m.created_at,1,10) AS d
                     FROM stock_moves m
                     JOIN blocks b ON b.id = m.block_id AND b.category = ?
                    WHERE {where}
                    GROUP BY m.block_id, substr(m.created_at,1,10)""",
                [category] + params).fetchall()

        # з журналу роздач: поголів'я по (блок, день) і втрати по блоку
        hc_by_bd: dict[tuple, float] = {}
        loss_by_block: dict[int, float] = {}
        loaded_by_block: dict[int, float] = {}
        distrib_by_block: dict[int, float] = {}
        for e in evs:
            bid = e["block_id"]
            if bid is None:
                continue
            k = (bid, e["op_date"])
            hc_by_bd[k] = max(hc_by_bd.get(k, 0.0), float(e["headcount"] or 0))
            loaded_by_block[bid] = loaded_by_block.get(bid, 0.0) + float(e["kg_loaded_all"] or 0)
            distrib_by_block[bid] = distrib_by_block.get(bid, 0.0) + float(e["kg_distributed"] or 0)
        for bid in loaded_by_block:
            loss_by_block[bid] = loaded_by_block[bid] - distrib_by_block.get(bid, 0.0)

        secs_by_block: dict[int, list] = {}
        for g in hg:
            secs_by_block.setdefault(g["profeed_block_id"], []).append(g["id"])
        days_by_block: dict[int, list] = {}
        for r in drows:
            days_by_block.setdefault(r["bid"], []).append(r["d"])

        # head-days блоку: profeed — сума поголів'я по днях зі звіту;
        # herd — сума по днях годівлі за поголів'ям привʼязаних секцій.
        def head_days(bid):
            if source == "herd":
                secs = secs_by_block.get(bid, [])
                total = 0.0
                for day in days_by_block.get(bid, []):
                    for sid in secs:
                        total += self.section_headcount_on(sid, day)
                return total
            return sum(hc for (b, _d), hc in hc_by_bd.items() if b == bid)

        sections = []
        for r in rows:
            d = dict(r)
            bid = d["block_id"]
            days = int(d["days"] or 0)
            hd = head_days(bid)
            kg = float(d["kg"] or 0)
            cost_nv = float(d["cost_nv"] or 0)
            cost_vat = float(d["cost_vat"] or 0)
            loss = loss_by_block.get(bid, 0.0)
            sections.append({
                "block_id": bid, "block_name": d["block_name"],
                "herd_kind": d["herd_kind"] or "", "subgroup": d["subgroup"] or "",
                "headcount": round(hd / days, 1) if days else 0.0,
                "head_days": round(hd, 1), "days": days,
                "kg": round(kg, 1), "cost_vat": round(cost_vat, 2),
                "cost_no_vat": round(cost_nv, 2),
                "kg_head_day": round(kg / hd, 2) if hd else None,
                "uah_head_day": round(cost_nv / hd, 2) if hd else None,
                "kg_distributed": round(distrib_by_block.get(bid, 0.0), 1),
                "loss_kg": round(loss, 1),
            })
        return {"sections": sections, "date_from": date_from, "date_to": date_to,
                "headcount_source": source}

    # ------------------------------------------- імпорт виробництва з Profeed
    # Вода з міксера — не корм, на складі її немає, тож зі списання виключаємо.
    _PROFEED_SKIP = {"h2o", "вода", "н2о"}

    @staticmethod
    def _kk_code_from_mixer(mixer: str) -> str:
        """Витягти код комбікорму з назви міксера Profeed.

        У виробництві КК міксер має вигляд «Дійні (К-2)», «Сухостій (К-5)»,
        «Телята (К-7)». Роздача — «1-ша роздача/Д» тощо; там дужки немає,
        тож повертаємо порожнє й такий запис не вважаємо виробництвом."""
        import re
        m = re.search(r"\(\s*К\s*-?\s*(\d+)\s*\)", str(mixer or ""), re.IGNORECASE)
        return f"К{m.group(1)}" if m else ""

    def scan_profeed_productions(self, folder: str) -> dict[str, Any]:
        """Знайти у звітах Profeed заміси комбікормів (ще не проведені).

        Сканує ВСІ .xlsx у теці. Кожна «партія» з міксером-комбікормом і
        непорожнім фактом — це заміс. Компоненти беруться за ФАКТОМ (скільки
        реально насипали), вода відкидається. № партії — ключ ідемпотентності:
        якщо його вже проведено, заміс не показуємо."""
        import glob
        import openpyxl

        folder = (folder or "").strip()
        p = Path(folder).expanduser()
        if not p.exists():
            return {"error": f"Теку не знайдено: {folder}", "items": []}
        files = sorted(glob.glob(str(p / "*.xlsx")) + glob.glob(str(p / "*.xls")))
        if not files:
            return {"error": "У теці немає файлів .xlsx", "items": []}

        # довідники для зіставлення назв
        feeds = self.list_products(category="feed")
        by_name = {(f["name"] or "").strip().lower(): f for f in feeds}
        with self._connect() as conn:
            done = {r[0] for r in conn.execute(
                "SELECT src_key FROM feed_productions WHERE src_key <> ''").fetchall()}

        HDR = {"Інгредієнт, назва", "№ партії", "Статус",
               "Планова кількість, кг", "Фактична кількість, кг"}
        found: dict[str, dict] = {}     # src_key -> заміс (дедуплікація між файлами)

        for fp in files:
            try:
                wb = openpyxl.load_workbook(fp, read_only=True, data_only=True)
            except Exception:  # noqa: BLE001
                continue
            for ws in wb.worksheets:
                rows = list(ws.iter_rows(values_only=True))
                # шукаємо рядок шапки
                hi = next((i for i, r in enumerate(rows[:6])
                           if HDR <= {str(c).strip() for c in r if c}), None)
                if hi is None:
                    continue
                h = [str(c).strip() if c is not None else "" for c in rows[hi]]
                ix = {name: h.index(name) for name in
                      ("Дата", "Міксер", "№ партії", "Інгредієнт, назва",
                       "Планова кількість, кг", "Фактична кількість, кг") if name in h}
                if "№ партії" not in ix or "Міксер" not in ix:
                    continue
                # групуємо рядки за № партії
                groups: dict[str, list] = {}
                for r in rows[hi + 1:]:
                    key = r[ix["№ партії"]]
                    if key is None or str(key).strip() == "":
                        continue
                    groups.setdefault(str(key).strip(), []).append(r)

                for src_key, grp in groups.items():
                    if src_key in done or src_key in found:
                        continue
                    kk = self._kk_code_from_mixer(grp[0][ix["Міксер"]])
                    if not kk:                       # це роздача, не виробництво
                        continue
                    lines, qty_out, qty_plan = [], 0.0, 0.0
                    for r in grp:
                        name = str(r[ix["Інгредієнт, назва"]] or "").strip()
                        if not name:                 # підсумковий рядок
                            continue
                        if name.lower() in self._PROFEED_SKIP:
                            continue
                        fact = self._to_float(r[ix.get("Фактична кількість, кг", -1)]
                                         if "Фактична кількість, кг" in ix else 0)
                        plan = self._to_float(r[ix.get("Планова кількість, кг", -1)]
                                         if "Планова кількість, кг" in ix else 0)
                        # відхилення факту від плану, %
                        dev = round((fact - plan) / plan * 100, 2) if plan else None
                        prod = by_name.get(name.lower())
                        lines.append({"name": name, "qty": round(fact, 3),
                                      "plan": round(plan, 3), "dev_pct": dev,
                                      "product_id": prod["id"] if prod else None,
                                      "unknown": prod is None})
                        qty_out += fact
                        qty_plan += plan
                    if qty_out <= 0:                 # факту немає — не робили
                        continue
                    kkprod = by_name.get(kk.lower())
                    dt = grp[0][ix["Дата"]] if "Дата" in ix else None
                    date_s = (str(dt)[:10] if dt else "")
                    found[src_key] = {
                        "src_key": src_key, "date": date_s,
                        "kk_code": kk, "kk_name": kkprod["name"] if kkprod else kk,
                        "kk_product_id": kkprod["id"] if kkprod else None,
                        "kk_missing": kkprod is None,
                        "qty_out": round(qty_out, 3),
                        "qty_plan": round(qty_plan, 3),
                        "lines": lines,
                        "unknown_feeds": sorted({l["name"] for l in lines if l["unknown"]}),
                        "file": Path(fp).name,
                    }
            wb.close()
        items = sorted(found.values(), key=lambda x: (x["date"], x["src_key"]))
        return {"items": items, "count": len(items), "files": len(files)}

    def import_profeed_productions(self, folder: str, src_keys: list,
                                   user_id: Optional[int] = None) -> dict[str, Any]:
        """Провести обрані заміси Profeed. Невідомі корми створюються
        автоматично (із нульовим залишком) — тоді у відповіді буде попередження,
        бо списати з нуля не вийде; такий заміс лишиться непроведеним."""
        scan = self.scan_profeed_productions(folder)
        if scan.get("error"):
            return scan
        want = set(src_keys or [])
        # scan["items"] уже відсортовано за (дата, № партії). Проводимо саме в
        # цьому порядку — тоді номери документів ВК-N ідуть послідовно з датами,
        # а не хаотично (set не зберігає порядок вибору).
        chosen = [it for it in scan["items"] if it["src_key"] in want]
        done, failed = [], []
        for it in chosen:
            key = it["src_key"]
            # КК: створюємо, якщо його ще немає
            kk_id = it["kk_product_id"]
            if not kk_id:
                pid = self.add_product(name=it["kk_name"], barcode="", unit="кг",
                                       min_stock=0, supplier="", notes="",
                                       category="feed",
                                       code=self.generate_product_code("feed"))
                kk_id = pid if isinstance(pid, int) else pid["id"]
            # компоненти: невідомі корми теж заводимо (щоб не губити рядок)
            comps = []
            for l in it["lines"]:
                cid = l["product_id"]
                if not cid:
                    pid = self.add_product(name=l["name"], barcode="", unit="кг",
                                           min_stock=0, supplier="", notes="",
                                           category="feed",
                                           code=self.generate_product_code("feed"))
                    cid = pid if isinstance(pid, int) else pid["id"]
                comps.append({"product_id": cid, "qty": l["qty"]})
            try:
                res = self.produce_combifeed(
                    product_id=kk_id, qty_out=it["qty_out"], components=comps,
                    prod_date=it["date"], source="profeed", src_key=key,
                    note=f"Імпорт Profeed · {it['kk_code']}", user_id=user_id)
                if res.get("skipped"):
                    failed.append({"src_key": key, "error": "вже проведено"})
                else:
                    done.append(res)
            except ValueError as exc:
                failed.append({"src_key": key, "error": str(exc)})
        return {"done": done, "done_count": len(done), "failed": failed}

    def get_feed_production(self, prod_id: int) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            r = conn.execute(
                "SELECT f.*, p.name AS product_name, p.code AS product_code, "
                "  p.barcode AS product_barcode "
                "FROM feed_productions f JOIN products p ON p.id = f.product_id "
                "WHERE f.id = ?", (prod_id,)).fetchone()
            if not r:
                return None
            lines = [dict(x) for x in conn.execute(
                "SELECT l.*, p.name, p.code FROM feed_production_lines l "
                "JOIN products p ON p.id = l.product_id "
                "WHERE l.production_id = ? ORDER BY l.sort_order, l.id",
                (prod_id,)).fetchall()]
        for l in lines:
            l["dev_kg"] = round(l["qty_fact"] - l["qty_plan"], 3)
            l["dev_pct"] = (round((l["qty_fact"] / l["qty_plan"] - 1) * 100, 2)
                            if l["qty_plan"] else None)
        plan_sum = sum(l["qty_plan"] for l in lines)
        dev_sum = sum(abs(l["qty_fact"] - l["qty_plan"]) for l in lines)
        return {**dict(r), "lines": lines,
                "accuracy_pct": (round(max(0.0, 100 - dev_sum / plan_sum * 100), 2)
                                 if plan_sum else None)}

    def delete_feed_production(self, prod_id: int) -> None:
        """Скасувати виробництво: повернути компоненти на склад і зняти КК.

        Рух складу розвертається точно за проводками документа, тому залишки
        й собівартість повертаються до стану «як було». Якщо вироблений
        комбікорм уже частково витратили — скасувати не можна, інакше
        залишок пішов би в мінус."""
        with self._connect() as conn:
            doc = conn.execute("SELECT * FROM feed_productions WHERE id = ?",
                               (prod_id,)).fetchone()
            if not doc:
                raise ValueError("Документ виробництва не знайдено.")
            doc_no = doc["doc_no"]

            in_moves = conn.execute(
                "SELECT * FROM stock_moves WHERE sale_no = ? AND move_type = 'IN'",
                (doc_no,)).fetchall()
            for m in in_moves:
                b = conn.execute("SELECT qty FROM stock_batches WHERE id = ?",
                                 (m["batch_id"],)).fetchone()
                if b and b["qty"] + 1e-9 < m["qty"]:
                    raise ValueError(
                        f"Комбікорм із {doc_no} уже частково витрачено "
                        f"(лишилось {b['qty']:g} з {m['qty']:g} кг) — скасувати не можна.")

            out_moves = conn.execute(
                "SELECT * FROM stock_moves WHERE sale_no = ? AND move_type = 'OUT'",
                (doc_no,)).fetchall()

            # 1) знімаємо оприбуткований комбікорм
            for m in in_moves:
                conn.execute("UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                             (m["qty"], m["batch_id"]))
            # 2) повертаємо компоненти в ті самі партії, з яких брали
            for m in out_moves:
                conn.execute("UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                             (m["qty"], m["batch_id"]))
            # 3) спершу проводки — на них є зовнішній ключ, інакше партію
            #    комбікорму видалити не вдасться
            conn.execute("DELETE FROM stock_moves WHERE sale_no = ?", (doc_no,))
            for m in in_moves:
                conn.execute("DELETE FROM stock_batches WHERE id = ? AND qty <= 1e-9",
                             (m["batch_id"],))
            conn.execute("DELETE FROM feed_production_lines WHERE production_id = ?",
                         (prod_id,))
            conn.execute("DELETE FROM feed_productions WHERE id = ?", (prod_id,))

    def list_feed_productions(self, limit: int = 50) -> list[dict[str, Any]]:
        """Партії комбікормів із їх складом і точністю виготовлення.

        Точність — наскільки факт завантаження збігся зі зразком. Рахуємо як
        100% мінус сумарне відхилення у кілограмах, віднесене до плану:
        це стійкіше за середнє по компонентах, бо великий компонент важить
        більше, ніж дрібна добавка. Якщо зразка немає — точність невідома."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT f.*, p.name AS product_name, p.code AS product_code "
                "FROM feed_productions f JOIN products p ON p.id = f.product_id "
                "ORDER BY f.prod_date DESC, f.id DESC LIMIT ?", (limit,)).fetchall()
            out = []
            for r in rows:
                lines = [dict(x) for x in conn.execute(
                    "SELECT l.*, p.name FROM feed_production_lines l "
                    "JOIN products p ON p.id = l.product_id "
                    "WHERE l.production_id = ? ORDER BY l.sort_order, l.id",
                    (r["id"],)).fetchall()]
                plan_sum = sum(l["qty_plan"] for l in lines)
                dev_sum = sum(abs(l["qty_fact"] - l["qty_plan"]) for l in lines)
                for l in lines:
                    l["dev_kg"] = round(l["qty_fact"] - l["qty_plan"], 3)
                    l["dev_pct"] = (round((l["qty_fact"] / l["qty_plan"] - 1) * 100, 2)
                                    if l["qty_plan"] else None)
                out.append({**dict(r), "lines": lines,
                            "accuracy_pct": (round(max(0.0, 100 - dev_sum / plan_sum * 100), 2)
                                             if plan_sum else None)})
        return out

    def feed_production_consumption(self, date_from: str = "",
                                    date_to: str = "") -> dict[str, Any]:
        """Зведений розхід кормів-компонентів на виробництво комбікормів за
        період: по кожному корму — витрачено кг та собівартість (з ПДВ і без),
        плюс ₴/кг. Дані з feed_production_lines (фактична FIFO-собівартість)."""
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        where, params = [], []
        if d1:
            where.append("fp.prod_date >= ?"); params.append(d1)
        if d2:
            where.append("fp.prod_date <= ?"); params.append(d2)
        w = ("WHERE " + " AND ".join(where)) if where else ""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT l.product_id AS pid, p.name AS name, p.code AS code, "
                "       COALESCE(p.unit, 'кг') AS unit, "
                "       SUM(l.qty_fact) AS kg, SUM(l.cost) AS cost, "
                "       SUM(l.cost_no_vat) AS cost_nv "
                "FROM feed_production_lines l "
                "JOIN feed_productions fp ON fp.id = l.production_id "
                "JOIN products p ON p.id = l.product_id "
                f"{w} GROUP BY l.product_id "
                "ORDER BY p.name COLLATE NOCASE", params).fetchall()
        items = []
        t_kg = t_cost = t_cost_nv = 0.0
        for r in rows:
            kg = r["kg"] or 0.0
            cost = r["cost"] or 0.0
            cost_nv = r["cost_nv"] or 0.0
            t_kg += kg; t_cost += cost; t_cost_nv += cost_nv
            items.append({
                "product_id": r["pid"], "name": r["name"], "code": r["code"],
                "unit": r["unit"], "kg": round(kg, 1),
                "cost": round(cost, 2), "cost_no_vat": round(cost_nv, 2),
                "per_kg": round(cost / kg, 4) if kg else 0,
                "per_kg_no_vat": round(cost_nv / kg, 4) if kg else 0})
        return {"items": items, "date_from": d1, "date_to": d2,
                "total_kg": round(t_kg, 1), "total_cost": round(t_cost, 2),
                "total_cost_no_vat": round(t_cost_nv, 2)}

    def feed_production_day(self, day: str = "") -> dict[str, Any]:
        """Виробництво комбікорму за ОДИН день: компоненти (корми, з яких
        вироблено КК) та власне вироблений КК. Для блоку в Огляді годівлі."""
        day = (day or "")[:10]
        cons = self.feed_production_consumption(day, day)   # корми-компоненти
        produced = []
        if day:
            with self._connect() as conn:
                rows = conn.execute(
                    "SELECT p.name AS name, p.code AS code, "
                    "       COALESCE(p.unit,'кг') AS unit, "
                    "       SUM(fp.qty_out) AS kg, SUM(fp.cost_total) AS cost, "
                    "       SUM(COALESCE(fp.cost_total_no_vat,0)) AS cost_nv "
                    "FROM feed_productions fp JOIN products p ON p.id = fp.product_id "
                    "WHERE fp.prod_date = ? "
                    "GROUP BY fp.product_id ORDER BY p.name COLLATE NOCASE",
                    (day,)).fetchall()
            for r in rows:
                kg = r["kg"] or 0.0
                cost = r["cost"] or 0.0
                cnv = r["cost_nv"] or 0.0
                produced.append({
                    "name": r["name"], "code": r["code"], "unit": r["unit"],
                    "kg": round(kg, 1), "cost": round(cost, 2),
                    "cost_no_vat": round(cnv, 2),
                    "per_kg_no_vat": round(cnv / kg, 4) if kg else 0})
        return {"day": day,
                "components": cons.get("items", []),
                "comp_total_kg": cons.get("total_kg", 0),
                "comp_total_cost_no_vat": cons.get("total_cost_no_vat", 0),
                "produced": produced,
                "prod_total_kg": round(sum(p["kg"] for p in produced), 1),
                "prod_total_cost_no_vat": round(sum(p["cost_no_vat"] for p in produced), 2)}

    def feed_production_range(self, date_from: str = "",
                             date_to: str = "") -> dict[str, Any]:
        """Виробництво комбікорму за ПЕРІОД: компоненти (розхід кормів на
        виробництво КК) + власне вироблений КК, згруповані по номенклатурі.
        Для блоку «Виробництво комбікорму» на сторінці «Рух годівлі»."""
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        cons = self.feed_production_consumption(d1, d2)   # компоненти за період
        where, params = [], []
        if d1:
            where.append("fp.prod_date >= ?"); params.append(d1)
        if d2:
            where.append("fp.prod_date <= ?"); params.append(d2)
        w = ("WHERE " + " AND ".join(where)) if where else ""
        produced = []
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.name AS name, p.code AS code, "
                "       COALESCE(p.unit,'кг') AS unit, "
                "       SUM(fp.qty_out) AS kg, SUM(fp.cost_total) AS cost, "
                "       SUM(COALESCE(fp.cost_total_no_vat,0)) AS cost_nv "
                "FROM feed_productions fp JOIN products p ON p.id = fp.product_id "
                f"{w} GROUP BY fp.product_id ORDER BY p.name COLLATE NOCASE",
                params).fetchall()
        for r in rows:
            kg = r["kg"] or 0.0
            cnv = r["cost_nv"] or 0.0
            produced.append({
                "name": r["name"], "code": r["code"], "unit": r["unit"],
                "kg": round(kg, 1), "cost": round(r["cost"] or 0.0, 2),
                "cost_no_vat": round(cnv, 2),
                "per_kg_no_vat": round(cnv / kg, 4) if kg else 0})
        return {"date_from": d1, "date_to": d2,
                "components": cons.get("items", []),
                "comp_total_kg": cons.get("total_kg", 0),
                "comp_total_cost_no_vat": cons.get("total_cost_no_vat", 0),
                "produced": produced,
                "prod_total_kg": round(sum(p["kg"] for p in produced), 1),
                "prod_total_cost_no_vat": round(sum(p["cost_no_vat"] for p in produced), 2)}

    def feed_production_by_ingredient(self, date_from: str = "",
                                     date_to: str = "") -> dict[str, Any]:
        """Розхід кормів на виробництво комбікорму: Корм → Дата, у форматі
        таблиці «По кормах» (кг, ₴ без ПДВ, ₴/кг, складський залишок на дату).
        Для окремої секції в таблиці «По кормах» на «Рух годівлі»."""
        import re as _re
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        where, params = [], []
        if d1:
            where.append("fp.prod_date >= ?"); params.append(d1)
        if d2:
            where.append("fp.prod_date <= ?"); params.append(d2)
        w = ("WHERE " + " AND ".join(where)) if where else ""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.name AS name, p.code AS code, COALESCE(p.unit,'кг') AS unit, "
                "       fp.prod_date AS d, SUM(l.qty_fact) AS kg, "
                "       SUM(l.qty_plan) AS plan, SUM(l.cost_no_vat) AS sum_nv "
                "FROM feed_production_lines l "
                "JOIN feed_productions fp ON fp.id = l.production_id "
                "JOIN products p ON p.id = l.product_id "
                f"{w} GROUP BY l.product_id, fp.prod_date "
                "ORDER BY p.name COLLATE NOCASE, fp.prod_date DESC", params).fetchall()

        def _norm(s):
            return _re.sub(r"\s+", " ", (s or "").strip()).casefold()

        def _acc(kg, plan):
            if not kg or not plan:
                return None
            return round(min(kg, plan) / max(kg, plan) * 100, 1)

        stock_map = self._feed_stock_by_date(d1, d2)
        groups: dict = {}
        for r in rows:
            key = _norm(r["name"]) or r["code"]
            g = groups.setdefault(key, {"name": r["name"], "code": r["code"],
                                        "unit": r["unit"], "kg": 0.0, "plan": 0.0,
                                        "sum": 0.0, "days": []})
            kg = r["kg"] or 0.0
            pl = r["plan"] or 0.0
            sm = r["sum_nv"] or 0.0
            g["kg"] += kg
            g["plan"] += pl
            g["sum"] += sm
            g["days"].append({"date": r["d"], "kg": round(kg, 4), "sum": round(sm, 2),
                              "plan": round(pl, 4) if pl else None,
                              "dev": round(kg - pl, 4) if pl else None,
                              "acc": _acc(kg, pl), "dry": None,
                              "price": round(sm / kg, 4) if kg else None})
        out = []
        tot_kg = tot_sum = 0.0
        for g in sorted(groups.values(), key=lambda x: -x["kg"]):
            sb = stock_map.get(_norm(g["name"]), {})
            for d in g["days"]:
                d["stock_left"] = sb.get(d["date"])
            ds = sorted(sb.keys())
            g["stock_by_date"] = sb
            g["stock_left"] = sb.get(ds[-1]) if ds else None
            g["price"] = round(g["sum"] / g["kg"], 4) if g["kg"] else None
            g["dev"] = round(g["kg"] - g["plan"], 4) if g["plan"] else None
            g["acc"] = _acc(g["kg"], g["plan"])
            g["plan"] = round(g["plan"], 4) if g["plan"] else None
            g["kg"] = round(g["kg"], 4)
            g["sum"] = round(g["sum"], 2)
            g["dry"] = None
            tot_kg += g["kg"]; tot_sum += g["sum"]
            out.append(g)
        return {"items": out, "total_kg": round(tot_kg, 1),
                "total_sum": round(tot_sum, 2), "date_from": d1, "date_to": d2}

    # =============== ПЕРЕНЕСЕННЯ ГІЛКИ ГОДІВЛЯ (CSV export/import) ===============
    # Порядок секцій у payload/CSV (він же — порядок вставки при імпорті).
    FEED_XFER_SECTIONS = ["suppliers", "recipients", "products", "blocks",
                          "batches", "moves", "productions", "production_lines",
                          "feeding_events", "feeding_event_ings", "feeding_leftover",
                          "feeding_pool_dest", "feeding_leftover_dest", "feeding_milk"]
    FEED_XFER_COLS = {
        "suppliers": ["name", "notes"],
        "recipients": ["name", "notes"],
        "products": ["old_id", "code", "name", "barcode", "unit", "min_stock",
                     "notes", "markup_pct", "sale_price", "dose_unit",
                     "pack_content", "exclude_from_order", "is_active", "created_at"],
        "blocks": ["old_id", "name", "herd_kind", "subgroup", "notes",
                   "is_active", "created_at"],
        "batches": ["old_id", "product_old_id", "lot_number", "expires_on", "qty",
                    "price_in", "price_out", "price_in_no_vat", "vat_rate",
                    "markup_pct", "invoice_number", "invoice_date", "receipt_date",
                    "supplier_name", "sort_order", "created_at"],
        "moves": ["product_old_id", "batch_old_id", "block_old_id", "recipient_name",
                  "barcode", "move_type", "qty", "note", "created_at", "price",
                  "total", "sale_no", "cash_given", "original_sale_no", "not_feed"],
        "productions": ["old_id", "doc_no", "prod_date", "product_old_id", "qty_out",
                        "cost_total", "price_per_kg", "source", "src_key", "note",
                        "created_at", "cost_total_no_vat", "price_per_kg_no_vat"],
        "production_lines": ["production_old_id", "product_old_id", "qty_plan",
                             "qty_fact", "price", "cost", "sort_order", "cost_no_vat"],
        # рух годівлі (заміси Profeed) — щоб «Рух годівлі» читався з БД
        "feeding_events": ["src_key", "op_date", "group_label", "block_old_id",
                           "ration", "kg_loaded", "kg_loaded_all", "kg_distributed",
                           "headcount", "plan_loaded", "dry_loaded", "plan_distributed",
                           "dry_distributed", "leftover", "file_ts", "mixer",
                           "created_at"],
        "feeding_event_ings": ["src_key", "name", "code", "plan", "kg", "dry"],
        # залишки ЗМР по секціях/днях + розподіл пулу (утилізація / інші групи)
        "feeding_leftover": ["section", "day", "qty_kg", "updated_at"],
        "feeding_pool_dest": ["day", "dest", "qty"],
        "feeding_leftover_dest": ["section", "day", "dest", "qty"],
        "feeding_milk": ["section", "day", "milk_kg"],
    }

    # ---- журнал завантажень звітів Profeed (контроль виконання) ----
    def _ensure_profeed_log(self, conn: sqlite3.Connection) -> None:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS profeed_fetch_log ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " at TEXT NOT NULL, day TEXT NOT NULL DEFAULT '',"
            " slot TEXT NOT NULL DEFAULT '', name TEXT NOT NULL DEFAULT '',"
            " ok INTEGER NOT NULL DEFAULT 1, replaced INTEGER NOT NULL DEFAULT 0,"
            " imported INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT '',"
            " size INTEGER NOT NULL DEFAULT 0, error TEXT NOT NULL DEFAULT '')")
        # ALTER-гард для наявних БД без колонки size
        cols = {r[1] for r in conn.execute("PRAGMA table_info(profeed_fetch_log)")}
        if "size" not in cols:
            conn.execute("ALTER TABLE profeed_fetch_log ADD COLUMN size INTEGER NOT NULL DEFAULT 0")

    def profeed_log_add(self, rows: list, source: str = "auto",
                        keep: int = 15) -> None:
        """Додати записи журналу завантажень і підрізати старі (тримаємо 15)."""
        if not rows:
            return
        with self._connect() as conn:
            self._ensure_profeed_log(conn)
            conn.executemany(
                "INSERT INTO profeed_fetch_log(at, day, slot, name, ok, replaced,"
                " imported, source, size, error) VALUES(?,?,?,?,?,?,?,?,?,?)",
                [(str(r.get("at") or self._now())[:16], str(r.get("day") or ""),
                  str(r.get("slot") or ""), str(r.get("name") or ""),
                  1 if r.get("ok", True) else 0, 1 if r.get("replaced") else 0,
                  int(r.get("imported") or 0), source, int(r.get("size") or 0),
                  str(r.get("error") or ""))
                 for r in rows])
            conn.execute(
                "DELETE FROM profeed_fetch_log WHERE id NOT IN "
                "(SELECT id FROM profeed_fetch_log ORDER BY id DESC LIMIT ?)",
                (max(1, int(keep or 15)),))

    def profeed_log_list(self, limit: int = 15) -> list[dict[str, Any]]:
        with self._connect() as conn:
            self._ensure_profeed_log(conn)
            rows = conn.execute(
                "SELECT * FROM profeed_fetch_log ORDER BY id DESC LIMIT ?",
                (max(1, int(limit or 15)),)).fetchall()
        return [dict(r) for r in rows]

    # ---- журнал балансувань залишку (щоб можна було скасувати останнє) ----
    def _ensure_feed_balance_log(self, conn: sqlite3.Connection) -> None:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feed_balance_log ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " product_id INTEGER NOT NULL, day TEXT NOT NULL, mode TEXT NOT NULL,"
            " dest TEXT NOT NULL DEFAULT 'stock', block_id INTEGER,"
            " delta REAL NOT NULL DEFAULT 0, payload TEXT NOT NULL DEFAULT '',"
            " created_at TEXT NOT NULL, user_id INTEGER)")

    def _log_feed_balance(self, conn: sqlite3.Connection, product_id: int, day: str,
                          mode: str, dest: str, block_id, delta: float,
                          payload: dict, user_id=None) -> None:
        self._ensure_feed_balance_log(conn)
        conn.execute(
            "INSERT INTO feed_balance_log(product_id, day, mode, dest, block_id,"
            " delta, payload, created_at, user_id) VALUES(?,?,?,?,?,?,?,?,?)",
            (product_id, day, mode, dest or "stock", block_id, delta,
             json.dumps(payload, ensure_ascii=False), self._now(), user_id))

    def feed_balance_last(self, product_id: Optional[int] = None) -> dict[str, Any]:
        """Останній запис балансування (для показу/скасування)."""
        with self._connect() as conn:
            self._ensure_feed_balance_log(conn)
            sql = ("SELECT l.*, p.name AS product_name, b.name AS block_name "
                   "FROM feed_balance_log l "
                   "LEFT JOIN products p ON p.id=l.product_id "
                   "LEFT JOIN blocks b ON b.id=l.block_id")
            params: list[Any] = []
            if product_id:
                sql += " WHERE l.product_id=?"
                params.append(int(product_id))
            sql += " ORDER BY l.id DESC LIMIT 1"
            r = conn.execute(sql, params).fetchone()
        if not r:
            return {}
        d = dict(r)
        d.pop("payload", None)
        return d

    def feed_balance_log_list(self, product_id: Optional[int] = None,
                              limit: int = 15) -> list[dict[str, Any]]:
        """Останні записи балансування (журнал) — для списку зі скасуванням."""
        with self._connect() as conn:
            self._ensure_feed_balance_log(conn)
            sql = ("SELECT l.id, l.product_id, l.day, l.mode, l.dest, l.block_id,"
                   " l.delta, l.created_at, l.payload,"
                   " p.name AS product_name, b.name AS block_name "
                   "FROM feed_balance_log l "
                   "LEFT JOIN products p ON p.id=l.product_id "
                   "LEFT JOIN blocks b ON b.id=l.block_id")
            params: list[Any] = []
            if product_id:
                sql += " WHERE l.product_id=?"
                params.append(int(product_id))
            sql += " ORDER BY l.id DESC LIMIT ?"
            params.append(max(1, int(limit or 15)))
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        for r in rows:
            try:
                r["kind"] = (json.loads(r.pop("payload") or "{}") or {}).get("kind", "")
            except Exception:  # noqa: BLE001
                r["kind"] = ""
                r.pop("payload", None)
        return rows

    # примітки, за якими впізнаємо рух-балансування (у т.ч. створені до появи журналу)
    _BAL_NOTE_LIKE = ("Інвентаризація%", "Коригування по групі%", "Початковий залишок%")

    def feed_balance_history(self, product_id: Optional[int] = None,
                             limit: int = 15) -> list[dict[str, Any]]:
        """Історія балансувань = записи журналу + рухи-балансування, яких у
        журналі немає (проведені до появи журналу). Для кожного рядка вказано,
        чи можна його скасувати."""
        rows = self.feed_balance_log_list(product_id, limit)
        logged_moves: set[int] = set()
        with self._connect() as conn:
            self._ensure_feed_balance_log(conn)
            for r in conn.execute("SELECT payload FROM feed_balance_log").fetchall():
                try:
                    pl = json.loads(r["payload"] or "{}")
                except Exception:  # noqa: BLE001
                    continue
                if pl.get("move_id"):
                    logged_moves.add(int(pl["move_id"]))
                for m in (pl.get("moves") or []):
                    if m.get("move_id"):
                        logged_moves.add(int(m["move_id"]))

            where = " OR ".join(["m.note LIKE ?"] * len(self._BAL_NOTE_LIKE))
            params: list[Any] = list(self._BAL_NOTE_LIKE)
            sql = ("SELECT m.id, m.product_id, m.move_type, m.qty, m.note, m.created_at,"
                   " m.block_id, m.sale_no, p.name AS product_name, b.name AS block_name "
                   "FROM stock_moves m "
                   "LEFT JOIN products p ON p.id=m.product_id "
                   "LEFT JOIN blocks b ON b.id=m.block_id "
                   f"WHERE p.category='feed' AND ({where})")
            if product_id:
                sql += " AND m.product_id=?"
                params.append(int(product_id))
            sql += " ORDER BY m.id DESC LIMIT ?"
            params.append(max(1, int(limit or 15)) * 3)
            extra = conn.execute(sql, params).fetchall()

        for m in extra:
            if int(m["id"]) in logged_moves:
                continue
            note = m["note"] or ""
            if note.startswith("Початковий залишок"):
                mode, dest = "opening", "stock"
            elif note.startswith("Коригування по групі"):
                mode, dest = "inventory", ("block" if m["block_id"] else "stock")
            else:
                mode = "inventory"
                dest = ("block" if m["block_id"]
                        else ("loss" if (m["sale_no"] or "").startswith("ГД-ІНВ") else "stock"))
            qty = self._to_float(m["qty"], 0)
            rows.append({
                "id": None, "move_id": m["id"], "product_id": m["product_id"],
                "product_name": m["product_name"], "day": str(m["created_at"] or "")[:10],
                "mode": mode, "dest": dest, "block_id": m["block_id"],
                "block_name": m["block_name"],
                "delta": qty if m["move_type"] == "IN" else -qty,
                "created_at": m["created_at"], "kind": "move", "legacy": True,
            })
        rows.sort(key=lambda r: (str(r.get("created_at") or ""), r.get("id") or 0),
                  reverse=True)
        return rows[:max(1, int(limit or 15))]

    def feed_balance_undo_move(self, move_id: int) -> dict[str, Any]:
        """Скасувати ОКРЕМИЙ рух-балансування (запис без журналу): видалити рух
        і повернути кількість у партію."""
        with self._connect() as conn:
            m = conn.execute(
                "SELECT m.*, p.category FROM stock_moves m "
                "LEFT JOIN products p ON p.id=m.product_id WHERE m.id=?",
                (int(move_id),)).fetchone()
            if not m:
                raise ValueError("Рух не знайдено.")
            if (m["category"] or "") != "feed":
                raise ValueError("Це не рух годівлі.")
            note = m["note"] or ""
            if not any(note.startswith(x.rstrip("%")) for x in self._BAL_NOTE_LIKE):
                raise ValueError("Цей рух не є балансуванням залишку.")
            qty = self._to_float(m["qty"], 0)
            if m["move_type"] == "IN":
                if m["batch_id"]:
                    conn.execute("UPDATE stock_batches SET qty=MAX(0, qty-?) WHERE id=?",
                                 (qty, m["batch_id"]))
            else:
                if m["batch_id"]:
                    conn.execute("UPDATE stock_batches SET qty=qty+? WHERE id=?",
                                 (qty, m["batch_id"]))
            conn.execute("DELETE FROM stock_moves WHERE id=?", (m["id"],))
            if m["batch_id"]:
                left = conn.execute("SELECT COUNT(*) FROM stock_moves WHERE batch_id=?",
                                    (m["batch_id"],)).fetchone()[0]
                if not left:
                    conn.execute("DELETE FROM stock_batches WHERE id=?", (m["batch_id"],))
            pid, day = m["product_id"], str(m["created_at"] or "")[:10]
        return {"ok": True, "move_id": int(move_id),
                "now": self.feed_stock_on_date(pid, day)}

    def feed_balance_undo(self, log_id: Optional[int] = None,
                          product_id: Optional[int] = None) -> dict[str, Any]:
        """Скасувати останнє балансування (або конкретне за id): повернути
        змінений прихід до попередньої кількості / видалити створені рухи."""
        with self._connect() as conn:
            self._ensure_feed_balance_log(conn)
            if log_id:
                row = conn.execute("SELECT * FROM feed_balance_log WHERE id=?",
                                   (int(log_id),)).fetchone()
            elif product_id:
                row = conn.execute(
                    "SELECT * FROM feed_balance_log WHERE product_id=? "
                    "ORDER BY id DESC LIMIT 1", (int(product_id),)).fetchone()
            else:
                row = conn.execute(
                    "SELECT * FROM feed_balance_log ORDER BY id DESC LIMIT 1").fetchone()
            if not row:
                raise ValueError("Немає записів балансування для скасування.")
            try:
                pl = json.loads(row["payload"] or "{}")
            except Exception:  # noqa: BLE001
                pl = {}
            kind = pl.get("kind") or ""

            def _drop_batch(bid):
                """Видалити партію, якщо по ній не лишилось інших рухів."""
                if not bid:
                    return
                used = conn.execute(
                    "SELECT COUNT(*) FROM stock_moves WHERE batch_id=?", (bid,)).fetchone()[0]
                if not used:
                    conn.execute("DELETE FROM stock_batches WHERE id=?", (bid,))

            if kind == "adjust_in":
                mid = pl.get("move_id")
                prev = self._to_float(pl.get("prev_qty"), 0)
                price = self._to_float(pl.get("price"), 0)
                conn.execute("UPDATE stock_moves SET qty=?, total=?, note=? WHERE id=?",
                             (prev, round(prev * price, 2), pl.get("prev_note") or "", mid))
                if pl.get("batch_id"):
                    conn.execute("UPDATE stock_batches SET qty=MAX(0, qty-?) WHERE id=?",
                                 (self._to_float(row["delta"], 0), pl["batch_id"]))
            elif kind in ("new_in", "inv_in"):
                conn.execute("DELETE FROM stock_moves WHERE id=?", (pl.get("move_id"),))
                _drop_batch(pl.get("batch_id"))
            elif kind == "inv_out":
                for m in (pl.get("moves") or []):
                    conn.execute("DELETE FROM stock_moves WHERE id=?", (m.get("move_id"),))
                    if m.get("batch_id"):
                        conn.execute("UPDATE stock_batches SET qty=qty+? WHERE id=?",
                                     (self._to_float(m.get("qty"), 0), m["batch_id"]))
            else:
                raise ValueError("Невідомий тип запису — скасувати неможливо.")
            conn.execute("DELETE FROM feed_balance_log WHERE id=?", (row["id"],))
            pid, day = row["product_id"], row["day"]
        return {"ok": True, "undone": dict(row.keys() and {
            "id": row["id"], "day": day, "mode": row["mode"],
            "delta": row["delta"]}), "now": self.feed_stock_on_date(pid, day)}

    def feed_stock_on_date(self, product_id: int, day: str) -> float:
        """Залишок корму на КІНЕЦЬ дати: сума приходів − сума видач/списань
        по рухах до цієї дати включно."""
        day = str(day or "")[:10]
        with self._connect() as conn:
            r = conn.execute(
                "SELECT COALESCE(SUM(CASE WHEN move_type='IN' THEN qty "
                "ELSE -qty END),0) FROM stock_moves "
                "WHERE product_id=? AND substr(created_at,1,10) <= ?",
                (product_id, day)).fetchone()
        return round(float(r[0] or 0), 4)

    def feed_balance(self, product_id: int, day: str, mode: str,
                     qty: float, note: str = "",
                     user_id: Optional[int] = None,
                     dest: str = "stock", block_id: Optional[int] = None) -> dict[str, Any]:
        """Балансування залишку корму на дату двома способами:

        • mode='opening' — ПОЧАТКОВИЙ ЗАЛИШОК: qty — скільки МАЄ БУТИ на дату;
          коригується ПЕРВИННИЙ (найраніший) прихід корму на різницю, тож
          залишок на цю дату стає рівно qty. Приходів немає → створюється
          стартовий прихід.
        • mode='inventory' — ІНВЕНТАРИЗАЦІЯ: qty — це ФАКТИЧНИЙ залишок на дату;
          система рахує різницю з обліковим і проводить лише її
          (лишок → прихід, нестача → списання). Виняток: dest='block' — тоді
          qty це САМА кількість зі знаком (+ додати / − відняти) на групу.

        КУДИ віднести нестачу (dest):
        • 'stock'  — лише склад (без віднесення на групи);
        • 'loss'   — втрати: списання з ознакою ГД-ІНВ, іде у витрати годівлі
                     як збиток (поряд з утилізацією залишків);
        • 'block'  — на конкретну групу/блок (block_id): корм вважається
                     згодованим цією групою й лягає в її собівартість.

        Рух створюється датою day (бекдейт), тому «Рух годівлі» й залишки на
        дати перераховуються автоматично."""
        day = str(day or "")[:10] or date.today().isoformat()
        qty = self._to_float(qty)
        mode = (mode or "opening").strip()
        prod = self.get_product(product_id)
        if not prod:
            raise ValueError("Корм не знайдено.")
        # відʼємне число дозволене лише для віднесення на групу (± кількість)
        if qty < 0 and not (mode == "inventory" and (dest or "") == "block"):
            raise ValueError("Кількість не може бути відʼємною.")

        cur_qty = self.feed_stock_on_date(product_id, day)

        # ── ПОЧАТКОВИЙ ЗАЛИШОК: коригуємо ПЕРВИННИЙ прихід так, щоб на вказану
        #    дату залишок став саме вказаним числом (різниця йде в найраніший
        #    прихід корму; якщо приходів ще немає — створюємо стартовий).
        if mode == "opening":
            delta = round(qty - cur_qty, 4)
            if abs(delta) < 1e-9:
                return {"ok": True, "delta": 0.0, "was": cur_qty, "now": cur_qty,
                        "note": "Залишок уже дорівнює вказаному — змін не потрібно."}
            with self._connect() as conn:
                # найраніший прихід НЕ пізніше вказаної дати (пізніші не впливають
                # на залишок цієї дати, тож коригувати їх немає сенсу)
                first = conn.execute(
                    "SELECT m.id, m.batch_id, m.qty, m.price, m.note, m.created_at "
                    "FROM stock_moves m WHERE m.product_id=? AND m.move_type='IN' "
                    "AND substr(m.created_at,1,10) <= ? "
                    "ORDER BY m.created_at, m.id LIMIT 1", (product_id, day)).fetchone()
                if first:
                    new_qty_in = round((first["qty"] or 0) + delta, 4)
                    if new_qty_in < 0:
                        raise ValueError(
                            "Неможливо: первинний прихід став би відʼємним "
                            f"({new_qty_in} кг). Зменште число або виправте прихід вручну.")
                    price = first["price"] or 0
                    TAG = " · коригування початкового залишку"
                    n0 = first["note"] or ""
                    n1 = n0 if TAG.strip() in n0 else (n0 + TAG).strip(" ·")
                    conn.execute(
                        "UPDATE stock_moves SET qty=?, total=?, note=? WHERE id=?",
                        (new_qty_in, round(new_qty_in * price, 2), n1, first["id"]))
                    if first["batch_id"]:
                        conn.execute(
                            "UPDATE stock_batches SET qty=MAX(0, qty+?) WHERE id=?",
                            (delta, first["batch_id"]))
                    self._log_feed_balance(
                        conn, product_id, day, mode, "stock", None, delta,
                        {"kind": "adjust_in", "move_id": first["id"],
                         "batch_id": first["batch_id"], "prev_qty": first["qty"],
                         "prev_note": n0, "price": price}, user_id)
                    action = "первинний прихід відкориговано"
                else:
                    # приходів немає — створюємо стартовий цією датою
                    now0 = self._now()
                    created0 = f"{day} {now0[11:]}" if len(now0) >= 19 else day
                    cur = conn.execute(
                        "INSERT INTO stock_batches(product_id, lot_number, expires_on, qty, "
                        "created_at, price_in, price_out, price_in_no_vat, vat_rate, "
                        "markup_pct, invoice_number, invoice_date, receipt_date, "
                        "supplier_id, sort_order) VALUES(?,?,'',?,?,0,0,0,0,0,'',?,?,NULL,0)",
                        (product_id, "ПОЧ-" + day.replace("-", ""), delta, created0, day, day))
                    bid0 = cur.lastrowid
                    m0 = conn.execute(
                        "INSERT INTO stock_moves(product_id, batch_id, barcode, move_type, "
                        "qty, note, created_at, price, total, user_id, block_id, sale_no) "
                        "VALUES(?,?,?,'IN',?,?,?,0,0,?,NULL,'')",
                        (product_id, bid0, prod.get("barcode"), delta,
                         "Початковий залишок", created0, user_id))
                    self._log_feed_balance(
                        conn, product_id, day, mode, "stock", None, delta,
                        {"kind": "new_in", "move_id": m0.lastrowid, "batch_id": bid0},
                        user_id)
                    action = "створено стартовий прихід"
            new_q = self.feed_stock_on_date(product_id, day)
            return {"ok": True, "delta": round(delta, 4), "was": cur_qty,
                    "now": new_q, "mode": mode, "day": day, "note": action}

        # ── ІНВЕНТАРИЗАЦІЯ
        if dest == "block":
            # на групу: qty — це САМА кількість (+ додати / − відняти), а не факт
            delta = qty
            label = "Коригування по групі"
        else:
            delta = round(qty - cur_qty, 4)
            label = "Інвентаризація"
        if abs(delta) < 1e-9:
            return {"ok": True, "delta": 0.0, "was": cur_qty, "now": cur_qty,
                    "note": "Розбіжності немає — рух не створювався."}

        now = self._now()
        created = f"{day} {now[11:]}" if len(now) >= 19 else day
        txt = f"{label}: {note}".strip(": ").strip() if note else label
        # Куди відносимо нестачу: 'loss'/'block' → рух позначаємо як годівельний
        # (sale_no 'ГД-ІНВ-…'), щоб він потрапляв у витрати годівлі; 'block' —
        # ще й прив'язуємо до блоку (лягає в собівартість групи).
        dest = (dest or "stock").strip()
        bid_dest = None
        sale_no = ""            # порожній = звичайне складське коригування
        if dest in ("loss", "block"):
            sale_no = "ГД-ІНВ-" + day.replace("-", "")
            if dest == "block":
                bid_dest = block_id
                if not bid_dest:
                    raise ValueError("Оберіть групу, на яку віднести різницю.")
                txt = f"{txt} · на групу"
            else:
                txt = f"{txt} · втрати"

        with self._connect() as conn:
            if delta > 0:
                # прихід: нова партія за середньою ціною корму (для собівартості)
                avg = conn.execute(
                    "SELECT AVG(price_in) FROM stock_batches "
                    "WHERE product_id=? AND price_in>0", (product_id,)).fetchone()[0] or 0
                avg_nv = conn.execute(
                    "SELECT AVG(price_in_no_vat) FROM stock_batches "
                    "WHERE product_id=? AND price_in_no_vat>0",
                    (product_id,)).fetchone()[0] or avg
                lot = "ІНВ-" + day.replace("-", "")
                cur = conn.execute(
                    "INSERT INTO stock_batches(product_id, lot_number, expires_on, qty, "
                    "created_at, price_in, price_out, price_in_no_vat, vat_rate, "
                    "markup_pct, invoice_number, invoice_date, receipt_date, "
                    "supplier_id, sort_order) VALUES(?,?,'',?,?,?,?,?,0,0,'',?,?,NULL,0)",
                    (product_id, lot, delta, created, avg, avg, avg_nv, day, day))
                bid = cur.lastrowid
                mv = conn.execute(
                    "INSERT INTO stock_moves(product_id, batch_id, barcode, move_type, "
                    "qty, note, created_at, price, total, user_id, block_id, sale_no) "
                    "VALUES(?,?,?,'IN',?,?,?,?,?,?,?,?)",
                    (product_id, bid, prod.get("barcode"), delta, txt, created,
                     avg, round(delta * (avg or 0), 2), user_id, bid_dest, sale_no))
                self._log_feed_balance(
                    conn, product_id, day, mode, dest, bid_dest, delta,
                    {"kind": "inv_in", "move_id": mv.lastrowid, "batch_id": bid}, user_id)
            else:
                # нестача: списуємо FIFO з наявних партій
                need = -delta
                done: list[dict[str, Any]] = []
                rows = conn.execute(
                    "SELECT id, qty, price_in, price_in_no_vat FROM stock_batches "
                    "WHERE product_id=? AND qty>0 ORDER BY id", (product_id,)).fetchall()
                for b in rows:
                    if need <= 1e-9:
                        break
                    take = min(need, b["qty"])
                    conn.execute("UPDATE stock_batches SET qty=qty-? WHERE id=?",
                                 (take, b["id"]))
                    price = b["price_in"] or 0
                    mv = conn.execute(
                        "INSERT INTO stock_moves(product_id, batch_id, barcode, move_type, "
                        "qty, note, created_at, price, total, user_id, block_id, sale_no) "
                        "VALUES(?,?,?,'WRITE_OFF',?,?,?,?,?,?,?,?)",
                        (product_id, b["id"], prod.get("barcode"), take, txt, created,
                         price, round(take * price, 2), user_id, bid_dest, sale_no))
                    done.append({"move_id": mv.lastrowid, "batch_id": b["id"], "qty": take})
                    need -= take
                if need > 1e-9:      # партій забракло — списуємо решту без партії
                    mv = conn.execute(
                        "INSERT INTO stock_moves(product_id, batch_id, barcode, move_type, "
                        "qty, note, created_at, price, total, user_id, block_id, sale_no) "
                        "VALUES(?,NULL,?,'WRITE_OFF',?,?,?,0,0,?,?,?)",
                        (product_id, prod.get("barcode"), need, txt, created, user_id,
                         bid_dest, sale_no))
                    done.append({"move_id": mv.lastrowid, "batch_id": None, "qty": need})
                self._log_feed_balance(
                    conn, product_id, day, mode, dest, bid_dest, delta,
                    {"kind": "inv_out", "moves": done}, user_id)
        new_qty = self.feed_stock_on_date(product_id, day)
        return {"ok": True, "delta": round(delta, 4), "was": cur_qty,
                "now": new_qty, "mode": mode, "day": day}

    def feed_transfer_export(self) -> dict[str, list]:
        """Усі дані гілки Годівля для перенесення: {секція: [dict,...]}.
        Внутрішні звʼязки — через old_id (product/block/batch/production),
        постачальник/отримувач — за назвою."""
        out: dict[str, list] = {s: [] for s in self.FEED_XFER_SECTIONS}
        with self._connect() as conn:
            feed_pids = [r["id"] for r in conn.execute(
                "SELECT id FROM products WHERE category='feed'").fetchall()]
            if not feed_pids:
                return out
            sup_name = {r["id"]: r["name"] for r in conn.execute(
                "SELECT id, name FROM suppliers").fetchall()}
            rcp_name = {r["id"]: r["name"] for r in conn.execute(
                "SELECT id, name FROM recipients").fetchall()}
            used_sup, used_rcp = set(), set()

            for r in conn.execute("SELECT * FROM products WHERE category='feed' "
                                  "ORDER BY id").fetchall():
                out["products"].append({
                    "old_id": r["id"], "code": r["code"], "name": r["name"],
                    "barcode": r["barcode"], "unit": r["unit"],
                    "min_stock": r["min_stock"], "notes": r["notes"],
                    "markup_pct": r["markup_pct"], "sale_price": r["sale_price"],
                    "dose_unit": r["dose_unit"], "pack_content": r["pack_content"],
                    "exclude_from_order": r["exclude_from_order"],
                    "is_active": r["is_active"], "created_at": r["created_at"]})
            for r in conn.execute("SELECT * FROM blocks WHERE category='feed' "
                                  "ORDER BY id").fetchall():
                out["blocks"].append({
                    "old_id": r["id"], "name": r["name"], "herd_kind": r["herd_kind"],
                    "subgroup": r["subgroup"], "notes": r["notes"],
                    "is_active": r["is_active"], "created_at": r["created_at"]})
            for r in conn.execute(
                    "SELECT b.* FROM stock_batches b JOIN products p ON p.id=b.product_id "
                    "WHERE p.category='feed' ORDER BY b.id").fetchall():
                if r["supplier_id"]:
                    used_sup.add(r["supplier_id"])
                out["batches"].append({
                    "old_id": r["id"], "product_old_id": r["product_id"],
                    "lot_number": r["lot_number"], "expires_on": r["expires_on"],
                    "qty": r["qty"], "price_in": r["price_in"], "price_out": r["price_out"],
                    "price_in_no_vat": r["price_in_no_vat"], "vat_rate": r["vat_rate"],
                    "markup_pct": r["markup_pct"], "invoice_number": r["invoice_number"],
                    "invoice_date": r["invoice_date"], "receipt_date": r["receipt_date"],
                    "supplier_name": sup_name.get(r["supplier_id"], ""),
                    "sort_order": r["sort_order"], "created_at": r["created_at"]})
            for r in conn.execute(
                    "SELECT m.* FROM stock_moves m JOIN products p ON p.id=m.product_id "
                    "WHERE p.category='feed' ORDER BY m.id").fetchall():
                if r["recipient_id"]:
                    used_rcp.add(r["recipient_id"])
                out["moves"].append({
                    "product_old_id": r["product_id"], "batch_old_id": r["batch_id"],
                    "block_old_id": r["block_id"],
                    "recipient_name": rcp_name.get(r["recipient_id"], ""),
                    "barcode": r["barcode"], "move_type": r["move_type"], "qty": r["qty"],
                    "note": r["note"], "created_at": r["created_at"], "price": r["price"],
                    "total": r["total"], "sale_no": r["sale_no"],
                    "cash_given": r["cash_given"],
                    "original_sale_no": r["original_sale_no"], "not_feed": r["not_feed"]})
            for r in conn.execute("SELECT * FROM feed_productions ORDER BY id").fetchall():
                out["productions"].append({
                    "old_id": r["id"], "doc_no": r["doc_no"], "prod_date": r["prod_date"],
                    "product_old_id": r["product_id"], "qty_out": r["qty_out"],
                    "cost_total": r["cost_total"], "price_per_kg": r["price_per_kg"],
                    "source": r["source"], "src_key": r["src_key"], "note": r["note"],
                    "created_at": r["created_at"],
                    "cost_total_no_vat": r["cost_total_no_vat"],
                    "price_per_kg_no_vat": r["price_per_kg_no_vat"]})
            for r in conn.execute("SELECT * FROM feed_production_lines ORDER BY id").fetchall():
                out["production_lines"].append({
                    "production_old_id": r["production_id"],
                    "product_old_id": r["product_id"], "qty_plan": r["qty_plan"],
                    "qty_fact": r["qty_fact"], "price": r["price"], "cost": r["cost"],
                    "sort_order": r["sort_order"], "cost_no_vat": r["cost_no_vat"]})
            for sid in sorted(used_sup):
                out["suppliers"].append({"name": sup_name.get(sid, ""), "notes": ""})
            for rid in sorted(used_rcp):
                out["recipients"].append({"name": rcp_name.get(rid, ""), "notes": ""})

            # --- рух годівлі (заміси), залишки, розподіл пулу, молоко по секціях ---
            def _tbl_exists(t):
                return bool(conn.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                    (t,)).fetchone())

            if _tbl_exists("feeding_events"):
                for r in conn.execute("SELECT * FROM feeding_events ORDER BY id").fetchall():
                    k = r.keys()
                    out["feeding_events"].append({
                        "src_key": r["src_key"], "op_date": r["op_date"],
                        "group_label": r["group_label"],
                        "block_old_id": r["block_id"], "ration": r["ration"],
                        "kg_loaded": r["kg_loaded"], "kg_loaded_all": r["kg_loaded_all"],
                        "kg_distributed": r["kg_distributed"], "headcount": r["headcount"],
                        "plan_loaded": r["plan_loaded"] if "plan_loaded" in k else 0,
                        "dry_loaded": r["dry_loaded"] if "dry_loaded" in k else 0,
                        "plan_distributed": r["plan_distributed"] if "plan_distributed" in k else 0,
                        "dry_distributed": r["dry_distributed"] if "dry_distributed" in k else 0,
                        "leftover": r["leftover"] if "leftover" in k else 0,
                        "file_ts": r["file_ts"] if "file_ts" in k else "",
                        "mixer": r["mixer"] if "mixer" in k else "",
                        "created_at": r["created_at"]})
            if _tbl_exists("feeding_event_ings"):
                for r in conn.execute("SELECT * FROM feeding_event_ings ORDER BY id").fetchall():
                    out["feeding_event_ings"].append({
                        "src_key": r["src_key"], "name": r["name"], "code": r["code"],
                        "plan": r["plan"], "kg": r["kg"], "dry": r["dry"]})
            if _tbl_exists("feeding_leftover"):
                for r in conn.execute("SELECT * FROM feeding_leftover").fetchall():
                    out["feeding_leftover"].append({
                        "section": r["section"], "day": r["day"], "qty_kg": r["qty_kg"],
                        "updated_at": r["updated_at"] if "updated_at" in r.keys() else ""})
            if _tbl_exists("feeding_pool_dest"):
                for r in conn.execute("SELECT * FROM feeding_pool_dest").fetchall():
                    out["feeding_pool_dest"].append({
                        "day": r["day"], "dest": r["dest"], "qty": r["qty"]})
            if _tbl_exists("feeding_leftover_dest"):
                for r in conn.execute("SELECT * FROM feeding_leftover_dest").fetchall():
                    out["feeding_leftover_dest"].append({
                        "section": r["section"], "day": r["day"],
                        "dest": r["dest"], "qty": r["qty"]})
            if _tbl_exists("feeding_milk"):
                for r in conn.execute("SELECT * FROM feeding_milk").fetchall():
                    out["feeding_milk"].append({
                        "section": r["section"], "day": r["day"], "milk_kg": r["milk_kg"]})
        return out

    def feed_transfer_import(self, payload: dict) -> dict:
        """Очистити рухи/партії/виробництво годівлі в ЦІЙ базі й записати нові з
        payload (структура feed_transfer_export). Товари/блоки/довідники —
        upsert за природним ключем (code / назва / name+herd_kind). Внутрішні
        звʼязки через old_id. Усе в одній транзакції."""
        now = self._now()
        stats = {k: 0 for k in ("products", "blocks", "suppliers", "recipients",
                                "batches", "moves", "productions", "production_lines",
                                "feeding_events", "feeding_event_ings", "feeding_leftover",
                                "feeding_pool_dest", "feeding_leftover_dest",
                                "feeding_milk")}

        def _f(v):
            return self._to_float(v) if v not in (None, "") else 0.0

        def _i(v):
            try:
                return int(float(v))
            except (TypeError, ValueError):
                return None

        with self._connect() as conn:
            # 1) очистити рухи/партії/виробництво годівлі (товари/блоки лишаємо),
            #    а також рух годівлі (заміси), залишки й розподіл пулу
            def _has(t):
                return bool(conn.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                    (t,)).fetchone())

            conn.execute("DELETE FROM feed_production_lines")
            conn.execute("DELETE FROM feed_productions")
            conn.execute("DELETE FROM stock_moves WHERE product_id IN "
                         "(SELECT id FROM products WHERE category='feed')")
            conn.execute("DELETE FROM stock_batches WHERE product_id IN "
                         "(SELECT id FROM products WHERE category='feed')")
            for t in ("feeding_event_ings", "feeding_events", "feeding_leftover",
                      "feeding_pool_dest", "feeding_leftover_dest", "feeding_milk"):
                if _has(t):
                    conn.execute(f"DELETE FROM {t}")

            # 2) довідники (за назвою)
            sup_id = {self._norm_key(r["name"]): r["id"] for r in conn.execute(
                "SELECT id, name FROM suppliers").fetchall()}
            for row in payload.get("suppliers", []):
                k = self._norm_key(row.get("name"))
                if not k or k in sup_id:
                    continue
                cur = conn.execute("INSERT INTO suppliers(name, notes, is_active, "
                                   "category, created_at) VALUES(?,?,1,'feed',?)",
                                   (row.get("name"), row.get("notes") or "", now))
                sup_id[k] = cur.lastrowid; stats["suppliers"] += 1
            rcp_id = {self._norm_key(r["name"]): r["id"] for r in conn.execute(
                "SELECT id, name FROM recipients").fetchall()}
            for row in payload.get("recipients", []):
                k = self._norm_key(row.get("name"))
                if not k or k in rcp_id:
                    continue
                cur = conn.execute("INSERT INTO recipients(name, notes, is_active, "
                                   "category, created_at) VALUES(?,?,1,'feed',?)",
                                   (row.get("name"), row.get("notes") or "", now))
                rcp_id[k] = cur.lastrowid; stats["recipients"] += 1

            # 3) товари. Матч: НАЗВА → штрихкод → код. Саме назва — природний
            #    ключ корму: коди генеруються в кожній базі окремо, тож той самий
            #    код у різних базах = різні корми (через це К2 ставав К4).
            prod_map: dict = {}
            tgt_code, tgt_bc, tgt_name = {}, {}, {}
            for r in conn.execute("SELECT id, code, barcode, name FROM products "
                                  "WHERE category='feed'").fetchall():
                if r["code"]:
                    tgt_code.setdefault(str(r["code"]), r["id"])
                if r["barcode"]:
                    tgt_bc.setdefault(str(r["barcode"]), r["id"])
                tgt_name.setdefault(self._norm_key(r["name"]), r["id"])
            for row in payload.get("products", []):
                oid = _i(row.get("old_id"))
                code = str(row.get("code") or "")
                bc = str(row.get("barcode") or "")
                ex = tgt_name.get(self._norm_key(row.get("name"))) \
                    or (tgt_bc.get(bc) if bc else None) \
                    or (tgt_code.get(code) if code else None)
                if ex:
                    # Наявний товар РЕАКТИВУЄМО й оновлюємо за джерелом: після
                    # «видалення» в інтерфейсі товар лишається в базі з
                    # is_active=0 — інакше склад після імпорту виглядав порожнім.
                    conn.execute(
                        "UPDATE products SET is_active=?, unit=?, min_stock=?, "
                        "pack_content=?, dose_unit=?, exclude_from_order=?, "
                        "notes=COALESCE(NULLIF(?,''), notes) WHERE id=?",
                        (_i(row.get("is_active")) if row.get("is_active") not in (None, "") else 1,
                         row.get("unit") or "кг", _f(row.get("min_stock")),
                         _f(row.get("pack_content")), row.get("dose_unit") or "",
                         _i(row.get("exclude_from_order")) or 0,
                         row.get("notes") or "", ex))
                    prod_map[oid] = ex
                    continue
                cur = conn.execute(
                    "INSERT INTO products(name, barcode, unit, min_stock, notes, "
                    "is_active, created_at, markup_pct, sale_price, code, category, "
                    "dose_unit, pack_content, exclude_from_order) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,'feed',?,?,?)",
                    (row.get("name"), row.get("barcode"), row.get("unit") or "кг",
                     _f(row.get("min_stock")), row.get("notes") or "",
                     _i(row.get("is_active")) if row.get("is_active") not in (None, "") else 1,
                     row.get("created_at") or now, _f(row.get("markup_pct")),
                     _f(row.get("sale_price")), code, row.get("dose_unit") or "",
                     _f(row.get("pack_content")),
                     _i(row.get("exclude_from_order")) or 0))
                # снапшот наявних НЕ поповнюємо — щоб легітимні дублі джерела
                # (напр. однаковий код) переносились 1:1, а не злипались.
                prod_map[oid] = cur.lastrowid; stats["products"] += 1

            # 4) блоки (upsert за name|herd_kind)
            blk_map: dict = {}
            tgt_blk = {}
            for r in conn.execute("SELECT id, name, herd_kind FROM blocks "
                                  "WHERE category='feed'").fetchall():
                tgt_blk.setdefault(self._norm_key(r["name"]) + "|" + (r["herd_kind"] or ""), r["id"])
            for row in payload.get("blocks", []):
                oid = _i(row.get("old_id"))
                key = self._norm_key(row.get("name")) + "|" + (row.get("herd_kind") or "")
                ex = tgt_blk.get(key)
                if ex:
                    # реактивуємо наявний блок (після «видалення» лишається is_active=0)
                    conn.execute(
                        "UPDATE blocks SET is_active=?, subgroup=COALESCE(NULLIF(?,''), subgroup) "
                        "WHERE id=?",
                        (_i(row.get("is_active")) if row.get("is_active") not in (None, "") else 1,
                         row.get("subgroup") or "", ex))
                    blk_map[oid] = ex
                    continue
                cur = conn.execute(
                    "INSERT INTO blocks(name, notes, is_active, category, created_at, "
                    "herd_kind, subgroup, herd_group_id) VALUES(?,?,?,'feed',?,?,?,NULL)",
                    (row.get("name"), row.get("notes") or "",
                     _i(row.get("is_active")) if row.get("is_active") not in (None, "") else 1,
                     row.get("created_at") or now, row.get("herd_kind") or "",
                     row.get("subgroup") or ""))
                blk_map[oid] = cur.lastrowid; tgt_blk[key] = cur.lastrowid
                stats["blocks"] += 1

            # 5) партії (1:1)
            batch_map: dict = {}
            for row in payload.get("batches", []):
                pid = prod_map.get(_i(row.get("product_old_id")))
                if pid is None:
                    continue
                cur = conn.execute(
                    "INSERT INTO stock_batches(product_id, lot_number, expires_on, qty, "
                    "created_at, price_in, price_out, price_in_no_vat, vat_rate, "
                    "markup_pct, invoice_number, invoice_date, receipt_date, "
                    "supplier_id, sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (pid, row.get("lot_number") or "", row.get("expires_on"),
                     _f(row.get("qty")), row.get("created_at") or now,
                     _f(row.get("price_in")), _f(row.get("price_out")),
                     _f(row.get("price_in_no_vat")), _f(row.get("vat_rate")),
                     _f(row.get("markup_pct")), row.get("invoice_number") or "",
                     row.get("invoice_date"), row.get("receipt_date"),
                     sup_id.get(self._norm_key(row.get("supplier_name"))),
                     _i(row.get("sort_order")) or 0))
                batch_map[_i(row.get("old_id"))] = cur.lastrowid; stats["batches"] += 1

            # 6) рухи (прихід/видача/списання) 1:1
            for row in payload.get("moves", []):
                pid = prod_map.get(_i(row.get("product_old_id")))
                if pid is None:
                    continue
                conn.execute(
                    "INSERT INTO stock_moves(product_id, batch_id, barcode, move_type, "
                    "qty, note, created_at, price, total, sale_no, cash_given, user_id, "
                    "original_sale_no, block_id, recipient_id, not_feed) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,NULL,?,?,?,?)",
                    (pid, batch_map.get(_i(row.get("batch_old_id"))),
                     row.get("barcode"), row.get("move_type") or "OUT",
                     _f(row.get("qty")), row.get("note") or "",
                     row.get("created_at") or now, _f(row.get("price")),
                     _f(row.get("total")), row.get("sale_no"),
                     _f(row.get("cash_given")), row.get("original_sale_no"),
                     blk_map.get(_i(row.get("block_old_id"))),
                     rcp_id.get(self._norm_key(row.get("recipient_name"))),
                     _i(row.get("not_feed")) or 0))
                stats["moves"] += 1

            # 7) виробництво КК 1:1
            fp_map: dict = {}
            for row in payload.get("productions", []):
                cur = conn.execute(
                    "INSERT INTO feed_productions(doc_no, prod_date, product_id, qty_out, "
                    "cost_total, price_per_kg, source, src_key, note, user_id, created_at, "
                    "cost_total_no_vat, price_per_kg_no_vat) "
                    "VALUES(?,?,?,?,?,?,?,?,?,NULL,?,?,?)",
                    (row.get("doc_no"), row.get("prod_date"),
                     prod_map.get(_i(row.get("product_old_id"))), _f(row.get("qty_out")),
                     _f(row.get("cost_total")), _f(row.get("price_per_kg")),
                     row.get("source") or "manual", row.get("src_key") or "",
                     row.get("note") or "", row.get("created_at") or now,
                     _f(row.get("cost_total_no_vat")), _f(row.get("price_per_kg_no_vat"))))
                fp_map[_i(row.get("old_id"))] = cur.lastrowid; stats["productions"] += 1
            for row in payload.get("production_lines", []):
                pn = fp_map.get(_i(row.get("production_old_id")))
                if pn is None:
                    continue
                conn.execute(
                    "INSERT INTO feed_production_lines(production_id, product_id, qty_plan, "
                    "qty_fact, price, cost, sort_order, cost_no_vat) VALUES(?,?,?,?,?,?,?,?)",
                    (pn, prod_map.get(_i(row.get("product_old_id"))),
                     _f(row.get("qty_plan")), _f(row.get("qty_fact")), _f(row.get("price")),
                     _f(row.get("cost")), _i(row.get("sort_order")) or 0,
                     _f(row.get("cost_no_vat"))))
                stats["production_lines"] += 1

            # 8) рух годівлі (заміси Profeed) + інгредієнти замісів
            for row in payload.get("feeding_events", []):
                if not _has("feeding_events"):
                    break
                conn.execute(
                    "INSERT OR REPLACE INTO feeding_events(src_key, op_date, group_label, "
                    "block_id, ration, kg_loaded, kg_loaded_all, kg_distributed, headcount, "
                    "plan_loaded, dry_loaded, plan_distributed, dry_distributed, leftover, "
                    "file_ts, mixer, created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (row.get("src_key"), row.get("op_date") or "",
                     row.get("group_label") or "",
                     blk_map.get(_i(row.get("block_old_id"))), row.get("ration") or "",
                     _f(row.get("kg_loaded")), _f(row.get("kg_loaded_all")),
                     _f(row.get("kg_distributed")), _f(row.get("headcount")),
                     _f(row.get("plan_loaded")), _f(row.get("dry_loaded")),
                     _f(row.get("plan_distributed")), _f(row.get("dry_distributed")),
                     _f(row.get("leftover")), row.get("file_ts") or "",
                     row.get("mixer") or "", row.get("created_at") or now))
                stats["feeding_events"] += 1
            for row in payload.get("feeding_event_ings", []):
                if not _has("feeding_event_ings"):
                    break
                conn.execute(
                    "INSERT INTO feeding_event_ings(src_key, name, code, plan, kg, dry) "
                    "VALUES(?,?,?,?,?,?)",
                    (row.get("src_key"), row.get("name") or "", row.get("code") or "",
                     _f(row.get("plan")), _f(row.get("kg")), _f(row.get("dry"))))
                stats["feeding_event_ings"] += 1

            # 9) залишки ЗМР + розподіл пулу (утилізація / перенесення групам) + молоко
            for row in payload.get("feeding_leftover", []):
                if not _has("feeding_leftover"):
                    break
                conn.execute(
                    "INSERT OR REPLACE INTO feeding_leftover(section, day, qty_kg, updated_at) "
                    "VALUES(?,?,?,?)",
                    (row.get("section") or "", row.get("day") or "",
                     _f(row.get("qty_kg")), row.get("updated_at") or now))
                stats["feeding_leftover"] += 1
            for row in payload.get("feeding_pool_dest", []):
                if not _has("feeding_pool_dest"):
                    break
                conn.execute(
                    "INSERT OR REPLACE INTO feeding_pool_dest(day, dest, qty) VALUES(?,?,?)",
                    (row.get("day") or "", row.get("dest") or "", _f(row.get("qty"))))
                stats["feeding_pool_dest"] += 1
            for row in payload.get("feeding_leftover_dest", []):
                if not _has("feeding_leftover_dest"):
                    break
                conn.execute(
                    "INSERT OR REPLACE INTO feeding_leftover_dest(section, day, dest, qty) "
                    "VALUES(?,?,?,?)",
                    (row.get("section") or "", row.get("day") or "",
                     row.get("dest") or "", _f(row.get("qty"))))
                stats["feeding_leftover_dest"] += 1
            for row in payload.get("feeding_milk", []):
                if not _has("feeding_milk"):
                    break
                conn.execute(
                    "INSERT OR REPLACE INTO feeding_milk(section, day, milk_kg) VALUES(?,?,?)",
                    (row.get("section") or "", row.get("day") or "",
                     _f(row.get("milk_kg"))))
                stats["feeding_milk"] += 1
        return stats

    @staticmethod
    def _norm_key(s) -> str:
        return " ".join(str(s or "").split()).casefold()

    def produce_combifeed(self, *, product_id: int, qty_out: float, components: list,
                          prod_date: str = "", note: str = "", source: str = "manual",
                          src_key: str = "", user_id: Optional[int] = None) -> dict[str, Any]:
        """Виробництво комбікорму: списати компоненти й оприбуткувати готовий КК.

        Компоненти списуються за FIFO за РЕАЛЬНИМИ цінами своїх партій —
        так собівартість комбікорму виходить фактичною, а не нормативною.
        Уся вартість компонентів ділиться на ФАКТИЧНИЙ випуск (qty_out), тому
        втрати при змішуванні автоматично лягають у ціну кілограма.
        src_key — ключ ідемпотентності (№ партії Profeed); повтор ігнорується."""
        qty_out = float(qty_out or 0)
        if qty_out <= 0:
            raise ValueError("Вкажіть фактично вироблену кількість (кг).")
        comps = [c for c in (components or []) if float(c.get("qty") or 0) > 0]
        if not comps:
            raise ValueError("Додайте хоча б один компонент із кількістю.")
        src_key = (src_key or "").strip()
        if src_key:
            with self._connect() as conn:
                if conn.execute("SELECT 1 FROM feed_productions WHERE src_key = ?",
                                (src_key,)).fetchone():
                    return {"skipped": True, "reason": "already_imported", "src_key": src_key}

        prod = self.get_product(product_id)
        if not prod:
            raise ValueError("Комбікорм не знайдено в довіднику.")
        prod_date = (prod_date or "").strip()[:10] or date.today().isoformat()
        doc_no = self.next_production_doc_no()
        now = self._now()
        created_at = f"{prod_date} {now[11:]}" if len(now) >= 19 else now

        # План зі зразка, перерахований на фактичний випуск — потрібен, щоб
        # порівняти із фактом завантаження й показати точність виготовлення.
        plan = {}
        rec = self.get_feed_recipe(product_id)
        if rec["batch_kg"]:
            k = qty_out / rec["batch_kg"]
            plan = {l["product_id"]: l["qty_kg"] * k for l in rec["lines"]}

        cost_total = 0.0
        cost_total_nv = 0.0
        line_costs: dict[int, list] = {}
        with self._connect() as conn:
            # 1) списуємо компоненти за FIFO, накопичуючи фактичну вартість
            for c in comps:
                pid = int(c["product_id"])
                need = float(c["qty"])
                line_costs[pid] = [need, 0.0, 0.0]  # [факт кг, вартість з ПДВ, без ПДВ]
                p = conn.execute("SELECT name, barcode FROM products WHERE id = ?",
                                 (pid,)).fetchone()
                if not p:
                    raise ValueError("Компонент не знайдено.")
                batches = conn.execute(
                    "SELECT id, qty, price_in, price_in_no_vat FROM stock_batches "
                    "WHERE product_id = ? AND qty > 0 "
                    "ORDER BY COALESCE(NULLIF(receipt_date,''), substr(created_at,1,10)), "
                    "created_at, id", (pid,)).fetchall()
                avail = sum(b["qty"] for b in batches)
                if avail + 1e-9 < need:
                    raise ValueError(
                        f"Недостатньо «{p['name']}»: потрібно {need:g}, є {avail:g}.")
                left = need
                for b in batches:
                    if left <= 1e-9:
                        break
                    use = min(left, b["qty"])
                    price = float(b["price_in"] or 0)
                    # якщо ціну без ПДВ не заповнили — вважаємо, що ПДВ немає
                    price_nv = float(b["price_in_no_vat"] or 0) or price
                    line_cost = use * price
                    cost_total += line_cost
                    cost_total_nv += use * price_nv
                    line_costs[pid][1] += line_cost
                    line_costs[pid][2] += use * price_nv
                    conn.execute("UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                                 (use, b["id"]))
                    conn.execute(
                        "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,"
                        " qty, note, created_at, price, total, user_id, sale_no) "
                        "VALUES (?,?,?,'OUT',?,?,?,?,?,?,?)",
                        (pid, b["id"], p["barcode"], use,
                         f"Виробництво КК «{prod['name']}» {doc_no}", created_at,
                         price, round(line_cost, 2), user_id, doc_no))
                    left = round(left - use, 6)

            price_per_kg = round(cost_total / qty_out, 6) if qty_out else 0.0
            price_per_kg_nv = round(cost_total_nv / qty_out, 6) if qty_out else 0.0
            # 2) оприбутковуємо готовий комбікорм окремою партією за собівартістю
            cur = conn.execute(
                "INSERT INTO stock_batches (product_id, qty, price_in, price_in_no_vat,"
                " vat_rate, price_out, lot_number, expires_on, supplier_id,"
                " invoice_number, invoice_date, receipt_date, created_at) "
                "VALUES (?,?,?,?,0,?,?,NULL,NULL,?,?,?,?)",
                (product_id, qty_out, price_per_kg, price_per_kg_nv, price_per_kg,
                 doc_no, doc_no, prod_date, prod_date, created_at))
            batch_id = cur.lastrowid
            conn.execute(
                "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,"
                " qty, note, created_at, price, total, user_id, sale_no) "
                "VALUES (?,?,?,'IN',?,?,?,?,?,?,?)",
                (product_id, batch_id, prod["barcode"], qty_out,
                 f"Виробництво комбікорму {doc_no}", created_at,
                 price_per_kg, round(cost_total, 2), user_id, doc_no))
            # 3) документ виробництва + склад партії (план зі зразка vs факт)
            prod_id = conn.execute(
                "INSERT INTO feed_productions (doc_no, prod_date, product_id, qty_out,"
                " cost_total, price_per_kg, cost_total_no_vat, price_per_kg_no_vat,"
                " source, src_key, note, user_id, created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (doc_no, prod_date, product_id, qty_out, round(cost_total, 2),
                 price_per_kg, round(cost_total_nv, 2), price_per_kg_nv,
                 source, src_key, note, user_id, created_at)).lastrowid
            for i, c in enumerate(comps):
                pid = int(c["product_id"])
                fact, cost, cost_nv = line_costs[pid]
                conn.execute(
                    "INSERT INTO feed_production_lines (production_id, product_id,"
                    " qty_plan, qty_fact, price, cost, cost_no_vat, sort_order) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (prod_id, pid, round(plan.get(pid, 0), 3), fact,
                     round(cost / fact, 6) if fact else 0, round(cost, 2),
                     round(cost_nv, 2), i))
        return {"doc_no": doc_no, "product": prod["name"], "qty_out": qty_out,
                "cost_total": round(cost_total, 2), "price_per_kg": price_per_kg,
                "cost_total_no_vat": round(cost_total_nv, 2),
                "price_per_kg_no_vat": price_per_kg_nv,
                "components": len(comps)}

    def dispense_stock(self, barcode: str, qty: float, note: str = "",
                       move_type: str = "OUT",
                       user_id: Optional[int] = None) -> dict[str, Any]:
        """Продаж (OUT) або списання (WRITE_OFF) — FIFO за датою приходу."""
        if move_type not in {"OUT", "WRITE_OFF"}:
            raise ValueError("Невірний тип операції.")
        product = self.get_product_by_barcode(barcode)
        if not product:
            raise ValueError("Товар зі штрихкодом не знайдено.")
        qty = float(qty or 0)
        if qty <= 0:
            raise ValueError("Кількість повинна бути більшою за 0.")
        if product["total_qty"] < qty:
            raise ValueError(
                f"Недостатньо залишку. На складі: {product['total_qty']:g} {product['unit']}."
            )
        remaining = qty
        total_sum = 0.0
        with self._connect() as conn:
            batches = conn.execute(
                """
                SELECT id, qty, price_in, price_out
                FROM stock_batches
                WHERE product_id = ? AND qty > 0
                ORDER BY COALESCE(NULLIF(receipt_date, ''), substr(created_at, 1, 10)), created_at, id
                """,
                (product["id"],),
            ).fetchall()
            for batch in batches:
                if remaining <= 0:
                    break
                used = min(remaining, batch["qty"])
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (used, batch["id"]),
                )
                price = batch["price_out"] if move_type == "OUT" else batch["price_in"]
                line_total = used * (price or 0)
                total_sum += line_total
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, qty,
                                             note, created_at, price, total, user_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (product["id"], batch["id"], product["barcode"], move_type, used,
                     (note or "").strip(), self._now(), price or 0, line_total, user_id),
                )
                remaining -= used
        return {
            "product": product,
            "qty": qty,
            "move_type": move_type,
            "total": round(total_sum, 2),
        }

    # ------------------------------------------------------------------ продаж чеком

    def process_sale(self, items: list[dict[str, Any]], move_type: str = "OUT",
                     note: str = "", cash_given: float = 0,
                     user_id: Optional[int] = None,
                     block_id: Optional[int] = None,
                     recipient_id: Optional[int] = None,
                     allow_negative: bool = False,
                     op_date: str = "") -> dict[str, Any]:
        """Проводить цілу операцію видачі/списання (кілька позицій) разом.

        items: [{barcode, qty, unit_price?}]
        block_id / recipient_id — куди і кому видано (для видачі на ферму).
        Вартість рахується за собівартістю партії (price_in), якщо ціну
        не передано явно. Робота за принципом «усе або нічого».
        """
        if move_type not in {"OUT", "WRITE_OFF"}:
            raise ValueError("Невірний тип операції.")
        if not items:
            raise ValueError("Чек порожній.")

        def _ref(val):
            try:
                return int(val) if val not in (None, "") else None
            except (TypeError, ValueError):
                return None

        # 1) Розбір і валідація позицій (блок/отримувач — на рівні позиції)
        lines: list[dict[str, Any]] = []
        need: dict[int, float] = {}
        for it in items:
            product = self.get_product_by_barcode(it.get("barcode", ""))
            if not product:
                raise ValueError(f"Товар «{it.get('barcode', '')}» не знайдено.")
            qty = float(it.get("qty") or 0)
            if qty <= 0:
                raise ValueError(f"Кількість для «{product['name']}» має бути більшою за 0.")
            raw_price = it.get("unit_price")
            unit_price = None
            if raw_price not in (None, ""):
                unit_price = float(raw_price)
            lines.append({
                "product": product,
                "qty": qty,
                "unit_price": unit_price,
                "block_id": _ref(it.get("block_id")) if it.get("block_id") not in (None, "") else block_id,
                "recipient_id": _ref(it.get("recipient_id")) if it.get("recipient_id") not in (None, "") else recipient_id,
                "not_feed": 1 if it.get("not_feed") else 0,
            })
            need[product["id"]] = need.get(product["id"], 0.0) + qty

        # 2) Перевірка залишку (сумарно по кожному товару).
        #    allow_negative=True (офлайн-синхронізація): не блокуємо, а лише
        #    позначаємо конфлікт «мінусовий залишок» (політика «провести й позначити»).
        conflict_negative = False
        for ln in lines:
            product = ln["product"]
            required = need[product["id"]]
            if product["total_qty"] < required - 1e-9:
                if allow_negative:
                    conflict_negative = True
                else:
                    raise ValueError(
                        f"Недостатньо «{product['name']}»: потрібно {required:g}, "
                        f"на складі {product['total_qty']:g} {product['unit']}."
                    )

        # 3) Проведення
        total_sum = 0.0
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COALESCE(MAX(CAST(sale_no AS INTEGER)), 0) "
                "FROM stock_moves WHERE sale_no <> ''"
            ).fetchone()
            sale_no = str(int(row[0]) + 1)

            # Дата операції: якщо передали op_date (YYYY-MM-DD) — беремо її + поточний
            # час (щоб порядок у межах дня був коректний); інакше — зараз.
            ts = self._now()
            d = str(op_date or "").strip()[:10]
            if d:
                try:
                    datetime.strptime(d, "%Y-%m-%d")
                    ts = d + datetime.now().strftime(" %H:%M:%S")
                except ValueError:
                    ts = self._now()

            for ln in lines:
                product = ln["product"]
                qty = ln["qty"]
                unit_price = ln["unit_price"]
                ln_block = ln["block_id"]
                ln_recipient = ln["recipient_id"]
                ln_not_feed = ln.get("not_feed") or 0
                remaining = qty
                batches = conn.execute(
                    """
                    SELECT id, qty, price_in, price_out
                    FROM stock_batches
                    WHERE product_id = ? AND qty > 0
                    ORDER BY COALESCE(NULLIF(receipt_date, ''), substr(created_at, 1, 10)), created_at, id
                    """,
                    (product["id"],),
                ).fetchall()
                for batch in batches:
                    if remaining <= 0:
                        break
                    used = min(remaining, batch["qty"])
                    conn.execute(
                        "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                        (used, batch["id"]),
                    )
                    # Некомерційна видача: вартість — за собівартістю партії
                    price = unit_price if unit_price is not None else (batch["price_in"] or 0)
                    line_total = used * (price or 0)
                    total_sum += line_total
                    conn.execute(
                        """
                        INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,
                                                 qty, note, created_at, price, total,
                                                 sale_no, cash_given, user_id,
                                                 block_id, recipient_id, not_feed)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (product["id"], batch["id"], product["barcode"], move_type,
                         used, (note or "").strip(), ts, price or 0,
                         line_total, sale_no, float(cash_given or 0), user_id,
                         ln_block, ln_recipient, ln_not_feed),
                    )
                    remaining -= used
                # Не вистачило партій (офлайн-політика): дозволяємо «мінус».
                # Залишок списуємо з останньої партії (вона піде в мінус), а
                # якщо партій немає — рухом без партії. Так видачу не втрачаємо.
                if allow_negative and remaining > 1e-9:
                    fb_id = batches[-1]["id"] if batches else None
                    if fb_id is not None:
                        conn.execute(
                            "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                            (remaining, fb_id))
                    price = unit_price if unit_price is not None else 0
                    line_total = remaining * (price or 0)
                    total_sum += line_total
                    conn.execute(
                        """
                        INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,
                                                 qty, note, created_at, price, total,
                                                 sale_no, cash_given, user_id,
                                                 block_id, recipient_id, not_feed)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (product["id"], fb_id, product["barcode"], move_type,
                         remaining, (note or "").strip(), ts, price or 0,
                         line_total, sale_no, float(cash_given or 0), user_id,
                         ln_block, ln_recipient, ln_not_feed),
                    )
                    remaining = 0
        return {
            "sale_no": sale_no,
            "move_type": move_type,
            "positions": len(lines),
            "total": round(total_sum, 2),
            "conflict": "negative_stock" if conflict_negative else "",
        }

    def apply_sync_ops(self, device_id: str, user_id: Optional[int],
                       ops: list[dict[str, Any]],
                       category: str = "pharmacy") -> dict[str, Any]:
        """Застосувати чергу офлайн-операцій з телефону (ідемпотентно).

        Кожна операція має op_id (UUID). Якщо op_id уже застосовано — повертаємо
        попередній результат (повторна відправка нічого не дублює). Підтримується
        тип 'sale' (видача/списання). Політика конфлікту — «провести й позначити»
        (allow_negative). Сервер присвоює канонічний sale_no."""
        results = []
        applied = duplicates = conflicts = rejected = 0
        for op in (ops or []):
            op_id = (str(op.get("op_id") or "")).strip()
            if not op_id:
                rejected += 1
                results.append({"op_id": "", "status": "rejected",
                                "error": "немає op_id"})
                continue
            # 1) ідемпотентність — чи вже застосовано
            with self._connect() as conn:
                prev = conn.execute(
                    "SELECT status, sale_no, conflict FROM sync_ops WHERE op_id = ?",
                    (op_id,)).fetchone()
            if prev:
                duplicates += 1
                results.append({"op_id": op_id, "status": prev["status"],
                                "sale_no": prev["sale_no"], "conflict": prev["conflict"],
                                "duplicate": True})
                continue
            # 2) застосування
            op_type = (op.get("type") or "").strip()
            payload = op.get("payload") or {}
            status, sale_no, conflict, err = "rejected", "", "", ""
            if op_type == "sale":
                try:
                    res = self.process_sale(
                        items=payload.get("items", []),
                        move_type=payload.get("move_type", "OUT"),
                        note=payload.get("note", ""),
                        user_id=user_id,
                        block_id=payload.get("block_id"),
                        recipient_id=payload.get("recipient_id"),
                        allow_negative=True)
                    sale_no = res.get("sale_no", "")
                    conflict = res.get("conflict", "")
                    status = "conflict" if conflict else "applied"
                except ValueError as exc:
                    status, err = "rejected", str(exc)
            elif op_type == "receipt":
                header = payload.get("header") or {}
                items = payload.get("items") or []
                added, errs = 0, []
                for it in items:
                    try:
                        self.receive_stock(
                            barcode=it.get("barcode", ""),
                            qty=float(it.get("qty") or 0),
                            lot_number=it.get("lot_number", ""),
                            expires_on=it.get("expires_on") or None,
                            price_in=float(it.get("price_in") or 0),
                            price_in_no_vat=float(it.get("price_in_no_vat") or 0),
                            vat_rate=float(it.get("vat_rate") or 0),
                            invoice_number=header.get("invoice_number", ""),
                            invoice_date=header.get("invoice_date", ""),
                            receipt_date=header.get("receipt_date", ""),
                            supplier_name=header.get("supplier_name", ""),
                            note=it.get("note", ""), user_id=user_id)
                        added += 1
                    except ValueError as exc:
                        errs.append(str(exc))
                if added and errs:
                    status, conflict = "conflict", ("; ".join(errs))[:200]
                elif added:
                    status = "applied"
                else:
                    status, err = "rejected", ("; ".join(errs))[:200] or "нічого не зараховано"
            elif op_type == "inventory":
                counts = payload.get("counts") or []
                changed, errs = 0, []
                for c in counts:
                    bc = (c.get("barcode") or "").strip()
                    try:
                        counted = float(c.get("qty") or 0)
                    except (TypeError, ValueError):
                        continue
                    prod = self.get_product_by_barcode(bc)
                    if not prod:
                        errs.append(bc + ": не знайдено")
                        continue
                    delta = counted - float(prod.get("total_qty") or 0)
                    if abs(delta) > 1e-9:
                        try:
                            self.adjust_stock(bc, delta, "Інвентаризація", user_id)
                            changed += 1
                        except ValueError as exc:
                            errs.append(bc + ": " + str(exc))
                if errs:
                    status, conflict = "conflict", ("; ".join(errs))[:200]
                else:
                    status = "applied"
            elif op_type == "new_product":
                # Створення нового (невідомого) товару, доданого офлайн.
                name = (payload.get("name") or "").strip()
                barcode = (payload.get("barcode") or "").strip()
                unit = (payload.get("unit") or "шт").strip() or "шт"
                if not name or not barcode:
                    status, err = "rejected", "потрібні назва і штрихкод"
                elif self.get_product_by_barcode(barcode):
                    status = "applied"          # вже існує — ідемпотентно
                else:
                    try:
                        self.add_product(name=name, barcode=barcode, unit=unit,
                                         min_stock=0, supplier="", notes="",
                                         category=(category or "pharmacy"))
                        status = "applied"
                    except Exception as exc:    # noqa: BLE001
                        msg = str(exc)
                        # штрихкод уже зайнятий між перевіркою і вставкою — теж ок
                        status = "applied" if "UNIQUE" in msg else "rejected"
                        if status == "rejected":
                            err = msg
            else:
                err = f"невідомий тип операції: {op_type}"
            # 3) журналюємо результат (для ідемпотентності й аудиту)
            with self._connect() as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO sync_ops (op_id, device_id, user_id, type, "
                    "status, sale_no, conflict, client_ts, applied_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (op_id, device_id, user_id, op_type, status, sale_no,
                     conflict or err, op.get("client_ts"), self._now()))
            if status == "applied":
                applied += 1
            elif status == "conflict":
                applied += 1
                conflicts += 1
            else:
                rejected += 1
            results.append({"op_id": op_id, "status": status, "sale_no": sale_no,
                            "conflict": conflict, "error": err})
        return {"results": results, "applied": applied, "duplicates": duplicates,
                "conflicts": conflicts, "rejected": rejected}

    def list_sync_conflicts(self, limit: int = 200) -> list[dict[str, Any]]:
        """Операції, що потребують уваги (конфлікт/відхилення)."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT s.op_id, s.type, s.status, s.sale_no, s.conflict, s.applied_at, "
                "u.username FROM sync_ops s LEFT JOIN users u ON u.id = s.user_id "
                "WHERE s.status IN ('conflict', 'rejected') "
                "ORDER BY s.applied_at DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(r) for r in rows]

    def count_sync_conflicts(self) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM sync_ops "
                "WHERE status IN ('conflict', 'rejected')").fetchone()
        return int(row["n"]) if row else 0

    def resolve_sync_conflict(self, op_id: str) -> bool:
        """Позначити конфлікт як опрацьований (зникає з переліку «Потребує уваги»).
        Рядок лишається для ідемпотентності — статус стає 'resolved'."""
        op_id = (op_id or "").strip()
        if not op_id:
            return False
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE sync_ops SET status = 'resolved' WHERE op_id = ? "
                "AND status IN ('conflict', 'rejected')", (op_id,))
            return cur.rowcount > 0

    def get_product_by_code(self, code: str) -> Optional[dict[str, Any]]:
        """Знайти товар за внутрішнім кодом (унікальним серед активних)."""
        c = (str(code or "")).strip()
        if not c:
            return None
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT p.id, p.name, p.barcode, p.code, p.unit, p.sale_price,
                       COALESCE(SUM(b.qty), 0) AS total_qty
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id
                WHERE p.code = ? AND p.is_active = 1
                GROUP BY p.id
                """,
                (c,),
            ).fetchone()
        return dict(row) if row else None

    def is_adjustment_note(self, note: str) -> bool:
        """True — якщо нота починається з префікса коригувального руху
        (Інвентаризація, Бій, Пересортиця, Прострочка, Розкрадання,
        Виявлення зайвого, Інше, Корекція)."""
        if not note:
            return False
        n = str(note)
        return any(n.startswith(p) for p in self._ADJUST_PREFIXES)

    def get_move_brief(self, move_id: int) -> Optional[dict[str, Any]]:
        """Короткі дані руху для журналу: товар, гілка, к-сть, примітка."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT p.name, p.category, m.qty, m.note "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "WHERE m.id = ?", (move_id,),
            ).fetchone()
        return dict(row) if row else None

    def get_move_user_id(self, move_id: int) -> Optional[int]:
        """Повертає user_id руху (або None, якщо руху немає чи user_id NULL)."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT user_id FROM stock_moves WHERE id = ?", (move_id,)
            ).fetchone()
        if not row:
            return None
        return row["user_id"]

    def undo_adjustment_move(self, move_id: int) -> dict[str, Any]:
        """Скасовує помилковий коригувальний рух (інвентаризація / бій / тощо).
        Повертає товар назад до партії (для WRITE_OFF) або знімає з партії
        (для IN). Дозволено лише для рухів з приміткою-підставою —
        реальні приходи й продажі не зачіпає."""
        with self._connect() as conn:
            move = conn.execute(
                "SELECT id, batch_id, qty, move_type, note "
                "FROM stock_moves WHERE id = ?", (move_id,),
            ).fetchone()
            if not move:
                raise ValueError("Рух не знайдено.")
            note = move["note"] or ""
            is_adj = any(note.startswith(p) for p in self._ADJUST_PREFIXES)
            if not is_adj:
                raise ValueError(
                    "Скасовувати можна лише коригувальні рухи "
                    "(інвентаризація, бій тощо).")
            if not move["batch_id"]:
                raise ValueError("Рух без партії — скасування неможливе.")
            qty = float(move["qty"] or 0)
            if move["move_type"] == "WRITE_OFF":
                # Повертаємо товар у партію
                conn.execute(
                    "UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                    (qty, move["batch_id"]))
            elif move["move_type"] == "IN":
                # Перевірка: чи вистачає у партії, щоб зняти назад
                cur_qty = conn.execute(
                    "SELECT qty FROM stock_batches WHERE id = ?",
                    (move["batch_id"],)).fetchone()
                have = float(cur_qty["qty"] if cur_qty else 0)
                if have + 1e-9 < qty:
                    raise ValueError(
                        f"Не можна скасувати: у партії лише {have:g}, "
                        f"а коригування додавало {qty:g}.")
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (qty, move["batch_id"]))
            else:
                raise ValueError(
                    f"Скасування для типу {move['move_type']} не підтримується.")
            conn.execute("DELETE FROM stock_moves WHERE id = ?", (move_id,))
        return {"move_id": move_id, "reversed_qty": qty}

    def adjust_batch(self, batch_id: int, *, delta: float,
                     reason_type: str, note: str = "",
                     user_id: Optional[int] = None) -> dict[str, Any]:
        """Коригування конкретної партії: списання (delta < 0) або додання
        (delta > 0). Підстава (reason_type) — інвентаризація, бій тощо.
        Використовує price_in саме цієї партії — собівартість обліку
        не «розмазується» по інших партіях."""
        delta = float(delta or 0)
        if abs(delta) < 1e-9:
            raise ValueError("Введіть ненульове значення.")
        reason_type = (reason_type or "").strip()
        if not reason_type:
            raise ValueError("Вкажіть підставу коригування.")
        note_full = reason_type
        if note and note.strip():
            note_full = f"{reason_type}: {note.strip()}"

        with self._connect() as conn:
            batch = conn.execute(
                "SELECT b.id, b.product_id, b.qty, b.price_in, p.name, p.barcode, "
                "       p.unit "
                "FROM stock_batches b JOIN products p ON p.id = b.product_id "
                "WHERE b.id = ?",
                (batch_id,),
            ).fetchone()
            if not batch:
                raise ValueError("Партію не знайдено.")
            price_in = float(batch["price_in"] or 0)

            if delta < 0:
                need = -delta
                if batch["qty"] + 1e-9 < need:
                    raise ValueError(
                        f"У партії лише {batch['qty']:g} {batch['unit']}, "
                        f"не можна списати {need:g}.")
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (need, batch_id))
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode,
                        move_type, qty, note, created_at, price, total, user_id)
                    VALUES (?, ?, ?, 'WRITE_OFF', ?, ?, ?, ?, ?, ?)
                    """,
                    (batch["product_id"], batch_id, batch["barcode"], need,
                     note_full, self._now(), price_in, need * price_in, user_id),
                )
            else:
                # додання — збільшуємо ту саму партію, рух IN
                conn.execute(
                    "UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                    (delta, batch_id))
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode,
                        move_type, qty, note, created_at, price, total, user_id)
                    VALUES (?, ?, ?, 'IN', ?, ?, ?, ?, ?, ?)
                    """,
                    (batch["product_id"], batch_id, batch["barcode"], delta,
                     note_full, self._now(), price_in, delta * price_in, user_id),
                )
        return {
            "batch_id": batch_id,
            "delta": delta,
            "reason_type": reason_type,
            "price_in": price_in,
            "sum": round(abs(delta) * price_in, 2),
        }

    def adjust_stock(self, barcode: str, delta: float, reason: str,
                     user_id: Optional[int] = None) -> dict[str, Any]:
        """Коригування залишків: позитивне (+) — додати в нову «корекційну»
        партію, негативне (–) — списати FIFO зі складу. Причина обовʼязкова —
        пишеться у примітку до руху."""
        product = self.get_product_by_barcode(barcode)
        if not product:
            raise ValueError("Товар зі штрихкодом не знайдено.")
        delta = float(delta or 0)
        if abs(delta) < 1e-9:
            raise ValueError("Введіть ненульове значення корекції.")
        reason = (reason or "").strip()
        if not reason:
            raise ValueError("Вкажіть причину корекції.")
        note = f"Корекція: {reason}"

        with self._connect() as conn:
            if delta > 0:
                # Додаємо нову партію з ціною = середня закупівельна (для
                # коректної собівартості). Якщо партій немає — беремо 0.
                avg = conn.execute(
                    "SELECT AVG(price_in) FROM stock_batches "
                    "WHERE product_id = ? AND price_in > 0",
                    (product["id"],),
                ).fetchone()[0] or 0
                sale_price = product.get("sale_price") or avg
                lot = f"КОР-{date.today().strftime('%Y%m%d')}"
                cur = conn.execute(
                    """
                    INSERT INTO stock_batches (
                        product_id, lot_number, expires_on, qty,
                        price_in, price_in_no_vat, price_out,
                        vat_rate, markup_pct,
                        invoice_number, invoice_date, receipt_date,
                        supplier_id, created_at
                    )
                    VALUES (?, ?, NULL, ?, ?, ?, ?, 0, 0, '', '', ?, NULL, ?)
                    """,
                    (product["id"], lot, delta, avg, avg, sale_price,
                     date.today().strftime("%Y-%m-%d"), self._now()),
                )
                batch_id = cur.lastrowid
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,
                                             qty, note, created_at, price, total, user_id)
                    VALUES (?, ?, ?, 'IN', ?, ?, ?, ?, ?, ?)
                    """,
                    (product["id"], batch_id, product["barcode"], delta,
                     note, self._now(), avg, delta * avg, user_id),
                )
                return {"delta": delta, "batch_id": batch_id, "type": "IN"}

            # Негативне — FIFO-списання
            need = -delta
            if product["total_qty"] < need - 1e-9:
                raise ValueError(
                    f"Недостатньо залишку. На складі: {product['total_qty']:g} "
                    f"{product['unit']}, треба списати {need:g}."
                )
            batches = conn.execute(
                """
                SELECT id, qty, price_in FROM stock_batches
                WHERE product_id = ? AND qty > 0
                ORDER BY COALESCE(NULLIF(receipt_date, ''), substr(created_at, 1, 10)), created_at, id
                """,
                (product["id"],),
            ).fetchall()
            remaining = need
            for batch in batches:
                if remaining <= 0:
                    break
                used = min(remaining, batch["qty"])
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (used, batch["id"]),
                )
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode, move_type,
                                             qty, note, created_at, price, total, user_id)
                    VALUES (?, ?, ?, 'WRITE_OFF', ?, ?, ?, ?, ?, ?)
                    """,
                    (product["id"], batch["id"], product["barcode"], used,
                     note, self._now(), batch["price_in"] or 0,
                     used * (batch["price_in"] or 0), user_id),
                )
                remaining -= used
            return {"delta": delta, "type": "WRITE_OFF"}

    def get_sale_returnable(self, sale_no: str) -> Optional[dict[str, Any]]:
        """Повертає чек продажу з полями original_qty / returned_qty /
        available_qty для кожного товару — для форми повернення."""
        sale_no = (sale_no or "").strip()
        if not sale_no:
            return None
        with self._connect() as conn:
            # Перевіряємо існування саме як продаж (OUT)
            head = conn.execute(
                """
                SELECT sale_no, MIN(created_at) AS created_at,
                       SUM(total) AS total
                FROM stock_moves
                WHERE sale_no = ? AND move_type = 'OUT'
                GROUP BY sale_no
                """,
                (sale_no,),
            ).fetchone()
            if not head:
                return None
            # Оригінальні позиції продажу (можуть бути в кількох партіях)
            rows = conn.execute(
                """
                SELECT m.product_id, m.batch_id, m.barcode, m.price,
                       SUM(m.qty) AS original_qty,
                       p.name, p.unit
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                WHERE m.sale_no = ? AND m.move_type = 'OUT'
                GROUP BY m.product_id, m.batch_id, m.price
                ORDER BY p.name
                """,
                (sale_no,),
            ).fetchall()
            items = []
            for r in rows:
                # Скільки вже повернуто з цієї партії за оригіналом
                returned = conn.execute(
                    """
                    SELECT COALESCE(SUM(qty), 0) AS q
                    FROM stock_moves
                    WHERE move_type = 'RETURN'
                      AND original_sale_no = ?
                      AND product_id = ?
                      AND COALESCE(batch_id, -1) = COALESCE(?, -1)
                    """,
                    (sale_no, r["product_id"], r["batch_id"]),
                ).fetchone()["q"]
                orig = float(r["original_qty"] or 0)
                ret = float(returned or 0)
                items.append({
                    "product_id": r["product_id"],
                    "batch_id": r["batch_id"],
                    "barcode": r["barcode"],
                    "name": r["name"],
                    "unit": r["unit"],
                    "price": float(r["price"] or 0),
                    "original_qty": orig,
                    "returned_qty": ret,
                    "available_qty": round(orig - ret, 4),
                })
        return {
            "sale_no": head["sale_no"],
            "created_at": head["created_at"],
            "total": float(head["total"] or 0),
            "items": items,
        }

    def process_return(self, original_sale_no: str,
                       items: list[dict[str, Any]],
                       note: str = "",
                       cash_given: float = 0,
                       user_id: Optional[int] = None) -> dict[str, Any]:
        """Повернення від клієнта, привʼязане до оригінального чека продажу.
        items: [{"product_id": ..., "batch_id": ..., "qty": ..., "price": ...}].
        Перевіряємо, що кількість не перевищує залишок «доступного для
        повернення» (original_qty − уже повернуто). Залишок повертається у
        ту саму партію, з якої був проданий."""
        original_sale_no = (original_sale_no or "").strip()
        if not original_sale_no:
            raise ValueError("Вкажіть номер чека продажу.")
        # Дістаємо чек з полем available_qty
        sale = self.get_sale_returnable(original_sale_no)
        if not sale:
            raise ValueError(
                f"Чек продажу №{original_sale_no} не знайдено.")
        if not items:
            raise ValueError("Виберіть хоча б одну позицію для повернення.")

        # Індексуємо доступне для перевірок (ключ = (product_id, batch_id))
        avail_idx: dict[tuple[int, Optional[int]], dict] = {}
        for ln in sale["items"]:
            avail_idx[(ln["product_id"], ln["batch_id"])] = ln

        # Валідація всіх рядків ДО запису у БД
        prepared: list[tuple[dict, float, float]] = []
        for it in items:
            try:
                pid = int(it.get("product_id"))
            except (TypeError, ValueError):
                raise ValueError("Невірний product_id у позиції повернення.")
            bid_raw = it.get("batch_id")
            bid = int(bid_raw) if bid_raw not in (None, "") else None
            qty = float(it.get("qty") or 0)
            if qty <= 0:
                continue   # тиха пропуск нульових
            key = (pid, bid)
            ref = avail_idx.get(key)
            if ref is None:
                raise ValueError(
                    "У оригінальному чеку немає такої позиції — "
                    "перевірте номер чека.")
            if qty > ref["available_qty"] + 1e-9:
                raise ValueError(
                    f"«{ref['name']}»: можна повернути не більше "
                    f"{ref['available_qty']:g} {ref['unit']}.")
            price_in = it.get("price")
            price = float(price_in) if price_in not in (None, "") else ref["price"]
            prepared.append((ref, qty, price))

        if not prepared:
            raise ValueError("Виберіть кількість для повернення хоча б однієї "
                             "позиції.")

        total_sum = 0.0
        with self._connect() as conn:
            # Нумерація — спільна з продажами (move_type вирізняє)
            row = conn.execute(
                "SELECT COALESCE(MAX(CAST(sale_no AS INTEGER)), 0) "
                "FROM stock_moves WHERE sale_no <> ''"
            ).fetchone()
            sale_no = str(int(row[0]) + 1)

            for ref, qty, price in prepared:
                # Повертаємо у ту ж саму партію, з якої був проданий товар.
                # Якщо batch_id оригінальної позиції відомий — використовуємо.
                # (батч міг бути вже видалений → перевіряємо існування.)
                batch_id = ref["batch_id"]
                if batch_id is not None:
                    exists = conn.execute(
                        "SELECT 1 FROM stock_batches WHERE id = ?",
                        (batch_id,),
                    ).fetchone()
                    if exists:
                        conn.execute(
                            "UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                            (qty, batch_id),
                        )
                    else:
                        batch_id = None
                if batch_id is None:
                    # партію видалили — створюємо нову «партію повернення»
                    lot = f"ПВ-{date.today().strftime('%Y%m%d')}"
                    cur = conn.execute(
                        """
                        INSERT INTO stock_batches (
                            product_id, lot_number, expires_on, qty,
                            price_in, price_in_no_vat, price_out,
                            vat_rate, markup_pct,
                            invoice_number, invoice_date, receipt_date,
                            supplier_id, created_at
                        )
                        VALUES (?, ?, NULL, ?, 0, 0, ?, 0, 0, '', '', ?, NULL, ?)
                        """,
                        (ref["product_id"], lot, qty, price,
                         date.today().strftime("%Y-%m-%d"), self._now()),
                    )
                    batch_id = cur.lastrowid

                line_total = qty * price
                total_sum += line_total
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode,
                        move_type, qty, note, created_at, price, total,
                        sale_no, cash_given, user_id, original_sale_no)
                    VALUES (?, ?, ?, 'RETURN', ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (ref["product_id"], batch_id, ref["barcode"], qty,
                     (note or "").strip(), self._now(), price, line_total,
                     sale_no, float(cash_given or 0), user_id,
                     original_sale_no),
                )
        return {
            "sale_no": sale_no,
            "original_sale_no": original_sale_no,
            "move_type": "RETURN",
            "positions": len(prepared),
            "total": round(total_sum, 2),
        }

    def undo_sale(self, sale_no: str) -> dict[str, Any]:
        """Відміняє операцію: повертає товар на склад і видаляє рухи.
        Для повернень (RETURN) — зворотна логіка: товар знову списується."""
        sale_no = str(sale_no or "").strip()
        if not sale_no:
            raise ValueError("Не вказано номер операції.")
        with self._connect() as conn:
            moves = conn.execute(
                "SELECT id, batch_id, qty, move_type FROM stock_moves "
                "WHERE sale_no = ? AND move_type IN ('OUT', 'WRITE_OFF', 'RETURN')",
                (sale_no,),
            ).fetchall()
            if not moves:
                raise ValueError("Операцію не знайдено.")
            for m in moves:
                if m["batch_id"]:
                    if m["move_type"] == "RETURN":
                        # Відмінити повернення → знову списати товар
                        conn.execute(
                            "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                            (m["qty"], m["batch_id"]),
                        )
                    else:
                        conn.execute(
                            "UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                            (m["qty"], m["batch_id"]),
                        )
                conn.execute("DELETE FROM stock_moves WHERE id = ?", (m["id"],))
        return {"sale_no": sale_no, "restored": len(moves)}

    def search_sales(self, *, sale_no: str = "", query: str = "",
                     limit: int = 200, category: Optional[str] = None) -> list[dict[str, Any]]:
        """Пошук операцій (OUT/WRITE_OFF/RETURN).
        - sale_no: точний збіг номера чека (вже без префікса «ВП-»).
        - query: LIKE-пошук по штрихкоду / назві / коду товару.
        Якщо обидва задані — використовуємо OR (точніший збіг по номеру + загальний пошук).
        Повертає такий самий формат, як recent_sales."""
        sale_no = (sale_no or "").strip()
        q = (query or "").strip()
        if not sale_no and not q:
            return []

        conditions = []
        params: list[Any] = []
        if sale_no:
            # Точний збіг номера чека або «починається з» — щоб «1» знайшло і «1», і «10», і «100»
            # Зробимо два варіанти: точний матч (пріоритет) + префіксний матч
            conditions.append("(m.sale_no = ? OR m.sale_no LIKE ?)")
            params.extend([sale_no, sale_no + "%"])
        if q:
            like = f"%{q.lower()}%"
            # ulower() — наш Unicode-aware LOWER (реєструється в _connect);
            # порівнюємо обидва боки в нижньому регістрі — щоб «Бровермектин»
            # знаходився по запиту «бровер» чи «БРОВЕР».
            conditions.append(
                "(ulower(m.barcode) LIKE ? OR ulower(p.name) LIKE ? "
                "OR ulower(p.code) LIKE ?)"
            )
            params.extend([like, like, like])

        where_clause = " OR ".join(conditions) if len(conditions) > 1 else conditions[0]
        cat_clause = " AND p.category = ?" if category else ""
        cat_params = [category] if category else []

        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT g.sale_no, g.move_type, g.created_at, g.qty, g.total,
                       g.positions, g.user_id, u.username AS user_login,
                       b.name AS block_name, b.herd_kind AS herd_kind,
                       rc.name AS recipient_name
                FROM (
                    SELECT m.sale_no, m.move_type,
                           MIN(m.created_at) AS created_at,
                           SUM(m.qty) AS qty,
                           SUM(m.total) AS total,
                           COUNT(DISTINCT m.product_id) AS positions,
                           MAX(m.user_id) AS user_id,
                           MAX(m.block_id) AS block_id,
                           MAX(m.recipient_id) AS recipient_id,
                           MAX(m.id) AS max_id
                    FROM stock_moves m
                    JOIN products p ON p.id = m.product_id
                    WHERE m.sale_no <> ''
                      AND m.move_type IN ('OUT', 'WRITE_OFF', 'RETURN')
                      AND ({where_clause}){cat_clause}
                    GROUP BY m.sale_no, m.move_type
                ) g
                LEFT JOIN users u ON u.id = g.user_id
                LEFT JOIN blocks b ON b.id = g.block_id
                LEFT JOIN recipients rc ON rc.id = g.recipient_id
                ORDER BY g.max_id DESC
                LIMIT ?
                """,
                params + cat_params + [int(limit)],
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                items = conn.execute(
                    """
                    SELECT p.name, m.barcode,
                           SUM(m.qty) AS qty, SUM(m.total) AS total,
                           SUM(m.total / (1 + COALESCE(bt.vat_rate, 0) / 100.0)) AS total_no_vat,
                           b.name AS block_name, rc.name AS recipient_name
                    FROM stock_moves m
                    JOIN products p ON p.id = m.product_id
                    LEFT JOIN stock_batches bt ON bt.id = m.batch_id
                    LEFT JOIN blocks b ON b.id = m.block_id
                    LEFT JOIN recipients rc ON rc.id = m.recipient_id
                    WHERE m.sale_no = ? AND m.move_type = ?
                    GROUP BY m.product_id, m.block_id, m.recipient_id
                    ORDER BY p.name
                    """,
                    (r["sale_no"], r["move_type"]),
                ).fetchall()
                d["items"] = [dict(x) for x in items]
                result.append(d)
        return result

    def recent_sales(self, limit: int = 25, category: Optional[str] = None,
                     date_from: str = "", date_to: str = "") -> list[dict[str, Any]]:
        """Останні операції продажу/списання, згруповані по чеку (sale_no)."""
        cat_clause = (" AND product_id IN (SELECT id FROM products WHERE category = ?)"
                      if category else "")
        params: list[Any] = [category] if category else []
        date_clause = ""
        if date_from:
            date_clause += " AND substr(created_at,1,10) >= ?"
            params.append(date_from)
        if date_to:
            date_clause += " AND substr(created_at,1,10) <= ?"
            params.append(date_to)
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT g.sale_no, g.move_type, g.created_at, g.qty, g.total,
                       g.positions, g.user_id, u.username AS user_login,
                       b.name AS block_name, b.herd_kind AS herd_kind,
                       rc.name AS recipient_name
                FROM (
                    SELECT sale_no, move_type,
                           MIN(created_at) AS created_at,
                           SUM(qty) AS qty,
                           SUM(total) AS total,
                           COUNT(DISTINCT product_id) AS positions,
                           MAX(user_id) AS user_id,
                           MAX(block_id) AS block_id,
                           MAX(recipient_id) AS recipient_id,
                           MAX(id) AS max_id
                    FROM stock_moves
                    WHERE sale_no <> '' AND move_type IN ('OUT', 'WRITE_OFF', 'RETURN')
                          AND sale_no NOT LIKE 'ВК-%'  -- виробництво КК не є видачею
                          AND sale_no NOT LIKE 'ГД-%'  -- годівля списується авто, не тут
                          {cat_clause}{date_clause}
                    GROUP BY sale_no, move_type
                ) g
                LEFT JOIN users u ON u.id = g.user_id
                LEFT JOIN blocks b ON b.id = g.block_id
                LEFT JOIN recipients rc ON rc.id = g.recipient_id
                ORDER BY g.max_id DESC
                LIMIT ?
                """,
                params + [limit],
            ).fetchall()
            result = []
            for r in rows:
                d = dict(r)
                items = conn.execute(
                    """
                    SELECT p.name, m.barcode,
                           SUM(m.qty) AS qty, SUM(m.total) AS total,
                           SUM(m.total / (1 + COALESCE(bt.vat_rate, 0) / 100.0)) AS total_no_vat,
                           b.name AS block_name, rc.name AS recipient_name
                    FROM stock_moves m
                    JOIN products p ON p.id = m.product_id
                    LEFT JOIN stock_batches bt ON bt.id = m.batch_id
                    LEFT JOIN blocks b ON b.id = m.block_id
                    LEFT JOIN recipients rc ON rc.id = m.recipient_id
                    WHERE m.sale_no = ?
                    GROUP BY m.product_id, m.block_id, m.recipient_id
                    ORDER BY p.name
                    """,
                    (r["sale_no"],),
                ).fetchall()
                d["items"] = [dict(x) for x in items]
                result.append(d)
        return result

    def get_sale(self, sale_no: str) -> Optional[dict[str, Any]]:
        """Повна інформація про одну операцію продажу/списання — для чека."""
        sale_no = str(sale_no or "").strip()
        if not sale_no:
            return None
        with self._connect() as conn:
            header = conn.execute(
                """
                SELECT m.sale_no, m.move_type, MIN(m.created_at) AS created_at,
                       SUM(m.qty) AS qty, SUM(m.total) AS total,
                       MAX(m.cash_given) AS cash_given,
                       MAX(m.user_id) AS user_id,
                       b.name AS block_name, rc.name AS recipient_name
                FROM stock_moves m
                LEFT JOIN blocks b ON b.id = m.block_id
                LEFT JOIN recipients rc ON rc.id = m.recipient_id
                WHERE m.sale_no = ? AND m.move_type IN ('OUT', 'WRITE_OFF', 'RETURN')
                GROUP BY m.sale_no
                """,
                (sale_no,),
            ).fetchone()
            if not header:
                return None
            items = conn.execute(
                """
                SELECT p.name, m.barcode, p.unit,
                       SUM(m.qty) AS qty, SUM(m.total) AS total
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                WHERE m.sale_no = ?
                GROUP BY m.product_id
                ORDER BY p.name
                """,
                (sale_no,),
            ).fetchall()
            note_row = conn.execute(
                "SELECT note FROM stock_moves WHERE sale_no = ? AND note <> '' LIMIT 1",
                (sale_no,),
            ).fetchone()
        d = dict(header)
        d["note"] = note_row["note"] if note_row else ""
        d["total"] = round(d["total"] or 0, 2)
        d["cash_given"] = round(d.get("cash_given") or 0, 2)
        d["change"] = round(max(0.0, d["cash_given"] - d["total"]), 2)
        d["items"] = []
        for it in items:
            x = dict(it)
            q = x["qty"] or 0
            x["price"] = round((x["total"] / q), 2) if q else 0
            x["total"] = round(x["total"] or 0, 2)
            d["items"].append(x)
        ca = d["created_at"] or ""
        d["date_display"] = (
            f"{ca[8:10]}.{ca[5:7]}.{ca[0:4]} {ca[11:16]}" if len(ca) >= 16 else ca
        )
        return d

    def get_sale_edit(self, sale_no: str) -> Optional[dict[str, Any]]:
        """Дані операції видачі/списання для редагування (блок/отримувач/примітка)."""
        sale_no = str(sale_no or "").strip()
        if not sale_no:
            return None
        with self._connect() as conn:
            header = conn.execute(
                "SELECT move_type, MIN(created_at) AS created_at, MAX(user_id) AS user_id "
                "FROM stock_moves WHERE sale_no = ? AND move_type IN ('OUT','WRITE_OFF') "
                "GROUP BY sale_no",
                (sale_no,),
            ).fetchone()
            if not header:
                return None
            rows = conn.execute(
                """
                SELECT m.product_id, p.name, m.barcode, SUM(m.qty) AS qty,
                       m.block_id, m.recipient_id,
                       bl.name AS block_name, bl.herd_kind AS herd_kind,
                       rc.name AS recipient_name
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                LEFT JOIN blocks bl ON bl.id = m.block_id
                LEFT JOIN recipients rc ON rc.id = m.recipient_id
                WHERE m.sale_no = ? AND m.move_type IN ('OUT','WRITE_OFF')
                GROUP BY m.product_id, m.block_id, m.recipient_id
                ORDER BY p.name
                """,
                (sale_no,),
            ).fetchall()
            note_row = conn.execute(
                "SELECT note FROM stock_moves WHERE sale_no = ? AND note <> '' LIMIT 1",
                (sale_no,),
            ).fetchone()
        d = dict(header)
        d["sale_no"] = sale_no
        d["note"] = note_row["note"] if note_row else ""
        d["positions"] = [dict(r) for r in rows]
        return d

    def _apply_position_qty(self, conn, sale_no: str, product_id: int, new_qty: float) -> None:
        """Змінити кількість позиції (товару) в операції видачі/списання,
        коригуючи залишки партій (FIFO). Зменшення — повертає товар у партії
        (з останніх рухів); збільшення — доспис із доступних партій за FIFO."""
        moves = conn.execute(
            "SELECT id, batch_id, qty, move_type, note, created_at, barcode, "
            "       price, user_id, block_id, recipient_id "
            "FROM stock_moves WHERE sale_no = ? AND product_id = ? "
            "AND move_type IN ('OUT','WRITE_OFF') ORDER BY id",
            (sale_no, int(product_id)),
        ).fetchall()
        if not moves:
            return
        old = round(sum(m["qty"] for m in moves), 4)
        new_qty = round(float(new_qty), 4)
        if new_qty <= 0:
            raise ValueError("Кількість має бути більшою за 0.")
        delta = round(new_qty - old, 6)
        if abs(delta) < 1e-9:
            return
        mtype = moves[0]["move_type"]
        tmpl = moves[0]

        if delta < 0:                                   # зменшення → повертаємо у партії
            ret = -delta
            for m in reversed(moves):                   # з останніх рухів
                if ret <= 1e-9:
                    break
                take = min(m["qty"], ret)
                if m["batch_id"]:
                    conn.execute("UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                                 (take, m["batch_id"]))
                left = round(m["qty"] - take, 4)
                price = m["price"] or 0
                if left <= 1e-9:
                    conn.execute("DELETE FROM stock_moves WHERE id = ?", (m["id"],))
                else:
                    conn.execute("UPDATE stock_moves SET qty = ?, total = ? WHERE id = ?",
                                 (left, round(left * price, 2), m["id"]))
                ret = round(ret - take, 6)
        else:                                           # збільшення → доспис FIFO
            need = delta
            batches = conn.execute(
                "SELECT id, qty, price_in, price_out FROM stock_batches "
                "WHERE product_id = ? AND qty > 0 "
                "ORDER BY COALESCE(NULLIF(receipt_date,''), substr(created_at,1,10)), created_at, id",
                (int(product_id),),
            ).fetchall()
            avail = round(sum(b["qty"] for b in batches), 4)
            if avail + 1e-9 < need:
                raise ValueError(f"Недостатньо залишку для збільшення: доступно {avail:g}.")
            for b in batches:
                if need <= 1e-9:
                    break
                use = min(need, b["qty"])
                conn.execute("UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                             (use, b["id"]))
                price = b["price_out"] if mtype == "OUT" else b["price_in"]
                exist = conn.execute(
                    "SELECT id, qty, price FROM stock_moves WHERE sale_no = ? "
                    "AND product_id = ? AND batch_id = ? AND move_type = ? LIMIT 1",
                    (sale_no, int(product_id), b["id"], mtype),
                ).fetchone()
                if exist:
                    nq = round(exist["qty"] + use, 4)
                    pr = exist["price"] if exist["price"] is not None else (price or 0)
                    conn.execute("UPDATE stock_moves SET qty = ?, total = ? WHERE id = ?",
                                 (nq, round(nq * (pr or 0), 2), exist["id"]))
                else:
                    conn.execute(
                        "INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, "
                        "qty, note, created_at, price, total, user_id, sale_no, block_id, recipient_id) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (int(product_id), b["id"], tmpl["barcode"], mtype, use,
                         tmpl["note"], tmpl["created_at"], price or 0,
                         round(use * (price or 0), 2), tmpl["user_id"], sale_no,
                         tmpl["block_id"], tmpl["recipient_id"]),
                    )
                need = round(need - use, 6)

    def update_sale_destinations(self, sale_no: str, positions: list,
                                 note: Optional[str] = None,
                                 op_date: Optional[str] = None) -> None:
        """Оновити блок/отримувача по позиціях видачі, примітку та (за бажанням)
        дату операції. Залишки не змінюються — лише призначення/дата."""
        sale_no = str(sale_no or "").strip()
        if not sale_no:
            raise ValueError("Не вказано номер операції.")

        def _ref(v):
            try:
                return int(v) if v not in (None, "") else None
            except (TypeError, ValueError):
                return None

        with self._connect() as conn:
            for p in (positions or []):
                pid = p.get("product_id")
                if pid is None:
                    continue
                # Зміна кількості (за наявності поля qty) — з коригуванням залишків
                # партій (FIFO). Виконуємо ДО оновлення блоку/отримувача, щоб нові
                # рухи теж потрапили під наступний UPDATE призначення.
                if p.get("qty") is not None:
                    try:
                        newq = float(p.get("qty"))
                    except (TypeError, ValueError):
                        newq = None
                    if newq is not None:
                        self._apply_position_qty(conn, sale_no, int(pid), newq)
                conn.execute(
                    "UPDATE stock_moves SET block_id = ?, recipient_id = ? "
                    "WHERE sale_no = ? AND product_id = ? "
                    "AND move_type IN ('OUT','WRITE_OFF')",
                    (_ref(p.get("block_id")), _ref(p.get("recipient_id")),
                     sale_no, int(pid)),
                )
            if note is not None:
                conn.execute(
                    "UPDATE stock_moves SET note = ? "
                    "WHERE sale_no = ? AND move_type IN ('OUT','WRITE_OFF')",
                    ((note or "").strip(), sale_no),
                )
            # Дата операції: міняємо лише день, час доби лишаємо (substr від 11-го
            # символу = " HH:MM:SS"), щоб порядок у межах дня не плутався.
            if op_date:
                d = str(op_date).strip()[:10]
                try:
                    datetime.strptime(d, "%Y-%m-%d")
                    conn.execute(
                        "UPDATE stock_moves SET created_at = ? || substr(created_at, 11) "
                        "WHERE sale_no = ? AND move_type IN ('OUT','WRITE_OFF')",
                        (d, sale_no),
                    )
                except ValueError:
                    pass

    # ------------------------------------------------------------------ редагування приходу

    @staticmethod
    def _user_note(full_note: str | None, invoice_number: str | None) -> str:
        """Витягує примітку користувача з move.note, відкидаючи префікс «Накл. X»."""
        note = (full_note or "")
        inv = (invoice_number or "").strip()
        if inv:
            tag = f"Накл. {inv}"
            if note == tag:
                return ""
            if note.startswith(tag + " | "):
                return note[len(tag) + 3:]
        return note

    def get_receipt_invoice(self, batch_id: int) -> Optional[dict[str, Any]]:
        """Прибуткова накладна за партією: усі позиції тієї ж накладної
        (той самий № + постачальник + дата приходу + гілка). Для друку."""
        with self._connect() as conn:
            base = conn.execute(
                "SELECT b.invoice_number, b.invoice_date, b.receipt_date, "
                "       b.supplier_id, b.created_at, p.category, s.name AS supplier "
                "FROM stock_batches b JOIN products p ON p.id = b.product_id "
                "LEFT JOIN suppliers s ON s.id = b.supplier_id WHERE b.id = ?",
                (batch_id,)).fetchone()
            if not base:
                return None
            bd = dict(base)
            rows = conn.execute(
                "SELECT p.name, p.code, p.barcode, p.unit, "
                "       b.lot_number, b.expires_on, b.price_in, b.price_in_no_vat, "
                "       b.vat_rate, b.sort_order, b.id AS batch_id, "
                "       COALESCE(m.qty, b.qty) AS qty "
                "FROM stock_batches b JOIN products p ON p.id = b.product_id "
                "LEFT JOIN stock_moves m ON m.batch_id = b.id AND m.move_type = 'IN' "
                "WHERE COALESCE(b.invoice_number,'') = ? "
                "  AND COALESCE(b.supplier_id,0) = ? "
                "  AND COALESCE(b.receipt_date,'') = ? AND p.category = ? "
                "ORDER BY b.sort_order, b.id",
                (bd.get("invoice_number") or "", bd.get("supplier_id") or 0,
                 bd.get("receipt_date") or "", bd.get("category"))).fetchall()
        items, sum_no_vat, sum_vat = [], 0.0, 0.0
        for r in rows:
            x = dict(r)
            qty = float(x.get("qty") or 0)
            pin = float(x.get("price_in") or 0)
            pinv = float(x.get("price_in_no_vat") or 0)
            rate = x.get("vat_rate")
            rate = rate if rate not in (None, "") else 20
            if not pinv and pin:
                pinv = round(pin / (1 + rate / 100), 4) if rate > 0 else pin
            x["price"] = round(pin, 2)
            x["price_no_vat"] = round(pinv, 4)
            x["sum_no_vat"] = round(qty * pinv, 2)
            x["total"] = round(qty * pin, 2)
            x["qty"] = qty
            sum_no_vat += x["sum_no_vat"]
            sum_vat += x["total"]
            items.append(x)
        ca = bd.get("created_at") or ""
        return {
            "invoice_number": bd.get("invoice_number") or "",
            "invoice_date": bd.get("invoice_date") or "",
            "receipt_date": bd.get("receipt_date") or (ca[:10] if ca else ""),
            "supplier": bd.get("supplier") or "",
            "items": items,
            "sum_no_vat": round(sum_no_vat, 2),
            "sum_with_vat": round(sum_vat, 2),
            "vat": round(sum_vat - sum_no_vat, 2),
        }

    def get_receipt(self, batch_id: int) -> Optional[dict[str, Any]]:
        """Повна інформація про прихід (партія + IN-рух + товар + постачальник)."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT b.id AS batch_id, b.product_id, b.lot_number, b.expires_on,
                       b.qty AS batch_qty, b.price_in, b.price_in_no_vat, b.price_out,
                       b.vat_rate, b.markup_pct, b.invoice_number, b.invoice_date,
                       b.receipt_date, b.supplier_id, b.created_at,
                       p.name AS product_name, p.barcode, p.unit, p.category,
                       s.name AS supplier_name,
                       m.id AS move_id, m.qty AS received_qty, m.note,
                       m.user_id AS user_id
                FROM stock_batches b
                JOIN products p ON p.id = b.product_id
                LEFT JOIN suppliers s ON s.id = b.supplier_id
                LEFT JOIN stock_moves m ON m.batch_id = b.id AND m.move_type = 'IN'
                WHERE b.id = ?
                """,
                (batch_id,),
            ).fetchone()
        if not row:
            return None
        d = dict(row)
        received = d["received_qty"] if d["received_qty"] is not None else d["batch_qty"]
        d["received_qty"] = received
        d["consumed_qty"] = round(received - d["batch_qty"], 4)
        d["user_note"] = self._user_note(d["note"], d["invoice_number"])
        # Націнку завжди виводимо від ціни закупки САМЕ цієї партії —
        # збережене значення могло бути усередненим по всьому товару.
        pin = d.get("price_in") or 0
        pout = d.get("price_out") or 0
        if pin > 0 and pout > 0:
            d["markup_pct"] = round((pout / pin - 1) * 100, 2)
        return d

    def update_receipt(
        self,
        batch_id: int,
        *,
        qty: float,
        lot_number: str = "",
        expires_on: str | None = None,
        price_in_no_vat: float = 0,
        price_in: float = 0,
        vat_rate: float = 20,
        markup_pct: float = 0,
        price_out: float = 0,
        invoice_number: str = "",
        invoice_date: str = "",
        receipt_date: str = "",
        supplier_name: str = "",
        note: str = "",
    ) -> dict[str, Any]:
        receipt = self.get_receipt(batch_id)
        if not receipt:
            raise ValueError("Прихід не знайдено.")

        qty = float(qty or 0)
        if qty <= 0:
            raise ValueError("Кількість має бути більшою за 0.")

        consumed = receipt["consumed_qty"]
        if qty < consumed - 1e-9:
            raise ValueError(
                f"З цієї партії вже списано {consumed:g} {receipt['unit']}. "
                f"Зменшити прихід нижче цього обсягу не можна."
            )
        new_batch_qty = round(qty - consumed, 4)

        vat_rate = float(vat_rate or 0)
        markup_pct = float(markup_pct or 0)
        price_in_no_vat = float(price_in_no_vat or 0)
        price_in = float(price_in or 0)
        price_out = float(price_out or 0)

        # добиваємо відсутню ціну за ставкою ПДВ
        if price_in and not price_in_no_vat and vat_rate > 0:
            price_in_no_vat = round(price_in / (1 + vat_rate / 100), 4)
        elif price_in_no_vat and not price_in:
            price_in = round(price_in_no_vat * (1 + vat_rate / 100), 4)
        if not price_out and price_in and markup_pct:
            price_out = round(price_in * (1 + markup_pct / 100), 2)
        if price_out and price_in and not markup_pct:
            markup_pct = round((price_out / price_in - 1) * 100, 2)

        # Ціни — необов'язкові (некомерційна аптека)
        if price_in_no_vat <= 0 and price_in > 0:
            price_in_no_vat = price_in
        if not (receipt_date or "").strip():
            raise ValueError("Вкажіть фактичну дату приходу.")
        if not (supplier_name or "").strip():
            raise ValueError("Вкажіть постачальника.")
        if not (invoice_number or "").strip():
            raise ValueError("Вкажіть номер накладної.")

        supplier_id = (self.get_or_create_supplier(
            supplier_name, category=receipt.get("category", "pharmacy"))
            if supplier_name else None)

        move_note = (note or "").strip()
        if invoice_number:
            tag = f"Накл. {invoice_number.strip()}"
            move_note = f"{tag} | {move_note}" if move_note else tag

        with self._connect() as conn:
            conn.execute(
                """
                UPDATE stock_batches SET
                    lot_number = ?, expires_on = ?, qty = ?,
                    price_in = ?, price_in_no_vat = ?, price_out = ?,
                    vat_rate = ?, markup_pct = ?,
                    invoice_number = ?, invoice_date = ?, receipt_date = ?,
                    supplier_id = ?
                WHERE id = ?
                """,
                (
                    (lot_number or "").strip(), (expires_on or None), new_batch_qty,
                    price_in, price_in_no_vat, price_out,
                    vat_rate, markup_pct,
                    (invoice_number or "").strip(), (invoice_date or "").strip(),
                    (receipt_date or "").strip(),
                    supplier_id, batch_id,
                ),
            )
            conn.execute(
                """
                UPDATE stock_moves
                SET qty = ?, price = ?, total = ?, note = ?
                WHERE batch_id = ? AND move_type = 'IN'
                """,
                (qty, price_in, round(qty * price_in, 4), move_note, batch_id),
            )
            # Ціна продажу — головна: застосовуємо до всіх партій товару
            self._apply_product_sale_price(conn, receipt["product_id"], price_out)
        return {"batch_id": batch_id, "qty": qty, "batch_qty": new_batch_qty}

    def update_invoice_header(self, batch_ids: list, *, supplier_name: str = "",
                              invoice_number: str = "", invoice_date: str = "",
                              receipt_date: str = "") -> dict[str, Any]:
        """Скоригувати шапку накладної для ВСІХ її позицій одразу: постачальник,
        номер, дата накладної, фактична дата приходу. Оновлює партії й тег
        «Накл.» у примітках приходів (кількість/ціни не чіпаємо)."""
        ids = []
        for b in (batch_ids or []):
            try:
                ids.append(int(b))
            except (TypeError, ValueError):
                pass
        if not ids:
            raise ValueError("Немає позицій накладної.")
        invoice_number = (invoice_number or "").strip()
        if not invoice_number:
            raise ValueError("Вкажіть номер накладної.")
        receipt_date = (receipt_date or "").strip()[:10]
        if not receipt_date:
            raise ValueError("Вкажіть фактичну дату приходу.")
        invoice_date = (invoice_date or "").strip()[:10]
        supplier_name = (supplier_name or "").strip()
        if not supplier_name:
            raise ValueError("Вкажіть постачальника.")
        rec = self.get_receipt(ids[0])
        cat = (rec.get("category") if rec else "pharmacy") or "pharmacy"
        supplier_id = self.get_or_create_supplier(supplier_name, category=cat)
        tag = f"Накл. {invoice_number}"
        ph = ",".join(["?"] * len(ids))
        with self._connect() as conn:
            conn.execute(
                f"UPDATE stock_batches SET invoice_number=?, invoice_date=?, "
                f"receipt_date=?, supplier_id=? WHERE id IN ({ph})",
                [invoice_number, invoice_date, receipt_date, supplier_id] + ids)
            for bid in ids:
                m = conn.execute("SELECT id, note FROM stock_moves "
                                 "WHERE batch_id=? AND move_type='IN'", (bid,)).fetchone()
                if not m:
                    continue
                note = m["note"] or ""
                if "|" in note:
                    user = note.split("|", 1)[1].strip()
                elif note.startswith("Накл."):
                    user = ""
                else:
                    user = note
                conn.execute("UPDATE stock_moves SET note=? WHERE id=?",
                             (f"{tag} | {user}" if user else tag, m["id"]))
        return {"updated": len(ids), "invoice_number": invoice_number,
                "supplier": supplier_name}

    def delete_receipt(self, batch_id: int) -> None:
        receipt = self.get_receipt(batch_id)
        if not receipt:
            raise ValueError("Прихід не знайдено.")
        if receipt["consumed_qty"] > 1e-9:
            raise ValueError(
                f"З цієї партії вже відпущено {receipt['consumed_qty']:g} {receipt['unit']}. "
                f"Видалити прихід неможливо — спочатку скасуйте відповідні продажі/списання."
            )
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM stock_moves WHERE batch_id = ? AND move_type = 'IN'",
                (batch_id,),
            )
            conn.execute("DELETE FROM stock_batches WHERE id = ?", (batch_id,))

    # ------------------------------------------------------------------ reports

    def recent_moves(self, limit: int = 30, move_type: str | None = None,
                     category: Optional[str] = None) -> list[dict[str, Any]]:
        params: list[Any] = []
        sql = (
            "SELECT m.id, m.batch_id, m.created_at, p.name, m.barcode, m.move_type, m.qty, "
            "       m.note, b.lot_number, m.price, m.total "
            "FROM stock_moves m "
            "JOIN products p ON p.id = m.product_id "
            "LEFT JOIN stock_batches b ON b.id = m.batch_id "
        )
        conds = []
        if move_type:
            conds.append("m.move_type = ?")
            params.append(move_type)
        if category:
            conds.append("p.category = ?")
            params.append(category)
        if conds:
            sql += "WHERE " + " AND ".join(conds) + " "
        sql += "ORDER BY m.id DESC LIMIT ?"
        params.append(int(limit))
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def low_stock(self) -> list[dict[str, Any]]:
        return [p for p in self.list_products() if p["total_qty"] <= p["min_stock"]]

    def expiring_batches(self, days: int = 60, category: Optional[str] = None) -> list[dict[str, Any]]:
        threshold = (date.today() + timedelta(days=days)).strftime("%Y-%m-%d")
        today = date.today().strftime("%Y-%m-%d")
        cat_clause = " AND p.category = ?" if category else ""
        cat_params = [category] if category else []
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT b.id, b.lot_number, b.expires_on, b.qty,
                       p.id AS product_id, p.name, p.barcode, p.unit
                FROM stock_batches b
                JOIN products p ON p.id = b.product_id
                WHERE b.qty > 0
                  AND b.expires_on IS NOT NULL
                  AND b.expires_on <> ''
                  AND b.expires_on <= ?{cat_clause}
                ORDER BY b.expires_on ASC
                """,
                [threshold] + cat_params,
            ).fetchall()
        result = []
        for r in rows:
            item = dict(r)
            item["expired"] = item["expires_on"] < today
            try:
                d = datetime.strptime(item["expires_on"], "%Y-%m-%d").date()
                item["days_left"] = (d - date.today()).days
            except (ValueError, TypeError):
                item["days_left"] = None
            result.append(item)
        return result

    def list_receipt_invoices(self, limit_invoices: int = 500,
                              category: Optional[str] = None,
                              date_from: str = "", date_to: str = ""
                              ) -> list[dict[str, Any]]:
        """Надходження, згруповані за накладною (постачальник + № + дата).
        Кожна накладна містить items — позиції з повною інформацією.
        Фільтр дати — за фактичною датою приходу (або датою руху, якщо її немає)."""
        cat_clause = " AND p.category = ?" if category else ""
        params: list[Any] = [category] if category else []
        # ефективна дата приходу для фільтра
        eff_date = "COALESCE(NULLIF(b.receipt_date, ''), substr(m.created_at, 1, 10))"
        date_clause = ""
        if date_from:
            date_clause += f" AND {eff_date} >= ?"
            params.append(date_from)
        if date_to:
            date_clause += f" AND {eff_date} <= ?"
            params.append(date_to)
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT m.id AS move_id, m.batch_id, m.created_at,
                       m.qty AS received_qty, m.user_id,
                       p.id AS product_id, p.name, p.code, p.barcode, p.unit,
                       b.lot_number, b.expires_on, b.price_in, b.price_in_no_vat,
                       b.vat_rate, b.invoice_number, b.invoice_date, b.receipt_date,
                       b.qty AS batch_qty, b.sort_order,
                       s.name AS supplier,
                       u.username AS user_login
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                LEFT JOIN stock_batches b ON b.id = m.batch_id
                LEFT JOIN suppliers s ON s.id = b.supplier_id
                LEFT JOIN users u ON u.id = m.user_id
                WHERE m.move_type = 'IN'
                      -- виробництво КК оприбутковується IN-рухом, але це не
                      -- прихід: корм не купили, а зробили з наявних
                      AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%')
                      {cat_clause}{date_clause}
                ORDER BY m.id DESC
                """,
                params,
            ).fetchall()
        invoices: dict[tuple, dict[str, Any]] = {}
        order: list[tuple] = []
        for r in rows:
            d = dict(r)
            pin = d.get("price_in") or 0
            pinv = d.get("price_in_no_vat") or 0
            rate = d.get("vat_rate")
            rate = rate if rate not in (None, "") else 20
            if not pinv and pin:
                pinv = round(pin / (1 + rate / 100), 4) if rate > 0 else pin
            qty = d.get("received_qty") or 0
            d["price"] = pin                       # ціна закупки з ПДВ (для деталей)
            d["total"] = round(qty * pin, 2)       # сума з ПДВ (для деталей)
            d["line_sum_no_vat"] = round(qty * pinv, 2)
            key = (d.get("invoice_number") or "", d.get("supplier") or "",
                   d.get("receipt_date") or "")
            inv = invoices.get(key)
            if inv is None:
                inv = {
                    "invoice_number": d.get("invoice_number") or "",
                    "supplier": d.get("supplier") or "",
                    "receipt_date": d.get("receipt_date") or "",
                    "invoice_date": d.get("invoice_date") or "",
                    "created_at": d.get("created_at"),
                    "positions": 0,
                    "sum_no_vat": 0.0,
                    "sum_with_vat": 0.0,
                    "items": [],
                }
                invoices[key] = inv
                order.append(key)
            inv["items"].append(d)
            inv["positions"] += 1
            inv["sum_no_vat"] += d["line_sum_no_vat"]
            inv["sum_with_vat"] += d["total"]
        result = []
        for key in order[:limit_invoices]:
            inv = invoices[key]
            inv["sum_no_vat"] = round(inv["sum_no_vat"], 2)
            inv["sum_with_vat"] = round(inv["sum_with_vat"], 2)
            # Порядок позицій: якщо задано ручний (sort_order>0) — за ним,
            # інакше — у порядку додавання (за batch_id/move_id).
            if any((it.get("sort_order") or 0) > 0 for it in inv["items"]):
                inv["items"].sort(key=lambda it: (it.get("sort_order") or 0,
                                                  it.get("batch_id") or 0))
            else:
                inv["items"].sort(key=lambda it: (it.get("batch_id") or it.get("move_id") or 0))
            result.append(inv)
        return result

    def set_batch_order(self, batch_ids: list) -> None:
        """Зберегти ручний порядок позицій накладної (1-based індекси)."""
        with self._connect() as conn:
            for i, bid in enumerate(batch_ids or [], start=1):
                try:
                    conn.execute(
                        "UPDATE stock_batches SET sort_order = ? WHERE id = ?",
                        (i, int(bid)))
                except (TypeError, ValueError):
                    continue

    def stock_as_of(self, date_str: str, category: Optional[str] = None) -> list[dict[str, Any]]:
        """Залишки на складі станом на кінець заданої дати (YYYY-MM-DD).
        Кількість і сума (грн з ПДВ) рахуються з рухів за чистим балансом:
        IN/RETURN додають, OUT/WRITE_OFF віднімають — так само, як у звіті руху,
        тож «залишок на кінець» в обох звітах збігається."""
        d = (date_str or "").strip()[:10] or date.today().strftime("%Y-%m-%d")
        cat_clause = " AND p.category = ?" if category else ""
        cat_params = [category] if category else []
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT p.id, p.name, p.code, p.barcode, p.unit, p.min_stock,
                  COALESCE(SUM(CASE
                      WHEN m.move_type IN ('IN','RETURN') THEN m.qty
                      WHEN m.move_type IN ('OUT','WRITE_OFF') THEN -m.qty
                      ELSE 0 END), 0) AS qty,
                  COALESCE(SUM(CASE
                      WHEN m.move_type IN ('IN','RETURN') THEN m.total
                      WHEN m.move_type IN ('OUT','WRITE_OFF') THEN -m.total
                      ELSE 0 END), 0) AS val
                FROM products p
                LEFT JOIN stock_moves m
                       ON m.product_id = p.id AND substr(m.created_at, 1, 10) <= ?
                WHERE p.is_active = 1{cat_clause}
                GROUP BY p.id
                ORDER BY p.name COLLATE NOCASE
                """,
                [d] + cat_params,
            ).fetchall()
        result = []
        for r in rows:
            qty = round(float(r["qty"] or 0), 4)
            if self._is_water(r["name"]):     # вода необмежена — залишок завжди 0
                qty = 0.0
            if qty <= 0:
                continue
            val = round(float(r["val"] or 0), 2)
            avg = round(val / qty, 4) if qty else 0
            result.append({
                "name": r["name"], "code": r["code"], "barcode": r["barcode"],
                "unit": r["unit"], "min_stock": r["min_stock"],
                "total_qty": qty,
                "avg_price_in": avg,
                "stock_value": val,
            })
        return result

    def stock_movement_report(self, date_from: str, date_to: str,
                              category: Optional[str] = None) -> list[dict[str, Any]]:
        """Звіт руху ветпрепаратів за період [from..to].
        По кожному товару: залишок на початок, надходження, видача+списання,
        залишок на кінець — кількість і сума (грн з ПДВ).
        Надходження = IN+RETURN; видача+списання = OUT+WRITE_OFF."""
        f = (date_from or "").strip()[:10] or "0000-01-01"
        t = (date_to or "").strip()[:10] or date.today().strftime("%Y-%m-%d")
        cat_clause = " AND p.category = ?" if category else ""
        cat_params = [category] if category else []
        with self._connect() as conn:
            rows = conn.execute(
                f"""
                SELECT p.id, p.name, p.code, p.barcode, p.unit,
                  COALESCE(SUM(CASE WHEN d < ? AND mt IN ('IN','RETURN') THEN qty
                                    WHEN d < ? AND mt IN ('OUT','WRITE_OFF') THEN -qty
                                    ELSE 0 END), 0) AS open_qty,
                  COALESCE(SUM(CASE WHEN d < ? AND mt IN ('IN','RETURN') THEN total
                                    WHEN d < ? AND mt IN ('OUT','WRITE_OFF') THEN -total
                                    ELSE 0 END), 0) AS open_val,
                  COALESCE(SUM(CASE WHEN d >= ? AND d <= ? AND mt IN ('IN','RETURN') THEN qty ELSE 0 END), 0) AS in_qty,
                  COALESCE(SUM(CASE WHEN d >= ? AND d <= ? AND mt IN ('IN','RETURN') THEN total ELSE 0 END), 0) AS in_val,
                  COALESCE(SUM(CASE WHEN d >= ? AND d <= ? AND mt IN ('OUT','WRITE_OFF') THEN qty ELSE 0 END), 0) AS out_qty,
                  COALESCE(SUM(CASE WHEN d >= ? AND d <= ? AND mt IN ('OUT','WRITE_OFF') THEN total ELSE 0 END), 0) AS out_val
                FROM products p
                LEFT JOIN (
                    SELECT sm.product_id, sm.move_type AS mt, sm.qty, sm.total,
                           -- ефективна дата руху: для приходу — дата ПРИХОДУ
                           -- партії (а не коли внесли запис); для видачі/списання
                           -- — дата операції (created_at = дата видачі/годівлі)
                           CASE WHEN sm.move_type IN ('IN','RETURN')
                                THEN COALESCE(NULLIF(sb.receipt_date, ''),
                                              substr(sm.created_at, 1, 10))
                                ELSE substr(sm.created_at, 1, 10) END AS d
                    FROM stock_moves sm
                    LEFT JOIN stock_batches sb ON sb.id = sm.batch_id
                ) m ON m.product_id = p.id
                WHERE p.is_active = 1{cat_clause}
                GROUP BY p.id
                ORDER BY p.name COLLATE NOCASE
                """,
                [f, f, f, f, f, t, f, t, f, t, f, t] + cat_params,
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            oq, ov = float(d["open_qty"]), float(d["open_val"])
            iq, iv = float(d["in_qty"]), float(d["in_val"])
            uq, uv = float(d["out_qty"]), float(d["out_val"])
            # Вода необмежена: залишок завжди 0, показуємо лише розхід. Надходження
            # = розхід (подається за потребою), суми — 0 (вода безкоштовна).
            if str(d["name"]).strip().lower() in self._WATER_NAMES:
                oq = ov = 0.0
                iq = uq                 # надходження = розхід
                iv = uv = ov = 0.0
            cq, cv = oq + iq - uq, ov + iv - uv
            # пропускаємо товари без залишків і без руху в періоді
            if abs(oq) < 1e-9 and abs(iq) < 1e-9 and abs(uq) < 1e-9 and abs(cq) < 1e-9:
                continue
            result.append({
                "name": d["name"], "code": d["code"], "barcode": d["barcode"], "unit": d["unit"],
                "open_qty": round(oq, 3), "open_val": round(ov, 2),
                "in_qty": round(iq, 3), "in_val": round(iv, 2),
                "out_qty": round(uq, 3), "out_val": round(uv, 2),
                "close_qty": round(cq, 3), "close_val": round(cv, 2),
            })
        return result

    def self_check(self) -> dict[str, Any]:
        """Самоперевірка обчислень: годівля (ЗМР/залишки) і склад (залишки/суми).
        Повертає перелік перевірок зі статусом ok/warn/fail, деталями та, де
        доречно, очікуваним/фактичним значенням. Нічого не змінює."""
        checks: list[dict[str, Any]] = []

        def add(group, name, status, detail="", expected=None, actual=None):
            checks.append({"group": group, "name": name, "status": status,
                           "detail": detail, "expected": expected, "actual": actual})

        def clip(items, n=5):
            xs = list(items)
            s = "; ".join(xs[:n])
            if len(xs) > n:
                s += f" … (+{len(xs) - n})"
            return s

        TOL = 1.0  # допуск, кг/грн (округлення)

        # ---------- Годівля (ЗМР / залишки) ----------
        try:
            tree = self.feeding_tree("feed", "", "")
            secs = tree.get("sections") or []
            if tree.get("error"):
                add("Годівля", "Дані годівлі", "warn", str(tree["error"]))
            elif not secs:
                add("Годівля", "Дані годівлі", "ok",
                    "Немає даних для перевірки (порожньо).")
            else:
                # 1) Залишок ЗМР ≤ роздача
                bad, frac = [], []
                for s in secs:
                    for d in s.get("days", []):
                        lo = d.get("leftover") or 0
                        di = d.get("distributed") or 0
                        if lo > di + 0.5:
                            bad.append(f"{d['section']} {d['date']}: {lo}>{di}")
                        if abs(lo - round(lo)) > 1e-6:
                            frac.append(f"{d['section']} {d['date']}: {lo} кг")
                add("Годівля", "Залишок ЗМР ≤ роздача",
                    "fail" if bad else "ok",
                    clip(bad) if bad else "Усі залишки в межах роздачі.")
                add("Годівля", "Залишки — цілі кілограми",
                    "warn" if frac else "ok",
                    clip(frac) if frac else "Усі залишки — цілі числа.")

                # 2) Спожито = завантажено − утилізація (інваріант пулу).
                # Спожито рахується від ЗАВАНТАЖЕНОГО (loaded − залишок + перенос),
                # тож і звіряємо із завантаженим, а не з роздачею.
                pool_dest = tree.get("pool_dest") or {}
                pool_kg = tree.get("pool_kg") or {}
                tot_cons = sum(s.get("consumed") or 0 for s in secs)
                tot_loaded = sum(s.get("loaded") or 0 for s in secs)
                disposal = sum((x.get("qty") or 0)
                               for lst in pool_dest.values() for x in lst
                               if x.get("dest") == self.FEED_DISPOSAL)
                expct = round(tot_loaded - disposal, 1)
                actl = round(tot_cons, 1)
                add("Годівля", "Спожито = завантажено − утилізація",
                    "fail" if abs(actl - expct) > TOL else "ok",
                    f"завантажено {round(tot_loaded, 1)} − утилізація {round(disposal, 1)}",
                    expct, actl)

                # 3) Пул залишків повністю й коректно розподілений: не менше
                # (нерозподілено) і не більше (перероздано) за зібраний пул.
                unalloc = over_alloc = 0.0
                all_days = set(pool_kg) | set(pool_dest)
                for day in all_days:
                    kg = pool_kg.get(day, 0) or 0
                    got = sum((x.get("qty") or 0) for x in pool_dest.get(day, []))
                    if kg - got > 0.5:
                        unalloc += kg - got
                    elif got - kg > 0.5:
                        over_alloc += got - kg
                if over_alloc > 0.5:
                    add("Годівля", "Пул залишків розподілений коректно", "fail",
                        f"роздано більше, ніж зібрано, на {round(over_alloc, 1)} кг — "
                        "зменшіть розподіл на панелі «Залишки ЗМР»")
                else:
                    add("Годівля", "Пул залишків розподілений коректно",
                        "warn" if unalloc > 0.5 else "ok",
                        (f"нерозподілено {round(unalloc, 1)} кг — рознесіть на панелі "
                         "«Залишки ЗМР»") if unalloc > 0.5
                        else "Увесь пул роздано або утилізовано.")

                # 4) Суми: групи = категорії = корми (розхід по факту завантаження).
                # Звіряємо ОДНУ метрику — завантажено (кг), бо «категорії» дає ще й
                # спожито окремо. Категорії ділять день за частками (Σчасток=1),
                # тож сума завантаженого має збігатися з групами й кормами.
                cat = self.feed_usage_by_category("feed", "", "")
                ing = self.feed_usage_by_ingredient("feed", "", "")
                t_grp = round(sum(s.get("loaded") or 0 for s in secs), 1)
                t_cat = round(sum(c.get("loaded") or 0
                                  for c in (cat.get("categories") or [])), 1)
                t_ing = round(sum(i.get("kg") or 0
                                  for i in (ing.get("ingredients") or [])), 1)
                mx = max(abs(t_grp - t_cat), abs(t_grp - t_ing), abs(t_cat - t_ing))
                add("Годівля", "Суми: групи = категорії = корми (завантажено)",
                    "fail" if mx > TOL else "ok",
                    f"групи {t_grp} · категорії {t_cat} · корми {t_ing} кг")
        except Exception as exc:  # noqa: BLE001
            add("Годівля", "Перевірка годівлі", "warn", f"Помилка: {exc}")

        # ---------- Склад (залишки / суми) ----------
        try:
            prods = self.list_products()
            # 1) Немає від'ємних залишків
            neg = [f"{p['name']}: {round(p.get('total_qty') or 0, 3)}"
                   for p in prods if (p.get("total_qty") or 0) < -1e-9]
            add("Склад", "Немає від'ємних залишків",
                "fail" if neg else "ok",
                clip(neg) if neg else "Усі залишки ≥ 0.")

            # 2) Вартість без ПДВ ≤ з ПДВ
            vat_bad = [p["name"] for p in prods
                       if (p.get("stock_value_no_vat") or 0)
                       > (p.get("stock_value") or 0) + 0.01]
            add("Склад", "Вартість без ПДВ ≤ з ПДВ",
                "fail" if vat_bad else "ok",
                clip(vat_bad) if vat_bad else "Співвідношення ПДВ коректне.")

            # 3) Крос-звірка залишків: партії (склад) ↔ рухи (баланс)
            today = date.today().strftime("%Y-%m-%d")
            saf = self.stock_as_of(today)
            q_batches = round(sum(max(0.0, p.get("total_qty") or 0)
                                  for p in prods
                                  if not self._is_water(p.get("name", ""))), 1)
            q_moves = round(sum(r.get("total_qty") or 0 for r in saf), 1)
            add("Склад", "Залишки: партії ↔ рухи",
                "fail" if abs(q_batches - q_moves) > TOL else "ok",
                f"партії {q_batches} · рухи {q_moves}", q_moves, q_batches)

            # 4) Вода на залишку = 0 (у всіх звітах)
            water_bad = [p["name"] for p in prods
                         if self._is_water(p.get("name", ""))
                         and abs(p.get("total_qty") or 0) > 1e-9]
            water_bad += [r["name"] for r in saf if self._is_water(r.get("name", ""))]
            add("Склад", "Вода на залишку = 0",
                "fail" if water_bad else "ok",
                clip(water_bad) if water_bad else "Вода скрізь 0.")
        except Exception as exc:  # noqa: BLE001
            add("Склад", "Перевірка складу", "warn", f"Помилка: {exc}")

        summary = {
            "ok": sum(1 for c in checks if c["status"] == "ok"),
            "warn": sum(1 for c in checks if c["status"] == "warn"),
            "fail": sum(1 for c in checks if c["status"] == "fail"),
        }
        summary["status"] = ("fail" if summary["fail"]
                             else ("warn" if summary["warn"] else "ok"))
        return {"checks": checks, "summary": summary, "checked_at": self._now()}

    def dashboard_stats(self, category: Optional[str] = None) -> dict[str, Any]:
        products = self.list_products(category=category)
        # Фільтр за категорією: для запитів лише по stock_moves — через підзапит,
        # для запиту з JOIN products (top_sellers) — через p.category.
        sub_clause = (" AND product_id IN (SELECT id FROM products WHERE category = ?)"
                      if category else "")
        ts_clause = " AND p.category = ?" if category else ""
        cat_p = [category] if category else []
        with self._connect() as conn:
            today = date.today().strftime("%Y-%m-%d")
            sales_today = conn.execute(
                # c = кількість ОПЕРАЦІЙ видачі (а не рядків-товарів): одна видача
                # може мати кілька позицій. Операція = sale_no (для старих без
                # номера — групуємо за часом створення).
                "SELECT COALESCE(SUM(total), 0) AS s, COALESCE(SUM(qty), 0) AS q, "
                "COUNT(DISTINCT COALESCE(NULLIF(sale_no, ''), created_at)) AS c "
                "FROM stock_moves WHERE move_type = 'OUT' "
                "AND sale_no NOT LIKE 'ВК-%' "  # виробництво КК — не видача
                "AND substr(created_at, 1, 10) = ?" + sub_clause,
                (today, *cat_p),
            ).fetchone()
            sales_month = conn.execute(
                "SELECT COALESCE(SUM(total), 0) AS s "
                "FROM stock_moves WHERE move_type = 'OUT' "
                "AND sale_no NOT LIKE 'ВК-%' "
                "AND substr(created_at, 1, 7) = ?" + sub_clause,
                (today[:7], *cat_p),
            ).fetchone()
            top_sellers = conn.execute(
                """
                SELECT p.name, p.barcode, p.code, p.unit,
                       SUM(m.qty) AS qty, SUM(m.total) AS revenue,
                       COUNT(*) AS ops, MAX(m.created_at) AS last_date
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                WHERE m.move_type = 'OUT'
                  AND substr(m.created_at, 1, 7) = ?
                """ + ts_clause + """
                GROUP BY p.id
                ORDER BY qty DESC
                LIMIT 15
                """,
                (today[:7], *cat_p),
            ).fetchall()
        total_units = sum(p["total_qty"] for p in products)
        # Баланс грошей у складі = вартість залишку за закупівельними цінами.
        stock_value_sum = sum(p.get("stock_value", 0) or 0 for p in products)
        low = [p for p in products
               if p["total_qty"] <= p["min_stock"] and not self._is_water(p["name"])]
        expiring = self.expiring_batches(30, category=category)
        return {
            "products_total": len(products),
            "units_total": total_units,
            "stock_value_sum": round(stock_value_sum, 2),
            "low_stock_count": len(low),
            "expiring_count": len(expiring),
            "expired_count": sum(1 for e in expiring if e["expired"]),
            "sales_today_sum": float(sales_today["s"] or 0),
            "sales_today_qty": float(sales_today["q"] or 0),
            "sales_today_count": int(sales_today["c"] or 0),
            "sales_month_sum": float(sales_month["s"] or 0),
            "top_sellers": [dict(r) for r in top_sellers],
        }

    def get_move(self, move_id: int) -> Optional[dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT id, batch_id, product_id, qty, move_type, note, "
                "       user_id, sale_no FROM stock_moves WHERE id = ?",
                (move_id,),
            ).fetchone()
        return dict(row) if row else None

    def is_adjustment_note(self, note: str) -> bool:
        n = (note or "").strip()
        return any(n.startswith(p) for p in self._ADJUST_PREFIXES)

    def undo_adjustment(self, move_id: int) -> dict[str, Any]:
        """Скасування коригувальної операції (інвентаризація, бій, тощо):
        повертає або забирає qty з партії й видаляє рух із журналу."""
        with self._connect() as conn:
            move = conn.execute(
                "SELECT id, batch_id, qty, move_type, note FROM stock_moves "
                "WHERE id = ?",
                (move_id,),
            ).fetchone()
            if not move:
                raise ValueError("Запис не знайдено.")
            if not self.is_adjustment_note(move["note"]):
                raise ValueError(
                    "Це не коригувальна операція — скасувати її тут не можна. "
                    "Продажі скасовуються в «Останніх операціях», прихід — у «Прихід».")
            if move["batch_id"] is None:
                raise ValueError(
                    "Рух без привʼязки до партії — скасування неможливе.")
            mt = move["move_type"]
            if mt == "WRITE_OFF":
                conn.execute(
                    "UPDATE stock_batches SET qty = qty + ? WHERE id = ?",
                    (move["qty"], move["batch_id"]),
                )
            elif mt == "IN":
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (move["qty"], move["batch_id"]),
                )
            else:
                raise ValueError(f"Невідповідний тип руху: {mt}")
            conn.execute("DELETE FROM stock_moves WHERE id = ?", (move_id,))
        return {"move_id": move_id, "qty": move["qty"], "move_type": mt}

    # Префікси приміток коригувальних рухів — для швидкого фільтра «Підстава»
    _ADJUST_PREFIXES = (
        "Інвентаризація",
        "Бій",
        "Порча",
        "Угар",
        "Пересортиця",
        "Прострочка",
        "Недостача",
        "Розкрадання",
        "Виявлення зайвого",
        "Інше",
        "Корекція",   # старого формату adjust_stock
    )

    def issue_by_block(self, date_from: str, date_to: str,
                       category: Optional[str] = None) -> list[dict[str, Any]]:
        """Видача/списання за період, згруповані по блоку → отримувачу → товару.
        Повертає рядки: block, recipient, product, unit, qty, total."""
        cat_clause = " AND p.category = ?" if category else ""
        params: list[Any] = [date_from, date_to]
        if category:
            params.append(category)
        sql = (
            "SELECT COALESCE(bl.name, '— без блоку —') AS block, "
            "       COALESCE(rc.name, '') AS recipient, "
            "       p.name AS product, p.unit AS unit, "
            "       SUM(m.qty) AS qty, SUM(m.total) AS total, "
            "       m.move_type AS move_type "
            "FROM stock_moves m "
            "JOIN products p ON p.id = m.product_id "
            "LEFT JOIN blocks bl ON bl.id = m.block_id "
            "LEFT JOIN recipients rc ON rc.id = m.recipient_id "
            "WHERE m.move_type IN ('OUT', 'WRITE_OFF') "
            "  AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%') "  # виробництво КК — не видача
            "  AND substr(m.created_at,1,10) >= ? "
            "  AND substr(m.created_at,1,10) <= ? " + cat_clause +
            " GROUP BY m.block_id, m.recipient_id, m.product_id, m.move_type "
            " ORDER BY block COLLATE NOCASE, recipient COLLATE NOCASE, "
            "          p.name COLLATE NOCASE"
        )
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["qty"] = round(d["qty"] or 0, 3)
            d["total"] = round(d["total"] or 0, 2)
            out.append(d)
        return out

    def feed_inventory_loss(self, date_from: str, date_to: str = "") -> dict[str, float]:
        """Втрати при балансуванні залишку (інвентаризація → «Втрати»): списання
        з ознакою ГД-ІНВ без прив'язки до групи. Те, що віднесене НА ГРУПУ, тут не
        рахується — воно вже в собівартості тієї групи."""
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10] or d1
        if not d1:
            return {"kg": 0.0, "sum": 0.0}
        with self._connect() as conn:
            r = conn.execute(
                "SELECT COALESCE(SUM(m.qty),0) AS kg, COALESCE(SUM(m.total),0) AS sum "
                "FROM stock_moves m JOIN products p ON p.id=m.product_id "
                "WHERE m.move_type='WRITE_OFF' AND p.category='feed' "
                "  AND m.sale_no LIKE 'ГД-ІНВ-%' AND m.block_id IS NULL "
                "  AND substr(m.created_at,1,10) BETWEEN ? AND ?", (d1, d2)).fetchone()
        return {"kg": round(float(r["kg"] or 0), 1), "sum": round(float(r["sum"] or 0), 2)}

    def feed_manual_usage(self, day: str) -> list[dict[str, Any]]:
        """Ручне використання кормів за день — видача/списання поза
        кормороздавачем (сторінка «Видача / списання»), із категорією
        (Корови/Молодняк за herd_kind блоку), підкатегорією та коментарем.
        Виключаємо роздачі Profeed (ГД-) і виробництво КК (ВК-)."""
        if not day:
            return []
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.name AS feed, p.unit AS unit, "
                "       COALESCE(bl.herd_kind, '') AS kind, "
                "       COALESCE(bl.subgroup, '') AS subgroup, "
                "       COALESCE(bl.name, rc.name, '') AS dir, "
                "       SUM(m.qty) AS qty, COALESCE(m.note, '') AS note, "
                "       MAX(COALESCE(m.not_feed, 0)) AS not_feed "
                "FROM stock_moves m "
                "JOIN products p ON p.id = m.product_id "
                "LEFT JOIN blocks bl ON bl.id = m.block_id "
                "LEFT JOIN recipients rc ON rc.id = m.recipient_id "
                "WHERE m.move_type IN ('OUT', 'WRITE_OFF') AND p.category = 'feed' "
                "  AND (m.sale_no IS NULL OR "
                "       (m.sale_no NOT LIKE 'ГД-%' AND m.sale_no NOT LIKE 'ВК-%')) "
                "  AND substr(m.created_at, 1, 10) = ? "
                "GROUP BY p.id, dir, note, kind, subgroup, COALESCE(m.not_feed, 0) "
                "ORDER BY kind, subgroup COLLATE NOCASE, dir COLLATE NOCASE, "
                "         feed COLLATE NOCASE",
                (day[:10],)).fetchall()
        kmap = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}
        return [{"category": kmap.get(r["kind"] or "", "Інше"),
                 "subgroup": r["subgroup"] or "",
                 "dir": r["dir"], "feed": r["feed"], "unit": r["unit"] or "кг",
                 "kg": round(r["qty"] or 0, 1), "note": r["note"] or "",
                 "not_feed": bool(r["not_feed"])} for r in rows]

    def feed_issue_matrix(self, days: int, feed_ids: list,
                          month_days: int = 30, group: str = "sub") -> dict[str, Any]:
        """Таблична видача кормів по КАТЕГОРІЯХ/ПІДКАТЕГОРІЯХ (рядки) × обрані
        корми (стовпці). Джерело — РУЧНА видача (stock_moves OUT, category=feed;
        без Profeed ГД- і виробництва КК ВК-). Категорія = herd_kind блоку,
        підкатегорія = subgroup. Клітинка = {kg, sum(₴)} за останні N днів; плюс
        окремо за `month_days` (колонка «За місяць»). Підсумки по рядках і всього."""
        days = max(1, min(365, int(days or 7)))
        month_days = max(1, min(366, int(month_days or 30)))
        ids, seen = [], set()
        for x in (feed_ids or []):
            try:
                i = int(x)
            except (TypeError, ValueError):
                continue
            if i > 0 and i not in seen:
                seen.add(i); ids.append(i)
        today = self._now()[:10]
        d_from = (datetime.strptime(today, "%Y-%m-%d")
                  - timedelta(days=days - 1)).strftime("%Y-%m-%d")
        m_from = (datetime.strptime(today, "%Y-%m-%d")
                  - timedelta(days=month_days - 1)).strftime("%Y-%m-%d")
        kmap = {"cow": "Корови", "young": "Молодняк", "pig": "Свині"}
        empty = {"feeds": [], "rows": [], "totals": {}, "days": days,
                 "from": d_from, "to": today, "month_days": month_days}
        if not ids:
            return empty
        with self._connect() as conn:
            qn = ",".join("?" * len(ids))
            meta = {r["id"]: r for r in conn.execute(
                f"SELECT id, name, unit FROM products "
                f"WHERE category='feed' AND id IN ({qn})", ids).fetchall()}
            feeds = [{"id": i, "name": meta[i]["name"], "unit": meta[i]["unit"] or "кг"}
                     for i in ids if i in meta]
            if not feeds:
                return empty
            fids = [f["id"] for f in feeds]
            qf = ",".join("?" * len(fids))

            def _agg(dfrom):
                return conn.execute(
                    f"SELECT COALESCE(bl.herd_kind,'') AS kind, "
                    f"       COALESCE(bl.subgroup,'') AS sub, m.product_id AS pid, "
                    f"       SUM(m.qty) AS qty, SUM(COALESCE(m.total,0)) AS val "
                    f"FROM stock_moves m "
                    f"JOIN products p ON p.id=m.product_id "
                    f"LEFT JOIN blocks bl ON bl.id=m.block_id "
                    f"WHERE m.move_type='OUT' AND p.category='feed' "
                    f"  AND m.product_id IN ({qf}) "
                    f"  AND (m.sale_no IS NULL OR (m.sale_no NOT LIKE 'ГД-%' "
                    f"       AND m.sale_no NOT LIKE 'ВК-%')) "
                    f"  AND substr(m.created_at,1,10) BETWEEN ? AND ? "
                    f"GROUP BY kind, sub, pid",
                    fids + [dfrom, today]).fetchall()
            per, mon = _agg(d_from), _agg(m_from)

        rowmap: dict = {}
        by_cat = (str(group or "sub").lower() == "cat")   # звести підкатегорії в категорію

        def _row(cat, sub):
            if by_cat:
                sub = ""
            k = (cat, sub)
            if k not in rowmap:
                rowmap[k] = {
                    "category": cat, "subgroup": sub,
                    "label": cat + (" · " + sub if sub else ""),
                    "cells": {f["id"]: {"kg": 0.0, "sum": 0.0, "m_kg": 0.0, "m_sum": 0.0}
                              for f in feeds},
                    "period_kg": 0.0, "period_sum": 0.0,
                    "month_kg": 0.0, "month_sum": 0.0}
            return rowmap[k]

        for r in per:
            row = _row(kmap.get(r["kind"] or "", "Інше"), r["sub"] or "")
            c = row["cells"][r["pid"]]
            c["kg"] += r["qty"] or 0.0; c["sum"] += r["val"] or 0.0
            row["period_kg"] += r["qty"] or 0.0; row["period_sum"] += r["val"] or 0.0
        for r in mon:
            row = _row(kmap.get(r["kind"] or "", "Інше"), r["sub"] or "")
            c = row["cells"][r["pid"]]
            c["m_kg"] += r["qty"] or 0.0; c["m_sum"] += r["val"] or 0.0
            row["month_kg"] += r["qty"] or 0.0; row["month_sum"] += r["val"] or 0.0

        rows = sorted(rowmap.values(), key=lambda x: x["label"])
        totals = {"cells": {f["id"]: {"kg": 0.0, "sum": 0.0, "m_kg": 0.0, "m_sum": 0.0}
                            for f in feeds},
                  "period_kg": 0.0, "period_sum": 0.0,
                  "month_kg": 0.0, "month_sum": 0.0}
        for row in rows:
            for fid, c in row["cells"].items():
                t = totals["cells"][fid]
                for k in ("kg", "sum", "m_kg", "m_sum"):
                    t[k] += c[k]
                    c[k] = round(c[k], 2 if "sum" in k else 1)
            for k in ("period_kg", "month_kg"):
                totals[k] += row[k]; row[k] = round(row[k], 1)
            for k in ("period_sum", "month_sum"):
                totals[k] += row[k]; row[k] = round(row[k], 2)
        for c in totals["cells"].values():
            for k in ("kg", "m_kg"):
                c[k] = round(c[k], 1)
            for k in ("sum", "m_sum"):
                c[k] = round(c[k], 2)
        for k in ("period_kg", "month_kg"):
            totals[k] = round(totals[k], 1)
        for k in ("period_sum", "month_sum"):
            totals[k] = round(totals[k], 2)
        return {"feeds": feeds, "rows": rows, "totals": totals, "days": days,
                "from": d_from, "to": today, "month_days": month_days}

    # Позначка документів, створених ТАБЛИЦЕЮ видачі (щоб перепроведення дня
    # чіпало лише свої записи, а не звичайну видачу з форми).
    FEED_GRID_MARK = "ТБВ"

    def feed_issue_grid(self, block_id: int, days: int,
                        feed_ids: list) -> dict[str, Any]:
        """Сітка вводу видачі: рядки — дні (останні N), стовпці — обрані корми,
        для ОДНОГО блоку (категорії/підкатегорії). Показує вже ПРОВЕДЕНЕ цією
        таблицею (kg) і окремо іншу ручну видачу того дня (other), щоб числа не
        виглядали загадково. Плюс sale_no документа дня (для перепроведення)."""
        block_id = int(block_id or 0)
        days = max(1, min(120, int(days or 7)))
        ids = [int(x) for x in (feed_ids or []) if str(x).strip().isdigit()]
        today = self._now()[:10]
        dlist = [(datetime.strptime(today, "%Y-%m-%d") - timedelta(days=i)).strftime("%Y-%m-%d")
                 for i in range(days)]
        # порожні рядки-дні: період видно ще ДО того, як додали корми-стовпці
        blank = [{"date": d, "cells": {}, "mine": {}, "other": {}, "sale_no": "",
                  "posted": False, "total": 0} for d in dlist]
        out = {"days": dlist, "feeds": [], "rows": blank, "block_id": block_id}
        if not (block_id and ids):
            return out
        with self._connect() as conn:
            qn = ",".join("?" * len(ids))
            meta = {r["id"]: r for r in conn.execute(
                f"SELECT id, name, unit, barcode FROM products "
                f"WHERE category='feed' AND id IN ({qn})", ids).fetchall()}
            feeds = [{"id": i, "name": meta[i]["name"], "unit": meta[i]["unit"] or "кг",
                      "barcode": meta[i]["barcode"]} for i in ids if i in meta]
            if not feeds:
                return out
            fids = [f["id"] for f in feeds]
            qf = ",".join("?" * len(fids))
            rows = conn.execute(
                f"SELECT substr(m.created_at,1,10) AS d, m.product_id AS pid, "
                f"       SUM(m.qty) AS qty, MAX(m.sale_no) AS sale_no, "
                f"       CASE WHEN COALESCE(m.note,'') LIKE ? THEN 1 ELSE 0 END AS mine "
                f"FROM stock_moves m JOIN products p ON p.id=m.product_id "
                f"WHERE m.move_type='OUT' AND p.category='feed' AND m.block_id=? "
                f"  AND m.product_id IN ({qf}) "
                f"  AND (m.sale_no IS NULL OR (m.sale_no NOT LIKE 'ГД-%' "
                f"       AND m.sale_no NOT LIKE 'ВК-%')) "
                f"  AND substr(m.created_at,1,10) >= ? "
                f"GROUP BY d, pid, mine",
                [self.FEED_GRID_MARK + "%", block_id] + fids + [dlist[-1]]).fetchall()
        posted: dict = {}
        for r in rows:
            slot = posted.setdefault(r["d"], {"mine": {}, "other": {}, "sale_no": ""})
            key = "mine" if r["mine"] else "other"
            slot[key][r["pid"]] = round((slot[key].get(r["pid"], 0)) + (r["qty"] or 0), 2)
            if r["mine"]:
                slot["sale_no"] = r["sale_no"] or slot["sale_no"]
        grid = []
        for d in dlist:
            p = posted.get(d, {"mine": {}, "other": {}, "sale_no": ""})
            # КЛІТИНКА = фактично видано за день (історія: таблиця + інші документи)
            cells = {f["id"]: round(p["mine"].get(f["id"], 0)
                                    + p["other"].get(f["id"], 0), 2) for f in feeds}
            grid.append({
                "date": d,
                "cells": cells,
                "mine": {f["id"]: p["mine"].get(f["id"], 0) for f in feeds},
                "other": {f["id"]: p["other"].get(f["id"], 0) for f in feeds},
                "sale_no": p["sale_no"],
                "posted": any(v > 0 for v in cells.values()),
                "total": round(sum(cells.values()), 2),
            })
        out["feeds"] = feeds
        out["rows"] = grid
        return out

    def feed_issue_post_day(self, day: str, block_id: int, items: list,
                            user_id: Optional[int] = None) -> dict[str, Any]:
        """Провести видачу за ОДИН день із таблиці: окрема ВВ на цей день.
        Якщо день уже проведено цією таблицею — попередній документ спершу
        скасовується (товар повертається на склад), потім створюється новий,
        тож повторне проведення не задвоює. items: [{barcode, qty}]."""
        day = str(day or "")[:10]
        block_id = int(block_id or 0)
        if not day or not block_id:
            raise ValueError("Не вказано день або групу.")
        want: dict = {}          # barcode -> цільова кількість за день (наша підкатегорія)
        nf: dict = {}            # barcode -> 1, якщо це ПІДСТИЛКА (не корм)
        for it in (items or []):
            bc = str((it or {}).get("barcode") or "").strip()
            try:
                q = float(str((it or {}).get("qty") or 0).replace(",", "."))
            except (TypeError, ValueError):
                q = 0.0
            if bc:
                want[bc] = want.get(bc, 0.0) + max(0.0, q)
                if (it or {}).get("not_feed"):
                    nf[bc] = 1

        with self._connect() as conn:
            row = conn.execute("SELECT herd_kind FROM blocks WHERE id=?", (block_id,)).fetchone()
            kind = (row["herd_kind"] if row else "") or ""
            # усі блоки ЦІЄЇ КАТЕГОРІЇ — накладна одна на категорію за день
            kin = [r["id"] for r in conn.execute(
                "SELECT id FROM blocks WHERE category='feed' AND COALESCE(herd_kind,'')=?",
                (kind,)).fetchall()] or [block_id]
            ph = ",".join("?" * len(kin))
            prev = [r["sale_no"] for r in conn.execute(
                f"SELECT DISTINCT sale_no FROM stock_moves "
                f"WHERE move_type='OUT' AND block_id IN ({ph}) "
                f"  AND substr(created_at,1,10)=? AND COALESCE(note,'') LIKE ? "
                f"  AND COALESCE(sale_no,'')<>''",
                kin + [day, self.FEED_GRID_MARK + "%"]).fetchall()]
            # рядки ІНШИХ підкатегорій цієї категорії — зберігаємо як були
            keep: dict = {}
            for sale in prev:
                for r in conn.execute(
                        "SELECT p.barcode AS bc, m.qty AS q, m.block_id AS b, "
                        "       COALESCE(m.not_feed,0) AS nf "
                        "FROM stock_moves m JOIN products p ON p.id=m.product_id "
                        "WHERE m.sale_no=? AND m.move_type='OUT'", (sale,)).fetchall():
                    if int(r["b"] or 0) != block_id:
                        k = (int(r["b"] or 0), r["bc"], int(r["nf"] or 0))
                        keep[k] = keep.get(k, 0.0) + (r["q"] or 0.0)

        # 1) скасувати попередні документи таблиці за цей день (по всій категорії)
        undone = []
        for sale in prev:
            try:
                self.undo_sale(sale)
                undone.append(sale)
            except Exception:  # noqa: BLE001
                pass

        # 2) що вже видано цього дня ІНШИМИ документами саме в НАШУ підкатегорію
        other: dict = {}
        if want:
            with self._connect() as conn:
                qn = ",".join("?" * len(want))
                for row in conn.execute(
                        f"SELECT p.barcode AS bc, SUM(m.qty) AS q FROM stock_moves m "
                        f"JOIN products p ON p.id=m.product_id "
                        f"WHERE m.move_type='OUT' AND m.block_id=? "
                        f"  AND substr(m.created_at,1,10)=? AND p.barcode IN ({qn}) "
                        f"  AND (m.sale_no IS NULL OR (m.sale_no NOT LIKE 'ГД-%' "
                        f"       AND m.sale_no NOT LIKE 'ВК-%')) "
                        f"GROUP BY p.barcode",
                        [block_id, day] + list(want.keys())).fetchall():
                    other[row["bc"]] = row["q"] or 0.0

        # 3) рядки документа: інші підкатегорії (як були) + наша (різниця)
        lines, warn = [], []
        for (b, bc, k_nf), q in keep.items():
            if q > 0:
                lines.append({"barcode": bc, "qty": q, "block_id": b, "not_feed": k_nf})
        for bc, target in want.items():
            delta = round(target - other.get(bc, 0.0), 3)
            if delta > 0.0001:
                lines.append({"barcode": bc, "qty": delta, "block_id": block_id,
                              "not_feed": nf.get(bc, 0)})
            elif delta < -0.0001:
                warn.append(bc)
        if not lines:
            return {"sale_no": "", "cleared": undone, "lines": 0, "warn": warn}
        res = self.process_sale(lines, move_type="OUT",
                                note=self.FEED_GRID_MARK + " таблиця видачі",
                                user_id=user_id, block_id=block_id, op_date=day)
        return {"sale_no": (res or {}).get("sale_no", ""), "cleared": undone,
                "lines": len(lines), "warn": warn}

    def feed_issue_clear(self, block_id: int, date_from: str, date_to: str,
                         only_table: bool = True) -> dict[str, Any]:
        """Прибрати РУЧНУ видачу кормів за період по групі (корм повертається на
        склад). only_table=True — лише документи, створені таблицею (ТБВ);
        False — уся ручна видача (крім Profeed ГД- і виробництва КК ВК-).
        Потрібно, щоб почати вносити дані заново з чистого аркуша."""
        block_id = int(block_id or 0)
        d1, d2 = str(date_from or "")[:10], str(date_to or "")[:10]
        if not (block_id and d1 and d2):
            raise ValueError("Вкажіть групу і період.")
        cond = "AND COALESCE(m.note,'') LIKE ? " if only_table else ""
        params = [block_id, d1, d2] + ([self.FEED_GRID_MARK + "%"] if only_table else [])
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT m.sale_no FROM stock_moves m "
                "JOIN products p ON p.id=m.product_id "
                "WHERE m.move_type='OUT' AND p.category='feed' AND m.block_id=? "
                "  AND substr(m.created_at,1,10) BETWEEN ? AND ? "
                "  AND COALESCE(m.sale_no,'')<>'' "
                "  AND m.sale_no NOT LIKE 'ГД-%' AND m.sale_no NOT LIKE 'ВК-%' "
                + cond, params).fetchall()
        done, failed = [], []
        for r in rows:
            try:
                self.undo_sale(r["sale_no"])
                done.append(r["sale_no"])
            except Exception:  # noqa: BLE001
                failed.append(r["sale_no"])
        return {"removed": done, "failed": failed, "count": len(done)}

    def feed_manual_consumed(self, date_from: str, date_to: str) -> dict[str, float]:
        """Сума ручної ГОДІВЛІ кормів за період (₴ собівартості й кг) — всього та
        окремо по Коровах. Лише корм, що пішов у годівлю (not_feed=0); підстилку
        (not_feed=1) НЕ рахуємо. Для включення ручної годівлі в собівартість."""
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        if not d1 or not d2:
            return {"all_sum": 0.0, "all_kg": 0.0, "cow_sum": 0.0, "cow_kg": 0.0}
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT COALESCE(bl.herd_kind, '') AS kind, "
                "       SUM(m.qty) AS qty, SUM(m.total) AS sum "
                "FROM stock_moves m "
                "JOIN products p ON p.id = m.product_id "
                "LEFT JOIN blocks bl ON bl.id = m.block_id "
                "WHERE m.move_type = 'OUT' AND p.category = 'feed' "
                "  AND (m.sale_no IS NULL OR "
                "       (m.sale_no NOT LIKE 'ГД-%' AND m.sale_no NOT LIKE 'ВК-%')) "
                "  AND COALESCE(m.not_feed, 0) = 0 "
                "  AND COALESCE(bl.herd_kind, '') != 'pig' "   # Свині — не ВРХ
                "  AND substr(m.created_at, 1, 10) BETWEEN ? AND ? "
                "GROUP BY kind", (d1, d2)).fetchall()
        out = {"all_sum": 0.0, "all_kg": 0.0, "cow_sum": 0.0, "cow_kg": 0.0}
        for r in rows:
            s = r["sum"] or 0.0
            q = r["qty"] or 0.0
            out["all_sum"] += s
            out["all_kg"] += q
            if (r["kind"] or "") == "cow":
                out["cow_sum"] += s
                out["cow_kg"] += q
        return {k: round(v, 2) for k, v in out.items()}

    def feed_purchase_vat_by_name(self, date_from: str, date_to: str) -> dict:
        """Реальний вхідний ПДВ з ПРИХОДУ кожного корму за період (податковий
        кредит), за «Датою приходу» партії. Ключ — нормалізована назва корму,
        значення — ПДВ ₴ (з-ПДВ − без-ПДВ за фактичними цінами). Для «По кормах»."""
        import re as _re
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        if not d1 or not d2:
            return {}
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT p.name AS name, "
                "  SUM(m.qty * (COALESCE(b.price_in,0) "
                "        - COALESCE(NULLIF(b.price_in_no_vat,0), b.price_in, 0))) AS vat "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "LEFT JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'IN' AND p.category = 'feed' "
                "  AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%') "   # не власне вир-во КК
                "  AND COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)) "
                "      BETWEEN ? AND ? "
                "GROUP BY p.name", (d1, d2)).fetchall()

        def norm(s):
            return _re.sub(r"\s+", " ", (s or "").strip()).casefold()
        out: dict = {}
        for r in rows:
            out[norm(r["name"])] = out.get(norm(r["name"]), 0.0) + (r["vat"] or 0)
        return {k: round(v, 2) for k, v in out.items()}

    def purchase_vat_by_category_day(self, day: str) -> dict:
        """Реальний вхідний ПДВ з ПРИХОДУ за день по категоріях (feed/pharmacy/
        materials), за «Датою приходу» партії. Для Звіту-2."""
        day = (day or "").strip()[:10]
        out = {"feed": 0.0, "pharmacy": 0.0, "materials": 0.0}
        if not day:
            return out
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT COALESCE(NULLIF(TRIM(p.category),''),'pharmacy') AS cat, "
                "  SUM(m.qty * (COALESCE(b.price_in,0) "
                "        - COALESCE(NULLIF(b.price_in_no_vat,0), b.price_in, 0))) AS vat "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "LEFT JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'IN' "
                "  AND (m.sale_no IS NULL OR m.sale_no NOT LIKE 'ВК-%') "   # не власне вир-во КК
                "  AND COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)) = ? "
                "GROUP BY cat", (day,)).fetchall()
        for r in rows:
            if r["cat"] in out:
                out[r["cat"]] = round(r["vat"] or 0.0, 2)
        return out

    def purchase_vat_day(self, day: str) -> float:
        """Вхідний ПДВ із УСІХ закупок (прихід, move_type='IN') за день —
        по «Даті приходу» партії (fallback: дата вводу). ПДВ = сума з ПДВ − без ПДВ
        по кожній партії (ціна_з_ПДВ − ціна_без_ПДВ) × к-сть. Для Звіту-2."""
        day = (day or "").strip()[:10]
        if not day:
            return 0.0
        with self._connect() as conn:
            row = conn.execute(
                "SELECT SUM(m.qty * (COALESCE(b.price_in,0) "
                "        - COALESCE(NULLIF(b.price_in_no_vat,0), b.price_in, 0))) AS vat "
                "FROM stock_moves m JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'IN' "
                "  AND COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)) = ?",
                (day,)).fetchone()
        return round((row["vat"] if row and row["vat"] else 0.0), 2)

    def branch_expense_day(self, day: str) -> dict:
        """Витрати за день по гілках Аптека та Матеріали — собівартість БЕЗ ПДВ
        виданого/списаного (move_type OUT або WRITE_OFF). Для Звіту-2."""
        day = (day or "").strip()[:10]
        out = {"pharmacy": 0.0, "materials": 0.0}
        if not day:
            return out
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT COALESCE(NULLIF(TRIM(p.category),''),'pharmacy') AS cat, "
                "  SUM(m.qty * COALESCE(NULLIF(b.price_in_no_vat,0), b.price_in, m.price, 0)) AS s "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "LEFT JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type IN ('OUT','WRITE_OFF') "
                "  AND COALESCE(NULLIF(TRIM(p.category),''),'pharmacy') IN ('pharmacy','materials') "
                "  AND substr(m.created_at,1,10) = ? "
                "GROUP BY cat", (day,)).fetchall()
        for r in rows:
            out[r["cat"]] = round(r["s"] or 0.0, 2)
        return out

    def _feed_stock_by_date(self, date_from: str, date_to: str) -> dict:
        """Складський залишок КОЖНОГО корму (кг) на кінець кожної дати в періоді.
        Ключ — нормалізована назва корму (як у feed_usage_by_ingredient), значення —
        {дата: залишок_кг}. Залишок = накопичена сума рухів (IN +, решта −) до кінця
        дати включно. Для колонки «Залишок» у «По кормах → просто по датах»."""
        import re as _re
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        if not d1 or not d2:
            return {}
        with self._connect() as conn:
            rows = conn.execute(
                # для ПРИХОДУ (IN) дата = «Дата приходу» партії (receipt_date), а не
                # час внесення в базу; для витрат — дата операції (created_at). Інакше
                # прихід «сідає» на дату вводу і залишок до неї виглядає від'ємним.
                "SELECT p.name AS name, "
                "  CASE WHEN m.move_type='IN' "
                "       THEN COALESCE(NULLIF(b.receipt_date,''), substr(m.created_at,1,10)) "
                "       ELSE substr(m.created_at,1,10) END AS dt, "
                "  SUM(CASE WHEN m.move_type='IN' THEN m.qty ELSE -m.qty END) AS delta "
                "FROM stock_moves m "
                "JOIN products p ON p.id = m.product_id "
                "LEFT JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE p.category = 'feed' "
                "GROUP BY p.name, dt").fetchall()

        def norm(s):
            return _re.sub(r"\s+", " ", (s or "").strip()).casefold()
        per: dict = {}
        for r in rows:
            per.setdefault(norm(r["name"]), {})
            dt = r["dt"]
            per[norm(r["name"])][dt] = per[norm(r["name"])].get(dt, 0.0) + (r["delta"] or 0)
        out: dict = {}
        for nm, agg in per.items():
            is_water = nm.startswith("вода")   # воду не складуємо → залишок завжди 0
            run = 0.0
            dmap: dict = {}
            for dt in sorted(agg):
                run += agg[dt]
                if d1 <= dt <= d2:
                    # Від'ємний залишок ЛИШАЄМО — це індикатор (списання раніше за
                    # оприбуткований прихід / немає початкового залишку). Лише воду
                    # завжди 0.
                    dmap[dt] = 0.0 if is_water else round(run, 1)
            out[nm] = dmap
        return out

    def _manual_feed_by_cat(self, date_from: str, date_to: str) -> list:
        """Ручна годівля за період: видача (OUT) корму на групу вручну
        (not_feed=0, лише ВРХ Корови/Молодняк, без ГД-/ВК-). Повертає ДЕТАЛЬНО
        по днях і кормах:
        [{cat, date, name, code, kg, sum_nv}] — щоб у feed_usage_by_category
        підкатегорія «Ручна годівля» показувала, який корм і скільки кг спожито
        (₴ собівартості БЕЗ ПДВ)."""
        d1 = (date_from or "")[:10]
        d2 = (date_to or "")[:10]
        if not d1 or not d2:
            return []
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT COALESCE(bl.herd_kind, '') AS kind, "
                "  substr(m.created_at, 1, 10) AS dt, "
                "  p.name AS name, p.code AS code, SUM(m.qty) AS kg, "
                "  SUM(m.qty * COALESCE(NULLIF(b.price_in_no_vat, 0), b.price_in, 0)) AS sum_nv "
                "FROM stock_moves m JOIN products p ON p.id = m.product_id "
                "LEFT JOIN blocks bl ON bl.id = m.block_id "
                "LEFT JOIN stock_batches b ON b.id = m.batch_id "
                "WHERE m.move_type = 'OUT' AND p.category = 'feed' "
                "  AND (m.sale_no IS NULL OR "
                "       (m.sale_no NOT LIKE 'ГД-%' AND m.sale_no NOT LIKE 'ВК-%')) "
                "  AND COALESCE(m.not_feed, 0) = 0 "
                "  AND COALESCE(bl.herd_kind, '') IN ('cow', 'young') "
                "  AND substr(m.created_at, 1, 10) BETWEEN ? AND ? "
                "GROUP BY kind, dt, p.id ORDER BY dt", (d1, d2)).fetchall()
        lbl = {"cow": "Корови", "young": "Молодняк"}
        return [{"cat": lbl[r["kind"]], "date": r["dt"],
                 "name": r["name"] or "", "code": r["code"] or "",
                 "kg": r["kg"] or 0.0, "sum_nv": r["sum_nv"] or 0.0}
                for r in rows if (r["kg"] or 0) > 0 and r["kind"] in lbl]

    def all_moves_filtered(self, date_from: str = "", date_to: str = "",
                           move_type: str = "", *,
                           reason: str = "", category: Optional[str] = None) -> list[dict[str, Any]]:
        sql = (
            "SELECT m.id, m.batch_id, m.created_at, p.name, p.code, m.barcode, "
            "       m.move_type, m.qty, "
            "       m.note, b.lot_number, b.invoice_number, b.expires_on, "
            "       b.markup_pct, b.price_out, "
            "       sup.name AS supplier, m.price, m.total, "
            "       m.user_id AS user_id, u.username AS user_login "
            "FROM stock_moves m "
            "JOIN products p ON p.id = m.product_id "
            "LEFT JOIN stock_batches b ON b.id = m.batch_id "
            "LEFT JOIN suppliers sup ON sup.id = b.supplier_id "
            "LEFT JOIN users u ON u.id = m.user_id "
            "WHERE 1=1 "
        )
        params: list[Any] = []
        if category:
            sql += "AND p.category = ? "
            params.append(category)
        if date_from:
            sql += "AND substr(m.created_at, 1, 10) >= ? "
            params.append(date_from)
        if date_to:
            sql += "AND substr(m.created_at, 1, 10) <= ? "
            params.append(date_to)
        if move_type:
            sql += "AND m.move_type = ? "
            params.append(move_type)
        if reason:
            if reason == "__any__":
                # Будь-яка коригувальна операція — нота починається з відомого префікса
                ors = " OR ".join(["m.note LIKE ?"] * len(self._ADJUST_PREFIXES))
                sql += f"AND ({ors}) "
                for p in self._ADJUST_PREFIXES:
                    params.append(p + "%")
            else:
                sql += "AND m.note LIKE ? "
                params.append(reason + "%")
        sql += "ORDER BY m.id DESC"
        with self._connect() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    # ----------------------------------------------------- журнал дій (audit)

    def log_audit(self, action: str, user_id: Optional[int] = None, *,
                  category: str = "", summary: str = "", detail: str = "") -> None:
        """Записати подію (зокрема видалення) до журналу дій користувачів."""
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO audit_log "
                "(created_at, user_id, action, category, summary, detail) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (self._now(), user_id, action, category or "",
                 summary or "", detail or ""),
            )

    def audit_trail(self, *, date_from: str = "", date_to: str = "",
                    user_id: Optional[int] = None, branch: str = "",
                    op_type: str = "", search: str = "",
                    limit: int = 2000) -> dict[str, Any]:
        """Єдина стрічка дій: операції зі складу + видалення з audit_log.

        Фільтри: дата (з/по), користувач, гілка (категорія), тип операції,
        текстовий пошук (товар/деталі/користувач).
        op_type: IN / OUT / WRITE_OFF / RETURN / ADJUST / DELETE.
        Повертає {items, total, truncated} — items обмежено limit."""
        msql = (
            "SELECT m.id, m.created_at, p.name AS product, p.category AS branch, "
            "       m.move_type, m.qty, m.note, m.user_id, u.username AS user_login, "
            "       m.sale_no, m.product_id "
            "FROM stock_moves m "
            "JOIN products p ON p.id = m.product_id "
            "LEFT JOIN users u ON u.id = m.user_id "
            "WHERE 1=1 "
        )
        mp: list[Any] = []
        if date_from: msql += "AND substr(m.created_at,1,10) >= ? "; mp.append(date_from)
        if date_to:   msql += "AND substr(m.created_at,1,10) <= ? "; mp.append(date_to)
        if user_id:   msql += "AND m.user_id = ? "; mp.append(user_id)
        if branch:    msql += "AND p.category = ? "; mp.append(branch)

        asql = (
            "SELECT a.created_at, a.user_id, a.category AS branch, "
            "       a.summary, a.detail, u.username AS user_login "
            "FROM audit_log a LEFT JOIN users u ON u.id = a.user_id WHERE 1=1 "
        )
        ap: list[Any] = []
        if date_from: asql += "AND substr(a.created_at,1,10) >= ? "; ap.append(date_from)
        if date_to:   asql += "AND substr(a.created_at,1,10) <= ? "; ap.append(date_to)
        if user_id:   asql += "AND a.user_id = ? "; ap.append(user_id)
        if branch:    asql += "AND a.category = ? "; ap.append(branch)

        with self._connect() as conn:
            mrows = conn.execute(msql, mp).fetchall()
            arows = conn.execute(asql, ap).fetchall()

        events: list[dict[str, Any]] = []
        # Один продаж (sale_no) може списатись із кількох партій — тоді в
        # stock_moves буде кілька рядків на той самий товар (напр. 5+5). У
        # журналі дій це має бути ОДНА дія: групуємо рядки одного продажу й
        # товару, сумуючи кількість. Рухи без sale_no (прихід, коригування,
        # повернення) лишаються окремими.
        move_groups: dict[Any, dict[str, Any]] = {}
        ordered_keys: list[Any] = []
        for r in mrows:
            d = dict(r)
            if self.is_adjustment_note(d["note"]):
                code, label = "ADJUST", "Коригування"
            else:
                code = d["move_type"]
                label = self._MOVE_LABEL.get(code, code)
            sale_no = (d.get("sale_no") or "").strip()
            if sale_no:
                key = ("sale", sale_no, d["product_id"], code)
            else:
                key = ("move", d["id"])
            grp = move_groups.get(key)
            if grp is None:
                grp = {
                    "created_at": d["created_at"],
                    "user_login": d["user_login"] or "—",
                    "branch": self._BRANCH_LABEL.get(d["branch"], d["branch"]),
                    "op_type": code,
                    "op_label": label,
                    "product": d["product"],
                    "qty": d["qty"] or 0,
                    "detail": d["note"] or "",
                }
                move_groups[key] = grp
                ordered_keys.append(key)
            else:
                grp["qty"] = (grp["qty"] or 0) + (d["qty"] or 0)
        for key in ordered_keys:
            events.append(move_groups[key])
        for r in arows:
            d = dict(r)
            events.append({
                "created_at": d["created_at"],
                "user_login": d["user_login"] or "—",
                "branch": (self._BRANCH_LABEL.get(d["branch"], d["branch"])
                           if d["branch"] else ""),
                "op_type": "DELETE",
                "op_label": "Видалення",
                "product": d["summary"],
                "qty": None,
                "detail": d["detail"] or "",
            })

        if op_type:
            events = [e for e in events if e["op_type"] == op_type]

        s = (search or "").strip().lower()
        if s:
            def _hit(e: dict[str, Any]) -> bool:
                return (s in (e["product"] or "").lower()
                        or s in (e["detail"] or "").lower()
                        or s in (e["user_login"] or "").lower())
            events = [e for e in events if _hit(e)]

        events.sort(key=lambda e: e["created_at"], reverse=True)
        total = len(events)
        return {"items": events[:limit], "total": total,
                "truncated": total > limit}

    # ------------------------------------------------------------------ helpers

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _op_ts(self, day: str) -> str:
        """Мітка часу руху за ДАТОЮ ОПЕРАЦІЇ з документа (день + поточний час).

        Залишки на дату, звіти руху й собівартість рахуються з `created_at`
        рухів, тож накладна, внесена заднім числом, має лягати СВОЄЮ датою
        приходу. Інакше корм «зʼявляється на складі» в день введення, а не
        коли реально надійшов (Роман 2026-09-02: 80 зі 126 приходів
        розходились із документом, подекуди на 200+ днів). Поведінка така
        сама, як у process_sale(op_date): некоректна дата → поточний момент."""
        d = (day or "").strip()[:10]
        try:
            date.fromisoformat(d)
        except Exception:  # noqa: BLE001
            return self._now()
        return d + self._now()[10:]
