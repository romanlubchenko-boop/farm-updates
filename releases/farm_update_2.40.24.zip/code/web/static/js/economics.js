/* ============ Економіка: витрати та аналітика прибутку ============ */

const ecoFrom      = document.getElementById('ecoFrom');
const ecoTo        = document.getElementById('ecoTo');
const ecoApplyBtn  = document.getElementById('ecoApplyBtn');
const ecoKpi       = document.getElementById('ecoKpi');
const ecoTopPanel  = document.getElementById('ecoTopPanel');
const ecoChart     = document.getElementById('ecoChart');
const netProfitCard = document.getElementById('netProfitCard');

let lastEco = null;          // останні дані для графіка
let currentHighlight = null; // підсвічений показник
const newCatName   = document.getElementById('newCatName');
const addCatBtn    = document.getElementById('addCatBtn');
const catBody      = document.querySelector('#catTable tbody');
const expCategory  = document.getElementById('expCategory');
const expenseForm  = document.getElementById('expenseForm');
const expAmount    = document.getElementById('expAmount');
const expDate      = document.getElementById('expDate');
const expNote      = document.getElementById('expNote');
const expensesBody = document.querySelector('#expensesTable tbody');
const expensesSum  = document.getElementById('expensesSum');

function isoDate(d) {
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function period() {
    return {
        from: ecoFrom.value || '',
        to: ecoTo.value || '',
    };
}

/* ---------- KPI ---------- */

function renderKpi(eco) {
    lastEco = eco;
    ecoKpi.querySelectorAll('[data-eco]').forEach((el) => {
        const key = el.dataset.eco;
        el.textContent = fmtMoney(eco[key] || 0);
    });
    // чистий прибуток: синій якщо в плюсі, червоний якщо в мінусі
    netProfitCard.className = 'stat-card ' +
        ((eco.net_profit || 0) >= 0 ? 'primary' : 'danger');
    // якщо графік відкритий — перемалювати з новими даними
    if (!ecoChart.hidden && currentHighlight) {
        renderEcoChart(eco, currentHighlight);
    }
}

/* ---------- графік показників (при наведенні) ---------- */

const ECO_METRICS = [
    { key: 'revenue',        label: 'Виручка з продажів', color: '#2f7ad9' },
    { key: 'cogs',           label: 'Собівартість',       color: '#94a3b8' },
    { key: 'gross_profit',   label: 'Валовий прибуток',   color: '#1aa86b' },
    { key: 'writeoff_loss',  label: 'Списано (втрати)',   color: '#d98a1a' },
    { key: 'expenses_total', label: 'Витрати за статтями', color: '#e0973a' },
    { key: 'net_profit',     label: 'Чистий прибуток',    color: '#1aa86b' },
];

function renderEcoChart(eco, highlight) {
    const rowH = 36, labelW = 176, padR = 104, top = 6;
    const W = 660;
    const chartX = labelW;
    const chartW = W - labelW - padR;
    const maxVal = Math.max(1, ...ECO_METRICS.map((m) => Math.abs(eco[m.key] || 0)));
    const H = top * 2 + ECO_METRICS.length * rowH;

    const rows = ECO_METRICS.map((m, i) => {
        const val = eco[m.key] || 0;
        const barH = rowH - 16;
        const y = top + i * rowH;
        const barY = y + 8;
        const w = Math.max(2, (Math.abs(val) / maxVal) * chartW);
        const isOn = !highlight || highlight === m.key;
        const op = isOn ? 1 : 0.26;
        let color = m.color;
        if (m.key === 'net_profit') color = val >= 0 ? '#1aa86b' : '#d04b4b';
        const labelWeight = highlight === m.key ? '700' : '500';
        const cy = barY + barH / 2 + 4;
        return `
            <g opacity="${op}">
                <text x="${labelW - 12}" y="${cy}" text-anchor="end"
                      font-size="12" font-weight="${labelWeight}" fill="#1e293b">${escapeHtml(m.label)}</text>
                <rect x="${chartX}" y="${barY}" width="${chartW}" height="${barH}" rx="4"
                      fill="#e3e8ef" opacity="0.55"></rect>
                <rect x="${chartX}" y="${barY}" width="${w}" height="${barH}" rx="4" fill="${color}"></rect>
                <text x="${chartX + w + 8}" y="${cy}" font-size="12"
                      font-weight="600" fill="#1e293b">${fmtMoney(val)}</text>
            </g>`;
    }).join('');

    ecoChart.innerHTML =
        '<div class="eco-chart-title">Показники за період — порівняння</div>' +
        `<svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet" ` +
        `xmlns="http://www.w3.org/2000/svg">${rows}</svg>`;
}

/* ---------- статті витрат ---------- */

function renderCategories(cats, byCategory) {
    // мапа «назва → витрачено за період»
    const spent = {};
    (byCategory || []).forEach((c) => { spent[c.category] = c.total; });

    if (!cats.length) {
        catBody.innerHTML = '<tr><td colspan="3" class="empty">Ще немає статей витрат</td></tr>';
    } else {
        catBody.innerHTML = cats.map((c) => `
            <tr>
                <td>${escapeHtml(c.name)}</td>
                <td class="num">${fmtMoney(spent[c.name] || 0)}</td>
                <td class="col-actions">
                    <button class="btn btn-icon btn-icon-danger" data-del-cat="${c.id}"
                            title="Видалити статтю">🗑</button>
                </td>
            </tr>
        `).join('');
    }
}

function fillCategorySelect(cats) {
    const cur = expCategory.value;
    expCategory.innerHTML = cats.map((c) =>
        `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
    if (cur) expCategory.value = cur;
}

/* ---------- витрати ---------- */

function renderExpenses(items) {
    if (!items.length) {
        expensesBody.innerHTML = '<tr><td colspan="5" class="empty">За період витрат немає</td></tr>';
        expensesSum.textContent = '0,00';
        return;
    }
    expensesBody.innerHTML = items.map((e) => `
        <tr>
            <td class="text-mute nowrap">${fmtDate(e.expense_date)}</td>
            <td>${escapeHtml(e.category || 'Без статті')}</td>
            <td class="num">${fmtMoney(e.amount)}</td>
            <td class="text-mute">${escapeHtml(e.note || '')}</td>
            <td class="col-actions">
                ${IS_ADMIN ? `<button class="btn btn-icon btn-icon-danger" data-del-exp="${e.id}"
                        title="Видалити витрату">🗑</button>` : ''}
            </td>
        </tr>
    `).join('');
    const total = items.reduce((s, e) => s + (e.amount || 0), 0);
    expensesSum.textContent = fmtMoney(total);
}

/* ---------- завантаження ---------- */

async function refresh() {
    const p = period();
    const qs = `?from=${encodeURIComponent(p.from)}&to=${encodeURIComponent(p.to)}`;
    const [eco, cats, exps] = await Promise.all([
        apiGet('/api/economics' + qs),
        apiGet('/api/expense-categories'),
        apiGet('/api/expenses' + qs),
    ]);
    if (eco.ok) renderKpi(eco);
    if (cats.ok) {
        renderCategories(cats.items || [], eco.ok ? eco.by_category : []);
        fillCategorySelect(cats.items || []);
    }
    if (exps.ok) renderExpenses(exps.items || []);
}

/* ---------- дії ---------- */

ecoApplyBtn.addEventListener('click', refresh);

// наведення на картку показника — показати графік
ecoKpi.addEventListener('mouseover', (e) => {
    const card = e.target.closest('.stat-card');
    if (!card || !lastEco) return;
    const valEl = card.querySelector('[data-eco]');
    if (!valEl) return;
    const key = valEl.dataset.eco;
    if (key === currentHighlight && !ecoChart.hidden) return;
    currentHighlight = key;
    ecoChart.hidden = false;
    renderEcoChart(lastEco, key);
});
// курсор пішов з верхньої панелі — сховати графік
ecoTopPanel.addEventListener('mouseleave', () => {
    ecoChart.hidden = true;
    currentHighlight = null;
});

addCatBtn.addEventListener('click', async () => {
    const name = newCatName.value.trim();
    if (!name) { toast('Вкажіть назву статті', 'warn'); newCatName.focus(); return; }
    const r = await apiSend('/api/expense-categories', 'POST', { name });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Статтю додано', 'success');
    newCatName.value = '';
    refresh();
});
newCatName.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); addCatBtn.click(); }
});

catBody.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-del-cat]');
    if (!btn) return;
    if (!await confirmAction('Видалити цю статтю витрат?')) return;
    const r = await apiSend('/api/expense-categories/' + btn.dataset.delCat, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Статтю видалено', 'success');
    refresh();
});

expenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const categoryId = expCategory.value;
    const amount = parseFloat(String(expAmount.value).replace(',', '.')) || 0;
    if (!categoryId) { toast('Оберіть статтю витрат', 'warn'); return; }
    if (!(amount > 0)) { toast('Вкажіть суму', 'warn'); expAmount.focus(); return; }
    if (!expDate.value) { toast('Вкажіть дату', 'warn'); expDate.focus(); return; }
    const r = await apiSend('/api/expenses', 'POST', {
        category_id: categoryId,
        amount: amount,
        expense_date: expDate.value,
        note: expNote.value,
    });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Витрату додано', 'success');
    expAmount.value = '';
    expNote.value = '';
    refresh();
});

expensesBody.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-del-exp]');
    if (!btn) return;
    if (!await confirmAction('Видалити цю витрату?')) return;
    const r = await apiSend('/api/expenses/' + btn.dataset.delExp, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Витрату видалено', 'success');
    refresh();
});

/* ---------- init ---------- */

document.addEventListener('DOMContentLoaded', () => {
    const now = new Date();
    // період за замовчуванням — поточний місяць
    ecoFrom.value = isoDate(new Date(now.getFullYear(), now.getMonth(), 1));
    ecoTo.value = isoDate(now);
    expDate.value = isoDate(now);
    refresh();
});
