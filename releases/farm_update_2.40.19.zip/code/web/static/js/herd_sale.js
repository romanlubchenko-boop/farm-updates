/* Продаж худоби накладними — за зразком приходу аптеки (pryhid.js):
   кілька накладних одночасно, набираєш і проводиш кожну окремо, поруч
   вкладка «Історія» з тими самими фільтрами (Роман 2026-09-21).
   Арифметика та сама: сума = вага × ціна, ціна з ПДВ = ціна × (1+ПДВ/100). */
(function () {
    'use strict';
    const $ = (id) => document.getElementById(id);
    const nf = new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 2 });
    const money = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const priceF = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
    const kgF = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    const r4 = (x) => Math.round(x * 10000) / 10000;
    const r2 = (x) => Math.round(x * 100) / 100;
    const rawNum = (v) => +String(v === null || v === undefined ? '' : v)
        .replace(/\s| /g, '').replace(',', '.') || 0;
    const esc = (s) => String(s === null || s === undefined ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const todayISO = () => {
        const d = new Date();
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    };

    let ANIMALS = [], REFS = {}, invs = [], activeId = 0, seq = 1, DOCS = [];
    let per = 'last', histQ = '';
    const LS = 'herd:sale_invs';

    /* ── дані ── */
    async function load() {
        const [an, evd, sale] = await Promise.all([
            apiGet('/api/herd/animals?limit=4000&status=active').catch(() => null),
            apiGet('/api/herd/events').catch(() => null),
            apiGet('/api/herd/sale').catch(() => null),
        ]);
        ANIMALS = (an && an.ok) ? (an.items || []) : [];
        const params = (evd && evd.ok) ? (evd.params || []) : [];
        ['exit_way', 'buyer', 'exit_reason'].forEach((k) => {
            const p = params.find((x) => x.key === k);
            REFS[k] = (p && p.choices) || [];
        });
        if (sale && sale.ok) DOCS = sale.docs || [];
        restore();
        if (!invs.length) addInv();
        render();
        renderHist();
    }
    const refLabel = (key, v) => {
        const c = (REFS[key] || []).find((x) => String(x.value) === String(v));
        return c ? c.label : (v || '');
    };
    const animalOf = (id) => ANIMALS.find((a) => a.id === id);

    /* ── накладні ── */
    // шапка памʼятається для НАСТУПНОЇ накладної (як постачальник у приході):
    // за день буває кілька поїздок на той самий комбінат з тією самою ціною
    const LSH = 'herd:sale_head';
    function lastHead() {
        try { return JSON.parse(localStorage.getItem(LSH) || 'null') || {}; }
        catch (e) { return {}; }
    }
    function rememberHead(v) {
        const l = v.lines[v.lines.length - 1] || {};
        try {
            localStorage.setItem(LSH, JSON.stringify({ buyer: v.buyer, exit_way: v.exit_way,
                reason: l.reason || v.lastReason || '',
                price_kg: rawNum(l.price_kg) || v.lastPrice || 0,
                vat: l.vat === undefined ? (v.lastVat === undefined ? 20 : v.lastVat) : rawNum(l.vat) }));
        } catch (e) { /* ok */ }
    }
    /* СПОСІБ ВИБУТТЯ за замовчуванням — «Продаж» (Роман 2026-09-25: «немає
       способу вибуття, зафіксувало загибель, а мені треба вимушений забій,
       вибракування на мʼясо, передано в інше господарство чи продаж»).
       Доти сторінка МОВЧКИ слала «1», а в довіднику під одиницею стоїть
       «Загибель» — тож кожен продаж лягав загибеллю. */
    function defWay() {
        const list = REFS.exit_way || [];
        const sale = list.find((c) => /продаж/i.test(c.label || ''));
        return String((sale || list[0] || {}).value || '1');
    }
    function newInv() {
        const h = lastHead();
        // ШАПКА — самі реквізити (Роман 2026-09-21: «у шапці тільки покупця,
        // номер, дату накладної, факт продажу»), а ціни, ПДВ і причина —
        // у рядках, як у приході аптеки. last* — чим заповнювати НОВИЙ рядок.
        return { id: seq++, doc_no: '', doc_date: todayISO(), fact_date: todayISO(),
            buyer: h.buyer || '', exit_way: h.exit_way || defWay(),
            collapsed: false, lines: [],
            lastPrice: h.price_kg || 0, lastVat: h.vat === undefined ? 20 : h.vat,
            lastReason: h.reason || '' };
    }
    function invOf(id) { return invs.find((v) => v.id === id); }
    function addInv() {
        const v = newInv();
        invs.unshift(v); activeId = v.id;
        render(); focusScan();
    }
    function saveDraft() {
        try { localStorage.setItem(LS, JSON.stringify({ invs, activeId, seq })); }
        catch (e) { /* приватний режим — просто не памʼятаємо */ }
    }
    function restore() {
        let d = null;
        try { d = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) { d = null; }
        if (!d || !Array.isArray(d.invs)) return;
        invs = d.invs; activeId = d.activeId || (invs[0] && invs[0].id) || 0;
        seq = d.seq || (invs.reduce((m, v) => Math.max(m, v.id), 0) + 1);
        // чернетка, набрана ДО появи поля «Спосіб вибуття», не має мовчки
        // піти «Загибеллю» — підставляємо типовий спосіб
        invs.forEach((v) => { if (!v.exit_way) v.exit_way = defWay(); });
    }

    /* ── рахунок ── */
    function lineSums(v, l) {
        const w = rawNum(l.weight);
        const p = rawNum(l.price_kg);
        const k = 1 + rawNum(l.vat) / 100;
        const nv = r2(w * p);
        return { w, p, nv, v: r2(nv * k), pv: r4(p * k) };
    }
    /* перерахунок у рядку — як у приході: ціна ↔ ціна з ПДВ, сума ділиться
       на вагу й дає ціну. Правило проти «пливучого» ПДВ: ОДНА сума рахується
       від ваги й ціни, а ДРУГА — від цієї ж суми за ставкою (а не від другої,
       округленої до 4 знаків, ціни). Інакше на партії в кілька десятків голів
       ПДВ у підвалі розходився зі ставкою на гривні. */
    function recalcLine(l, changed) {
        const k = 1 + rawNum(l.vat) / 100;
        const w = rawNum(l.weight);
        // введену суму не чіпаємо — від неї йдуть ціна й друга сума
        if (changed === 'sum_nv') {
            if (w) l.price_kg = r4(rawNum(l.sum_nv) / w);
            l.sum_v = r2(rawNum(l.sum_nv) * k);
            l.price_v = w ? r4(rawNum(l.sum_v) / w) : r4(rawNum(l.price_kg) * k);
            return;
        }
        if (changed === 'sum_v') {
            if (w) l.price_v = r4(rawNum(l.sum_v) / w);
            l.sum_nv = r2(rawNum(l.sum_v) / k);
            l.price_kg = w ? r4(rawNum(l.sum_nv) / w) : r4(rawNum(l.price_v) / k);
            return;
        }
        // змінили ціну, ставку або вагу: ведучою є та ціна, яку правили
        const leadV = changed === 'price_v'
            || (!rawNum(l.price_kg) && rawNum(l.price_v));
        if (leadV) {
            l.price_kg = r4(rawNum(l.price_v) / k);
            l.sum_v = r2(w * rawNum(l.price_v));
            l.sum_nv = r2(rawNum(l.sum_v) / k);
        } else {
            l.price_v = r4(rawNum(l.price_kg) * k);
            l.sum_nv = r2(w * rawNum(l.price_kg));
            l.sum_v = r2(rawNum(l.sum_nv) * k);
        }
    }
    /* ── розкладка гуртом ──────────────────────────────────────────────
       На комбінаті зважують і рахують ПАРТІЮ: у накладній одна вага і одна
       сума. Тут вони вписуються в смужку «Разом на всіх» і самі розходяться
       по тваринах; остання тварина забирає копійки округлення, тож підсумок
       дорівнює введеному точно. */
    function spreadWeight(v, total) {
        const n = v.lines.length;
        if (!n || total <= 0) return;
        const cur = v.lines.map((l) => rawNum(l.weight));
        const filled = cur.filter((x) => x > 0).length;
        const have = cur.reduce((a, b) => a + b, 0);
        // частину тварин уже зважили окремо: їхню вагу лишаємо, а рештою
        // документа ділимо НЕзважених; не вистачило ваги — ділимо все наново
        const rest = Math.round((total - have) * 10) / 10;
        const part = filled > 0 && filled < n && rest > 0;
        const take = v.lines.map((l, i) => (part ? cur[i] === 0 : true));
        const lastIdx = take.lastIndexOf(true);
        const cnt = take.filter(Boolean).length;
        const base = part ? rest : total;
        // наростаючим підсумком — щоб похибка десятих не накопичувалась
        let cum = 0, done = 0;
        v.lines.forEach((l, i) => {
            if (!take[i]) { recalcLine(l, 'weight'); return; }
            cum += (!part && have > 0) ? cur[i] / have : 1 / cnt;
            const upto = (i === lastIdx) ? base : Math.round(base * cum * 10) / 10;
            const w = Math.round((upto - done) * 10) / 10;
            l.weight = w; done = Math.round((done + w) * 10) / 10;
            recalcLine(l, 'weight');
        });
    }
    function spreadSum(v, total, withVat) {
        const n = v.lines.length;
        if (!n || total <= 0) return false;
        const W = v.lines.reduce((a, l) => a + rawNum(l.weight), 0);
        if (!W) return false;              // без ваги ділити нічим
        // копійки округлення забирає ОСТАННЯ зважена тварина, тож підсумок
        // дорівнює введеному точно; незважена грошей не отримує, але свою
        // ціну зберігає — інакше після вводу ваги в неї були б нулі
        const last = v.lines.reduce((m, l, i) => (rawNum(l.weight) > 0 ? i : m), -1);
        let left = total;
        v.lines.forEach((l, i) => {
            const w = rawNum(l.weight);
            const k = 1 + rawNum(l.vat) / 100;
            if (!w) { l.sum_nv = 0; l.sum_v = 0; return; }
            const s = (i === last) ? r2(left) : r2(total * w / W);
            left = r2(left - s);
            // друга сума — від ЦІЄЇ ж суми за ставкою, а не від округленої ціни
            if (withVat) {
                l.sum_v = s; l.sum_nv = r2(s / k);
                l.price_v = r4(s / w);
                l.price_kg = r4(rawNum(l.sum_nv) / w);
            } else {
                l.sum_nv = s; l.sum_v = r2(s * k);
                l.price_kg = r4(s / w);
                l.price_v = r4(rawNum(l.sum_v) / w);
            }
        });
        return true;
    }

    // ціна/ставка гуртом: рядок, у якому вже стоїть це саме число, не чіпаємо —
    // повторне застосування того самого не має рухати гроші
    function spreadPrice(v, price, withVat) {
        if (!v.lines.length || price <= 0) return;
        v.lines.forEach((l) => {
            if (withVat) {
                if (rawNum(l.price_v) === price) return;
                l.price_v = price; recalcLine(l, 'price_v');
            } else {
                if (rawNum(l.price_kg) === price) return;
                l.price_kg = price; recalcLine(l, 'price_kg');
            }
        });
    }

    function spreadReason(v, code) {
        v.lines.forEach((l) => { l.reason = code; });
        v.lastReason = code;
    }

    function spreadVat(v, vat) {
        if (!v.lines.length || vat < 0) return;
        v.lines.forEach((l) => {
            if (rawNum(l.vat) === vat) return;
            l.vat = vat; recalcLine(l, 'vat');
        });
    }

    function invTotals(v) {
        let kg = 0, nv = 0, sv = 0;
        v.lines.forEach((l) => {
            kg += rawNum(l.weight); nv += rawNum(l.sum_nv); sv += rawNum(l.sum_v);
        });
        return { heads: v.lines.length, kg, nv: r2(nv), sv: r2(sv) };
    }
    function invSumLine(v, full) {
        const t = invTotals(v);
        if (!t.heads) return full ? '' : '<span class="muted">порожня</span>';
        const head = `${t.heads} гол. · ${kgF.format(t.kg)} кг`;
        return `${head} · <b>${money.format(t.nv)}</b> ₴ без ПДВ · `
            + `<b>${money.format(t.sv)}</b> ₴ з ПДВ`
            + (full ? ` · ПДВ <b>${money.format(t.sv - t.nv)}</b> ₴` : '');
    }
    function distBar(v) {
        const t = invTotals(v);
        const f = (id, lab, val, unit) => `<label><span class="l">${lab}</span>
            <span class="fx"><input class="dq" data-d="${id}" data-inv="${v.id}" type="text"
                   inputmode="decimal" value="${val}" placeholder="0,00">`
            + (unit ? `<span class="unit">${unit}</span>` : '') + '</span></label>';
        // ціна гуртом = середня по накладній (сума ÷ вага)
        const pnv = t.kg ? r4(t.nv / t.kg) : 0, pv = t.kg ? r4(t.sv / t.kg) : 0;
        // ставка: спільна, якщо в усіх однакова; інакше — фактична з підсумків
        // причина: спільна, якщо в усіх однакова; різні — порожньо
        const rr0 = v.lines.map((l) => String(l.reason || ''));
        const rs = rr0.every((x) => x === rr0[0]) ? rr0[0] : null;
        const rates = v.lines.map((l) => rawNum(l.vat));
        const same = rates.length && rates.every((x) => x === rates[0]);
        // мішані ставки — числа НЕ показуємо: середня не є ставкою накладної,
        // а поле редаговане (так само, як «— різні —» у причині)
        const vat = same ? rates[0] : null;
        return `<div class="dist" data-inv="${v.id}">
            <span class="d-lab">Разом на всіх</span>
            ${f('w', 'вага', t.kg ? kgF.format(t.kg) : '', 'кг')}
            ${f('pnv', 'ціна без ПДВ', pnv ? priceF.format(pnv) : '', '₴/кг')}
            ${f('nv', 'сума без ПДВ', t.nv ? money.format(t.nv) : '')}
            ${f('vat', 'ПДВ', vat === null ? '' : nf.format(vat), '%')}
            ${f('pv', 'ціна з ПДВ', pv ? priceF.format(pv) : '', '₴/кг')}
            ${f('v', 'сума з ПДВ', t.sv ? money.format(t.sv) : '')}
            <label><span class="l">причина вибуття</span><span class="fx">
              <select class="dsel" data-inv="${v.id}">
                <option value="">${rs === null ? '— різні —' : '— причина —'}</option>
                ${(REFS.exit_reason || []).map((c) =>
                    `<option value="${esc(c.value)}"${String(c.value) === String(rs || '')
                        ? ' selected' : ''}>${esc(c.label)}</option>`).join('')}
              </select></span></label>
          </div>`;
    }
    function invHeadMeta(v) {
        const bits = [refLabel('buyer', v.buyer) || 'покупець не вказаний'];
        if (v.doc_no) bits.push(`№ ${v.doc_no}`);
        if (v.doc_date) bits.push(v.doc_date.split('-').reverse().join('.'));
        return esc(bits.join(' · '));
    }

    /* ── рендер накладних ── */
    function render() {
        const box = $('invs');
        if (!invs.length) {
            box.innerHTML = '<div class="inv"><div class="inv-empty">'
                + 'Натисніть «＋ Накладна», заповніть шапку — і додавайте тварин</div></div>';
            saveDraft();
            return;
        }
        box.innerHTML = invs.map((v) => {
            const act = v.id === activeId, n = v.lines.length;
            const rows = v.lines.map((l, i) => {
                const a = animalOf(l.animal_id) || {};
                const cell = (f, cls, val, ph) => `<input class="qty ${cls}" data-f="${f}"
                        data-inv="${v.id}" data-i="${i}" type="text" inputmode="decimal"
                        value="${val}" placeholder="${ph || ''}">`;
                /* під номером — реєстраційний номер (UA…), кличка, група
                   й номер лактації (Роман 2026-09-21) */
                const sub = [a.uin, l.name, a.group_name,
                    a.lactation_no ? `лакт. ${a.lactation_no}` : ''].filter(Boolean).join(' · ');
                return `<tr>
                    <td class="c-an"><span class="an-in"><b class="a-tag">${esc(l.tag)}</b>
                        <span class="a-sub">${sub ? esc(sub) : ''}</span></span></td>
                    <td class="num nw">${cell('weight', 'w-w', l.weight ? nf.format(rawNum(l.weight)) : '', '0')}<span class="unit">кг</span></td>
                    <td class="num">${cell('price_kg', 'w-p', rawNum(l.price_kg) ? priceF.format(rawNum(l.price_kg)) : '', '0,00')}</td>
                    <td class="num">${cell('sum_nv', 'w-s', rawNum(l.sum_nv) ? money.format(rawNum(l.sum_nv)) : '', '0,00')}</td>
                    <td class="num">${cell('price_v', 'w-p', rawNum(l.price_v) ? priceF.format(rawNum(l.price_v)) : '', '0,00')}</td>
                    <td class="num">${cell('sum_v', 'w-s b', rawNum(l.sum_v) ? money.format(rawNum(l.sum_v)) : '', '0,00')}</td>
                    <td><select class="r-sel" data-f="reason" data-inv="${v.id}" data-i="${i}">
                        <option value="">— причина —</option>${(REFS.exit_reason || []).map((c) =>
                            `<option value="${esc(c.value)}"${String(c.value) === String(l.reason || '')
                                ? ' selected' : ''}>${esc(c.label)}</option>`).join('')}</select></td>
                    <td><button class="rm" data-inv="${v.id}" data-i="${i}" title="Прибрати">✕</button></td>
                </tr>`;
            }).join('');
            const hdInputs = `<span class="inv-hd">
                  <label class="f-sup">Покупець *
                    <select data-hd="buyer" data-inv="${v.id}">
                      <option value="">— оберіть —</option>${(REFS.buyer || []).map((c) =>
                        `<option value="${esc(c.value)}"${String(c.value) === String(v.buyer)
                            ? ' selected' : ''}>${esc(c.label)}</option>`).join('')}</select></label>
                  <label class="f-no">№ накладної
                    <input type="text" data-hd="doc_no" data-inv="${v.id}"
                           value="${esc(v.doc_no)}" placeholder="дасться сам"></label>
                  <label class="f-dt">Дата накладної
                    <input type="date" data-hd="doc_date" data-inv="${v.id}" value="${v.doc_date}"></label>
                  <label class="f-dt">Факт продажу *
                    <input type="date" data-hd="fact_date" data-inv="${v.id}" value="${v.fact_date || v.doc_date}"></label>
                  <label class="f-way">Спосіб вибуття *
                    <select data-hd="exit_way" data-inv="${v.id}">${(REFS.exit_way || []).map((c) =>
                        `<option value="${esc(c.value)}"${String(c.value) === String(v.exit_way || defWay())
                            ? ' selected' : ''}>${esc(c.label)}</option>`).join('')}</select></label>
                </span>`;
            return `<div class="inv${act ? ' is-active' : ''}${v.collapsed ? ' is-collapsed' : ''}${v.doc_id ? ' is-edit' : ''}" data-inv="${v.id}">
              ${v.doc_id ? `<div class="inv-edmark">Правите проведену накладну <b>${esc(v.doc_no || '')}</b> — зміни підуть і в картки тварин</div>` : ''}
              <div class="inv-head" data-inv="${v.id}">
                <span class="inv-caret">▾</span>
                ${v.collapsed ? `<span class="h-hd">${invHeadMeta(v)}</span>` : hdInputs}
                <span class="inv-sum">${invSumLine(v)}</span>
                <button type="button" class="inv-print" data-inv="${v.id}"
                        title="Друк накладної на A4"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="7" rx="1"/></svg></button>
                <button class="inv-del" data-inv="${v.id}" title="${v.doc_id ? 'Вийти з правки (накладна лишиться проведеною)' : 'Видалити накладну'}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/></svg></button>
              </div>
              <div class="inv-body">
                <div class="inv-scroll">
                <table>
                  <colgroup><col class="c-tag"><col class="c-w"><col class="c-pnv">
                    <col class="c-sum"><col class="c-pv"><col class="c-sum">
                    <col class="c-reason"><col class="c-rm"></colgroup>
                  <thead><tr>
                    <th>Тварина</th><th class="num nw">Жива вага</th>
                    <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th>
                    <th class="num">Ціна з ПДВ</th>
                    <th class="num">Сума з ПДВ</th><th>Причина вибуття</th><th></th>
                  </tr></thead>
                  <tbody>${rows || '<tr><td colspan="8" class="inv-empty">'
                      + 'Уведіть номер тварини — вона потрапить сюди</td></tr>'}</tbody>
                </table>
                </div>
                ${n ? distBar(v) : ''}
                <div class="inv-foot">
                  <span class="t">${invSumLine(v, true)}</span>
                  <span class="spacer"></span>
                  ${v.doc_id ? `<button class="inv-drop" data-inv="${v.id}">Скасувати правку</button>` : ''}
                  <button class="inv-go" data-inv="${v.id}" ${n ? '' : 'disabled'}>${
                      v.doc_id ? 'Зберегти зміни' : 'Провести продаж'}</button>
                </div>
              </div>
            </div>`;
        }).join('');
        bindInvs();
        saveDraft();
    }

    /* друк НЕпроведеної накладної: дані набору відправляємо в ту саму
       серверну друковану форму (нічого не зберігається) */
    function printDraft(v) {
        if (!v.lines.length) { toast('У накладній ще немає тварин', 'warn'); return; }
        const payload = { doc_no: v.doc_no, doc_date: v.doc_date,
            fact_date: v.fact_date || v.doc_date, buyer: v.buyer,
            lines: v.lines.map((l) => {
                const a = animalOf(l.animal_id) || {};
                return { animal_id: l.animal_id, tag: l.tag,
                    animal_name: l.name || a.name || '',
                    group_name: a.group_name || '',
                    lactation_no: a.lactation_no || '',
                    weight: rawNum(l.weight), price_kg: rawNum(l.price_kg),
                    price_v: rawNum(l.price_v), vat: rawNum(l.vat),
                    sum_nv: rawNum(l.sum_nv), sum_v: rawNum(l.sum_v),
                    reason: l.reason || '' };
            }) };
        const f = document.createElement('form');
        f.method = 'POST'; f.action = '/herd/sale/invoice/preview';
        f.target = '_blank'; f.style.display = 'none';
        const inp = document.createElement('input');
        inp.type = 'hidden'; inp.name = 'data'; inp.value = JSON.stringify(payload);
        f.appendChild(inp); document.body.appendChild(f);
        f.submit(); f.remove();
    }

    function focusScan() {
        const s = $('saleScan');
        if (s) { s.focus(); s.select(); }
    }
    function focusCell(invId, i, f) {
        const el = document.querySelector(`.qty[data-inv="${invId}"][data-i="${i}"][data-f="${f}"]`);
        if (el) { el.focus(); el.select(); }
    }
    function softRefresh(v) {
        const card = document.querySelector(`.inv[data-inv="${v.id}"]`);
        if (!card) return;
        v.lines.forEach((l, i) => {
            const tr = card.querySelectorAll('tbody tr')[i];
            if (!tr) return;
            // оновлюємо сусідні поля, КРІМ того, в якому зараз курсор
            const put = (f, val) => {
                const el = tr.querySelector(`.qty[data-f="${f}"]`);
                if (!el || el === document.activeElement) return;
                el.value = val;
            };
            put('price_kg', rawNum(l.price_kg) ? priceF.format(rawNum(l.price_kg)) : '');
            put('price_v', rawNum(l.price_v) ? priceF.format(rawNum(l.price_v)) : '');
            put('sum_nv', rawNum(l.sum_nv) ? money.format(rawNum(l.sum_nv)) : '');
            put('sum_v', rawNum(l.sum_v) ? money.format(rawNum(l.sum_v)) : '');
            put('weight', rawNum(l.weight) ? nf.format(rawNum(l.weight)) : '');
            const rsel = tr.querySelector('.r-sel');
            if (rsel && rsel !== document.activeElement) rsel.value = l.reason || '';
        });
        card.querySelector('.inv-sum').innerHTML = invSumLine(v);
        card.querySelector('.inv-foot .t').innerHTML = invSumLine(v, true);
        const t = invTotals(v);
        const putD = (d, val) => {
            const el = card.querySelector(`.dq[data-d="${d}"]`);
            if (!el || el === document.activeElement) return;
            el.value = val;
        };
        putD('w', t.kg ? kgF.format(t.kg) : '');
        putD('nv', t.nv ? money.format(t.nv) : '');
        putD('v', t.sv ? money.format(t.sv) : '');
        putD('pnv', t.kg && t.nv ? priceF.format(r4(t.nv / t.kg)) : '');
        putD('pv', t.kg && t.sv ? priceF.format(r4(t.sv / t.kg)) : '');
        const rr = v.lines.map((l) => rawNum(l.vat));
        putD('vat', rr.length && rr.every((x) => x === rr[0]) ? nf.format(rr[0]) : '');
        const rr0 = v.lines.map((l) => String(l.reason || ''));
        const ds = card.querySelector('.dsel');
        if (ds && ds !== document.activeElement) {
            const one = rr0.every((x) => x === rr0[0]);
            ds.options[0].text = one ? '— причина —' : '— різні —';
            ds.value = one ? (rr0[0] || '') : '';
        }
        saveDraft();
    }

    function bindInvs() {
        const box = $('invs');
        box.querySelectorAll('.inv-head').forEach((h) => h.addEventListener('click', (e) => {
            if (e.target.closest('.inv-del') || e.target.closest('.inv-hd')) return;
            const id = +h.dataset.inv, v = invOf(id);
            if (activeId !== id) { activeId = id; v.collapsed = false; }
            else v.collapsed = !v.collapsed;
            render();
            if (!v.collapsed) focusScan();
        }));
        box.querySelectorAll('.inv-hd input, .inv-hd select').forEach((inp) => {
            const v = invOf(+inp.dataset.inv);
            inp.addEventListener('focus', () => { activeId = v.id; });
            const put = () => {
                const f = inp.dataset.hd;
                v[f] = (f === 'price_kg' || f === 'vat') ? rawNum(inp.value) : inp.value;
                if (f === 'price_kg' || f === 'vat') softRefresh(v);
                rememberHead(v);
                saveDraft();
            };
            inp.addEventListener('input', put);
            inp.addEventListener('change', put);
        });
        box.querySelectorAll('button.inv-print').forEach((b) => b.addEventListener('click', (e) => {
            e.stopPropagation();
            printDraft(invOf(+b.dataset.inv));
        }));
        const dropInv = (v, ask) => {
            // ⚠️ У режимі правки ✕ НЕ чіпає проведену накладну — лише закриває
            // правку. Скасувати сам документ можна в «Історії» (там кошик).
            if (ask && v.lines.length && !confirm(v.doc_id
                ? 'Вийти з правки? Незбережені зміни зникнуть.'
                : 'Видалити накладну разом із тваринами?')) return;
            invs = invs.filter((x) => x.id !== v.id);
            if (activeId === v.id) activeId = (invs[0] || {}).id || 0;
            if (!invs.length) addInv();
            if (v.doc_id) setView('hist');
            render();
        };
        box.querySelectorAll('.inv-del').forEach((b) => b.addEventListener('click', () =>
            dropInv(invOf(+b.dataset.inv), true)));
        box.querySelectorAll('.inv-drop').forEach((b) => b.addEventListener('click', () =>
            dropInv(invOf(+b.dataset.inv), true)));
        box.querySelectorAll('.rm').forEach((b) => b.addEventListener('click', () => {
            const v = invOf(+b.dataset.inv);
            v.lines.splice(+b.dataset.i, 1);
            render(); focusScan();
        }));
        box.querySelectorAll('.r-sel').forEach((sel) => sel.addEventListener('change', () => {
            invOf(+sel.dataset.inv).lines[+sel.dataset.i].reason = sel.value;
            saveDraft();
        }));
        box.querySelectorAll('.dq').forEach((q) => {
            const v = invOf(+q.dataset.inv);
            q.addEventListener('focus', () => { activeId = v.id; q.select(); });
            q.addEventListener('input', () => {
                const pos = q.selectionStart;
                q.value = q.value.replace(/[^0-9.,]/g, '');
                q.setSelectionRange(pos, pos);
            });
            // розкладаємо, коли число введене повністю (Enter або перехід далі)
            q.addEventListener('change', () => {
                const x = rawNum(q.value), d = q.dataset.d;
                if (!v.lines.length) { softRefresh(v); return; }
                if (d === 'vat') spreadVat(v, x);            // 0% теж ставка
                else if (x <= 0) { softRefresh(v); return; }
                else if (d === 'w') spreadWeight(v, x);
                else if (d === 'pnv' || d === 'pv') spreadPrice(v, x, d === 'pv');
                else if (!spreadSum(v, x, d === 'v')) {
                    toast('Спершу вкажіть вагу — сума ділиться за вагою', 'warn');
                }
                // НЕ render(): перемальовка картки зʼїдала перший клік по
                // «Провести продаж» і переводила Tab у нікуди
                softRefresh(v);
            });
            q.addEventListener('keydown', (e) => {
                if (e.key !== 'Enter') return;
                e.preventDefault(); q.blur(); focusScan();
            });
        });
        box.querySelectorAll('.dsel').forEach((sel) => sel.addEventListener('change', () => {
            const v = invOf(+sel.dataset.inv);
            activeId = v.id;
            spreadReason(v, sel.value);
            softRefresh(v);
        }));
        box.querySelectorAll('.qty').forEach((q) => {
            const v = invOf(+q.dataset.inv);
            const l = () => v.lines[+q.dataset.i];
            q.addEventListener('input', () => {
                const pos = q.selectionStart;
                q.value = q.value.replace(/[^0-9.,]/g, '');
                q.setSelectionRange(pos, pos);
                const row = l();
                row[q.dataset.f] = q.value;
                recalcLine(row, q.dataset.f);
                softRefresh(v);
            });
            q.addEventListener('focus', () => { activeId = v.id; q.select(); });
            q.addEventListener('blur', () => {
                const f = q.dataset.f, x = rawNum(l()[f]);
                q.value = !x ? (f === 'vat' ? nf.format(0) : '')
                    : (f === 'weight' || f === 'vat') ? nf.format(x)
                    : (f === 'sum_nv' || f === 'sum_v') ? money.format(x) : priceF.format(x);
            });
            q.addEventListener('keydown', (e) => {
                if (e.key !== 'Enter') return;
                e.preventDefault();
                if (q.dataset.f === 'weight' && !rawNum(l().price_kg)) {
                    focusCell(v.id, +q.dataset.i, 'price_kg');
                } else focusScan();
            });
        });
        box.querySelectorAll('.inv-go').forEach((b) => b.addEventListener('click', () => post(+b.dataset.inv)));
    }

    /* ── додавання тварини ── */
    let acIdx = -1;
    function acRender(q) {
        const box = $('saleAc');
        const s = String(q || '').trim().toLowerCase();
        const v = invOf(activeId);
        const used = new Set((v ? v.lines : []).map((l) => l.animal_id));
        const list = ANIMALS.filter((a) => !used.has(a.id)).filter((a) => {
            if (!s) return true;
            return String(a.tag || '').toLowerCase().includes(s)
                || String(a.name || '').toLowerCase().includes(s);
        }).slice(0, 12);
        if (!list.length) { box.hidden = true; box.innerHTML = ''; acIdx = -1; return; }
        box.innerHTML = list.map((a) => `<div class="lg-sug-item" data-id="${a.id}">
                <span class="s-tag">${esc(a.tag)}</span>`
            + (a.name ? `<span class="s-name">${esc(a.name)}</span>` : '')
            + (a.group_name ? `<span class="s-name">· ${esc(a.group_name)}</span>` : '')
            + '</div>').join('');
        box.hidden = false; acIdx = 0;
        box.querySelector('.lg-sug-item').classList.add('is-active');
        box.querySelectorAll('.lg-sug-item').forEach((r) => r.addEventListener('click', () => {
            addAnimal(+r.dataset.id);
        }));
    }
    function acMove(step) {
        const items = [...$('saleAc').querySelectorAll('.lg-sug-item')];
        if (!items.length) return;
        items.forEach((x) => x.classList.remove('is-active'));
        acIdx = (acIdx + step + items.length) % items.length;
        items[acIdx].classList.add('is-active');
        items[acIdx].scrollIntoView({ block: 'nearest' });
    }
    function addAnimal(id) {
        const a = animalOf(id);
        if (!a) return;
        let v = invOf(activeId);
        if (!v) { addInv(); v = invOf(activeId); }
        if (v.lines.some((l) => l.animal_id === a.id)) {
            toast(`№${a.tag} вже в накладній`, 'warn'); return;
        }
        const prev = v.lines[v.lines.length - 1];
        v.lines.push({ animal_id: a.id, tag: a.tag, name: a.name || '', weight: '',
            price_kg: prev ? prev.price_kg : (v.lastPrice || ''),
            vat: prev ? prev.vat : (v.lastVat === undefined ? 20 : v.lastVat),
            price_v: prev ? prev.price_v : '',
            reason: prev ? prev.reason : (v.lastReason || ''),
            sum_nv: '', sum_v: '' });
        v.collapsed = false;
        $('saleScan').value = ''; $('saleAc').hidden = true; acIdx = -1;
        render();
        focusCell(v.id, v.lines.length - 1, 'weight');
    }

    /* ── проведення ── */
    /* ⚠️ ЗАМОК ПЕРШИМ РЯДКОМ. Накладна лишається на екрані, доки сервер
       відповідає, а кнопка «Провести продаж» жива — друге натискання
       проводить ТОЙ САМИЙ документ удруге: тварини вибувають двома записами,
       вага й сума задвоюються. Той самий урок, що в груповому вводі
       (2.39.55). */
    let posting = false;
    async function post(invId) {
        if (posting) return;
        posting = true;
        const btn = document.querySelector(`.inv-go[data-inv="${invId}"]`);
        const was = btn ? btn.textContent : '';
        if (btn) { btn.disabled = true; btn.textContent = 'Проводжу…'; }
        try {
            await postRun(invId);
        } finally {
            posting = false;
            // кнопка могла зникнути разом із проведеною накладною
            const b2 = document.querySelector(`.inv-go[data-inv="${invId}"]`);
            if (b2) { b2.disabled = false; b2.textContent = was || 'Провести продаж'; }
        }
    }

    async function postRun(invId) {
        const v = invOf(invId);
        if (!v || !v.lines.length) { toast('Додайте тварин', 'warn'); return; }
        const noW = v.lines.filter((l) => !rawNum(l.weight));
        if (noW.length) {
            toast(`Без ваги: ${noW.map((l) => '№' + l.tag).join(', ')}`, 'warn');
            const i = v.lines.indexOf(noW[0]);
            focusCell(v.id, i, 'weight');
            return;
        }
        const noP = v.lines.filter((l) => !rawNum(l.price_kg) && !rawNum(l.price_v));
        if (noP.length) {
            toast(`Без ціни: ${noP.map((l) => '№' + l.tag).join(', ')}`, 'warn');
            focusCell(v.id, v.lines.indexOf(noP[0]), 'price_kg');
            return;
        }
        if (!v.buyer) { toast('Оберіть покупця', 'warn'); return; }
        const t = invTotals(v);
        const edit = !!v.doc_id;      // правимо проведену чи проводимо нову
        if (!confirm(edit
            ? `Зберегти зміни в накладній ${v.doc_no}?\n`
                + `${t.heads} гол. · ${kgF.format(t.kg)} кг · ${money.format(t.sv)} ₴ з ПДВ.\n`
                + 'Події вибуття в картках тварин перепишуться.'
            : `Провести продаж${v.doc_no ? ' ' + v.doc_no : ''}?\n`
                + `${t.heads} гол. · ${kgF.format(t.kg)} кг · ${money.format(t.sv)} ₴ з ПДВ.\n`
                + 'Тварини вибудуть зі стада.')) return;
        const payload = {
            doc_no: v.doc_no, doc_date: v.doc_date, fact_date: v.fact_date || v.doc_date,
            buyer: v.buyer, exit_way: v.exit_way || defWay(),
            lines: v.lines.map((l) => ({
                id: l.line_id || 0,            // порожній — нова тварина в накладній
                animal_id: l.animal_id, tag: l.tag, weight: rawNum(l.weight),
                price_kg: rawNum(l.price_kg), price_v: rawNum(l.price_v),
                vat: rawNum(l.vat), sum_nv: rawNum(l.sum_nv), sum_v: rawNum(l.sum_v),
                reason: l.reason || '',
            })),
        };
        const r = edit
            ? await apiSend('/api/herd/sale/' + v.doc_id, 'POST', payload)
            : await apiSend('/api/herd/sale', 'POST', payload);
        if (!r || !r.ok) { toast((r && r.error) || (edit ? 'Не збережено' : 'Не проведено'), 'error'); return; }
        const bad = (r.failed || []).length;
        if (edit) {
            const bits = [];
            if (r.added) bits.push(`додано ${r.added}`);
            if (r.removed) bits.push(`прибрано ${r.removed}`);
            toast(bad ? `Збережено, не вдалося ${bad}`
                : `Накладну ${r.doc_no} виправлено${bits.length ? ' · ' + bits.join(', ') : ''}`,
                bad ? 'warn' : 'ok');
        } else {
            toast(bad ? `Проведено ${r.applied}, не вдалося ${bad}` : `Накладна ${r.doc_no} проведена`,
                bad ? 'warn' : 'ok');
        }
        if (!bad) {
            rememberHead(v);
            invs = invs.filter((x) => x.id !== v.id);
            if (!invs.length) addInv(); else activeId = invs[0].id;
            if (edit) setView('hist');       // виправили — вертаємось в історію
        }
        await reloadDocs();
        render();
    }


    /* ПРАВКА ПРОВЕДЕНОЇ НАКЛАДНОЇ — ТІЄЮ САМОЮ ФОРМОЮ, ЩО Й ПРОДАЖ
       (Роман 2026-09-25: «форма редагування повинна бути один в один, як
       форма внесення»). Тому окремої форми немає зовсім: накладна з історії
       кладеться в ту саму картку набору, лише з `doc_id` — і далі працює все
       звичне: перерахунок цін, додавання тварини номером, розподіл сум,
       друк. Кнопка внизу каже «Зберегти зміни», а не «Провести продаж». */
    function editDoc(d) {
        if (invs.some((x) => x.doc_id === d.id)) {   // вже відкрита на правку
            activeId = invs.find((x) => x.doc_id === d.id).id;
            setView('sale'); render();
            return;
        }
        const v = {
            id: seq++, doc_id: d.id, doc_no: d.doc_no || '',
            doc_date: (d.doc_date || '').slice(0, 10),
            fact_date: (d.fact_date || d.doc_date || '').slice(0, 10),
            buyer: d.buyer || '', exit_way: String(d.exit_way || defWay()),
            collapsed: false,
            lines: (d.lines || []).map((l) => ({
                line_id: l.id, animal_id: l.animal_id, tag: l.tag,
                name: l.animal_name || '',
                weight: nf.format(l.weight || 0),
                price_kg: priceF.format(l.price_kg || 0),
                sum_nv: money.format(l.sum_nv || 0),
                vat: nf.format(l.vat || 0),
                price_v: priceF.format(l.price_v || 0),
                sum_v: money.format(l.sum_v || 0),
                reason: l.reason || '',
            })),
            lastPrice: (d.lines || [])[0] ? rawNum((d.lines || [])[0].price_kg) : 0,
            lastVat: (d.lines || [])[0] ? rawNum((d.lines || [])[0].vat) : 20,
            lastReason: ((d.lines || [])[0] || {}).reason || '',
        };
        invs.unshift(v);
        activeId = v.id;
        setView('sale');
        render();
    }

    /* ── історія ── */
    async function reloadDocs() {
        const q = periodQuery();
        const r = await apiGet('/api/herd/sale' + q).catch(() => null);
        DOCS = (r && r.ok) ? (r.docs || []) : [];
        renderHist();
    }
    function periodQuery() {
        const d = new Date();
        const iso = (x) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
        if (per === 'today') return `?from=${iso(d)}&to=${iso(d)}&limit=200`;
        if (per === 'week') {
            const a = new Date(d); a.setDate(d.getDate() - 6);
            return `?from=${iso(a)}&to=${iso(d)}&limit=200`;
        }
        if (per === 'month') {
            const a = new Date(d.getFullYear(), d.getMonth(), 1);
            return `?from=${iso(a)}&to=${iso(d)}&limit=200`;
        }
        if (per === 'prevmonth') {
            const a = new Date(d.getFullYear(), d.getMonth() - 1, 1);
            const b = new Date(d.getFullYear(), d.getMonth(), 0);
            return `?from=${iso(a)}&to=${iso(b)}&limit=200`;
        }
        if (per === 'range') {
            const f = $('histFrom').value, t = $('histTo').value;
            if (f || t) return `?from=${f}&to=${t}&limit=200`;
        }
        return '?limit=15';
    }

    function renderHist() {
        const box = $('histRows');
        const q = histQ.trim().toLowerCase();
        const list = DOCS.filter((d) => {
            if (!q) return true;
            const hay = [d.doc_no, refLabel('buyer', d.buyer),
                ...(d.lines || []).map((l) => l.tag)].join(' ').toLowerCase();
            return hay.includes(q);
        });
        if (!list.length) {
            box.innerHTML = '<div class="inv"><div class="inv-empty">За цей період накладних немає</div></div>';
            return;
        }
        let tHeads = 0, tKg = 0, tNv = 0, tV = 0;
        list.forEach((d) => { tHeads += d.heads; tKg += d.kg; tNv += d.total_nv; tV += d.total_v; });
        box.innerHTML = `<div class="hist-total">Всього: <b>${list.length}</b> накл. · `
            + `<b>${tHeads}</b> гол. · <b>${kgF.format(tKg)}</b> кг · `
            + `<b>${money.format(tNv)}</b> ₴ без ПДВ · <b>${money.format(tV)}</b> ₴ з ПДВ · `
            + `ПДВ <b>${money.format(tV - tNv)}</b> ₴</div>`
            + list.map((d) => `<div class="inv is-collapsed" data-doc="${d.id}">
              <div class="inv-head">
                <span class="inv-caret">▾</span>
                <span class="h-hd"><b>${esc(d.doc_no)}</b> · ${esc((d.doc_date || '').split('-').reverse().join('.'))}`
                + `${d.fact_date && d.fact_date !== d.doc_date ? ' · факт ' + esc(d.fact_date.split('-').reverse().join('.')) : ''}`
                + `${d.buyer ? ' · ' + esc(refLabel('buyer', d.buyer)) : ''} · ${d.heads} гол. · ${kgF.format(d.kg)} кг</span>
                <span class="inv-sum"><b>${money.format(d.total_v)}</b> ₴ з ПДВ</span>
                <a class="inv-print" href="/herd/sale/${d.id}/invoice" target="_blank"
                   rel="noopener" title="Друк накладної на A4"
                   onclick="event.stopPropagation()"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="7" rx="1"/></svg></a>
                <button class="inv-ed-btn" data-edit="${d.id}" title="Виправити накладну: дати, номер, покупця, ціни й ПДВ"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></button>
                <button class="inv-del" data-doc="${d.id}" title="Скасувати накладну"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/></svg></button>
              </div>
              <div class="inv-body"><div class="inv-scroll"><table>
                <thead><tr><th>Тварина</th><th class="num">Вага</th>
                  <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th>
                  <th class="num">ПДВ %</th><th class="num">Ціна з ПДВ</th>
                  <th class="num">Сума з ПДВ</th><th>Причина</th></tr></thead>
                <tbody>${(d.lines || []).map((l) => `<tr>
                  <td class="c-an"><span class="an-in"><b class="a-tag">${esc(l.tag)}</b>
                      <span class="a-sub">${esc(l.animal_name || '')}</span></span></td>
                  <td class="num">${kgF.format(l.weight)} кг</td>
                  <td class="num">${priceF.format(l.price_kg)}</td>
                  <td class="num">${money.format(l.sum_nv)}</td>
                  <td class="num">${nf.format(l.vat || 0)}</td>
                  <td class="num">${priceF.format(l.price_v || 0)}</td>
                  <td class="num b">${money.format(l.sum_v)}</td>
                  <td>${esc(refLabel('exit_reason', l.reason))}</td></tr>`).join('')}</tbody>
              </table></div></div>
            </div>`).join('');
        box.querySelectorAll('.inv-head').forEach((h) => h.addEventListener('click', (e) => {
            if (e.target.closest('.inv-del') || e.target.closest('.inv-ed-btn')) return;
            h.parentElement.classList.toggle('is-collapsed');
        }));
        box.querySelectorAll('.inv-ed-btn').forEach((b) => b.addEventListener('click', (e) => {
            e.stopPropagation();
            const d = DOCS.find((x) => String(x.id) === String(b.dataset.edit));
            if (d) editDoc(d);
        }));
        box.querySelectorAll('.inv-del').forEach((b) => b.addEventListener('click', async () => {
            const d = DOCS.find((x) => String(x.id) === String(b.dataset.doc));
            if (!confirm(`Скасувати накладну ${d.doc_no}?\n${d.heads} гол. повернуться в стадо.`)) return;
            const r = await apiSend('/api/herd/sale/' + d.id, 'DELETE');
            if (!r || !r.ok) { toast((r && r.error) || 'Не скасовано', 'error'); return; }
            toast(`Накладну скасовано, повернуто ${r.returned} гол.`);
            await reloadDocs();
        }));
    }

    /* ── звʼязки сторінки ── */
    function setView(v) {
        const hist = v === 'hist';
        $('viewSeg').querySelectorAll('.cat-tab').forEach((x) =>
            x.classList.toggle('is-active', (x.dataset.view === 'hist') === hist));
        $('viewSale').hidden = hist;
        $('viewHist').hidden = !hist;
        if (hist) reloadDocs(); else focusScan();
    }
    $('viewSeg').addEventListener('click', (e) => {
        const b = e.target.closest('.cat-tab');
        if (b) setView(b.dataset.view);
    });
    $('histPer').addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (!b) return;
        $('histPer').querySelectorAll('.seg-btn').forEach((x) => x.classList.toggle('is-active', x === b));
        per = b.dataset.per;
        $('histRange').hidden = per !== 'range';
        reloadDocs();
    });
    ['histFrom', 'histTo'].forEach((id) => $(id).addEventListener('change', () => {
        if (per === 'range') reloadDocs();
    }));
    $('histQ').addEventListener('input', (e) => { histQ = e.target.value; renderHist(); });
    $('addInv').addEventListener('click', addInv);
    $('collapseAll').addEventListener('click', () => {
        const any = invs.some((v) => !v.collapsed);
        invs.forEach((v) => { v.collapsed = any; });
        render();
    });
    $('saleScan').addEventListener('input', (e) => acRender(e.target.value));
    $('saleScan').addEventListener('focus', () => acRender($('saleScan').value));
    $('saleScan').addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); acMove(1); return; }
        if (e.key === 'ArrowUp') { e.preventDefault(); acMove(-1); return; }
        if (e.key === 'Escape') { $('saleAc').hidden = true; return; }
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const items = [...$('saleAc').querySelectorAll('.lg-sug-item')];
        const it = items[acIdx] || items[0];
        if (it) { addAnimal(+it.dataset.id); return; }
        toast('Тварину не знайдено', 'warn');
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#saleScan') && !e.target.closest('#saleAc')) $('saleAc').hidden = true;
    });

    load();
}());
