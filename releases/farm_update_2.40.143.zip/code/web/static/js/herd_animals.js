/* Реєстр тварин (поголівний облік) — Фаза 1. */
'use strict';

/* Типи подій живуть у ДОВІДНИКУ (herd_event_defs) — проведення через
   Журнал (/herd/log): одна система, ефекти застосовуються завжди. */

let ALL_GROUPS = [];
let STATUSES = {};

const $ = (id) => document.getElementById(id);
const bind = (id, ev, fn) => { const el = $(id); if (el) el.addEventListener(ev, fn); };
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------- фільтри ----------
   Вибір фільтрів памʼятається між сторінками (Роман 2026-09-15): перемикач
   тварин у шапці гілки гортає САМЕ цю вибірку, тож він має знати, що обрано,
   навіть коли людина пішла з реєстру на календар чи рух поголівʼя. */
const FLT_KEY = 'herd:filters';

function selText(id) {
    const el = $(id);
    const o = el && el.options[el.selectedIndex];
    return (o && o.value) ? o.textContent.trim() : '';
}

function curFilters() {
    return {
        q: $('animSearch').value.trim(),
        status: $('animStatus').value,
        sex: $('animSex').value,
        group_id: $('animGroup').value,
        // назви — щоб перемикач у шапці підписував вибірку словами
        // («Нетелі»), а не кодом: на інших сторінках цих списків немає
        group_name: selText('animGroup'),
        status_name: selText('animStatus'),
    };
}

function saveFilters(f) {
    try { localStorage.setItem(FLT_KEY, JSON.stringify(f)); } catch (e) { /* ignore */ }
}

function restoreFilters() {
    let f = null;
    try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
    if (!f) return;
    if (f.q) $('animSearch').value = f.q;
    // статус і секцію ставимо ПІСЛЯ того, як наповняться списки (fillFilters)
    pendingFilters = f;
}

let pendingFilters = null;

/* ---------- колонки ----------
   Роман 2026-09-17: «таке саме налаштування колонок у реєстрі тварин», як у
   груповому вводі. Бирка є завжди; решта — параметри з КОНСТРУКТОРА (назви
   теж звідти: «усі параметри повинні йти із списку, із конструктора»).
   Частину з них реєстр уже має в самій тварині — такі клітинки малюємо з
   неї, без запиту значень. Набір свій у кожного й лежить на сервері. */
const DEFAULT_COLS = ['name', 'sex', 'age_months', 'breed', 'group', 'lactation', 'status'];
let COLS = null;
let PARAMS = [];
let LAST_ITEMS = [];
// колонки, що беруться з самої тварини (без запиту параметрів)
const CORE_COLS = {
    name: { label: 'Кличка', cell: (a) => escapeHtml(a.name || '') },
    sex: { label: 'Стать', cell: (a) => escapeHtml(a.sex ? herdOpt('sex', a.sex) : '') },
    // ⚠️ «Вік» — ЄДИНА вбудована колонка, у якої в Конструкторі може стояти
    // СВОЯ формула, і саме за нею добирає FILTER. Доти колонка малювала вік
    // самої тварини (повні календарні місяці), а умова рахувала формулу — і
    // в списку стояло «11», хоча умова age>=12 його пропустила (Роман
    // 2026-09-26). Тепер показуємо ТЕ САМЕ число, за яким іде добір.
    age_months: { label: 'Вік, міс', num: true,
        cell: (a) => {
            const v = a.p ? a.p.age_months : undefined;
            if (v !== undefined && v !== null && v !== '') return escapeHtml(String(v));
            return (a.age_months == null ? '' : a.age_months);
        } },
    breed: { label: 'Порода', cell: (a) => escapeHtml(a.breed || '') },
    group: { label: 'Секція', cell: (a) => escapeHtml(a.group_name || '') },
    // 0 — це телиці, нетелі й бики: показуємо нуль, а не порожнечу
    lactation: { label: 'Лакт.', num: true,
        cell: (a) => (a.lactation_no == null ? '' : a.lactation_no) },
    status: { label: 'Статус',
        cell: (a) => `<span class="anim-badge ${a.status}">${escapeHtml(a.status_label || '')}</span>` },
};
const paramOf = (k) => PARAMS.find((p) => p.key === k) || null;

function colLabel(k) {
    const p = paramOf(k);                  // назва — як у конструкторі
    if (p) return p.label;
    return CORE_COLS[k] ? CORE_COLS[k].label : k;
}

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}

function paramCell(a, k) {
    const raw = (a.p || {})[k];
    if (raw === null || raw === undefined || raw === '') return '';
    const num = numText(raw, (paramOf(k) || {}).dtype);
    if (num !== null) return escapeHtml(num);
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = k === 'repro_code' ? '' : (a.pl || {})[k];
    if (lbl) return escapeHtml(lbl);
    const p = paramOf(k);
    if (p && p.dtype === 'date' && /^\d{4}-\d{2}-\d{2}/.test(String(raw))) {
        const [y, m, d] = String(raw).slice(0, 10).split('-');
        return `${d}.${m}.${y}`;
    }
    // довгі номери (транспондер) — по три цифри, як у картці тварини
    if (/^\d{9,}$/.test(String(raw))) return String(raw).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
    return escapeHtml(String(raw));
}

/* ---------- вкладка «Робота зі стадом» ----------
   Рядок-формула своєю мовою (herd_query.js): ФІЛЬТР(…) ПОКАЗАТИ(…)
   ГРУПУВАТИ(…) СОРТУВАТИ(…). Нічого не зберігається — це разова вибірка. */
const AW_KEY = 'herd:work_formula';
/* ⚠️ «=» ПЕРЕД ФОРМУЛОЮ (Роман 2026-09-22: «не прибрав символ = перед
   формулою всередині»). Знак рівності стоїть ОКРЕМИМ значком ліворуч від
   поля — а в самому полі він дублювався, бо зберігається разом із формулою
   («=BODY(…)»). Тепер у полі його не показуємо, а в сховищі й у збережених
   списках лишаємо, щоб старі списки й посилання далі читались. */
const awNoEq = (t) => String(t === null || t === undefined ? '' : t).replace(/^\s*=\s*/, '');
const awWithEq = (t) => { const v = awNoEq(t).trim(); return v ? '=' + v : ''; };
/* ПАНЕЛІ «ОГЛЯДУ» Й ПОСИЛАННЯ «[Назва]» — у спільному модулі herd_panels.js
   (аналіз 2026-09-26, пакет 3): там добір тварин формулою, розбір показників,
   точний пошук звіту, підрахунок і формат показу. Сторінка дає модулю свій
   світ — збережені списки, панелі й параметри стада. */
const { qRows, aggValue, splitRatio, fxAllParts, refKey, refCanon, refExpand, fxSides, fxCheck,
    tableFx, fxHasRef, refDependents, refTaken, refLookup, refName, newId, ratioOf, ovCountOn, partInk,
    ovBlocks, ovParts, ovIsComposite, ovShown,
    ovmPicksOf, ovmFormulaOf, ovGuarded, ovmWhyNot, ovComponentIds, ovSecMove } = window.herdPanels;
window.herdPanels.use({ lists: () => WLISTS, tiles: () => OV, params: () => PARAMS, events: evGet });
/* ПОКАЗНИКИ З ПОДІЙ (Роман 2026-09-29: «на огляді… плитку отелів або відсоток — така сама
   логіка»): EVENT(calving) FILTER(lact>0) VIEW(month_1) рахує сервер тим самим рушієм, що й
   «Рух поголівʼя». Модуль панелей питає число тут; немає — «…», а всі невідомі частини йдуть
   на сервер ОДНИМ запитом, і тоді плитки й переліки перемальовуються. Значення живе 5 хв. */
const EVM = new Map();                            // формула → {v, cnt, …} | {err}, t — коли пораховано
const EV_TTL = 300000;
let EV_WANT = new Set(), EV_BUSY = false, EV_TIMER = 0;
function evGet(text) {
    const k = String(text || '').trim();
    const hit = EVM.get(k);
    if (hit && Date.now() - hit.t < EV_TTL) return hit.r;
    EV_WANT.add(k);
    if (!EV_TIMER) EV_TIMER = setTimeout(evFetch, 30);
    return hit ? hit.r : null;                    // давнє число видно, поки рахується нове
}
/* GET, а не POST: той, хто лише переглядає, POST на /api/ не має права слати. Пачка — до
   ~5 000 знаків адреси, решта — наступним запитом */
const evUrl = (keys, items) => '/api/herd/event-values?' + new URLSearchParams(
    keys.map((k) => ['f', k]).concat(items ? [['items', '1']] : [])).toString();
async function evFetch() {
    EV_TIMER = 0;
    if (EV_BUSY || !EV_WANT.size) return;
    const want = [];
    for (const k of EV_WANT) {
        if (want.length && (want.length >= 40 || evUrl(want.concat([k])).length > 5000)) break;
        want.push(k);
    }
    want.forEach((k) => EV_WANT.delete(k));
    EV_BUSY = true;
    const r = await apiGet(evUrl(want)).catch(() => null);
    EV_BUSY = false;
    const now = Date.now();
    const why = (r && r.ok === false && r.error) || 'не вдалося порахувати — спробую ще';
    want.forEach((k) => {
        const v = r && r.ok !== false && r.values ? r.values[k] : null;
        // збій чи «спитай ще» — повторимо за хвилину, а не щопівхвилини по колу
        const again = !v || v.retry;
        EVM.set(k, { t: again ? now - EV_TTL + 60000 : now, r: (v && !v.retry) ? v : { err: v ? v.err : why } });
    });
    evRedraw();
    if (EV_WANT.size) EV_TIMER = setTimeout(evFetch, 30);
}
/* перед збереженням: формула з подіями мусить розібратись на сервері (Enter не пише биту) */
async function evCheck(formula) {
    const keys = window.herdPanels.evSides(formula);
    if (!keys.length) return '';
    const r = await apiGet(evUrl(keys)).catch(() => null);
    if (!r || r.ok === false || !r.values) return (r && r.error) || 'не вдалося перевірити формулу з подіями';
    const bad = keys.map((k) => r.values[k]).find((v) => !v || v.err);
    if (bad === undefined) {
        const now = Date.now();
        keys.forEach((k) => EVM.set(k, { t: now, r: r.values[k] }));
        return '';
    }
    return bad ? bad.err : 'не порахувалось';
}
function evRedraw() {                             // нові числа з подій — плитки, переліки, рядок формули
    if (typeof ovRender === 'function') ovRender();
    if (typeof ovRailRender === 'function' && $('ovRailList')) ovRailRender();
    if ($('awPanList') && !PAN_CLOSED) panList();
    if ($('awRailList')) railList();
    if (typeof awEvRedraw === 'function') awEvRedraw();
}
/* прочитані тварини лежать у памʼяті: поки формула не просить НОВИХ
   параметрів, наступний запуск миттєвий — без звернення до сервера */
let WORK_CACHE = null;
const CACHE_TTL = 120000;
/* Остання вибірка «Роботи зі стадом» живе в памʼяті браузера між заходами:
   таблиця малюється одразу, а свіжі дані підтягуються слідом
   (Роман 2026-09-19: «моментальна робота»). */
const WORK_STORE = 'herd:work_cache';
function workCacheSave() {
    try {
        localStorage.setItem(WORK_STORE, JSON.stringify({
            keys: [...WORK_CACHE.keys], items: WORK_CACHE.items, at: WORK_CACHE.at,
            groups: ALL_GROUPS }));
    } catch (e) { /* місця немає — обійдемось памʼяттю сторінки */ }
}
function workCacheLoad() {
    try {
        const c = JSON.parse(localStorage.getItem(WORK_STORE) || 'null');
        if (c && Array.isArray(c.items) && c.items.length) {
            // з іншого заходу — могли змінитись, тож завжди перечитуємо слідом
            if (!ALL_GROUPS.length && Array.isArray(c.groups)) ALL_GROUPS = c.groups;
            return { keys: new Set(c.keys || []), items: c.items, at: c.at || 0, stored: true };
        }
    } catch (e) { /* ignore */ }
    return null;
}
let TAB = 'reg';
let Q = null;                        // розібрана формула
let ALL_ITEMS = [];
const qOn = () => TAB === 'work' && !!(Q && (Q.cols.length || Q.filters.length
    || Q.sorts.length || Q.groups.length));
const effCols = () => (qOn() && Q.cols.length ? Q.cols : COLS);
const stripTags = (h) => String(h === null || h === undefined ? '' : h)
    .replace(/<[^>]*>/g, '').trim();          // «0» лишається нулем, не порожнечею

let colsSaveT = null;
function saveCols() {
    clearTimeout(colsSaveT);
    colsSaveT = setTimeout(() => {
        apiSend('/api/herd/ui-columns', 'POST', { scope: 'registry', columns: COLS })
            .then((r) => {
                if (!r || !r.ok) { toast('Колонки не збережено', 'error'); return; }
                // памʼять старту — теж, інакше наступний захід вважав би
                // колонки «зміненими» і малював таблицю двічі
                try {
                    const b = JSON.parse(localStorage.getItem(BOOT_KEY) || 'null');
                    if (b) { b.cols = COLS; localStorage.setItem(BOOT_KEY, JSON.stringify(b)); }
                } catch (e) { /* ignore */ }
            });
    }, 500);
}

/* Перелік параметрів, налаштування і колонки — у памʼяті браузера: сторінка
   стартує одразу з них, а свіже читається слідом (Роман 2026-09-24:
   «перемальовка секунда, наче притормажує» — таблиця чекала в черзі за
   переліком параметрів разом із подіями, яких ця сторінка не показує). */
const BOOT_KEY = 'herd:anim_boot';
function bootFromMemory() {
    try {
        const b = JSON.parse(localStorage.getItem(BOOT_KEY) || 'null');
        if (!b || !Array.isArray(b.params) || !b.params.length) return false;
        PARAMS = b.params;
        window.HERD_CONSTS = b.consts || [];
        COLS = (b.cols || DEFAULT_COLS).filter((k) => paramOf(k));
        return true;
    } catch (e) { return false; }
}

/* true — перелік змінився проти того, з чим сторінка стартувала */
async function loadColumns() {
    const [c, ev] = await Promise.all([
        apiGet('/api/herd/ui-columns?scope=registry'),
        // лише параметри й налаштування — без подій і прав доступу
        apiGet('/api/herd/events?active=1&lite=1'),
    ]);
    if (!ev || !ev.ok) return false;              // сервер не відповів — лишаємо, що є
    const before = JSON.stringify([PARAMS, window.HERD_CONSTS || [], COLS]);
    PARAMS = ev.params || [];
    // налаштування ферми — їхні назви працюють в умовах формули
    window.HERD_CONSTS = ev.consts || [];
    const saved = c && c.ok ? c.columns : null;
    // лише те, що є в конструкторі
    COLS = (saved || DEFAULT_COLS).filter((k) => paramOf(k));
    try {
        localStorage.setItem(BOOT_KEY, JSON.stringify({
            params: PARAMS, consts: window.HERD_CONSTS, cols: saved }));
    } catch (e) { /* місця немає — стартуватимемо з сервера */ }
    return JSON.stringify([PARAMS, window.HERD_CONSTS, COLS]) !== before;
}

/* ---------- список ---------- */
async function loadList() {
    const f = curFilters();
    const params = new URLSearchParams();
    // у «Роботі зі стадом» добір задає формула, а не панель фільтрів
    if (TAB !== 'work') Object.keys(f).forEach((k) => { if (f[k]) params.set(k, f[k]); });
    saveFilters(f);
    if (COLS === null) await loadColumns();
    // значення параметрів: колонки + усе, що згадала формула
    // у «Роботі зі стадом» разом із колонками беремо й те, що потрібне
    // числам рейки: доти рейка читала ВСЕ стадо окремим другим запитом
    // «tag» просимо завжди, коли працює формула: ним розводяться однакові
    // значення в автоматичному порядку (за першим параметром списку)
    const need = [...new Set([...effCols(), ...((qOn() && Q.keys) || []),
        ...(qOn() ? ['tag'] : []), ...(TAB === 'work' ? railNeed() : [])])]
        .filter((k) => qOn() || TAB === 'work' || !CORE_COLS[k]);
    if (need.length) params.set('params', need.join(','));
    // у «Роботі зі стадом» беремо лише потрібні поля — відповідь удвічі легша
    if (TAB === 'work') params.set('lean', '1');
    // той самий запит уже в дорозі (старт із памʼяті + свіжий перелік) —
    // не питаємо вдруге; застарілу відповідь не малюємо: інакше та, що
    // прийшла ОСТАННЬОЮ, а не найновіша, переписала б таблицю
    const qs = params.toString();
    const seq = ++LIST_SEQ;
    const req = (TAB === 'work' && WORK_LOADING && WORK_QS === qs)
        ? WORK_LOADING : apiGet('/api/herd/animals?' + qs);
    if (TAB === 'work') { WORK_LOADING = req; WORK_QS = qs; }
    let r;
    try { r = await req; } finally {
        if (WORK_LOADING === req) { WORK_LOADING = null; WORK_QS = null; }
    }
    if (seq !== LIST_SEQ) return;
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    STATUSES = r.statuses || {};
    ALL_GROUPS = r.groups || [];
    fillFilters();
    if (pendingFilters) {                   // списки готові — ставимо збережене
        const f0 = pendingFilters;
        pendingFilters = null;
        if (f0.status) $('animStatus').value = f0.status;
        if (f0.sex) $('animSex').value = f0.sex;
        if (f0.group_id) $('animGroup').value = f0.group_id;
        if (f0.status || f0.sex || f0.group_id) { loadList(); return; }
    }
    renderStats(r.stats || {});
    ALL_ITEMS = r.items || [];
    if (TAB === 'work') {                          // запамʼятовуємо, що вже прочитано
        WORK_CACHE = { keys: new Set(need), items: ALL_ITEMS, at: Date.now() };
        workCacheSave();
        railCounts();                              // числа рейки — з цих самих даних
    }
    renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
    // перемикач у шапці гортає цю саму вибірку — віддаємо йому свіжий
    // порядок замість того, щоб він питав сервер удруге
    if (window.herdNav) window.herdNav.cacheList(r.items || []);
}

function fillFilters() {
    const st = $('animStatus');
    if (st.options.length <= 1) {
        // «вибулі» — не окремий статус, а всі, крім тих, що в стаді; те саме
        // значення розуміють перемикач у смужці й панель добору
        const gone = document.createElement('option');
        gone.value = 'gone'; gone.textContent = 'Вибулі';
        st.appendChild(gone);
        Object.entries(STATUSES).forEach(([k, v]) => {
            const o = document.createElement('option'); o.value = k; o.textContent = v;
            st.appendChild(o);
        });
    }
    const g = $('animGroup');
    if (g.options.length <= 1) {
        ALL_GROUPS.forEach((gr) => {
            const o = document.createElement('option'); o.value = gr.id; o.textContent = gr.name;
            g.appendChild(o);
        });
    }
}

function renderStats(s) {
    $('animStats').innerHTML =
        `<div class="anim-stat"><b>${s.active || 0}</b><span>${escapeHtml(herdOpt('status', 'active', 'В стаді'))}</span></div>` +
        `<div class="anim-stat"><b>${s.cows || 0}</b><span>${escapeHtml(herdOpt('sex', 'F', 'Корів/телиць'))}</span></div>`;
}

/* порядок секцій — ПОВНИЙ список Конструктора (у варіантах параметра лише
   секції з чинним періодом, тож секція без періоду випадала з порядку) */
function sortParamsFor() {
    if (!ALL_GROUPS.length) return PARAMS;
    return PARAMS.map((p) => (p.key === 'group'
        ? Object.assign({}, p, { choices: ALL_GROUPS.map((g) => ({ value: g.name, label: g.name })) })
        : p));
}

/* добір і порядок — за формулою */
/* хто потрапив у список ДОДАТКОВИМ блоком (FILTER2…): id → назва блоку */
let EXTRA_OF = new Map();

function applyQ(items) {
    if (!qOn()) return items;
    EXTRA_OF = new Map();
    let out = qRows(Q, items, EXTRA_OF);
    // порядок груп — за Конструктором; «sort <параметр групи> desc» перевертає групи
    const dirOf = (k) => ((Q.sorts.find((sx) => sx.key === k) || {}).dir || 'asc');
    const order = Q.groups.map((k) => ({ key: k, dir: dirOf(k) }))
        .concat(Q.sorts.filter((sx) => !Q.groups.includes(sx.key)));
    // Порядку не задано — список іде за ПЕРШИМ своїм параметром (Роман
    // 2026-09-26: «списки треба автоматично сортувати по першому параметру»).
    // Доти такий список ішов так, як його віддала база: за номером РЯДКОМ,
    // тож «999» стояло після «42657». У формулу це не дописується — написали
    // своє «sort», і воно головніше.
    const auto = !Q.sorts.length;
    if (auto) {
        const first = (Q.cols || []).find((k) => paramOf(k));
        if (first && !Q.groups.includes(first)) order.push({ key: first, dir: 'asc' });
        // однакові значення (уся секція) розводить номер тварини — інакше
        // всередині групи порядок лишався б випадковим
        if (order.length && !order.some((sx) => sx.key === 'tag')) {
            order.push({ key: 'tag', dir: 'asc' });
        }
    }
    if (order.length && auto && EXTRA_OF.size) {
        // упорядковуємо КОЖЕН блок окремо: спершу основні, далі додані
        // (FILTER2) — будова списку лишається така, як була, змінюється лише
        // порядок усередині. Написане «sort» діє на ВЕСЬ список, як і доти.
        const blocks = new Map();
        out.forEach((a) => {
            const n = EXTRA_OF.get(a.id) || '';
            if (!blocks.has(n)) blocks.set(n, []);
            blocks.get(n).push(a);
        });
        out = [...blocks.values()].flatMap(
            (part) => window.herdQuery.sortRows(part, order, sortParamsFor()));
    } else if (order.length) {
        out = window.herdQuery.sortRows(out, order, sortParamsFor());
    }
    return out;
}

const TAG_KEYS = ['tag', 'id'];
/* у «Роботі зі стадом» шапка коротка — тими самими словами, що й у формулі */
function headLabel(k) {
    const p = paramOf(k);
    return qOn() ? (p ? awShort(p) : k) : colLabel(k);
}
const tagInCols = () => effCols().some((k) => TAG_KEYS.includes(k));
/* Назва додаткового блоку стоїть ЗЛІВА ВІД НОМЕРА, у тій самій клітинці
   (Роман 2026-09-24: «не окремо колонку, а зліва від номера — але щоб номер
   не зміщався»). Місце під позначку зарезервоване В КОЖНОМУ рядку, тож номери
   стоять на одній вертикалі; на папері позначка теж видна. */
const exCol = () => qOn() && EXTRA_OF.size > 0;
const EX_HEAD = 'Дод.';                        // у вивантаженні — окрема колонка

function renderHead() {
    const html = (qOn() && Q.rownum ? '<th class="num">№</th>' : '')
        + (tagInCols() ? '' : `<th>${escapeHtml(qOn()
            ? (paramOf('tag') ? awShort(paramOf('tag')) : 'id')
            : herdLabel('tag', 'Номер тварини'))}</th>`)
        + effCols().map((k) => {
        const p = paramOf(k);
        const num = (CORE_COLS[k] && CORE_COLS[k].num) || (!CORE_COLS[k] && p && ['int', 'float'].includes(p.dtype));
        const p2 = paramOf(k);
        return `<th${num ? ' class="num"' : ''}`
            + `${qOn() && p2 ? ` title="${escapeHtml(p2.label)}"` : ''}>`
            + `${escapeHtml(headLabel(k))}</th>`;
    }).join('');
    $('animHead').innerHTML = html;
}

let ROW_NO = 0;
function rowHtml(a) {
    ROW_NO += 1;
    const cells = [];
    if (qOn() && Q.rownum) cells.push(`<td class="num">${ROW_NO}</td>`);
    if (!tagInCols()) cells.push(`<td><b>${escapeHtml(a.tag)}</b></td>`);
    effCols().forEach((k) => {
        if (CORE_COLS[k]) {
            cells.push(`<td data-k="${escapeHtml(k)}"${CORE_COLS[k].num ? ' class="num"' : ''}>${CORE_COLS[k].cell(a)}</td>`);
            return;
        }
        const p = paramOf(k);
        const num = p && ['int', 'float'].includes(p.dtype);
        cells.push(`<td data-k="${escapeHtml(k)}"${num ? ' class="num"' : ''}>${paramCell(a, k)}</td>`);
    });
    const ex = EXTRA_OF.get(a.id);
    // позначка йде В КЛІТИНКУ НОМЕРА, місце під неї є в кожному рядку —
    // інакше номери «стрибали» б на позначених рядках
    if (exCol()) {
        const i = (qOn() && Q.rownum) ? 1 : 0;
        cells[i] = cells[i].replace(/^<td/, '<td data-ex="1"')
            .replace(/^(<td[^>]*>)/, `$1<i class="exm">${escapeHtml(ex || '')}</i>`);
    }
    return `<tr data-id="${a.id}"${ex ? ` class="is-extra" title="${escapeHtml(ex)}"` : ''}>${cells.join('')}</tr>`;
}

/* ---------- увесь добір → «Груповий ввід» (Роман 2026-09-22) ----------
   Спершу тут були галочки в рядках, але Роман: «прибери галочки, просто
   зроби посилання на груповий ввід і збережи фільтрацію». Тож туди їде
   ВЕСЬ добір — САМОЮ ФОРМУЛОЮ (?f=…), тож там список живий і рахується
   на місці, а не приїжджає замороженим переліком номерів. */

function awGoUpd() {
    const b = $('awEvent');
    if (!b) return;
    const n = (qOn() && Q.cols.length) ? LAST_ITEMS.length : 0;
    b.hidden = !n;
    b.textContent = `Груповий ввід · ${n}`;
    b.title = 'Внести подію для всіх тварин цього списку';
}

/* підсумки: кількість і середнє/сума по числових параметрах */
const numFmt = (v, dec) => (Math.round(v * 10 ** dec) / 10 ** dec)
    .toLocaleString('uk-UA', { minimumFractionDigits: dec, maximumFractionDigits: dec });

function aggText(rows) {
    const aggs = (qOn() && Q.aggs) || [];
    // «N гол.» показуємо, поки не попросили cnt окремо
    const out = aggs.some((a) => a.fn === 'cnt') ? [] : [`<b>${rows.length}</b> гол.`];
    aggs.forEach((a) => {
        if (a.fn === 'cnt') {                     // кількість: усіх або із заповненим параметром
            const n = a.key
                ? rows.filter((x) => {
                    const v = (x.p || {})[a.key];
                    return !(v === null || v === undefined || v === '');
                }).length
                : rows.length;
            const p0 = a.key ? paramOf(a.key) : null;
            out.push(`cnt${p0 ? ' ' + escapeHtml(p0.short || p0.key) : ''} <b>${n}</b>`);
            return;
        }
        const nums = rows.map((x) => {
            const raw = (x.p || {})[a.key];
            const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
            return Number.isFinite(n) ? n : null;
        }).filter((n) => n !== null);
        if (!nums.length) return;
        const p = paramOf(a.key);
        const nm = p ? (p.short || p.key) : a.key;
        const v = a.fn === 'sum' ? nums.reduce((t, n) => t + n, 0)
            : a.fn === 'min' ? Math.min(...nums)
            : a.fn === 'max' ? Math.max(...nums)
            : nums.reduce((t, n) => t + n, 0) / nums.length;
        // назви агрегацій — ті самі слова, що й у формулі
        const dec = ['sum', 'min', 'max'].includes(a.fn) ? 0 : 1;
        out.push(`${a.fn} ${escapeHtml(nm)} <b>${numFmt(v, dec)}</b>`);
    });
    return out.join(' · ');
}

/* підсумковий рядок таблиці: числа стоять У СВОЇХ колонках, без підписів
   (Роман 2026-09-18: «вигрупування напроти стовпця — чіткіше») */
function sumRowHtml(rows, title, cls, attrs) {
    const aggs = (qOn() && Q.aggs) || [];
    const cols = effCols();
    const byCol = new Map();
    const rest = [];
    aggs.forEach((a) => {
        const v = aggValue(a, rows);
        if (v === null) return;
        const dec = a.fn === 'avg' ? 1 : 0;
        const txt = numFmt(v, dec);
        if (a.key && cols.includes(a.key)) {           // кілька агрегацій на колонку — поруч
            const cur = byCol.get(a.key) || { fns: [], txts: [] };
            cur.fns.push(a.fn); cur.txts.push(txt);
            byCol.set(a.key, cur);
        } else if (a.fn === 'cnt' && !a.key) rest.push(txt);   // просто кількість, без підпису
        else rest.push(`${a.fn}${a.key ? ' ' + escapeHtml(colShort(a.key)) : ''} ${txt}`);
    });
    const head = escapeHtml(title) + (aggs.some((a) => a.fn === 'cnt' && !a.key)
        ? '' : ` · ${rows.length}`)
        + (rest.length ? ` · ${rest.join(' · ')}` : '');
    // назва групи займає колонки ДО першої з числом — інакше вона розсуває «id»
    const lead = (qOn() && Q.rownum ? 1 : 0) + (tagInCols() ? 0 : 1);
    let firstNum = cols.findIndex((k) => byCol.has(k));
    if (firstNum < 0) firstNum = cols.length;
    const titleSpan = lead + firstNum - (qOn() && Q.rownum ? 1 : 0);
    let html = `<tr class="${cls}"${attrs || ''}>`;
    if (qOn() && Q.rownum) html += '<td></td>';
    html += `<td colspan="${Math.max(1, titleSpan)}">${head}</td>`;
    cols.slice(tagInCols() ? firstNum : firstNum).forEach((k, i) => {
        if (i + firstNum < firstNum) return;
        const hit = byCol.get(k);
        html += `<td${isNumCol(k) ? ' class="num"' : ''}`
            + `${hit ? ` title="${hit.fns.join(' · ')}"` : ''}>`
            + `${hit ? `<b>${hit.txts.join(' · ')}</b>` : ''}</td>`;
    });
    return html + '</tr>';
}

const colShort = (k) => { const p = paramOf(k); return p ? (p.short || p.key) : k; };
const isNumCol = (k) => {
    if (CORE_COLS[k] && CORE_COLS[k].num) return true;
    const p = paramOf(k);
    return !!p && ['int', 'float', 'number'].includes(p.dtype);
};

function aggRow(rows, cls) {
    if (!qOn() || (!Q.aggs.length && !Q.groups.length)) return '';
    const span = effCols().length + (tagInCols() ? 0 : 1) + (Q.rownum ? 1 : 0);
    return `<tr class="anim-sum ${cls || ''}"><td colspan="${span}">${aggText(rows)}</td></tr>`;
}

/* групи формули — рядком-шапкою, як у календарі */
function groupedHtml(items, lvl) {
    const gs = (qOn() && Q.groups) || [];
    if (lvl >= gs.length) {
        if (gs.length && Q.rownum === 'group') ROW_NO = 0;   // VIEW(nogroup) — у кожній групі з 1
        return items.map(rowHtml).join('');
    }
    const k = gs[lvl];
    let by = new Map();
    items.forEach((a) => {
        const _t = stripTags(CORE_COLS[k] ? CORE_COLS[k].cell(a) : paramCell(a, k));
        const t = _t === '' || _t == null ? '— не вказано' : _t;   // «0» — теж значення
        if (!by.has(t)) by.set(t, []);
        by.get(t).push(a);
    });
    // порядок самих груп: якщо в sort стоїть параметр, однаковий у межах групи
    // (напр. «№ секції» при групуванні за секцією) — групи шикуються за ним
    const gsort = ((qOn() && Q.sorts) || []).find((sx) => {
        if (sx.key === k) return true;
        return [...by.values()].every((part) => {
            const v0 = (part[0].p || {})[sx.key];
            return part.every((a) => (a.p || {})[sx.key] === v0);
        });
    });
    if (gsort) {
        const rows = [...by.entries()].map(([t, part]) => ({ t, part, a: part[0] }));
        const sorted = window.herdQuery.sortRows(rows.map((x) => x.a),
            [{ key: gsort.key, dir: gsort.dir }], sortParamsFor());
        const pos = new Map(sorted.map((a, idx) => [a, idx]));
        rows.sort((x, y) => pos.get(x.a) - pos.get(y.a));
        by = new Map(rows.map((x) => [x.t, x.part]));
    }
    const span = effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0);
    const pre = gs.length > 1 ? `${escapeHtml(headLabel(k))}: ` : '';
    // шапка групи: назва + числа агрегацій у своїх колонках
    // рівень групи — у класі (l0, l1…): друк повторює на новому аркуші й батьківську шапку
    const gcls = `anim-grp l${Math.min(lvl, 2)}`;
    // ⚠️ САМЕ значення групи тримаємо в атрибутах рядка, а не лише в його
    // тексті: у шапці поруч стоять і кількість, і агрегації, тож вивантаження
    // в Excel мусило б виколупувати значення з рядка — і помилялось би.
    const gat = (t) => ` data-gkey="${escapeHtml(k)}" data-glvl="${lvl}"`
        + ` data-gval="${escapeHtml(t)}"`;
    return [...by.entries()].map(([t, part]) =>
        (qOn() && Q.aggs.length
            ? sumRowHtml(part, pre + t, gcls, gat(t))
            : `<tr class="${gcls}"${gat(t)}><td colspan="${span}">${pre}${escapeHtml(t)} · ${part.length}</td></tr>`)
        + groupedHtml(part, lvl + 1)).join('');
}

function renderTable(items, total) {
    LAST_ITEMS = items;
    // у «Роботі зі стадом» таблиця по ширині вмісту, а не на все вікно
    const tbl = document.querySelector('.anim-table');
    tbl.classList.toggle('auto-w', qOn());
    delete tbl.dataset.colsResizable;              // шапка перемальовується
    delete tbl.dataset.colsFixed;
    tbl.classList.remove('is-sized');
    tbl.style.tableLayout = '';
    tbl.style.width = '';
    renderHead();
    const all = total === undefined ? items.length : total;
    const nEx = items.filter((a) => EXTRA_OF.has(a.id)).length;
    $('animCount').textContent = items.length
        ? `· ${nEx ? `${items.length - nEx} + ${nEx}` : items.length}`
            + `${qOn() && all !== items.length ? ` із ${all}` : ''}` : '';
    const tb = $('animBody');
    if (!items.length) {
        tb.innerHTML = `<tr><td colspan="${effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0)}" class="empty">${qOn()
            ? 'За цією формулою нікого' : 'Немає тварин. Додайте або імпортуйте.'}</td></tr>`;
        return;
    }
    ROW_NO = 0;
    tb.innerHTML = groupedHtml(items, 0)
        + (qOn() && Q.aggs.length ? sumRowHtml(items, 'Разом', 'anim-sum all')
            : (qOn() && Q.groups.length ? aggRow(items, 'all') : ''));
    // ширину колонок можна тягнути за межу заголовка; памʼятається в браузері
    // У «Роботі зі стадом» ширину не чіпаємо руками: колонка сама стає
    // за найширшим вмістом (Роман 2026-09-18). Ручний ресайз — лише в реєстрі.
    if (!qOn()) requestAnimationFrame(() => makeColumnsResizable('animTable', 'herd:reg_colw'));
    awKeepWidth();
    awGoUpd();
    tb.querySelectorAll('tr[data-id]').forEach((tr) => {
        tr.addEventListener('click', () => {
            const a = items.find((x) => String(x.id) === String(tr.dataset.id));
            if (a && window.herdNav) window.herdNav.setCurrent(a);
            location.href = '/herd/animals/' + tr.dataset.id;
        });
    });
}

/* ⚠️ ТАБЛИЦЯ НЕ ВУЖЧАЄ ВІД ОНОВЛЕННЯ (Роман 2026-09-22). Один і той самий
   список малюється ДВІЧІ — спершу з памʼяті, а за мить із сервера, — і колонки
   щоразу міряються наново за вмістом, тож ширина сіпалась на очах. Тепер для
   відкритої формули памʼятаємо найбільшу заміряну ширину кожної колонки і
   ставимо її НИЖНЬОЮ межею: довший текст колонку ще розсуне, коротший —
   уже ні. Нова формула — міряємо з чистого аркуша. */
let WKEEP_SIG = '', WKEEP = [];
function awKeepWidth() {
    const tbl = $('animTable');
    if (!tbl || !tbl.tHead || !qOn()) { WKEEP_SIG = ''; WKEEP = []; return; }
    const ths = [...tbl.tHead.rows[0].cells];
    const sig = ($('awInput').value || '').trim();
    if (sig !== WKEEP_SIG) { WKEEP_SIG = sig; WKEEP = []; }
    ths.forEach((th) => { th.style.minWidth = ''; });        // міряємо вільно
    const now = ths.map((th) => Math.round(th.getBoundingClientRect().width));
    WKEEP = ths.map((th, i) => Math.max(WKEEP[i] || 0, now[i] || 0));
    ths.forEach((th, i) => { if (WKEEP[i]) th.style.minWidth = WKEEP[i] + 'px'; });
}

/* ---------- модал додати/редагувати ---------- */
function groupOptions(sel) {
    return '<option value="">—</option>' + ALL_GROUPS.map((g) =>
        `<option value="${g.id}"${String(g.id) === String(sel || '') ? ' selected' : ''}>${escapeHtml(g.name)}</option>`).join('');
}

/* ═══ ФОРМА ТВАРИНИ: УСІ АКТИВНІ ПАРАМЕТРИ, ТАБЛИЧНИМ СТИЛЕМ ═══
   Роман 2026-09-25: «якщо ми кажемо про нову тварину, то повинна бути форма
   внесення абсолютно всіх активних параметрів; треба позначити, які
   обовʼязкові… маленький табличний стиль».
   📌 Форма БУДУЄТЬСЯ З ПЕРЕЛІКУ ПАРАМЕТРІВ, а не написана руками: завели в
   Конструкторі новий параметр — він сам зʼявився тут, у своїй секції. Доти
   форма знала одинадцять полів, і все інше доводилось дописувати в картці
   вже після збереження.
   📌 Обчислювані параметри (з формулою) сюди НЕ йдуть: їх не вводять, вони
   рахуються. Обовʼязковість бере прапорець параметра (Конструктор →
   Параметри → «Обовʼязковий при заведенні тварини»); бирка — завжди. */

/* поля, які форма показує: активні, не обчислювані; у порядку секцій */
function afFields() {
    const out = PARAMS.filter((p) => !(p.formula || '').trim());
    const secs = [];
    out.forEach((p) => {
        const s = p.section || 'Інше';
        if (!secs.includes(s)) secs.push(s);
    });
    return secs.map((s) => ({ name: s, items: out.filter((p) => (p.section || 'Інше') === s) }));
}

/* ЧИ ОБОВʼЯЗКОВЕ ПОЛЕ ЗАРАЗ. Сталий прапорець — або УМОВА, написана тією
   самою мовою, що в списках (Роман 2026-09-25: «якщо лактація більше нуля,
   тоді треба обовʼязково вказати дату отелу» → `lact>0` у параметрі).
   Умова читається на кожну зміну форми, тож зірочка зʼявляється й зникає
   на очах — розбір формули кешуємо, щоб не робити його на кожну літеру. */
const AF_COND = new Map();
function afCondOf(p) {
    const c = (p.req_if || '').trim();
    if (!c) return null;
    if (AF_COND.has(c)) return AF_COND.get(c);
    let f = null;
    try {
        const q = window.herdQuery.parse('FILTER(' + c + ')', PARAMS);
        f = (q && !q.error && (q.filters || []).length) ? q.filters : null;
    } catch (e) { f = null; }
    AF_COND.set(c, f);
    return f;
}
function AF_REQ(p, vals) {
    if (p.key === 'tag' || p.req_new) return true;
    const f = afCondOf(p);
    if (!f || !vals) return false;
    try {
        return window.herdQuery.passes(Object.assign({ p: vals }, vals), f);
    } catch (e) { return false; }
}

/* Які поля залежать від ЦЬОГО (Роман 2026-09-25: «дати підказку під № лактації,
   коли вона >0 — які саме поля через це стали обовʼязковими»). Ключі беремо з
   самої умови, тож підказка зʼявляється під тим полем, яке її вмикає. */
function afTriggers() {
    const by = new Map();
    PARAMS.forEach((p) => {
        const f = afCondOf(p);
        (f || []).forEach((c) => {
            if (!c.key) return;
            if (!by.has(c.key)) by.set(c.key, []);
            if (!by.get(c.key).includes(p)) by.get(c.key).push(p);
        });
    });
    return by;
}

/* одне поле таблиці: назва ліворуч, ввід праворуч */
function afField(p, val, vals) {
    const req = AF_REQ(p, vals);
    const lbl = escapeHtml(p.label || p.key) + (p.unit ? ` <i>${escapeHtml(p.unit)}</i>` : '')
        + `<b class="af-star"${req ? '' : ' hidden'}> *</b>`;
    const v = val === undefined || val === null ? '' : String(val);
    let inp;
    if (p.key === 'group') {
        inp = `<select data-k="group">${groupOptions(v)}</select>`;
    } else if ((p.options || []).length || (p.choices || []).length) {
        // список значень. ⚠️ Беремо `options`, а не `choices`: у другому
        // мітка йде з кодом («born — Власні») — це для рядка формули, де код
        // треба бачити; у формі тварини потрібна сама назва.
        const opts = (p.options && p.options.length)
            ? p.options.map((o) => (typeof o === 'string'
                ? { c: o, l: o } : { c: o.c, l: o.l }))
            : (p.choices || []).map((c) => ({ c: c.value, l: c.label }));
        inp = `<select data-k="${escapeHtml(p.key)}"><option value="">—</option>`
            + opts.map((o) => `<option value="${escapeHtml(o.c)}"`
                + `${String(o.c) === v ? ' selected' : ''}>${escapeHtml(o.l)}</option>`).join('')
            + '</select>';
    } else {
        // дробове — текстове поле з комою (Роман 2026-09-29)
        const dec = ['float', 'number'].includes(p.dtype);
        const t = p.dtype === 'date' ? 'date' : (p.dtype === 'int' ? 'number' : 'text');
        const step = p.dtype === 'int' ? ' step="1"' : (dec ? ' inputmode="decimal" data-dec' : '');
        inp = `<input type="${t}"${step} data-k="${escapeHtml(p.key)}" value="${escapeHtml(dec ? window.decText(v) : v)}">`;
    }
    return `<label class="af-f" data-p="${escapeHtml(p.key)}"><span>${lbl}</span>${inp}`
        + '<em class="af-why" hidden></em></label>';
}

/* Початкові значення форми: те, що правильне для більшості нових тварин. */
function afDefaults() {
    return { sex: 'F', source: 'born', entry_date: todayISO(), lactation: 0 };
}

/* Малюємо форму НА ВКЛАДЦІ (Роман 2026-09-25: «перенеси додати тварину на
   головну, зроби це вкладку»). Доти вона жила у вікні й після збереження
   вела в картку — заводити кількох підряд було незручно. */
let AF_DRAWN = false, AF_ONLY_REQ = false;
async function afOpen(vals) {
    const box = $('afBody');
    if (!box) return;
    if (AF_DRAWN && !vals) return;               // повернулись на вкладку — не перемальовуємо
    // ⚠️ Форма будується З ПАРАМЕТРІВ, а вони можуть іще не прийти: у свіжому
    // браузері памʼяті старту немає, і вкладка малювала б ПОРОЖНЮ форму.
    if (!PARAMS.length) {
        try { await loadColumns(); } catch (e) { /* сервер мовчить — далі перевірка */ }
    }
    if (!PARAMS.length) {
        box.innerHTML = '<div class="hp-empty">Параметри ще не прочитались — оновіть сторінку</div>';
        return;
    }
    // ⚠️ Те саме про СЕКЦІЇ: «Група» бралася з уже прочитаного списку стада,
    // і при вході одразу на вкладку випадайка була порожня
    if (!ALL_GROUPS.length) {
        try {
            const g = await apiGet('/api/herd/groups');
            ALL_GROUPS = (g && (g.groups || g.items)) || [];
        } catch (e) { /* лишиться порожньою — видно одразу */ }
    }
    const v = vals || afDefaults();
    box.innerHTML = afFields().map((s) =>
        `<div class="af-sec">${escapeHtml(s.name)}</div><div class="af-grid">`
        + s.items.map((p) => afField(p, v[p.key], v)).join('') + '</div>').join('');
    const nreq = PARAMS.filter((p) => !(p.formula || '').trim() && p.req_new).length;
    const cond = PARAMS.filter((p) => !(p.formula || '').trim() && (p.req_if || '').trim()).length;
    $('afNote').innerHTML = `<b>*</b> — обовʼязкові: ${nreq}`
        + (cond ? `, ще ${cond} за умовою` : '')
        + ' (задаються в Конструкторі → Параметри). Після «Додати в реєстр» форма'
        + ' лишається заповненою — очищаються номер, кличка, UIN, батьки й нотатка.';
    afStars();
    $('afMiss').textContent = '';
    AF_DRAWN = true;
    adRender();
    const first = box.querySelector('[data-k="tag"]');
    if (first) first.focus();
}

/* що зараз набрано у формі */
function afVals() {
    const vals = {};
    $('afBody').querySelectorAll('[data-k]').forEach((el) => {
        vals[el.dataset.k] = (el.value || '').trim();
    });
    return vals;
}

/* зірочки умовних полів — на очах: поставили лактацію 2, і «Дата останнього
   отелу» одразу стала обовʼязковою */
function afStars() {
    const box = $('afBody');
    if (!box) return;
    const vals = afVals();
    PARAMS.forEach((p) => {
        const row = box.querySelector(`.af-f[data-p="${p.key}"]`);
        if (!row) return;
        const req = AF_REQ(p, vals);
        row.classList.toggle('is-req', req);       // з цього живе «лише обовʼязкові»
        if (!(p.req_if || '').trim()) return;
        const f = row.querySelector('.af-star');
        if (f) f.hidden = !req;
    });
    // у режимі «лише обовʼязкові» секція без жодного поля не має стояти порожня
    box.querySelectorAll('.af-sec').forEach((sec) => {
        const grid = sec.nextElementSibling;
        if (!grid || !grid.classList.contains('af-grid')) return;
        const on = !AF_ONLY_REQ
            || !!grid.querySelector('.af-f.is-req');
        sec.hidden = !on;
        grid.hidden = !on;
    });
    // під полем, яке ввімкнуло умову, кажемо ЩО саме стало обовʼязковим
    afTriggers().forEach((list, key) => {
        const why = box.querySelector(`.af-f[data-p="${key}"] .af-why`);
        if (!why) return;
        const on = list.filter((p) => AF_REQ(p, vals)).map((p) => p.label || p.key);
        why.textContent = on.length ? 'через це обовʼязкові: ' + on.join(', ') : '';
        why.hidden = !on.length;
    });
}

/* ═══ ПЕРЕЛІК ДОДАНИХ — щоб було видно, кого щойно внесли ═══
   Роман 2026-09-25: «ті тварини, які ми будемо вносити, будемо додавати
   таблично в реєстр, щоб можна було бачити, що ми додаємо».
   Тримаємо в sessionStorage: перелік переживає оновлення сторінки, але не
   тягнеться днями — це «що я зараз завів», а не звіт. */
const AD_LS = 'herd:add_log';
let ADDED = [];
try { ADDED = JSON.parse(sessionStorage.getItem(AD_LS) || '[]') || []; } catch (e) { ADDED = []; }

function adSave() {
    try { sessionStorage.setItem(AD_LS, JSON.stringify(ADDED.slice(-100))); } catch (e) { /* ignore */ }
}
function adRender() {
    const body = $('adBody');
    if (!body) return;
    const n = ADDED.length;
    $('adCount').textContent = n ? `${n} ${plural(n, 'тварина', 'тварини', 'тварин')}` : '';
    const cl = $('adClear');
    if (cl) cl.hidden = !n;
    if (!n) {
        body.innerHTML = '<tr><td colspan="8" class="ad-empty">Ще нікого не додали — '
            + 'заповніть форму вище й натисніть «Додати в реєстр».</td></tr>';
        return;
    }
    // останні — ЗВЕРХУ: щойно доданого видно без прокрутки
    body.innerHTML = ADDED.slice().reverse().map((a, i) => {
        const tag = a.id
            ? `<a href="/herd/animals/${a.id}"><b>${escapeHtml(a.tag || '')}</b></a>`
            : `<b>${escapeHtml(a.tag || '')}</b>`;
        return `<tr><td class="num">${n - i}</td><td>${tag}</td>`
            + `<td>${escapeHtml(a.name || '')}</td><td>${escapeHtml(a.sex || '')}</td>`
            + `<td>${escapeHtml(adDmy(a.birth))}</td><td>${escapeHtml(a.group || '')}</td>`
            + `<td class="num">${escapeHtml(a.lact === '' || a.lact === undefined ? '' : String(a.lact))}</td>`
            + `<td class="text-mute">${escapeHtml(a.at || '')}</td></tr>`;
    }).join('');
}
/* дата у переліку — як на фермі (25.09.2026), а не ISO */
function adDmy(v) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v || ''));
    return m ? `${m[3]}.${m[2]}.${m[1]}` : (v || '');
}
function plural(n, one, few, many) {
    const a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b === 1) return one;
    if (b >= 2 && b <= 4) return few;
    return many;
}

/* Поля, які ОЧИЩАЮТЬСЯ після додавання: те, що в кожної тварини своє.
   Решта (група, порода, звідки, дата надходження) переноситься на наступну —
   заводять же підряд по одній партії. «Очистити форму» скидає все. */
const AF_CLEAR = ['tag', 'name', 'uin', 'dam_tag', 'sire_code', 'notes'];

async function saveAnimal() {
    const box = $('afBody');
    const vals = afVals();
    // ⚠️ Перевіряємо ПЕРЕД запитом і називаємо конкретні поля: сервер знає
    // лише про бирку, а решту обовʼязкових задала сама ферма
    const miss = PARAMS.filter((p) => !(p.formula || '').trim() && AF_REQ(p, vals)
        && !String(vals[p.key] || '').trim());
    box.querySelectorAll('.af-f').forEach((f) => f.classList.remove('is-miss'));
    if (miss.length) {
        miss.forEach((p) => {
            const el = box.querySelector(`[data-k="${p.key}"]`);
            if (el) el.closest('.af-f').classList.add('is-miss');
        });
        $('afMiss').textContent = 'Не заповнено: '
            + miss.map((p) => p.label || p.key).join(', ');
        const f = box.querySelector(`[data-k="${miss[0].key}"]`);
        if (f) { f.focus(); f.scrollIntoView({ block: 'center' }); }
        return;
    }
    $('afMiss').textContent = '';
    // ядро тварини йде полями самої тварини, решта — параметрами
    const CORE = { tag: 'tag', name: 'name', sex: 'sex', birth_date: 'birth_date',
        breed: 'breed', group: 'group_id', dam_tag: 'dam_tag', sire_code: 'sire_code',
        lactation: 'lactation_no', status: 'status', source: 'source',
        entry_date: 'entry_date', notes: 'notes' };
    const payload = { params: {} };
    Object.keys(vals).forEach((k) => {
        if (CORE[k]) payload[CORE[k]] = vals[k];
        else if (vals[k] !== '') payload.params[k] = vals[k];
    });
    const btn = $('afSaveBtn');
    btn.disabled = true;
    let r;
    try {
        r = await apiSend('/api/herd/animals', 'POST', payload);
    } finally { btn.disabled = false; }
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    if (r.params_failed && r.params_failed.length) {
        toast('Збережено, але не лягло: ' + r.params_failed.join(', '), 'warn');
    } else toast(`Додано: ${vals.tag || ''}`, 'success');
    // рядок у таблицю — мітки беремо ТАКІ, ЯК ВИДНО у формі (назва секції,
    // назва статі), а не коди: перелік читає людина
    const lblOf = (k) => {
        const el = box.querySelector(`[data-k="${k}"]`);
        if (!el) return '';
        if (el.tagName === 'SELECT') return (el.selectedOptions[0] || {}).text || '';
        return el.value || '';
    };
    ADDED.push({ id: r.id || 0, tag: vals.tag || '', name: vals.name || '',
        sex: lblOf('sex'), birth: vals.birth_date || '', group: lblOf('group'),
        lact: vals.lactation === undefined ? '' : vals.lactation,
        at: new Date().toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }) });
    adSave();
    adRender();
    // форма лишається заповненою — очищаємо лише те, що в кожної своє
    AF_CLEAR.forEach((k) => {
        const el = box.querySelector(`[data-k="${k}"]`);
        if (el) el.value = '';
    });
    afStars();
    const first = box.querySelector('[data-k="tag"]');
    if (first) { first.focus(); first.scrollIntoView({ block: 'center' }); }
}

/* ⚠️ ІМПОРТ і НУМЕРАЦІЯ ПЕРЕЇХАЛИ В КОНСТРУКТОР (Роман 2026-09-25:
   «імпорт і нумерацію прибрати із огляду… це все треба перенести в
   конструктор»). Там же — імпорт даних файлом під обрану подію. Додати
   тварину теж звідти: кнопка веде сюди з ?add=1, і форма відкривається сама
   — щоб не тримати ДВІ копії тієї самої форми. */

/* ---------- init ---------- */
let searchTimer = null;
bind('animSearch', 'input', () => {
    clearTimeout(searchTimer); searchTimer = setTimeout(loadList, 250);
});
['animStatus', 'animSex', 'animGroup'].forEach((id) => bind(id, 'change', loadList));
bind('afSaveBtn', 'click', () => saveAnimal());
bind('afReset', 'click', () => afOpen(afDefaults()));
bind('afScope', 'click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (!b) return;
    AF_ONLY_REQ = b.dataset.req === '1';
    $('afScope').querySelectorAll('.seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x === b));
    $('afBody').classList.toggle('only-req', AF_ONLY_REQ);
    afStars();
});
bind('adClear', 'click', () => { ADDED = []; adSave(); adRender(); });
// умовна обовʼязковість читається на кожну зміну форми
$('afBody') && $('afBody').addEventListener('input', afStars);
$('afBody') && $('afBody').addEventListener('change', afStars);
// Enter у полі форми = «Додати в реєстр» (крім дат — там Enter відкриває
// вибір дати в частині браузерів)
$('afBody') && $('afBody').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'date') {
        e.preventDefault(); saveAnimal();
    }
});

/* ---------- збережені списки (вкладка «Списки») ----------
   Формула з назвою, категорією і коментарем; лежать на сервері — одні на
   ферму, як списки календаря. Відкритий список лишається «приєднаним», тож
   виправлену формулу можна перезберегти однією кнопкою. */
let WLISTS = [], WCATS = [], WCUR = null;

/* перелік списків і їхні числа — у памʼяті браузера: рейка видна одразу */
const WL_MEM = 'herd:wlists_mem';
function wlFromMemory() {
    try {
        const m = JSON.parse(localStorage.getItem(WL_MEM) || 'null');
        if (!m || !Array.isArray(m.lists)) return false;
        WLISTS = m.lists; WCATS = m.cats || []; RAIL_N = m.n || {};
        return true;
    } catch (e) { return false; }
}
function wlToMemory() {
    try {
        localStorage.setItem(WL_MEM, JSON.stringify({ lists: WLISTS, cats: WCATS, n: RAIL_N }));
    } catch (e) { /* ignore */ }
}

/* Копія з памʼяті — ЛИШЕ для миттєвої рейки. Писати списки (сервер
   ЗАМІНЮЄ їх усі тим, що прийшло) можна тільки після свіжого читання:
   інакше старою копією стерлись би списки, заведені на іншому компʼютері.
   WL_GEN — номер збереження: читання, що вирушило ДО нього, вже застаріле. */
let WL_FRESH = false, WL_GEN = 0, WL_LOADING = null;
/* що сторінка прочитала з сервера: відбитки (WL_REVS) і самі списки (WL_BASE, id → JSON) — при збереженні
   сервер бере від сторінки лише змінене тут, решту лишає як є (стара вкладка не стирає чужих змін) */
let WL_REVS = null, WL_BASE = {};
// лише те, що сервер зберігає, — службове, дописане сторінкою, змінами не рахується
const WL_KEYS = ['id', 'name', 'formula', 'category', 'note', 'color', 'edge', 'bg'];
const listSig = (x) => JSON.stringify(WL_KEYS.map((k) => (x[k] === undefined || x[k] === null ? '' : x[k])));
const listSnap = (arr) => Object.fromEntries((arr || []).map((x) => [String(x.id), listSig(x)]));
function listDiff(arr, base) {                     // що змінила сама сторінка
    const ids = new Set((arr || []).map((x) => String(x.id)));
    return { dirty: (arr || []).filter((x) => base[String(x.id)] !== listSig(x)).map((x) => String(x.id)),
        deleted: Object.keys(base).filter((i) => !ids.has(i)) };
}
function wlLoad() {                                // одне читання на всіх, хто чекає
    if (!WL_LOADING) WL_LOADING = wlFetch().finally(() => { WL_LOADING = null; });
    return WL_LOADING;
}
function wlEnsure() {
    return WL_FRESH ? Promise.resolve(true) : wlLoad().then(() => WL_FRESH);
}
const awNorm = (f) => awWithEq(String(f || '')).replace(/\s+/g, ' ').trim();
async function wlFetch() {
    const gen = WL_GEN;
    const r = await apiGet('/api/herd/work-lists').catch(() => null);
    if (!r || !r.ok) return;                       // не прочитали — лишаємо, що було
    if (gen !== WL_GEN) return;                    // поки йшло — зберегли новіше
    WLISTS = r.lists || [];
    WCATS = r.categories || [];
    WL_REVS = r.revs || null;
    WL_BASE = listSnap(WLISTS);
    WL_FRESH = true;
    wlToMemory();
    // список відкрили з копії в памʼяті, а на іншому компʼютері його вже
    // змінили: Enter переписав би свіже старим — відкриваємо свіже або
    // відвʼязуємось
    if (WCUR) {
        const F = WLISTS.find((x) => String(x.id) === String(WCUR.id));
        if (F && awNorm(F.formula) === awNorm(WCUR.formula)) WCUR = F;
        else if (F && TAB === 'work' && awNorm($('awInput').value) === awNorm(WCUR.formula)) wlOpen(F);
        else {
            wlSetCur(null);
            toast(F ? `Список «${F.name}» змінили на іншому компʼютері — відкрийте його ще раз`
                : 'Відкритого списку вже немає', 'error');
        }
    }
    wlCatsFill();
    wlRender();
}

async function wlSave() {
    if (!WL_FRESH) {                               // лише копія з памʼяті — не пишемо
        wlEnsure().then(() => { railRender(); wlRender(); });
        toast('Списки ще звіряються з сервером — повторіть за мить', 'error');
        return false;
    }
    const body = WL_REVS ? Object.assign({ lists: WLISTS, revs: WL_REVS }, listDiff(WLISTS, WL_BASE)) : { lists: WLISTS };
    let r = await apiSend('/api/herd/work-lists', 'POST', body).catch(() => null);
    if (r && r.conflict) {                         // той самий список змінили деінде — питаємо, а не затираємо
        const ok = await confirmAction(`${r.error}. Записати ваш варіант поверх?`, { ok: 'Записати поверх' });
        if (!ok) {
            WL_GEN++;
            await wlFetch();                       // показуємо свіже — ваше незбережене не пишемо
            railRender(); railCounts();
            toast('Показано свіжі списки — повторіть свою зміну', 'error');
            return false;
        }
        r = await apiSend('/api/herd/work-lists', 'POST', Object.assign({}, body, { force: 1 })).catch(() => null);
    }
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося зберегти', 'error'); return false; }
    WLISTS = r.lists || [];
    WL_REVS = r.revs || WL_REVS;
    WL_BASE = listSnap(WLISTS);
    WL_GEN++;
    wlToMemory();
    wlRender();
    // формулу списку щойно змінили (💾, ⚙, нова, копія) — число в рейці
    // рахувалось ЛИШЕ при вході на вкладку, тож лишалось від старої формули
    // (Роман 2026-09-24: «вирахував 12, а в списку старий напис 72»)
    railCounts();
    return true;
}

/* ПОДВІЙНИЙ КЛІК ПО НАЗВІ СПИСКУ В БІЧНІЙ ПАНЕЛІ — перейменувати просто на місці (Роман
   2026-09-30). Тим самим шляхом, що й скрізь (reportRename): разом із посиланнями на список.
   Enter чи вихід із поля — зберегти, Esc — як було. */
/* ⚠️ Не рідний dblclick: перший клік відкриває список і перемальовує рейку, тож другий
   потрапляє вже в НОВИЙ рядок — браузер таких двох кліків за подвійний не рахує. Тому
   рахуємо самі: два кліки по назві того самого списку за 450 мс (RAIL_CLK у кліку рейки). */
let RAIL_CLK = { id: '', t: 0 };
function railRename(id) {
    const btn = document.querySelector(`#awRailList .awr-i[data-wl="${CSS.escape(String(id))}"]`);
    const span = btn && btn.querySelector(':scope > span');
    const L = WLISTS.find((x) => String(x.id) === String(id));
    if (!span || !L || btn.querySelector('.awr-rn')) return;
    const inp = document.createElement('input');
    inp.className = 'awr-rn';
    inp.value = L.name;
    inp.maxLength = 80;
    span.replaceWith(inp);
    inp.focus();
    inp.select();
    let fired = false;
    const done = async (save) => {
        if (fired) return;
        fired = true;
        const v = inp.value.trim().replace(/\s+/g, ' ');
        inp.remove();                               // поле геть — рейка знову малюється
        if (save && v && v !== L.name) {
            if (await wlEnsure()) {
                const cur = WLISTS.find((x) => String(x.id) === String(L.id));
                if (cur && await reportRename('list', cur, v)) toast(`Список перейменовано: «${v}»`, 'success');
            } else toast('Списки не прочитались з сервера — спробуйте ще раз', 'error');
        }
        railRender();
        wlRender();
    };
    inp.addEventListener('keydown', (ev) => {
        ev.stopPropagation();                       // пробіл і Enter — полю, а не кнопці-рядку
        if (ev.key === 'Enter') { ev.preventDefault(); done(true); }
        if (ev.key === 'Escape') { ev.preventDefault(); done(false); }
    });
    inp.addEventListener('keyup', (ev) => ev.preventDefault());   // пробіл у полі не «натискає» рядок
    inp.addEventListener('blur', () => done(true));
}

/* перелік категорій у випадайках (добір у «Списках», збереження нового) — щоразу наново:
   категорії міняють у вікні «Категорії» */
function wlCatsFill() {
    const opt = (c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`;
    const sel = $('wlCat');
    if (sel) {
        const v = sel.value;
        sel.innerHTML = '<option value="">Усі категорії</option>' + WCATS.map(opt).join('');
        sel.value = WCATS.includes(v) ? v : '';
    }
    const save = $('awSaveCat');
    if (save) {
        const v = save.value;
        save.innerHTML = '<option value="">Без категорії</option>' + WCATS.map(opt).join('');
        save.value = WCATS.includes(v) ? v : '';
    }
}

/* ═══ ВІКНО «КАТЕГОРІЇ» (Роман 2026-09-30: «управління категоріями і розташуванням цих
   категорій… створити «Профілактика молодняка»»). Кожна зміна одразу на сервері:
   назва — Enter/вихід із поля, ⠿ — перетягнути (порядок), ✕ — з перепитом, «+» — нова. ═══ */
let WC_FOR = null, WC_BUSY = false;
function wcBox() {
    let b = $('wcPop');
    if (!b) {
        b = document.createElement('div');
        b.id = 'wcPop';
        b.className = 'ov-pop wc-pop';
        b.hidden = true;
        document.body.appendChild(b);
    }
    return b;
}
function wcRender() {
    const b = wcBox();
    const n = (c) => WLISTS.filter((L) => (L.category || '') === c).length;
    b.innerHTML = '<div class="ov-pop-h"><b>Категорії списків</b>'
        + '<button type="button" class="ov-pop-x" data-wc-x title="Закрити">✕</button></div>'
        + '<div class="wc-list">' + WCATS.map((c, i) => `<div class="wc-row" data-i="${i}" draggable="true">`
            + '<span class="wc-grip" title="Потягніть, щоб змінити порядок">⠿</span>'
            + `<input value="${escapeHtml(c)}" data-old="${escapeHtml(c)}" maxlength="40">`
            + `<span class="wc-n" title="Списків у категорії">${n(c) || ''}</span>`
            + `<button type="button" class="wc-del" data-wc-del="${i}" title="Видалити категорію">✕</button></div>`).join('')
        + '</div><div class="wc-add"><input id="wcNew" placeholder="Нова категорія" maxlength="40">'
        + '<button type="button" class="btn btn-primary" data-wc-add>+ Додати</button></div>';
}
function wcPlace() {
    const b = wcBox();
    if (!WC_FOR || b.hidden) return;
    const r = WC_FOR.getBoundingClientRect();
    const w = b.offsetWidth, h = b.offsetHeight;
    let left = window.scrollX + r.left, top = window.scrollY + r.bottom + 6;
    left = Math.max(window.scrollX + 8, Math.min(left, window.scrollX + document.documentElement.clientWidth - w - 8));
    if (r.bottom + 6 + h > window.innerHeight) top = Math.max(window.scrollY + 8, window.scrollY + r.top - h - 6);
    b.style.left = `${Math.round(left)}px`;
    b.style.top = `${Math.round(top)}px`;
}
async function wcOpen(anchor) {
    const b = wcBox();
    if (!b.hidden && WC_FOR === anchor) { wcClose(); return; }
    if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    WC_FOR = anchor;
    wcRender();
    b.hidden = false;
    wcPlace();
}
function wcClose() { const b = $('wcPop'); if (b) b.hidden = true; WC_FOR = null; }
async function wcSave(cats, renames) {
    if (WC_BUSY) return false;
    WC_BUSY = true;
    try {
        const r = await apiSend('/api/herd/list-cats', 'POST', { cats, renames: renames || {} }).catch(() => null);
        if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося зберегти', 'error'); wcRender(); return false; }
        WCATS = r.categories || [];
        WLISTS = r.lists || WLISTS;
        WL_REVS = r.revs || WL_REVS;
        WL_BASE = listSnap(WLISTS);
        WL_GEN++;
        if (WCUR) WCUR = WLISTS.find((x) => String(x.id) === String(WCUR.id)) || null;
        wlToMemory();
        wlCatsFill();
        wlRender();
        railRender();
        if (!wcBox().hidden) { wcRender(); wcPlace(); }
        return true;
    } finally { WC_BUSY = false; }
}
function wcRename(inp) {
    const old = inp.dataset.old, nw = inp.value.trim().replace(/\s+/g, ' ');
    if (!nw) { inp.value = old; return; }
    if (nw === old) return;
    if (WCATS.some((c) => c !== old && c.toLowerCase() === nw.toLowerCase())) {
        toast(`Категорія «${nw}» уже є`, 'error'); inp.value = old; return;
    }
    wcSave(WCATS.map((c) => (c === old ? nw : c)), { [old]: nw });
}
async function wcAdd() {
    const inp = $('wcNew');
    const nw = (inp.value || '').trim().replace(/\s+/g, ' ');
    if (!nw) { inp.focus(); return; }
    if (WCATS.some((c) => c.toLowerCase() === nw.toLowerCase())) { toast(`Категорія «${nw}» уже є`, 'error'); return; }
    if (await wcSave([...WCATS, nw])) { const i2 = $('wcNew'); if (i2) i2.focus(); toast(`Категорію «${nw}» додано`, 'success'); }
}
async function wcDel(i) {
    const c = WCATS[i];
    if (c === undefined) return;
    const n = WLISTS.filter((L) => (L.category || '') === c).length;
    if (!await confirmAction(`Видалити категорію «${c}»?`
        + (n ? ` Її ${n} ${n === 1 ? 'список перейде' : 'списки перейдуть'} у «Без категорії».` : ''),
    { ok: 'Видалити', okClass: 'btn-danger' })) return;
    if (await wcSave(WCATS.filter((x, k) => k !== i))) toast(`Категорію «${c}» видалено`, 'success');
}
let WC_DRAG = null;
document.addEventListener('click', (e) => {
    const b = $('wcPop');
    if (!b || b.hidden) return;
    if (e.target.closest('[data-wc-x]')) { wcClose(); return; }
    if (e.target.closest('[data-wc-add]')) { wcAdd(); return; }
    const d = e.target.closest('[data-wc-del]');
    if (d) { wcDel(+d.dataset.wcDel); return; }
    // клік повз вікно (і не по кнопці, що його відкриває) — закрити
    if (!e.target.closest('#wcPop') && !e.target.closest('#wlCatsBtn, #awRailCats')
        && !e.target.closest('.modal')) wcClose();
});
document.addEventListener('keydown', (e) => {
    const b = $('wcPop');
    if (!b || b.hidden) return;
    if (e.key === 'Escape' && !document.querySelector('.modal:not([hidden])')) { wcClose(); return; }
    if (e.key !== 'Enter') return;
    if (e.target.id === 'wcNew') { e.preventDefault(); wcAdd(); return; }
    if (e.target.closest('#wcPop .wc-row input')) { e.preventDefault(); e.target.blur(); }
});
document.addEventListener('change', (e) => {
    const inp = e.target.closest && e.target.closest('#wcPop .wc-row input');
    if (inp) wcRename(inp);
});
document.addEventListener('dragstart', (e) => {
    const r = e.target.closest && e.target.closest('#wcPop .wc-row');
    if (!r) return;
    if (e.target.closest('input')) { e.preventDefault(); return; }
    WC_DRAG = +r.dataset.i;
    r.classList.add('is-drag');
    try { e.dataTransfer.setData('text/plain', String(WC_DRAG)); e.dataTransfer.effectAllowed = 'move'; } catch (er) { /* ignore */ }
});
document.addEventListener('dragover', (e) => {
    if (WC_DRAG === null) return;
    const r = e.target.closest && e.target.closest('#wcPop .wc-row');
    if (!r) return;
    e.preventDefault();
    document.querySelectorAll('#wcPop .wc-row.is-over').forEach((x) => x.classList.remove('is-over'));
    r.classList.add('is-over');
});
document.addEventListener('drop', (e) => {
    if (WC_DRAG === null) return;
    const r = e.target.closest && e.target.closest('#wcPop .wc-row');
    if (!r) return;
    e.preventDefault();
    const to = +r.dataset.i, from = WC_DRAG;
    WC_DRAG = null;
    if (to === from) { wcRender(); return; }
    const next = [...WCATS];
    const [m] = next.splice(from, 1);
    next.splice(to, 0, m);                       // стає НА місце того, на кого кинули
    wcSave(next);
});
document.addEventListener('dragend', () => {
    if (WC_DRAG === null && !document.querySelector('#wcPop .is-drag')) return;
    WC_DRAG = null;
    document.querySelectorAll('#wcPop .is-drag, #wcPop .is-over').forEach((x) => x.classList.remove('is-drag', 'is-over'));
});
window.addEventListener('resize', wcPlace);
window.addEventListener('scroll', wcPlace, true);

/* ширина зони назви у вкладці «Списки» — тягнуть за правий край клітинки назви
   (Роман 2026-09-30: «щоб можна було розширювати зону, де назва списку і тіло формули») */
const WL_NW_KEY = 'herd:wl_nw';
function wlNwApply(px) {
    const t = $('wlTbl');
    if (!t) return;
    if (px > 0) { t.style.setProperty('--wl-nw', px + 'px'); t.classList.add('has-nw'); }
    else { t.style.removeProperty('--wl-nw'); t.classList.remove('has-nw'); }
}
document.addEventListener('mousedown', (e) => {
    const h = e.target.closest('#wlTbl .wl-rz');
    if (!h) return;
    e.preventDefault();
    const t = $('wlTbl'), cell = h.closest('td');
    const x0 = e.clientX, w0 = cell.getBoundingClientRect().width;
    const max = Math.max(160, t.getBoundingClientRect().width * 0.7);
    t.classList.add('is-rz');
    let w = w0;
    const mv = (m) => { w = Math.round(Math.min(max, Math.max(110, w0 + m.clientX - x0))); wlNwApply(w); };
    const up = () => {
        document.removeEventListener('mousemove', mv);
        document.removeEventListener('mouseup', up);
        t.classList.remove('is-rz');
        try { localStorage.setItem(WL_NW_KEY, String(w)); } catch (er) { /* ignore */ }
    };
    document.addEventListener('mousemove', mv);
    document.addEventListener('mouseup', up);
});
document.addEventListener('dblclick', (e) => {
    if (!e.target.closest('#wlTbl .wl-rz')) return;
    wlNwApply(0);
    try { localStorage.removeItem(WL_NW_KEY); } catch (er) { /* ignore */ }
});
try { wlNwApply(+localStorage.getItem(WL_NW_KEY) || 0); } catch (e) { /* ignore */ }

function wlRender() {
    const box = $('wlBody');
    if (!box) return;
    const q = ($('wlSearch') ? $('wlSearch').value : '').trim().toLowerCase();
    const cat = $('wlCat') ? $('wlCat').value : '';
    const rows = WLISTS.filter((L) => (!cat || L.category === cat)
        && (!q || `${L.name} ${L.note || ''} ${L.formula}`.toLowerCase().includes(q)));
    const tbl = $('wlTbl');
    if (!rows.length) {
        if (tbl) tbl.classList.add('is-empty');
        box.innerHTML = `<tr><td colspan="3" class="wl-empty">${WLISTS.length
            ? 'За цим добором нічого немає.'
            : 'Збережених списків ще немає. Наберіть формулу у «Роботі зі стадом» і збережіть її значком 💾.'}</td></tr>`;
        return;
    }
    if (tbl) tbl.classList.remove('is-empty');
    // теми йдуть у порядку Конструктора, «Без категорії» — останньою
    const secs = [];
    (WCATS.length ? WCATS : [...new Set(rows.map((L) => L.category))].filter(Boolean))
        .forEach((c) => {
            const got = rows.filter((L) => L.category === c);
            if (got.length) secs.push([c, got]);
        });
    // категорія, якої вже немає в переліку, — теж окремою групою, а не зникає
    [...new Set(rows.map((L) => L.category).filter((c) => c && !WCATS.includes(c)))]
        .forEach((c) => secs.push([c, rows.filter((L) => L.category === c)]));
    const rest = rows.filter((L) => !L.category);
    if (rest.length) secs.push(['Без категорії', rest]);

    const rowHtml = (L) => `<tr class="wl-row" data-id="${escapeHtml(L.id)}">
        <td class="wl-cname"><span class="wl-name" data-act="open" title="Відкрити">${escapeHtml(L.name)}</span>
            ${L.note ? `<div class="wl-note">${escapeHtml(L.note)}</div>` : ''}
            <span class="wl-rz" title="Потягніть, щоб змінити ширину · двічі клацніть — як було"></span></td>
        <td>
            <code class="wl-f">${awHlHtml(awNoEq(L.formula || ''))}</code>
            <button type="button" class="wl-fcopy" data-act="fcopy"
                    title="Скопіювати формулу" aria-label="Скопіювати формулу"><svg
                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect
                    x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0
                    1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
        </td>
        <td class="wl-acts">
            <button type="button" data-act="copy"
                    title="Зробити копію — щоб правити, не чіпаючи цей список">⧉</button>
            <button type="button" data-act="cal" title="Копію — у Календар">📅</button>
            <button type="button" data-act="rename" title="Перейменувати">✎</button>
            <button type="button" data-act="del" title="Видалити">✕</button>
        </td>
    </tr>`;
    box.innerHTML = secs.map(([c, got]) => `<tr class="wl-sec"><td colspan="3">
        ${escapeHtml(c)}<span class="wl-n">${got.length}</span></td></tr>`
        + got.map(rowHtml).join('')).join('');
}

/* який список зараз відкрито у «Роботі зі стадом» */
function wlSetCur(L) {
    // відкрили інший список — коробка ⚙ більше не про нього
    if (CFG_FOR && (!L || String(L.id) !== CFG_FOR.id)) awCfgClose();
    WCUR = L || null;
    if (WCUR) OV_CUR = null;
    awCurShow();
    railRender();                       // у рейці підсвічується відкритий список
}

/* ---------- рейка збережених списків збоку від таблиці ----------
   Кількість голів рахується ТУТ, у браузері, тією самою мовою добору, що й
   сама формула — оператор бачить, куди йти, ще до кліку. Якщо для якогось
   списку бракує значень параметра, один раз дочитуємо їх усі разом. */
let RAIL_N = {}, RAIL_ITEMS = null, RAIL_KEYS = null;

/* рейку можна згорнути — тоді таблиці дістається вся ширина
   (Роман 2026-09-22: «щоб цю частину можна скривати, розкривати») */
const RAIL_CLOSED_KEY = 'herd:rail_closed';
let RAIL_CLOSED = false;
try { RAIL_CLOSED = localStorage.getItem(RAIL_CLOSED_KEY) === '1'; } catch (e) { /* ignore */ }
/* Панелі «Огляду» — у тій самій рейці, окремим блоком (Роман 2026-09-26:
   «на сторінці роботи зі стадом треба також додати перелік панелей, так
   само як і списки; натискати на панель і редагувати її»). Доти панель
   правилась лише з «Огляду»: клік по плитці приводив сюди, але назад по
   наступну доводилось іти вкладкою. */
const PAN_CLOSED_KEY = 'herd:pan_closed';
let PAN_CLOSED = false;
try { PAN_CLOSED = localStorage.getItem(PAN_CLOSED_KEY) === '1'; } catch (e) { /* ignore */ }

let RAIL_Q = '';

/* каркас рейки будуємо ОДИН раз: інакше перемальовка на кожну літеру
   забирала б фокус із поля пошуку */
function railShell(box) {
    if (box.dataset.shell === '1') return;
    box.dataset.shell = '1';
    // ДВА РІЗНІ МІСЦЯ, а не один довгий перелік (Роман 2026-09-26: «давай
    // розʼєднаємо, що панелі — це панелі, а списки — це списки»): кожен блок
    // у своїй коробці, і виглядають вони по-різному — список рядком із
    // номером, панель плиткою з числом угорі, як на «Огляді»
    box.innerHTML = '<input type="search" id="awRailQ" class="awr-q" autocomplete="off"'
        + ' placeholder="пошук списку чи панелі">'
        + '<div class="awr-blk" id="awListsBlk">'
        + '<div class="awr-headrow">'
        + '<button type="button" class="awr-head" id="awRailHead"></button>'
        + '<button type="button" class="awr-add awr-cats" id="awRailCats"'
        + ' title="Категорії списків: додати, перейменувати, видалити, змінити порядок">⚙</button>'
        + '<button type="button" class="awr-add" id="awRailAdd"'
        + ' title="Новий порожній список — формулу наберіть у рядку, Enter збереже">+</button>'
        + '</div>'
        + '<div id="awRailList"></div>'
        + '</div>'
        + '<div class="awr-blk awr-blk-pan" id="awPanBlk">'
        + '<div class="awr-headrow">'
        + '<button type="button" class="awr-head" id="awPanHead"></button>'
        + '<button type="button" class="awr-add" id="awPanAdd"'
        + ' title="Нова порожня панель — формулу наберіть у рядку, Enter збереже">+</button>'
        + '</div>'
        + '<div id="awPanList"></div>';
    $('awRailQ').addEventListener('input', () => {
        RAIL_Q = $('awRailQ').value.trim().toLowerCase();
        // перемальовуємо ЛИШЕ переліки (не всю рейку) — інакше поле пошуку
        // губило б фокус на кожній літері
        railList();
        if (!PAN_CLOSED) panList();
    });
}

function railRender() {
    const box = $('awRail');
    if (!box) return;
    box.hidden = TAB !== 'work';
    if (box.hidden) return;
    railShell(box);
    // ⚠️ «Згорнута» — це коли згорнуті ОБИДВА блоки. Клас лишився з 2.39.25,
    // коли в рейці були самі списки, і після 2.40.29 згортання «Списків»
    // робило `flex:0 0 auto` ВСІЙ рейці — а відкритий блок «Панелі» розпирав
    // її за вмістом на всю сторінку (Роман 2026-09-26, скрін).
    const shut = RAIL_CLOSED && PAN_CLOSED;
    box.classList.toggle('is-closed', shut);
    const head = $('awRailHead');
    head.title = RAIL_CLOSED ? 'Показати списки' : 'Згорнути списки';
    // підпис каже, ЩО це: список дає перелік тварин, панель — одне число
    head.innerHTML = `<span class="awr-chev">${RAIL_CLOSED ? '▸' : '▾'}</span>Списки`
        + '<i class="awr-what">перелік тварин</i>';
    // пошук шукає і в списках, і в панелях — ховаємо, лише коли згорнуті обидва
    // блоки або шукати нічого
    $('awRailQ').hidden = shut || (WLISTS.length + OV.filter((t) => !ovIsComposite(t)).length) < 2;
    $('awRailList').hidden = RAIL_CLOSED;
    if (!RAIL_CLOSED) railList();
    const ph = $('awPanHead');
    if (ph) {
        ph.title = PAN_CLOSED ? 'Показати панелі' : 'Згорнути панелі';
        ph.innerHTML = `<span class="awr-chev">${PAN_CLOSED ? '▸' : '▾'}</span>Панелі`
            + '<i class="awr-what">показник числом</i>';
        $('awPanList').hidden = PAN_CLOSED;
        if (!PAN_CLOSED) panList();
    }
}

/* Перелік панелей «Огляду» — так само, як списки: клік відкриває панель у
   рядку формули (звідти її правлять і зберігають Enter-ом), число праворуч —
   те саме, що на плитці «Огляду». */
/* око — тонким контуром, як решта значків застосунку; перекреслене око
   означає «на «Огляді» не показується» (Роман 2026-09-26) */
const EYE_SVG = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none"'
    + ' stroke="currentColor" stroke-width="1.8" stroke-linecap="round">'
    + '<path d="M1.8 12S5.4 5.8 12 5.8 22.2 12 22.2 12 18.6 18.2 12 18.2 1.8 12 1.8 12Z"/>'
    + '<circle cx="12" cy="12" r="3"/></svg>';
const EYE_OFF_SVG = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none"'
    + ' stroke="currentColor" stroke-width="1.8" stroke-linecap="round">'
    + '<path d="M1.8 12S5.4 5.8 12 5.8 22.2 12 22.2 12 18.6 18.2 12 18.2 1.8 12 1.8 12Z"/>'
    + '<circle cx="12" cy="12" r="3"/><path d="M3.5 3.5 20.5 20.5"/></svg>';

function panList(box, pick) {
    const wrap = box || $('awPanList');
    if (!wrap) return;
    // У ПЕРЕЛІКУ — ЛИШЕ ПОКАЗНИКИ (Роман 2026-09-27: «із бічної панелі прибрати
    // комбіновані, залишити тільки показники створені»): складені живуть
    // плитками на «Огляді», а їхні показники — посилання на своїх тварин
    // порожня панель («+» щойно завела) теж тут — у неї ще набирають формулу
    const IND = OV.filter((t) => !ovIsComposite(t) || !String(t.formula || '').trim());
    if (!IND.length) {
        wrap.innerHTML = '<p class="awr-cat">Показників ще немає — наберіть формулу в «Роботі зі стадом» і збережіть панеллю («+»)</p>';
        return;
    }
    const hit = (t) => !RAIL_Q
        || `${t.name} ${t.section || ''}`.toLowerCase().includes(RAIL_Q);
    const secs = [];
    IND.forEach((t) => {
        const k = (t.section || '').trim() || 'Без розділу';     // як і на «Огляді»
        let g = secs.find((x) => x.k === k);
        if (!g) { g = { k, list: [] }; secs.push(g); }
        g.list.push(t);
    });
    const hex = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : '');
    const html = secs.map((g) => {
        const seen = g.list.filter(hit);
        if (!seen.length) return '';
        const tiles = seen.map((t) => {
            let n = ovCount(t);
            if (n === null && OV_LAST[t.id] !== undefined) n = OV_LAST[t.id];
            const bad = typeof n === 'string';
            const pt = ovParts(n, t);
            // порожня панель — «порожня», а не вічне «…», ніби число ще читається
            const blank = !String(t.formula || '').trim();
            const txt = blank ? 'порожня' : (bad ? '—' : (n === null ? '' : pt.main));
            const st = [hex(t.color) && `--awr-ink:${hex(t.color)}`,
                hex(t.color) && '--awr-dim:.75',
                hex(t.edge) && `--awr-edge:${hex(t.edge)}`,
                hex(ovBgOf(t.bg || '')) && `--awr-bg:${hex(ovBgOf(t.bg || ''))}`]
                .filter(Boolean).join(';');
            // у переліку «Огляду» під час наповнення підсвічуємо ті, що вже в
            // панелі (без урахування регістру — як і рахується посилання)
            const on = pick ? (pick.names || []).includes(refKey(t.name))
                : (OV_CUR && String(OV_CUR.id) === String(t.id));
            // що в панель НЕ покласти — гасимо одразу, а не ламаємо панель
            // після кліку (аналіз 2026-09-26, Н7/Н8)
            const na = pick ? ovmWhyNot(t, pick.self) : '';
            const hid = t.hidden ? ' is-hid' : '';
            // панель — ПЛИТКА: число вгорі, назва під ним. Саме так вона
            // виглядає на «Огляді», і саме цим вона не схожа на рядок списку
            return `<button type="button" class="awr-t${on ? ' on' : ''}${hid}${na ? ' is-na' : ''}"`
                + (st ? ` style="${st}"` : '')
                + ` data-ov="${escapeHtml(t.id)}"`
                + ` title="${escapeHtml((na || (bad ? String(n) : t.name))
                    + (t.hidden ? ' · схована з «Огляду»' : ''))}">`
                // ✎ — налаштування просто біля панелі (спливаюче вікно)
                + `<i class="awr-ed" data-ed="${escapeHtml(t.id)}" title="Налаштувати: назва, розділ, кольори, розмір">✎</i>`
                // ✕ — видалити панель (лише в бічній панелі «Роботи зі стадом»; на «Огляді» ✕ на самій плитці)
                + (box ? '' : `<i class="awr-x" data-ovdel="${escapeHtml(t.id)}" role="button" title="Видалити панель">✕</i>`)
                + `<b${blank ? ' class="awr-blank"' : ''}>${escapeHtml(txt || '…')}</b>`
                + ((!bad && pt.sub) ? `<i class="awr-sub">${escapeHtml(pt.sub)}</i>` : '')
                + '<span>'
                // око при КОЖНОМУ показнику: світиться — стоїть на «Огляді»,
                // перекреслене — не стоїть. Клік перемикає
                + `<i class="awr-eye${t.hidden ? ' is-off' : ''}"`
                + ` data-eye="${escapeHtml(t.id)}"`
                + ` title="${t.hidden ? 'Не показується на «Огляді» — натисніть, щоб показати'
                    : 'Показується на «Огляді» — натисніть, щоб сховати'}">`
                + (t.hidden ? EYE_OFF_SVG : EYE_SVG) + '</i>'
                + `${escapeHtml(t.name)}</span></button>`;
        }).join('');
        return `<p class="awr-cat">${escapeHtml(g.k)}</p><div class="awr-tiles">${tiles}</div>`;
    }).join('');
    wrap.innerHTML = html || '<p class="awr-cat">Нічого не знайшли</p>';
}

/* означення панелей потрібні рейці й на «Роботі зі стадом» — читаємо їх
   один раз (спершу з памʼяті браузера, щоб перелік був видно одразу) */
let OV_FETCHING = null, OV_FRESH = false;
/* памʼять браузера читаємо СИНХРОННО і на самому старті: інакше перше
   читання стада пішло б без ключів панелей, і рейка попросила б стадо
   ВДРУГЕ, щоб порахувати їхні числа */
function ovFromMemory() {
    if (OV.length) return true;
    try {
        const c = JSON.parse(localStorage.getItem(OV_CACHE) || 'null');
        if (c && Array.isArray(c.tiles) && c.tiles.length) {
            OV = c.tiles;
            OV_LAST = c.counts || {};
            return true;
        }
    } catch (e) { /* ignore */ }
    return false;
}
async function ovEnsure() {
    // свіжий перелік — один раз за захід (як і списки): панель могли завести
    // з іншого компʼютера, але питати сервер на кожен клік по вкладці зайве
    if (OV_FRESH || OV_FETCHING) return OV_FETCHING;
    if (ovFromMemory()) railRender();
    OV_FETCHING = apiGet('/api/herd/overview-tiles').catch(() => null);
    const r = await OV_FETCHING;
    OV_FETCHING = null;
    if (r && r.ok !== false && Array.isArray(r.tiles)) { OV = r.tiles; OV_FRESH = true; railRender(); }
    return null;
}

function railList() {
    const wrap = $('awRailList');
    if (!wrap) return;
    // назву саме правлять (подвійний клік) — перемальовка вбила б поле
    if (wrap.querySelector('.awr-rn')) return;
    if (!WLISTS.length) {
        wrap.innerHTML = '<p class="awr-cat">Збережених списків ще немає</p>';
        return;
    }
    // категорії — у ПОРЯДКУ З ВІКНА «Категорії», далі невідомі, «Без категорії» — останньою
    const by = new Map();
    WCATS.forEach((c) => by.set(c, []));
    WLISTS.forEach((L) => {
        const c = (L.category || '').trim() || 'Без категорії';
        if (!by.has(c)) by.set(c, []);
        by.get(c).push(L);
    });
    if (by.has('Без категорії')) { const x = by.get('Без категорії'); by.delete('Без категорії'); by.set('Без категорії', x); }
    [...by.keys()].forEach((c) => { if (!by.get(c).length) by.delete(c); });
    // нумерація СВОЯ в кожній категорії (Роман 2026-09-22): «Інше 1, 2»,
    // «Відтворення 1» — щоб список можна було назвати номером уголос.
    // Рахуємо ДО пошуку, щоб номер не стрибав, коли частину відсіяно.
    const no = new Map();
    by.forEach((ls) => ls.forEach((L, i) => no.set(String(L.id), i + 1)));
    const hit = (L) => !RAIL_Q
        || `${L.name} ${L.category || ''} ${L.note || ''}`.toLowerCase().includes(RAIL_Q);
    const html = [...by.entries()].map(([c, ls]) => {
        const seen = ls.filter(hit);
        if (!seen.length) return '';
        return `<p class="awr-cat">${escapeHtml(c)}</p>` + seen.map((L) => {
            let n = RAIL_N[L.id];
            if (n === undefined && window.herdPanels.evSides(L.formula).length) {
                // список із подіями — те саме число, що дала б плитка «Огляду» з цією формулою
                const c = ovCountOn(L.formula, OV_ITEMS);
                const b = (ovBlocks(c, {}) || [])[0];
                n = !b ? '' : (b.err ? '⚠' : b.v);
            }
            // свій колір списку (шестерня «Вигляд»): лише чистий hex у style=
            const hex = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : '');
            // кладемо ЗМІННІ, а не готові кольори: інакше темна тема не мала б
            // чим їх перебити (у панелей «Огляду» так і зроблено)
            const st = [hex(L.color) && `--awr-ink:${hex(L.color)}`,
                hex(L.color) && '--awr-dim:.75',   // номер і кількість — трохи тихіше
                hex(L.edge) && `--awr-edge:${hex(L.edge)}`,
                hex(ovBgOf(L.bg || '')) && `--awr-bg:${hex(ovBgOf(L.bg || ''))}`]
                .filter(Boolean).join(';');
            return `<button type="button" class="awr-i${WCUR && String(WCUR.id) === String(L.id) ? ' on' : ''}"`
                + (st ? ` style="${st}"` : '')
                + ` data-wl="${escapeHtml(L.id)}" title="${escapeHtml(L.note || L.name)}">`
                + `<i class="awr-no">${no.get(String(L.id))}</i>`
                + `<span>${escapeHtml(L.name)}</span>`
                + `<b>${n === undefined ? '' : n}</b>`
                + `<i class="awr-x" data-wldel="${escapeHtml(L.id)}" role="button" title="Видалити список">✕</i></button>`;
        }).join('');
    }).join('');
    wrap.innerHTML = html || '<p class="awr-cat">Нічого не знайшли</p>';
}

/* які параметри потрібні числам рейки — ключі з формул усіх списків */
function railQs() {
    if (!WLISTS.length || !PARAMS.length) return [];
    return WLISTS.map((L) => {
        if (!awNoEq(L.formula || '').trim()) return null;   // новий порожній — без числа, а не «усе стадо»
        const r = refExpand(L.formula);        // список теж може посилатись на звіт
        if (r.error) return null;
        const q = window.herdQuery.parse(r.text, PARAMS);
        return (q && !q.error) ? { id: L.id, q } : null;
    }).filter(Boolean);
}
/* що потрібно ЧИСЛАМ ПАНЕЛЕЙ — ключі з їхніх формул (у частці «A / B» обидві) */
function panNeed() {
    if (!OV.length || !PARAMS.length) return [];
    return [...new Set(OV.flatMap((t) => fxAllParts(t.formula).flatMap((part) => {
        const fx = fxSides(part);
        return fx.error ? [] : fx.sides.flatMap((f) => {
            const q = window.herdQuery.parse(f, PARAMS);
            return (q && !q.error) ? (q.keys || []) : [];
        });
    })))];
}
// панелі рахуються з ТОГО САМОГО читання стада, що й списки — інакше рейка
// просила б стадо двічі за один вхід на сторінку
const railNeed = () => [...new Set([...railQs().flatMap((x) => x.q.keys || []),
    ...panNeed()])];
let WORK_LOADING = null, WORK_QS = null;          // таблиця саме читає стадо
let LIST_SEQ = 0;                                  // номер найновішого читання

async function railCounts() {
    const qs = railQs();
    const pn = panNeed();
    if (!qs.length && !pn.length) {
        // параметри й списки є, а жодна формула не розбирається — старі числа геть
        if (PARAMS.length && WLISTS.length && Object.keys(RAIL_N).length) {
            RAIL_N = {}; wlToMemory(); railRender();
        }
        return;
    }
    // «ядрові» параметри (лактація, статус) теж просимо ЗНАЧЕННЯМИ: добір
    // читає їх із p, а не з полів картки — без цього лічильник давав 0
    const need = [...new Set([...qs.flatMap((x) => x.q.keys || []), ...pn])];
    const covers = () => WORK_CACHE && need.every((k) => WORK_CACHE.keys.has(k));
    // таблиця вже читає стадо з цими ж параметрами — не дублюємо запит
    if (!covers() && WORK_LOADING) { await WORK_LOADING.catch(() => null); }
    let items = null;
    if (covers()) items = WORK_CACHE.items;
    else if (RAIL_KEYS && need.every((k) => RAIL_KEYS.has(k))) items = RAIL_ITEMS;
    if (!items) {
        const qp = 'lean=1' + (need.length ? '&params=' + encodeURIComponent(need.join(',')) : '');
        const r = await apiGet('/api/herd/animals?' + qp).catch(() => null);
        if (!r || !r.ok) return;                       // не порахували — просто без числа
        RAIL_ITEMS = r.items || [];
        RAIL_KEYS = new Set(need);
        items = RAIL_ITEMS;
    }
    // будуємо наново: список, чия формула більше не розбирається, лишається
    // без числа, а не з числом від старої формули
    const next = {};
    qs.forEach((x) => {
        next[x.id] = qRows(x.q, items).length;         // з додатковими блоками — як у таблиці
    });
    RAIL_N = next;
    // числа панелей — по тому самому читанню, але ЛИШЕ по тих, хто в стаді
    // (плитка «Огляду» рахує саме їх; тут у списку бувають і вибулі)
    if (pn.length) { OV_ITEMS = items.filter((a) => a.status === 'active'); OV_KEYS = new Set(need); }
    wlToMemory();                                  // наступний захід — одразу з числами
    railRender();
}

document.addEventListener('click', (e) => {
    if (e.target.closest('#awRailHead')) {
        RAIL_CLOSED = !RAIL_CLOSED;
        try { localStorage.setItem(RAIL_CLOSED_KEY, RAIL_CLOSED ? '1' : '0'); } catch (er) { /* ignore */ }
        railRender();
        return;
    }
    if (e.target.closest('#awRail .awr-rn')) return;             // клік у полі перейменування
    if (e.target.closest('#awRailAdd')) { awNewList(); return; }   // «+» — новий порожній список
    if (e.target.closest('#awRailCats')) { wcOpen(e.target.closest('#awRailCats')); return; }
    const del = e.target.closest('#awRail [data-wldel]');
    if (del) { awDelList(del.dataset.wldel); return; }
    if (e.target.closest('#awPanAdd')) { awNewPanel(); return; }   // «+» — нова порожня панель
    const pdel = e.target.closest('#awRail [data-ovdel]');
    if (pdel) { awDelPanel(pdel.dataset.ovdel); return; }
    if (e.target.closest('#awPanHead')) {
        PAN_CLOSED = !PAN_CLOSED;
        try { localStorage.setItem(PAN_CLOSED_KEY, PAN_CLOSED ? '1' : '0'); } catch (er) { /* ignore */ }
        railRender();
        return;
    }
    // ✎ на панелі — вікно налаштувань просто біля неї
    const ed = e.target.closest('#awRail [data-ed]');
    if (ed) { ovPopOpen(ed.dataset.ed, ed.closest('.awr-t')); return; }
    const eye = e.target.closest('#awRail [data-eye]');
    if (eye) { ovEyeToggle(eye.dataset.eye); return; }
    const b = e.target.closest('#awRail .awr-i, #awRail .awr-t');
    if (!b) return;
    if (b.dataset.ov) {                          // клік по панелі — відкрити її
        const t = OV.find((x) => String(x.id) === String(b.dataset.ov));
        if (t) ovOpenInWork(t);
        return;
    }
    const L = WLISTS.find((x) => String(x.id) === String(b.dataset.wl));
    // другий клік по НАЗВІ того самого списку за 450 мс — перейменувати (Роман 2026-09-30)
    if (L && e.target.closest('.awr-i > span')) {
        const now = Date.now();
        if (RAIL_CLK.id === String(L.id) && now - RAIL_CLK.t < 450) {
            RAIL_CLK = { id: '', t: 0 };
            railRename(L.id);
            return;
        }
        RAIL_CLK = { id: String(L.id), t: now };
    }
    if (L) wlOpen(L);
});

/* смужка під рядком: що саме зараз відкрито — список чи панель «Огляду» */
/* Що відкрито — переживає оновлення сторінки (Роман 2026-09-24: «при
   оновленні зникає виділення списку; при оновленні повинно все
   зберігатися»). Живе поруч із формулою (localStorage), бо формула в рядку
   теж переживає вихід зі сторінки — привʼязка має жити стільки ж. */
const AW_CUR_KEY = 'herd:aw_cur';
function awCurSave() {
    const v = WCUR ? { k: 'list', id: String(WCUR.id) }
        : (OV_CUR ? { k: 'tile', id: String(OV_CUR.id) } : null);
    try {
        if (v) localStorage.setItem(AW_CUR_KEY, JSON.stringify(v));
        else localStorage.removeItem(AW_CUR_KEY);
    } catch (e) { /* ignore */ }
}
/* Повертаємо привʼязку, ЛИШЕ коли в рядку та сама формула, що збережена
   в списку: інакше Enter переписав би список чужою формулою (напр. зайшли
   за посиланням ?f=… з «Перевірки»). */
async function awCurRestore() {
    if (WCUR || OV_CUR) return;
    let v = null;
    try { v = JSON.parse(localStorage.getItem(AW_CUR_KEY) || 'null'); } catch (e) { v = null; }
    if (!v || !v.id) return;
    const norm = awNorm;
    const txt = norm($('awInput').value);
    // порожній рядок — лише для нового порожнього СПИСКУ (його формулу ще набирають)
    if (!txt && v.k !== 'list' && v.k !== 'tile') return;
    if (v.k === 'list') {
        // звіряємо зі СВІЖОЮ формулою, а не з копією в памʼяті
        if (!await wlEnsure() || WCUR || OV_CUR) return;
        const L = WLISTS.find((x) => String(x.id) === v.id);
        if (L && norm(L.formula) === txt) wlSetCur(L);
    } else if (v.k === 'tile') {
        if (!OV.length) {
            const r = await apiGet('/api/herd/overview-tiles').catch(() => null);
            if (r && r.tiles) OV = r.tiles;
        }
        const t = OV.find((x) => String(x.id) === v.id);
        if (t && norm(t.formula) === txt) { OV_CUR = t; WCUR = null; awCurShow(); }
    }
}

function awCurShow() {
    awCurSave();
    const box = $('awCurName');
    if (!box) return;
    const cur = WCUR || OV_CUR;
    // смужку НЕ ховаємо: її висота зарезервована в .aw-status, інакше поява
    // назви списку зсувала б рейку й таблицю вниз (Роман 2026-09-22)
    box.innerHTML = cur
        ? (WCUR ? 'Список ' : 'Панель ') + `<b>${escapeHtml(cur.name)}</b>`
        : '';
}

function wlOpen(L) {
    $('awInput').value = awNoEq(L.formula);
    try { localStorage.setItem(AW_KEY, L.formula); } catch (e) { /* ignore */ }
    wlSetCur(L);
    setTab('work');
    awPaint();
}

/* ---------- вкладки: Огляд / Робота зі стадом / Списки ---------- */
/* ═══════════ ІСТОРІЯ: що робили на фермі ═══════════
   Роман 2026-09-23: «в історії фіксувати гарно, наглядно послідовні рухи.
   Там буде дата. І що робили — наприклад, внесли 10 тварин браку. І щоб
   можна було навести на панельку і висвітилась інформація. Щоб було
   візуальне ділення на дати: що сьогодні, що вчора, що позавчора».

   📌 Вісь стрічки — КОЛИ ВНЕСЛИ (created_at), а не коли подія сталась:
   питання «що сьогодні робили» саме про роботу. Якщо дата події інша,
   кажемо про це прямо в картці («за 14.09»), щоб не збрехати. */
let HS = [], HS_EDITS = [], HS_DEPTH = 30;

const hsDmy = (d) => (d && d.length >= 10
    ? `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}` : (d || ''));

/* «Сьогодні · Вчора · Позавчора», далі — датою з днем тижня. */
const HS_WDAY = ['неділя', 'понеділок', 'вівторок', 'середа', 'четвер',
    'пʼятниця', 'субота'];
function hsDayLabel(iso) {
    const t = new Date(); t.setHours(0, 0, 0, 0);
    const d = new Date(iso + 'T00:00:00');
    const days = Math.round((t - d) / 86400000);
    if (days === 0) return { name: 'Сьогодні', sub: hsDmy(iso) };
    if (days === 1) return { name: 'Вчора', sub: hsDmy(iso) };
    if (days === 2) return { name: 'Позавчора', sub: hsDmy(iso) };
    return { name: hsDmy(iso), sub: HS_WDAY[d.getDay()] || '' };
}

/* Події → дні → дії. Дія = групове внесення (спільний batch_id) або одна
   подія. Усередині дня новіші зверху. */
function hsGroup(rows) {
    const by = new Map();
    rows.forEach((e) => {
        const cr = String(e.created_at || '');
        const day = cr.slice(0, 10);
        if (!day) return;
        // ключ дії: номер пакета, а для давньої історії — той самий відбиток,
        // що й у журналі подій (подія + дата + автор + секунда внесення).
        // ⚠️ Правка стоїть у стрічці СВОЇМ днем і своїм рядком — тому в неї
        // свій ключ: інакше виправлення злилось би з самою подією, якої в
        // цьому дні немає (вона в тому, коли її внесли).
        const k = e._fix
            ? 'x|' + (e.edit_batch || ('i' + e.id))
            : e.batch_id
            ? 'b|' + e.batch_id
            : [e.event_def_id || e.event_type || '', (e.event_date || '').slice(0, 10),
                e.user_id || '', cr.slice(0, 19)].join('|');
        if (!by.has(day)) by.set(day, new Map());
        const acts = by.get(day);
        if (!acts.has(k)) acts.set(k, []);
        acts.get(k).push(e);
    });
    const out = [];
    [...by.keys()].sort().reverse().forEach((day) => {
        const acts = [...by.get(day).values()]
            .sort((a, b) => String(b[0].created_at || '')
                .localeCompare(String(a[0].created_at || '')));
        out.push({ day, label: hsDayLabel(day), acts });
    });
    return out;
}

/* Зведення однієї дії — те, що видно на картці. */
function hsAct(list) {
    const e = list[0];
    const same = (f) => (list.every((x) => (x[f] || '') === (e[f] || '')) ? (e[f] || '') : '');
    const tags = list.map((x) => x.animal_tag).filter(Boolean)
        .sort((a, b) => String(a).localeCompare(String(b), 'uk', { numeric: true }));
    const cr = String(e.created_at || '');
    return {
        n: list.length,
        many: list.length > 1,
        time: cr.length >= 16 ? cr.slice(11, 16) : '',
        name: e.event_type || '',
        // 'edit' — подію виправили, 'del' — прибрали; порожнє — звичайне внесення
        fix: e._fix || '',
        cat: e.category || 'other',
        user: e.user_name || '',
        // дата САМОЇ події — показуємо, лише якщо вона не збігається з днем внесення
        evDay: (e.event_date || '').slice(0, 10) !== cr.slice(0, 10)
            ? (e.event_date || '').slice(0, 10) : '',
        group: same('group_name'),
        // деталі пакета — СПІЛЬНІ частини, а не лише повний збіг: в осіменінні
        // плідник і спосіб однакові, а «номер ос.» у кожної свій, і вимога
        // збігу цілого рядка лишала б стрічку без найголовнішого
        details: (() => {
            const parts = (x) => String(x.details || '').split(' · ').filter(Boolean);
            return parts(e).filter((q) => list.every((x) => parts(x).includes(q)))
                .join(' · ');
        })(),
        note: same('note'),
        tags,
        // секції з кількостями: «Група-4 — 6 гол. · Мастит — 4 гол.»
        groups: (() => {
            const m = new Map();
            list.forEach((x) => {
                const g = x.group_name || '—';
                m.set(g, (m.get(g) || 0) + 1);
            });
            return [...m.entries()];
        })(),
        day: cr.slice(0, 10),
        ids: list.map((x) => x.id).join(','),
        bid: String(e.batch_id || ''),
    };
}

/* Українська кількість: 1 подія · 2 події · 5 подій. */
function hsPl(n, one, few, many) {
    const a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b === 1) return one;
    if (b >= 2 && b <= 4) return few;
    return many;
}

/* ── малювання стрічки ──
   Рядок = ОДНЕ внесення (групове або одна подія), а не одна тварина: Роман
   просив бачити «внесли 10 тварин браку», а не десять однакових рядків.
   Це СІТКА, не таблиця: колонки задані раз на контейнері, тож розкриті
   пакети й роздільники днів не воюють із colspan (урок 2.39.49). */
let HS_ACTS = [];

function hsDet(a, e) {
    const out = [];
    // дата події ≠ день внесення — кажемо прямо, інакше стрічка бреше
    if (a.evDay) out.push(`<span class="hx-back">за ${hsDmy(a.evDay).slice(0, 5)}</span>`);
    if (a.many) {
        const show = a.tags.slice(0, 5).map((t) => escapeHtml(t)).join(' · ');
        out.push(show + (a.tags.length > 5
            ? ` <i>і ще ${a.tags.length - 5}</i>` : ''));
    } else if (e.animal_name) {
        out.push(escapeHtml(e.animal_name));
    }
    const d = String(a.details || '').trim();
    if (d) out.push((out.length ? '— ' : '') + escapeHtml(d));
    else if (a.note) out.push((out.length ? '— ' : '') + escapeHtml(a.note));
    return out.join(' ');
}

const HS_FIX_W = { edit: 'виправлено', del: 'прибрано' };

function hsRow(a, e, i, alt) {
    const cat = escapeHtml(a.cat || 'other');
    const num = a.many
        ? `<b>${a.n}</b> ${hsPl(a.n, 'голова', 'голови', 'голів')}`
        : escapeHtml(e.animal_tag || '');
    // позначка стоїть ПЕРЕД назвою події — там, де око читає «що сталося»
    const fix = a.fix
        ? `<i class="hx-fix is-${a.fix}">${HS_FIX_W[a.fix] || 'виправлено'}</i>` : '';
    const ttl = (a.fix ? (HS_FIX_W[a.fix] || '') + ' · ' : '') + a.name;
    return `<div class="hx-row ev-c-${cat}${a.many ? ' is-batch' : ''}`
        + `${a.fix ? ' is-fix' : ''}${alt ? ' is-alt' : ''}"`
        + ` data-i="${i}" tabindex="0"${a.many ? ' role="button" aria-expanded="false"' : ''}>`
        + `<span class="hx-time">${escapeHtml(a.time)}</span>`
        + '<span class="hx-cat" aria-hidden="true"></span>'
        + `<span class="hx-ev" title="${escapeHtml(ttl)}">${fix}${escapeHtml(a.name)}</span>`
        + `<span class="hx-n">${num}</span>`
        + `<span class="hx-det">${hsDet(a, e)}</span>`
        + `<span class="hx-who">${escapeHtml(a.user)}</span>`
        + `<span class="hx-more" aria-hidden="true">${a.many ? '▸' : ''}</span>`
        + (IS_ADMIN ? `<button type="button" class="hx-del" data-del="${i}"
             title="${a.fix ? 'Прибрати цю позначку зі стрічки' : 'Прибрати це внесення'}">✕</button>` : '')
        + '</div>';
}

/* Скільки внесень показуємо за день одразу. Звичайний день на фермі — це
   кілька внесень; сотні бувають лише в дні перенесення історії (дзеркало
   ОРСЕКу 21–22.09), і тоді вони затопили б стрічку. Решта — за кнопкою,
   з чесним числом. */
const HS_DAY_MAX = 40;
const HS_SHOWN = new Set();

function hsRender() {
    const box = $('hsFeed');
    if (!box) return;
    box.classList.toggle('can-del', IS_ADMIN);   // колонка під ✕ лише в адміна
    const days = hsGroup(HS.concat(HS_EDITS));
    HS_ACTS = [];
    if (!days.length) {
        box.innerHTML = '<div class="hp-empty">За цей час нічого не вносили</div>';
        if ($('hsCount')) $('hsCount').textContent = '';
        return;
    }
    let nAct = 0, nEv = 0, nFix = 0;
    // правки рахуємо ОКРЕМО: виправлення — не нове внесення, і зливати їх
    // в одне число означало б сказати неправду про обсяг роботи
    const isFix = (l) => !!(l[0] && l[0]._fix);
    const html = days.map((d) => {
        const de = d.acts.filter((l) => !isFix(l)).reduce((s, l) => s + l.length, 0);
        const df = d.acts.filter(isFix).reduce((s, l) => s + l.length, 0);
        const all = HS_SHOWN.has(d.day) || d.acts.length <= HS_DAY_MAX;
        const acts = all ? d.acts : d.acts.slice(0, HS_DAY_MAX);
        const rows = acts.map((list, k) => {
            const a = hsAct(list);
            const i = HS_ACTS.push({ a, list }) - 1;
            return hsRow(a, list[0], i, k % 2 === 1);
        }).join('');
        const dIn = d.acts.filter((l) => !isFix(l)).length;
        nAct += dIn; nEv += de; nFix += df;
        const sum = `${dIn} ${hsPl(dIn, 'внесення', 'внесення', 'внесень')}`
            + ` · ${de} ${hsPl(de, 'подія', 'події', 'подій')}`
            + (df ? ` · ${df} ${hsPl(df, 'правка', 'правки', 'правок')}` : '');
        const rest = d.acts.length - acts.length;
        const more = rest > 0
            ? `<button type="button" class="hx-all" data-day="${escapeHtml(d.day)}">`
                + `Показати решту — ще ${rest} ${hsPl(rest, 'внесення', 'внесення', 'внесень')}</button>`
            : '';
        return `<div class="hx-day"><b>${escapeHtml(d.label.name)}</b>`
            + `<span>${escapeHtml(d.label.sub)}</span>`
            + `<span class="sum">${sum}</span></div>${rows}${more}`;
    }).join('');
    box.innerHTML = html;
    if ($('hsCount')) {
        // межу читання називаємо вголос, інакше «за три місяці» тихо показувало б
        // не всі дні, а людина думала б, що їх і не було
        const cut = HS.length >= 1000 ? ' · показано останні 1000 подій' : '';
        $('hsCount').textContent = `${nAct} ${hsPl(nAct, 'внесення', 'внесення', 'внесень')}`
            + ` · ${nEv} ${hsPl(nEv, 'подія', 'події', 'подій')}`
            + (nFix ? ` · ${nFix} ${hsPl(nFix, 'правка', 'правки', 'правок')}` : '')
            + ` · ${days.length} ${hsPl(days.length, 'день', 'дні', 'днів')}${cut}`;
    }
}

/* Розкритий пакет — тварини підсписком ЗЛІВА, без вирівнювання по колонках
   стрічки: у них інший зміст (той самий висновок, що в журналі 2.39.53). */
function hsKids(rec) {
    const L = [...rec.list].sort((x, y) => String(x.animal_tag || '')
        .localeCompare(String(y.animal_tag || ''), 'uk', { numeric: true }));
    const items = L.map((e, n) => {
        const html = e.details_html || '';
        let d;
        if (html.includes('<')) d = html;
        else {
            // жирність через одну — як у журналі подій
            d = String(e.details || '').split(' · ').filter((x) => x !== '')
                .map((x, k) => (k % 2 ? escapeHtml(x) : `<b>${escapeHtml(x)}</b>`))
                .join(' · ');
        }
        if (!d && e.note) d = escapeHtml(e.note);
        return `<div class="hx-kid${n % 2 ? ' is-alt' : ''}">`
            + `<span class="k-n">${n + 1}</span>`
            + `<a class="k-tag" href="/herd/animals/${e.animal_id}">${escapeHtml(e.animal_tag || '')}</a>`
            + `<span class="k-nm">${escapeHtml(e.animal_name || '')}</span>`
            + `<span class="k-d">${d}</span></div>`;
    }).join('');
    return `<div class="hx-kids">${items}</div>`;
}

function hsToggle(row) {
    // розкрили пакет — підказка більше не потрібна: вона стоїть під рядком і
    // накрила б щойно відкритий перелік. HX_ROW лишаємо, щоб вона не
    // вискочила знову від руху миші в межах того самого рядка.
    const pop = $('hxPop');
    if (pop) pop.classList.remove('on');
    const nx = row.nextElementSibling;
    if (nx && nx.classList.contains('hx-kids')) {
        nx.remove();
        row.classList.remove('is-open');
        row.setAttribute('aria-expanded', 'false');
        return;
    }
    const rec = HS_ACTS[+row.dataset.i];
    if (!rec) return;
    row.insertAdjacentHTML('afterend', hsKids(rec));
    row.classList.add('is-open');
    row.setAttribute('aria-expanded', 'true');
}

/* ── підказка при наведенні ──
   Одна коробка на сторінку, ПОЗА панеллю (`.panel{overflow:hidden}` зрізала б
   вкладену) і `position:fixed` — тим самим шляхом, що й підказки формули.
   Показуємо те, чого немає в рядку: ДВІ дати (їх і плутають), секції з
   кількостями, деталі, нотатку й перелік бирок. */
let HX_ROW = null;

function hxHtml(rec) {
    const a = rec.a, e = rec.list[0];
    const row = (t, v) => (v ? `<dt>${t}</dt><dd>${v}</dd>` : '');
    const head = a.fix
        ? (a.fix === 'del' ? 'подію прибрано' : 'подію виправлено')
            + (a.many ? ` · ${a.n} ${hsPl(a.n, 'голова', 'голови', 'голів')}` : '')
            + (a.bid ? ` · внесення №${escapeHtml(a.bid)}` : '')
        : a.many
        ? `групове · ${a.n} ${hsPl(a.n, 'голова', 'голови', 'голів')}`
            + (a.bid ? ` · внесення №${escapeHtml(a.bid)}` : '')
        : 'одинична подія';
    // що саме змінили — окремим списком, бо в рядку воно ріжеться трикрапкою
    const chg = (e.changes || []).map((c) =>
        `<span><b>${escapeHtml(c.label)}</b>: ${escapeHtml(c.was || '—')}`
        + (a.fix === 'del' ? '' : ` → ${escapeHtml(c.now || '—')}`)
        + '</span>').join('');
    const secs = a.groups.map(([g, n]) => escapeHtml(g)
        + (a.many ? ` — ${n} ${hsPl(n, 'голова', 'голови', 'голів')}` : '')).join(' · ');
    const tags = rec.list.length > 1
        ? [...rec.list].sort((x, y) => String(x.animal_tag || '')
            .localeCompare(String(y.animal_tag || ''), 'uk', { numeric: true }))
            .slice(0, 24)
            .map((x) => `<span>${escapeHtml(x.animal_tag || '')}`
                + `${x.animal_name ? ' ' + escapeHtml(x.animal_name) : ''}</span>`).join('')
        : '';
    const more = rec.list.length > 24
        ? `<span class="more">і ще ${rec.list.length - 24}</span>` : '';
    return `<div class="hx-pop-h"><b class="ev-c-${escapeHtml(a.cat || 'other')}">`
        + `${escapeHtml(a.name)}</b><span>${head}</span></div><dl>`
        + row('Подія відбулась', escapeHtml(hsDmy((e.event_date || '').slice(0, 10))))
        + row(a.fix ? 'Виправлено' : 'Внесено',
            `${escapeHtml(hsDmy(a.day))}${a.time ? ', ' + escapeHtml(a.time) : ''}`
            + (a.user ? ' · ' + escapeHtml(a.user) : ''))
        + row(a.many ? 'Секції' : 'Секція', secs)
        // у правці «деталі» — це самі зміни, і вони нижче окремим списком:
        // двічі те саме в одній підказці читається як помилка
        + row(a.fix === 'del' ? 'Що прибрали' : 'Деталі',
            (a.fix === 'edit' && chg) ? '' : escapeHtml(a.details || ''))
        + row('Нотатка', escapeHtml(a.note || ''))
        + '</dl>'
        + (chg ? `<div class="hx-chg">${chg}</div>` : '')
        + (tags ? `<div class="hx-tags">${tags}${more}</div>` : '')
        + (a.many ? '<p class="hx-go">Клік — розкрити перелік тварин</p>' : '');
}

function hxPlace(pop, row, ev) {
    const pad = 12, r = row.getBoundingClientRect();
    const w = pop.offsetWidth, h = pop.offsetHeight;
    let x = (ev && ev.clientX) ? ev.clientX + 16 : r.left + 48;
    let y = r.bottom + 6;
    if (x + w + pad > window.innerWidth) x = Math.max(pad, window.innerWidth - w - pad);
    if (y + h + pad > window.innerHeight) y = Math.max(pad, r.top - h - 6);
    pop.style.left = `${Math.round(x)}px`;
    pop.style.top = `${Math.round(y)}px`;
}

function hxShow(row, ev) {
    const pop = $('hxPop');
    if (!pop || HX_ROW === row) return;
    const rec = HS_ACTS[+row.dataset.i];
    if (!rec) return;
    HX_ROW = row;
    pop.innerHTML = hxHtml(rec);
    pop.hidden = false;
    // міряємо ОДИН раз на вході в рядок, не на кожен рух миші — інакше
    // на кількох сотнях рядків сторінка гальмує
    hxPlace(pop, row, ev);
    pop.classList.add('on');
}

function hxHide() {
    HX_ROW = null;
    const pop = $('hxPop');
    if (pop) pop.classList.remove('on');
}


/* ═══ ДРУГА ІСТОРІЯ: ЩО МІНЯЛИ В НАЛАШТУВАННЯХ ═══
   Роман 2026-09-25: «зміна списків — треба зафіксувати, який був список до
   цього і що змінено, щоб адмін потім міг виправити, якщо якась дурня була
   зроблена». Стрічка подій відповідає «що робили з тваринами», ця — «хто що
   переробив у списках, панелях і календарі». Повернути стан до правки може
   лише адміністратор — він же єдиний, хто тут щось видаляє. */
let HS_MODE = 'events';
let CH_AREA = '';                 // фільтр стрічки змін: '' = усе
// ⚠️ IS_ADMIN уже оголошений в app.js (він є на кожній сторінці) — своє
// оголошення `const` ламало б увесь файл ще до виконання.

async function chLoad() {
    const box = $('hsFeed');
    if (!box) return;
    box.innerHTML = '<div class="hp-empty">Читаю зміни…</div>';
    const r = await apiGet('/api/herd/change-log?limit=200'
        + (CH_AREA ? '&area=' + encodeURIComponent(CH_AREA) : '')).catch(() => null);
    const items = (r && r.ok && r.items) ? r.items : [];
    $('hsCount').textContent = items.length
        ? `${items.length} ${plural(items.length, 'зміна', 'зміни', 'змін')}`
        : '';
    if (!items.length) {
        box.innerHTML = CH_AREA
            ? '<div class="hp-empty">У цій ділянці змін ще не було</div>'
            : '<div class="hp-empty">Налаштувань ще не міняли — тут зʼявиться, хто й '
              + 'що переробив у списках, панелях, календарі та Конструкторі</div>';
        return;
    }
    const ACT = { add: 'додано', edit: 'змінено', del: 'прибрано' };
    box.innerHTML = items.map((x, i) => {
        const when = String(x.created_at || '').slice(0, 16).replace('T', ' ');
        const who = escapeHtml(x.user_name || x.username || '—');
        const act = ACT[x.action] || x.action;
        // «Повернути» має сенс лише там, де є стан ДО (у доданого його немає)
        const canBack = IS_ADMIN && x.before;
        return `<div class="ch-row${i % 2 ? ' is-alt' : ''}">
            <span class="ch-when">${escapeHtml(when)}</span>
            <span class="ch-who">${who}</span>
            <span class="ch-what"><span class="ch-act ${escapeHtml(x.action)}">${escapeHtml(act)}</span>`
            + `<b>${escapeHtml(x.obj_name || x.obj_id || '')}</b> `
            + `<i>${escapeHtml(x.area_label || '')}</i>`
            + (x.summary ? `<br><i>${escapeHtml(x.summary)}</i>` : '')
            + (x.action === 'del' && x.before && x.before.formula
                ? `<br><i>формула: ${escapeHtml(String(x.before.formula))}</i>` : '')
            + '</span>'
            + (canBack ? `<button type="button" class="ch-back" data-back="${x.id}"
                 title="Повернути так, як було до цієї зміни">Повернути</button>` : '<span></span>')
            + '</div>';
    }).join('');
    box.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', async () => {
        const row = items.find((x) => String(x.id) === String(b.dataset.back)) || {};
        const nm = row.obj_name || row.obj_id || 'налаштування';
        if (!await confirmAction(`Повернути «${nm}» таким, яким воно було до цієї зміни? `
            + 'Нинішній стан запишеться в цю саму стрічку, тож крок можна буде відкотити назад.',
            { ok: 'Повернути', okClass: 'btn-primary' })) return;
        b.disabled = true;
        const r2 = await apiSend(`/api/herd/change-log/${row.id}/restore`, 'POST', {});
        b.disabled = false;
        if (!r2 || !r2.ok) { toast((r2 && r2.error) || 'Не вдалося', 'error'); return; }
        toast(`Повернуто: ${r2.name || nm}`, 'success');
        // і списки, і ПАНЕЛІ на сторінці застаріли: доти скидались лише
        // списки, і наступний клік по оку тихо скасовував повернення (Н4)
        WL_FRESH = false;
        OV_FRESH = false;
        await chLoad();
    }));
}

function hsSetMode(m) {
    HS_MODE = (m === 'changes') ? 'changes' : 'events';
    const seg = $('hsMode');
    if (seg) seg.querySelectorAll('.seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.m === HS_MODE));
    // глибина — лише для подій, ділянка — лише для змін
    const depth = document.querySelector('.hs-bar .hs-f:not(.hs-area)');
    if (depth) depth.hidden = HS_MODE !== 'events';
    const area = document.querySelector('.hs-bar .hs-area');
    if (area) area.hidden = HS_MODE !== 'changes';
    if (HS_MODE === 'changes') chLoad(); else hsLoad();
}

async function hsLoad() {
    const box = $('hsFeed');
    if (!box) return;
    const to = new Date(); const from = new Date(to.getTime() - HS_DEPTH * 86400000);
    const iso = (d) => d.toISOString().slice(0, 10);
    box.innerHTML = '<div class="hp-empty">Читаю історію…</div>';
    // події та ПРАВКИ подій — два різні сліди: подія стоїть у дні, коли її
    // внесли, а виправлення — у тому, коли виправляли (Роман 2026-09-25)
    const [r, rx] = await Promise.all([
        apiGet(`/api/herd/events-log?limit=1000&order=created&cfrom=${iso(from)}&cto=${iso(to)}`),
        apiGet(`/api/herd/edits-log?limit=1000&cfrom=${iso(from)}&cto=${iso(to)}`),
    ]);
    HS = (r && r.ok && r.events) ? r.events : [];
    HS_EDITS = ((rx && rx.ok && rx.edits) || []).map((x) => {
        const chg = x.changes || [];
        const del = x.action === 'delete';
        // у правці показуємо перехід «було → стало», у скасуванні — те, що
        // в події СТОЯЛО (стрілка в нікуди читалась би як ще одна зміна)
        const txt = chg.map((c) => del
            ? `${c.label}: ${c.was || '—'}`
            : `${c.label}: ${c.was || '—'} → ${c.now || '—'}`).join(' · ');
        return Object.assign({}, x, {
            _fix: del ? 'del' : 'edit',
            details: txt || (x.details || ''),
        });
    });
    hsRender();
}

function setTab(t) {
    TAB = ['work', 'lists', 'hist', 'add'].includes(t) ? t : 'reg';
    document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.tab === TAB));
    $('animWork').hidden = TAB !== 'work';
    $('animLists').hidden = TAB !== 'lists';
    $('animHist').hidden = TAB !== 'hist';
    $('animAdd').hidden = TAB !== 'add';
    $('animOver').hidden = TAB !== 'reg';       // «Огляд» — самі панелі-показники
    $('animFilters').hidden = true;             // добір живе у формулі, не в панелі фільтрів
    $('animStats').hidden = true;
    // таблиця тварин — лише у «Роботі зі стадом»
    $('animTableWrap').hidden = TAB !== 'work';
    // рядок формули переїхав усередину .aw-split (поруч із рейкою), тож
    // ховати треба й саму обгортку — інакше на «Огляді» лишався б рядок
    const sp = $('awSplit');
    if (sp) sp.hidden = TAB !== 'work';
    const fxTop = $('awFxTop');                 // рядок формули під пошуком (єдиний стандарт, 2026-09-30)
    if (fxTop) fxTop.hidden = TAB !== 'work';
    // пішли з «Огляду» — панель, яку збирали, більше не «в роботі»: доти
    // режим лишався, і після повернення клік по показнику дописував його в
    // панель замість відкрити (аналіз 2026-09-26, Н14)
    if (TAB !== 'reg' && typeof ovmStop === 'function') ovmStop(true);
    ovPopClose();                           // вікно налаштувань панелі не переходить з вкладкою
    if (TAB !== 'work') {                   // пішли з вкладки — нічого не висить
        awCfgClose();
        // підказка рядка формули стоїть `position:fixed`, тож сама вона з
        // вкладкою не зникає — і лишалась поверх «Огляду»
        if ($('awSug')) { $('awSug').hidden = true; AW_SUG = []; }
    }
    // лічильник не ЗНИКАЄ, а ховається: місце лишається за ним, інакше
    // вкладки їдуть убік при кожній зміні вкладки (Роман 2026-09-22)
    $('animCount').classList.toggle('is-off', TAB !== 'work');
    railRender();
    try { sessionStorage.setItem('herd:anim_tab', TAB); } catch (e) { /* ignore */ }
    if (TAB === 'work') {
        runFormula();
        // списки й панелі могли бути ще не прочитані — рейка без них порожня
        Promise.all([WLISTS.length ? Promise.resolve() : wlLoad(), ovEnsure()]).then(() => {
            railRender();
            railCounts();
        });
    } else if (TAB === 'lists') wlLoad();
    else if (TAB === 'hist') { if (HS_MODE === 'changes') chLoad(); else hsLoad(); }
    else if (TAB === 'add') afOpen();
    else { Q = null; ovLoad(); }
}

/* ---------- «Огляд»: налаштовані панелі-показники ----------
   Панель — назва + формула добору (та сама мова, що в «Роботі зі стадом»).
   Роман 2026-09-18: «прибрати реєстр і зробити налаштовані панелі». */
let OV = [], OV_ITEMS = [], OV_CUR = null, SAVE_WHERE = 'list';
let OV_COLOR = '', OV_BG = '', OV_EDGE = '', OV_LAST = {};
// які параметри вже прочитано для чисел панелей (нова формула може спитати інший)
let OV_KEYS = null;
// ранні коди фону: основні кольори показувались блідим тоном — лишаємо їх блідими
const OV_BG_OLD = { '#2f5fb0': '#e3ebf7', '#1aa86b': '#e1f4ea', '#7c3aed': '#ece3fc',
    '#b45309': '#f6e8dc', '#0e7490': '#dcedf1', '#e5484d': '#fbe2e3', '#5b7083': '#e6e9ed',
    '#f5f8fd': '#f5f8fd', '#f4fbf7': '#f4fbf7', '#f8f6fd': '#f8f6fd', '#fdf9f3': '#fdf9f3',
    '#f2f9fb': '#f2f9fb', '#fdecec': '#fdecec', '#f7f8fa': '#f7f8fa' };
const ovBgOf = (c) => OV_BG_OLD[c] || c;
const ovTint = (c) => (c ? ovBgOf(c) : '');

const OV_CACHE = 'herd:ov_cache';

/* один «Огляд» за раз (Роман 2026-09-29: «треба, щоб миттєво»): на старті ovLoad кликали двоє — і стадо (400 КБ)
   читалось двічі поспіль; другий виклик тепер чекає першого */
let OV_LOADING = null;
function ovLoad() {
    if (OV_LOADING) return OV_LOADING;
    OV_LOADING = ovLoadRun().finally(() => { OV_LOADING = null; });
    return OV_LOADING;
}
async function ovLoadRun() {
    // панель може посилатись на збережений СПИСОК («[Корови фуражні]»), тож
    // перелік списків має бути на руках, інакше число стало б помилкою
    if (!WLISTS.length) await wlLoad().catch(() => null);
    // торішні числа з памʼяті браузера — щоб панелі були видні одразу,
    // а не спалахували порожнечею, поки читаються дані (Роман 2026-09-18)
    // (памʼять браузера на старті вже підняв ovFromMemory — малюємо одразу,
    // а не після запиту: доти «Огляд» чекав мережі, хоч копія була на руках)
    if (OV.length || ovFromMemory()) ovRender();
    const r = await apiGet('/api/herd/overview-tiles').catch(() => null);
    // ⚠️ ВІДПОВІДЬ-ПОМИЛКА ≠ «ПАНЕЛЕЙ НЕМАЄ» (аналіз 2026-09-26): доти збій
    // читання (напр. сесія скінчилась) ставив OV = [] і ще й позначав його
    // свіжим — сторінка казала «Панелей ще немає», а «+» потім записав би
    // одну порожню панель замість усіх
    if (!r || r.ok === false || !Array.isArray(r.tiles)) {
        toast('Панелі не прочитались з сервера — оновіть сторінку', 'error');
        return;
    }
    OV = r.tiles;
    OV_FRESH = true;
    ovRender();                                  // спершу назви, числа — після читання
    if (COLS === null) await loadColumns();
    const keys = new Set();
    OV.forEach((t) => fxAllParts(t.formula).forEach((part) => {
        const fx = fxSides(part);
        if (fx.error) return;
        fx.sides.forEach((f) => {
            const q = window.herdQuery.parse(f, PARAMS);
            if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
        });
    }));
    const p = new URLSearchParams();
    if (keys.size) p.set('params', [...keys].join(','));
    p.set('lean', '1');
    p.set('status', 'active');            // панелі рахують тих, хто в стаді
    const a = await apiGet('/api/herd/animals?' + p.toString()).catch(() => null);
    if (!a || a.ok === false) return;            // числа лишаються з памʼяті
    OV_ITEMS = a.items || [];
    OV_KEYS = keys;
    if (a.groups) ALL_GROUPS = a.groups;
    ovRender();
    try {                                        // запамʼятовуємо на наступний вхід
        const counts = {};
        OV.forEach((t) => {
            const n = ovCount(t);
            if (n && typeof n === 'object' && !n.pending && !(n.parts || []).some((x) => x.pending)) counts[t.id] = n;
        });
        OV_LAST = counts;
        localStorage.setItem(OV_CACHE, JSON.stringify({ tiles: OV, counts }));
    } catch (e) { /* ignore */ }
}

/* число панелі на тваринах «Огляду» (ті, хто в стаді); рахує спільний модуль */
function ovCount(t) {
    if (!OV_ITEMS.length) return null;
    return ovCountOn(t.formula, OV_ITEMS);
}

function ovRender() {
    const box = $('ovGrid');
    if (!box) return;
    // схована панель — робоча складова інших, на «Огляді» її плитки немає
    // (Роман 2026-09-26: «налаштувати панель, а потім скрити із вигляду»)
    // складена схованою не буває: «комбіновані панелі або є, або немає»
    // (Роман 2026-09-27) — ховаються оком лише показники
    const SHOWN = OV.filter(ovShown);
    if (!SHOWN.length) {
        // ⚠️ ПОРОЖНІЙ «ОГЛЯД» МУСИТЬ ПОЯСНИТИ СЕБЕ (Роман 2026-09-26: «взагалі
        // все пропало» — він поперемикав око в кожного показника, і сторінка
        // стала порожньою, ніби дані зникли). Нічого не втрачено: показники
        // на місці, просто жоден не позначений до показу.
        // «Показати всі» НЕ викладає складових (аналіз 2026-09-26, Н17): вони
        // вже стоять усередині складених, а окремими плитками засмічували б
        // «Огляд» — на Буртах це 15 робочих панелей
        const comp = ovComponentIds();
        const keep = OV.some((t) => comp.has(String(t.id))) && OV.some((t) => !comp.has(String(t.id)));
        box.innerHTML = OV.length
            ? '<div class="ov-hint">Усі показники сховані з «Огляду» —'
                + ' у переліку в кожного перекреслене око. Нічого не втрачено:'
                + ' натисніть око, щоб повернути потрібний, або'
                + ' <button type="button" class="btn btn-sm" id="ovShowAll">Показати всі</button>'
                + (keep ? ' — складові складених панелей лишаться в переліку.' : '')
                + '</div>'
            : '<div class="ov-hint">Панелей ще немає — наберіть формулу у'
                + ' «Роботі зі стадом» і натисніть «+».</div>';
        if (typeof ovRailRender === 'function') ovRailRender();
        return;
    }
    const tileHtml = (t) => {
        let n = ovCount(t);
        if (n === null && OV_LAST[t.id] !== undefined) n = OV_LAST[t.id];   // поки читаємо
        const bad = typeof n === 'string';
        const pt = ovParts(n, t);
        // складена панель — назва ВГОРІ жирним (вона про всю плитку);
        // один показник — назва ПІД числом і дрібним, як і була
        // чорний шрифт у темній темі стає світлим (інакше не видно)
        const ink = (c) => (c === '#101418' ? 'var(--ov-ink)' : escapeHtml(c));
        const picks = ovmPicksOf(t);
        const edit = String(OVM_EDIT) === String(t.id);    // цю налаштовують просто на ній
        const pick = edit && !!picks;                       // …і наповнюють показниками
        // кілька показників — СТАВИМО ЇХ ПОРУЧ, кожен зі своїм підписом
        let blocks = ovBlocks(n, t);
        if (!blocks && picks && picks.length) {
            // стадо ще читається — склад панелі видно одразу, з «…» замість чисел
            // (і вже своїми кольорами — щоб колір не спалахував після читання)
            blocks = picks.map((p) => ({ v: '…', sub: '', lab: p.name, tier: p.tier, err: '',
                ink: partInk({ label: p.name }, t, picks.length > 1) }));
        } else if (blocks && picks && blocks.length === picks.length) {
            // підпис і рівень беремо зі складу: у битої одинокої частини їх немає,
            // а без підпису біля неї не було б ✕, щоб її прибрати
            blocks = blocks.map((x, i) => Object.assign({}, x,
                { lab: x.lab || picks[i].name, tier: picks[i].tier }));
        }
        // номер показника у формулі — для посилання на його тварин
        if (blocks) blocks = blocks.map((x, i) => Object.assign({}, x, { idx: i }));
        // порожня складена панель теж малюється «як складена» — інакше вона
        // показувала б «…», ніби число ще читається
        const composite = !!(blocks && blocks.length > 1) || !!pick
            || !!(picks && picks.length !== 1);
        const pt1 = (blocks || []).filter((x) => x.tier !== 'sub');
        const pt2 = (blocks || []).filter((x) => x.tier === 'sub');
        const nmTop = (composite || edit)
            ? (edit
                ? `<input type="text" class="ov-nmin" value="${escapeHtml(t.name)}" maxlength="40">`
                : `<span class="ov-nm">${escapeHtml(t.name)}</span>`)
            : '';
        const nmBottom = (composite || edit) ? '' : `<span>${escapeHtml(t.name)}</span>`;
        // поки панель у роботі, у кожного показника ✕ (прибрати), ↓/↑ (рівень)
        // і квадратик кольору — колір САМОЇ панелі-показника: складова часто
        // схована, і плитки, на якій її налаштувати, на «Огляді» немає
        const acts = (x) => {
            if (!pick || !x.lab) return '';
            const src = refLookup(x.lab);
            const so = src && src.kind === 'tile' ? src.obj : null;
            return `<span class="ov-pt-acts"><button type="button" data-ovm-tier="${escapeHtml(x.lab)}"`
                + ` title="${x.tier === 'sub' ? 'Зробити основним' : 'Зробити другорядним'}">`
                + `${x.tier === 'sub' ? '↑' : '↓'}</button>`
                + `<button type="button" data-ovm-del="${escapeHtml(x.lab)}"`
                + ' title="Прибрати з панелі">✕</button>'
                + (so ? `<button type="button" class="ov-sw ov-pt-sw" data-for="color"`
                    + ` data-tile="${escapeHtml(so.id)}"`
                    + ` title="Колір шрифту показника «${escapeHtml(x.lab)}» — такий він і в інших панелях"`
                    + ` style="background:${/^#[0-9a-f]{6}$/i.test(so.color || '') ? so.color : 'var(--text)'}"></button>` : '')
                + '</span>';
        };
        // показник-посилання — кольором шрифту СВОЄЇ панелі (partInk). І кожен
        // показник — ПОСИЛАННЯ на своїх тварин у «Роботі зі стадом», навіть
        // другорядний (Роман 2026-09-27); поки панель у роботі — ні
        const link = (x) => !edit && !x.err;
        const blk2 = (x) => `<span class="ov-pt${x.err ? ' is-err' : ''}${x.ink ? ' has-ink' : ''}"`
            + (x.ink ? ` style="--sp:${ink(x.ink)}"` : '')
            + (link(x) ? ` data-part="${x.idx}" title="${escapeHtml(x.lab
                ? `Відкрити «${x.lab}» у «Роботі зі стадом»` : 'Відкрити цих тварин у «Роботі зі стадом»')}"` : '')
            + (x.err ? ` title="${escapeHtml(x.err)}"` : '') + '>'
            + `<b>${escapeHtml(x.v)}</b>`
            + (x.sub ? `<u>${escapeHtml(x.sub)}</u>` : '')
            + (x.lab ? `<i>${escapeHtml(x.lab)}</i>` : '')
            + acts(x) + '</span>';
        // ⚠️ БИТА ЧАСТИНА НАЗИВАЄ СЕБЕ ПРОСТО НА ПЛИТЦІ (аналіз 2026-09-26, Н6):
        // доти вся складена лишалась порожньою назвою, а причина жила лише в
        // підказці на іншій сторінці — те саме «все пропало», що й у 2.40.39
        const errB = (blocks || []).find((x) => x.err);
        const errLine = errB
            ? `<span class="ov-err" title="${escapeHtml(errB.err)}">⚠ ${escapeHtml(
                (errB.lab ? errB.lab + ': ' : '') + errB.err)}</span>` : '';
        const empty = !!(picks && !picks.length);
        const body = composite
            ? (empty
                ? `<span class="ov-empty2">${pick ? 'Оберіть показники в переліку'
                    : 'Порожня — натисніть ✎ і оберіть показники'}</span>`
                : `<span class="ov-parts">${pt1.map(blk2).join('')}</span>`
                    // другорядні — ПІД основними й дрібнішим шрифтом
                    + (pt2.length ? `<span class="ov-parts ov-parts2">${pt2.map(blk2).join('')}</span>` : '')
                    + errLine)
            : `<b>${n === null ? '…' : escapeHtml(pt.main)}</b>`
                + (pt.sub ? `<i class="ov-sub">${escapeHtml(pt.sub)}</i>` : '')
                + (bad ? `<i class="ov-sub ov-err" title="${escapeHtml(n)}">${escapeHtml(n)}</i>` : '');
        // налаштування — ПРОСТО НА ПЛИТЦІ, для будь-якої панелі (ovmToolsHtml)
        const tools = edit ? ovmToolsHtml(t, !pick) : '';
        // одинока панель без свого кольору бере колір панелі, на яку посилається
        const tcol = (!composite && blocks && blocks.length === 1 && blocks[0].ink) || t.color;
        const st = (tcol ? `--sp:${ink(tcol)};` : '')
            + (t.edge ? `--edge:${ink(t.edge)};` : '')
            + (t.bg ? `--spbg:${ovTint(escapeHtml(t.bg))};` : '')
            // плитка в роботі не вужчає між кліками (OVM_W) і не буває вужчою
            // за налаштування на ній
            + (edit ? `min-width:${Math.max(OVM_W, OVM_MIN_W)}px;` : '');
        const c = st ? ` style="${st}"` : '';
        const sz = ['lg', 'xl'].includes(t.size) ? ` sz-${t.size}` : '';
        return `<div class="ov-tile${composite ? ' is-multi' : ''}${sz}${edit ? ' is-picking' : ''}"
                draggable="${edit ? 'false' : 'true'}"
                data-id="${escapeHtml(t.id)}"
                data-sec="${escapeHtml(t.section || '')}"${c}
                data-fx="${escapeHtml(t.formula)}">
            ${nmTop}${body}${nmBottom}${tools}
            <span class="ov-acts">
                <button type="button" data-act="edit" title="Змінити">✎</button>
                <button type="button" data-act="del" title="Прибрати">✕</button>
            </span>
        </div>`;
    };
    // розділи — смугами, у порядку першої появи в УСЬОМУ переліку (разом зі
    // схованими) — так само, як у бічному переліку. Доти «Огляд» рахував лише
    // видимі: «Стадо корів» (перша панель — схована «Фуражні») збоку стояв
    // першим, а тут четвертим, і перенесення одного розділу зсувало б інші
    const secs = ovSecsShown().map((k) => ({ k,
        list: SHOWN.filter((t) => (t.section || '').trim() === k) }));
    // ⚠️ НАЗВУ, ЯКУ САМЕ НАБИРАЮТЬ, ПЕРЕМАЛЬОВКА НЕ ЗАБИРАЄ: після «+»
    // відповідь сервера приходить за мить і малює плитку наново — доти поле
    // назви при цьому губило фокус, а набране за ці пів секунди зникало
    const act = document.activeElement;
    const typing = (act && act.classList && act.classList.contains('ov-nmin') && box.contains(act))
        ? { v: act.value, a: act.selectionStart, b: act.selectionEnd } : null;
    // Смугу розділу ТЯГНУТЬ, щоб поставити розділ вище чи нижче (Роман
    // 2026-09-27: «категорії хочу передвигати»). ⚠️ Панелі БЕЗ РОЗДІЛУ, що
    // стоять після іншого розділу, дістають свою смугу «Без розділу»: доти
    // вони мовчки дописувались під попередню смугу й читались як її частина
    // (на Буртах «Корови тільні» й «Відтворення корів» здавались «Стадом
    // корів»), і перенесення розділу лишило б їх позаду.
    box.innerHTML = secs.map((g, i) =>
        ((g.k || i) ? `<div class="ov-sec${g.k ? '' : ' is-none'}" draggable="true"`
            + ` data-sec="${escapeHtml(g.k)}"`
            + ' title="Потягніть смугу вище чи нижче — розділ переїде разом з усіма своїми панелями">'
            + `${escapeHtml(g.k || 'Без розділу')}</div>` : '')
        + g.list.map(tileHtml).join('')).join('');
    if (OVM_EDIT) {
        const el = box.querySelector('.ov-tile.is-picking');
        if (el) OVM_W = Math.max(OVM_W, el.offsetWidth);
        const inp = el && el.querySelector('.ov-nmin');
        if (inp && typing) {
            inp.value = typing.v;
            inp.focus();
            try { inp.setSelectionRange(typing.a, typing.b); } catch (e) { /* ignore */ }
        }
    }
    if (typeof ovRailRender === 'function') ovRailRender();   // перелік збоку — разом із плитками
    // розділи, які вже є — у підказку поля
    const dl = $('ovSections');
    if (dl) dl.innerHTML = [...new Set(OV.map((t) => (t.section || '').trim()).filter(Boolean))]
        .map((k) => `<option value="${escapeHtml(k)}">`).join('');
}

function ovPaintColors() {
    const cur = { color: OV_COLOR, edge: OV_EDGE, bg: OV_BG };
    document.querySelectorAll('.ov-sw').forEach((b) => {
        const v = cur[b.dataset.for];
        const dflt = b.dataset.for === 'color' ? 'var(--text)'
            : (b.dataset.for === 'edge' ? 'var(--primary)' : 'var(--surface)');
        b.style.background = v ? (b.dataset.for === 'bg' ? ovBgOf(v) : v) : dflt;
    });
}

/* названі кольори — та сама палітра, що в «Русі поголівʼя» (Роман 2026-09-29: «таке саме вікно вигляду для списків і
   панелей»): [назва, шрифт, кант, фон]; зберігаються, як і доти, кодом кольору */
const OV_NAMED = [
    ['Коричневий', '#8a3a16', '#a1481e', '#f2e5df'],
    ['Червоний', '#b3372f', '#e5484d', '#fbe5e6'],
    ['Помаранчевий', '#b45309', '#e8750a', '#fcecdd'],
    ['Жовтий', '#8a6a00', '#d9a400', '#faf2db'],
    ['Оливковий', '#5f6b12', '#7c8a1e', '#edefdf'],
    ['Зелений', '#2f7d4f', '#1aa86b', '#dff3ea'],
    ['Бірюзовий', '#0f766e', '#0e9488', '#ddf0ee'],
    ['Блакитний', '#0e7490', '#0891b2', '#dcf0f4'],
    ['Синій', '#2f5fb0', '#2f5fb0', '#e2e9f4'],
    ['Індиго', '#4338ca', '#4f46e5', '#e6e5fb'],
    ['Фіолетовий', '#6d3fc0', '#7c3aed', '#ede3fc'],
    ['Рожевий', '#be185d', '#db2777', '#fae1ec'],
    ['Сірий', '#7a6a58', '#7a6a58', '#eceae8'],
    ['Графітовий', '#334155', '#475569', '#e5e7ea'],
    ['Чорний', '#101418', '#1f1a17', '#e0dfdf'],
];
/* спливна палітра біля зразка — перелік «кружечок · назва» + «свій колір» */
let OV_PAL_FOR = '';
/* палітру відкрили на самій панелі «Огляду» (id) — колір лягає одразу в неї,
   а не в коробку ⚙ «Роботи зі стадом» */
let OV_PAL_TILE = '';
function ovPalOpen(btn) {
    const box = $('ovPal');
    if (!box) return;
    if (box.parentElement !== document.body) document.body.appendChild(box);
    OV_PAL_FOR = btn.dataset.for;
    OV_PAL_TILE = btn.dataset.tile || '';
    const tt = OV_PAL_TILE ? OV.find((x) => String(x.id) === OV_PAL_TILE) : null;
    const cur = (tt ? { color: tt.color || '', edge: tt.edge || '', bg: ovBgOf(tt.bg || '') }
        : { color: OV_COLOR, edge: OV_EDGE, bg: ovBgOf(OV_BG) })[OV_PAL_FOR] || '';
    const none = { color: 'Як звичайно', edge: 'Колір гілки', bg: 'Без фону' }[OV_PAL_FOR];
    const at = { color: 1, edge: 2, bg: 3 }[OV_PAL_FOR];
    const lc = cur.toLowerCase();
    const named = OV_NAMED.some((n) => n[at] === lc);
    const item = (hex, label) => `<button type="button" data-pc="${hex}" class="${lc === hex ? 'on' : ''}">`
        + `<i class="ov-pl-dot${hex ? '' : ' is-none'}"${hex ? ` style="background:${OV_PAL_FOR === 'bg' ? OV_NAMED.find((n) => n[3] === hex)[2] : hex}"` : ''}></i>`
        + `<span>${escapeHtml(label)}</span></button>`;
    box.innerHTML = `<div class="ov-pl">${item('', none)}${OV_NAMED.map((n) => item(n[at], n[0])).join('')}</div>`
        + `<label class="ov-pl-own${cur && !named ? ' on' : ''}"><input type="color" id="ovPalCustom"`
        + ` value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#808080'}"><span>Свій колір${cur && !named ? ' · ' + escapeHtml(cur) : ''}</span></label>`;
    box.hidden = false;
    const r = btn.getBoundingClientRect();
    const w = box.offsetWidth, h = box.offsetHeight;
    box.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - w - 8))}px`;
    box.style.top = `${(r.bottom + 6 + h < window.innerHeight) ? r.bottom + 6 : Math.max(8, r.top - h - 6)}px`;
}
function ovPalSet(c, live) {
    if (OV_PAL_TILE) {
        // панель у роботі, показник у ній (квадратик біля ↓ ✕) чи панель
        // зі спливаючого вікна налаштувань;
        // «свій колір» шле зміну на кожен рух повзунка — на сервер, коли вщухне
        ovSetFields(OV_PAL_TILE, { [OV_PAL_FOR]: c }, !!live);
        return;
    }
    if (OV_PAL_FOR === 'color') OV_COLOR = c;
    else if (OV_PAL_FOR === 'edge') OV_EDGE = c;
    else if (OV_PAL_FOR === 'bg') OV_BG = c;
    ovPaintColors();
}

/* ═══ ЗБЕРЕЖЕННЯ ПАНЕЛЕЙ — ПО ОДНІЙ ДІЇ, ПО ЧЕРЗІ (аналіз 2026-09-26, Н4/Н11) ═══
   Доти сторінка слала ВЕСЬ перелік панелей, і сервер ставив його замість
   свого. Тож вкладка, відкрита зранку, «Повернути» з журналу, а то й
   відповідь на попередній клік тихо стирали чужі та щойно зроблені зміни.
   Тепер кожна дія — окрема операція над ОДНІЄЮ панеллю (додати · змінити ·
   прибрати · пересунути), сервер застосовує її до СВОГО переліку, а сторінка
   шле їх строго по черзі. Відповідь замінює перелік на сторінці лише тоді,
   коли в черзі нічого не лишилось — інакше запізніла відповідь відкотила б
   щойно зроблений клік. Не вдалось — перечитуємо з сервера: людина бачить
   те, що справді збережено, а не свою незбережену зміну. */
let OV_QUEUE = Promise.resolve(), OV_INFLIGHT = 0;

function ovSend(path, body) {
    OV_INFLIGHT += 1;
    const run = async () => {
        let r = null;
        try { r = await apiSend(path, 'POST', body); } catch (e) { r = null; }
        OV_INFLIGHT -= 1;
        if (!r || r.ok === false) {
            toast((r && r.error) || 'Не збереглося — показую те, що на сервері', 'error');
            await ovRefetch();
            return null;
        }
        // сервер міг дати новій панелі інший id (якщо такий уже був)
        if (body && body.op === 'add' && body.tile && r.id && String(r.id) !== String(body.tile.id)) {
            if (String(OVM_EDIT) === String(body.tile.id)) OVM_EDIT = String(r.id);
            if (String(OVM_NEW) === String(body.tile.id)) OVM_NEW = String(r.id);
        }
        if (r.lists) { WLISTS = r.lists; WL_FRESH = true; WL_GEN++; wlToMemory(); }
        if (!OV_INFLIGHT && Array.isArray(r.tiles)) {
            OV = r.tiles;
            OV_FRESH = true;
            ovAfterWrite();
        }
        return r;
    };
    const p = OV_QUEUE.then(run);
    OV_QUEUE = p.catch(() => null);
    return p;
}
const ovOp = (op) => ovSend('/api/herd/overview-tiles/op', op);

/* свіжий перелік із сервера (після збою або перед записом зі старої копії) */
async function ovRefetch() {
    const r = await apiGet('/api/herd/overview-tiles').catch(() => null);
    if (!r || r.ok === false || !Array.isArray(r.tiles)) return false;
    OV = r.tiles;
    OV_FRESH = true;
    ovAfterWrite();
    return true;
}
async function ovEnsureFresh() {
    return OV_FRESH ? true : ovRefetch();
}

/* після будь-якого запису: те, що відкрито чи в роботі, звіряємо за id —
   його могли прибрати (тоді Enter мовчки не зберігав би нікуди) */
function ovAfterWrite() {
    if (OV_CUR) {
        const t = OV.find((x) => String(x.id) === String(OV_CUR.id));
        if (t) OV_CUR = t;
        else {
            OV_CUR = null;
            awCurShow();
            if (TAB === 'work') toast('Відкритої панелі вже немає — «+» збереже формулу новою', 'error');
        }
    }
    if (OVM_EDIT && !ovmTile()) ovmStop(true);
    ovPopRender(true);                      // вікно налаштувань — за правдою сервера
    ovCacheSave();
    ovRender();
    railRender();
    // нова формула могла спитати параметр, якого ще не читали — дочитуємо стадо
    const need = panNeed();
    if (OV_KEYS && need.some((k) => !OV_KEYS.has(k))) {
        if (TAB === 'reg') ovLoad();
        else if (TAB === 'work') railCounts();
    }
}

/* памʼять браузера — щоб наступний вхід малював панелі одразу. Пишемо й після
   кліків (доти лише після повного читання — і перший кадр був старий) */
function ovCacheSave() {
    try { localStorage.setItem(OV_CACHE, JSON.stringify({ tiles: OV, counts: OV_LAST })); } catch (e) { /* ignore */ }
}

/* ПЕРЕЙМЕНУВАТИ СПИСОК ЧИ ПАНЕЛЬ — ОДНИМ ШЛЯХОМ, РАЗОМ ІЗ ПОСИЛАННЯМИ
   (аналіз 2026-09-26, Н2). Доти назву міняли ЧОТИРИ місця (⚙ панелі, ⚙
   списку, «Списки», поле на плитці), а посилання в інших звітах переписувало
   лише одне — і складена панель мовчки чіплялась за інший звіт. Тепер
   переписує сервер, в усіх панелях і списках одразу. */
async function reportRename(kind, obj, name) {
    const nm = String(name || '').trim().replace(/\s+/g, ' ');
    if (!obj || !nm) return false;
    if (nm === obj.name) return true;
    if (/[[\]]/.test(nm)) {
        toast('У назві не можна квадратних дужок — ними у формулі позначають посилання', 'error');
        return false;
    }
    const clash = refTaken(nm, kind, obj.id);
    if (clash) {
        toast(`«${nm}» — так уже зветься ${clash.kind === 'list' ? 'список' : 'панель'}. `
            + 'На звіти посилаються за назвою, тож вона має бути одна.', 'error');
        return false;
    }
    const r = await ovSend('/api/herd/report-rename', { kind, id: obj.id, name: nm });
    if (!r) return false;
    if (WCUR) WCUR = WLISTS.find((x) => String(x.id) === String(WCUR.id)) || null;
    awCurShow();
    wlRender();
    railCounts();
    const rw = (r.rewritten || []).filter(Boolean);
    toast(rw.length ? `Перейменовано. Посилання оновлено в: ${rw.map((x) => `«${x}»`).join(', ')}`
        : 'Перейменовано', 'success');
    return true;
}

/* хто зламається, якщо прибрати цей звіт — питаємо ДО, а не після */
function refDepsText(name, obj) {
    const deps = refDependents(name, obj);
    return deps.length
        ? ` На цей звіт посилаються: ${deps.map((x) => `«${x.name}»`).join(', ')} — там цей показник `
            + 'стане «—» з поясненням, і його можна буде прибрати ✕.'
        : '';
}

function awHelpHtml() {
    return '<h4>Як писати</h4>'
        + '<p>Рядок складається з трьох частин — як налаштування списку в календарі: '
        + '<b>BODY</b> (тіло — які параметри показати), <b>FILTER</b> (фільтрація — кого брати), '
        + '<b>VIEW</b> (відображення — як показати). Усередині дужок пишемо через пробіл, '
        + 'параметри — короткими назвами.</p>'
        + '<p><code>=BODY(name group dslh)</code> — колонки таблиці. Без BODY таблиці немає: '
        + 'видно лише, скільки знайдено, і показники з VIEW (avg, sum…).</p>'
        + '<p><code>FILTER(dslh&gt;=35 rc=4)</code> — добір. Умови: '
        + '<code>=</code> <code>&lt;&gt;</code> <code>&gt;</code> <code>&gt;=</code> '
        + '<code>&lt;</code> <code>&lt;=</code>, ще <code>dslh between 28 35</code>, '
        + '<code>name contains Рай</code>, <code>name empty</code> (порожньо), '
        + '<code>name notempty</code> (є значення), '
        + '<code>group=Група-1 or Група-2</code>.</p>'
        + '<p><code>VIEW(no groupby group sort dslh desc avg dslh)</code> — '
        + '<code>no</code> колонка № з/п, <code>groupby &lt;параметр&gt;</code> групи, '
        + '<code>sort &lt;параметр&gt; desc</code> порядок (а <code>groupby group desc</code> '
        + 'перевертає самі групи), '
        + '<code>cnt</code> кількість (сама по собі — голів, з назвою параметра — '
        + 'скільки тварин мають це значення), <code>avg</code> середнє, <code>sum</code> сума, '
        + '<code>min</code> найменше, <code>max</code> найбільше. '
        + 'Числа стають у своїх колонках — у рядку групи й у рядку «Разом»; '
        + 'на одну колонку можна поставити кілька агрегацій, вони стануть поруч. '
        + 'Ширину колонки тягніть за межу заголовка — вона памʼятається. '
        + '«🖨 Друк» — попередній перегляд на A4, як у календарі: аркуш, колонки, '
        + 'шрифт і його розмір.</p>'
        + '<p>Підказка вискакує сама: стрілки <b>↑↓</b> — вибрати, <b>Tab</b> — підтвердити, '
        + '<b>Esc</b> — закрити. <b>Enter</b> — прочитати список за формулою (окремої кнопки немає).</p>'
        + '<p>Після Enter рядок сам набуває акуратного вигляду: дії великими літерами, '
        + 'параметри — короткими назвами, зайві пробіли й коми прибираються.</p>'
        + '<p>Частини пишуться в один рядок одна за одною; будь-яку можна пропустити. '
        + 'Українські слова (ТІЛО, ФІЛЬТРАЦІЯ, ВІДОБРАЖЕННЯ, групувати, сортувати, спад, між, '
        + 'містить, порожньо, або) теж працюють — після Enter рядок переписується англійською.</p>';
}

function awWordsHtml() {
    const bySec = {};
    PARAMS.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    return '<h4>Параметри з конструктора</h4>'
        + Object.keys(bySec).map((sec) => `<div class="aw-sec"><h4>${escapeHtml(sec)}</h4>`
            + '<div class="aw-words">'
            + bySec[sec].map((p) => `<button type="button" data-w="${escapeHtml(awShort(p))}"`
                + ` title="${escapeHtml(p.label)}">${escapeHtml(awShort(p))}</button>`).join('')
            + '</div></div>').join('');
}

/* коротка назва параметра — нею й пишемо у формулі */
function awShort(p) { return (p.short || p.key || '').trim() || p.label; }

/* кольорова підсвітка формули — herdQuery.highlight (herd_query.js) */

/* розфарбований HTML формули — той самий вигляд у рядку й у «Списках» */
const AW_HL_EV = /\b(EVENT|BORN|ENTRY|START|IN|OUT)\s*\(/i;
function awHlHtml(txt) {
    // формула з подією — тими самими кольорами, що рядок формули «Руху поголівʼя» (назва події — зеленим)
    if (!AW_HL_EV.test(String(txt || ''))) return window.herdQuery.highlight(txt, PARAMS);   // спільна з Календарем
    return window.herdQuery.highlight(txt, PARAMS, { acts: /^(event|born|entry|start|in|out)$/i,
        words: /^(herd|first|alive|dead|all|from|to|by)$/i,
        events: () => awEvents().flatMap((e) => [e.en, e.name, e.key]).filter(Boolean) });
}

function awPaint() {
    const hl = $('awHl');
    if (!hl) return;
    const txt = $('awInput').value;
    hl.innerHTML = awHlHtml(txt);
    hl.scrollLeft = $('awInput').scrollLeft;
    if ($('awClear')) $('awClear').hidden = !txt;
}

/* ── підказки під час набору ──────────────────────────────────────────
   Роман 2026-09-18: «немає підказок при вводі». Підказуємо дію, слово
   всередині ВІДОБРАЖЕННЯ і короткі назви параметрів після «[». */
const AW_ACTS = [
    { w: 'BODY', t: 'тіло — які параметри показати' },
    { w: 'FILTER', t: 'фільтрація — кого брати' },
    { w: 'FILTER2', t: 'додати тварин до списку: FILTER2([Пропущені] dcc>226)' },
    { w: 'VIEW', t: 'відображення — групи й порядок' },
    // та сама мова, що в «Русі поголівʼя»: не тварини, а події за період
    { w: 'EVENT', t: 'події замість тварин: EVENT(calving) FILTER(lact>0) VIEW(month_1) · EVENT(birth) · EVENT(entry)' },
];
// період подій у VIEW(…) — від сьогодні
const AW_PERIODS = [
    { w: 'month', t: 'цей місяць (так і без VIEW)' }, { w: 'month_1', t: 'минулий місяць; month_2 — позаминулий…' },
    { w: 'year', t: 'цей рік' }, { w: 'year_1', t: 'минулий рік' }, { w: 'week', t: 'цей тиждень' },
    { w: 'today', t: 'сьогодні' }, { w: 'yesterday', t: 'вчора' }, { w: '30d', t: 'останні 30 днів (7d, 90d…)' },
    { w: 'quarter', t: 'цей квартал' },
];
let AW_EVS = null;                                // події ферми — для назви в EVENT(…)
function awEvents() {
    if (AW_EVS === null) {
        AW_EVS = [];
        apiGet('/api/herd/move-vocab').then((r) => {
            AW_EVS = (r && r.events) || [];
            if (typeof awPaint === 'function') awPaint();     // назви подій — у кольорі одразу, як прийшли
        })
            .catch(() => { AW_EVS = null; });
    }
    return AW_EVS || [];
}
const AW_DISP = [
    { w: 'groupby', t: 'групувати — групи в таблиці' },
    { w: 'sort', t: 'сортувати — порядок рядків' },
    { w: 'no', t: 'нумерація — колонка № з/п' },
    { w: 'nogroup', t: 'нумерація з 1 у кожній групі' },
    { w: 'cnt', t: 'кількість — усіх або з даними в параметрі' },
    { w: 'avg', t: 'середнє по числовому параметру' },
    { w: 'sum', t: 'сума по числовому параметру' },
    { w: 'min', t: 'найменше значення' },
    { w: 'max', t: 'найбільше значення' },
    { w: 'desc', t: 'спад — від більшого до меншого' },
];
const AW_COND = [
    { w: '=', t: 'дорівнює' }, { w: '>', t: 'більше' }, { w: '<', t: 'менше' },
    { w: '>=', t: 'більше або дорівнює' }, { w: '<=', t: 'менше або дорівнює' },
    { w: '<>', t: 'не дорівнює' }, { w: 'between', t: 'між: between 200 260' },
    { w: 'contains', t: 'містить частину тексту' }, { w: 'empty', t: 'порожньо — значення немає' },
    { w: 'notempty', t: 'не порожньо — значення є' }, { w: 'or', t: 'або — кілька значень' },
];
let AW_SUG = [], AW_POS = 0, AW_FROM = 0, AW_NAV = false;

/* яка дія відкрита в місці курсора */
function awContext(txt) {
    let open = null, depth = 0;
    const re = /([\p{L}]+\d*)\s*\(|\)/gu;      // FILTER2( — теж дія
    let m;
    while ((m = re.exec(txt))) {
        if (m[0] === ')') { depth = Math.max(0, depth - 1); if (!depth) open = null; }
        else { depth += 1; open = (m[1] || '').toLowerCase(); }
    }
    return depth ? open : null;
}

function awParamItems(word, close, only) {
    const w = (word || '').toLowerCase();
    const starts = (x) => String(x || '').toLowerCase().startsWith(w);
    return PARAMS.filter((p) => (!only || only(p)) && (!w || starts(awShort(p)) || starts(p.key)
        || (p.label || '').toLowerCase().includes(w)))
        .sort((a, b) => (Number(!starts(awShort(a))) - Number(!starts(awShort(b))))
            || (awShort(a).length - awShort(b).length))
        .map((p) => ({ ins: awShort(p) + (close ? '] ' : ' '), w: awShort(p), t: p.label, k: 'p' }));
}

/* значення параметра для умови: коди з назвами, секції, стать */
function awValueItems(p, word) {
    const w = (word || '').toLowerCase();
    let list = [];
    if (p.key === 'group') list = ALL_GROUPS.map((g) => ({ v: g.name, l: '' }));
    else list = (p.choices || []).map((c) => ({ v: String(c.value), l: String(c.label || '') }));
    return list.filter((x) => !w || x.v.toLowerCase().startsWith(w) || x.l.toLowerCase().includes(w))
        // значення з пробілом — у квадратних дужках, інакше формула розірветься
        .map((x) => ({ ins: (/\s/.test(x.v) ? `[${x.v}]` : x.v) + ' ', w: x.v,
            t: x.l && x.l !== x.v ? x.l : '', k: 'v' }));
}

/* назви збережених звітів — підказка для посилання «[Назва]» */
function awRefItems(word) {
    const w = (word || '').trim().toLowerCase();
    const all = [...(WLISTS || []).map((L) => ({ n: String(L.name || ''), t: 'список' })),
        ...(OV || []).map((T) => ({ n: String(T.name || ''), t: 'панель «Огляду»' }))];
    return all.filter((x) => x.n && (!w || x.n.toLowerCase().includes(w)))
        .map((x) => ({ ins: x.n + '] ', w: x.n, t: x.t, k: 'r' }));
}

const AW_NUM = (p) => ['int', 'float', 'number'].includes(p.dtype);
const AW_TOK = '([\\p{L}\\d_./№]+|\\[[^\\]]+\\])';

function awSuggest() {
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    const left = el.value.slice(0, at);
    const inBr = left.lastIndexOf('[') > left.lastIndexOf(']');
    const findP = (tok) => window.herdQuery.findParam(tok, PARAMS);
    let items = [];
    if (inBr) {
        AW_FROM = left.lastIndexOf('[') + 1;
        // усередині FILTER/BODY/VIEW «[…]» — це назва ПАРАМЕТРА; поза дужками
        // дії — посилання на вже збережений звіт (список або панель)
        items = awContext(left) === null
            ? awRefItems(left.slice(AW_FROM))
            : awParamItems(left.slice(AW_FROM), true);
    } else {
        const m = left.match(/[\p{L}\d_./№]*$/u);
        const word = m ? m[0] : '';
        AW_FROM = at - word.length;
        const ctx = awContext(left);
        const lw = word.toLowerCase();
        const evOn = /\b(EVENT|BORN|ENTRY)\s*\(/i.test(left);
        const evName = ctx === 'event' && /\bEVENT\s*\(\s*[^\s()]*$/i.test(left);
        if (!ctx && evOn && /\)\s*[A-Za-z]*$/.test(left)) {   // після EVENT(…) — FILTER / VIEW
            items = [{ w: 'FILTER', t: 'кого рахувати: FILTER(lact>0)' }, { w: 'VIEW', t: 'за який період і що: VIEW(month_1), VIEW(avg milk/lkd)' }]
                .filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                .map((x) => ({ ins: x.w + '(', w: x.w + '(', t: x.t, k: 'a' }));
        } else if (evName) {                      // назва події — для формул чи українська
            items = awEvents().filter((e) => !lw || [e.en, e.name, e.key].some((n) => String(n || '').toLowerCase().startsWith(lw)))
                .map((e) => ({ ins: (e.en || (/[\s()]/.test(e.name) ? `[${e.name}]` : e.name)) + ') ',
                    w: e.en || e.name, t: e.en ? e.name : 'подія', k: 'a' }));
        } else if (!ctx) {                        // поза дужками — дія
            items = AW_ACTS.filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                .map((x) => ({ ins: x.w + '(', w: x.w + '(', t: x.t, k: 'a' }));
        } else if (['view', 'відображення', 'вигляд'].includes(ctx) && evOn) {
            const agg = left.match(new RegExp('(?:^|[\\s(])(avg|sum|min|max|cnt|середнє|сума|мін|макс)\\s+' + '([\\p{L}\\d_./]*)$', 'iu'));
            items = agg ? awParamItems(word, false)
                : AW_PERIODS.concat(AW_DISP.filter((x) => ['cnt', 'avg', 'sum', 'min', 'max'].includes(x.w)))
                    .filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                    .map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t, k: 'w' }));
        } else if (['view', 'відображення', 'вигляд'].includes(ctx)) {
            const agg = left.match(new RegExp('\\b(avg|sum|min|max|середнє|сума|мін|макс)\\s+' + '([\\p{L}\\d_./]*)$', 'iu'));
            const grp = left.match(/\b(groupby|sort|cnt|count|групувати|сортувати)\s+([\p{L}\d_./]*)$/iu);
            if (agg) items = awParamItems(word, false, AW_NUM);           // лише числові
            else if (grp) items = awParamItems(word, false);
            else {
                const sortDone = left.match(/\bsort\s+\S+\s+([\p{L}]*)$/iu);
                const dirs = sortDone ? [{ w: 'desc', t: 'спад — від більшого до меншого' },
                    { w: 'asc', t: 'зростання' }] : [];
                items = dirs.concat(AW_DISP).filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                    .map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t, k: 'w' }))
                    .concat(lw ? awParamItems(word, false) : []);
            }
        } else if (/^(filter|фільтр|фільтрація)\d*$/.test(ctx) || ctx === 'де') {
            // значення: «rc=», «group=Група-1 or »
            const vm = left.match(new RegExp(AW_TOK + '\\s*(=|<>|!=|>=|<=|>|<)\\s*'
                + '((?:[^\\s()]+\\s+(?:or|або)\\s+)*)([^\\s()]*)$', 'u'));
            // умова: одразу після назви параметра
            const cm = left.match(new RegExp(AW_TOK + '\\s+([\\p{L}]*)$', 'u'));
            const vp = vm ? findP(vm[1]) : null;
            if (vp) {
                AW_FROM = at - vm[4].length;
                items = awValueItems(vp, vm[4]);
            } else if (cm && findP(cm[1]) && !/^(between|між|contains|містить)$/i.test(cm[1])) {
                const cw = cm[2].toLowerCase();
                items = AW_COND.filter((x) => !cw || x.w.toLowerCase().startsWith(cw))
                    .map((x) => ({ ins: x.w + (/^[<>=]/.test(x.w) ? '' : ' '), w: x.w, t: x.t, k: 'w' }));
                if (cw) items = items.concat(awParamItems(cm[2], false));
            } else if (/[<>=]$/.test(left.trimEnd())) {
                items = [];
            } else {
                items = awParamItems(word, false);
            }
        } else {
            items = awParamItems(word, false);
        }
    }
    AW_SUG = items.slice(0, 40);
    AW_POS = 0;
    AW_NAV = false;
    awDrawSug();
}

/* підказка — під курсором, поверх сторінки (панель має transform) */
function awPlaceSug() {
    const box = $('awSug'), el = $('awInput');
    if (!box || !el || box.hidden) return;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    const cv = awPlaceSug.cv || (awPlaceSug.cv = document.createElement('canvas'));
    const g = cv.getContext('2d');
    g.font = `${cs.fontSize} ${cs.fontFamily}`;
    // рядок може переноситись: рахуємо лише останній візуальний рядок до курсора
    const x0 = r.left + parseFloat(cs.paddingLeft)
        + g.measureText(el.value.slice(0, AW_FROM)).width - el.scrollLeft;
    const w = box.offsetWidth;
    box.style.left = `${Math.round(Math.max(8, Math.min(x0, r.right - 40, window.innerWidth - w - 8)))}px`;
    box.style.width = '';
    const below = window.innerHeight - r.bottom - 10;
    const above = r.top - 10;
    const up = below < 140 && above > below;     // унизу тісно — відкриваємо вгору
    box.style.maxHeight = `${Math.min(320, Math.max(120, up ? above : below))}px`;
    box.style.top = up ? '' : `${Math.round(r.bottom + 4)}px`;
    box.style.bottom = up ? `${Math.round(window.innerHeight - r.top + 4)}px` : '';
}

/* опис у підказці: приклад після «:» — тими самими кольорами, що в рядку */
function awHintHtml(t) {
    const m = String(t || '').match(/^(.*?:\s)([A-Za-z=(\[].*)$/);
    return m ? escapeHtml(m[1]) + `<i class="aw-ex">${awHlHtml(m[2])}</i>` : escapeHtml(t || '');
}

function awDrawSug() {
    const box = $('awSug');
    if (!AW_SUG.length) { box.hidden = true; return; }
    box.innerHTML = AW_SUG.map((x, i) =>
        `<div data-i="${i}"${i === AW_POS ? ' class="on"' : ''}><b class="${x.k || ''}">${escapeHtml(x.w)}</b>`
        + `<span>${awHintHtml(x.t)}</span></div>`).join('')
        + '<div class="foot">↑↓ вибрати · Tab — вставити · Enter — прочитати список · Esc — закрити</div>';
    box.hidden = false;
    awPlaceSug();
}

function awTake(i) {
    const x = AW_SUG[i];
    if (!x) return;
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    el.value = el.value.slice(0, AW_FROM) + x.ins + el.value.slice(at);
    const pos = AW_FROM + x.ins.length;
    el.focus();
    el.selectionStart = el.selectionEnd = pos;
    $('awSug').hidden = true;
    AW_SUG = [];
    awPaint();
    awSuggest();
}

function awInsert(word) {
    const t = $('awInput');
    const at = t.selectionStart === null ? t.value.length : t.selectionStart;
    const before = t.value.slice(0, at), after = t.value.slice(at);
    t.value = before + '[' + word + ']' + after;
    t.focus();
    t.selectionStart = t.selectionEnd = (before + '[' + word + ']').length;
}

function runFormula() {
    let text = $('awInput').value.trim();
    // набране скорочення «[Дійн]» доповнюємо до повної назви звіту: збережена
    // формула мусить посилатись ТОЧНО, інакше після перейменування сусіднього
    // звіту вона мовчки чіплялась би за інший (аналіз 2026-09-26, Н1)
    const open = WCUR || OV_CUR;
    const canon = refCanon(text, open ? open.formula : '');
    if (canon !== text) { text = canon; $('awInput').value = canon; awPaint(); }
    try { localStorage.setItem(AW_KEY, text); } catch (e) { /* ignore */ }
    const msg = $('awMsg');
    // порожній рядок — стада не показуємо (Роман 2026-09-18)
    if (!text) {
        Q = null;
        msg.textContent = 'Наберіть формулу і натисніть Enter.';
        msg.classList.remove('bad');
        $('animTableWrap').hidden = true;
        $('animCount').classList.add('is-off');   // ховаємо НАПИС, місце лишаємо
        return;
    }
    // частка «A / B»: у таблиці — тварини чисельника, над нею — сама частка.
    // «[Назва]» з будь-якого боку — це вже збережений звіт (список або панель)
    // кілька показників через «;» — таблиця показує тварин ПЕРШОГО
    const parts = fxAllParts(text);
    const fx = fxSides(parts[0]);
    if (fx.error) { msg.textContent = fx.error; msg.classList.add('bad'); return; }
    // EVENT(…) FILTER(…) VIEW(…) — не тварини, а події за період: таблиця подій, над нею число
    // (Роман 2026-09-29: «одна система написання формул… івент — замість боді»)
    AW_EV = null;
    AW_EV_SEQ += 1;                                // запізніла відповідь подій уже не про цю формулу
    if (fx.sides.some((x) => window.herdPanels.isEvText(x))) { awEvRun(text, fx); return; }
    const rp = fx.ratio;
    let qb = null;
    const q = window.herdQuery.parse(fx.sides[0], PARAMS);
    if (rp && !q.error) {
        qb = window.herdQuery.parse(fx.sides[1], PARAMS);
        if (qb.error) { msg.textContent = 'після «/»: ' + qb.error; msg.classList.add('bad'); return; }
        q.keys = [...new Set([...q.keys, ...qb.keys])];
    }
    if (q.error) { msg.textContent = q.error; msg.classList.add('bad'); return; }
    Q = q;
    // без BODY — стандартного списку не показуємо, лише підсумок (Роман 2026-09-19)
    const noBody = !q.cols.length;
    $('animTableWrap').hidden = noBody;
    $('animCount').classList.remove('is-off');
    // акуратний вигляд: дії великими, без зайвих пробілів, короткі назви
    // рядок із посиланням НЕ причісуємо: інакше «[Корови фуражні]» мовчки
    // перетворилось би на розгорнуту формулу, і звʼязок зі звітом зник би
    const tidy = (qb || fxHasRef(text) || parts.length > 1)
        ? '' : window.herdQuery.format(q, PARAMS);
    // страховка: упорядкований рядок має означати рівно те саме, інакше лишаємо як є
    const same = (x, y) => JSON.stringify([x.cols, x.filters, x.sorts, x.groups, x.aggs, x.rownum])
        === JSON.stringify([y.cols, y.filters, y.sorts, y.groups, y.aggs, y.rownum]);
    // акуратний вигляд рядка: у ПОЛІ — без «=» (він стоїть значком ліворуч),
    // у сховищі — з ним, як зберігаються списки
    if (tidy && awNoEq(tidy) !== text && same(q, window.herdQuery.parse(tidy, PARAMS))) {
        $('awInput').value = awNoEq(tidy);
        try { localStorage.setItem(AW_KEY, tidy); } catch (e) { /* ignore */ }
        awPaint();
    }
    msg.classList.remove('bad');
    const need = [...new Set([...(q.cols.length ? q.cols : COLS || []), ...q.keys])];
    if (!WORK_CACHE) WORK_CACHE = workCacheLoad();
    const have = WORK_CACHE && need.every((k) => WORK_CACHE.keys.has(k));
    const fresh = have && !WORK_CACHE.stored && (Date.now() - WORK_CACHE.at) < CACHE_TTL;
    const done = () => {
        // те саме число вже стоїть у шапці («Стадо · 191 із 614»), тож окремий
        // рядок під формулою лишаємо тільки там, де таблиці немає
        msg.textContent = LAST_ITEMS.length ? '' : `Нікого із ${ALL_ITEMS.length}`;
        // хто прийшов додатковим блоком — у рядку під формулою, бо в таблиці
        // вони перемішані порядком сортування
        if (LAST_ITEMS.length && EXTRA_OF.size) {
            const by = new Map();
            LAST_ITEMS.forEach((a) => {
                const n = EXTRA_OF.get(a.id);
                if (n) by.set(n, (by.get(n) || 0) + 1);
            });
            msg.innerHTML = 'Додатково: ' + [...by.entries()]
                .map(([n, c]) => `<b>${escapeHtml(n)}</b> · ${c}`).join(' · ');
        }
        if (noBody && !qb) {
            const extra = (q.aggs || []).map((ag) => {
                const v = aggValue(ag, LAST_ITEMS);
                if (v === null) return '';
                const p0 = ag.key ? paramOf(ag.key) : null;
                return `${ag.fn}${p0 ? ' ' + escapeHtml(p0.short || p0.key) : ''} `
                    + `<b>${numFmt(v, ag.fn === 'avg' || !Number.isInteger(v) ? 1 : 0)}</b>`;
            }).filter(Boolean);
            msg.innerHTML = `Знайдено <b>${LAST_ITEMS.length}</b> із ${ALL_ITEMS.length}`
                + (extra.length ? ' · ' + extra.join(' · ') : '')
                + ' <span class="aw-dim">· таблиця — з BODY(…)</span>';
        }
        if (qb) {
            // як на панелі «Огляду»: рахуються тварини в стаді
            const r = ratioOf(q, qb, ALL_ITEMS.filter((a) => a.status === 'active'));
            const f = (v, d) => (v === null ? '—' : numFmt(v, d));
            msg.textContent = r.v === null ? 'Частка: знаменник порожній'
                : (r.pct ? `Частка ${f(r.v, 1)} % — ${f(r.a, 0)} із ${f(r.b, 0)} (у стаді)`
                    : `Відношення ${f(r.v, 2)} = ${f(r.a, 1)} / ${f(r.b, 1)} (у стаді)`);
        }
        // панель із кількох показників: показуємо ВСІ — інакше, набираючи її,
        // людина бачила б лише перше число й не знала, що вийшло
        if (parts.length > 1) {
            const n = ovCountOn(text, ALL_ITEMS.filter((a) => a.status === 'active'));
            if (typeof n === 'string') { msg.textContent = n; msg.classList.add('bad'); return; }
            // той самий показ, що на плитці й у рейці — і з форматом ВІДКРИТОЇ
            // панелі, а не вигаданої (доти тут було своє правило, Н9)
            const bl = ovBlocks(n, OV_CUR || {}) || [];
            const bad = bl.find((x) => x.err);
            if (bad) {
                msg.textContent = (bad.lab ? bad.lab + ': ' : '') + bad.err;
                msg.classList.add('bad');
                return;
            }
            msg.textContent = 'Панель: ' + bl.map((x) => (x.lab ? x.lab + ' ' : '') + x.v
                + (x.sub ? ` (${x.sub})` : '')).join(' · ') + ' (у стаді)';
        }
    };
    if (have) {                                    // усе вже прочитано — рахуємо на місці
        ALL_ITEMS = WORK_CACHE.items;
        renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
        done();
        if (!fresh) loadList().then(done);         // застаріле — оновлюємо слідом, тихо
        return;
    }
    msg.textContent = 'Читаю…';
    loadList().then(done);
}

/* ПОДІЇ ЗАМІСТЬ ТВАРИН: формула починається з EVENT / BORN / ENTRY / START / IN / OUT — мова
   «Руху поголівʼя». Сервер рахує тим самим рушієм і віддає перелік подій за період (VIEW(month_1),
   без нього — цей місяць); у таблиці — подія на рядок, клік по номеру — картка. */
let AW_EV = null, AW_EV_SEQ = 0;
async function awEvRun(text, fx) {
    Q = null;
    LIST_SEQ += 1;                                 // читання стада, що ще в дорозі, таблицю подій не перемалює
    LAST_ITEMS = [];
    awGoUpd();                                     // «Груповий ввід» — лише для тварин, не для подій
    const msg = $('awMsg');
    msg.classList.remove('bad');
    msg.textContent = 'Рахую події…';
    const first = fx.sides[0];
    const isEv = window.herdPanels.isEvText(first);
    // таблиця — перелік першого боку; частка з двох подій — число над таблицею (весь вираз)
    const side = window.herdPanels.evKey(fx.sides.every(window.herdPanels.isEvText) && !fx.ratio ? fx.whole : first);
    const my = ++AW_EV_SEQ;
    // бік частки з тварин (FILTER, панель) — рахуємо на тих, хто в стаді, з його параметрами
    const keys = new Set();
    fx.sides.filter((x) => !window.herdPanels.isEvText(x)).forEach((x) => {
        const q = window.herdQuery.parse(x, PARAMS);
        if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
    });
    const needAnimals = keys.size && !(WORK_CACHE && [...keys].every((k) => WORK_CACHE.keys.has(k)));
    const [r] = await Promise.all([
        isEv ? apiGet(evUrl([side], true)).catch(() => null) : Promise.resolve(null),
        needAnimals ? apiGet('/api/herd/animals?lean=1&status=active&params=' + encodeURIComponent([...keys].join(',')))
            .then((a) => { if (a && a.ok !== false) ALL_ITEMS = a.items || []; }).catch(() => null) : null]);
    if (my !== AW_EV_SEQ) return;
    AW_EV = { text, isEv, res: isEv ? ((r && r.ok !== false && r.values && r.values[side]) || { err: (r && r.error) || 'не вдалося порахувати' }) : null };
    awEvRedraw();
}
function awEvRedraw() {
    if (!AW_EV) return;
    const msg = $('awMsg');
    const wrap = $('animTableWrap');
    const { res, text } = AW_EV;
    const d5 = (d) => (d ? `${d.slice(8, 10)}.${d.slice(5, 7)}` : '');
    const dmy = (d) => (d ? `${d5(d)}.${d.slice(0, 4)}` : '');
    // над таблицею — те саме число, що дала б плитка «Огляду» з цією формулою
    const n = ovCountOn(text, ALL_ITEMS.filter((a) => a.status === 'active'));
    const bl = typeof n === 'string' ? [{ err: n }] : (ovBlocks(n, OV_CUR || {}) || []);
    const bad = (res && res.err) ? res.err : (bl.find((x) => x.err) || {}).err;
    msg.classList.toggle('bad', !!bad);
    if (bad) {
        msg.textContent = bad;
        wrap.hidden = true;
        $('animCount').textContent = '';
        return;
    }
    const period = res && res.from ? ` · ${res.from === res.to ? dmy(res.from) : `${d5(res.from)}–${dmy(res.to)}`}` : '';
    msg.innerHTML = (res && res.desc ? escapeHtml(res.desc) + ': ' : '')
        + bl.map((x) => (x.lab ? escapeHtml(x.lab) + ' ' : '') + `<b>${escapeHtml(x.v)}</b>` + (x.sub ? ` (${escapeHtml(x.sub)})` : '')).join(' · ')
        + escapeHtml(period);
    if (!res) { wrap.hidden = true; $('animCount').textContent = ''; return; }
    if (res.items === null || res.items === undefined) {   // вираз із кількох показників — переліку немає
        wrap.hidden = true;
        $('animCount').textContent = '';
        msg.innerHTML += ' <span class="aw-dim">· перелік — для одного показника</span>';
        return;
    }
    const items = res.items || [];
    wrap.hidden = false;
    $('animCount').classList.remove('is-off');
    $('animCount').textContent = `· ${items.length} ${items.length === 1 ? 'подія' : 'подій'}`;
    const tbl = document.querySelector('.anim-table');
    tbl.classList.add('auto-w');
    $('animHead').innerHTML = '<th class="num">№</th><th>Тварина</th><th>Кличка</th><th>Дата</th><th>Деталі</th>';
    $('animBody').innerHTML = items.length ? items.map((it, i) => `<tr><td class="num">${i + 1}</td>`
        + `<td><a href="/herd/animals/${encodeURIComponent(it.id)}">${escapeHtml(it.tag || '')}</a></td>`
        + `<td>${escapeHtml(it.name || '')}</td><td>${dmy(it.date)}</td><td>${escapeHtml(it.note || '')}</td></tr>`).join('')
        : '<tr><td colspan="5" class="empty">За цей період подій немає</td></tr>';
}

/* ТАБЛИЦЯ У ФАЙЛ — ПЛАСКА (Роман 2026-09-25: «дані повинні вигружатися не
   згруповані, а чисті колонки; якщо є групування — розкласти ці дані»).
   Групування на екрані читається оком, а у файлі воно ЗАВАЖАЄ: шапки груп і
   «Разом» стоять зайвими рядками посеред даних, і ні відсортувати, ні звести
   таблицю в Excel уже не можна. Тому:
   • шапки груп і «Разом» у файл НЕ йдуть;
   • значення групи стає ЗВИЧАЙНОЮ колонкою (першою) у КОЖНОГО рядка —
     групування вкладене, тож колонок стільки, скільки рівнів.
   На екрані й на друку все лишається як було. */
function awTableData() {
    if (AW_EV && AW_EV.res && !AW_EV.res.err) {     // режим подій: шапка й рядки — як на екрані
        const head = [...document.querySelectorAll('#animHead th')].map((th) => th.textContent.trim());
        const rows = [...document.querySelectorAll('#animBody tr')].filter((tr) => !tr.querySelector('.empty'))
            .map((tr) => ({ kind: 'row', cells: [...tr.cells].map((td) => td.textContent.replace(/\u00a0/g, ' ').trim()) }));
        const d = new Date();
        const dmy = `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
        return { head, rows, title: awCurName() || (AW_EV.res.desc || 'Події'),
            sub: `${rows.length} ${rows.length === 1 ? 'подія' : 'подій'} · ${dmy}` };
    }
    // ⚠️ Групували за колонкою, яка й так показана (звичайний випадок:
    // BODY(… group …) VIEW(groupby group)) — другої такої колонки у файлі не
    // треба, значення вже стоїть у своїй. Додаємо лише те, чого в таблиці немає.
    const shown = effCols().concat(tagInCols() ? [] : ['tag']);
    const gkeys = ((qOn() && Q.groups) || []).filter((k) => !shown.includes(k));
    const head = gkeys.map(headLabel)
        .concat(qOn() && Q.rownum ? ['№'] : [])
        .concat(exCol() ? [EX_HEAD] : [])
        .concat(tagInCols() ? [] : [headLabel('tag')])
        .concat(effCols().map(headLabel));
    // на якому рівні групування стоїть кожен ключ — значення беремо саме звідти
    const GLVL = new Map(((qOn() && Q.groups) || []).map((k, i) => [k, i]));
    const rows = [];
    const grp = [];                       // значення груп по рівнях, зверху вниз
    document.querySelectorAll('#animBody tr').forEach((tr) => {
        if (tr.classList.contains('anim-grp')) {
            const lv = +(tr.dataset.glvl || 0);
            grp[lv] = tr.dataset.gval || '';
            grp.length = lv + 1;          // вкладені рівні починаються наново
            return;
        }
        if (tr.classList.contains('anim-sum')) return;
        const cells = gkeys.map((k) => grp[GLVL.get(k)] || '');
        if (exCol()) cells.push(EXTRA_OF.get(+tr.dataset.id) || '');
        [...tr.cells].forEach((td) => {
            const span = td.colSpan || 1;
            const m = td.querySelector(':scope > .exm');
            // саме текст: innerHTML лишав «&nbsp;» у розрядах числа
            const raw = m ? td.textContent.slice(m.textContent.length) : td.textContent;
            cells.push((raw || '').replace(/\u00a0/g, ' ').trim());
            for (let i = 1; i < span; i++) cells.push('');
        });
        rows.push({ kind: 'row', cells });
    });
    const d = new Date();
    const dmy = `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
    // ⚠️ ФОРМУЛУ У ФАЙЛ НЕ КЛАДЕМО (Роман 2026-09-25): у другому рядку стояв
    // рядок добору — людині, яка відкриває файл, він нічого не каже, а Excel
    // ще й намагався прочитати його як формулу. Натомість — назва списку
    // й скільки тут тварин, тобто ЩО саме вивантажено.
    return { head, rows,
        title: awCurName() || 'Робота зі стадом',
        sub: `${rows.length} ${rows.length === 1 ? 'тварина' : 'тварин'} · ${dmy}` };
}

async function awXlsx() {
    const btn = $('awXlsx');
    btn.disabled = true;
    try {
        const r = await fetch('/api/herd/export-xlsx', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(awTableData()),
        });
        if (!r.ok) { toast('Не вдалося зібрати файл', 'error'); return; }
        const blob = await r.blob();
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = awFileName('xlsx');
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    } catch (e) {
        toast('Сервер не відповів', 'error');
    } finally { btn.disabled = false; }
}

/* друк на A4 — як у календарі: спільний модуль herd_print.js */
const AW_PRINT_KEY = 'herd:work_print';
let AW_PRINT = { orient: 'p', twocol: false, font: { family: '', size: 11, bold: false, italic: false } };
try { AW_PRINT = Object.assign(AW_PRINT, JSON.parse(localStorage.getItem(AW_PRINT_KEY) || '{}')); } catch (e) { /* ignore */ }

/* таблиця для друку: та сама шапка й рядки, але БЕЗ екранних ширин —
   клас «fit» каже модулю друку порахувати стовпці за вмістом під ширину
   аркуша (herd_print.js → fitTables). Доти сюди йшли ширини з екрана, а екран
   удвічі ширший за аркуш, тож останні стовпці просто зрізало. */
/* Чи прибирати нуль цієї колонки на папері (налаштування параметра). */
function hideZeroCol(k) {
    if (!k) return false;
    const p = paramOf(k);
    return !!(p && p.hide_zero);
}

function awPrintHtml() {
    const src = document.getElementById('animTable');
    const ths = [...src.tHead.rows[0].cells];
    const head = '<tr>' + ths.map((th) => `<th${th.classList.contains('num') ? ' class="num"' : ''}>`
        + `${escapeHtml(th.textContent.trim())}</th>`).join('') + '</tr>';
    const rows = [...src.tBodies[0].rows].map((tr) => {
        const lv = (tr.className.match(/\bl(\d)\b/) || [])[1] || '0';
        const cls = tr.classList.contains('anim-grp') ? ` class="sec l${lv}"`
            : (tr.classList.contains('anim-sum') ? ' class="tot"' : '');
        return `<tr${cls}>` + [...tr.cells].map((td) => {
            const m = td.querySelector(':scope > .exm');
            const mk = m ? `<i class="exm">${escapeHtml(m.textContent.trim())}</i>` : '';
            let txt = m ? td.textContent.slice(m.textContent.length) : td.textContent;
            // нуль на папір не йде, якщо так налаштовано параметр
            if (hideZeroCol(td.dataset.k) && window.herdPrint.isZeroText(txt)) txt = '';
            return `<td${td.classList.contains('num') ? ' class="num"' : ''}`
                + `${td.colSpan > 1 ? ` colspan="${td.colSpan}"` : ''}>${mk}${escapeHtml(txt.trim())}</td>`;
        }).join('') + '</tr>';
    }).join('');
    return `<table class="fit"><thead>${head}</thead><tbody>${rows}</tbody></table>`;
}

/* «· додатково: + · 9» у підписі аркуша — щоб і без колонки було зрозуміло,
   скільки тварин прийшло додатковим блоком */
function exSub() {
    if (!EXTRA_OF.size) return '';
    const by = new Map();
    LAST_ITEMS.forEach((a) => {
        const n = EXTRA_OF.get(a.id);
        if (n) by.set(n, (by.get(n) || 0) + 1);
    });
    return ' · додатково: ' + [...by.entries()].map(([n, c]) => `${n} · ${c}`).join(' · ');
}

/* ЯК НАЗИВАЄТЬСЯ ТЕ, ЩО ЗАРАЗ У РЯДКУ (Роман 2026-09-22 — на папір;
   2026-09-25 — і у файл: «треба показувати, що ти друкуєш, тобто назву
   списка»). Назву беремо, лише доки в рядку САМЕ формула відкритого списку:
   після ручної правки список уже не той, і стара назва збрехала б.
   ⚠️ Порівнюємо ЗМІСТ добору, а не текст: рядок сам «причісується» після
   Enter (herdQuery.format), і звірка по тексту гасила б назву одразу. */
function awCurName() {
    const cur = WCUR || OV_CUR;
    if (!cur) return '';
    const sig = (t) => {
        try {
            const one = (x) => [x.cols, x.filters, x.sorts, x.groups, x.aggs, x.rownum];
            const all = [];
            for (const part of fxAllParts(awNoEq(t).trim())) {
                const fx = fxSides(part);           // посилання — у свою формулу
                if (fx.error) return null;
                const side = [];
                for (const f of fx.sides) {
                    // подія — звіряємо сам текст (без зайвих пробілів)
                    if (window.herdPanels.isEvText(f)) { side.push(window.herdPanels.evKey(f).replace(/\s+/g, ' ')); continue; }
                    const q = window.herdQuery.parse(f, PARAMS);
                    if (q.error) return null;
                    side.push(one(q));
                }
                all.push(side);
            }
            return all.length ? JSON.stringify(all) : null;
        } catch (e) { return null; }
    };
    const mine = sig($('awInput').value);
    return (mine && mine === sig(cur.formula || '')) ? (cur.name || '') : '';
}

/* імʼя файла — з назви списку; у назві трапляються знаки, яких файл не любить */
function awFileName(ext) {
    const n = (awCurName() || 'Робота зі стадом')
        .replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
    const d = new Date();
    const dmy = `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
    return `${n} ${dmy}.${ext}`;
}

function awPrint() {
    if (AW_EV && AW_EV.res && !AW_EV.res.err && (AW_EV.res.items || []).length) {   // перелік подій — як на екрані
        const d = awTableData();
        window.herdPrint.open({
            state: AW_PRINT,
            twocolToggle: true,
            content: () => ({ title: d.title, sub: `${$('awMsg').textContent} · ${d.sub}`, body: awPrintHtml() }),
            onChange: () => {
                try { localStorage.setItem(AW_PRINT_KEY, JSON.stringify(AW_PRINT)); } catch (e) { /* ignore */ }
            },
        });
        return;
    }
    if (!LAST_ITEMS.length) { toast('Немає що друкувати', 'error'); return; }
    const today = new Date();
    const dmy = `${String(today.getDate()).padStart(2, '0')}.${String(today.getMonth() + 1).padStart(2, '0')}.${today.getFullYear()}`;
    const name = awCurName();
    window.herdPrint.open({
        state: AW_PRINT,
        twocolToggle: true,
        content: () => ({
            title: name || 'Робота зі стадом',
            sub: `${LAST_ITEMS.length} із ${ALL_ITEMS.length} · ${dmy}${exSub()}`,
            body: awPrintHtml(),                       // формулу на папір не виносимо
        }),
        onChange: () => {
            try { localStorage.setItem(AW_PRINT_KEY, JSON.stringify(AW_PRINT)); } catch (e) { /* ignore */ }
        },
    });
}

function awCsv() {
    // те саме, що в Excel: пласкі дані, назва списку — в імені файла.
    // 📌 Усередині CSV лишаємо ЛИШЕ шапку й дані: підпис над нею зсунув би
    // колонки для всього, що читає цей файл машиною (Power BI, імпорт).
    const d = awTableData();
    const num = (v) => String(v === null || v === undefined ? '' : v)
        .replace(/(\d)[\s\u00a0]+(?=\d)/g, '$1');            // 2 349 → 2349
    const esc = (v) => (/[;"\n]/.test(num(v)) ? '"' + num(v).replace(/"/g, '""') + '"' : num(v));
    const lines = [d.head.map(esc).join(';')]
        .concat(d.rows.map((r) => (r.cells || []).map(esc).join(';')));
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = awFileName('csv');
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 2000);
}

document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
    b.addEventListener('click', () => setTab(b.dataset.tab)));


/* ✕ у стрічці історії — прибрати рядок (лише адміністратор).
   Роман 2026-09-25: «я помилково зробив, я тестував… хочу, щоб я як адмін міг
   правити свою історію».
   📌 Рядок у стрічці буває ДВОХ різних природ, і прибираються вони по-різному:
   (1) ПОЗНАЧКА «виправлено / прибрано» — це запис журналу правок; зникає сама
       позначка, подія лишається такою, якою стала;
   (2) ВНЕСЕННЯ — це самі події; прибрати його означає скасувати подію
       (одну чи весь пакет), із поверненням наслідків, як у журналі подій. */
async function hsDelete(i) {
    const rec = HS_ACTS[i];
    const a = rec && rec.a;
    if (!a) return;
    hxHide();
    if (a.fix) {
        if (!await confirmAction(
            `Прибрати позначку «${HS_FIX_W[a.fix] || 'виправлено'} · ${a.name}» зі стрічки? `
            + 'Сама подія не зміниться — зникне лише слід цієї правки, '
            + 'і повернути його буде нізвідки.', { ok: 'Прибрати' })) return;
        const r = await apiSend('/api/herd/edits-log', 'DELETE',
            { ids: String(a.ids || '').split(',').filter(Boolean) });
        if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
        toast('Позначку прибрано', 'success');
        await hsLoad();
        return;
    }
    const what = a.many ? `${a.name} — ${a.n} гол.` : `${a.name} · ${a.tags && a.tags[0] || ''}`;
    if (!await confirmAction(
        `Прибрати внесення «${what}»? Подію буде скасовано, а її наслідки — відкочено.`,
        { ok: 'Прибрати' })) return;
    // ⚠️ `a.ids` — РЯДОК «1,2,3» (так його склали для пакетів), а не масив:
    // взяти з нього [0] означало б першу ЦИФРУ номера — і прибрати чужу подію
    const one = String(a.ids || '').split(',').filter(Boolean)[0];
    const r = a.many
        ? await apiSend('/api/herd/events-batch?quiet=1', 'DELETE',
            a.bid ? { batch_id: a.bid } : { ids: a.ids })
        : await apiSend('/api/herd/animals/events/' + one + '?quiet=1', 'DELETE');
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
    toast(a.many ? `Прибрано ${a.n} гол.` : 'Подію прибрано', 'success');
    await hsLoad();
}

/* ── стрічка історії: наведення, розкриття, глибина ── */
(function hsBind() {
    const feed = $('hsFeed');
    if (!feed) return;
    // наведення слухаємо ДЕЛЕГОВАНО: mouseenter не спливає, а рядків сотні
    feed.addEventListener('mouseover', (e) => {
        const row = e.target.closest('.hx-row');
        if (row) hxShow(row, e); else hxHide();
    });
    feed.addEventListener('mouseleave', hxHide);
    // з клавіатури — та сама коробка
    feed.addEventListener('focusin', (e) => {
        const row = e.target.closest('.hx-row');
        if (row) hxShow(row, null);
    });
    feed.addEventListener('focusout', hxHide);
    feed.addEventListener('click', (e) => {
        if (e.target.closest('.k-tag')) return;     // посилання на картку
        const del = e.target.closest('.hx-del');
        if (del) { e.stopPropagation(); hsDelete(+del.dataset.del); return; }
        const all = e.target.closest('.hx-all');
        if (all) { HS_SHOWN.add(all.dataset.day); hxHide(); hsRender(); return; }
        const row = e.target.closest('.hx-row.is-batch');
        if (row) hsToggle(row);
    });
    feed.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        const row = e.target.closest('.hx-row.is-batch');
        if (!row) return;
        e.preventDefault();
        hsToggle(row);
    });
    // сторінка поїхала — підказка не має висіти на порожньому місці
    window.addEventListener('scroll', hxHide, true);
    const seg = $('hsMode');
    if (seg) seg.addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (b) hsSetMode(b.dataset.m);
    });
    const ar = $('chArea');
    if (ar) {
        try { CH_AREA = localStorage.getItem('herd:chg_area') || ''; } catch (e) { /* ignore */ }
        if ([...ar.options].some((o) => o.value === CH_AREA)) ar.value = CH_AREA; else CH_AREA = '';
        ar.addEventListener('change', () => {
            CH_AREA = ar.value;
            try { localStorage.setItem('herd:chg_area', CH_AREA); } catch (e) { /* ignore */ }
            chLoad();
        });
    }
    const dep = $('hsDepth');
    if (dep) {
        dep.addEventListener('change', () => {
            HS_DEPTH = parseInt(dep.value, 10) || 30;
            try { localStorage.setItem('herd:hist_depth', String(HS_DEPTH)); } catch (er) { /* ignore */ }
            hsLoad();
        });
        try {
            const saved = localStorage.getItem('herd:hist_depth');
            if (saved && [...dep.options].some((o) => o.value === saved)) {
                dep.value = saved;
                HS_DEPTH = parseInt(saved, 10) || 30;
            }
        } catch (er) { /* ignore */ }
    }
}());

/* збереження набраної формули під назвою */
function awSaveWhere(w) {
    SAVE_WHERE = w === 'tile' ? 'tile' : 'list';
    document.querySelectorAll('#awSaveWhere .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.w === SAVE_WHERE));
    const tile = SAVE_WHERE === 'tile';
    $('awSaveCat').hidden = tile;               // список має категорію й коментар,
    $('awSaveNote').hidden = tile;              // панель — розділ
    $('ovSection').hidden = !tile;
    // кольори й формат числа переїхали під шестерню (Роман 2026-09-22)
    $('awSaveName').placeholder = tile ? 'Назва панелі' : 'Назва списку';
}

/* ЗБЕРЕГТИ ВІДКРИТЕ (тепер кличе Enter у рядку формули — awAutoSave; кнопку
   💾 прибрано 2026-09-24). Відкритий список чи панель оновлюємо МОВЧКИ (Роман
   2026-09-22: «кнопка Зберегти повинна зберігати наявний список відкритий,
   без ніяких питань»); вікно з питаннями лишилось для НОВОГО — «чи це
   список, чи панель, яка категорія». Щоб зробити ОКРЕМИЙ список із наявного,
   беруть ⧉ «копію» у «Списках» і правлять її: «+» чистить і рядок теж. */
async function awSaveClick() {
    const f = awWithEq($('awInput').value);
    if (!f) { toast('Спершу наберіть формулу', 'error'); return; }
    // УСЯ формула — без помилок: доти перевірявся лише перший показник, і
    // биту другу частину можна було зберегти (аналіз 2026-09-26)
    const bad = (WCUR || OV_CUR) ? (fxCheck(f) || await evCheck(f)) : '';
    if (bad) { toast(`Не збережено: ${bad}`, 'error'); return; }
    if (WCUR && !await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    if (WCUR) {
        const L = WLISTS.find((x) => String(x.id) === String(WCUR.id));
        if (L) {
            L.formula = f;
            if (await wlSave()) {
                wlSetCur(WLISTS.find((x) => String(x.id) === String(L.id)) || null);
                toast(`Список «${L.name}» збережено`, 'success');
            }
            return;
        }
    }
    if (OV_CUR) {
        const t = OV.find((x) => String(x.id) === String(OV_CUR.id));
        if (t) {
            // ⚠️ СКЛАДЕНУ ПАНЕЛЬ ENTER НЕ ПЕРЕЗАПИСУЄ (пастка 2.40.39: о 16:52
            // «Корови» стали «=BODY(id)» — людина набирала нову формулу, не
            // памʼятаючи, що панель відкрита). Її правлять на «Огляді» ✎.
            if (ovGuarded(t)) {
                toast(`«${t.name}» зібрана з показників — її правлять на «Огляді» (✎). `
                    + 'Цю формулу «+» збереже окремо.', 'error');
                return;
            }
            t.formula = f;
            const r = await ovOp({ op: 'set', id: t.id, fields: { formula: f } });
            if (r) {
                awCurShow();
                toast(`Панель «${t.name}» збережено`, 'success');
            }
            return;
        }
    }
    awSaveOpen();                       // нічого не відкрито — питаємо, що це
}

function awSaveOpen() {
    const f = $('awInput').value.trim();
    if (!f) { toast('Спершу наберіть формулу', 'error'); return; }
    if (!WCATS.length) wlLoad();
    $('awCfgBox').hidden = true;
    $('awSaveBox').hidden = false;
    awSaveWhere('list');
    $('awSaveName').value = '';
    $('ovSection').value = '';          // чужий розділ не підставляємо
    $('awSaveCat').value = '';
    $('awSaveNote').value = '';
    $('awSaveName').focus();
}

/* ⚙ ВИГЛЯД — назва, категорія, коментар і кольори відкритого СПИСКУ.
   Панель налаштовують спливаючим вікном поряд із нею (ovPopOpen). */
/* ⚙ тримається за ТОЙ запис, для якого її відкрили: доки коробка стоїть,
   людина може клацнути інший список у рейці чи панель на «Огляді», і запис
   «те, що відкрито зараз» уже інший — кольори лягли б не туди. */
let CFG_FOR = null;

function awCfgClose() {
    if ($('awCfgBox')) $('awCfgBox').hidden = true;
    if ($('ovPal')) $('ovPal').hidden = true;
    CFG_FOR = null;
}

/* перелік категорій у шестерні збирається щоразу: категорію могли додати в
   Конструкторі вже після завантаження сторінки. Свою, якої немає в переліку,
   теж лишаємо — інакше вона мовчки злетіла б при збереженні. */
function awCfgCats(cur) {
    const sel = $('awCfgCat');
    if (!sel) return;
    const cats = [...WCATS];
    if (cur && cur.category && !cats.includes(cur.category)) cats.push(cur.category);
    sel.innerHTML = '<option value="">Без категорії</option>'
        + cats.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    sel.value = (cur && cur.category) || '';
}

function awCfgOpen() {
    // ПАНЕЛЬ налаштовують маленьким вікном поряд із нею самою — у переліку
    // збоку, а коли її там не видно, біля ⚙ (Роман 2026-09-27: «прибрати цю
    // панель налаштування і зробити… в самій панелі спливаючим вікном»).
    // Смуга ⚙ лишилась ЛИШЕ для списків.
    if (!WCUR && OV_CUR) {
        if (OV_POP && OV_POP.id === String(OV_CUR.id)) { ovPopClose(); return; }
        const it = document.querySelector(`#awRail .awr-t[data-ov="${CSS.escape(String(OV_CUR.id))}"]`);
        ovPopOpen(OV_CUR.id, (it && it.offsetParent) ? it : $('awCfgBtn'));
        return;
    }
    const cur = WCUR;
    if (!cur) {
        toast('Спершу відкрийте список або панель', 'error');
        return;
    }
    ovPopClose();
    CFG_FOR = { kind: 'list', id: String(cur.id), name: cur.name };
    $('awSaveBox').hidden = true;
    $('awCfgBox').hidden = false;
    $('awCfgTitle').textContent = 'Список';
    $('awCfgName').value = cur.name || '';
    $('awCfgName').maxLength = 80;
    if (!WCATS.length) wlLoad().then(() => { if (!$('awCfgBox').hidden) awCfgCats(WCUR); });
    awCfgCats(cur);
    $('awCfgNote').value = cur.note || '';
    OV_COLOR = cur.color || '';
    OV_EDGE = cur.edge || '';
    OV_BG = ovBgOf(cur.bg || '');
    ovPaintColors();
    // що стояло в коробці при відкритті: записуємо ЛИШЕ змінене. Доти ⚙
    // переписувала всі поля знімком — і око, клацнуте в рейці, поки коробка
    // стояла відкритою, мовчки відкочувалось (аналіз 2026-09-26, Н18)
    CFG_SNAP = cfgValues();
}

let CFG_SNAP = {};
function cfgValues() {
    return {
        color: OV_COLOR, edge: OV_EDGE, bg: OV_BG,
        category: $('awCfgCat').value, note: $('awCfgNote').value.trim(),
    };
}

/* Копія списку в Календар (Роман 2026-09-24). Копією, не звʼязком: там
   список живе своїм життям — дні, подія, друк, — і правка тут його не чіпає.
   Дописує сервер до того, що вже є в календарі (/cal-lists/add). */
let WL_TO_CAL = false;
async function wlToCal(L) {
    if (WL_TO_CAL || !L) return;
    WL_TO_CAL = true;
    try {
        // календар читає лише звичайну формулу: частка «A / B» і помилка там
        // дали б список, у якому мовчки опинилось би все стадо
        if (!awNoEq(L.formula || '').trim()) { toast('У списку ще немає формули', 'error'); return; }
        if (fxHasRef(awNoEq(L.formula))) {
            toast('Календар не читає посилання на інший звіт — підставте саму формулу', 'error');
            return;
        }
        const q = window.herdQuery.parse(awWithEq(L.formula), PARAMS);
        if (splitRatio(awNoEq(L.formula)) || q.error) {
            toast(q.error ? `Календар не читає цю формулу: ${q.error}`
                : 'Календар не показує частку «A / B» — перенесіть звичайний список', 'error');
            return;
        }
        const cal = await apiGet('/api/herd/cal-lists').catch(() => null);
        if (!cal || !cal.ok) { toast('Не вдалося прочитати календар', 'error'); return; }
        const twin = (cal.lists || []).find((c) => awNorm(c.formula) === awNorm(L.formula));
        if (twin && !await confirmAction(`У календарі вже є «${twin.name || 'список'}» з такою самою формулою. Додати ще одну копію?`,
            { ok: 'Додати' })) return;
        const r = await apiSend('/api/herd/cal-lists/add', 'POST', { name: L.name, formula: L.formula });
        if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося додати', 'error'); return; }
        if (await confirmAction(`«${L.name}» додано в Календар. Відкрити його, щоб задати дні й подію?`,
            { ok: 'Відкрити' })) location.href = '/herd/calendar#l=' + encodeURIComponent(r.list.id);
        else toast(`«${L.name}» — у Календарі`, 'success');
    } finally { WL_TO_CAL = false; }
}
bind('awCfgCal', 'click', async () => {
    if (!CFG_FOR || CFG_FOR.kind !== 'list') return;
    if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    const L = WLISTS.find((x) => String(x.id) === CFG_FOR.id);
    if (!L) { toast('Цього списку вже немає', 'error'); return; }
    wlToCal(L);
});

async function awCfgDo() {
    if (!CFG_FOR) { awCfgClose(); return; }
    const name = $('awCfgName').value.trim().replace(/\s+/g, ' ');
    if (!name) { $('awCfgName').focus(); return; }
    const now = cfgValues();
    const changed = Object.keys(now).filter((k) => now[k] !== null && now[k] !== CFG_SNAP[k]);
    const forId = CFG_FOR.id;
    if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    let L = WLISTS.find((x) => String(x.id) === forId);
    if (!L) { awCfgClose(); toast('Цього списку вже немає', 'error'); return; }
    if (name !== L.name) {
        if (!await reportRename('list', L, name)) return;
        L = WLISTS.find((x) => String(x.id) === forId);
        if (!L) { awCfgClose(); return; }
    }
    const lk = ['color', 'edge', 'bg', 'category', 'note'].filter((k) => changed.includes(k));
    const keep = WCUR && String(WCUR.id) === forId;
    if (lk.length) {
        lk.forEach((k) => { L[k] = now[k]; });
        if (!await wlSave()) return;
    }
    if (keep) wlSetCur(WLISTS.find((x) => String(x.id) === forId) || null);
    awCfgClose();
    toast('Збережено', 'success');
}

/* зберегти набране панеллю-показником «Огляду» */
async function awSaveTile(name, formula) {
    // кольори й формат числа тут НЕ чіпаємо — вони живуть під шестернею,
    // інакше збереження формули щоразу скидало б вигляд панелі
    const section = $('ovSection').value.trim();
    if (!await ovEnsureFresh()) { toast('Панелі не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    const bad = fxCheck(formula);
    if (bad) { toast(`Не збережено: ${bad}`, 'error'); return; }
    if (/[[\]]/.test(name)) { toast('У назві не можна квадратних дужок — ними у формулі позначають посилання', 'error'); return; }
    // назва одна на списки й панелі: на звіт посилаються саме нею (Н1)
    const clash = refTaken(name, 'tile', null);
    if (clash && clash.kind === 'list') {
        toast(`«${name}» — так уже зветься список. Дайте панелі іншу назву.`, 'error');
        return;
    }
    let t = clash ? clash.obj : null;
    let r;
    if (t) {
        const own = OV_CUR && String(OV_CUR.id) === String(t.id);
        if (!own && !await confirmAction(`Панель «${t.name}» уже є. Замінити?`,
            { ok: 'Замінити' })) return;
        // порожній розділ не затирає наявний (інакше збереження однойменної
        // панелі мовчки переносило б її в інший розділ)
        const fields = Object.assign({ formula }, section ? { section } : {});
        Object.assign(t, fields);
        r = await ovOp({ op: 'set', id: t.id, fields });
    } else {
        t = { id: newId('o', OV), name: name.slice(0, 40), formula, section, show: '' };
        OV.push(t);
        r = await ovOp({ op: 'add', tile: t });
    }
    if (!r) return;
    OV_CUR = OV.find((x) => String(x.id) === String(r.id || t.id)) || null;
    $('awSaveBox').hidden = true;
    awCurShow();
    railRender();
    railCounts();            // нова панель одразу з числом
    toast(`Панель «${t.name}» збережено`, 'success');
}

async function awSaveDo() {
    const name = $('awSaveName').value.trim().replace(/\s+/g, ' ');
    const formula = awWithEq($('awInput').value);
    if (!name) { $('awSaveName').focus(); return; }
    if (!formula) { toast('Спершу наберіть формулу', 'error'); return; }
    const evBad = await evCheck(formula);
    if (evBad) { toast(`Не збережено: ${evBad}`, 'error'); return; }
    if (SAVE_WHERE === 'tile') { await awSaveTile(name, formula); return; }
    if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
    if (/[[\]]/.test(name)) { toast('У назві не можна квадратних дужок — ними у формулі позначають посилання', 'error'); return; }
    const clash = refTaken(name, 'list', null);
    if (clash && clash.kind === 'tile') {
        toast(`«${name}» — так уже зветься панель. Дайте списку іншу назву.`, 'error');
        return;
    }
    const fields = { formula, category: $('awSaveCat').value, note: $('awSaveNote').value.trim() };
    let L = clash ? clash.obj : null;
    if (L) {
        // «+» заводить НОВЕ: однойменний наявний (зокрема й відкритий) —
        // лише з перепитом, інакше мовчки переписали б список, з якого почали
        if (!await confirmAction(`Список «${L.name}» уже є. Замінити?`, { ok: 'Замінити' })) return;
        Object.assign(L, fields);
    } else {
        // ⚠️ id, якого ще немає: доти «'w' + кількість + початок назви» міг
        // збігтися з чужим списком — і Enter переписав би ІНШИЙ (Н5)
        L = Object.assign({ id: newId('w', WLISTS), name }, fields);
        WLISTS.push(L);
    }
    const id = L.id;
    if (await wlSave()) {
        $('awSaveBox').hidden = true;
        wlSetCur(WLISTS.find((x) => String(x.id) === String(id)) || null);
        toast(`Список «${name}» збережено`, 'success');
    }
}

/* панелі «Огляду» — колір і фон живуть у вікні збереження «Роботи зі стадом» */
/* палітри шрифту, канта й фону */
document.addEventListener('click', (e) => {
    const sw = e.target.closest('.ov-sw');
    const box = $('ovPal');
    if (sw) {
        e.stopPropagation();
        if (box && !box.hidden && OV_PAL_FOR === sw.dataset.for) { box.hidden = true; return; }
        ovPalOpen(sw);
        return;
    }
    if (!box || box.hidden) return;
    const pc = e.target.closest('#ovPal [data-pc]');
    if (pc) { ovPalSet(pc.dataset.pc); box.hidden = true; return; }
    if (!e.target.closest('#ovPal')) box.hidden = true;
});
document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'ovPalCustom') ovPalSet(e.target.value, true);
});

/* перетягування панелей: порядок і розділ — куди кинули, там і стоїть */
let OV_DRAG = null;
/* РОЗДІЛ, ЯКИЙ ТЯГНУТЬ (null — не тягнуть; '' — «Без розділу») */
let OV_SEC_DRAG = null;
/* розділи в тому порядку, як їх видно на «Огляді»: за першою панеллю в усьому
   переліку (як і в бічному), але лише ті, де є що показати */
function ovSecsShown() {
    const out = [];
    OV.forEach((t) => {
        const k = (t.section || '').trim();
        if (!out.includes(k)) out.push(k);
    });
    return out.filter((k) => OV.some((t) => ovShown(t) && (t.section || '').trim() === k));
}
/* розділ під курсором — за висотою: смуги йдуть одна під одною на всю
   ширину, тож і проміжок між плитками належить своєму розділу */
function ovSecAt(y) {
    let k = null;
    document.querySelectorAll('#ovGrid .ov-sec').forEach((h) => {
        if (h.getBoundingClientRect().top <= y) k = (h.dataset.sec || '').trim();
    });
    if (k === null) {                   // вище першої смуги — розділ без смуги на початку
        const t = document.querySelector('#ovGrid .ov-tile');
        k = t ? (t.dataset.sec || '').trim() : null;
    }
    return k;
}
/* куди ляже розділ: тягнуть угору — ПЕРЕД тим, над яким відпустили, донизу — ПІСЛЯ */
function ovSecTarget(y) {
    const k = ovSecAt(y);
    const order = ovSecsShown();
    const from = order.indexOf(OV_SEC_DRAG), to = order.indexOf(k);
    if (k === null || k === OV_SEC_DRAG || from < 0 || to < 0) return null;
    return { target: k, after: to > from };
}
function ovSecDropClear() {
    const g = $('ovGrid');
    if (!g) return;
    g.classList.remove('sec-drop-end', 'sec-drop-start');
    g.querySelectorAll('.sec-drop').forEach((x) => x.classList.remove('sec-drop'));
}
/* лінія там, де розділ ляже: над смугою того, що стане наступним, або в кінці */
function ovSecShowDrop(d) {
    const g = $('ovGrid');
    const order = ovSecsShown().filter((x) => x !== OV_SEC_DRAG);
    const next = order[order.indexOf(d.target) + (d.after ? 1 : 0)];
    if (next === undefined) { g.classList.add('sec-drop-end'); return; }
    const h = [...g.querySelectorAll('.ov-sec')].find((x) => (x.dataset.sec || '').trim() === next);
    if (h) h.classList.add('sec-drop');
    else g.classList.add('sec-drop-start');
}
/* формула панелі при наведенні — кольорова, як у рядку й у «Списках»
   (Роман 2026-09-19); замість звичайної сірої підказки браузера */
let ovTipT = null;
function ovTipHide() { clearTimeout(ovTipT); const t = $('ovTip'); if (t) t.hidden = true; }
bind('ovGrid', 'mouseover', (e) => {
    const tile = e.target.closest('.ov-tile');
    // над показником-посиланням — його власна підказка, формула плитки заважала б
    if (!tile || e.target.closest('.ov-acts, .ov-pt[data-part]')) { ovTipHide(); return; }
    if (tile.contains(e.relatedTarget)) return;
    clearTimeout(ovTipT);
    ovTipT = setTimeout(() => {
        let tip = $('ovTip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'ovTip';
            tip.className = 'ov-tip';
            document.body.appendChild(tip);              // панель має transform
        }
        tip.innerHTML = `<code class="wl-f">${awHlHtml(tile.dataset.fx || '')}</code>`;
        tip.hidden = false;
        const r = tile.getBoundingClientRect();
        const w = tip.offsetWidth, h = tip.offsetHeight;
        tip.style.left = `${Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8)))}px`;
        tip.style.top = `${Math.round(r.bottom + 6 + h > window.innerHeight ? r.top - h - 6 : r.bottom + 6)}px`;
    }, 0);          // підказки — миттєво (Роман 2026-09-24)
});
bind('ovGrid', 'mouseout', (e) => {
    const tile = e.target.closest('.ov-tile');
    if (tile && !tile.contains(e.relatedTarget)) ovTipHide();
});
window.addEventListener('scroll', ovTipHide, true);

bind('ovGrid', 'dragstart', (e) => {
    ovTipHide();
    const sh = e.target.closest('.ov-sec');
    if (sh) {                                   // тягнуть смугу — увесь розділ
        OV_SEC_DRAG = (sh.dataset.sec || '').trim();
        document.querySelectorAll('#ovGrid [data-sec]').forEach((x) => {
            if ((x.dataset.sec || '').trim() === OV_SEC_DRAG) x.classList.add('sec-moving');
        });
        try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', OV_SEC_DRAG); } catch (er) { /* ignore */ }
        return;
    }
    const t = e.target.closest('.ov-tile');
    if (!t) return;
    OV_DRAG = t.dataset.id;
    t.classList.add('dragging');
    try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', OV_DRAG); } catch (er) { /* ignore */ }
});
bind('ovGrid', 'dragover', (e) => {
    if (OV_SEC_DRAG !== null) {
        e.preventDefault();
        ovSecDropClear();
        const d = ovSecTarget(e.clientY);
        if (d) ovSecShowDrop(d);
        return;
    }
    if (!OV_DRAG) return;
    const t = e.target.closest('.ov-tile');
    e.preventDefault();
    document.querySelectorAll('#ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('drop-before', 'drop-after'));
    if (!t || t.dataset.id === OV_DRAG) return;
    const r = t.getBoundingClientRect();
    t.classList.add(e.clientX < r.left + r.width / 2 ? 'drop-before' : 'drop-after');
});
bind('ovGrid', 'dragend', () => {
    OV_DRAG = null;
    OV_SEC_DRAG = null;
    ovSecDropClear();
    document.querySelectorAll('#ovGrid .sec-moving').forEach((x) => x.classList.remove('sec-moving'));
    document.querySelectorAll('#ovGrid .dragging, #ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('dragging', 'drop-before', 'drop-after'));
});
bind('ovGrid', 'drop', async (e) => {
    e.preventDefault();
    if (OV_SEC_DRAG !== null) {
        const sec = OV_SEC_DRAG;
        const d = ovSecTarget(e.clientY);
        OV_SEC_DRAG = null;
        ovSecDropClear();
        if (!d) { ovRender(); return; }
        OV = ovSecMove(OV, sec, d.target, d.after);    // одразу на екрані, слідом — на сервер
        ovRender();
        await ovOp({ op: 'secmove', section: sec, target: d.target, after: d.after });
        return;
    }
    const target = e.target.closest('.ov-tile');
    const id = OV_DRAG;
    OV_DRAG = null;
    if (!target || !id || target.dataset.id === id) { ovRender(); return; }
    const after = target.classList.contains('drop-after');
    const moved = OV.find((x) => String(x.id) === String(id));
    const dest = OV.find((x) => String(x.id) === String(target.dataset.id));
    if (!moved || !dest) return;
    OV = OV.filter((x) => x !== moved);
    moved.section = dest.section || '';        // кинули в інший розділ — туди й переїхала
    const at = OV.indexOf(dest) + (after ? 1 : 0);
    OV.splice(at, 0, moved);
    ovRender();
    await ovOp({ op: 'move', id: moved.id, target: dest.id, after, section: moved.section });
});
bind('ovSection', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('ovGrid', 'click', async (e) => {
    ovTipHide();
    const tile = e.target.closest('.ov-tile');
    if (!tile) return;
    const t = OV.find((x) => String(x.id) === String(tile.dataset.id));
    if (!t) return;
    const act = (e.target.closest('[data-act]') || {}).dataset;
    if (act && act.act === 'edit') {
        // БУДЬ-ЯКУ панель налаштовують просто тут, нікуди не переходячи
        // (Роман 2026-09-27: «все на місці повинно бути»): складену ще й
        // наповнюють кліками в переліку; формулу звичайної правлять у
        // «Роботі зі стадом» — туди веде клік по самій плитці
        ovmStart(t.id);
        return;
    }
    if (act && act.act === 'del') {
        // ⚠️ спершу кажемо, КОМУ ця панель потрібна (аналіз 2026-09-26, Н2):
        // доти ✕ на плитці не питав про залежних — і складена панель мовчки
        // лишалась без показника
        const ok = await confirmAction(`Прибрати панель «${t.name}»?${refDepsText(t.name, t)}`,
            { ok: 'Прибрати', okClass: 'btn-danger' });
        if (!ok) return;
        if (String(OVM_EDIT) === String(t.id)) ovmStop(true);
        OV = OV.filter((x) => x !== t);
        ovRender();
        await ovOp({ op: 'del', id: t.id });
        return;
    }
    if (String(OVM_EDIT) === String(t.id)) return;   // цю зараз наповнюємо
    // показник складеної — посилання на ЙОГО тварин (Роман 2026-09-27: «на
    // комбінованих панелях повинно бути посилання на списки… навіть якщо
    // показник другорядний»)
    const ptEl = e.target.closest('.ov-pt[data-part]');
    if (ptEl) { ovOpenPart(t, Number(ptEl.dataset.part)); return; }
    ovOpenInWork(t);                        // клік по панелі — показати самих тварин
});

/* показник складеної → його тварини в «Роботі зі стадом». Посилання на
   панель відкриває САМУ ту панель (як клік по ній у переліку: Enter там
   збереже формулу в неї), на список — сам список; свій показник, набраний
   формулою, — лише його формулу, ні до чого не привʼязану */
function ovOpenPart(t, i) {
    const part = fxAllParts(t.formula)[i];
    if (!part) { ovOpenInWork(t); return; }
    const nm = refName(part);
    if (nm) {
        const r = refLookup(nm);
        if (!r || r.many) {
            toast(r && r.many ? r.many : `Немає звіту «${nm}» — його прибрали чи перейменували`, 'error');
            return;
        }
        if (r.kind === 'list') wlOpen(r.obj);
        else ovOpenInWork(r.obj);
        return;
    }
    ovmStop(true);
    $('awInput').value = awNoEq(part);
    try { localStorage.setItem(AW_KEY, awWithEq(part)); } catch (er) { /* ignore */ }
    WCUR = null;
    OV_CUR = null;
    awCurShow();
    setTab('work');
    railRender();
    awPaint();
}

function ovOpenInWork(t) {
    ovmStop(true);                      // пішли з «Огляду» — робота над панеллю закінчена
    if (CFG_FOR && String(t.id) !== CFG_FOR.id) awCfgClose();
    $('awInput').value = awNoEq(t.formula);
    try { localStorage.setItem(AW_KEY, t.formula); } catch (er) { /* ignore */ }
    WCUR = null;
    OV_CUR = t;
    awCurShow();
    setTab('work');
    railRender();                       // у рейці підсвічується відкрита панель
    awPaint();
}

bind('awSaveWhere', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awSaveWhere(b.dataset.w);
});

/* ═══ «ОГЛЯД»: ПЕРЕЛІК ПОКАЗНИКІВ ЗБОКУ + ЗБИРАННЯ ПАНЕЛІ ПРЯМО В НІЙ ═══
   Роман 2026-09-26: «просто створити панель, і вона пуста створюється.
   Потім я вибираю цю панель і клацаю, які показники туди ставити. І підпис
   у тій самій панелі — щоб було просто».
   Тож: «+» заводить ПОРОЖНЮ панель і одразу бере її в роботу; далі кліки
   по показниках у переліку кладуть їх у неї й забирають назад; назва
   правиться просто на плитці. Ніяких вікон. Складена панель НЕ копіює
   формули — вона називає показники («[Дійні] ; [Сухостій]»), тож правка
   показника одразу міняє й панель. */
let OVM_EDIT = null;               // id панелі, яку зараз наповнюємо
let OVM_NEW = null;                // id щойно заведеної «+» (порожню приберемо на виході)
/* ШИРИНА ПЛИТКИ НА ЧАС РОБОТИ (аналіз 2026-09-26, Н15): доти вхід у роботу
   розширював плитку (поле назви, кнопки, підказка), а кожен клік у переліку
   міняв її ширину — і сусідні плитки перескакували з ряду в ряд просто під
   рукою, а на вузькому екрані разом із ними їхав і сам перелік. Тепер
   плитка в роботі не буває вужчою, ніж була: росте, коли показників більше,
   а назад стискається лише після «Готово». Розмір (А · А · А) скидає це. */
let OVM_W = 0;
/* найвужча плитка в роботі: інакше налаштуванням на ній бракувало б місця */
const OVM_MIN_W = 232;
/* id панелі, у чиєму полі «Розділ» набирають назву НОВОГО розділу замість
   вибору зі списку ('' — ніде) */
let OV_NEWSEC_ID = '';

/* ═══ НАЛАШТУВАННЯ ПАНЕЛІ ПРОСТО НА НІЙ ═══
   Роман 2026-09-27: «вибір категорії також в панелі повинно бути зашито
   одразу, щоб нікуди не переходити ні за яким посиланням. Також колір канта,
   фона і шрифта. Також самі панелі вибирати. Все на місці повинно бути».
   Доти ✎ звичайної панелі і ⚙ складеної вели на іншу вкладку. Тепер ✎ на
   БУДЬ-ЯКІЙ панелі відкриває все тут: показники (крім набраних формулою),
   розділ, три кольори, розмір, а панелі з формулою — ще й формат числа.
   Саму формулу, як і доти, правлять у «Роботі зі стадом» (клік по плитці). */
/* рядки налаштування панелі — ТІ САМІ на плитці в роботі і в спливаючому
   вікні біля панелі (ovPopOpen). `opt.name` — рядок «Назва» (у вікні; на
   плитці назва правиться вгорі), `opt.add` — «Показники ＋ додати…» (лише
   складена в роботі), `opt.fmt` — формат числа (лише панель із формулою).
   `data-tid` — для якої панелі: обробники беруть її звідси, а не з того,
   що «зараз у роботі». */
function ovSetRows(t, opt) {
    const o = opt || {};
    const row = (lab, html, cls) => `<i>${lab}</i><span${cls ? ` class="${cls}"` : ''}>${html}</span>`;
    let out = '';
    if (o.name) {
        out += row('Назва', `<input type="text" class="ov-set-nm" data-ovm-name maxlength="40"`
            + ` value="${escapeHtml(t.name)}" title="Нова назва — Enter; посилання на панель перепишуться самі">`);
    }
    if (o.add) {
        // додати показник і звідси — не лише кліком у переліку збоку
        const have = (ovmPicksOf(t) || []).map((x) => refKey(x.name));
        const can = OV.filter((x) => !ovmWhyNot(x, t) && !have.includes(refKey(x.name)));
        out += row('Показники', `<select data-ovm-add title="Додати в цю панель ще один показник">`
            + '<option value="">＋ додати…</option>'
            + can.map((x) => `<option value="${escapeHtml(x.id)}">${escapeHtml(x.name)}</option>`).join('')
            + '</select>');
    }
    const cur = (t.section || '').trim();
    const secs = [];
    OV.forEach((x) => { const k = (x.section || '').trim(); if (k && !secs.includes(k)) secs.push(k); });
    out += row('Розділ', OV_NEWSEC_ID === String(t.id)
        ? '<input type="text" class="ov-set-new" data-ovm-newsec maxlength="40"'
            + ' placeholder="Назва нового розділу" title="Enter — зберегти, Esc — відмовитись">'
        : '<select data-ovm-sec title="У якому розділі «Огляду» стоїть панель">'
            + `<option value=""${cur ? '' : ' selected'}>Без розділу</option>`
            + secs.map((k) => `<option value="${escapeHtml(k)}"${k === cur ? ' selected' : ''}>`
                + `${escapeHtml(k)}</option>`).join('')
            + '<option value="\u0001new">＋ новий розділ…</option></select>');
    // кольори — палітра відкривається тут же, колір лягає одразу в цю панель
    const hex = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : '');
    const sw = (f, lab, dflt, val) => `<button type="button" class="ov-sw" data-for="${f}"`
        + ` data-tile="${escapeHtml(t.id)}" title="${lab}" style="background:${hex(val) || dflt}"></button>`;
    out += row('Колір', sw('color', 'Колір шрифту', 'var(--text)', t.color)
        + sw('edge', 'Колір канта зліва', 'var(--primary)', t.edge)
        + sw('bg', 'Фон панелі', 'var(--surface)', ovBgOf(t.bg || '')));
    out += row('Розмір', ['', 'lg', 'xl'].map((z, i) =>
        `<button type="button" data-ovm-size="${z}"${(t.size || '') === z ? ' class="is-on"' : ''}`
        + ` title="${['Звичайна', 'Велика', 'Ще більша'][i]}"`
        + ` style="font-size:${[10.5, 13, 15.5][i]}px">А</button>`).join(''), 'ov-sz');
    if (o.fmt) {
        const dec = String(t.dec === undefined || t.dec === null ? '' : t.dec);
        out += row('Число', '<select class="ov-set-num" data-ovm-dec title="Скільки знаків після коми">'
            + ['', '0', '1', '2', '3'].map((v, i) => `<option value="${v}"${dec === v ? ' selected' : ''}>`
                + `${['як є', 'ціле', '0,0', '0,00', '0,000'][i]}</option>`).join('') + '</select>'
            + '<label class="ov-set-chk" title="Пробіл між тисячами: 12 631 замість 12631">'
            + `<input type="checkbox" data-ovm-sep${t.sep === false ? '' : ' checked'}> 1 000</label>`);
        // «Показувати» має сенс лише в частці «A / B» — там два числа
        if (splitRatio(fxAllParts(t.formula)[0] || '')) {
            const md = t.show || 'pct';
            out += row('Показувати', '<select data-ovm-show title="Що показує панель-частка">'
                + [['pct', 'відсоток'], ['num', 'кількість'], ['both', 'кількість і відсоток']]
                    .map(([v, l]) => `<option value="${v}"${md === v ? ' selected' : ''}>${l}</option>`).join('')
                + '</select>');
        }
    }
    return `<span class="ov-set" data-tid="${escapeHtml(t.id)}">${out}</span>`;
}
/* налаштування на плитці, що в роботі: ті самі рядки + «Готово» */
function ovmToolsHtml(t, formula) {
    return ovSetRows(t, { add: !formula, fmt: formula })
        + '<span class="ov-done"><button type="button" data-ovm-done="1">Готово</button>'
        + `<i>${formula ? 'формулу правлять у «Роботі зі стадом»'
            : 'натискайте показники в переліку'} · Esc — закінчити</i></span>`;
}

/* змінити поля панелі: одразу на плитці, слідом — на сервер. `soon` —
   зачекати мить (палітра «свій колір» шле зміну на кожен рух повзунка) */
const OV_SAVE_T = {}, OV_PENDING = {};
function ovSetFields(id, fields, soon) {
    const t = OV.find((x) => String(x.id) === String(id));
    if (!t) return;
    Object.assign(t, fields);
    ovRender();
    ovPopRender();
    if (TAB === 'work') railRender();       // колір і в переліку збоку
    const k = String(t.id);
    OV_PENDING[k] = Object.assign(OV_PENDING[k] || {}, fields);
    clearTimeout(OV_SAVE_T[k]);
    const send = () => {
        const f = OV_PENDING[k];
        delete OV_PENDING[k];
        if (f && Object.keys(f).length) ovOp({ op: 'set', id: k, fields: f });
    };
    if (soon) OV_SAVE_T[k] = setTimeout(send, 400);
    else send();
}

/* інший розділ: панель стає В КІНЕЦЬ нового розділу. Інакше розділ, куди її
   поставили чи звідки забрали, міг би сам переїхати на «Огляді» — розділ
   стоїть там, де його перша панель */
async function ovSetSection(t, sec) {
    const k = String(sec || '').trim().replace(/\s+/g, ' ').slice(0, 40);
    OV_NEWSEC_ID = '';
    if (!t || (t.section || '').trim() === k) { ovRender(); ovPopRender(); return; }
    const last = [...OV].reverse().find((x) => x !== t && (x.section || '').trim() === k);
    OV = OV.filter((x) => x !== t);
    t.section = k;
    if (last) OV.splice(OV.indexOf(last) + 1, 0, t);
    else OV.push(t);
    ovRender();
    ovPopRender();
    if (TAB === 'work') railRender();
    // панель у роботі переїхала в інше місце «Огляду» — показуємо, куди
    if (String(OVM_EDIT) === String(t.id)) {
        const el = document.querySelector('#ovGrid .ov-tile.is-picking');
        if (el) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
    await ovOp({ op: 'move', id: t.id, target: last ? last.id : '', after: true, section: k });
}
const OVM_ON = () => !!OVM_EDIT;
const ovmTile = () => OV.find((x) => String(x.id) === String(OVM_EDIT)) || null;

/* перелік показників збоку «Огляду» — той самий, що в рейці «Роботи зі
   стадом», і так само згортається (Роман 2026-09-26: «це панель бічна, її
   треба скривати, розкривати») */
const OVR_CLOSED_KEY = 'herd:ovrail_closed';
let OVR_CLOSED = false;
try { OVR_CLOSED = localStorage.getItem(OVR_CLOSED_KEY) === '1'; } catch (e) { /* ignore */ }

/* ВЗЯТИ ПАНЕЛЬ У РОБОТУ — ОДНА ТОЧКА ВХОДУ (аналіз 2026-09-26, Н14).
   Доти входів було два («+» і ✎), і з видаленням старого редактора зник
   рядок, що розгортав згорнутий перелік показників (урок 2.40.34 — глухий
   кут: «оберіть показники в переліку», а переліку не видно). */
function ovmStart(id, isNew) {
    // з якої ширини починаємо — плитка в роботі вужчою не стане (OVM_W)
    const was = document.querySelector(`#ovGrid .ov-tile[data-id="${CSS.escape(String(id))}"]`);
    OVM_W = was ? was.offsetWidth : 0;
    OVM_EDIT = String(id);
    OVM_NEW = isNew ? String(id) : null;
    OV_NEWSEC_ID = '';
    // перелік показників потрібен, лише коли панель ними й наповнюють
    // (лише на час роботи: вибір людини в памʼяті лишається)
    if (ovmPicksOf(ovmTile())) OVR_CLOSED = false;
    ovRender();
    const el = document.querySelector('.ov-tile.is-picking .ov-nmin');
    if (el) { el.focus(); if (isNew) el.select(); }
}
/* І ОДНА ТОЧКА ВИХОДУ — «Готово», Escape, інша вкладка, клік по іншій
   панелі, око на самій панелі. Доти кожен шлях виходив по-своєму, а
   половина не виходила зовсім (кліки дописувались у сховану панель). */
function ovmStop(silent) {
    if (!OVM_EDIT) return;
    const t = ovmTile();
    const blankNew = !!(t && OVM_NEW && String(t.id) === OVM_NEW && !String(t.formula || '').trim());
    OVM_EDIT = null;
    OVM_NEW = null;
    OVM_W = 0;
    OV_NEWSEC_ID = '';
    // палітра, відкрита на плитці, лишається лише для вікна налаштувань
    if (OV_PAL_TILE && !OV_POP) { OV_PAL_TILE = ''; if ($('ovPal')) $('ovPal').hidden = true; }
    try { OVR_CLOSED = localStorage.getItem(OVR_CLOSED_KEY) === '1'; } catch (e) { /* ignore */ }
    if (blankNew) {
        // «+» → нічого не обрали → «Готово»: порожня «Нова панель» не лишається
        // висіти на «Огляді» назавжди
        OV = OV.filter((x) => x !== t);
        ovOp({ op: 'del', id: t.id });
        if (!silent) toast('Порожню панель прибрано', 'success');
    }
    ovRender();
}

function ovRailRender() {
    const box = $('ovRail');
    if (!box) return;
    box.classList.toggle('is-closed', OVR_CLOSED);
    const cur = ovmTile();
    // поки збираємо панель, на вузькому екрані перелік стоїть унизу вікна
    // (CSS), а не їде за плитками, що ростуть над ним (Н15)
    box.classList.toggle('is-picking', !!cur);
    // «+» стоїть НАД переліком показників — саме з них і збирається панель
    box.innerHTML = '<div class="awr-headrow">'
        + '<button type="button" class="awr-head" id="ovRailHead"'
        + ` title="${OVR_CLOSED ? 'Показати перелік показників' : 'Згорнути перелік'}">`
        + `<span class="awr-chev">${OVR_CLOSED ? '▸' : '▾'}</span>Показники`
        + (OVR_CLOSED ? '' : `<i class="awr-what">${cur ? `${ovmPicksOf(cur) ? 'додаєте в' : 'налаштовуєте'} «${escapeHtml(cur.name)}»`
            : 'натисніть, щоб відкрити'}</i>`)
        + '</button>'
        + '<button type="button" class="awr-add" id="ovMerge"'
        + ' title="Нова панель із показників">+</button>'
        + '</div>'
        + (OVR_CLOSED ? '' : '<div id="ovRailList"></div>');
    // що зараз у панелі, яку наповнюємо — щоб підсвітити в переліку
    // панель, набрану формулою, не наповнюють — перелік тоді звичайний
    const picks = cur ? ovmPicksOf(cur) : null;
    if (!OVR_CLOSED) {
        panList($('ovRailList'), picks ? { names: picks.map((x) => refKey(x.name)), self: cur } : null);
    }
}

/* «+» — порожня панель, і одразу беремо її в роботу */
bind('ovRail', 'click', async (e) => {
    if (e.target.closest('#ovMerge')) {
        if (!await ovEnsureFresh()) { toast('Панелі не прочитались з сервера — оновіть сторінку', 'error'); return; }
        ovmStop(true);
        // назва за замовчуванням — неповторна: дві «Нова панель» робили
        // посилання на неї неоднозначним
        let name = 'Нова панель';
        for (let i = 2; refTaken(name, 'tile', null); i++) name = `Нова панель ${i}`;
        const t = { id: newId('o', OV), name, formula: '', section: '', show: '' };
        OV.push(t);
        ovmStart(t.id, true);
        await ovOp({ op: 'add', tile: t });
        return;
    }
    if (e.target.closest('#ovRailHead')) {
        OVR_CLOSED = !OVR_CLOSED;
        try { localStorage.setItem(OVR_CLOSED_KEY, OVR_CLOSED ? '1' : '0'); } catch (er) { /* ignore */ }
        ovRailRender();
        return;
    }
    const ed = e.target.closest('[data-ed]');
    if (ed) { ovPopOpen(ed.dataset.ed, ed.closest('.awr-t')); return; }
    const eye = e.target.closest('[data-eye]');
    if (eye) { ovEyeToggle(eye.dataset.eye); return; }
    const b = e.target.closest('.awr-t');
    if (!b) return;
    const t = OV.find((x) => String(x.id) === String(b.dataset.ov));
    if (!t) return;
    if (OVM_ON() && ovmPicksOf(ovmTile())) ovmToggle(t);    // наповнюємо панель
    else ovOpenInWork(t);                   // інакше — показуємо його тварин
});

/* Око: показувати цей показник на «Огляді» чи ні.
   ⚠️ Ця функція зникла разом із редактором-карткою у 2.40.45 — вона стояла
   поруч із ним, і око після того клікалось у порожнечу (ReferenceError).
   Те саме, що з `ovmNames()`: видаляєш блок — пройдись по тому, що з нього
   кликали, і по тому, що лежало поруч. */
async function ovEyeToggle(id) {
    const t = OV.find((x) => String(x.id) === String(id));
    if (!t) return;
    t.hidden = !t.hidden;
    // сховали саму панель, яку збирали, — робота закінчується: інакше кліки
    // по показниках мовчки дописувались би в невидиму панель (Н14)
    if (t.hidden && String(OVM_EDIT) === String(t.id)) ovmStop(true);
    ovRender();
    railRender();
    if (await ovOp({ op: 'set', id: t.id, fields: { hidden: t.hidden } })) {
        toast(t.hidden ? `«${t.name}» сховано з «Огляду»` : `«${t.name}» знову на «Огляді»`,
            'success');
    }
}

/* зберегти склад панелі, що в роботі: одразу на екрані, слідом — на сервер */
function ovmPut(t, picks) {
    t.formula = ovmFormulaOf(picks);
    ovRender();
    return ovOp({ op: 'set', id: t.id, fields: { formula: t.formula } });
}

/* показник у панель / з панелі (порівняння — без урахування регістру, як і
   рахується посилання: інакше «[Дійн]» не підсвічувалось і клік дописував дубль) */
async function ovmToggle(src) {
    const t = ovmTile();
    if (!t || !src) return;
    const why = ovmWhyNot(src, t);
    if (why) { toast(why, 'error'); return; }
    const picks = ovmPicksOf(t);
    if (!picks) { toast('Цю панель зібрано формулою — правте її у «Роботі зі стадом»', 'error'); return; }
    const k = refKey(src.name);
    const has = picks.some((x) => refKey(x.name) === k);
    let next = has ? picks.filter((x) => refKey(x.name) !== k)
        : picks.concat([{ name: src.name, tier: '' }]);
    // прибрали останній основний — першим основним стає перший другорядний
    if (next.length && !next.some((x) => x.tier !== 'sub')) next = next.map((x, i) => (i ? x : Object.assign({}, x, { tier: '' })));
    await ovmPut(t, next);
}

/* дії просто на плитці, поки вона в роботі */
bind('ovGrid', 'click', async (e) => {
    if (e.target.closest('#ovShowAll')) {
        // складові лишаються схованими — вони вже є всередині складених (Н17);
        // якщо сховані самі лише складові, повертаємо все, як і доти
        const comp = ovComponentIds();
        let back = OV.filter((x) => x.hidden && !comp.has(String(x.id)));
        if (!back.length) back = OV.filter((x) => x.hidden);
        const ids = back.map((x) => x.id);
        if (!ids.length) return;
        back.forEach((x) => { x.hidden = false; });
        ovRender();
        if (await ovOp({ op: 'set', ids, fields: { hidden: false } })) {
            const left = OV.filter((x) => x.hidden).length;
            toast(left
                ? `На «Огляді» знову ${ids.length} ${plural(ids.length, 'панель', 'панелі', 'панелей')}. `
                    + `Складові (${left}) лишились у переліку — вони вже показані всередині складених.`
                : 'Усі показники знову на «Огляді»', 'success');
        }
        return;
    }
    if (ovSetOnClick(e)) return;
    if (e.target.closest('[data-ovm-done]')) { ovmStop(); return; }
    const del = e.target.closest('[data-ovm-del]');
    if (del) {
        const t = ovmTile();
        const picks = t && ovmPicksOf(t);
        if (!picks) return;
        const k = refKey(del.dataset.ovmDel);
        let next = picks.filter((x) => refKey(x.name) !== k);
        if (next.length && !next.some((x) => x.tier !== 'sub')) next = next.map((x, i) => (i ? x : Object.assign({}, x, { tier: '' })));
        await ovmPut(t, next);
        return;
    }
    const tier = e.target.closest('[data-ovm-tier]');
    if (tier) {
        const t = ovmTile();
        const picks = t && ovmPicksOf(t);
        if (!picks) return;
        const x = picks.find((y) => refKey(y.name) === refKey(tier.dataset.ovmTier));
        if (!x) return;
        // ⚠️ хоча б один показник — основний (запобіжник старого редактора,
        // що зник разом із ним у 2.40.45): без нього на плитці не лишалось
        // жодного великого числа
        if (x.tier !== 'sub' && picks.filter((y) => y.tier !== 'sub').length === 1) {
            toast('Хоча б один показник має бути основним — спершу підніміть інший ↑', 'error');
            return;
        }
        x.tier = x.tier === 'sub' ? '' : 'sub';
        await ovmPut(t, picks);
    }
});
/* назва — просто на плитці (тим самим перейменуванням, що й скрізь: разом
   із посиланнями на неї в інших звітах) */
bind('ovGrid', 'change', async (e) => {
    if (await ovSetOnChange(e)) return;         // налаштування на плитці (ovSetRows)
    const t = ovmTile();
    const inp = e.target.closest('.ov-nmin');
    if (!t || !inp) return;
    const nm = inp.value.trim().replace(/\s+/g, ' ').slice(0, 40);
    if (!nm || nm === t.name) { inp.value = t.name; return; }
    if (!await reportRename('tile', t, nm)) inp.value = t.name;
});
bind('ovGrid', 'keydown', (e) => {
    if (e.target.closest('.ov-nmin') && e.key === 'Enter') { e.preventDefault(); e.target.blur(); }
    ovSetOnKey(e);
});
bind('ovGrid', 'focusout', ovSetOnBlur);

/* ─── обробники рядків налаштування (ovSetRows) — спільні для плитки в
   роботі й спливаючого вікна; панель — з `data-tid` самого блоку ─── */
const ovSetTile = (el) => {
    const box = el && el.closest && el.closest('.ov-set[data-tid]');
    return box ? (OV.find((x) => String(x.id) === box.dataset.tid) || null) : null;
};
/* розмір (А · А · А) */
function ovSetOnClick(e) {
    const szb = e.target.closest('.ov-set [data-ovm-size]');
    if (!szb) return false;
    const t = ovSetTile(szb);
    if (!t) return true;
    if (String(OVM_EDIT) === String(t.id)) OVM_W = 0;   // інший розмір — плитка міряється наново
    ovSetFields(t.id, { size: szb.dataset.ovmSize || '' });
    return true;
}
async function ovSetOnChange(e) {
    const t = ovSetTile(e.target);
    if (!e.target.closest('.ov-set[data-tid]')) return false;
    if (!t) return true;
    const sec = e.target.closest('[data-ovm-sec]');
    if (sec) {
        if (sec.value === '\u0001new') {           // «＋ новий розділ…» — поле для назви
            OV_NEWSEC_ID = String(t.id);
            ovRender();
            ovPopRender();
            const ns = document.querySelector(`.ov-set[data-tid="${CSS.escape(String(t.id))}"] [data-ovm-newsec]`);
            if (ns) ns.focus();
            return true;
        }
        await ovSetSection(t, sec.value);
        return true;
    }
    const add = e.target.closest('[data-ovm-add]');
    if (add) {
        const src = OV.find((x) => String(x.id) === String(add.value));
        if (src) await ovmToggle(src);
        return true;
    }
    const dec = e.target.closest('[data-ovm-dec]');
    if (dec) { ovSetFields(t.id, { dec: dec.value }); return true; }
    const sep = e.target.closest('[data-ovm-sep]');
    if (sep) { ovSetFields(t.id, { sep: !!sep.checked }); return true; }
    const show = e.target.closest('[data-ovm-show]');
    if (show) { ovSetFields(t.id, { show: show.value }); return true; }
    const nmi = e.target.closest('[data-ovm-name]');
    if (nmi) {
        const nm = nmi.value.trim().replace(/\s+/g, ' ').slice(0, 40);
        if (!nm || nm === t.name) { nmi.value = t.name; return true; }
        if (!await reportRename('tile', t, nm)) nmi.value = t.name;
        ovPopRender();
        return true;
    }
    return true;
}
/* назва нового розділу: Enter — поставити панель у нього, Esc — відмовитись
   (Esc тут не завершує роботи над панеллю й не закриває вікна); назва
   панелі у вікні — Enter */
function ovSetOnKey(e) {
    if (e.target.closest('[data-ovm-name]') && e.key === 'Enter') {
        e.preventDefault();
        e.target.blur();
        if (OV_POP && OV_POP.stale) ovPopRender(true);   // вийшли з поля клавішею — показати відкладене
        return;
    }
    const ns = e.target.closest('[data-ovm-newsec]');
    if (!ns || (e.key !== 'Enter' && e.key !== 'Escape')) return;
    e.preventDefault();
    // ІНШІ слухачі на document теж не мусять його бачити: інакше Esc тут
    // заодно завершував роботу над плиткою «Огляду» (і прибирав щойно
    // заведену порожню панель) — stopPropagation сусідів на тому ж вузлі не спиняє
    e.stopImmediatePropagation();
    const t = ovSetTile(ns);
    const v = e.key === 'Enter' ? ns.value.trim() : '';
    ns.dataset.done = '1';
    if (v && t) ovSetSection(t, v);
    else { OV_NEWSEC_ID = ''; ovRender(); ovPopRender(); }
}
/* пішли з поля нового розділу, так і не натиснувши Enter: набране —
   ставимо, порожнє — повертаємо список розділів */
function ovSetOnBlur(e) {
    const ns = e.target.closest && e.target.closest('[data-ovm-newsec]');
    if (!ns || ns.dataset.done === '1') return;
    ns.dataset.done = '1';
    const t = ovSetTile(ns);
    const v = ns.value.trim();
    // ставимо ПІСЛЯ кліку, яким із поля вийшли: перемальовка між натисканням і
    // відпусканням миші прибрала б кнопку з-під неї (клік по «А» чи кольору
    // губився б); без миші (Tab) — за мить
    let done = false;
    const commit = () => {
        if (done) return;
        done = true;
        if (!OV_NEWSEC_ID) return;
        if (v && t) ovSetSection(t, v);
        else { OV_NEWSEC_ID = ''; ovRender(); ovPopRender(); }
    };
    document.addEventListener('pointerup', () => setTimeout(commit, 0), { once: true, capture: true });
    setTimeout(commit, 400);
}
/* ═══ НАЛАШТУВАННЯ ПАНЕЛІ — СПЛИВАЮЧЕ ВІКНО БІЛЯ НЕЇ ═══
   Роман 2026-09-27 (скрін смуги ⚙ «Панель» у «Роботі зі стадом»): «треба
   прибрати цю панель налаштування і зробити налаштування кольорів в самій
   панелі вспливаючим вікном». Смуги ⚙ для панелей більше немає (для списків
   лишилась): ✎ на панелі в бічному переліку, а в «Роботі зі стадом» і ⚙
   відкритої панелі, відкривають маленьке вікно просто біля неї — назва,
   розділ, кольори, розмір, число й «Прибрати панель». Зміни — одразу, без
   «Зберегти». Сховані показники плитки на «Огляді» не мають — їх
   налаштовують саме тут. */
let OV_POP = null;          // { id, r } — чия панель і біля чого стоїть вікно
function ovPopBox() {
    let b = $('ovPop');
    if (!b) {
        b = document.createElement('div');
        b.id = 'ovPop';
        b.className = 'ov-pop';
        b.hidden = true;
        document.body.appendChild(b);
    }
    return b;
}
function ovPopOpen(id, anchor) {
    const t = OV.find((x) => String(x.id) === String(id));
    if (!t) return;
    awCfgClose();                           // смуга списку й вікно панелі разом не стоять
    OV_NEWSEC_ID = '';
    // звідки відкрили — щоб щоразу знаходити ЖИВИЙ рядок переліку: після правок
    // перелік перемальовується й переставляється, а вікно має лишатись біля панелі
    const rail = anchor && anchor.closest ? anchor.closest('#awRail, #ovRail') : null;
    OV_POP = { id: String(t.id), sel: rail ? `#${rail.id} .awr-t[data-ov="${CSS.escape(String(t.id))}"]`
        : (anchor && anchor.id ? `#${CSS.escape(anchor.id)}` : ''), r: ovPopRect(anchor) };
    ovPopRender();
}
function ovPopClose() {
    if (!OV_POP) return;
    if (OV_NEWSEC_ID === OV_POP.id) OV_NEWSEC_ID = '';
    OV_POP = null;
    ovPopBox().hidden = true;
    if (OV_PAL_TILE && !OVM_EDIT) { OV_PAL_TILE = ''; if ($('ovPal')) $('ovPal').hidden = true; }
}
/* `soft` — перемальовка з відповіді сервера: поки людина стоїть у полі
   вікна (набирає назву, новий розділ, розгорнула список), вікно НЕ чіпаємо —
   інакше набране зникало б на півслові; перемалюємо, щойно вона з вікна вийде */
function ovPopRender(soft) {
    if (!OV_POP) return;
    const t = OV.find((x) => String(x.id) === OV_POP.id);
    if (!t) { ovPopClose(); return; }
    const box = ovPopBox();
    const ae = document.activeElement;
    if (soft && ae && box.contains(ae) && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)) {
        OV_POP.stale = true;
        return;
    }
    OV_POP.stale = false;
    box.innerHTML = '<div class="ov-pop-h">'
        + `<b title="${escapeHtml(t.name)}">${escapeHtml(t.name)}</b>`
        + '<button type="button" class="ov-pop-x" data-pop-x title="Закрити (Esc)">✕</button></div>'
        + ovSetRows(t, { name: true, fmt: !ovmPicksOf(t) })
        + '<div class="ov-pop-f"><button type="button" class="ov-pop-del" data-pop-del'
        + ' title="Прибрати цю панель зовсім">🗑 Прибрати панель</button></div>';
    box.hidden = false;
    ovPopPlace();
    requestAnimationFrame(ovPopPlace);      // перелік перемальовується слідом — стати біля нового
}
// місце — у координатах сторінки: вікно гортається разом із нею
function ovPopRect(el) {
    if (!el || !el.getBoundingClientRect || !el.offsetParent) return null;
    const r = el.getBoundingClientRect();
    return { l: r.left + window.scrollX, t: r.top + window.scrollY,
        rt: r.right + window.scrollX, b: r.bottom + window.scrollY };
}
/* ПОРЯД ІЗ ПАНЕЛЛЮ (Роман 2026-09-27: «спливаюче вікно повинно бути таке
   невеличке і поряд із показником»): праворуч від неї, не влазить — ліворуч
   (перелік стоїть справа, тож там і вийде ліворуч), не влазить ніде — під
   нею. По висоті — урівень із панеллю, не виходячи за край вікна. */
function ovPopPlace() {
    if (!OV_POP) return;
    const box = ovPopBox();
    const live = OV_POP.sel ? ovPopRect(document.querySelector(OV_POP.sel)) : null;
    if (live) OV_POP.r = live;              // рядка не видно — лишаємось, де стояли
    const r = OV_POP.r;
    const sx = window.scrollX, sy = window.scrollY;
    const vw = document.documentElement.clientWidth, vh = window.innerHeight;
    const w = box.offsetWidth, h = box.offsetHeight;
    const gap = 8;
    let left, top;
    if (!r) { left = sx + (vw - w) / 2; top = sy + 80; }
    else if (r.rt + gap + w <= sx + vw - 8) { left = r.rt + gap; top = r.t; }
    else if (r.l - gap - w >= sx + 8) { left = r.l - gap - w; top = r.t; }
    else { left = r.l; top = r.b + 6; }
    left = Math.max(sx + 8, Math.min(left, sx + vw - w - 8));
    top = Math.max(sy + 8, Math.min(top, sy + vh - h - 8));
    box.style.left = `${Math.round(left)}px`;
    box.style.top = `${Math.round(top)}px`;
}
async function ovPopDelete() {
    const t = OV_POP ? OV.find((x) => String(x.id) === OV_POP.id) : null;
    // вікно закриваємо ДО перепиту: воно стоїть вище за перепит, і другий
    // клік по «Прибрати» відкривав би ДРУГИЙ перепит — після «Скасувати» панель
    // тоді прибирав будь-який наступний Enter на сторінці
    ovPopClose();
    if (!t) return;
    if (!await confirmAction(`Прибрати панель «${t.name}»?${refDepsText(t.name, t)}`,
        { ok: 'Прибрати', okClass: 'btn-danger' })) return;
    const id = t.id;
    if (String(OVM_EDIT) === String(id)) ovmStop(true);
    OV = OV.filter((x) => x !== t);
    if (OV_CUR && String(OV_CUR.id) === String(id)) { OV_CUR = null; awCurShow(); }
    ovRender();
    railRender();
    if (await ovOp({ op: 'del', id })) toast('Панель прибрано', 'success');
}
document.addEventListener('click', (e) => {
    const pop = e.target.closest('#ovPop');
    if (pop) {
        if (e.target.closest('[data-pop-x]')) { ovPopClose(); return; }
        if (e.target.closest('[data-pop-del]')) { ovPopDelete(); return; }
        ovSetOnClick(e);
        // відкладене — наступним кроком: клік по підпису «1 000» ще має
        // клацнути саму галочку, і перемальовка зараз забрала б її з-під нього
        if (OV_POP && OV_POP.stale) setTimeout(() => ovPopRender(true), 0);
        return;
    }
    // клік поза вікном закриває його (палітра, перепит і самі кнопки ✎ / ⚙ — ні)
    if (OV_POP && !e.target.closest('#ovPal, .modal, [data-ed], #awCfgBtn')) ovPopClose();
});
document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('#ovPop')) ovSetOnChange(e); });
document.addEventListener('keydown', (e) => { if (e.target.closest && e.target.closest('#ovPop')) ovSetOnKey(e); });
/* відкладену перемальовку робимо, коли людина з поля вийшла: клавіатурою —
   одразу, мишею — ПІСЛЯ кліку (див. вище): перемалювати посеред кліку означало б
   прибрати кнопку з-під миші, і Safari клік просто губив би */
document.addEventListener('focusout', (e) => {
    if (!(e.target.closest && e.target.closest('#ovPop'))) return;
    ovSetOnBlur(e);
    const to = e.relatedTarget;
    if (OV_POP && OV_POP.stale && to && !(to.closest && to.closest('#ovPop'))) setTimeout(() => ovPopRender(true), 0);
});
window.addEventListener('resize', () => { if (OV_POP) ovPopPlace(); });
/* Esc закриває вікно ПЕРШИМ (перехоплюємо ще до інших обробників Esc, щоб
   не завершилась заодно й робота над плиткою); у полі нового розділу Esc —
   лише відмова від поля */
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !OV_POP) return;
    if (e.target.closest && e.target.closest('#ovPop [data-ovm-newsec]')) return;
    if (document.querySelector('.modal:not([hidden])')) return;
    if ($('ovPal') && !$('ovPal').hidden) { $('ovPal').hidden = true; e.stopPropagation(); return; }
    e.stopPropagation();
    ovPopClose();
}, true);

/* Escape завершує роботу, ДЕ Б НЕ БУВ фокус: доти він слухав лише сітку
   плиток, а після кліку в переліку фокус уже був не там (Н14) */
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !OVM_EDIT || TAB !== 'reg') return;
    if (document.querySelector('.modal:not([hidden])')) return;   // спершу закривається вікно
    if (e.target.closest && e.target.closest('#ovPop')) return;   // Esc у вікні — про вікно
    ovmStop();
});

bind('awCfgBtn', 'click', awCfgOpen);
bind('awCfgOk', 'click', awCfgDo);
bind('awCfgCancel', 'click', awCfgClose);
bind('awCfgBox', 'keydown', (e) => {
    if (e.key === 'Escape') awCfgClose();
    // Enter на іншій кнопці коробки (напр. «📅 У календар») — її власна дія,
    // а не збереження ⚙
    if (e.key === 'Enter' && !(e.target.tagName === 'BUTTON' && e.target.id !== 'awCfgOk')) {
        e.preventDefault(); awCfgDo();
    }
});
bind('awSaveOk', 'click', awSaveDo);
bind('awSaveCancel', 'click', () => { $('awSaveBox').hidden = true; });
bind('awSaveName', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('awSaveNote', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
});

/* добір у «Списках» */
bind('wlSearch', 'input', wlRender);
bind('wlCat', 'change', wlRender);
bind('wlCatsBtn', 'click', (e) => wcOpen(e.currentTarget));

/* дії над збереженими списками */
bind('animLists', 'click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const row = b.closest('.wl-row');
    const L = WLISTS.find((x) => String(x.id) === String(row.dataset.id));
    if (!L) return;
    if (b.dataset.act === 'open') { wlOpen(L); return; }
    /* СКОПІЮВАТИ ФОРМУЛУ в буфер (Роман 2026-09-22) — щоб укинути її в інший
       список, у листа чи просто поруч поправити. Береться рядок як є, разом
       із «=», тож вставляється просто в рядок «Роботи зі стадом». */
    if (b.dataset.act === 'fcopy') {
        const fx = awNoEq(L.formula || '');          // без «=» — як у рядку формули
        try {
            await navigator.clipboard.writeText(fx);
            toast('Формулу скопійовано', 'success');
        } catch (e) {
            // ферма відкривається і по http у мережі — там clipboard недоступний
            try {
                const ta = document.createElement('textarea');
                ta.value = fx; ta.style.position = 'fixed'; ta.style.opacity = '0';
                document.body.appendChild(ta); ta.select();
                document.execCommand('copy'); ta.remove();
                toast('Формулу скопійовано', 'success');
            } catch (e2) { toast('Не вдалося скопіювати', 'error'); }
        }
        return;
    }
    /* КОПІЯ СПИСКУ (Роман 2026-09-22). Робочий список зазвичай правлять «від
       наявного»: узяти готовий, трохи змінити добір — і це вже інший список.
       Копія лягає ОДРАЗУ під оригіналом і в ту саму категорію, тож шукати її
       не треба; назва «… (копія)», щоб не плутати з першим. */
    if (b.dataset.act === 'cal') { wlToCal(L); return; }
    if (b.dataset.act === 'copy') {
        const base = L.name.replace(/\s*\(копія(?:\s+\d+)?\)$/, '');
        let name = base + ' (копія)';
        for (let n = 2; refTaken(name, 'list', null); n++) name = `${base} (копія ${n})`;
        const copy = Object.assign({}, L, { id: newId('w', WLISTS), name });
        WLISTS.splice(WLISTS.indexOf(L) + 1, 0, copy);
        if (await wlSave()) toast(`Створено «${name}»`, 'success');
        return;
    }
    if (b.dataset.act === 'rename') {
        const span = row.querySelector('.wl-name');
        if (row.querySelector('input')) return;
        const inp = document.createElement('input');
        inp.className = 'aw-namein';
        inp.value = L.name;
        inp.maxLength = 80;
        span.replaceWith(inp);
        inp.focus();
        inp.select();
        // ⚠️ перейменування — тим самим шляхом, що й скрізь: разом із
        // посиланнями на цей список у панелях (доти тут мінялась лише назва,
        // і «[Стара назва]» у складених панелях ламалось). Enter і blur
        // обидва кличуть done — другий виклик нічого не робить.
        let fired = false;
        const done = async (save) => {
            if (fired) return;
            fired = true;
            const v = inp.value.trim();
            if (save && v && v !== L.name) {
                if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); wlRender(); return; }
                const cur = WLISTS.find((x) => String(x.id) === String(L.id));
                if (cur) await reportRename('list', cur, v);
            }
            wlRender();
        };
        inp.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') done(true);
            if (ev.key === 'Escape') done(false);
        });
        inp.addEventListener('blur', () => done(true));
        return;
    }
    if (b.dataset.act === 'del') {
        const ok = await confirmAction(`Видалити список «${L.name}»?${refDepsText(L.name, L)}`,
            { ok: 'Видалити', okClass: 'btn-danger' });
        if (!ok) return;
        if (WCUR && WCUR.id === L.id) wlSetCur(null);
        WLISTS = WLISTS.filter((x) => x !== L);
        await wlSave();
    }
});

/* вибрані тварини → «Груповий ввід». Сторінка вже вміє приймати ?ids= —
   тим самим шляхом туди веде календар, тож нічого нового на сервері. */
bind('awEvent', 'click', () => {
    // передаємо САМУ ФОРМУЛУ, а не перелік номерів: у груповому вводі
    // список лишається живим і не залежить від довжини адреси
    const txt = $('awInput').value;
    if (!txt.trim() || !LAST_ITEMS.length) return;
    // ⚠️ посилання «[Назва]» туди передавати НЕ МОЖНА: груповий ввід читає
    // формулу своїм розбором, збережених звітів він не знає — і НЕ зрозумівши
    // формулу, мовчки відмітив би ВСЕ СТАДО. Тому підставляємо саму формулу
    // звіту (у частці — її чисельник: саме його тварин показує таблиця)
    // таблиця показує тварин ПЕРШОГО показника — їх і передаємо (Н13): доти
    // туди йшов увесь рядок складеної панелі, і груповий ввід не розумів нічого
    const fx = tableFx(txt);
    if (fx.error) { toast(fx.error, 'error'); return; }
    location.href = '/herd/group?f=' + encodeURIComponent(awWithEq(fx.sides[0]));
});

/* рядок формули: підсвітка, підказки, Enter */
bind('awInput', 'input', () => { awPaint(); awSuggest(); });   // підказка вискакує сама
bind('awInput', 'scroll', () => { $('awHl').scrollLeft = $('awInput').scrollLeft; });
bind('awInput', 'keyup', awPaint);
bind('awInput', 'click', awSuggest);
bind('awInput', 'focus', awSuggest);
bind('awInput', 'blur', () => setTimeout(() => { $('awSug').hidden = true; }, 150));
bind('awInput', 'keydown', (e) => {
    const open = AW_SUG.length && !$('awSug').hidden;
    if (open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        AW_POS = (AW_POS + (e.key === 'ArrowDown' ? 1 : AW_SUG.length - 1)) % AW_SUG.length;
        AW_NAV = true;                               // обрали стрілками — Enter вставляє
        awDrawSug();
        const on = $('awSug').querySelector('.on');
        if (on) on.scrollIntoView({ block: 'nearest' });
        return;
    }
    if (e.key === 'Enter' && open && AW_NAV) { e.preventDefault(); awTake(AW_POS); return; }
    // Tab — підтвердити вибір із підказки
    if (e.key === 'Tab' && open) { e.preventDefault(); awTake(AW_POS); return; }
    if (e.key === 'Escape') { $('awSug').hidden = true; AW_SUG = []; return; }
    // Enter — прочитати список за формулою; відкритий список чи панель
    // заразом ЗБЕРІГАЄТЬСЯ (Роман 2026-09-24: «натискаєш Enter — і воно
    // автоматом зберігається»)
    if (e.key === 'Enter') {
        e.preventDefault();
        $('awSug').hidden = true; AW_SUG = [];
        runFormula();
        awAutoSave();
    }
});

/* Enter зберігає ВІДКРИТЕ (список або панель «Огляду») — лише коли формула
   правильна (з помилкою нічого не перепишемо) і справді змінилась (інакше
   кожен Enter смикав би сервер і показував «збережено» даремно). Нове, ще
   не збережене, Enter не чіпає: там треба назва — це 💾. */
let AW_AUTOSAVING = false;
async function awAutoSave() {
    if (AW_AUTOSAVING || (!WCUR && !OV_CUR)) return;
    const txt = $('awInput').value.trim();
    if (!txt || $('awMsg').classList.contains('bad')) return;
    // порівнюємо зі свіжим списком: свіже читання могло й відвʼязати
    if (WCUR && (!await wlEnsure() || !WCUR)) return;
    const cur = WCUR ? WLISTS.find((x) => String(x.id) === String(WCUR.id))
        : OV.find((x) => String(x.id) === String(OV_CUR.id));
    if (!cur) {
        // відкритий звіт тим часом прибрали — кажемо вголос, а не мовчимо
        toast((WCUR ? 'Відкритого списку' : 'Відкритої панелі') + ' вже немає — «+» збереже формулу новим', 'error');
        if (WCUR) wlSetCur(null); else { OV_CUR = null; awCurShow(); }
        return;
    }
    const norm = (f) => awWithEq(String(f || '')).replace(/\s+/g, ' ').trim();
    if (norm(cur.formula) === norm(txt)) return;
    AW_AUTOSAVING = true;
    try { await awSaveClick(); } finally { AW_AUTOSAVING = false; }
}
window.addEventListener('scroll', awPlaceSug, true);
window.addEventListener('resize', awPlaceSug);
/* «+» — НОВИЙ ПОРОЖНІЙ СПИСОК (Роман 2026-09-30: «при натисканні на плюс повинен з'явитися
   новий пустий список, категорія «Інше», строка формул пуста; після цього — набивання списку
   в строці формул»). Список одразу на сервері й відкритий, рядок формули чистий — Enter
   запише набране саме в нього (awAutoSave). Назву міняють у ⚙ або у вкладці «Списки». */
let AW_NEWING = false;
async function awNewList() {
    if (AW_NEWING) return;
    AW_NEWING = true;
    try {
        const el = $('awInput');
        if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
        // відкритий уже порожній новий — другого не плодимо, просто пишемо в нього
        const open = WCUR && WLISTS.find((x) => String(x.id) === String(WCUR.id));
        if (open && !awNoEq(open.formula || '').trim()) {
            el.value = ''; runFormula(); el.focus(); awSuggest();
            return;
        }
        let name = 'Новий список', i = 1;
        while (refTaken(name, 'list', null)) name = `Новий список ${++i}`;
        const L = { id: newId('w', WLISTS), name, formula: '', category: WCATS.includes('Інше') ? 'Інше' : '', note: '' };
        WLISTS.push(L);
        if (!await wlSave()) {
            WLISTS = WLISTS.filter((x) => x !== L);
            return;
        }
        el.value = '';
        try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
        OV_CUR = null;
        if ($('awSaveBox')) $('awSaveBox').hidden = true;
        wlSetCur(WLISTS.find((x) => String(x.id) === String(L.id)) || null);
        awPaint();
        runFormula();
        el.focus();
        awSuggest();
        toast(`«${name}» — наберіть формулу й натисніть Enter`, 'success');
    } finally { AW_NEWING = false; }
}
bind('awNew', 'click', awNewList);
/* Те саме для ПАНЕЛЕЙ (Роман 2026-09-30: «той самий алгоритм додавання, видалення зроби і в
   списку панелей»): «+» — порожня «Нова панель» (без розділу), відкрита, рядок чистий, Enter
   пише формулу в неї; ✕ на плитці — видалити з перепитом. */
async function awNewPanel() {
    if (AW_NEWING) return;
    AW_NEWING = true;
    try {
        const el = $('awInput');
        if (!await ovEnsureFresh()) { toast('Панелі не прочитались з сервера — спробуйте ще раз', 'error'); return; }
        const open = OV_CUR && OV.find((x) => String(x.id) === String(OV_CUR.id));
        if (open && !awNoEq(open.formula || '').trim()) {
            el.value = ''; runFormula(); el.focus(); awSuggest();
            return;
        }
        let name = 'Нова панель';
        for (let i = 2; refTaken(name, 'tile', null); i++) name = `Нова панель ${i}`;
        const t = { id: newId('o', OV), name, formula: '', section: '', show: '' };
        OV.push(t);
        const r = await ovOp({ op: 'add', tile: t });
        if (!r) { OV = OV.filter((x) => x !== t); railRender(); return; }
        const id = String(r.id || t.id);
        el.value = '';
        try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
        if ($('awSaveBox')) $('awSaveBox').hidden = true;
        wlSetCur(null);
        OV_CUR = OV.find((x) => String(x.id) === id) || t;
        awCurShow();
        railRender();
        awPaint();
        runFormula();
        el.focus();
        awSuggest();
        toast(`«${name}» — наберіть формулу й натисніть Enter`, 'success');
    } finally { AW_NEWING = false; }
}
async function awDelPanel(id) {
    if (AW_DELING) return;
    AW_DELING = true;
    try {
        if (!await ovEnsureFresh()) { toast('Панелі не прочитались з сервера — спробуйте ще раз', 'error'); return; }
        const t = OV.find((x) => String(x.id) === String(id));
        if (!t) { toast('Цієї панелі вже немає', 'error'); return; }
        if (!await confirmAction(`Видалити панель «${t.name}»?${refDepsText(t.name, t)}`,
            { ok: 'Видалити', okClass: 'btn-danger' })) return;
        if (String(OVM_EDIT) === String(t.id)) ovmStop(true);
        if (OV_POP && OV_POP.id === String(t.id)) ovPopClose();
        const wasOpen = OV_CUR && String(OV_CUR.id) === String(t.id);
        OV = OV.filter((x) => x !== t);
        if (wasOpen) {
            OV_CUR = null;
            awCurShow();
            const el = $('awInput');
            el.value = '';
            try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
            awPaint();
            runFormula();
        }
        ovRender();
        railRender();
        if (await ovOp({ op: 'del', id: t.id })) toast(`Панель «${t.name}» видалено`, 'success');
    } finally { AW_DELING = false; }
}
/* ✕ у рядку рейки — видалити список, з перепитом (Роман 2026-09-30); той самий шлях,
   що у вкладці «Списки»: у перепиті названо, хто на цей список посилається */
let AW_DELING = false;
async function awDelList(id) {
    if (AW_DELING) return;
    AW_DELING = true;
    try {
        if (!await wlEnsure()) { toast('Списки не прочитались з сервера — спробуйте ще раз', 'error'); return; }
        const L = WLISTS.find((x) => String(x.id) === String(id));
        if (!L) { toast('Цього списку вже немає', 'error'); return; }
        const ok = await confirmAction(`Видалити список «${L.name}»?${refDepsText(L.name, L)}`,
            { ok: 'Видалити', okClass: 'btn-danger' });
        if (!ok) return;
        const wasOpen = WCUR && String(WCUR.id) === String(L.id);
        const keep = WLISTS;
        WLISTS = WLISTS.filter((x) => x !== L);
        if (!await wlSave()) { WLISTS = keep; railRender(); return; }
        if (wasOpen) {
            wlSetCur(null);
            const el = $('awInput');
            el.value = '';
            try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
            awPaint();
            runFormula();
        }
        railRender();
        toast(`Список «${L.name}» видалено`, 'success');
    } finally { AW_DELING = false; }
}
/* ✕ — очистити рядок і ВІДВʼЯЗАТИСЯ від відкритого списку: Enter тепер
   зберігає відкрите, тож без відвʼязки нова формула в чистому рядку
   переписала б старий список (доти це робив «+»). */
bind('awClear', 'click', () => {
    const el = $('awInput');
    el.value = '';
    try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
    OV_CUR = null;
    wlSetCur(null);                                // смужка «відкрито…» гасне
    if ($('awSaveBox')) $('awSaveBox').hidden = true;
    awCfgClose();
    awPaint();
    runFormula();                                  // таблиця ховається, рядок чистий
    el.focus();
    awSuggest();
});
bind('awSug', 'mousedown', (e) => {
    const d = e.target.closest('[data-i]');
    if (d) { e.preventDefault(); awTake(+d.dataset.i); }
});
bind('awHelpBtn', 'click', () => {
    const on = $('awHelp').hidden;          // одна кнопка на дві коробки:
    $('awHelp').hidden = !on;               // «як писати» + перелік параметрів
    $('awWords').hidden = !on;
});
// друк і вивантаження — лише коли є таблиця, тобто формула з BODY(…)
const needBody = (fn) => () => {
    if (Q && !Q.cols.length) { toast('Додайте у формулу BODY(…) — які колонки вивести', 'error'); return; }
    fn();
};
bind('awCsv', 'click', needBody(awCsv));
bind('awXlsx', 'click', needBody(awXlsx));
bind('awPrint', 'click', needBody(awPrint));
bind('awWords', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awInsert(b.dataset.w);
});

// підказка живе в <body>: у панелі є transform, а він ловить position:fixed
if ($('awSug')) document.body.appendChild($('awSug'));

restoreFilters();
try { $('awInput').value = awNoEq(localStorage.getItem(AW_KEY) || ''); } catch (e) { /* ignore */ }
awPaint();
// на старті — лише перелік параметрів; дані читає сама вкладка («Огляд» —
// легкий добір для панелей, «Робота» — за формулою). Раніше тут щоразу
// тягнувся весь список стада (1,3 МБ), навіть коли видно лише «Огляд».
function awBoxesFill() {
    $('awHelp').innerHTML = awHelpHtml();
    // приклади в довідці — тими самими кольорами, що в рядку
    $('awHelp').querySelectorAll('code').forEach((c) => {
        c.classList.add('wl-f');
        c.innerHTML = awHlHtml(c.textContent);
    });
    $('awWords').innerHTML = awWordsHtml();
}
function awBoot() {
    awBoxesFill();
    // перехід на «Головну» — завжди «Огляд» (Роман 2026-09-19); оновлення
    // чи «назад» лишають вкладку, на якій людина була в цьому візиті
    let t = 'reg', nav = 'navigate';
    try { nav = (performance.getEntriesByType('navigation')[0] || {}).type || 'navigate'; } catch (e) { /* ignore */ }
    if (nav === 'reload' || nav === 'back_forward') {
        try { t = sessionStorage.getItem('herd:anim_tab') || 'reg'; } catch (e) { t = 'reg'; }
    }
    // давнє посилання «+ Додати тварину» (Конструктор) — одразу на заведення
    if (/[?&]add=1/.test(location.search)) {
        history.replaceState(null, '', location.pathname);   // оновлення не повторює
        t = 'add';
    }
    // посилання з формулою (напр. зі сторінки «Перевірка») — одразу ці тварини
    const fq = new URLSearchParams(location.search).get('f');
    if (fq) {
        $('awInput').value = awNoEq(fq);
        try { localStorage.setItem(AW_KEY, fq); } catch (e) { /* ignore */ }
        history.replaceState(null, '', location.pathname);   // оновлення не повторює
        t = 'work';
        awPaint();
        // за посиланням прийшли з ЧУЖОЮ формулою — старої привʼязки не повертаємо
        try { localStorage.removeItem(AW_CUR_KEY); } catch (e) { /* ignore */ }
    }
    setTab(t);                      // «Огляд» теж має свою розкладку (панелі)
    awCurRestore().then(() => { railRender(); awScrollRestore(nav); });
}


/* Де людина була на сторінці — теж переживає оновлення. Дані приходять
   частинами, тож браузер сам прокрутку не повертає (сторінка ще коротка):
   тримаємо свою і доганяємо, доки таблиця не домалюється. */
try { history.scrollRestoration = 'manual'; } catch (e) { /* ignore */ }
const AW_SCROLL_KEY = 'herd:anim_scroll';
// прокручується або сам перелік, або вся рейка — беремо ту, що справді має скрол
const awRailScroller = () => {
    const a = $('awRailList'), b = $('awRail');
    return (a && a.scrollHeight > a.clientHeight + 1) ? a : b;
};
window.addEventListener('pagehide', () => {
    const rail = awRailScroller();
    try {
        sessionStorage.setItem(AW_SCROLL_KEY, JSON.stringify({
            y: window.scrollY, tab: TAB, rail: rail ? rail.scrollTop : 0 }));
    } catch (e) { /* ignore */ }
});
function awScrollRestore(nav) {
    if (nav !== 'reload' && nav !== 'back_forward') return;
    let v = null;
    try { v = JSON.parse(sessionStorage.getItem(AW_SCROLL_KEY) || 'null'); } catch (e) { v = null; }
    if (!v || v.tab !== TAB) return;
    const t0 = Date.now();
    const step = () => {
        const rail = awRailScroller();
        if (rail && v.rail) rail.scrollTop = v.rail;
        const room = document.documentElement.scrollHeight - window.innerHeight;
        if (room >= v.y - 2) { window.scrollTo(0, v.y); return; }
        if (Date.now() - t0 < 4000) setTimeout(step, 120);   // таблиця ще дочитується
        else window.scrollTo(0, v.y);
    };
    step();
}

// «⚙ Колонки» прибрано з «Огляду» в 2.40.40 (колонки задає BODY формули);
// мертвий виклик herdColPicker на неіснуючу кнопку прибрано в 2.40.49 —
// його знайшла перевірка tests/check_page_js.py

/* Перемикач «Живі · Вибулі · Усі» у смужці гілки має рухати й саму таблицю:
   інакше вгорі написано одне, а в списку інше (Роман 2026-09-16 просив
   перевірити перемикач на всіх сторінках стада). */
window.herdRegistry = {
    reload() {
        let f = null;
        try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
        if (!f) return;
        $('animSearch').value = f.q || '';
        $('animStatus').value = f.status || '';
        $('animSex').value = f.sex || '';
        $('animGroup').value = f.group_id || '';
        return loadList();
    },
};

/* ---------- старт сторінки ----------
   Стоїть у самому КІНЦІ файлу: сторінка тепер стартує одразу (з памʼяті), а
   не після мережевого запиту, тож усе, що оголошено вище, має бути вже
   готове — інакше перший же виклик натрапив би на ще не оголошену змінну. */
// Є памʼять із минулого заходу — малюємо одразу, свіже читаємо слідом і
// перемальовуємо, лише якщо щось справді змінилось. Немає — як доти.
const WL_WARM = wlFromMemory();
ovFromMemory();                       // панелі з памʼяті — до першого читання стада
if (bootFromMemory()) {
    awBoot();
    loadColumns().then((changed) => {
        if (!changed) return;
        awBoxesFill();
        if (TAB === 'work') { runFormula(); railCounts(); }
        else if (TAB === 'reg') ovLoad();
    });
} else {
    loadColumns().then(awBoot);
}
// перелік списків — завжди свіжий один раз за захід (з памʼяті він лише для
// миттєвої рейки; інакше новий список з іншого компʼютера сюди б не дійшов)
if (WL_WARM) wlLoad().then(() => { railRender(); if (TAB === 'work') railCounts(); });

/* Рядок формули під смужкою пошуку (2026-09-30) тримається вгорі під час прокрутки — як на «Русі поголівʼя»:
   на телефоні шапка застосунку липка, тож стаємо ПІД неї; прилип — легка тінь знизу. */
(function () {
    const bar = document.getElementById('awFxTop');
    const topbar = document.querySelector('.topbar');
    if (!bar) return;
    let TOP = null, IO = null;
    const barTop = () => (topbar && getComputedStyle(topbar).position === 'sticky' ? topbar.offsetHeight : 0);
    function place() {
        const t = barTop();
        if (t === TOP) return;
        TOP = t;
        bar.style.top = (t - 1) + 'px';
        if (!window.IntersectionObserver) return;
        if (IO) IO.disconnect();
        IO = new IntersectionObserver(([en]) => { bar.classList.toggle('is-stuck', en.intersectionRatio < 1); },
            { threshold: [1], rootMargin: `${-t}px 0px 0px 0px` });
        IO.observe(bar);
    }
    place();
    window.addEventListener('resize', place);
    if (window.ResizeObserver && topbar) new ResizeObserver(place).observe(topbar);
}());
