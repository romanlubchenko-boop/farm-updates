/* Налаштування типів подій (які параметри змінюють). */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const $ = (id) => document.getElementById(id);
let EVENTS = [], PARAMS = [], CATS = {}, MODES = {};
let editing = null;

const ARG_MODES = new Set(['const', 'inc']);   // авто-режими зі звичайним полем значення
const MODE_SYM = { const: '=', event_date: '← дата події', inc: '+', clear: '→ очистити',
    when: 'якщо' };

async function load() {
    const r = await apiGet('/api/herd/events');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    EVENTS = r.events || [];
    PARAMS = (r.params || []).filter((p) => !(p.formula || '').trim())   // обчислювані не міняємо
        .sort((a, b) => (a.label || '').localeCompare(b.label || '', 'uk'));   // за алфавітом
    fillParamDatalist();
    CATS = r.categories || {};
    MODES = r.modes || {};
    render();
}

/* ---------- список ---------- */
// підпис значення за кодом параметра (напр. репрокод 0 → «Телиця»)
function codeLabel(paramKey, val) {
    const p = paramByKey(paramKey);
    const ch = (p && p.choices) || [];
    const c = ch.find((x) => String(x.value) === String(val));
    return c ? c.label : (val || '—');
}
function effSummary(ev) {
    return (ev.effects || []).map((e) => {
        if (e.mode === 'input') {
            return `${e.param_label} ❓ питати` + (e.arg ? ` (за замовч. ${e.arg})` : '');
        }
        if (e.mode === 'when') {
            const s = parseWhenSpec(e.arg);
            const parts = s.rules.filter((r) => r.if).map((r) => {
                const ifp = paramByKey(r.if);
                return `${(ifp && ifp.label) || r.if}=${codeLabel(r.if, r.eq)}→${codeLabel(e.param_key, r.val)}`;
            });
            if (s.default) parts.push(`інакше→${codeLabel(e.param_key, s.default)}`);
            return `${e.param_label}: ${parts.join('; ')}`;
        }
        const sym = MODE_SYM[e.mode] || e.mode;
        if (e.mode === 'const' || e.mode === 'inc') return `${e.param_label} ${sym}${e.arg}`;
        return `${e.param_label} ${sym}`;
    }).join(' · ');
}

function render() {
    $('evCount').textContent = EVENTS.length ? `· ${EVENTS.length}` : '';
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    let html = '', seq = 0;
    order.forEach((cat) => {
        const list = bySec[cat];
        if (!list || !list.length) return;
        html += `<tr class="ev-sec"><td colspan="7">${escapeHtml(CATS[cat] || cat)} · ${list.length}</td></tr>`;
        list.forEach((e) => {
            const idx = EVENTS.indexOf(e); seq += 1;
            html += `<tr class="ev-row ${e.is_active ? '' : 'off'}" data-id="${e.id}">
                <td class="ev-c ev-num">${seq}</td>
                <td><b>${escapeHtml(e.name)}</b></td>
                <td>${escapeHtml(CATS[e.category] || e.category)}</td>
                <td class="ev-effs">${escapeHtml(effSummary(e))}</td>
                <td><span class="ev-badge ${e.is_standard ? 'std' : 'cus'}">${e.is_standard ? 'системна' : 'створена'}</span></td>
                <td class="ev-c"><input type="checkbox" data-act="toggle" ${e.is_active ? 'checked' : ''}></td>
                <td class="ev-c ev-actions">
                    <button class="ev-move" data-act="up" ${idx === 0 ? 'disabled' : ''} title="Вгору">▲</button>
                    <button class="ev-move" data-act="down" ${idx === EVENTS.length - 1 ? 'disabled' : ''} title="Вниз">▼</button>
                    <button data-act="edit" title="Редагувати">✏</button>
                    ${(!e.is_standard || window.canManage('herd')) ? '<button class="ev-del-btn" data-act="del" title="Видалити">−</button>' : ''}
                </td>
            </tr>`;
        });
    });
    $('evBody').innerHTML = html || '<tr><td colspan="7" class="empty">Немає подій</td></tr>';
    if (window.makeColumnsResizable) makeColumnsResizable('evTable', 'farm:ev_cols');
}

/* ---------- редактор ефектів ---------- */
// datalist для розумного пошуку параметра (по літерах, за алфавітом)
function fillParamDatalist() {
    const dl = $('eeParamDL'); if (!dl) return;
    dl.innerHTML = PARAMS.map((p) =>
        `<option value="${escapeHtml(p.label)}"></option>`).join('');
}
function paramByLabel(lbl) {
    const s = (lbl || '').trim();
    return PARAMS.find((p) => (p.label || '') === s);
}
function autoModeOptions(sel) {   // авто-режими (без «input» — це «Питати»)
    return Object.entries(MODES).filter(([k]) => k !== 'input').map(([k, v]) =>
        `<option value="${k}"${k === sel ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
}
function paramByKey(k) { return PARAMS.find((p) => p.key === k); }
function argControlHtml(param, val) {   // список варіантів або вільне поле
    const ch = (param && param.choices) || [];
    if (ch.length) {
        const opts = '<option value="">—</option>' + ch.map((c) =>
            `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('');
        return `<select class="ref-select ee-arg">${opts}</select>`;
    }
    return `<input type="text" class="ref-select ee-arg" placeholder="значення" value="${escapeHtml(val || '')}">`;
}
// select параметра (для умови «Якщо»)
function paramSelectHtml(sel, cls) {
    return `<select class="ref-select ${cls}"><option value="">— параметр —</option>`
        + PARAMS.map((p) => `<option value="${escapeHtml(p.key)}"${p.key === sel ? ' selected' : ''}>${escapeHtml(p.label)}</option>`).join('')
        + '</select>';
}
// поле значення параметра (select із варіантів або вільне поле)
function valControlHtml(param, val, cls) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ${cls}"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ${cls}" value="${escapeHtml(val || '')}" placeholder="значення" style="width:88px">`;
}
// arg → {rules:[{if,eq,val}], default} (сумісно зі старим одиничним форматом)
function parseWhenSpec(arg) {
    let d = {};
    try { if (arg && arg.trim().startsWith('{')) d = JSON.parse(arg); } catch (e) { d = {}; }
    if (d && Array.isArray(d.rules)) {
        return {
            rules: d.rules.map((r) => ({ if: r.if || '', eq: r.eq || '', val: r.val || '' })),
            default: d.default || '',
        };
    }
    if (d && (d.if || d.eq || d.val)) {   // старий одиничний формат
        if (!d.if) return { rules: [], default: d.val || '' };
        return { rules: [{ if: d.if, eq: d.eq || '', val: d.val || '' }], default: '' };
    }
    return { rules: [], default: '' };
}
function whenRuleLineHtml(targetParam, r) {
    const ifParam = paramByKey(r.if);
    return `<div class="ee-when-line" data-role="rule">`
        + `<span class="ee-op">якщо</span> ${paramSelectHtml(r.if, 'ee-if')} `
        + `<span class="ee-op">=</span> ${valControlHtml(ifParam, r.eq, 'ee-ifval')} `
        + `<span class="ee-op">→</span> ${valControlHtml(targetParam, r.val, 'ee-val')}`
        + `<button type="button" class="ee-line-del" title="Прибрати умову">✕</button></div>`;
}
function whenDefaultLineHtml(targetParam, val) {
    return `<div class="ee-when-line ee-when-def" data-role="default">`
        + `<span class="ee-op">інакше</span> <span class="ee-op">→</span> `
        + `${valControlHtml(targetParam, val, 'ee-val')}</div>`;
}
// віджет: багато правил «якщо…→…» під одним параметром + рядок «інакше»
function whenBlockHtml(targetParam, arg) {
    const spec = parseWhenSpec(arg);
    const rules = spec.rules.length ? spec.rules : [{ if: '', eq: '', val: '' }];
    const lines = rules.map((r) => whenRuleLineHtml(targetParam, r)).join('')
        + whenDefaultLineHtml(targetParam, spec.default);
    return `<div class="ee-when"><div class="ee-when-lines">${lines}</div>`
        + `<button type="button" class="ee-when-add">+ ще «якщо»</button></div>`;
}
function readWhenBlock(scope) {
    const rules = [];
    scope.querySelectorAll('.ee-when-line[data-role="rule"]').forEach((l) => {
        rules.push({
            if: (l.querySelector('.ee-if') || {}).value || '',
            eq: (l.querySelector('.ee-ifval') || {}).value || '',
            val: (l.querySelector('.ee-val') || {}).value || '',
        });
    });
    const dl = scope.querySelector('.ee-when-line[data-role="default"] .ee-val');
    return { rules, default: dl ? dl.value : '' };
}
// поле значення залежно від режиму
function argHtmlFor(param, mode, ask, val) {
    if (!ask && mode === 'when') return whenBlockHtml(param, val);
    return argControlHtml(param, val);
}
function effRow(e) {
    e = e || { param_key: '', mode: 'const', arg: '' };
    const ask = e.mode === 'input';
    const autoMode = ask ? 'const' : (e.mode || 'const');
    const div = document.createElement('div');
    div.className = 'ev-eff-row';
    const curParam = paramByKey(e.param_key);
    div.innerHTML =
        `<input type="text" class="ref-select ee-param" list="eeParamDL" placeholder="пошук параметра…"
             value="${escapeHtml(curParam ? curParam.label : '')}" autocomplete="off">
         <label class="ee-ask" title="Питати значення в оператора під час події">
             <input type="checkbox" class="ee-ask-cb" ${ask ? 'checked' : ''}> Питати</label>
         <select class="ref-select ee-mode">${autoModeOptions(autoMode)}</select>
         <span class="ee-arg-wrap"></span>
         <button type="button" class="ev-eff-del" title="Прибрати">✕</button>`;
    const askCb = div.querySelector('.ee-ask-cb');
    const modeSel = div.querySelector('.ee-mode');
    const paramSel = div.querySelector('.ee-param');
    const argWrap = div.querySelector('.ee-arg-wrap');
    const isWhenMode = () => !askCb.checked && modeSel.value === 'when';
    const sync = () => {
        const asking = askCb.checked;
        modeSel.disabled = asking;
        const argInp = div.querySelector('.ee-arg');
        if (argInp) {   // звичайне поле значення (для «Якщо» його немає)
            const showArg = asking || ARG_MODES.has(modeSel.value);
            argInp.style.visibility = showArg ? '' : 'hidden';
            if (argInp.tagName === 'INPUT') argInp.placeholder = asking ? 'за замовч. (необовʼязково)' : 'значення';
        }
    };
    const renderArg = (val) => {   // (пере)будувати поле значення за поточним режимом
        const tgt = paramByLabel(paramSel.value) || curParam;
        div.classList.toggle('has-when', isWhenMode());
        argWrap.innerHTML = argHtmlFor(tgt, askCb.checked ? 'input' : modeSel.value, askCb.checked, val);
        sync();
    };
    // при зміні цільового параметра — зберегти правила «Якщо»
    const keepWhen = () => renderArg(isWhenMode() ? JSON.stringify(readWhenBlock(argWrap)) : '');
    paramSel.addEventListener('change', keepWhen);
    paramSel.addEventListener('input', keepWhen);
    askCb.addEventListener('change', () => renderArg(''));
    modeSel.addEventListener('change', () => renderArg(''));
    // дії всередині блоку «Якщо» (делеговано; argWrap живе між перебудовами)
    argWrap.addEventListener('click', (ev) => {
        if (ev.target.closest('.ee-when-add')) {
            const s = readWhenBlock(argWrap); s.rules.push({ if: '', eq: '', val: '' });
            renderArg(JSON.stringify(s));
        } else if (ev.target.closest('.ee-line-del')) {
            const line = ev.target.closest('.ee-when-line');
            const idx = [...argWrap.querySelectorAll('.ee-when-line[data-role="rule"]')].indexOf(line);
            const s = readWhenBlock(argWrap); s.rules.splice(idx, 1);
            renderArg(JSON.stringify(s));
        }
    });
    argWrap.addEventListener('change', (ev) => {   // зміна умовного параметра → оновити його значення
        if (ev.target.classList.contains('ee-if')) renderArg(JSON.stringify(readWhenBlock(argWrap)));
    });
    div.querySelector('.ev-eff-del').addEventListener('click', () => div.remove());
    renderArg(e.arg);       // початкове наповнення зі збереженим значенням
    return div;
}

/* ---------- модал ---------- */
function openEdit(ev) {
    editing = ev;
    const isNew = !ev;
    $('eeTitle').textContent = isNew ? 'Нова подія' : ('Подія: ' + ev.name);
    $('eeName').value = isNew ? '' : ev.name;
    $('eeCat').innerHTML = Object.entries(CATS).map(([k, v]) =>
        `<option value="${k}"${(!isNew && ev.category === k) ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
    $('eeSource').value = (isNew || !ev.is_standard) ? 'cus' : 'std';
    $('eeSource').disabled = !isNew && !!ev.is_standard && !window.canManage('herd');
    $('eeActive').checked = isNew ? true : !!ev.is_active;
    $('eeShowPanel').checked = isNew ? true : (ev.show_on_panel === undefined ? true : !!ev.show_on_panel);
    // прив'язка: показувати у вікні іншої події (окрім себе)
    const attSel = ev ? (ev.attach_to || '') : '';
    $('eeAttach').innerHTML = '<option value="">— окрема подія —</option>' +
        EVENTS.filter((x) => !ev || x.id !== ev.id).map((x) =>
            `<option value="${escapeHtml(x.key)}"${x.key === attSel ? ' selected' : ''}>${escapeHtml(x.name)}</option>`).join('');
    const box = $('eeEffects'); box.innerHTML = '';
    (isNew ? [] : (ev.effects || [])).forEach((e) => box.appendChild(effRow(e)));
    if (isNew) box.appendChild(effRow(null));
    $('eeDelBtn').style.display = (isNew ? false : (!ev.is_standard || window.canManage('herd'))) ? '' : 'none';
    $('evEditModal').hidden = false;
    $('eeName').focus();
}

function collectEffects() {
    const out = [];
    document.querySelectorAll('#eeEffects .ev-eff-row').forEach((r) => {
        const p = paramByLabel(r.querySelector('.ee-param').value);
        const pk = p ? p.key : '';
        if (!pk) return;
        const asking = r.querySelector('.ee-ask-cb').checked;
        const mode = asking ? 'input' : r.querySelector('.ee-mode').value;
        let arg = '';
        if (mode === 'when') {
            const s = readWhenBlock(r.querySelector('.ee-arg-wrap'));
            const rules = s.rules.filter((x) => x.if);   // лише заповнені умови
            if (!rules.length && !s.default) return;      // порожній блок — пропускаємо
            arg = JSON.stringify({ rules, default: s.default });
        } else if (asking || ARG_MODES.has(mode)) {
            const el = r.querySelector('.ee-arg');
            arg = el ? el.value.trim() : '';
        }
        out.push({ param_key: pk, mode, arg });
    });
    return out;
}

async function saveEdit() {
    const isNew = !editing;
    const name = $('eeName').value.trim();
    if (!name) { toast('Вкажіть назву', 'warn'); $('eeName').focus(); return; }
    const payload = {
        name, category: $('eeCat').value, is_active: $('eeActive').checked,
        show_on_panel: $('eeShowPanel').checked,
        attach_to: $('eeAttach').value || '',
        is_standard: $('eeSource').value === 'std' ? 1 : 0,
        effects: collectEffects(),
    };
    const url = isNew ? '/api/herd/events' : ('/api/herd/events/' + editing.id);
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('evEditModal').hidden = true;
    toast(isNew ? 'Додано' : 'Збережено', 'success');
    load();
}

async function delEvent(ev) {
    if (!ev) return;
    if (ev.is_standard && !window.canManage('herd')) { toast('Системну подію видаляє лише адмін', 'warn'); return; }
    if (!confirm(`Видалити подію «${ev.name}»?`)) return;
    const r = await apiSend('/api/herd/events/' + ev.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    load();
}
async function delEdit() {
    if (editing) await delEvent(editing);
    $('evEditModal').hidden = true;
}
async function moveEvent(id, dir) {
    const i = EVENTS.findIndex((e) => String(e.id) === String(id));
    const j = dir === 'up' ? i - 1 : i + 1;
    if (i < 0 || j < 0 || j >= EVENTS.length) return;
    const arr = EVENTS.slice(); [arr[i], arr[j]] = [arr[j], arr[i]]; EVENTS = arr; render();
    await apiSend('/api/herd/events/reorder', 'POST', { order: arr.map((e) => e.id) });
}
async function toggleActive(id, checked) {
    const r = await apiSend('/api/herd/events/' + id, 'POST', { is_active: checked });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); load(); return; }
    // синхронізуємо памʼять, щоб модал показував той самий стан, що й рядок
    const ev = EVENTS.find((x) => String(x.id) === String(id));
    if (ev) ev.is_active = checked ? 1 : 0;
}

/* ---------- події таблиці ---------- */
$('evBody').addEventListener('click', (e) => {
    const row = e.target.closest('.ev-row'); if (!row) return;
    const id = row.dataset.id; const act = e.target.dataset.act;
    const ev = EVENTS.find((x) => String(x.id) === String(id));
    if (act === 'edit') openEdit(ev);
    else if (act === 'up' || act === 'down') moveEvent(id, act);
    else if (act === 'del') delEvent(ev);
    else if (!e.target.closest('button, input') && ev) openEdit(ev);
});
$('evBody').addEventListener('change', (e) => {
    if (e.target.dataset.act === 'toggle') toggleActive(e.target.closest('.ev-row').dataset.id, e.target.checked);
});

$('evAddBtn').addEventListener('click', () => openEdit(null));
$('eeAddEff').addEventListener('click', () => $('eeEffects').appendChild(effRow(null)));
$('eeSaveBtn').addEventListener('click', saveEdit);
$('eeDelBtn').addEventListener('click', delEdit);
document.querySelectorAll('#evEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('evEditModal').hidden = true; }));
// оновлення списку параметрів (блок «Параметри») → перезавантажити,
// щоб новий параметр одразу зʼявився у виборі ефектів
document.addEventListener('herd-params-changed', () => { if ($('evTable')) load(); });
if ($('evTable')) load();   // запускаємось лише за наявності розмітки
})();
