/* Налаштування параметрів тварин (стандартні + власні). */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const DTYPE_LABEL = {
    date: 'Дата', text: 'Текст', int: 'Ціле (int)', float: 'Дробове (float)',
    bool: 'Так/Ні', list: 'Список', cod: 'Код', ref_animal: 'Родовід',
    computed: 'Обчислюване',
    // legacy-аліаси
    number: 'Число', select: 'Список', code: 'Код',
};
// Типи ДАНИХ (обчислюваність — окремо, через «Тип обчислення»)
const ADD_DTYPES = ['int', 'float', 'text', 'date', 'bool', 'list', 'cod', 'ref_animal'];
// Опис вбудованих (стандартних) формул — для показу «як обчислюється»
const LEGACY_DESC = {
    age: 'Вік = Сьогодні − Дата народження (у місяцях)',
    days_alive: 'Сьогодні − Дата народження (днів)',
    dim: 'Днів у молоці = Сьогодні − Дата останнього отелу',
    days_preg: 'Днів тільності = Сьогодні − Дата ост. осіменіння (лише коли статус «Тільна»)',
    expected_calving: 'Очікуваний отел = Дата ост. осіменіння + 280 днів',
    service_period: 'Сервіс-період = Дата ост. осіменіння − Дата останнього отелу (днів)',
};
let FORMULA_OPS = [];     // операції для обчислюваних (date_diff, num_diff…)
let DATE_OPERANDS = [];   // дати-операнди (сьогодні, народження, параметри-дати)
let NUM_OPERANDS = [];    // числові операнди (№ лактації, параметри int/float)
let COD_OPERANDS = [];    // cod-операнди (для code_label — довідник код→мітка)
let editingLegacy = false; // редагуємо стандартну вбудовану формулу (не конструктор)
const IS_LIST = (dt) => dt === 'list' || dt === 'select';
const IS_COD = (dt) => dt === 'cod' || dt === 'code';
const HAS_OPTS = (dt) => IS_LIST(dt) || IS_COD(dt);

// Розбір значень: list → масив рядків; cod → масив {c,l}
// (діапазон «0-9» розгортається; або числа/пари «1=Телиця» через кому)
function parseOptions(dtype, raw) {
    const s = (raw || '').trim();
    if (IS_COD(dtype)) {
        const rng = s.match(/^(-?\d+)\s*[-–]\s*(-?\d+)$/);   // діапазон N-M
        if (rng) {
            let a = +rng[1], b = +rng[2];
            if (a > b) { const t = a; a = b; b = t; }
            const out = [];
            for (let i = a; i <= b; i++) out.push({ c: String(i), l: String(i) });
            return out;
        }
        return s.split(',').map((x) => x.trim()).filter(Boolean).map((x) => {
            const i = x.indexOf('=');
            return i < 0 ? { c: x, l: x } : { c: x.slice(0, i).trim(), l: x.slice(i + 1).trim() };
        }).filter((o) => o.c !== '');
    }
    return s.split(',').map((x) => x.trim()).filter(Boolean);
}
// чи це суцільний цілочисловий діапазон без власних підписів
function codIsRange(list) {
    if (!list || list.length < 2) return false;
    const nums = list.map((o) => Number(o.c));
    if (nums.some((n) => !Number.isInteger(n))) return false;
    if (list.some((o) => String(o.l) !== String(o.c))) return false;
    for (let i = 1; i < nums.length; i++) if (nums[i] !== nums[i - 1] + 1) return false;
    return true;
}
function formatOptions(dtype, list) {
    if (!list || !list.length) return '';
    if (IS_COD(dtype)) {
        if (codIsRange(list)) return `${list[0].c}-${list[list.length - 1].c}`;
        return list.map((o) => (String(o.l) === String(o.c) ? o.c : `${o.c}=${o.l}`)).join(', ');
    }
    return list.join(', ');
}
function operandLabel(key) {
    const o = DATE_OPERANDS.find((x) => x.key === key);
    return o ? o.label : (key || '');
}
function opLabel(opKey) {
    const f = FORMULA_OPS.find((x) => x.op === opKey);
    return f ? f.label : opKey;
}
function detailText(p) {
    const f = (p.formula || '').trim();
    if (f) {                         // обчислюване
        if (f.startsWith('{')) {
            try {
                const c = JSON.parse(f);
                const lab = (k) => {
                    const o = DATE_OPERANDS.find((x) => x.key === k)
                        || NUM_OPERANDS.find((x) => x.key === k)
                        || COD_OPERANDS.find((x) => x.key === k);
                    return o ? o.label : k;   // літерал → саме число
                };
                if (c.op === 'code_label') return `авто: мітка коду «${escapeHtml(lab(c.a))}»`;
                const sign = (c.op === 'num_sum' || c.op === 'date_add') ? '+' : '−';
                return `авто: ${escapeHtml(lab(c.a))} ${sign} ${escapeHtml(lab(c.b))}`;
            } catch (e) { /* ignore */ }
        }
        return 'авто: ' + escapeHtml(LEGACY_DESC[f] || f);
    }
    if (IS_COD(p.dtype)) return escapeHtml(formatOptions(p.dtype, p.options_list || []));
    if (IS_LIST(p.dtype)) return escapeHtml((p.options_list || []).join(', '));
    return '';
}

const $ = (id) => document.getElementById(id);
let SECTIONS = [];
let PARAMS = [];            // усі параметри (за sort_order)
let editing = null;        // параметр, який редагуємо
let ppQuery = '';          // фільтр пошуку

// Параметри, що проходять фільтр (за назвою/скороченням/секцією)
function filteredParams() {
    const q = ppQuery.trim().toLowerCase();
    if (!q) return PARAMS;
    return PARAMS.filter((p) =>
        (p.label || '').toLowerCase().includes(q)
        || (p.short || '').toLowerCase().includes(q)
        || (p.section || '').toLowerCase().includes(q));
}

async function load() {
    const r = await apiGet('/api/herd/params');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    SECTIONS = r.sections || [];
    PARAMS = r.params || [];
    FORMULA_OPS = r.formula_ops || [];
    DATE_OPERANDS = r.date_operands || [];
    NUM_OPERANDS = r.num_operands || [];
    COD_OPERANDS = r.cod_operands || [];
    render(filteredParams());
    // сигнал іншим блокам (Події) — оновити списки параметрів
    document.dispatchEvent(new CustomEvent('herd-params-changed'));
}

function opSpec(op) {               // типи слотів A/B для операції ('' = слот сховано)
    const f = FORMULA_OPS.find((x) => x.op === op);
    return f ? { a: f.a || 'date', b: ('b' in f ? f.b : 'date') } : { a: 'date', b: 'date' };
}
function slotList(type) {           // операнди слота (+ «Число (ввести)» для num)
    if (type === 'num') return NUM_OPERANDS.concat([{ key: '__literal__', label: 'Число (ввести)' }]);
    if (type === 'cod') return COD_OPERANDS;
    return DATE_OPERANDS;
}
const isLiteral = (v) => /^-?\d/.test(String(v || ''));
function fillSlot(type, val, selId, litId) {
    const list = slotList(type);
    $(selId).innerHTML = list.map((o) =>
        `<option value="${escapeHtml(o.key)}">${escapeHtml(o.label)}</option>`).join('');
    const known = list.some((o) => o.key === val);
    const lit = $(litId);
    if (type === 'num' && val && !known && isLiteral(val)) {   // збережений літерал
        $(selId).value = '__literal__'; lit.value = val; lit.hidden = false;
    } else {
        $(selId).value = known ? val : (list[0] ? list[0].key : '');
        lit.hidden = $(selId).value !== '__literal__';
        if (!lit.hidden && isLiteral(val)) lit.value = val;
    }
}
function fillOperandSelects(op, a, b) {
    const spec = opSpec(op);
    fillSlot(spec.a, a, 'peOpA', 'peALit');
    const bField = $('peOpB').closest('.field');
    const hasB = !!spec.b;                       // '' → операція з одним операндом
    if (bField) bField.hidden = !hasB;
    if (hasB) {
        fillSlot(spec.b, b, 'peOpB', 'peBLit');
        const minus = (op === 'date_diff' || op === 'date_sub' || op === 'num_diff');
        $('peOpBLabel').textContent = minus ? 'B (віднімається)' : 'B (додається)';
    }
}
function slotValue(selId, litId) {  // значення операнда (літерал → число)
    if ($(selId).value === '__literal__') return ($(litId).value || '').trim().replace(',', '.');
    return $(selId).value;
}
function fillFormulaSelects() {
    $('peOp').innerHTML = FORMULA_OPS.map((f) =>
        `<option value="${f.op}">${escapeHtml(f.label)}</option>`).join('');
}

function sectionOptions(sel) {
    return SECTIONS.map((s) =>
        `<option value="${escapeHtml(s)}"${s === sel ? ' selected' : ''}>${escapeHtml(s)}</option>`).join('');
}

/* ---------- список ---------- */
function render(params) {
    $('ppCount').textContent = params.length ? `· ${params.length}` : '';
    const bySec = {};
    params.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    const order = SECTIONS.concat(Object.keys(bySec).filter((s) => !SECTIONS.includes(s)));
    let html = '';
    let seq = 0;                       // суцільна нумерація згори вниз (по блоках)
    order.forEach((sec) => {
        const list = bySec[sec];
        if (!list || !list.length) return;
        html += `<tr class="pp-sec"><td colspan="9">${escapeHtml(sec)} · ${list.length}</td></tr>`;
        list.forEach((p) => {
            const idx = params.indexOf(p);
            seq += 1;
            const detail = detailText(p);
            html += `<tr class="pp-row ${p.is_active ? '' : 'off'}" data-id="${p.id}">
                <td class="pp-c pp-num">${seq}</td>
                <td class="pp-name"><b>${escapeHtml(p.label)}</b></td>
                <td class="pp-short">${escapeHtml(p.short || '')}</td>
                <td class="pp-dtype">${DTYPE_LABEL[p.dtype] || p.dtype}</td>
                <td>${escapeHtml(p.unit || '')}</td>
                <td class="pp-detail">${detail}</td>
                <td><span class="pp-badge ${p.is_standard ? 'std' : 'cus'}">${p.is_standard ? 'системний' : 'створений'}</span></td>
                <td class="pp-c"><input type="checkbox" data-act="toggle" ${p.is_active ? 'checked' : ''}></td>
                <td class="pp-c pp-actions">
                    <button class="pp-move" data-act="up" ${idx === 0 ? 'disabled' : ''} title="Вгору">▲</button>
                    <button class="pp-move" data-act="down" ${idx === params.length - 1 ? 'disabled' : ''} title="Вниз">▼</button>
                    <button data-act="edit" title="Редагувати">✏</button>
                    ${(!p.is_standard || window.canManage('herd')) ? '<button class="pp-del-btn" data-act="del" title="Видалити">−</button>' : ''}
                </td>
            </tr>`;
        });
    });
    $('ppBody').innerHTML = html ||
        `<tr><td colspan="9" class="empty">${ppQuery ? 'Нічого не знайдено' : 'Немає параметрів'}</td></tr>`;
    if (window.makeColumnsResizable) makeColumnsResizable('ppTable', 'farm:pp_cols');
}

/* ---------- модал: додати / редагувати ---------- */
function openEdit(p) {
    editing = p;                       // p == null → новий параметр
    const isNew = !p;
    let dtype = isNew ? 'int' : p.dtype;
    if (dtype === 'computed') dtype = 'int';   // legacy: computed більше не тип даних
    $('peTitle').textContent = isNew ? 'Новий параметр' : ('Параметр: ' + p.label);
    $('peLabel').value = isNew ? '' : (p.label || '');
    $('peShort').value = isNew ? '' : (p.short || '');
    $('peUnit').value = isNew ? '' : (p.unit || '');
    $('peSection').innerHTML = sectionOptions(isNew ? SECTIONS[0] : p.section);
    // тип: новий/власний — можна обрати; стандартний — лише показ.
    // Якщо поточний тип legacy (number/select/code) — додаємо його в список.
    const typeSel = $('peType');
    const types = ADD_DTYPES.slice();
    if (!types.includes(dtype)) types.unshift(dtype);
    typeSel.innerHTML = types
        .map((d) => `<option value="${d}"${d === dtype ? ' selected' : ''}>${DTYPE_LABEL[d] || d}</option>`).join('');
    // тип стандартних заблоковано, але адмін може змінити
    typeSel.disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peOptions').value = (!isNew && IS_LIST(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    $('peCodes').value = (!isNew && IS_COD(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    // тип обчислення: обчислюване = є формула
    const fml = isNew ? '' : (p.formula || '');
    const computed = !!fml.trim();
    editingLegacy = computed && !fml.trim().startsWith('{');   // вбудована (age/dim…)
    $('peCompute').value = computed ? 'computed' : 'fixed';
    $('peCompute').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    fillFormulaSelects();
    let cfg = { op: 'date_diff', a: '__today__', b: 'birth_date', fallback: '' };
    if (fml.trim().startsWith('{')) { try { cfg = Object.assign(cfg, JSON.parse(fml)); } catch (e) { /* ignore */ } }
    $('peOp').value = cfg.op;
    fillOperandSelects(cfg.op, cfg.a, cfg.b);
    $('peFallback').value = cfg.fallback || '';
    togglePeOpts();
    // джерело: створений/системний. Системний→створений — лише адмін
    $('peSource').value = (isNew || !p.is_standard) ? 'cus' : 'std';
    $('peSource').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peActive').checked = isNew ? true : !!p.is_active;
    $('peHint').textContent = isNew
        ? '«Тип обчислення»: Фіксоване — вводиться руками/подіями; Обчислюване — рахується формулою.'
        : (editingLegacy ? ('Обчислення: ' + (LEGACY_DESC[fml.trim()] || fml.trim()))
            : (p.is_standard && !window.canManage('herd')
                ? 'Стандартний параметр: тип змінити не можна, але можна перейменувати, змінити секцію/одиницю та вимкнути.'
                : ''));
    $('peDelBtn').style.display = (isNew ? false : (!p.is_standard || window.canManage('herd'))) ? '' : 'none';
    $('ppEditModal').hidden = false;
    $('peLabel').focus();
}

function togglePeOpts() {
    const dt = $('peType').value;
    const computed = $('peCompute').value === 'computed';
    // «Значення списку» — лише для типу list; «Коди» — лише для cod
    document.querySelector('.pp-e-opts').hidden = !(IS_LIST(dt) && !computed);
    document.querySelector('.pp-e-codes').hidden = !(IS_COD(dt) && !computed);
    // конструктор формули — для обчислюваних (окрім стандартних вбудованих)
    document.querySelector('.pp-e-formula').hidden = !(computed && !editingLegacy);
}

async function saveEdit() {
    const isNew = !editing;
    const label = $('peLabel').value.trim();
    if (!label) { toast('Вкажіть назву', 'warn'); $('peLabel').focus(); return; }
    const payload = {
        label, short: $('peShort').value.trim(),
        unit: $('peUnit').value.trim(), section: $('peSection').value,
        is_active: $('peActive').checked,
    };
    // тип даних + обчислення + джерело: для нового, власного або адміна на системному
    if (isNew || !editing.is_standard || window.canManage('herd')) {
        payload.is_standard = ($('peSource').value === 'std') ? 1 : 0;
        const dtype = $('peType').value;
        payload.dtype = dtype;
        const computed = $('peCompute').value === 'computed';
        if (!computed && IS_LIST(dtype)) {
            payload.options = parseOptions(dtype, $('peOptions').value);
            if (!payload.options.length) { toast('Додайте значення списку', 'warn'); return; }
        } else if (!computed && IS_COD(dtype)) {
            payload.options = parseOptions(dtype, $('peCodes').value);
            if (!payload.options.length) { toast('Задайте коди (напр. 0-9)', 'warn'); return; }
        }
        if (!editingLegacy) {           // legacy-формулу не чіпаємо
            if (computed) {
                const op = $('peOp').value, spec = opSpec(op);
                const a = slotValue('peOpA', 'peALit');
                const b = spec.b ? slotValue('peOpB', 'peBLit') : '';
                if (!a || (spec.b && !b)) { toast('Заповніть операнди', 'warn'); return; }
                payload.formula = JSON.stringify({
                    op, a, b, fallback: $('peFallback').value.trim(),
                });
            } else {
                payload.formula = '';   // фіксоване — очищаємо формулу
            }
        }
    }
    const url = isNew ? '/api/herd/params' : ('/api/herd/params/' + editing.id);
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('ppEditModal').hidden = true;
    toast(isNew ? 'Додано' : 'Збережено', 'success');
    load();
}

async function delEdit() {
    if (!editing) return;
    if (editing.is_standard && !window.canManage('herd')) return;
    if (!confirm(`Видалити параметр «${editing.label}» і всі його значення?`)) return;
    const r = await apiSend('/api/herd/params/' + editing.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('ppEditModal').hidden = true;
    load();
}

async function delParam(p) {
    if (!p) return;
    if (p.is_standard && !window.canManage('herd')) {
        toast('Стандартний параметр може видалити лише адміністратор', 'warn');
        return;
    }
    const warn = p.is_standard ? ' (СТАНДАРТНИЙ!)' : '';
    if (!confirm(`Видалити параметр «${p.label}»${warn} і всі його значення?`)) return;
    const r = await apiSend('/api/herd/params/' + p.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Видалено', 'success');
    load();
}

/* ---------- переміщення / вкл-викл ---------- */
async function moveParam(id, dir) {
    const i = PARAMS.findIndex((p) => String(p.id) === String(id));
    const j = dir === 'up' ? i - 1 : i + 1;
    if (i < 0 || j < 0 || j >= PARAMS.length) return;
    const arr = PARAMS.slice();
    [arr[i], arr[j]] = [arr[j], arr[i]];
    PARAMS = arr;
    render(filteredParams());   // оптимістично
    await apiSend('/api/herd/params/reorder', 'POST', { order: arr.map((p) => p.id) });
}

async function toggleActive(id, checked) {
    const r = await apiSend('/api/herd/params/' + id, 'POST', { is_active: checked });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); load(); return; }
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (p) p.is_active = checked ? 1 : 0;
    render(filteredParams());
}

/* ---------- події таблиці ---------- */
$('ppBody').addEventListener('click', (e) => {
    const row = e.target.closest('.pp-row'); if (!row) return;
    const id = row.dataset.id; const act = e.target.dataset.act;
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (act === 'edit') { if (p) openEdit(p); }
    else if (act === 'up' || act === 'down') moveParam(id, act);
    else if (act === 'del') delParam(p);
    // клік будь-де по рядку (окрім кнопок/галочки) — відкрити редагування
    else if (!e.target.closest('button, input') && p) openEdit(p);
});
$('ppBody').addEventListener('change', (e) => {
    if (e.target.dataset.act === 'toggle') {
        toggleActive(e.target.closest('.pp-row').dataset.id, e.target.checked);
    }
});

/* ---------- ініт ---------- */
$('peType').addEventListener('change', togglePeOpts);
$('peCompute').addEventListener('change', togglePeOpts);
$('peOp').addEventListener('change', () => fillOperandSelects($('peOp').value));
$('peOpA').addEventListener('change', () => { $('peALit').hidden = $('peOpA').value !== '__literal__'; });
$('peOpB').addEventListener('change', () => { $('peBLit').hidden = $('peOpB').value !== '__literal__'; });
if ($('ppSearch')) $('ppSearch').addEventListener('input', (e) => {
    ppQuery = e.target.value || ''; render(filteredParams());
});
$('ppAddBtn').addEventListener('click', () => openEdit(null));
$('peSaveBtn').addEventListener('click', saveEdit);
$('peDelBtn').addEventListener('click', delEdit);
document.querySelectorAll('#ppEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('ppEditModal').hidden = true; }));
if ($('ppTable')) load();   // запускаємось лише за наявності розмітки
})();
