/* ============ Прихід товару ============ */

const recvInput   = document.getElementById('receiveBarcode');
const recvPreview = document.getElementById('receivePreview');
const recentInBody = document.querySelector('#recentInTable tbody');
const recentSearch = document.getElementById('recentSearch');
const recentCount  = document.getElementById('recentCount');
const recvFromEl   = document.getElementById('recvFrom');
const recvToEl     = document.getElementById('recvTo');

function recvISO(d) { return d.toISOString().slice(0, 10); }
function recvSetPeriod(days) {
    if (days === 'all') { recvFromEl.value = ''; recvToEl.value = ''; return; }
    const today = new Date();
    recvToEl.value = recvISO(today);
    const from = new Date();
    from.setDate(today.getDate() - Number(days));
    recvFromEl.value = recvISO(from);
}
function recvMarkPreset(days) {
    document.querySelectorAll('#recvPresets .btn').forEach(b =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));
}

const invoiceNumberEl = document.getElementById('invoiceNumber');
const invoiceDateEl   = document.getElementById('invoiceDate');
const receiptDateEl   = document.getElementById('receiptDate');
const supplierNameEl  = document.getElementById('supplierName');
const suppliersListEl = document.getElementById('suppliersList');
const productNameSearch  = document.getElementById('productNameSearch');
const productSuggestions = document.getElementById('productSuggestions');
const barcodeSuggestions = document.getElementById('barcodeSuggestions');

let invoiceItems = [];   // позиції поточної накладної (редагуються в таблиці)

function focusBarcode() { recvInput.focus(); recvInput.select(); }
function markInvalid(el)  { if (el) el.classList.add('input-error'); }
function clearInvalid(el) { if (el) el.classList.remove('input-error'); }

function parseDec(v) {
    const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
    return isFinite(n) ? n : 0;
}
function numStr(x) {
    const n = parseDec(x);
    return n ? String(Math.round(n * 10000) / 10000).replace('.', ',') : '';
}
// будь-який не-цифровий символ під час введення → кома (десятковий роздільник)
function normalizeComma(v) {
    v = String(v == null ? '' : v).replace(/[^\d]/g, ',');
    const i = v.indexOf(',');
    if (i !== -1) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/,/g, '');
    return v;
}
const DECIMAL_FIELDS = new Set(['vat_rate', 'qty', 'price_in_no_vat', 'price_in', 'sum_no_vat', 'sum_with_vat']);

/* ---------- таблиця накладної з рядковим введенням ---------- */

const invoiceBody = document.querySelector('#invoiceTable tbody');
const invoiceTable = document.getElementById('invoiceTable');
const invCount = document.getElementById('invCount');
const invSum = document.getElementById('invSum');
const invSumNoVat = document.getElementById('invSumNoVat');

/* режим роботи з ПДВ */
const VAT_MODE_KEY = 'vetpharm:recv_vat_mode';
let vatMode = (localStorage.getItem(VAT_MODE_KEY) === 'without') ? 'without' : 'with';
const defaultVat = () => (vatMode === 'with' ? '20' : '0');

function applyVatModeUI() {
    invoiceTable.classList.toggle('no-vat', vatMode === 'without');
    document.querySelectorAll('#recvVatToggle .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.vatMode === vatMode));
}

/* ---------- збереження набраної накладної (між сесіями) ---------- */

const INVOICE_KEY = 'vetpharm:receive_invoice';
let lastInvChange = 0;

function invoiceState() {
    return {
        vatMode,
        receipt_date: receiptDateEl.value,
        supplier_name: supplierNameEl.value,
        invoice_number: invoiceNumberEl.value,
        invoice_date: invoiceDateEl.value,
        items: invoiceItems,
    };
}

let _invSaveTimer = null;
function persistInvoice() {
    lastInvChange = Date.now();
    try { localStorage.setItem(INVOICE_KEY, JSON.stringify(invoiceState())); }
    catch (_) { /* ignore */ }
    // СПІЛЬНА накладна на сервері (дебаунс, щоб не слати на кожну клавішу)
    clearTimeout(_invSaveTimer);
    _invSaveTimer = setTimeout(() => {
        lastInvChange = Date.now();
        apiSend('/api/invoice/save', 'POST', { invoice: invoiceState() }).catch(() => {});
    }, 500);
}

function applyInvoiceHeader(inv) {
    if (!inv) return;
    if (inv.vatMode === 'without' || inv.vatMode === 'with') { vatMode = inv.vatMode; applyVatModeUI(); }
    if (inv.receipt_date) receiptDateEl.value = inv.receipt_date;
    if (inv.supplier_name) supplierNameEl.value = inv.supplier_name;
    if (inv.invoice_number) invoiceNumberEl.value = inv.invoice_number;
    if (inv.invoice_date) invoiceDateEl.value = inv.invoice_date;
}

// початкове завантаження зі СПІЛЬНОГО серверного кошика-накладної
async function restoreInvoice() {
    const r = await apiGet('/api/invoice');
    const inv = (r && r.ok && r.invoice && typeof r.invoice === 'object') ? r.invoice : null;
    if (inv) {
        applyInvoiceHeader(inv);
        invoiceItems = Array.isArray(inv.items) ? inv.items : [];
    }
    renderInvoice();
    return invoiceItems.length > 0;
}

/* Скан у СПІЛЬНУ накладну (сервер додає атомарно, шапку не чіпає) */
async function serverInvoiceScan(barcode) {
    const r = await apiSend('/api/invoice/scan', 'POST', { barcode });
    if (r && r.ok && r.invoice) {
        invoiceItems = Array.isArray(r.invoice.items) ? r.invoice.items : invoiceItems;
        lastInvChange = Date.now();
        renderInvoice();
        recvInput.value = '';
        const tr = invoiceBody.querySelector(`tr[data-idx="${invoiceItems.length - 1}"]`);
        const q = tr && tr.querySelector('input[data-field="qty"]');
        if (q) { q.focus(); q.select(); }
    }
    return r;
}

function updateInvoiceFooter() {
    const totalQty = invoiceItems.reduce((s, it) => s + parseDec(it.qty), 0);
    const sumNV = invoiceItems.reduce((s, it) => s + parseDec(it.qty) * parseDec(it.price_in_no_vat), 0);
    const sumV = invoiceItems.reduce((s, it) => s + parseDec(it.qty) * parseDec(it.price_in), 0);
    invCount.textContent = fmtNum(totalQty);
    invSumNoVat.textContent = fmtMoney(sumNV);
    invSum.textContent = fmtMoney(sumV);
}

function renderInvoice() {
    if (invoiceItems.length === 0) {
        invoiceBody.innerHTML = '<tr><td colspan="12" class="empty">Знайдіть ' + ((window.ITEM_WORDS && window.ITEM_WORDS.acc) || 'препарат') + ' вище — він додасться рядком сюди</td></tr>';
    } else {
        invoiceBody.innerHTML = invoiceItems.map((it, i) => `
            <tr data-idx="${i}">
                <td class="num">${i + 1}</td>
                <td>${escapeHtml(it.name)}
                    <div class="text-mute" style="font-size:11px;">${escapeHtml(it.barcode)}</div>
                </td>
                <td class="text-mute">${escapeHtml(it.unit || '')}</td>
                <td class="num vatcol"><input class="cart-input" inputmode="decimal" data-field="vat_rate" value="${escapeHtml(String(it.vat_rate ?? defaultVat()))}"></td>
                <td class="num"><input class="cart-input" inputmode="decimal" data-field="qty" placeholder="0" value="${escapeHtml(String(it.qty || ''))}"></td>
                <td class="num"><input class="cart-input" inputmode="decimal" data-field="price_in_no_vat" placeholder="0,00" value="${escapeHtml(numStr(it.price_in_no_vat))}"></td>
                <td class="num"><input class="cart-input" inputmode="decimal" data-field="sum_no_vat" placeholder="0,00" value="${escapeHtml(numStr(parseDec(it.qty) * parseDec(it.price_in_no_vat)))}"></td>
                <td class="num vatcol"><input class="cart-input" inputmode="decimal" data-field="price_in" placeholder="0,00" value="${escapeHtml(numStr(it.price_in))}"></td>
                <td class="num vatcol"><input class="cart-input" inputmode="decimal" data-field="sum_with_vat" placeholder="0,00" value="${escapeHtml(numStr(parseDec(it.qty) * parseDec(it.price_in)))}"></td>
                <td><input type="date" class="cart-input" data-field="expires_on" value="${escapeHtml(it.expires_on || '')}"></td>
                <td class="col-actions"><button class="btn btn-icon btn-icon-danger" data-inv-remove="${i}" title="Прибрати">🗑</button></td>
            </tr>
        `).join('');
    }
    updateInvoiceFooter();
}

const r4 = (n) => Math.round(n * 10000) / 10000;

function rowRecalc(idx, changed) {
    const it = invoiceItems[idx];
    const vat = parseDec(it.vat_rate);
    const k = 1 + vat / 100;
    const qty = parseDec(it.qty);
    if (changed === 'price_in_no_vat') {
        it.price_in = r4(parseDec(it.price_in_no_vat) * k);
    } else if (changed === 'price_in') {
        it.price_in_no_vat = vat > 0 ? r4(parseDec(it.price_in) / k) : parseDec(it.price_in);
    } else if (changed === 'vat_rate') {
        it.price_in = r4(parseDec(it.price_in_no_vat) * k);
    } else if (changed === 'sum_no_vat') {
        if (qty > 0) {
            it.price_in_no_vat = r4(parseDec(it.sum_no_vat) / qty);
            it.price_in = r4(parseDec(it.price_in_no_vat) * k);
        }
    } else if (changed === 'sum_with_vat') {
        if (qty > 0) {
            it.price_in = r4(parseDec(it.sum_with_vat) / qty);
            it.price_in_no_vat = vat > 0 ? r4(it.price_in / k) : it.price_in;
        }
    }
    // 'qty' — ціни лишаються, оновляться лише суми (у patchRow)
}

function patchRow(idx, changed) {
    const tr = invoiceBody.querySelector(`tr[data-idx="${idx}"]`);
    if (!tr) return;
    const it = invoiceItems[idx];
    const qty = parseDec(it.qty);
    const fields = {
        price_in_no_vat: numStr(it.price_in_no_vat),
        price_in: numStr(it.price_in),
        sum_no_vat: numStr(qty * parseDec(it.price_in_no_vat)),
        sum_with_vat: numStr(qty * parseDec(it.price_in)),
    };
    for (const f in fields) {
        if (f === changed) continue;            // поле, яке зараз редагують, не чіпаємо
        const el = tr.querySelector(`input[data-field="${f}"]`);
        if (el) el.value = fields[f];
    }
    updateInvoiceFooter();
}

// рядкове редагування
invoiceBody.addEventListener('input', (e) => {
    const inp = e.target.closest('input[data-field]');
    if (!inp) return;
    const tr = inp.closest('tr');
    const idx = parseInt(tr.dataset.idx, 10);
    const it = invoiceItems[idx];
    if (!it) return;
    const field = inp.dataset.field;
    let val = inp.value;
    if (DECIMAL_FIELDS.has(field)) {
        const norm = normalizeComma(val);
        if (norm !== val) { inp.value = norm; val = norm; }
    }
    it[field] = val;
    rowRecalc(idx, field);
    patchRow(idx, field);
    persistInvoice();
});

// перемикач режиму ПДВ
document.querySelectorAll('#recvVatToggle .seg-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        const m = btn.dataset.vatMode;
        if (m === vatMode) return;
        vatMode = m;
        localStorage.setItem(VAT_MODE_KEY, vatMode);
        // переводимо наявні рядки на нову ставку
        invoiceItems.forEach((it, i) => {
            it.vat_rate = defaultVat();
            rowRecalc(i, 'vat_rate');
        });
        applyVatModeUI();
        renderInvoice();
        persistInvoice();
    });
});

// зміни шапки накладної також зберігаємо
[receiptDateEl, supplierNameEl, invoiceNumberEl, invoiceDateEl].forEach((el) => {
    if (el) el.addEventListener('input', persistInvoice);
});

invoiceBody.addEventListener('click', (e) => {
    const rm = e.target.closest('[data-inv-remove]');
    if (rm) {
        invoiceItems.splice(parseInt(rm.dataset.invRemove, 10), 1);
        renderInvoice();
        persistInvoice();
    }
});

document.getElementById('clearInvoiceBtn').addEventListener('click', async () => {
    if (!invoiceItems.length) return;
    if (!await confirmAction('Очистити всі позиції накладної?')) return;
    invoiceItems = [];
    renderInvoice();
    persistInvoice();
});

/* ---------- пошук/сканування → додає рядок ---------- */

function addRow(product) {
    invoiceItems.push({
        barcode: product.barcode,
        name: product.name,
        unit: product.unit || '',
        vat_rate: defaultVat(),
        price_in_no_vat: '',
        price_in: '',
        qty: '',
        lot_number: '',
        expires_on: '',
    });
    renderInvoice();
    persistInvoice();
    const tr = invoiceBody.querySelector(`tr[data-idx="${invoiceItems.length - 1}"]`);
    const q = tr && tr.querySelector('input[data-field="qty"]');
    if (q) q.focus();
    // очищаємо поле пошуку для наступного препарату
    if (productNameSearch) productNameSearch.value = '';
    recvInput.value = '';
    if (recvPreview) recvPreview.hidden = true;
}

let _lastAdd = { code: '', t: 0 };
async function lookupBarcode(barcode) {
    barcode = (barcode || '').trim();
    if (!barcode) return;
    // захист від подвійного спрацювання (сканер + change/автокомпліт на одну дію)
    const now = Date.now();
    if (barcode === _lastAdd.code && now - _lastAdd.t < 900) return;
    _lastAdd = { code: barcode, t: now };
    if (barcodeSuggestions) barcodeSuggestions.hidden = true;
    if (productSuggestions) productSuggestions.hidden = true;
    // Каскад на сервері: склад → каталог → новий. Якщо є на складі чи в каталозі,
    // сервер додасть позицію (з каталогу — створить товар автоматично).
    const r = await serverInvoiceScan(barcode);
    if (r && r.ok) {
        if (r.from_catalog) toast('Додано з каталогу: ' + (r.added || ''), 'success');
        return;
    }
    // Відмова в правах — це НЕ «товару немає»: форму нового товару не
    // відкриваємо, інакше людина заводить дубль замість того, щоб побачити
    // причину (Роман 2026-09-09: «одразу показує форму створення нового»).
    if (r && r.error && !r.ok && !/не знайдено/i.test(String(r.error))) {
        toast(r.error, 'error');
        return;
    }
    // немає ні на складі, ні в каталозі — відкриваємо «Новий товар»
    // (у полі лишаємо те, що ввела людина, а не службовий код)
    if (!recvInput.value.trim()) recvInput.value = barcode;
    if (/^\d{6,}$/.test(barcode)) {
        document.getElementById('newProductBtn').click();
    } else {
        toast('Товар «' + barcode + '» не знайдено', 'warn');
    }
}

recvInput.addEventListener('change', () => {
    const v = recvInput.value.trim();
    if (v.length < 6) return;
    lookupBarcode(v);
});

[recvInput, receiptDateEl, supplierNameEl, invoiceNumberEl].forEach((el) => {
    if (el) el.addEventListener('input', () => clearInvalid(el));
});

/* ---------- зберегти накладну ---------- */

document.getElementById('commitInvoiceBtn').addEventListener('click', async () => {
    [receiptDateEl, supplierNameEl, invoiceNumberEl].forEach(clearInvalid);
    if (invoiceItems.length === 0) { toast('Додайте хоча б одну позицію', 'warn'); return; }

    // валідація рядків
    for (let i = 0; i < invoiceItems.length; i++) {
        const it = invoiceItems[i];
        if (!(parseDec(it.qty) > 0)) {
            toast(`Рядок ${i + 1}: вкажіть кількість`, 'warn');
            const inp = invoiceBody.querySelector(`tr[data-idx="${i}"] input[data-field="qty"]`);
            if (inp) { markInvalid(inp); inp.focus(); }
            return;
        }
        if (!(parseDec(it.price_in) > 0 || parseDec(it.price_in_no_vat) > 0)) {
            toast(`Рядок ${i + 1}: вкажіть ціну закупки`, 'warn');
            const inp = invoiceBody.querySelector(`tr[data-idx="${i}"] input[data-field="price_in_no_vat"]`);
            if (inp) { markInvalid(inp); inp.focus(); }
            return;
        }
    }

    const problems = [];
    if (!receiptDateEl.value) problems.push([receiptDateEl, 'Вкажіть фактичну дату приходу']);
    if (!supplierNameEl.value.trim()) problems.push([supplierNameEl, 'Вкажіть постачальника']);
    if (!invoiceNumberEl.value.trim()) problems.push([invoiceNumberEl, 'Вкажіть номер накладної']);
    if (problems.length) {
        problems.forEach(([el]) => markInvalid(el));
        toast(problems[0][1], 'warn');
        problems[0][0].focus();
        return;
    }

    const payload = {
        supplier_name: supplierNameEl.value,
        invoice_number: invoiceNumberEl.value,
        invoice_date: invoiceDateEl.value,
        receipt_date: receiptDateEl.value,
        items: invoiceItems.map((it) => ({
            barcode: it.barcode,
            qty: parseDec(it.qty),
            lot_number: it.lot_number || '',
            expires_on: it.expires_on || '',
            vat_rate: parseDec(it.vat_rate),
            price_in: parseDec(it.price_in),
            price_in_no_vat: parseDec(it.price_in_no_vat),
        })),
    };
    const r = await apiSend('/api/receive/bulk', 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    if (r.errors && r.errors.length) {
        toast(`Зараховано ${r.added}, з помилками: ${r.errors[0]}`, 'warn');
    } else {
        toast(`Накладну збережено: ${r.added} поз. на ${fmtMoney(r.total)} ₴`, 'success');
    }

    invoiceItems = [];
    renderInvoice();
    invoiceNumberEl.value = '';
    invoiceDateEl.value = new Date().toISOString().slice(0, 10);
    supplierNameEl.value = '';
    localStorage.removeItem(INVOICE_KEY);
    apiSend('/api/invoice/clear', 'POST', {}).catch(() => {});  // очистити спільну
    lastInvChange = Date.now();
    loadRecent();
    loadSuppliers();
    loadProductsIndex();
    supplierNameEl.focus();
});

document.getElementById('newInvoiceBtn').addEventListener('click', () => {
    invoiceItems = [];
    renderInvoice();
    invoiceNumberEl.value = '';
    invoiceDateEl.value = new Date().toISOString().slice(0, 10);
    supplierNameEl.value = '';
    receiptDateEl.value = new Date().toISOString().slice(0, 10);
    localStorage.removeItem(INVOICE_KEY);
    apiSend('/api/invoice/clear', 'POST', {}).catch(() => {});  // очистити спільну
    lastInvChange = Date.now();
    toast('Нову накладну розпочато', 'success');
    supplierNameEl.focus();
});

/* ---------- модал нового товару ---------- */

const npForm         = document.getElementById('newProductForm');
const npName         = document.getElementById('npName');
const npBarcode      = document.getElementById('npBarcode');
const npGenBtn       = document.getElementById('npGenBarcodeBtn');
const npLabelPreview = document.getElementById('npLabelPreview');
const npBarcodeLabel = document.getElementById('npBarcodeLabel');
const npPrintBtn     = document.getElementById('npPrintLabelBtn');

/* ---- Автопідказка назви з каталогу у формі «Новий товар» ----
   Замість друкувати назву — обираєте з каталогу (тисячі назв). Якщо в записі
   каталогу є штрихкод, а поле порожнє — підставимо і його. */
(function setupCatalogNameAutocomplete() {
    const box = document.getElementById('npNameSuggestions');
    if (!npName || !box) return;
    let items = [], active = -1, timer = null;
    const hide = () => { box.hidden = true; active = -1; };
    function upd() {
        box.querySelectorAll('.autocomplete-item').forEach((el, i) => {
            el.classList.toggle('is-active', i === active);
            if (i === active) el.scrollIntoView({ block: 'nearest' });
        });
    }
    function render() {
        if (!items.length) { hide(); return; }
        box.innerHTML = items.map((it, i) => `
            <div class="autocomplete-item" data-i="${i}">
                <div class="ac-name">${escapeHtml(it.name)}</div>
                <div class="ac-meta">${it.barcode ? escapeHtml(it.barcode) : 'без штрихкоду'}${it.unit ? ' · ' + escapeHtml(it.unit) : ''}</div>
            </div>`).join('');
        box.hidden = false;
    }
    function pick(it) {
        if (!it) return;
        hide();
        npName.value = it.name;
        if (npForm.unit && it.unit) npForm.unit.value = it.unit;
        if (it.barcode && npBarcode && !npBarcode.value.trim()) {
            npBarcode.value = it.barcode;
            if (typeof renderNpLabel === 'function') renderNpLabel();
        }
        if (npBarcode && !npBarcode.value.trim()) npBarcode.focus();
    }
    async function search(q) {
        const r = await apiGet('/api/catalog?q=' + encodeURIComponent(q));
        items = ((r && r.items) || []).slice(0, 12);
        render();
    }
    npName.addEventListener('input', () => {
        const q = npName.value.trim();
        if (q.length < 2) { hide(); return; }
        clearTimeout(timer);
        timer = setTimeout(() => search(q), 180);
    });
    npName.addEventListener('keydown', (e) => {
        if (box.hidden) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); active = Math.min(active + 1, items.length - 1); upd(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); active = Math.max(active - 1, 0); upd(); }
        else if (e.key === 'Enter') { if (active >= 0 && items[active]) { e.preventDefault(); e.stopImmediatePropagation(); pick(items[active]); } }
        else if (e.key === 'Escape') hide();
    });
    box.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const el = e.target.closest('.autocomplete-item');
        if (el) pick(items[parseInt(el.dataset.i, 10)]);
    });
    npName.addEventListener('blur', () => setTimeout(hide, 150));
})();

// Малює прев'ю етикетки, якщо в полі коректний штрихкод EAN-13.
function renderNpLabel() {
    const code = (npBarcode.value || '').trim();
    if (!window.Barcode || !Barcode.isValidEAN13(code)) {
        npLabelPreview.hidden = true;
        npBarcodeLabel.innerHTML = '';
        return;
    }
    const name = (npName.value || '').trim() || 'Новий товар';
    npBarcodeLabel.innerHTML =
        '<div class="bc-label-name">' + escapeHtml(name) + '</div>' +
        Barcode.ean13SVG(code, { module: 3, barHeight: 62 });
    npLabelPreview.hidden = false;
}

document.getElementById('newProductBtn').addEventListener('click', async () => {
    npForm.reset();
    npLabelPreview.hidden = true;
    npBarcodeLabel.innerHTML = '';
    if (recvInput.value.trim()) npBarcode.value = recvInput.value.trim();
    renderNpLabel();
    openModal('newProductModal');
    npName.focus();
    // підставляємо наступний вільний код товару
    const r = await apiGet('/api/generate-code');
    if (r.ok) npForm.code.value = r.code;
});

// Згенерувати унікальний внутрішній штрихкод
npGenBtn.addEventListener('click', async () => {
    npGenBtn.disabled = true;
    const r = await apiGet('/api/generate-barcode');
    npGenBtn.disabled = false;
    if (!r.ok || !r.barcode) {
        toast(r.error || 'Не вдалося згенерувати код', 'error');
        return;
    }
    npBarcode.value = r.barcode;
    clearInvalid(npBarcode);
    toast('Штрихкод згенеровано', 'success');
    renderNpLabel();
});

npBarcode.addEventListener('input', renderNpLabel);
npName.addEventListener('input', () => { if (!npLabelPreview.hidden) renderNpLabel(); });

// Друк етикетки в окремому вікні
npPrintBtn.addEventListener('click', () => {
    const code = (npBarcode.value || '').trim();
    if (!window.Barcode || !Barcode.isValidEAN13(code)) {
        toast('Спершу згенеруйте коректний штрихкод', 'warn');
        return;
    }
    const name = (npName.value || '').trim() || 'Товар';
    const svg = Barcode.ean13SVG(code, { module: 3, barHeight: 72 });
    const w = window.open('', '_blank', 'width=440,height=340');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(
        '<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">' +
        '<title>Етикетка ' + escapeHtml(code) + '</title><style>' +
        '@page{margin:6mm;}' +
        'body{font-family:Arial,sans-serif;text-align:center;margin:0;padding:10px;}' +
        '.nm{font-size:13px;font-weight:700;margin-bottom:4px;word-break:break-word;}' +
        'svg{max-width:100%;height:auto;}' +
        '</style></head><body>' +
        '<div class="nm">' + escapeHtml(name) + '</div>' + svg +
        '<script>window.onload=function(){window.print();};' +
        'window.onafterprint=function(){window.close();};<\/script>' +
        '</body></html>');
    w.document.close();
});

// Код товару — лише цифри (літери прибираються одразу при введенні)
npForm.code.addEventListener('input', () => {
    npForm.code.value = npForm.code.value.replace(/\D/g, '');
});

npForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(npForm).entries());
    const r = await apiSend('/api/products', 'POST', data);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Товар додано', 'success');
    closeModal('newProductModal');
    // Якщо штрихкод не вводили — сервер призначив внутрішній; беремо його з відповіді
    const bc = r.barcode || data.barcode || '';
    recvInput.value = bc;
    if (bc) lookupBarcode(bc);
    loadProductsIndex();   // новий товар одразу доступний у розумному пошуку
});

/* ---------- розумний пошук препарату (логіка — у app.js) ---------- */

// Єдине поле: автокомпліт шукає і за назвою, і за кодом/штрихкодом.
createAutocomplete(recvInput, barcodeSuggestions, (p) => {
    // У полі показуємо НАЗВУ (людина шукала саме її), а шукаємо за штрихкодом,
    // а якщо його немає — за внутрішнім кодом: у кормів штрихкоду зазвичай
    // немає, і раніше в полі зʼявлявся код, а прихід пропонував «новий товар».
    const code = (p.barcode || p.code || '').trim();
    recvInput.value = p.name || code;
    if (code) lookupBarcode(code);
    else toast('У товару немає ні штрихкоду, ні коду', 'warn');
});

// F2 — перший раз фокус на полі пошуку, другий раз — камера.
if (window.attachScanShortcut) {
    attachScanShortcut(recvInput, document.getElementById('recvCameraBtn'));
}

// Обробник сканера (Enter / швидкий ввід) — реєструємо після автокомпліту
attachScannerHandler(recvInput, lookupBarcode);

/* ---------- сканування камерою телефона: скан → у накладну ---------- */
(function () {
    const camBtn = document.getElementById('recvCameraBtn');
    if (!camBtn || !window.openCameraScanner) return;
    camBtn.addEventListener('click', () => {
        const scanner = openCameraScanner(async (code) => {
            const r = await serverInvoiceScan(code);   // у СПІЛЬНУ накладну
            // авто-закриття камери одразу після скану (нижче)
            if (r && r.ok) {
                if (window.scanBeep) window.scanBeep(true);
                if (scanner) scanner.setStatus((r.from_catalog ? '✓ З каталогу: ' : '✓ Додано: ') +
                    (r.added || '') + '  ·  у накладній: ' + invoiceItems.length);
            } else {
                if (window.scanBeep) window.scanBeep(false);
                if (scanner) scanner.setStatus('✗ Немає на складі й у каталозі — «Новий товар»');
                recvInput.value = code;                 // підставимо штрихкод у форму
                if (scanner) scanner.close();           // закрити камеру, показати форму
                setTimeout(() => document.getElementById('newProductBtn').click(), 150);
            }
            const a = document.activeElement;
            if (a && a.blur) a.blur();
        }, { autoClose: true });     // камера закривається одразу після скану
    });
})();

/* ---------- список постачальників ---------- */

async function loadSuppliers() {
    const r = await apiGet('/api/suppliers');
    if (!r.ok) return;
    const items = r.items || [];
    suppliersListEl.innerHTML = items
        .map((s) => `<option value="${escapeHtml(s.name)}"></option>`)
        .join('');
}

/* ---------- останні надходження (згруповані за накладними) ---------- */

let allInvoices = [];            // накладні з сервера
let lastReceiptsJson = '';

// сортування: на рівні накладних і всередині накладної
// За замовчуванням — за датою приходу, від нових до давніх (новіші зверху).
let invSortCol = 'receipt_date', invSortDir = 'desc';
let detSortCol = null, detSortDir = 'asc';
const expandedInv = new Set();   // ключі розкритих накладних
let renderedKeys = [];           // gi -> ключ накладної (для збереження розкриття)
let renderedInvoices = [];       // gi -> накладна (для редагування шапки)
const invKey = (inv) => `${inv.invoice_number}|${inv.supplier}|${inv.receipt_date}`;

function cmp(a, b, dir) {
    if (a == null && b == null) return 0;
    if (a == null) return 1;
    if (b == null) return -1;
    if (typeof a === 'number' && typeof b === 'number') return (a - b) * dir;
    return String(a).localeCompare(String(b), 'uk', { numeric: true }) * dir;
}

// значення позиції за ключем колонки деталей (для сортування всередині)
function detailValue(m, key) {
    switch (key) {
        case 'date': return m.created_at;
        case 'name': return m.name;
        case 'code': return m.code;
        case 'lot':  return m.lot_number;
        case 'exp':  return m.expires_on;
        case 'qty':  return Number(m.received_qty) || 0;
        case 'pnv':  return Number(m.price_in_no_vat) || 0;
        case 'pv':   return Number(m.price) || 0;
        case 'snv':  return Number(m.line_sum_no_vat) || 0;
        case 'sum':  return Number(m.total) || 0;
        case 'user': return m.user_login;
        case 'no':   return Number(m._pos) || 0;   // номер позиції
        default:     return null;
    }
}

async function loadRecent() {
    const qs = new URLSearchParams();
    if (recvFromEl && recvFromEl.value) qs.set('from', recvFromEl.value);
    if (recvToEl && recvToEl.value) qs.set('to', recvToEl.value);
    const r = await apiGet('/api/receipts/invoices' + (qs.toString() ? '?' + qs.toString() : ''));
    if (!r.ok) return;
    const items = r.items || [];
    const j = JSON.stringify(items);
    if (j === lastReceiptsJson) return;
    lastReceiptsJson = j;
    allInvoices = items;
    renderRecent();
}

function invoiceMatches(inv, q) {
    if (!q) return true;
    const head = [inv.invoice_number, inv.supplier].map((x) => (x || '').toLowerCase()).join(' ');
    if (head.includes(q)) return true;
    return (inv.items || []).some((m) =>
        [m.name, m.code, m.barcode, m.lot_number].map((x) => (x == null ? '' : String(x)).toLowerCase())
            .join(' ').includes(q));
}

function renderRecent() {
    const q = (recentSearch.value || '').trim().toLowerCase();
    let list = allInvoices.filter((inv) => invoiceMatches(inv, q));

    // сортування накладних
    if (invSortCol) {
        const dir = invSortDir === 'desc' ? -1 : 1;
        list = list.slice().sort((a, b) => cmp(a[invSortCol], b[invSortCol], dir));
    }
    // індикатори в заголовках накладних
    document.querySelectorAll('#recentInTable thead .sortable-th').forEach((th) => {
        th.classList.remove('sort-asc', 'sort-desc');
        if (th.dataset.sort === invSortCol) {
            th.classList.add(invSortDir === 'desc' ? 'sort-desc' : 'sort-asc');
        }
    });

    const shown = q ? list : list.slice(0, 25);

    recentCount.textContent = q ? ('Знайдено: ' + list.length)
        : (allInvoices.length > 25 ? ('Показано 25 з ' + allInvoices.length) : '');

    if (shown.length === 0) {
        recentInBody.innerHTML = '<tr><td colspan="7" class="empty">' +
            (q ? 'Нічого не знайдено' : 'Поки що порожньо') + '</td></tr>';
        return;
    }

    const headCells = DETAIL_COLS.map((c) => {
        let cls = c.num ? 'num' : '';
        if (c.key === detSortCol) cls += (detSortDir === 'desc' ? ' sort-desc' : ' sort-asc');
        return `<th data-dcol="${c.key}" data-dsort="${c.key}" class="sortable-th ${cls}">${c.label}` +
            `<span class="sort-ind"></span><span class="dcol-resizer" data-dcol="${c.key}"></span></th>`;
    }).join('') + '<th></th>';

    renderedKeys = [];
    renderedInvoices = [];
    recentInBody.innerHTML = shown.map((inv, gi) => {
        const key = invKey(inv);
        renderedKeys[gi] = key;
        renderedInvoices[gi] = inv;
        const isOpen = expandedInv.has(key);
        let items = inv.items || [];
        // № позиції — за збереженим (природним) порядком, не залежить від сортування
        items.forEach((m, idx) => { m._pos = idx + 1; });
        if (detSortCol) {
            const dir = detSortDir === 'desc' ? -1 : 1;
            items = items.slice().sort((a, b) => cmp(detailValue(a, detSortCol), detailValue(b, detSortCol), dir));
        }
        const detail = items.map((m) => {
            const cells = DETAIL_COLS.map((c) => {
                const v = c.key === 'no'
                    ? `<span class="pos-grip" title="Перетягніть, щоб змінити порядок">⠿</span> ${m._pos}`
                    : detailCell(m, c.key);
                return `<td data-dcol="${c.key}" class="${c.num ? 'num' : 'text-mute'}">${v}</td>`;
            }).join('');
            const act = `<td class="col-actions">${m.batch_id && m.can_edit ? `
                <div class="row-actions">
                    <button class="btn btn-icon" data-edit-receipt="${m.batch_id}" title="Редагувати">✎</button>
                    <button class="btn btn-icon btn-icon-danger" data-del-receipt="${m.batch_id}" title="Видалити">🗑</button>
                </div>` : ''}</td>`;
            return `<tr class="inv-pos" draggable="true" data-batch="${m.batch_id}" data-invkey="${escapeHtml(key)}">${cells}${act}</tr>`;
        }).join('');
        const fbid = ((inv.items || []).find((x) => x.batch_id) || {}).batch_id;
        const printBtn = fbid
            ? `<a class="btn btn-icon" href="${(window.API_BASE || '')}/receipt/${fbid}/invoice"
                  target="_blank" title="Друк прибуткової накладної" style="margin-left:8px;">🖨</a>` : '';
        const canEditInv = (inv.items || []).some((x) => x.can_edit);
        const editInvBtn = canEditInv
            ? `<button class="btn btn-icon inv-edit" data-inv-edit="${gi}"
                  title="Скоригувати дані накладної" style="margin-left:4px;">✎</button>` : '';
        return `
            <tr class="inv-row" data-inv="${gi}">
                <td><button class="batch-toggle" data-inv-toggle="${gi}" title="Показати позиції">${isOpen ? '▾' : '▸'}</button></td>
                <td><strong>${escapeHtml(inv.invoice_number || '—')}</strong>${editInvBtn}</td>
                <td>${escapeHtml(inv.supplier || '—')}</td>
                <td class="num">${fmtNum(inv.positions)}</td>
                <td class="num">${fmtMoney(inv.sum_no_vat)}</td>
                <td class="num"><strong>${fmtMoney(inv.sum_with_vat)}</strong></td>
                <td class="text-mute nowrap" style="white-space:nowrap;">${escapeHtml(inv.receipt_date || fmtDate(inv.created_at) || '')}${printBtn}</td>
            </tr>
            <tr class="inv-detail" data-detail="${gi}" ${isOpen ? '' : 'hidden'}>
                <td colspan="7">
                    <div class="batch-box">
                        <div class="batch-box-title">Позиції накладної (${inv.positions})</div>
                        <table class="batch-table inv-detail-table">
                            <thead><tr>${headCells}</tr></thead>
                            <tbody>${detail}</tbody>
                        </table>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
    applyDetailPrefs();
}

// Сортування на рівні накладних (клік по заголовку зовнішньої таблиці)
document.querySelectorAll('#recentInTable thead .sortable-th').forEach((th) => {
    th.addEventListener('click', (e) => {
        if (e.target.closest('.col-resizer')) return;   // це тягнули ширину
        const col = th.dataset.sort;
        if (!col) return;
        if (invSortCol === col) {
            invSortDir = (invSortDir === 'asc') ? 'desc' : 'asc';
        } else {
            invSortCol = col;
            invSortDir = ['positions', 'sum_no_vat', 'sum_with_vat', 'receipt_date'].includes(col) ? 'desc' : 'asc';
        }
        renderRecent();
    });
});

// Сортування всередині накладної (клік по заголовку таблиці позицій)
recentInBody.addEventListener('click', (e) => {
    if (e.target.closest('.dcol-resizer')) return;      // це тягнули ширину
    const th = e.target.closest('.inv-detail-table th[data-dsort]');
    if (!th) return;
    const col = th.dataset.dsort;
    if (detSortCol === col) {
        detSortDir = (detSortDir === 'asc') ? 'desc' : 'asc';
    } else {
        detSortCol = col;
        detSortDir = ['qty', 'pnv', 'pv', 'snv', 'sum', 'date', 'exp'].includes(col) ? 'desc' : 'asc';
    }
    renderRecent();
});

// Перетягування позицій усередині накладної (зміна номера/порядку)
let dragBatch = null, dragKey = null;
function clearDragOver() {
    recentInBody.querySelectorAll('.drag-over').forEach((x) => x.classList.remove('drag-over'));
}
recentInBody.addEventListener('dragstart', (e) => {
    const tr = e.target.closest('.inv-pos');
    if (!tr) return;
    dragBatch = tr.dataset.batch;
    dragKey = tr.dataset.invkey;
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', dragBatch); } catch (_) { /* ie */ }
    tr.classList.add('dragging');
});
recentInBody.addEventListener('dragend', (e) => {
    const tr = e.target.closest('.inv-pos');
    if (tr) tr.classList.remove('dragging');
    clearDragOver();
    dragBatch = null; dragKey = null;
});
recentInBody.addEventListener('dragover', (e) => {
    const tr = e.target.closest('.inv-pos');
    if (!tr || !dragKey || tr.dataset.invkey !== dragKey) return;
    e.preventDefault();
    clearDragOver();
    if (tr.dataset.batch !== dragBatch) tr.classList.add('drag-over');
});
recentInBody.addEventListener('drop', async (e) => {
    const tr = e.target.closest('.inv-pos');
    if (!tr || !dragKey || tr.dataset.invkey !== dragKey) return;
    e.preventDefault();
    const moved = dragBatch, target = tr.dataset.batch;
    clearDragOver();
    if (!moved || moved === target) return;
    const tbody = tr.closest('tbody');
    let ids = [...tbody.querySelectorAll('.inv-pos')].map((r) => r.dataset.batch);
    const from = ids.indexOf(moved);
    if (from < 0) return;
    ids.splice(from, 1);
    const to = ids.indexOf(target);
    ids.splice(to < 0 ? ids.length : to, 0, moved);
    const r = await apiSend('/api/receipts/reorder', 'POST', { batch_ids: ids.map(Number) });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    detSortCol = null;          // показуємо ручний порядок
    lastReceiptsJson = '';
    loadRecent();
});

/* ---------- колонки всередині накладної: вибір + ширина ---------- */

const DETAIL_COLS = [
    { key: 'no',    label: '№',            num: true },
    { key: 'date',  label: 'Дата',         num: false },
    { key: 'name',  label: 'Товар',        num: false },
    { key: 'code',  label: 'Код',          num: false },
    { key: 'exp',   label: 'Термін',       num: false },
    { key: 'qty',   label: 'К-сть',        num: true },
    { key: 'pnv',   label: 'Ціна без ПДВ', num: true },
    { key: 'pv',    label: 'Ціна з ПДВ',   num: true },
    { key: 'snv',   label: 'Сума без ПДВ', num: true },
    { key: 'sum',   label: 'Сума з ПДВ',   num: true },
    { key: 'user',  label: 'Користувач',   num: false },
];
const DET_HIDDEN_KEY = 'vetpharm:inv_detail_hidden';
const DET_WIDTH_KEY  = 'vetpharm:inv_detail_widths';

function detailCell(m, key) {
    switch (key) {
        case 'date': return `<span class="nowrap">${fmtDateTime(m.created_at)}</span>`;
        case 'name': return `${escapeHtml(m.name)}<div class="text-mute" style="font-size:11px;">${escapeHtml(m.barcode)}</div>`;
        case 'code': return escapeHtml(m.code || '');
        case 'exp':  return m.expires_on ? fmtDate(m.expires_on) : '—';
        case 'qty':  return fmtNum(m.received_qty);
        case 'pnv':  return fmtMoney(m.price_in_no_vat || 0);
        case 'pv':   return fmtMoney(m.price);
        case 'snv':  return fmtMoney(m.line_sum_no_vat || 0);
        case 'sum':  return fmtMoney(m.total);
        case 'user': return escapeHtml(m.user_login || '');
        default:     return '';
    }
}

function getDetHidden() {
    try { return new Set(JSON.parse(localStorage.getItem(DET_HIDDEN_KEY) || '[]')); }
    catch (_) { return new Set(); }
}
function getDetWidths() {
    try { return JSON.parse(localStorage.getItem(DET_WIDTH_KEY) || '{}') || {}; }
    catch (_) { return {}; }
}

function applyDetailPrefs() {
    const hidden = getDetHidden();
    const widths = getDetWidths();
    document.querySelectorAll('.inv-detail-table').forEach((tbl) => {
        tbl.style.tableLayout = 'fixed';
        tbl.querySelectorAll('[data-dcol]').forEach((cell) => {
            const k = cell.dataset.dcol;
            cell.style.display = hidden.has(k) ? 'none' : '';
            if (cell.tagName === 'TH' && widths[k]) cell.style.width = widths[k] + 'px';
        });
    });
}

// перетягування ширини стовпця всередині накладної (спільне для всіх таблиць)
recentInBody.addEventListener('mousedown', (e) => {
    const handle = e.target.closest('.dcol-resizer');
    if (!handle) return;
    e.preventDefault();
    e.stopPropagation();
    const key = handle.dataset.dcol;
    const th = handle.closest('th');
    const startX = e.clientX;
    const startW = th.offsetWidth;
    document.body.style.cursor = 'col-resize';
    const onMove = (m) => {
        const w = Math.max(48, startW + (m.clientX - startX));
        const widths = getDetWidths();
        widths[key] = w;
        localStorage.setItem(DET_WIDTH_KEY, JSON.stringify(widths));
        applyDetailPrefs();
    };
    const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        document.body.style.cursor = '';
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
});

// кнопка «Колонки» — вибір видимих стовпців усередині накладної
(function initDetailColumnPicker() {
    const anchor = document.querySelector('.rcp-fields')
        || document.getElementById('recentHeadActions');
    if (!anchor) return;
    const hidden = getDetHidden();
    const wrap = document.createElement('div');
    wrap.className = 'col-picker';
    wrap.innerHTML =
        '<button type="button" class="btn btn-ghost col-picker-btn" title="Колонки в накладній">⚙ Колонки</button>' +
        '<div class="col-picker-menu" hidden>' +
          '<div class="col-picker-title">Колонки в накладній</div>' +
          DETAIL_COLS.map((c) =>
            `<label class="col-picker-item"><input type="checkbox" data-key="${c.key}" ${hidden.has(c.key) ? '' : 'checked'}><span>${c.label}</span></label>`
          ).join('') +
        '</div>';
    anchor.appendChild(wrap);
    const btn = wrap.querySelector('.col-picker-btn');
    const menu = wrap.querySelector('.col-picker-menu');
    function positionMenu() {
        menu.style.top = ''; menu.style.left = '';
        const r = btn.getBoundingClientRect();
        const mh = menu.offsetHeight, mw = menu.offsetWidth;
        const below = window.innerHeight - r.bottom, above = r.top;
        const top = (below < mh + 12 && above > below)
            ? Math.max(4, r.top - mh - 4) : (r.bottom + 4);
        let left = r.right - mw;
        if (left < 4) left = 4;
        if (left + mw > window.innerWidth - 4) left = window.innerWidth - mw - 4;
        menu.style.top = top + 'px';
        menu.style.left = left + 'px';
    }
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (menu.hidden) { menu.hidden = false; positionMenu(); } else { menu.hidden = true; }
    });
    window.addEventListener('resize', () => { if (!menu.hidden) positionMenu(); });
    window.addEventListener('scroll', () => { if (!menu.hidden) positionMenu(); }, { passive: true });
    document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) menu.hidden = true; });
    menu.querySelectorAll('input[type="checkbox"]').forEach((inp) => {
        inp.addEventListener('change', () => {
            const h = getDetHidden();
            if (inp.checked) h.delete(inp.dataset.key); else h.add(inp.dataset.key);
            localStorage.setItem(DET_HIDDEN_KEY, JSON.stringify([...h]));
            applyDetailPrefs();
        });
    });
})();

recentSearch.addEventListener('input', renderRecent);

// Пресети періоду + ручні дати (як у «Дії користувачів»)
const recvPresetsEl = document.getElementById('recvPresets');
if (recvPresetsEl) {
    recvPresetsEl.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-days]');
        if (!btn) return;
        const d = btn.dataset.days;
        recvSetPeriod(d === 'all' ? 'all' : Number(d));
        recvMarkPreset(d);
        lastReceiptsJson = '';
        loadRecent();
    });
}
[recvFromEl, recvToEl].forEach((el) => el && el.addEventListener('change', () => {
    recvMarkPreset(null);
    lastReceiptsJson = '';
    loadRecent();
}));

// розкриття/згортання накладної (стан зберігається між перемальовуваннями)
recentInBody.addEventListener('click', (e) => {
    const tg = e.target.closest('[data-inv-toggle]');
    if (!tg) return;
    const key = renderedKeys[tg.dataset.invToggle];
    if (!key) return;
    if (expandedInv.has(key)) expandedInv.delete(key); else expandedInv.add(key);
    renderRecent();
});

/* ---------- коригування шапки накладної (усі позиції) ---------- */
const editInvoiceForm = document.getElementById('editInvoiceForm');
let editInvBatchIds = [];
recentInBody.addEventListener('click', (e) => {
    const b = e.target.closest('[data-inv-edit]');
    if (!b) return;
    const inv = renderedInvoices[b.dataset.invEdit];
    if (!inv) return;
    editInvBatchIds = (inv.items || []).map((x) => x.batch_id).filter(Boolean);
    const f = editInvoiceForm;
    f.supplier.value = inv.supplier || '';
    f.invoice_number.value = inv.invoice_number || '';
    f.invoice_date.value = (inv.invoice_date || '').slice(0, 10);
    f.receipt_date.value = (inv.receipt_date || '').slice(0, 10);
    const cnt = document.getElementById('editInvCount');
    if (cnt) cnt.textContent = `Позицій у накладній: ${editInvBatchIds.length} (зміни застосуються до всіх)`;
    openModal('editInvoiceModal');
});
if (editInvoiceForm) {
    editInvoiceForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const f = editInvoiceForm;
        const r = await apiSend('/api/receipts/invoice-header', 'POST', {
            batch_ids: editInvBatchIds,
            supplier: f.supplier.value.trim(),
            invoice_number: f.invoice_number.value.trim(),
            invoice_date: f.invoice_date.value,
            receipt_date: f.receipt_date.value,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast(`Накладну оновлено (${r.updated} поз.)`, 'success');
        closeModal('editInvoiceModal');
        loadRecent();
    });
}

/* ---------- редагування / видалення приходу ---------- */

const editReceiptForm  = document.getElementById('editReceiptForm');
const editProductLine  = document.getElementById('editProductLine');
const editConsumedWarn = document.getElementById('editConsumedWarn');
const ePurchaseSection = document.getElementById('ePurchaseSection');
const eVatRate    = document.getElementById('eVatRate');
const ePriceNoVat = document.getElementById('ePriceNoVat');
const ePriceVat   = document.getElementById('ePriceVat');
const eSumNoVat   = document.getElementById('eSumNoVat');
const eSumVat     = document.getElementById('eSumVat');
const eQty        = document.getElementById('eQty');

let editConsumed = 0;   // скільки вже списано з партії, що редагується

// Той самий рушій розрахунків ПДВ, що й у формі приходу (без секції продажу)
const editCalc = createPurchaseCalc({
    section:       ePurchaseSection,
    toggleButtons: ePurchaseSection.querySelectorAll('.vat-toggle .seg-btn'),
    hint:          document.getElementById('ePurchaseHint'),
    lblPriceNoVat: document.getElementById('eLblPriceNoVat'),
    lblSumNoVat:   document.getElementById('eLblSumNoVat'),
    qty:           eQty,
    priceNoVat:    ePriceNoVat,
    priceVat:      ePriceVat,
    sumNoVat:      eSumNoVat,
    sumVat:        eSumVat,
    vatSummary:    document.getElementById('eVatSummary'),
    vatRateInput:  document.getElementById('eVatPct'),
    warnNoQty:     false,
});

async function openEditReceipt(batchId) {
    const r = await apiGet('/api/receipts/' + batchId);
    if (!r.ok) { toast(r.error || 'Не вдалося завантажити прихід', 'error'); return; }
    const rc = r.receipt;
    editConsumed = rc.consumed_qty || 0;

    const f = editReceiptForm;
    f.batch_id.value       = rc.batch_id;
    f.receipt_date.value   = rc.receipt_date || '';
    f.supplier_name.value  = rc.supplier_name || '';
    f.invoice_number.value = rc.invoice_number || '';
    f.invoice_date.value   = rc.invoice_date || '';
    f.qty.value            = rc.received_qty;
    f.expires_on.value     = rc.expires_on || '';
    f.note.value           = rc.user_note || '';

    // режим ПДВ і ставку визначаємо зі збереженої партії
    const mode = (Number(rc.vat_rate) > 0) ? 'with' : 'without';
    eVatRate.value = rc.vat_rate;
    const eVatPct = document.getElementById('eVatPct');
    if (eVatPct) eVatPct.value = (Number(rc.vat_rate) > 0) ? rc.vat_rate : 20;
    ePriceNoVat.value = rc.price_in_no_vat || '';
    ePriceVat.value   = rc.price_in || '';
    eSumNoVat.value = '';
    eSumVat.value   = '';

    editCalc.resetEditState();
    editCalc.setVatMode(mode);   // застосує режим + перерахує суми

    editProductLine.textContent = `${rc.product_name} · ${rc.barcode}`;

    if (editConsumed > 0) {
        editConsumedWarn.hidden = false;
        editConsumedWarn.textContent =
            `Увага: з цієї партії вже списано ${fmtNum(editConsumed)} ${rc.unit}. ` +
            `Кількість не можна зменшити нижче цього значення, видалення недоступне.`;
    } else {
        editConsumedWarn.hidden = true;
    }

    openModal('editReceiptModal');
}

recentInBody.addEventListener('click', (e) => {
    const editId = e.target.dataset.editReceipt;
    const delId  = e.target.dataset.delReceipt;
    if (editId) openEditReceipt(editId);
    else if (delId) deleteReceiptRow(delId);
});

async function deleteReceiptRow(batchId) {
    if (!await confirmAction('Видалити цей прихід? Партію буде вилучено зі складу.')) return;
    const r = await apiSend('/api/receipts/' + batchId, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Прихід видалено', 'success');
    loadRecent();
    loadProductsIndex();
}

editReceiptForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(editReceiptForm).entries());
    const batchId = data.batch_id;
    delete data.batch_id;

    [eQty, editReceiptForm.receipt_date, editReceiptForm.supplier_name,
     editReceiptForm.invoice_number, ePriceNoVat, ePriceVat].forEach(clearInvalid);
    const priceFilled =
        (parseFloat(data.price_in_no_vat) > 0) || (parseFloat(data.price_in) > 0);
    const problems = [];
    if (!data.qty || parseFloat(data.qty) <= 0) {
        problems.push([eQty, 'Вкажіть кількість (більше 0)']);
    }
    if (!data.receipt_date) {
        problems.push([editReceiptForm.receipt_date, 'Вкажіть фактичну дату приходу']);
    }
    if (!data.supplier_name || !data.supplier_name.trim()) {
        problems.push([editReceiptForm.supplier_name, 'Вкажіть постачальника']);
    }
    if (!data.invoice_number || !data.invoice_number.trim()) {
        problems.push([editReceiptForm.invoice_number, 'Вкажіть номер накладної']);
    }
    if (!priceFilled) {
        problems.push([ePriceNoVat, 'Вкажіть ціну закупки']);
    }
    if (problems.length) {
        problems.forEach(([el]) => markInvalid(el));
        toast(problems[0][1], 'warn');
        problems[0][0].focus();
        return;
    }

    // ставка ПДВ — з обраного режиму; ціни продажу немає
    data.vat_rate = editCalc.getVatRate();
    if (editCalc.getVatMode() === 'without' && !data.price_in) {
        data.price_in = data.price_in_no_vat;
    }
    data.price_out = 0;
    data.markup_pct = 0;
    const r = await apiSend('/api/receipts/' + batchId, 'PUT', data);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Прихід оновлено', 'success');
    closeModal('editReceiptModal');
    loadRecent();
    loadSuppliers();
    loadProductsIndex();
});

document.getElementById('deleteReceiptBtn').addEventListener('click', async () => {
    const batchId = editReceiptForm.batch_id.value;
    if (!batchId) return;
    if (editConsumed > 0) {
        toast('З партії вже списано товар — видалення недоступне', 'error');
        return;
    }
    if (!await confirmAction('Видалити цей прихід? Партію буде вилучено зі складу.')) return;
    const r = await apiSend('/api/receipts/' + batchId, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Прихід видалено', 'success');
    closeModal('editReceiptModal');
    loadRecent();
    loadProductsIndex();
});

/* ---------- init ---------- */

/* ---------- авто-оновлення «Останніх надходжень» ---------- */

let receiptsPollTimer = null;

function startReceiptsPoll() {
    if (receiptsPollTimer) return;
    receiptsPollTimer = setInterval(loadRecent, 5000);
}

function stopReceiptsPoll() {
    if (receiptsPollTimer) {
        clearInterval(receiptsPollTimer);
        receiptsPollTimer = null;
    }
}

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        stopReceiptsPoll();
    } else {
        loadRecent();
        startReceiptsPoll();
    }
});

/* ---------- розсувний роздільник між колонками приходу ---------- */

function initReceiveSplitter() {
    const splitter = document.getElementById('receiveSplitter');
    const layout = splitter && splitter.closest('.receive-2col');
    if (!splitter || !layout) return;
    const KEY = 'vetpharm:receive_split';
    const saved = parseFloat(localStorage.getItem(KEY));
    if (isFinite(saved) && saved >= 20 && saved <= 75) {
        layout.style.setProperty('--recv-left', saved + '%');
    }
    splitter.addEventListener('mousedown', (ev) => {
        ev.preventDefault();
        splitter.classList.add('dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        const onMove = (m) => {
            const rect = layout.getBoundingClientRect();
            let pct = ((m.clientX - rect.left) / rect.width) * 100;
            pct = Math.max(20, Math.min(75, pct));
            layout.style.setProperty('--recv-left', pct + '%');
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            splitter.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            const cur = layout.style.getPropertyValue('--recv-left');
            if (cur) localStorage.setItem(KEY, parseFloat(cur));
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
    splitter.addEventListener('dblclick', () => {
        layout.style.removeProperty('--recv-left');
        localStorage.removeItem(KEY);
    });
}

/* ---------- зміна ширини стовпців таблиці накладної ---------- */
function initInvoiceColResize() {
    const table = document.getElementById('invoiceTable');
    if (!table || !table.tHead) return;
    const ths = Array.from(table.tHead.rows[0].cells);
    const KEY = 'vetpharm:recv_colw';
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { saved = {}; }
    const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(saved)); } catch (e) {} };
    ths.forEach((th, i) => {
        if (saved[i]) th.style.width = saved[i] + 'px';
        if (i === ths.length - 1) return;          // на колонці дій ручку не ставимо
        const h = document.createElement('span');
        h.className = 'col-resizer';
        th.appendChild(h);
        h.addEventListener('mousedown', (ev) => {
            ev.preventDefault(); ev.stopPropagation();
            const startX = ev.clientX;
            const startW = th.getBoundingClientRect().width;
            const onMove = (m) => {
                const w = Math.max(40, Math.round(startW + (m.clientX - startX)));
                th.style.width = w + 'px';
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                saved[i] = Math.round(parseFloat(th.style.width) || startW);
                persist();
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        // подвійний клік по ручці — скинути ширину цієї колонки
        h.addEventListener('dblclick', (ev) => {
            ev.preventDefault(); ev.stopPropagation();
            delete saved[i]; th.style.width = '';
            persist();
        });
    });
}

/* СПІЛЬНА накладна: підтягувати скани з телефона / інших пристроїв */
function startInvoicePoll() {
    setInterval(async () => {
        if (document.hidden) return;
        if (Date.now() - lastInvChange < 3500) return;     // щойно міняли тут
        if (document.querySelector('.modal:not([hidden])')) return;
        const ae = document.activeElement;                 // не чіпати, поки редагують
        if (ae && ae.closest && (ae.closest('#invoiceTable') || ae.closest('.invoice-head'))) return;
        const r = await apiGet('/api/invoice');
        if (!r || !r.ok || !r.invoice) return;
        const srv = Array.isArray(r.invoice.items) ? r.invoice.items : [];
        if (JSON.stringify(srv) !== JSON.stringify(invoiceItems)) {
            invoiceItems = srv;
            renderInvoice();
        }
    }, 3000);
}

document.addEventListener('DOMContentLoaded', async () => {
    initReceiveSplitter();
    initInvoiceColResize();
    const today = new Date().toISOString().slice(0, 10);
    applyVatModeUI();
    await restoreInvoice();                  // спільна накладна з сервера
    if (!receiptDateEl.value) receiptDateEl.value = today;
    if (!invoiceDateEl.value) invoiceDateEl.value = today;
    focusBarcode();
    recvSetPeriod(45);
    recvMarkPreset(45);
    loadRecent();
    startReceiptsPoll();
    loadSuppliers();
    loadProductsIndex();
    makeColumnsResizable('recentInTable', 'vetpharm:receive_invoices_cols');
    startInvoicePoll();
});
