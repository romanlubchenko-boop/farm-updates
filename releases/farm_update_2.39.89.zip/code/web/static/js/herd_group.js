/* Груповий ввід події: таблиця тварин ліворуч, форма події праворуч.
   Поля беруться з конструктора події (швидкий блок, обовʼязкові, вимкнені
   пропускаються). Проведення — тим самим /api/herd/apply-event-bulk.

   Роман 2026-09-16 («передивись форму і знайди недоліки»):
   • масовий запис показує ВІДМОВИ пооб'єктно — раніше «записано N» ховало
     тих, кому подія не підійшла (тільній не вносять осіменіння);
   • вибір поза фільтром видно окремим числом — інакше кнопка обіцяла 80,
     а в таблиці стояло 79;
   • перед записом — підтвердження зі зведенням: відкотити масову помилку
     можна лише по одній тварині;
   • відбирати можна за статтю, станом відтворення й днями після отелу —
     самої секції для групових робіт мало;
   • перемикач «Живі · Вибулі · Усі» у смужці гілки тепер керує і цим
     списком (доти стояв і не робив нічого). */
'use strict';

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}
(function () {

const $ = (id) => document.getElementById(id);
const LS_EVENT = 'herd:last_event';        // спільний із формою однієї тварини
const FLT_KEY = 'herd:filters';            // фільтри гілки (смужка стада)
const PAGE = 200;                          // скільки рядків малюємо за раз

let EVENTS = [], ANIMALS = [], CHOICES = {};
let PARAMS = [];                           // параметри тварини (з конструктора)
let APPLIED = new Set();                   // кому подію вже внесено цією датою
let sel = new Set();
let onlySel = false;
const URLQ = new URLSearchParams(location.search);
let curId = null;                          // тварина, виділена набором номера
let PLAN_KEY = '';                         // параметр «закріплений бик»
/* Фільтри налаштовує сама людина (Роман 2026-09-16: «я сам додаю параметр
   для фільтрації, можу видалити»). Кожен — {key, vals:[…]} для списків,
   {key, from, to} для чисел і дат, {key, text} для тексту. Набір свій у
   кожного користувача й лежить на сервері. */
/* ДОБІР ФОРМУЛОЮ (Роман 2026-09-22: «зроби, щоб формула працювала в
   груповому вводі»). Зі сторінки «Робота зі стадом» сюди приходить не
   готовий перелік номерів, а САМА формула рядком ?f=… — і список тут
   живий: додали тварину чи змінився параметр, і вона зʼявиться сама. */
let FX = null, FX_TEXT = new URLSearchParams(location.search).get('f') || '';
let FILTERS = null;
const DEFAULT_FILTERS = ['group', 'sex', 'repro_code', 'dim'];
/* Видимі колонки таблиці — окремо від фільтрів (Роман 2026-09-17: «таке саме
   налаштування колонок, як в останніх подіях»). Лише параметри конструктора;
   «name» (Кличка) малюємо прямо з тварини — вона вже є в списку. Новий фільтр сам додає свою колонку, а прибрати колонку
   можна лише в «⚙ Колонки» — фільтр і показ більше не звʼязані намертво. */
let COLS = null;
const NAME_COL = 'name';
let shown = PAGE;
let busy = false;

const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

/* «1 тварина · 2 тварини · 5 тварин» — числа в підписах читає людина, а не
   програма, тож рід і відмінок мають збігатися. */
function plural(n, one, few, many) {
    const a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b > 1 && b < 5) return few;
    if (b === 1) return one;
    return many;
}
const forAnimals = (n) => `${n} ${plural(n, 'тварини', 'тварин', 'тварин')}`;

const jget = (k) => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } };
const norm = (s) => String(s || '').toLowerCase().replace(/[\s ]+/g, '');

/* ─────────── завантаження ─────────── */
async function load(withEvents) {
    // Події — ПЕРШИМИ: без обраної події сервер не скаже, кому її вже
    // внесено обраною датою, і позначка «вже» не з'явилась би при відкритті.
    if (withEvents) {
        const [evd, fl] = await Promise.all([
            apiGet('/api/herd/events?active=1'),
            FILTERS ? null : apiGet('/api/herd/bulk-filters'),
        ]);
        if (!evd || !evd.ok) { toast((evd && evd.error) || 'Помилка', 'error'); return; }
        EVENTS = (evd.events || []).filter((e) => e.show_on_panel === undefined || e.show_on_panel);
        PARAMS = evd.params || [];
        window.HERD_CONSTS = evd.consts || [];   // назви налаштувань у формулі
        CHOICES = {};
        PARAMS.forEach((p2) => { CHOICES[p2.key] = p2.choices || []; });
        let want = '';
        try { want = localStorage.getItem(LS_EVENT) || ''; } catch (_) { /* ignore */ }
        // прийшли з календаря: ?event=<ключ події>&ids=… — подія й тварини вже обрані
        const fromEv = EVENTS.find((e) => e.key && e.key === URLQ.get('event'));
        if (fromEv) want = String(fromEv.id);
        $('hgEvent').innerHTML = EVENTS.map((e) =>
            `<option value="${e.id}"${String(e.id) === want ? ' selected' : ''}>`
            + `${escapeHtml(e.name)}</option>`).join('')
            || '<option value="">подій немає</option>';
        if (!FILTERS) {
            const saved = fl && fl.ok ? fl.filters : null;
            FILTERS = (saved || DEFAULT_FILTERS.map((key) => ({ key })))
                .filter((f) => paramOf(f.key));      // параметр могли прибрати
            const savedCols = fl && fl.ok ? fl.columns : null;
            // ще не налаштовували — показуємо як доти: кличка + колонки фільтрів
            COLS = (savedCols || [NAME_COL, ...FILTERS.map((x) => x.key)])
                .filter((k) => paramOf(k));          // лише параметри конструктора
        }
    }

    fxParse();
    const f = jget(FLT_KEY) || {};
    const p = new URLSearchParams();
    if (f.status) p.set('status', f.status);
    // значення, потрібні САМІЙ формулі, теж просимо — інакше добір мовчки
    // порахується по порожньому і покаже не тих тварин
    const need = [...new Set([...(FILTERS || []).map((x) => x.key),
                              ...(COLS || []).filter((k) => k !== NAME_COL),
                              ...((FX && FX.keys) || [])])];
    if (need.length) p.set('params', need.join(','));
    const ev = curEvent();
    if (ev) { p.set('event_id', ev.id); p.set('date', $('hgDate').value || todayISO()); }
    const an = await apiGet('/api/herd/animals/bulk?' + p.toString());
    if (!an || !an.ok) { toast((an && an.error) || 'Помилка', 'error'); return; }
    ANIMALS = an.items || [];
    APPLIED = new Set(an.applied_ids || []);
    PLAN_KEY = an.plan_sire_param || '';

    renderFilters();
    renderTable();
    if (withEvents) renderFields();
}

/* ─────────── фільтри ─────────── */
const paramOf = (key) => PARAMS.find((x) => x.key === key) || null;
const isNum = (pr) => ['int', 'float'].includes(pr.dtype);
const isDate = (pr) => pr.dtype === 'date';

function saveFilters() {
    clearTimeout(saveFilters.t);
    saveFilters.t = setTimeout(() => {
        apiSend('/api/herd/bulk-filters', 'POST', { filters: FILTERS })
            .then((r) => { if (!r || !r.ok) toast('Фільтри не збережено', 'error'); });
    }, 600);
}

function saveCols() {
    clearTimeout(saveCols.t);
    saveCols.t = setTimeout(() => {
        apiSend('/api/herd/bulk-filters', 'POST', { columns: COLS })
            .then((r) => { if (!r || !r.ok) toast('Колонки не збережено', 'error'); });
    }, 500);
}

// спільний модуль фільтрів (herd_filters.js) — той самий, що в календарі
const FLT = herdFilters({
    listEl: $('hfList'),
    addBtn: $('hfAdd'),
    params: () => PARAMS,
    choices: () => CHOICES,
    animals: () => ANIMALS,
    filters: () => FILTERS,
    onChange: async (kind, key) => {
        saveFilters();
        shown = PAGE;
        if (kind === 'add') {
            // відбираєш за параметром — одразу бачиш його значення
            if (!COLS.includes(key)) { COLS.push(key); saveCols(); }
            await load(false);
        } else {
            renderTable();                       // значення вже є — перезапит не потрібен
        }
    },
});
const renderFilters = () => FLT.render();

function filtered() {
    // «лише вибрані» показує ВСІХ вибраних, навіть поза фільтрами
    if (onlySel) return ANIMALS.filter((a) => sel.has(a.id));
    let out = ANIMALS.filter((a) => FLT.passesAll(a) && fxPasses(a));
    // порядок теж за формулою: список має виглядати так само, як там,
    // звідки його принесли (групування рядками-шапками тут не робимо)
    if (FX && window.herdQuery && (FX.sorts || FX.groups)) {
        const gs = FX.groups || [];
        const order = gs.map((k) => ({ key: k, dir: 'asc' }))
            .concat((FX.sorts || []).filter((sx) => !gs.includes(sx.key)));
        if (order.length) out = window.herdQuery.sortRows(out, order, PARAMS);
    }
    return out;
}

/* ─────────── добір формулою ─────────── */
function fxParse() {
    if (!FX_TEXT || !window.herdQuery || !PARAMS.length) { fxShow(); return; }
    const q = window.herdQuery.parse(FX_TEXT.replace(/^\s*=/, ''), PARAMS);
    if (!q || q.error) {
        toast('Формулу не зрозуміло: ' + ((q && q.error) || '—'), 'warn');
        FX = null; FX_TEXT = '';
    } else FX = q;
    fxShow();
}

/* Тварина з цієї формули? Додаткові блоки FILTER2(…) теж беремо — інакше
   кнопка «Груповий ввід · 56» вела б сюди, а подію внесли б лише 12
   (тут це перевірка по кожній тварині, тож повторів не буває). */
const fxPasses = (a) => {
    if (!FX) return true;
    if (window.herdQuery.passes(a, FX.filters)) return true;
    return (FX.extra || []).some((e) => e.filters && e.filters.length
        && window.herdQuery.passes(a, window.herdQuery.extraFilters(FX.filters, e.filters)));
};

function fxShow() {
    const box = $('hgFx');
    if (!box) return;
    box.hidden = !FX;
    if (!FX) return;
    box.innerHTML = `<span class="hg-fxt" title="${escapeHtml(FX_TEXT)}">`
        + `За формулою: ${escapeHtml(FX_TEXT)}</span>`
        + '<button type="button" class="hg-fxx" title="Показати все стадо">✕</button>';
}

function fxDrop() {
    FX = null; FX_TEXT = '';
    try {
        const u = new URL(location.href);
        u.searchParams.delete('f');
        history.replaceState(null, '', u.pathname + (u.search || ''));
    } catch (e) { /* ignore */ }
    fxShow();
    renderTable();
}

document.addEventListener('click', (e) => {
    if (e.target.closest('#hgFx .hg-fxx')) fxDrop();
});

/* як показати значення в клітинці */
function cellText(a, pr) {
    const raw = (a.p || {})[pr.key];
    if (raw === null || raw === undefined || raw === '') return '';
    if (pr.key === 'sex') return raw === 'M' ? '♂' : '♀';
    const num = numText(raw, pr.dtype);
    if (num !== null) return num;
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = pr.key === 'repro_code' ? '' : (a.pl || {})[pr.key];
    if (lbl) return lbl;
    if (isDate(pr) && /^\d{4}-\d{2}-\d{2}/.test(String(raw))) {
        const [y, m, d] = String(raw).slice(0, 10).split('-');
        return `${d}.${m}.${y}`;
    }
    // довгі номери (транспондер) — по три цифри, як у картці тварини
    if (/^\d{9,}$/.test(String(raw))) return String(raw).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
    return String(raw);
}

function row(a) {
    const done = APPLIED.has(a.id);
    const gone = a.status !== 'active';
    const cols = (COLS || []).map((k) => {
        if (k === NAME_COL) return `<td>${escapeHtml(a.name || '')}</td>`;
        const pr = paramOf(k);
        if (!pr) return '';
        const cls = (isNum(pr) || pr.key === 'sex') ? ' class="num"' : '';
        return `<td${cls}>${escapeHtml(cellText(a, pr))}</td>`;
    }).join('');
    return `<tr data-id="${a.id}" class="${sel.has(a.id) ? 'on' : ''}${gone ? ' is-gone' : ''}${a.id === curId ? ' hn-cur' : ''}">
        <td class="c"><input type="checkbox" ${sel.has(a.id) ? 'checked' : ''}${gone ? ' disabled' : ''}></td>
        <td class="tag">${escapeHtml(a.tag)}${done ? '<span class="hg-done" title="Цю подію вже внесено обраною датою">вже</span>' : ''}</td>
        ${cols}
        ${gone ? `<td class="hg-gonec">${escapeHtml(a.status_label || '')}</td>` : '<td></td>'}
    </tr>`;
}

/* шапка таблиці — за обраними колонками */
function renderHead() {
    const cols = (COLS || []).map((k) => {
        const pr = paramOf(k);
        if (!pr) return '';
        const cls = (isNum(pr) || pr.key === 'sex') ? ' class="c"' : '';
        // повна назва: скорочення конструктора (RC, DIM, GNDR) людині не кажуть нічого
        return `<th${cls}>${escapeHtml(pr.label)}</th>`;
    }).join('');
    $('hgHead').innerHTML = `<th class="c"><input type="checkbox" id="hgAll" title="Обрати всіх у доборі"></th>
        <th>${escapeHtml(herdLabel('tag', 'Номер тварини'))}</th>${cols}<th></th>`;
    $('hgAll').addEventListener('change', () => {
        const pick = filtered().filter((a) => a.status === 'active');
        const all = pick.length && pick.every((a) => sel.has(a.id));
        pick.forEach((a) => { if (all) sel.delete(a.id); else sel.add(a.id); });
        renderTable();
    });
}

function renderTable() {
    const list = filtered();
    renderHead();
    $('hgCount').textContent = list.length ? `· ${list.length}` : '';
    const part = list.slice(0, shown);
    const span = 3 + (COLS || []).length;
    $('hgBody').innerHTML = part.length ? part.map(row).join('')
        : `<tr><td colspan="${span}" class="hg-empty">Тварин за цим добором немає</td></tr>`;
    $('hgMore').hidden = list.length <= shown;
    $('hgMore').textContent = `Показати ще ${Math.min(PAGE, list.length - shown)} із ${list.length}`;

    $('hgBody').querySelectorAll('tr[data-id]').forEach((tr) => tr.addEventListener('click', (e) => {
        const id = +tr.dataset.id;
        const a = ANIMALS.find((x) => x.id === id);
        if (a && a.status !== 'active') {      // вибула — подію вносити нікуди
            toast('Тварина вибула зі стада — подія не вноситься', 'warn');
            const cb0 = tr.querySelector('input'); if (cb0) cb0.checked = false;
            return;
        }
        if (sel.has(id)) sel.delete(id); else sel.add(id);
        if (e.target.tagName !== 'INPUT') {
            const cb = tr.querySelector('input'); if (cb) cb.checked = sel.has(id);
        }
        tr.classList.toggle('on', sel.has(id));
        syncSel();
        focusNumber();
    }));

    const pick = list.filter((a) => a.status === 'active');
    const allOn = pick.length && pick.every((a) => sel.has(a.id));
    const someOn = pick.some((a) => sel.has(a.id));
    $('hgAll').checked = !!allOn;
    $('hgAll').indeterminate = !allOn && someOn;
    syncSel();
}

function curEvent() {
    const id = +($('hgEvent').value || 0);
    return EVENTS.find((e) => e.id === id) || null;
}

function inputControl(eff) {
    const ch = CHOICES[eff.param_key] || [];
    if (ch.length) {
        const isCod = eff.param_dtype === 'cod' || eff.param_dtype === 'code';
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) =>
            `<option value="${escapeHtml(c.value)}"${String(c.value) === String(eff.arg || '') ? ' selected' : ''}>`
            + `${escapeHtml(isCod ? c.label : `${i + 1}. ${c.label}`)}</option>`).join('');
        return `<select class="hg-in hg-input" data-key="${escapeHtml(eff.param_key)}"`
            + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}">${opts}</select>`;
    }
    const dt = eff.param_dtype;
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float') ? 'number' : 'text');
    const step = dt === 'float' ? ' step="0.01"' : '';
    return `<input type="${type}"${step} class="hg-in hg-input" data-key="${escapeHtml(eff.param_key)}"`
        + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}"`
        + (dt === 'multi' ? window.multiAttrs(dt, (paramOf(eff.param_key) || {}).vmin,
            (paramOf(eff.param_key) || {}).vmax) : ' placeholder="значення"')
        + ` value="${escapeHtml(eff.arg || '')}">`;
}

/* ГРОШІ ЗВʼЯЗАНІ між собою й тут — як у приході й на сторінці однієї тварини.
   Працює і в панелі «для всіх», і в кроковому опитуванні по кожній тварині:
   ціну задають спільну, вагу вводять кожній — суми рахуються самі. */
const MONEY_ROLES = ['qty', 'price_nv', 'sum_nv', 'vat', 'price_v', 'sum_v'];
const r4m = (x) => Math.round(x * 10000) / 10000;
const r2m = (x) => Math.round(x * 100) / 100;
function moneyRoleOf(key) {
    const p = (PARAMS || []).find((x) => x.key === key);
    const r = p && (p.money_role || '').trim();
    return MONEY_ROLES.includes(r) ? r : '';
}
function moneyFieldsIn(scope) {
    const out = {};
    (scope || document).querySelectorAll('.hg-input[data-key]').forEach((el) => {
        const role = moneyRoleOf(el.dataset.key);
        if (role) out[role] = el;
    });
    return out;
}
function mv(el) {
    if (!el) return null;
    const v = parseFloat(String(el.value || '').trim().replace(',', '.'));
    return isFinite(v) ? v : null;
}
function mset(el, v, dec) {
    if (!el || el === document.activeElement) return;
    el.value = (v === null || !isFinite(v)) ? '' : String(Number(v.toFixed(dec)));
}
function recalcMoneyIn(scope, changedRole) {
    const f = moneyFieldsIn(scope);
    if (!f.price_nv && !f.price_v && !f.sum_nv && !f.sum_v) return;
    const qty = mv(f.qty), vat = mv(f.vat);
    const k = 1 + (vat === null ? 0 : vat) / 100;
    let pnv = mv(f.price_nv), pv = mv(f.price_v);
    if (changedRole === 'sum_nv') {
        const s = mv(f.sum_nv); pnv = (s !== null && qty) ? r4m(s / qty) : pnv;
    } else if (changedRole === 'sum_v') {
        const s = mv(f.sum_v); pv = (s !== null && qty) ? r4m(s / qty) : pv;
        pnv = (pv !== null && k) ? r4m(pv / k) : pnv;
    } else if (changedRole === 'price_v') {
        pnv = (pv !== null && k) ? r4m(pv / k) : pnv;
    }
    if (pnv !== null) pv = r4m(pnv * k);
    else if (pv !== null) pnv = r4m(pv / k);
    mset(f.price_nv, pnv, 4);
    mset(f.price_v, pv, 4);
    mset(f.sum_nv, (qty !== null && pnv !== null) ? r2m(qty * pnv) : null, 2);
    mset(f.sum_v, (qty !== null && pv !== null) ? r2m(qty * pv) : null, 2);
}
document.addEventListener('input', (ev) => {
    const t = ev.target;
    if (!t || !t.dataset || !t.classList.contains('hg-input')) return;
    const role = moneyRoleOf(t.dataset.key);
    if (!role) return;
    recalcMoneyIn(t.closest('#hgStepBody') || t.closest('#hgInputs') || document, role);
});

/* Поле з умовою показується, лише коли умова справджується — так само, як
   на сторінці однієї тварини (у «Вибутті» покупець і сума лише для продажу). */
function applyFieldConds(effs) {
    (effs || []).forEach((eff) => {
        let c = null;
        try { c = JSON.parse(eff.cond || '{}'); } catch (e) { c = null; }
        if (!c || !c.if) return;
        const lab = document.querySelector(`#hgInputs .hg-f[data-field="${CSS.escape(eff.param_key)}"]`);
        if (!lab) return;
        const src = document.querySelector(`#hgInputs .hg-f[data-field="${CSS.escape(c.if)}"] .hg-in`);
        const raw = src ? String(src.value || '').trim() : '';
        const want = c.eq == null ? '' : String(c.eq);
        const op = c.op || 'eq';
        let on = false;
        if (raw) {
            if (op === 'eq') on = raw.toLowerCase() === want.toLowerCase();
            else if (op === 'ne') on = raw.toLowerCase() !== want.toLowerCase();
            else {
                const x = parseFloat(raw.replace(',', '.')), y = parseFloat(want.replace(',', '.'));
                if (isFinite(x) && isFinite(y)) on = { gt: x > y, ge: x >= y, lt: x < y, le: x <= y }[op] || false;
            }
        }
        lab.hidden = !on;   // значення лишаємо: серверна умова однаково
                            // не дасть його записати, а дефолт не зникне
    });
}
document.addEventListener('change', (ev) => {
    if (ev.target.closest && ev.target.closest('#hgInputs')) {
        const e2 = curEvent();
        applyFieldConds(e2 ? (e2.effects || []).filter((x) => x.mode === 'input') : []);
    }
});
function renderFields() {
    const ev = curEvent();
    try { if (ev) localStorage.setItem(LS_EVENT, String(ev.id)); } catch (_) { /* ignore */ }
    const effs = ev ? (ev.effects || []).filter((e) => e.mode === 'input'
        && (!('enabled' in e) || e.enabled)) : [];
    $('hgInputs').innerHTML = effs.map((eff) => `<label class="hg-f" data-field="${escapeHtml(eff.param_key)}">
        <span class="hg-lbl">${escapeHtml(eff.param_label)}${eff.required ? '<span class="hg-req"> *</span>' : ''}</span>
        ${inputControl(eff)}</label>`).join('');
    applyFieldConds(effs);      // поле з умовою («покупець» — лише для продажу)
    $('hgReqNote').textContent = effs.length
        ? 'Заповнене тут — одне для всіх. Порожнє запитаємо окремо по кожній тварині після «Зберегти».'
        : '';
    $('hgAuto').textContent = (ev && ev.births)
        ? `Приплід у груповому режимі не вноситься — подію «${ev.name}» вносьте на сторінці «Події».`
        : '';
    // право на подію видно ДО заповнення форми, а не після відмови сервера
    const denied = ev && ev.can_apply === false;
    $('hgDeny').textContent = denied ? 'Цю подію вам вносити не дозволено — зверніться до адміністратора.' : '';
    $('hgDeny').hidden = !denied;
    syncSel();
}

/* ─────────── вибір ─────────── */
function selStats() {
    const vis = new Set(filtered().map((a) => a.id));
    let inView = 0;
    sel.forEach((id) => { if (vis.has(id)) inView += 1; });
    return { total: sel.size, inView, outside: sel.size - inView };
}

/* Стрічка вибраних під полем номера. Роман 2026-09-23: «якщо буде 2000
   дійних і вводити по 100 голів на осіменіння, треба зручний метод
   відображення зафіксованих». Тому показуємо не все підряд, а ОСТАННІ
   набрані — саме їх людина звіряє на слух із зоотехніком; решта дивиться
   з таблиці кнопкою «показати всіх», яка вмикає режим «лише вибрані».
   У тому режимі стрічка згортається до лічильника: повний список і так
   перед очима, з колонками й галочками. */
const PICK_CAP = 300;            // більше цього списком не малюємо
let LAST_PICK = 0;               // щойно набрана — її підсвічуємо й підкручуємо
/* Порядок у «Зафіксованих» обирає людина (Роман 2026-09-23: «треба кнопку,
   чи сортувати, чи ні»): за номером — шукати оком; за вводом — бачити, як
   лягали набрані. Вибір памʼятається. */
let PICK_SORT = true;
try { PICK_SORT = localStorage.getItem('herd:pick_sort') !== 'add'; } catch (e) { /* ignore */ }
function pickSortBtn() {
    const b = $('hgPickSort');
    if (!b) return;
    b.textContent = PICK_SORT ? '⇅ за номером' : '⇅ за вводом';
    b.classList.toggle('is-on', PICK_SORT);
    b.setAttribute('aria-pressed', PICK_SORT ? 'true' : 'false');
}
/* Номер тварини як ключ сортування: спершу число на початку («1023»,
   «2824-2» → 2824), далі сам рядок — щоб «2824» стояло перед «2824-2». */
const tagKey = (t) => {
    const m = String(t || '').match(/^\d+/);
    return m ? Number(m[0]) : Number.MAX_SAFE_INTEGER;
};
function renderPicked() {
    const box = $('hnPicked');
    if (!box) return;
    const n = sel.size;
    pickSortBtn();               // напис на кнопці є й тоді, коли вибір порожній
    const cnt = $('hgPickN');
    if (cnt) cnt.textContent = n ? '· ' + n : '';
    const empty = $('hgPickEmpty');
    if (empty) empty.hidden = !!n;
    if (!n) { box.hidden = true; box.innerHTML = ''; return; }
    const by = new Map(ANIMALS.map((a) => [a.id, a]));
    // ЗА НОМЕРОМ (Роман 2026-09-23: «при додаванні одразу сортувати по
    // номеру») — так потрібну голову знаходиш оком, а не перечитуючи все.
    // Щойно додана не губиться: у неї руда рамка і колонка підкручується
    // до неї.
    const ids = PICK_SORT
        ? [...sel].sort((x, y) => {
            const ax = by.get(x), ay = by.get(y);
            const tx = ax ? ax.tag : String(x), ty = ay ? ay.tag : String(y);
            return (tagKey(tx) - tagKey(ty)) || String(tx).localeCompare(String(ty), 'uk');
        })
        : [...sel].reverse();                    // як набирали, остання згори
    const head = ids.slice(0, PICK_CAP);
    box.innerHTML = head.map((id) => {
        const a = by.get(id);
        const tag = a ? a.tag : ('№' + id);
        const nm = a && a.name ? ' · ' + a.name : '';
        return `<button type="button" class="hn-chip${id === LAST_PICK ? ' hn-new' : ''}"`
            + ` data-un="${id}" title="Прибрати з вибору">`
            + `<span class="hn-t">${escapeHtml(tag + nm)}</span><span class="hn-x">✕</span></button>`;
    }).join('') + (n > head.length
        ? `<span class="hn-rest">…і ще ${n - head.length} — дивіться «лише вибрані»</span>` : '');
    box.hidden = false;
    const cur = box.querySelector('.hn-new');
    if (cur) cur.scrollIntoView({ block: 'nearest' });
}

function syncSel() {
    renderPicked();
    const st = selStats();
    const ev = curEvent();
    const denied = ev && ev.can_apply === false;
    $('hgSelInfo').innerHTML = st.total
        ? `Вибрано <b>${st.total}</b>${st.outside
            ? ` · <span class="hg-warn">${st.outside} поза добором</span>` : ''}`
        : 'Нікого не вибрано';
    $('hgSelTools').hidden = !st.total;
    const done = [...sel].filter((id) => APPLIED.has(id)).length;
    $('hgSel').textContent = st.total
        ? (done ? `${done} із вибраних уже мають цю подію за обрану дату — запис повториться.`
            : '')
        : 'Оберіть тварин у таблиці зліва.';
    $('hgSubmit').disabled = !st.total || busy || denied;
    $('hgSubmit').textContent = busy ? 'Записую…'
        : denied ? 'Немає права на цю подію'
        : (st.total ? `Зберегти для ${forAnimals(st.total)}` : 'Позначте тварин у таблиці');
}

/* ─────────── запис ─────────── */
function summary(r, ev, n) {
    const failed = r.failed || [];
    const byReason = new Map();
    failed.forEach((f) => {
        // «№1001 (Ожина): стан …» → лишаємо саму причину.
        // ⚠️ \S+ тут жадібно ковтав і двокрапку, тож обрізалось по
        // «Дозволено зі станів:» — беремо все до ПЕРШОЇ двокрапки.
        const why = String(f.error || '').replace(/^№[^:]*:\s*/, '').trim();
        if (!byReason.has(why)) byReason.set(why, []);
        byReason.get(why).push(f.tag || ('#' + f.id));
    });
    const lines = [...byReason.entries()].map(([why, tags]) =>
        `<li><b>${tags.length}</b> — ${escapeHtml(why)}<span class="hg-tags">${
            escapeHtml(tags.slice(0, 12).join(', '))}${tags.length > 12 ? ' …' : ''}</span></li>`).join('');
    $('hgResult').hidden = false;
    $('hgResult').className = 'hg-result' + (failed.length ? ' has-fail' : '');
    $('hgResult').innerHTML =
        `<div class="hg-rhead">«${escapeHtml(ev.name)}» · записано <b>${r.applied || 0}</b> із ${n}</div>`
        + (failed.length
            ? `<div class="hg-rfail">Не записано ${failed.length}:</div><ul class="hg-rlist">${lines}</ul>`
              + '<div class="hg-rhint">Ці тварини лишились позначеними — виправте стан або зніміть вибір.</div>'
            : '');
}

/* поля події, які вносяться (увімкнені, режим «питати») */
function eventInputs(ev) {
    return ev ? (ev.effects || []).filter((e) => e.mode === 'input'
        && (!('enabled' in e) || e.enabled)) : [];
}

/* ⚠️ Від натискання «Зберегти» до відповіді сервера — замок. Доти прапорець
   `busy` ставився аж ПІСЛЯ вікна підтвердження, тож друге натискання встигало
   відкрити другий такий самий діалог; обидва чіпляли свій обробник на ту саму
   кнопку «Так», і ОДНЕ натискання «Так» відправляло ДВА записи. Саме так
   23.09.2026 три осіменіння лягли в базу по два рази. */
let saving = false;
async function submit() {
    if (saving) return;
    saving = true;
    try { await submitRun(); } finally { saving = false; syncSel(); }
}

async function submitRun() {
    const ev = curEvent();
    if (!ev) { toast('Оберіть подію', 'warn'); return; }
    if (!sel.size) { toast('Оберіть тварин', 'warn'); return; }

    // Заповнене в панелі — спільне для всіх. НЕзаповнене питаємо по кожній
    // тварині окремо (Роман 2026-09-17: «технік один на всіх, а різні
    // осіменіння і бугаї — щоб програма запитувала по кожній тварині»).
    const inputs = {};
    const ask = [];
    eventInputs(ev).forEach((eff) => {
        const el = document.querySelector(`#hgInputs .hg-input[data-key="${CSS.escape(eff.param_key)}"]`);
        if (el) el.closest('.hg-f').classList.remove('is-miss');
        const v = el ? String(el.value || '').trim() : '';
        if (v) inputs[eff.param_key] = v; else ask.push(eff);
    });

    let perAnimal = {};
    if (ask.length) {
        perAnimal = await askEach(ev, ask, inputs);
        if (!perAnimal) { $('hnInput').focus(); return; }       // людина скасувала
    }

    const date = $('hgDate').value || todayISO();
    if (!await confirmBulk(ev, date, inputs, ask)) return;

    busy = true; syncSel();
    const n = sel.size;
    // ⚠️ try/finally: на великій вибірці запит може впасти за таймаутом, і
    // без цього кнопка лишалась «Записую…» назавжди
    let r;
    try {
        r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: [...sel], event_id: ev.id, event_date: date,
            inputs, per_animal: perAnimal, note: ($('hgNote').value || '').trim(),
        });
    } finally {
        busy = false;
    }
    if (!r || !r.ok) { syncSel(); toast((r && r.error) || 'Помилка', 'error'); return; }

    summary(r, ev, n);
    const failedIds = new Set((r.failed || []).map((f) => f.id));
    sel = new Set([...sel].filter((id) => failedIds.has(id)));   // лишаємо проблемних
    STEP = null;                                                 // відповіді використано
    $('hgNote').value = '';
    const dup = (r.dupes || []).length;
    toast(failedIds.size
        ? `Записано ${r.applied} з ${n}, відхилено ${failedIds.size}`
        : (dup
            ? `${forAnimals(dup)} вже мали цю подію щойно — повтор пропущено`
            : `«${ev.name}» записано для ${forAnimals(r.applied || n)}`),
        (failedIds.size || dup) ? 'warn' : 'success');
    await load(false);         // стани тварин після події вже інші
    $('hnInput').focus();
}

/* текст значення так, як його бачить людина (для списку — назва варіанта) */
function shownValue(key, v) {
    const ch = CHOICES[key] || [];
    const c = ch.find((x) => String(x.value) === String(v));
    return c ? c.label : String(v);
}

/* ─────────── покроковий ввід ───────────
   Тварини по одній: «3 з 12 · 1119 Оксана», під нею поля, не задані для
   всіх. Відповіді памʼятаються: випадково закрили вікно й відкрили знову —
   введене на місці (поки не змінилися подія й вибір).

   Клавіатура (Роман 2026-09-17): Enter на полі ВІДКРИВАЄ список, стрілки
   обирають, Enter ФІКСУЄ і переводить на наступне питання; після
   останнього питання — наступна тварина. Нативний <select> так не вміє
   (відкрити його з коду не можна в усіх браузерах), тож список свій.

   Закріплений бик тварини підставляється в «Бик» і підписується під полем.
   Обрали іншого — під полем попередження, і перехід далі треба
   підтвердити ще одним Enter (як перепит у формі однієї тварини). */
let STEP = null;             // {sig, answers: {id: {key: value}}, confirmed: {id: true}}

const choiceText = (sel) => (sel.selectedOptions[0] ? sel.selectedOptions[0].textContent : '');

function planOf(a) {
    if (!PLAN_KEY) return null;
    const v = String(((a && a.p) || {})[PLAN_KEY] || '').trim();
    if (!v) return null;
    const lbl = ((a.pl || {})[PLAN_KEY]) || '';
    return { value: v, label: lbl ? `${v} — ${lbl}` : v };
}

/* список-замінник для <select>: кнопка з поточним значенням + спливний
   перелік під нею. Сам <select> лишається джерелом значення (прихований). */
function enhanceSelect(sel, onPicked) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'hgs-pick hg-in';
    btn.dataset.for = sel.dataset.key;
    const sync = () => {
        btn.textContent = sel.value ? choiceText(sel) : '— оберіть —';
        btn.classList.toggle('is-empty', !sel.value);
    };
    sel.hidden = true;
    sel.after(btn);
    sync();

    let list = null, act = 0, buf = '', bufT = null;
    const opts = () => [...sel.options].filter((o) => o.value !== '');
    const paint = () => {
        list.querySelectorAll('.hgs-opt').forEach((el, k) => el.classList.toggle('on', k === act));
        const cur = list.children[act];
        if (cur) cur.scrollIntoView({ block: 'nearest' });
    };
    const open = () => {
        if (list) return;
        const o = opts();
        list = document.createElement('div');
        list.className = 'hgs-list';
        list.innerHTML = o.map((x) => `<div class="hgs-opt">${escapeHtml(x.textContent)}</div>`).join('')
            || '<div class="hgs-none">Варіантів немає</div>';
        act = Math.max(0, o.findIndex((x) => x.value === sel.value));
        btn.after(list);
        btn.classList.add('is-open');
        list.querySelectorAll('.hgs-opt').forEach((el, k) => el.addEventListener('mousedown', (e) => {
            e.preventDefault(); act = k; pick();
        }));
        paint();
    };
    const close = () => {
        if (!list) return;
        list.remove(); list = null;
        btn.classList.remove('is-open');
    };
    const pick = () => {
        const o = opts()[act];
        if (o) { sel.value = o.value; sel.dispatchEvent(new Event('change')); }
        sync(); close();
        onPicked(btn);
    };
    btn.addEventListener('click', () => { if (list) close(); else open(); });
    btn.addEventListener('blur', () => setTimeout(close, 120));
    btn.addEventListener('keydown', (e) => {
        const o = opts();
        if (e.key === 'Enter') {
            e.preventDefault(); e.stopPropagation();
            if (list) pick(); else open();
        } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            if (!list) { open(); return; }
            act = Math.min(o.length - 1, Math.max(0, act + (e.key === 'ArrowDown' ? 1 : -1)));
            paint();
        } else if (e.key === 'Home' || e.key === 'End') {
            if (!list) return;
            e.preventDefault(); act = e.key === 'Home' ? 0 : o.length - 1; paint();
        } else if (e.key === 'Escape' && list) {
            e.preventDefault(); e.stopPropagation(); close();
        } else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
            // набір літер/цифр — до першого варіанта, що їх містить («мажор», «ура»)
            e.preventDefault();
            buf += e.key.toLowerCase();
            clearTimeout(bufT); bufT = setTimeout(() => { buf = ''; }, 900);
            if (!list) open();
            const k = o.findIndex((x) => x.textContent.toLowerCase().includes(buf));
            if (k >= 0) { act = k; paint(); }
        }
    });
    sel.addEventListener('change', sync);
    return btn;
}

function askEach(ev, ask, common) {
    return new Promise((resolve) => {
        const list = ANIMALS.filter((a) => sel.has(a.id));
        const sig = `${ev.id}|${ask.map((e) => e.param_key).join(',')}|${list.map((a) => a.id).join(',')}`;
        if (!STEP || STEP.sig !== sig) STEP = { sig, answers: {}, confirmed: {} };
        const answers = STEP.answers;
        const m = $('hgStep');
        let i = 0;

        const commonTxt = Object.entries(common).map(([k, v]) => {
            const eff = eventInputs(ev).find((e) => e.param_key === k);
            return `${escapeHtml((eff && eff.param_label) || k)} — <b>${escapeHtml(shownValue(k, v))}</b>`;
        }).join(' · ');

        const controls = () => [...$('hgStepBody').querySelectorAll('.hgs-pick, input.hg-input')];

        /* підпис під «Биком»: закріплений і чи збігається з обраним */
        const planNote = () => {
            const a = list[i];
            const plan = planOf(a);
            const bull = $('hgStepBody').querySelector('.hg-input[data-key="last_bull"]');
            if (!bull) return;
            const cell = bull.closest('.hg-f');
            let n = cell.querySelector('.hgs-plan');
            if (!plan) { if (n) n.remove(); return; }
            if (!n) { n = document.createElement('span'); n.className = 'hgs-plan'; cell.appendChild(n); }
            const v = String(bull.value || '').trim();
            const differs = v && v !== plan.value;
            n.classList.toggle('is-diff', !!differs);
            n.textContent = differs
                ? `Закріплено ${plan.label}, обрано ${shownValue('last_bull', v)}`
                  + (STEP.confirmed[a.id] ? ' — Enter ще раз, щоб підтвердити' : '')
                : `закріплено: ${plan.label}`;
        };

        const draw = () => {
            const a = list[i];
            const own = answers[a.id] || {};
            const plan = planOf(a);
            const meta = [a.group_name, (a.pl || {}).repro_code].filter(Boolean).map(escapeHtml).join(' · ');
            $('hgStepBody').innerHTML = `
                <div class="hgs-bar"><i style="width:${Math.round(((i + 1) / list.length) * 100)}%"></i></div>
                <div class="hgs-who">
                    <span class="hgs-tag">${escapeHtml(a.tag)}</span>
                    ${a.name ? `<span class="hgs-name">${escapeHtml(a.name)}</span>` : ''}
                    ${meta ? `<span class="hgs-meta">${meta}</span>` : ''}
                </div>
                <div class="hgs-fields">${ask.map((eff) => {
                    // закріплений бик — пропозиція, поки людина не обрала свого
                    let val = own[eff.param_key];
                    if (val === undefined && eff.param_key === 'last_bull' && plan) val = plan.value;
                    return `<div class="hg-f">
                        <span class="hg-lbl">${escapeHtml(eff.param_label)}${eff.required ? '<span class="hg-req"> *</span>' : ''}</span>
                        ${inputControl(Object.assign({}, eff, { arg: val || '' }))}</div>`;
                }).join('')}</div>
                ${commonTxt ? `<p class="hgs-common">Для всіх: ${commonTxt}</p>` : ''}`;
            // спільні гроші (ціна, ПДВ) — приховано, щоб суми рахувались і тут
            Object.entries(common).forEach(([k, v]) => {
                if (!moneyRoleOf(k)) return;
                const h = document.createElement('input');
                h.type = 'hidden'; h.className = 'hg-input'; h.dataset.key = k; h.value = v;
                $('hgStepBody').appendChild(h);
            });
            $('hgStepBody').querySelectorAll('select.hg-input').forEach((s2) => enhanceSelect(s2, advance));
            $('hgStepBody').querySelectorAll('input.hg-input').forEach((inp) =>
                inp.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); advance(inp); }
                }));
            const bull = $('hgStepBody').querySelector('.hg-input[data-key="last_bull"]');
            if (bull) bull.addEventListener('change', () => { delete STEP.confirmed[a.id]; planNote(); });
            planNote();
            recalcMoneyIn($('hgStepBody'), '');    // суми за вагою цієї тварини
            $('hgStepCount').textContent = `${i + 1} з ${list.length}`;
            $('hgStepBack').disabled = i === 0;
            $('hgStepNext').textContent = i === list.length - 1 ? 'Готово' : 'Далі →';
            const first = controls()[0];
            if (first) setTimeout(() => first.focus(), 20);
        };

        /* зафіксували поле — на наступне питання; після останнього — далі */
        const advance = (from) => {
            const cs = controls();
            const k = cs.indexOf(from);
            if (k >= 0 && k < cs.length - 1) { cs[k + 1].focus(); return; }
            next();
        };

        const keep = () => {
            const a = list[i];
            const own = {};
            $('hgStepBody').querySelectorAll('.hg-input').forEach((el) => {
                const v = String(el.value || '').trim();
                if (v) own[el.dataset.key] = v;
            });
            answers[a.id] = own;
        };

        const next = () => {
            keep();
            const a = list[i];
            let miss = null;
            $('hgStepBody').querySelectorAll('.hg-input').forEach((el) => {
                const f = el.closest('.hg-f');
                const bad = el.dataset.req === '1' && !String(el.value || '').trim();
                f.classList.toggle('is-miss', bad);
                if (bad && !miss) miss = f.querySelector('.hgs-pick') || el;
            });
            if (miss) { miss.focus(); return; }
            // обрали не закріпленого бика — один перепит, але не заборона
            const plan = planOf(a);
            const bullV = String((answers[a.id] || {}).last_bull || '').trim();
            if (plan && bullV && bullV !== plan.value && !STEP.confirmed[a.id]) {
                STEP.confirmed[a.id] = true;          // наступний Enter уже проходить
                planNote();
                $('hgStepNext').focus();
                return;
            }
            if (i < list.length - 1) { i += 1; draw(); return; }
            close(answers);
        };
        const back = () => { keep(); if (i > 0) { i -= 1; draw(); } };

        const onKey = (e) => {
            if (e.key === 'Escape') { e.preventDefault(); keep(); close(null); return; }
            // Enter поза полями (на «Далі», «Назад» чи в порожньому місці вікна)
            // обробляємо самі: натискання Enter на кнопці не в кожному
            // браузері стає кліком, а потік має бути суцільно з клавіатури.
            // Поля й список свій Enter перехоплюють раніше (stopPropagation).
            if (e.key !== 'Enter') return;
            e.preventDefault();
            if (document.activeElement === $('hgStepBack')) back(); else next();
        };
        const onCancel = () => { keep(); close(null); };
        const close = (val) => {
            m.hidden = true;
            m.removeEventListener('keydown', onKey);
            document.removeEventListener('keydown', escAny);
            $('hgStepNext').removeEventListener('click', next);
            $('hgStepBack').removeEventListener('click', back);
            m.querySelectorAll('[data-close]').forEach((b) => b.removeEventListener('click', onCancel));
            resolve(val);
        };

        // ⚠️ Слухача НА САМІЙ модалці мало: спільний обробник у app.js ховає
        // вікно на Escape звідусіль, і якщо фокус був поза вікном (клік по
        // заголовку чи смужці поступу), обіцянка не завершувалась — замок
        // `saving` лишався зведеним, кнопка «Зберегти» вмирала до
        // перезавантаження. Той самий капкан уже ловили в confirmBulk.
        // ⚠️ БЕЗ перевірки `m.hidden`! Спільний обробник у app.js зареєстрований
        // РАНІШЕ і спрацьовує ПЕРШИМ — він уже сховав вікно, тож умова
        // «доки видно» знешкоджувала сам захист. Саме так замок лишався
        // зведеним і кнопка «Зберегти» вмирала. confirmBulk здоровий тому,
        // що його esc такої умови не має.
        const escAny = (e) => { if (e.key === 'Escape') { keep(); close(null); } };
        m.addEventListener('keydown', onKey);
        document.addEventListener('keydown', escAny);
        $('hgStepNext').addEventListener('click', next);
        $('hgStepBack').addEventListener('click', back);
        m.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', onCancel));
        m.hidden = false;
        draw();
    });
}

/* Підтвердження: масовий запис відкочується лише по одній тварині, тож
   перед ним людина має побачити, що саме зараз станеться. */
function confirmBulk(ev, date, inputs, ask) {
    return new Promise((resolve) => {
        const m = $('hgConfirm');
        // друге таке саме вікно поверх першого — це подвійне натискання;
        // якби обидва дочекались «Так», пішло б два однакові записи
        if (!m.hidden) { resolve(false); return; }
        const vals = Object.entries(inputs).map(([k, v]) => {
            const el = document.querySelector(`#hgInputs [data-key="${CSS.escape(k)}"]`);
            const lbl = (el && el.dataset.label) || k;
            const txt = (el && el.tagName === 'SELECT' && el.selectedOptions[0])
                ? el.selectedOptions[0].textContent.trim() : v;
            return `<li>${escapeHtml(lbl)}: <b>${escapeHtml(txt)}</b></li>`;
        }).join('')
            + ((ask && ask.length)
                ? `<li>Окремо для кожної тварини: <b>${ask.map((e) => escapeHtml(e.param_label)).join(', ')}</b></li>`
                : '');
        const done = [...sel].filter((id) => APPLIED.has(id)).length;
        $('hgConfirmBody').innerHTML =
            `<p class="hg-cq">Записати «<b>${escapeHtml(ev.name)}</b>» для <b>${forAnimals(sel.size)}</b>?</p>`
            + `<ul class="hg-clist"><li>Дата: <b>${escapeHtml(date)}</b></li>${vals}</ul>`
            + (done ? `<p class="hg-cwarn">${done} із них уже мають цю подію за цю дату — буде запис-дубль.</p>` : '')
            + '<p class="hg-chint" data-ins="2">Скасувати масовий запис однією дією не можна — '
            + 'подію доведеться прибирати з картки кожної тварини.</p>';
        m.hidden = false;
        const off = (val) => {
            m.hidden = true;
            m.querySelectorAll('[data-close]').forEach((b) => b.removeEventListener('click', no));
            $('hgConfirmOk').removeEventListener('click', yes);
            document.removeEventListener('keydown', esc);
            resolve(val);
        };
        const yes = () => off(true);
        const no = () => off(false);
        // ⚠️ Escape ховає БУДЬ-ЯКУ відкриту модалку спільним обробником у
        // app.js, обіцянки він не знає. Без цього рядка обіцянка не
        // завершувалась ніколи, замок `saving` лишався зведеним — і кнопка
        // «Зберегти» вмирала до перезавантаження сторінки.
        // 📌 ПРАВИЛО: обіцянка, що чекає на вікно, мусить мати відповідь на
        // КОЖЕН спосіб його закрити, не лише на свої кнопки.
        const esc = (e) => { if (e.key === 'Escape') no(); };
        m.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', no));
        $('hgConfirmOk').addEventListener('click', yes);
        document.addEventListener('keydown', esc);
    });
}

/* ─────────── ввід за номером ───────────
   Роман 2026-09-17: «вводити номера, нажимати Enter — і в списку біля цього
   номера ставиться галочка. Фокус не змінюється, завжди в полі номера».
   Номер шукаємо серед усіх завантажених тварин (не лише у видимому доборі):
   спершу точний збіг бирки чи UIN/транспондера, потім унікальний «хвіст» —
   так досить останніх цифр із нашийника чи сканера. */
function findByNumber(raw) {
    const q = norm(raw);
    if (!q) return { list: [] };
    const nums = (a) => [a.tag, ...String(a.search || '').split(/\s+/)].map(norm).filter(Boolean);
    const exact = ANIMALS.filter((a) => nums(a).some((n) => n === q));
    if (exact.length) return { list: exact, exact: true };
    const tail = ANIMALS.filter((a) => nums(a).some((n) => n.endsWith(q)));
    if (tail.length) return { list: tail, exact: false };
    // номера немає — пробуємо кличку: поле одне, окремого пошуку не тримаємо
    // (Роман 2026-09-17: «нащо два поля пошуку? прагнемо мінімалізму»)
    const byName = ANIMALS.filter((a) => norm(a.name) === q);
    if (byName.length) return { list: byName, exact: true };
    return { list: ANIMALS.filter((a) => norm(a.name).startsWith(q)), exact: false };
}

function numberMsg(text, kind) {
    const m = $('hnMsg');
    m.textContent = text;
    m.className = 'hn-msg' + (kind ? ' ' + kind : '');
    $('hnInput').classList.toggle('is-err', kind === 'err');
}

function focusNumber() {
    const inp = $('hnInput');
    // не відбираємо фокус, якщо людина саме заповнює поля події чи фільтр
    const act = document.activeElement;
    if (act && act !== document.body && act !== inp
        && act.closest('.hg-form, .hf-bar, .hf-pop, .hp-head, #hgConfirm, .hg-selbar')) return;
    inp.focus();
}

function markByNumber() {
    const inp = $('hnInput');
    const raw = inp.value.trim();
    if (!raw) return;
    const { list } = findByNumber(raw);
    if (!list.length) {
        curId = null;
        numberMsg(`№ ${raw} не знайдено`, 'err');
        inp.select();                                // одразу набрати правильний
        return;
    }
    if (list.length > 1) {
        const tags = list.slice(0, 4).map((a) => a.tag).join(', ');
        numberMsg(`Під «${raw}» ${list.length} тварин (${tags}${list.length > 4 ? '…' : ''}) — уточніть номер`, 'err');
        inp.select();
        return;
    }
    const a = list[0];
    const who = `${a.tag}${a.name ? ' ' + a.name : ''}`;
    if (a.status !== 'active') {
        numberMsg(`${who} вибула зі стада — подія не вноситься`, 'err');
        inp.select();
        return;
    }
    if (sel.has(a.id)) {             // на сотні голів повтор трапляється легко
        inp.value = '';
        numberMsg(`${who} вже у списку`, 'mute');
        showRow(a.id);
        inp.focus();
        return;
    }
    inp.value = '';
    // успіх не підписуємо: галочка й спалах рядка вже все показують, а
    // лічильник вибору (і «поза добором») стоїть над таблицею.
    // Повідомлення лишаються лише для помилок (Роман 2026-09-17).
    numberMsg('', '');
    sel.add(a.id);
    LAST_PICK = a.id;
    curId = null;                                    // виділення переходить у галочку
    // рядок має бути намальований, щоб показати галочку
    const idx = filtered().findIndex((x) => x.id === a.id);
    if (idx >= shown) shown = idx + PAGE;
    renderTable();
    showRow(a.id);
    inp.focus();
}

/* Під час набору тварина ВИДІЛЯЄТЬСЯ в списку, а галочка ставиться лише
   на Enter (Роман 2026-09-17: «при виборі тварини виділити її в списку,
   потім при натисканні Enter ставити галочку»). Виділяємо тільки
   однозначний збіг — поки під набраним кілька тварин, рядок не стрибає. */
function highlightByNumber() {
    const inp = $('hnInput');
    const raw = inp.value.trim();
    const { list } = raw ? findByNumber(raw) : { list: [] };
    const a = list.length === 1 ? list[0] : null;
    const was = curId;
    curId = a ? a.id : null;
    $('hgBody').querySelectorAll('tr.hn-cur').forEach((tr) => tr.classList.remove('hn-cur'));
    if (inp.classList.contains('is-err')) numberMsg('', '');
    if (!a) { numberMsg('', ''); return; }
    const idx = filtered().findIndex((x) => x.id === a.id);
    if (idx < 0) {
        // у таблиці її не видно — інакше людина не зрозуміє, чому нічого не виділилось
        numberMsg(`${a.tag} не входить у поточний добір`, 'mute');
        return;
    }
    numberMsg('', '');
    // із запасом рядків після знайденого — інакше він останній у таблиці
    // й підняти його під шапку нікуди
    if (idx >= shown) { shown = idx + PAGE; renderTable(); }
    const tr = $('hgBody').querySelector(`tr[data-id="${a.id}"]`);
    if (!tr) return;
    tr.classList.add('hn-cur');
    if (was !== curId) scrollToRow(tr);
}

/* Знайдений рядок ставимо ПЕРШИМ під шапкою таблиці — тобто одразу під
   полем номера, куди людина й дивиться. ⚠️ Центрувати в блоці таблиці не
   можна: блок буває вищий за видиму частину вікна, і рядок опинявся нижче
   краю екрана. Прокручується лише таблиця, сторінка стоїть. */
function scrollToRow(tr) {
    const wrap = tr.closest('.hg-tblwrap');
    if (!wrap) return;
    const head = wrap.querySelector('thead');
    const top = tr.offsetTop - (head ? head.offsetHeight : 0) - 4;
    wrap.scrollTop = Math.max(0, top);
}

function showRow(id) {
    const tr = $('hgBody').querySelector(`tr[data-id="${id}"]`);
    if (!tr) return;
    scrollToRow(tr);
    tr.classList.remove('hn-flash');
    void tr.offsetWidth;                             // перезапуск спалаху
    tr.classList.add('hn-flash');
}

/* ─────────── події сторінки ─────────── */
/* клік по пігулці — зняти цю тварину з вибору */
$('hgPickSort').addEventListener('click', () => {
    PICK_SORT = !PICK_SORT;
    try { localStorage.setItem('herd:pick_sort', PICK_SORT ? 'tag' : 'add'); } catch (e) { /* ignore */ }
    renderPicked();
    $('hnInput').focus();
});

$('hnPicked').addEventListener('click', (e) => {
    const b = e.target.closest('[data-un]');
    if (!b) return;
    sel.delete(+b.dataset.un);
    if (LAST_PICK === +b.dataset.un) LAST_PICK = 0;
    renderTable();
    syncSel();
    $('hnInput').focus();
});

$('hnInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); markByNumber(); }
});
$('hnInput').addEventListener('input', highlightByNumber);
$('hgMore').addEventListener('click', () => { shown += PAGE; renderTable(); });
// «⚙ Колонки» — спільний компонент гілки (herd_colpicker.js)
herdColPicker({
    button: $('hfCols'),
    params: () => PARAMS,
    hide: ['tag'],
    selected: () => COLS || [],
    onToggle: async (k, on) => {
        if (on) { if (!COLS.includes(k)) COLS.push(k); }
        else COLS = COLS.filter((x) => x !== k);
        saveCols();
        // значень нового параметра в завантаженому списку ще немає
        const missing = on && k !== NAME_COL
            && ANIMALS.length && !Object.prototype.hasOwnProperty.call(ANIMALS[0].p || {}, k);
        if (missing) await load(false); else renderTable();
    },
});
$('hgOnlySel').addEventListener('click', () => {
    onlySel = !onlySel;
    $('hgOnlySel').classList.toggle('on', onlySel);
    $('hgOnlySel').textContent = onlySel ? 'показати всіх' : 'лише вибрані';
    shown = PAGE;
    renderTable();
});
$('hgClearSel').addEventListener('click', () => {
    sel = new Set();
    numberMsg('', '');
    if (onlySel) $('hgOnlySel').click(); else renderTable();
    $('hnInput').focus();
});
$('hgEvent').addEventListener('change', () => { renderFields(); load(false); });
$('hgDate').addEventListener('change', () => load(false));
$('hgSubmit').addEventListener('click', submit);

$('hgDate').value = todayISO();
$('hgDate').max = todayISO();          // майбутньою датою події не вносять

// перемикач «Живі · Вибулі · Усі» у смужці гілки керує і цим списком
window.herdRegistry = { reload: () => load(false) };

load(true).then(() => {
    const ids = (URLQ.get('ids') || '').split(',').map(Number).filter(Boolean);
    if (ids.length) {
        const have = new Set(ANIMALS.map((a) => a.id));
        sel = new Set(ids.filter((id) => have.has(id)));
        history.replaceState(null, '', location.pathname);   // оновлення сторінки не повторює добір
        if (sel.size && !onlySel) $('hgOnlySel').click(); else renderTable();
    } else if (FX) {
        // прийшли з формулою: увесь її добір ОДРАЗУ відмічений — саме по ньому
        // людина сюди й ішла; зайвих знімають на місці. Вибулих не чіпаємо —
        // їм подію вносити нікуди.
        sel = new Set(filtered().filter((a) => a.status === 'active').map((a) => a.id));
        renderTable();
        syncSel();
    }
    $('hnInput').focus();
});
})();
