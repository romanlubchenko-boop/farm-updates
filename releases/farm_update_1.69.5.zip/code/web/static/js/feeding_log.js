/* Рух годівлі по секціях — патерн «майстер-рядок → підпанель» як у надходженнях.
   Секція (майстер) → розкриття «Дні годівлі» → розкриття «Завантажені корми».
   Дані прямо зі звітів Profeed (feeding_tree). Молоко вводиться вручну. */

const $ = (id) => document.getElementById(id);
/* Формат як у виробництві комбікорму: групування розрядів, без примусових
   нулів (1 155, а не 1 155,0). d — максимум знаків після коми. */
const fmt = (n, d = 1) => (n == null || n === '' ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: 0, maximumFractionDigits: d }));
const money = (n) => (n == null ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
/* Спожито ₴ (гроші йдуть за кормом): consumed_sum + бейдж переносу залишку.
   +X — отримано із залишків інших груп, −X — віддано в залишки. */
function moneyConsumed(o) {
    const cs = (o.consumed_sum != null) ? o.consumed_sum
        : (o.sum != null ? o.sum : o.ration_sum);
    return money(cs);
}
/* Перенос ₴: +отримано із залишків / −віддано в залишки (окрема колонка) */
function moneyTransfer(o) {
    let b = '';
    if (o.refed_in_sum) b += `<span class="fl-disp-badge" title="Отримано із залишків інших груп, ₴">+${money(o.refed_in_sum)}</span>`;
    if (o.leftover_sum) b += `<span class="fl-disp-badge fl-give" title="Віддано в залишки, ₴">−${money(o.leftover_sum)}</span>`;
    return b || '—';
}
/* Дві комірки: вартість корму за кг (вартість завантаженого ÷ завантажено)
   і на голову (вартість завантаженого ÷ голів/голово-дні). */
function feedPriceCells(sumV, loadedV, headsV) {
    const s = sumV || 0;
    return `<td class="num">${loadedV ? money(s / loadedV) : '—'}</td>`
        + `<td class="num">${headsV ? money(s / headsV) : '—'}</td>`;
}
/* Відхилення завантаження — рівно 1 знак після коми (0,0) */
const fmtDev = (n) => (n == null || n === '' ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: 1, maximumFractionDigits: 1 }));
/* Ціна без ПДВ — 4 знаки після коми */
const price4 = (n) => (n == null ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: 4, maximumFractionDigits: 4 }));
/* Кількість завантаження — до 4 знаків після коми (без зайвих нулів) */
const fmt4 = (n) => (n == null || n === '' ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: 0, maximumFractionDigits: 4 }));

let sections = [];
let disposalKg = 0, disposalSum = 0;   // утилізація залишків: кг та збиток ₴
let treeConsumedTotal = null;          // канонічний підсумок «Спожито ₴» (секції)
let treeLeftTotal = null, treeRefedTotal = null;   // канонічні ± переносу (Разом)
let usageConsumedTotal = null;         // канонічний підсумок «Спожито ₴» (секції стада)
let usageCatsConsumedTotal = null;     // «Спожито ₴» для «По категоріях» (+ ручна годівля)
let usageLeftTotal = null, usageRefedTotal = null;   // канонічні ± переносу (Разом)

// «Разом»: показуємо канонічний підсумок, АЛЕ якщо він різниться від суми
// округлених видимих рядків лише на копійку (артефакт округлення прихованих
// ~0 рядків) — показуємо суму рядків, щоб «Разом» дорівнював видимим рядкам.
function canonTotal(rowsVal, canonVal) {
    if (canonVal == null) return rowsVal;
    return Math.abs(canonVal - (rowsVal || 0)) <= 0.011 ? (rowsVal || 0) : canonVal;
}
let tmrOn = false;           // показувати загальнозмішаний раціон замість інгредієнтів
const openSec = new Set();   // назви розкритих секцій
const openDay = new Set();   // ключі "секція|дата" розкритих днів
const KEY_TMR = 'farm:fl_tmr';

async function loadTree() {
    const from = $('flFrom').value || '';
    const to = $('flTo').value || '';
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    let r;
    try { r = await apiGet('/api/feed/feeding-tree?' + qs.toString()); }
    catch (e) { r = { ok: false, error: 'Сервер не відповів (можливо, потрібен перезапуск)' }; }
    if (!r || !r.ok) {
        $('flBody').innerHTML = `<tr><td colspan="24" class="empty">${escapeHtml((r && r.error) || (r && r.note) || 'Помилка')}</td></tr>`;
        return;
    }
    sections = r.sections || [];
    disposalKg = r.disposal_kg || 0;
    disposalSum = r.disposal_sum || 0;
    treeConsumedTotal = (r.total_consumed_sum != null) ? r.total_consumed_sum : null;
    treeLeftTotal = (r.total_leftover_sum != null) ? r.total_leftover_sum : null;
    treeRefedTotal = (r.total_refed_in_sum != null) ? r.total_refed_in_sum : null;
    const secLoaded = sections.reduce((s, x) => s + (x.loaded || 0), 0);
    $('flDiag').textContent = sections.length
        ? (`Секцій: ${sections.length} · Витрата: ${fmt(secLoaded)} кг`) : '';
    render();
    if (window.makeColumnsResizable) makeColumnsResizable('flTable', 'farm:fl_cols');
    renderKpi();
    renderAttention(r.pool_kg || {}, r.pool_dest || {});
    loadLeftPanel();
    loadUsage();
    loadIngUsage();
    loadProdIngredient();
}

/* ===== Виробництво комбікорму — розхід кормів (секція в таблиці «По кормах») ===== */
let prodIng = [];               // корми-компоненти виробництва КК за період
const openProdIng = new Set();  // розкриті корми виробництва (ключ = name|code)
async function loadProdIngredient() {
    const from = $('flFrom').value || '', to = $('flTo').value || '';
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    let r;
    try { r = await apiGet('/api/feed/production-by-ingredient?' + qs.toString()); }
    catch (e) { r = null; }
    prodIng = (r && r.ok) ? (r.items || []) : [];
    renderIngUsage();   // перемалювати «По кормах» разом із секцією виробництва
}

/* ===== Аналітичні картки зверху ===== */
function kpiAccCls(v) {
    if (v == null) return '';
    if (v >= 95) return 'k-ok';
    if (v >= 90) return 'k-warn';
    return 'k-bad';
}
function kpiCard(cap, val, sub, valCls, accent) {
    return `<div class="fl-kpi-card${accent ? ' k-accent' : ''}">
        <span class="k-cap">${cap}</span>
        <span class="k-val ${valCls || ''}">${val}</span>
        ${sub ? `<span class="k-sub">${sub}</span>` : ''}</div>`;
}
function renderKpi() {
    const el = $('flKpi');
    if (!el) return;
    const cards = [];
    if (sections && sections.length) {
        const t = secTotals(sections);
        cards.push(kpiCard('Точність завантаження',
            t.accuracy == null ? '—' : fmt(t.accuracy) + '%', '', kpiAccCls(t.accuracy), true));
        cards.push(kpiCard('Точність розвантаження',
            t.acc_dist == null ? '—' : fmt(t.acc_dist) + '%', '', kpiAccCls(t.acc_dist), true));
    }
    if (disposalKg > 0 || disposalSum > 0) {
        cards.push(kpiCard('Утилізація (збиток)',
            money(disposalSum) + ' ₴', fmt(disposalKg) + ' кг за період', 'k-bad', true));
    }
    if (cats && cats.length) {
        // конверсія — перша лактуюча підкатегорія з даними надою
        let convDone = false;
        cats.forEach((c) => (c.subs || []).forEach((sb) => {
            if (sb.conv != null && !convDone) {
                cards.push(kpiCard('Конверсія корму', fmt(sb.conv, 2),
                    'молоко/СР · ' + escapeHtml(sb.subgroup), '', true));
                convDone = true;
            }
        }));
        // СР/гол по кожній підкатегорії. Для ДІЙНИХ поголів'я беремо з управління
        // стада (герд-облік d_cow), а не з Profeed-годівлі.
        cats.forEach((c) => (c.subs || []).forEach((sb) => {
            if (sb.dry_head == null) return;
            const isDairy = /дійн/i.test(sb.subgroup || '');
            let dryHead = sb.dry_head, milkHead = sb.milk_head;
            if (isDairy && herdCowDays > 0) {
                dryHead = (sb.dry || 0) / herdCowDays;
                milkHead = (sb.milk != null) ? (sb.milk / herdCowDays) : sb.milk_head;
            }
            const sub = milkHead != null
                ? ('молоко/гол ' + fmt(milkHead) + ' кг' + (isDairy ? ' · упр. стада' : ''))
                : escapeHtml(c.category);
            cards.push(kpiCard('СР/гол · ' + escapeHtml(sb.subgroup),
                fmt(dryHead, 2) + ' кг', sub, ''));
        }));
    }
    el.innerHTML = cards.join('');
}

/* ===== По категоріях і підкатегоріях (той самий період) ===== */
let cats = [];
let herdCowDays = 0;   // голово-дні дійних з управління стада за період
const openCat = new Set();
const openSub = new Set();   // ключі "категорія|підкатегорія"
const openDayU = new Set();  // ключі "категорія|підкатегорія|дата"

async function loadUsage() {
    const from = $('flFrom').value || '';
    const to = $('flTo').value || '';
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    let r;
    try { r = await apiGet('/api/feed/usage-by-category?' + qs.toString()); }
    catch (e) { r = { ok: false, error: 'Сервер не відповів' }; }
    if (!r || !r.ok) {
        $('fuBody').innerHTML = `<tr><td colspan="21" class="empty">${escapeHtml((r && (r.error || r.note)) || 'Помилка')}</td></tr>`;
        return;
    }
    cats = r.categories || [];
    herdSecs = r.herd_sections || [];
    // голово-дні дійних з управління стада (для СР/гол та молоко/гол на дійну)
    herdCowDays = 0;
    try {
        const hq = new URLSearchParams();
        if (from) hq.set('from', from);
        if (to) hq.set('to', to);
        const hr = await apiGet('/api/herd/cowdays?' + hq.toString());
        if (hr && hr.ok) herdCowDays = +hr.cowdays || 0;
    } catch (e) { /* без герд-даних лишаємо feeding heads */ }
    usageConsumedTotal = (r.total_consumed_sum != null) ? r.total_consumed_sum : null;
    usageCatsConsumedTotal = (r.total_consumed_cats_sum != null)
        ? r.total_consumed_cats_sum : usageConsumedTotal;
    usageLeftTotal = (r.total_leftover_sum != null) ? r.total_leftover_sum : null;
    usageRefedTotal = (r.total_refed_in_sum != null) ? r.total_refed_in_sum : null;
    // У шапці показуємо ЗАВАНТАЖЕНО (витрата зі складу) — щоб число збігалося
    // з панеллю «По кормах». Спожито (після залишків) є в колонках таблиці.
    const catLoaded = cats.reduce((s, c) => s + (c.loaded || 0), 0);
    $('fuDiag').textContent = cats.length
        ? ('Витрата: ' + fmt(catLoaded) + ' кг') : (r.note || '');
    renderUsage();
    renderHerdSecs();
    if (window.makeColumnsResizable) makeColumnsResizable('fuTable', 'farm:fu_cols');
    if (window.makeColumnsResizable) makeColumnsResizable('hsTable', 'farm:hs_cols');
    renderKpi();
}

let herdSecs = [];
const openHS = new Set();      // розкриті секції стада
const openHSDay = new Set();   // ключі "секція|дата" — розкриті корми дня

function hsDaysTable(s, hi) {
    const rows = (s.days || []).map((d, di) => {
        const isOpen = openHSDay.has(s.section + '|' + d.date);
        const row = `<tr>
            <td class="fu-toggle-cell"><button class="batch-toggle" data-hsday="${hi}:${di}"
                title="Завантажені корми">${isOpen ? '▾' : '▸'}</button></td>
            <td>${escapeHtml(d.date)}</td>${fuCells(d)}</tr>`;
        const det = isOpen ? `<tr><td colspan="21">${usageDayIng(d)}</td></tr>` : '';
        return row + det;
    }).join('');
    return `<div class="batch-box" style="display:inline-block">
        <div class="batch-box-title">По датах — ${escapeHtml(s.section)}</div>
        <table class="batch-table fu-sub-tbl">
            <thead><tr><th style="width:22px;"></th><th>Дата</th>${FU_HEAD}</tr></thead>
            <tbody>${rows}</tbody></table></div>`;
}

function renderHerdSecs() {
    const body = $('hsBody');
    if (!body) return;
    if (!herdSecs.length) {
        body.innerHTML = '<tr><td colspan="21" class="empty">Немає прив’язаних секцій стада</td></tr>';
        if ($('hsDiag')) $('hsDiag').textContent = '';
        return;
    }
    const rows = herdSecs.map((s, hi) => {
        const isOpen = openHS.has(s.section);
        const master = `<tr class="fu-cat-row inv-row">
            <td class="fu-toggle-cell"><button class="batch-toggle" data-hs-toggle="${hi}"
                title="По датах">${isOpen ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(s.section)}</strong></td>${fuCells(s)}</tr>`;
        const detail = `<tr class="inv-detail" ${isOpen ? '' : 'hidden'}>
            <td colspan="21">${hsDaysTable(s, hi)}</td></tr>`;
        return master + detail;
    }).join('');
    const tot = fuTotals(herdSecs);
    tot.consumed_sum = canonTotal(tot.consumed_sum, usageConsumedTotal);
    // залишки/перенос — СТРОГО канонічні (щоб «залишки в грошах» збігались між звітами)
    tot.leftover_sum = (usageLeftTotal != null) ? usageLeftTotal : tot.leftover_sum;
    tot.refed_in_sum = (usageRefedTotal != null) ? usageRefedTotal : tot.refed_in_sum;
    body.innerHTML = rows + `<tr class="fu-total-row">
        <td></td><td><strong>Разом</strong></td>${fuCells(tot)}</tr>`;
    if ($('hsDiag')) {
        const hl = herdSecs.reduce((a, x) => a + (x.loaded || 0), 0);
        $('hsDiag').textContent = 'Секцій: ' + herdSecs.length + ' · Витрата: ' + fmt(hl) + ' кг';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const body = $('hsBody');
    if (!body) return;
    body.addEventListener('click', (e) => {
        const sBtn = e.target.closest('[data-hs-toggle]');
        if (sBtn) {
            const s = herdSecs[+sBtn.dataset.hsToggle];
            if (openHS.has(s.section)) openHS.delete(s.section); else openHS.add(s.section);
            renderHerdSecs(); return;
        }
        const dBtn = e.target.closest('[data-hsday]');
        if (dBtn) {
            const [hi, di] = dBtn.dataset.hsday.split(':').map(Number);
            const s = herdSecs[hi];
            const key = s.section + '|' + s.days[di].date;
            if (openHSDay.has(key)) openHSDay.delete(key); else openHSDay.add(key);
            renderHerdSecs();
        }
    });
});

/* Спільні колонки метрик (15 шт) для всіх рівнів */
const FU_HEAD = `<th class="num">Голів</th><th class="num">Зав. план</th><th class="num">Зав. факт</th>
    <th class="num">Зав. відх</th><th class="num">Зав. точн%</th>
    <th class="num">Розд. план</th><th class="num">Розд. факт</th>
    <th class="num">Розд. відх</th><th class="num">Розд. точн%</th>
    <th class="num">Залишки</th><th class="num">Залишки%</th>
    <th class="num">Спожито</th><th class="num">СР</th>
    <th class="num">Молоко</th><th class="num">Конв</th><th class="num">Спожито ₴ без ПДВ</th>
    <th class="num">₴/кг корму</th><th class="num">₴/гол</th>
    <th class="num">Перенос ₴</th>`;

function fuCells(m) {
    return `<td class="num">${m.heads_days == null ? '—' : fmt(m.heads_days, 0)}</td>
        <td class="num">${fmt4(m.plan_loaded)}</td><td class="num">${fmt4(m.loaded)}</td>
        <td class="num ${devCls(m.dev_load)}">${fmtDev(m.dev_load)}</td>
        <td class="num ${accCls(m.acc_load)}">${m.acc_load == null ? '—' : fmt(m.acc_load) + '%'}</td>
        <td class="num">${fmt(m.plan_dist)}</td><td class="num">${fmt(m.dist)}</td>
        <td class="num ${devCls(m.dev_dist)}">${fmt(m.dev_dist)}</td>
        <td class="num ${accCls(m.acc_dist)}">${m.acc_dist == null ? '—' : fmt(m.acc_dist) + '%'}</td>
        <td class="num">${fmt(m.leftover)}</td>
        <td class="num">${m.leftover_pct == null ? '—' : fmt(m.leftover_pct) + '%'}</td>
        <td class="num">${fmt(m.consumed)}</td><td class="num">${fmt(m.dry)}</td>
        <td class="num">${fmt(m.milk)}</td><td class="num">${fmt(m.conv, 2)}</td>
        <td class="num" title="Завантажено: ${money(m.sum)} ₴">${moneyConsumed(m)}</td>
        ${feedPriceCells(m.sum, m.loaded, m.heads_days)}
        <td class="num">${moneyTransfer(m)}</td>`;
}

function fuTotals(list) {
    const t = { plan_loaded: 0, loaded: 0, plan_dist: 0, dist: 0, leftover: 0,
        consumed: 0, dry: 0, milk: 0, sum: 0, heads_days: 0,
        consumed_sum: 0, refed_in_sum: 0, leftover_sum: 0 };
    list.forEach((x) => {
        t.heads_days += (x.heads_days || 0);
        t.plan_loaded += x.plan_loaded; t.loaded += x.loaded;
        t.plan_dist += x.plan_dist; t.dist += x.dist; t.leftover += x.leftover;
        t.consumed += x.consumed; t.dry += x.dry; t.milk += (x.milk || 0); t.sum += x.sum;
        t.consumed_sum += (x.consumed_sum || 0);
        t.refed_in_sum += (x.refed_in_sum || 0);
        t.leftover_sum += (x.leftover_sum || 0);
    });
    const a = (f, p) => (p ? +(Math.min(f, p) / Math.max(f, p) * 100).toFixed(1) : null);
    const accL = list.map((x) => x.acc_load).filter((x) => x != null);
    return {
        heads_days: t.heads_days || null,
        plan_loaded: t.plan_loaded, loaded: t.loaded,
        dev_load: +(t.loaded - t.plan_loaded).toFixed(1),
        acc_load: accL.length ? +(accL.reduce((a2, b) => a2 + b, 0) / accL.length).toFixed(1) : null,
        plan_dist: t.plan_dist, dist: t.dist,
        dev_dist: +(t.dist - t.plan_dist).toFixed(1), acc_dist: a(t.dist, t.plan_dist),
        leftover: t.leftover, leftover_pct: t.dist ? +(t.leftover / t.dist * 100).toFixed(1) : null,
        consumed: t.consumed, dry: t.dry, milk: t.milk || null,
        conv: (t.milk && t.dry) ? +(t.milk / t.dry).toFixed(2) : null, sum: t.sum,
        consumed_sum: t.consumed_sum || null,
        refed_in_sum: t.refed_in_sum || null, leftover_sum: t.leftover_sum || null,
    };
}

function usageDayIng(d) {
    const rows = (d.ingredients || []).map((it) => `<tr>
        <td>${escapeHtml(it.name)}</td>
        <td class="num">${fmt(it.plan)}</td>
        <td class="num">${fmt(it.kg)}</td>
        <td class="num ${it.dev == null ? '' : devCls(it.dev)}">${it.dev == null ? '—' : fmt(it.dev)}</td>
        <td class="num ${accCls(it.acc)}">${it.acc == null ? '—' : fmt(it.acc) + '%'}</td>
        <td class="num">${fmt(it.dry)}</td>
        <td class="num">${it.price == null ? '—' : price4(it.price)}</td>
        <td class="num">${it.sum == null ? '—' : money(it.sum)}</td>
    </tr>`).join('');
    const planT = (d.ingredients || []).reduce((a, it) => a + (it.plan || 0), 0);
    const accT = accAvg(d.ingredients);
    return `<div class="batch-box" style="display:inline-block">
        <div class="batch-box-title">Завантажені корми — ${escapeHtml(d.date)}</div>
        <table class="batch-table fu-sub-tbl">
            <thead><tr><th>Інгредієнт</th><th class="num">План, кг</th><th class="num">Факт, кг</th>
                <th class="num">Відх.</th><th class="num">Точн. %</th><th class="num">СР, кг</th>
                <th class="num">Ціна/кг без ПДВ</th><th class="num">Сума ₴ без ПДВ</th></tr></thead>
            <tbody>${rows || '<tr><td class="empty" colspan="8">Немає даних</td></tr>'}</tbody>
            <tfoot><tr><td><b>Разом</b></td><td class="num"><b>${fmt4(planT)}</b></td>
                <td class="num"><b>${fmt4(d.loaded)}</b></td>
                <td class="num"><b>${planT ? fmt4(d.loaded - planT) : '—'}</b></td>
                <td class="num ${accCls(accT)}"><b>${accT == null ? '—' : fmt(accT) + '%'}</b></td>
                <td class="num"><b>${fmt4(d.dry)}</b></td><td></td>
                <td class="num"><b>${money(d.sum)}</b></td></tr></tfoot>
        </table></div>`;
}

function usageDaysTable(s, ci, si) {
    const rows = s.days.map((d, di) => {
        const isOpen = openDayU.has(s._cat + '|' + s.subgroup + '|' + d.date);
        const row = `<tr>
            <td class="fu-toggle-cell"><button class="batch-toggle" data-uday="${ci}:${si}:${di}"
                title="Завантажені корми">${isOpen ? '▾' : '▸'}</button></td>
            <td>${escapeHtml(d.date)}</td>${fuCells(d)}</tr>`;
        const det = isOpen ? `<tr><td colspan="21">${usageDayIng(d)}</td></tr>` : '';
        return row + det;
    }).join('');
    return `<div class="batch-box" style="display:inline-block">
        <div class="batch-box-title">По датах — ${escapeHtml(s.subgroup)}</div>
        <table class="batch-table fu-sub-tbl">
            <thead><tr><th style="width:22px;"></th><th>Дата</th>${FU_HEAD}</tr></thead>
            <tbody>${rows}</tbody></table></div>`;
}

function usageSubTable(c, ci) {
    const rows = c.subs.map((s, si) => {
        s._cat = c.category;
        const isOpen = openSub.has(c.category + '|' + s.subgroup);
        const row = `<tr class="fu-sub-row">
            <td class="fu-toggle-cell"><button class="batch-toggle" data-sub="${ci}:${si}"
                title="По датах">${isOpen ? '▾' : '▸'}</button></td>
            <td>${escapeHtml(s.subgroup)}</td>${fuCells(s)}</tr>`;
        const det = isOpen ? `<tr><td colspan="21">${usageDaysTable(s, ci, si)}</td></tr>` : '';
        return row + det;
    }).join('');
    return `<div class="batch-box" style="display:inline-block">
        <div class="batch-box-title">Підкатегорії — ${escapeHtml(c.category)}</div>
        <table class="batch-table fu-sub-tbl">
            <thead><tr><th style="width:24px;"></th><th>Підкатегорія</th>${FU_HEAD}</tr></thead>
            <tbody>${rows}</tbody></table></div>`;
}

function renderUsage() {
    const body = $('fuBody');
    if (!cats.length) {
        body.innerHTML = '<tr><td colspan="21" class="empty">Немає даних — перевірте налаштування секцій (Категорія/Підкатегорія)</td></tr>';
        return;
    }
    const rows = cats.map((c, ci) => {
        const isOpen = openCat.has(c.category);
        const master = `<tr class="fu-cat-row inv-row">
            <td class="fu-toggle-cell"><button class="batch-toggle" data-cat-toggle="${ci}"
                title="Підкатегорії">${isOpen ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(c.category)}</strong></td>${fuCells(c)}</tr>`;
        const detail = `<tr class="inv-detail" ${isOpen ? '' : 'hidden'}>
            <td colspan="21">${usageSubTable(c, ci)}</td></tr>`;
        return master + detail;
    }).join('');
    const tot = fuTotals(cats);
    tot.consumed_sum = canonTotal(tot.consumed_sum, usageCatsConsumedTotal);
    // залишки/перенос — СТРОГО канонічні (щоб «залишки в грошах» збігались між звітами)
    tot.leftover_sum = (usageLeftTotal != null) ? usageLeftTotal : tot.leftover_sum;
    tot.refed_in_sum = (usageRefedTotal != null) ? usageRefedTotal : tot.refed_in_sum;
    body.innerHTML = rows + `<tr class="fu-total-row">
        <td></td><td><strong>Разом</strong></td>${fuCells(tot)}</tr>`;
}

document.addEventListener('DOMContentLoaded', async () => {
    // вибір стовпця надою для конверсії — усі стовпці аркуша «Виробництво»
    const sel = $('fuMilkCol');
    if (sel) {
        try {
            const r = await apiGet('/api/feed/milk-col');
            if (r && r.ok) {
                const opts = (r.options && r.options.length) ? r.options : [r.col];
                sel.innerHTML = opts.map((c) =>
                    `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
                sel.value = r.col;
            }
        } catch (e) { /**/ }
        sel.addEventListener('change', async (e) => {
            try { await apiSend('/api/feed/milk-col', 'POST', { col: e.target.value }); }
            catch (err) { /**/ }
            loadUsage();
        });
    }
    $('fuBody').addEventListener('click', (e) => {
        const catBtn = e.target.closest('[data-cat-toggle]');
        if (catBtn) {
            const c = cats[+catBtn.dataset.catToggle];
            if (openCat.has(c.category)) openCat.delete(c.category); else openCat.add(c.category);
            renderUsage(); return;
        }
        const subBtn = e.target.closest('[data-sub]');
        if (subBtn) {
            const [ci, si] = subBtn.dataset.sub.split(':').map(Number);
            const s = cats[ci].subs[si];
            const key = cats[ci].category + '|' + s.subgroup;
            if (openSub.has(key)) openSub.delete(key); else openSub.add(key);
            renderUsage(); return;
        }
        const dayBtn = e.target.closest('[data-uday]');
        if (dayBtn) {
            const [ci, si, di] = dayBtn.dataset.uday.split(':').map(Number);
            const s = cats[ci].subs[si];
            const key = cats[ci].category + '|' + s.subgroup + '|' + s.days[di].date;
            if (openDayU.has(key)) openDayU.delete(key); else openDayU.add(key);
            renderUsage();
        }
    });
});

function devCls(v) { return Math.abs(v || 0) > 0.5 ? 'fl-dev-bad' : ''; }
/* Бейдж статусу списання */
function woBadge(st) {
    if (st === 'done') return ' <span class="fl-wo fl-wo-ok" title="Списано зі складу">✓ списано</span>';
    if (st === 'partial') return ' <span class="fl-wo fl-wo-part" title="Списано частково">◐ частково</span>';
    return '';
}
/* Середня точність замісу — середнє з точностей окремих кормів */
function accAvg(ings) {
    const v = (ings || []).map((it) => it.acc).filter((x) => x != null);
    return v.length ? +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(1) : null;
}
/* Колір точності: ≥95 зелений, 90–95 жовтий, <90 червоний */
function accCls(v) {
    if (v == null) return '';
    if (v >= 95) return 'fl-acc-ok';
    if (v >= 90) return 'fl-acc-warn';
    return 'fl-acc-bad';
}

/* Вкладена таблиця днів секції */
function daysTable(s, si) {
    const head = `<thead><tr>
        <th style="width:26px;"></th>
        <th>Дата</th><th class="num">Гол.</th>
        <th class="num">Зав. план</th><th class="num">Зав. факт</th>
        <th class="num">Зав. відх</th><th class="num">Зав. точн%</th>
        <th class="num">Розд. план</th><th class="num">Розд. факт</th>
        <th class="num">Розд. відх</th><th class="num">Розд. точн%</th>
        <th class="num">Залишки</th><th class="num">Залишки%</th>
        <th class="num">Спожито</th><th class="num">Спож/гол</th>
        <th class="num">СР</th><th class="num">СР/гол</th><th class="num">кг/гол</th>
        <th class="num">Молоко</th><th class="num">Конв.</th>
        <th class="num">Спожито ₴ без ПДВ</th><th class="num">₴/кг корму</th><th class="num">₴/гол</th><th class="num">Перенос ₴</th>
    </tr></thead>`;
    const rows = s.days.map((d, di) => {
        const key = s.section + '|' + d.date;
        const isOpen = openDay.has(key);
        const dayTr = `<tr class="fl-day-row">
            <td class="fl-toggle-cell"><button class="batch-toggle" data-day-toggle
                data-sec="${si}" data-day="${di}" title="Завантажені корми">${isOpen ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(d.date)}</strong>
                <span class="text-mute"> · ${d.feedings} розд.</span>${woBadge(d.written_off)}</td>
            <td class="num">${fmt(d.heads, 0)}</td>
            <td class="num">${fmt4(d.plan_loaded)}</td>
            <td class="num">${fmt4(d.loaded)}</td>
            <td class="num ${devCls(d.dev_load)}">${fmtDev(d.dev_load)}</td>
            <td class="num ${accCls(d.accuracy)}">${d.accuracy == null ? '—' : fmt(d.accuracy) + '%'}</td>
            <td class="num">${fmt(d.plan_distributed)}</td>
            <td class="num">${fmt(d.distributed)}</td>
            <td class="num ${devCls(d.dev)}">${fmt(d.dev)}</td>
            <td class="num ${accCls(d.acc_dist)}">${d.acc_dist == null ? '—' : fmt(d.acc_dist) + '%'}</td>
            <td class="num">${fmt(d.leftover)}${d.refed_in ? `<span class="fl-disp-badge" title="Отримано із залишків інших груп">+${fmt(d.refed_in)}</span>` : ''}</td>
            <td class="num">${d.leftover_pct == null ? '—' : fmt(d.leftover_pct) + '%'}</td>
            <td class="num">${fmt(d.consumed)}</td>
            <td class="num">${fmt(d.consumed_head)}</td>
            <td class="num">${fmt(d.dry)}</td>
            <td class="num">${fmt(d.dry_head)}</td>
            <td class="num">${fmt(d.kg_head)}</td>
            <td class="num"><input class="fl-milk-in" type="number" min="0" step="1"
                data-sec="${si}" data-day="${di}" value="${d.milk == null ? '' : d.milk}" placeholder="—"></td>
            <td class="num">${fmt(d.conv, 2)}</td>
            <td class="num" title="Завантажено: ${money(d.ration_sum)} ₴">${moneyConsumed(d)}</td>
            ${feedPriceCells(d.ration_sum, d.loaded, d.heads)}
            <td class="num">${moneyTransfer(d)}</td>
        </tr>`;
        const ingTr = isOpen
            ? `<tr class="fl-ing-row"><td colspan="24">${ingBox(d)}</td></tr>` : '';
        return dayTr + ingTr;
    }).join('');
    return `<table class="batch-table fl-days-table">${head}<tbody>${rows}</tbody></table>`;
}

const FL_DISPOSAL = 'Утилізація';

/* Підпанель «Завантажені корми» для дня */
function ingBox(d) {
    let inner;
    if (tmrOn) {
        inner = `<div class="fl-tmr-line"><b>Загальнозмішаний раціон:</b>
            ${escapeHtml(d.ration || '—')} — ${fmt(d.loaded)} кг, СР ${fmt(d.dry)} кг,
            сума ${money(d.ration_sum)} ₴ без ПДВ</div>`;
    } else {
        let planT = 0;
        const rows = (d.ingredients || []).map((it) => {
            planT += (it.plan || 0);
            return `<tr>
            <td>${escapeHtml(it.name)}</td>
            <td class="num">${fmt4(it.plan)}</td>
            <td class="num">${fmt4(it.kg)}</td>
            <td class="num ${it.dev == null ? '' : devCls(it.dev)}">${it.dev == null ? '—' : fmt4(it.dev)}</td>
            <td class="num ${accCls(it.acc)}">${it.acc == null ? '—' : fmt(it.acc) + '%'}</td>
            <td class="num">${fmt4(it.dry)}</td>
            <td class="num">${it.price == null ? '—' : price4(it.price)}</td>
            <td class="num">${it.sum == null ? '—' : money(it.sum)}</td>
        </tr>`;
        }).join('');
        const accT = accAvg(d.ingredients);
        inner = `<table class="batch-table fl-ing-tbl">
            <thead><tr><th>Інгредієнт</th><th class="num">План, кг</th><th class="num">Факт, кг</th>
                <th class="num">Відх.</th><th class="num">Точн. %</th><th class="num">СР, кг</th>
                <th class="num">Ціна/кг без ПДВ</th><th class="num">Сума ₴ без ПДВ</th></tr></thead>
            <tbody>${rows || '<tr><td class="empty" colspan="8">Немає даних</td></tr>'}</tbody>
            <tfoot><tr><td><b>Разом</b></td><td class="num"><b>${fmt4(planT)}</b></td>
                <td class="num"><b>${fmt4(d.loaded)}</b></td>
                <td class="num"><b>${planT ? fmt4(d.loaded - planT) : '—'}</b></td>
                <td class="num ${accCls(accT)}"><b>${accT == null ? '—' : fmt(accT) + '%'}</b></td>
                <td class="num"><b>${fmt4(d.dry)}</b></td>
                <td class="num" title="Ціна раціону за кг без ПДВ"><b>${d.loaded ? price4(d.ration_sum / d.loaded) : '—'}</b></td>
                <td class="num"><b>${money(d.ration_sum)}</b></td></tr></tfoot>
        </table>`;
    }
    return `<div class="batch-box fl-ing-box">
        <div class="batch-box-title">Завантажені корми — ${escapeHtml(d.date)}${d.ration ? ' · Раціон: ' + escapeHtml(d.ration) : ''}</div>${inner}</div>`;
}

function render() {
    const q = ($('flSearch').value || '').trim().toLowerCase();
    const body = $('flBody');
    const secShow = q
        ? sections.filter((s) => s.section.toLowerCase().includes(q)
            || s.days.some((d) => d.date.includes(q)))
        : sections;
    if (!secShow.length) {
        body.innerHTML = `<tr><td colspan="24" class="empty">${sections.length
            ? 'Нічого не знайдено' : 'Роздач немає — перевірте теку звітів Profeed'}</td></tr>`;
        return;
    }
    body.innerHTML = secShow.map((s, si) => {
        const isOpen = openSec.has(s.section);
        const master = `<tr class="fl-sec-row inv-row">
            <td class="fl-toggle-cell"><button class="batch-toggle" data-sec-toggle="${si}"
                title="Дні годівлі">${isOpen ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(s.section)}</strong>${woBadge(s.written_off)}</td>
            <td class="num">${s.days_count}</td>${secCells(s)}</tr>`;
        const detail = `<tr class="inv-detail" ${isOpen ? '' : 'hidden'}>
            <td colspan="24">
                <div class="batch-box">
                    <div class="batch-box-title">Дні годівлі (${s.days_count})</div>
                    ${daysTable(s, si)}
                </div>
            </td>
        </tr>`;
        return master + detail;
    }).join('') + (() => {
        const tot = secTotals(secShow);
        tot.consumed_sum = canonTotal(tot.consumed_sum, treeConsumedTotal);
        // залишки/перенос — СТРОГО канонічні (звіти сходяться до копійки)
        tot.leftover_sum = (treeLeftTotal != null) ? treeLeftTotal : tot.leftover_sum;
        tot.refed_in_sum = (treeRefedTotal != null) ? treeRefedTotal : tot.refed_in_sum;
        return `<tr class="fl-total-row">
        <td></td><td><strong>Разом</strong></td><td></td>${secCells(tot)}</tr>`;
    })();
}

/* Комірки метрик секції (18 шт) — той самий порядок, що й у день-таблиці */
function secCells(m) {
    return `<td class="num">${fmt4(m.plan_loaded)}</td><td class="num">${fmt4(m.loaded)}</td>
        <td class="num ${devCls(m.dev_load)}">${fmtDev(m.dev_load)}</td>
        <td class="num ${accCls(m.accuracy)}">${m.accuracy == null ? '—' : fmt(m.accuracy) + '%'}</td>
        <td class="num">${fmt(m.plan_distributed)}</td><td class="num">${fmt(m.distributed)}</td>
        <td class="num ${devCls(m.dev)}">${fmt(m.dev)}</td>
        <td class="num ${accCls(m.acc_dist)}">${m.acc_dist == null ? '—' : fmt(m.acc_dist) + '%'}</td>
        <td class="num">${fmt(m.leftover)}</td>
        <td class="num">${m.leftover_pct == null ? '—' : fmt(m.leftover_pct) + '%'}</td>
        <td class="num">${fmt(m.consumed)}</td><td class="num">${fmt(m.consumed_head)}</td>
        <td class="num">${fmt(m.dry)}</td><td class="num">${fmt(m.dry_head)}</td>
        <td class="num">${fmt(m.kg_head)}</td><td class="num">${fmt(m.milk_head)}</td>
        <td class="num">${fmt(m.conv, 2)}</td><td class="num" title="Завантажено: ${money(m.sum)} ₴">${moneyConsumed(m)}</td>
        ${feedPriceCells(m.sum, m.loaded, m.heads_days)}
        <td class="num">${moneyTransfer(m)}</td>`;
}

function secTotals(list) {
    const t = { plan_loaded: 0, loaded: 0, plan_distributed: 0, distributed: 0,
        leftover: 0, consumed: 0, dry: 0, sum: 0, consumed_sum: 0,
        refed_in_sum: 0, leftover_sum: 0, heads_days: 0 };
    list.forEach((s) => {
        t.heads_days += (s.heads_days || 0);
        t.plan_loaded += s.plan_loaded; t.loaded += s.loaded;
        t.plan_distributed += s.plan_distributed; t.distributed += s.distributed;
        t.leftover += s.leftover; t.consumed += s.consumed; t.dry += s.dry; t.sum += s.sum;
        t.consumed_sum += (s.consumed_sum || 0);
        t.refed_in_sum += (s.refed_in_sum || 0);
        t.leftover_sum += (s.leftover_sum || 0);
    });
    const accA = list.map((s) => s.accuracy).filter((x) => x != null);
    const acc = (f, p) => (p ? +(Math.min(f, p) / Math.max(f, p) * 100).toFixed(1) : null);
    return {
        heads_days: t.heads_days || null,
        plan_loaded: t.plan_loaded, loaded: t.loaded,
        dev_load: +(t.loaded - t.plan_loaded).toFixed(1),
        accuracy: accA.length ? +(accA.reduce((a, b) => a + b, 0) / accA.length).toFixed(1) : null,
        plan_distributed: t.plan_distributed, distributed: t.distributed,
        dev: +(t.distributed - t.plan_distributed).toFixed(1),
        acc_dist: acc(t.distributed, t.plan_distributed), leftover: t.leftover,
        leftover_pct: t.distributed ? +(t.leftover / t.distributed * 100).toFixed(1) : null,
        consumed: t.consumed, consumed_head: null, dry: t.dry, dry_head: null,
        kg_head: null, milk_head: null, conv: null, sum: t.sum,
        consumed_sum: t.consumed_sum || null,
        refed_in_sum: t.refed_in_sum || null, leftover_sum: t.leftover_sum || null,
    };
}

/* Розкриття секцій та днів */
$('flBody').addEventListener('click', (e) => {
    const secBtn = e.target.closest('[data-sec-toggle]');
    if (secBtn) {
        const s = sections[+secBtn.dataset.secToggle];
        if (openSec.has(s.section)) openSec.delete(s.section); else openSec.add(s.section);
        render(); return;
    }
    const dayBtn = e.target.closest('[data-day-toggle]');
    if (dayBtn) {
        const s = sections[+dayBtn.dataset.sec];
        const d = s.days[+dayBtn.dataset.day];
        const key = s.section + '|' + d.date;
        if (openDay.has(key)) openDay.delete(key); else openDay.add(key);
        render();
    }
});

/* Введення молока → збереження + перерахунок конверсії */
$('flBody').addEventListener('change', async (e) => {
    const inp = e.target.closest('.fl-milk-in');
    if (!inp) return;
    const s = sections[+inp.dataset.sec];
    const d = s.days[+inp.dataset.day];
    const val = inp.value === '' ? 0 : parseFloat(inp.value);
    try {
        await apiSend('/api/feed/feeding-milk', 'POST',
            { section: s.section, day: d.date, milk_kg: val });
    } catch (err) { /* лишаємо значення */ }
    d.milk = val > 0 ? val : null;
    d.conv = (val > 0 && d.dry_consumed) ? +(val / d.dry_consumed).toFixed(2) : null;
    s.milk = s.days.reduce((a, x) => a + (x.milk || 0), 0) || null;
    const dc = s.days.reduce((a, x) => a + (x.dry_consumed || 0), 0);
    const hd = s.days.reduce((a, x) => a + (x.heads || 0), 0);
    s.milk_head = (s.milk && hd) ? +(s.milk / hd).toFixed(1) : null;
    s.conv = (s.milk && dc) ? +(s.milk / dc).toFixed(2) : null;
    render();
});

/* ===== Банер «До уваги»: нерозподілені залишки ЗМР ===== */
function renderAttention(poolKg, poolDest) {
    const el = $('flAttention');
    if (!el) return;
    // Дні всіх залишків І всіх розподілів (розподіл міг лишитись, а залишок — зникнути)
    const days = new Set(Object.keys(poolKg || {}));
    Object.keys(poolDest || {}).forEach((d) => days.add(d));
    let under = 0, over = 0, uDays = 0, oDays = 0, firstDay = '';
    days.forEach((day) => {
        const pool = (poolKg || {})[day] || 0;
        const dist = ((poolDest || {})[day] || []).reduce((s, x) => s + (x.qty || 0), 0);
        const diff = pool - dist;
        if (diff > 0.5) { under += diff; uDays++; if (!firstDay || day > firstDay) firstDay = day; }
        else if (diff < -0.5) { over += -diff; oDays++; if (!firstDay || day > firstDay) firstDay = day; }
    });
    if (!under && !over) { el.hidden = true; el.innerHTML = ''; return; }
    const dw = (n) => (n === 1 ? 'дату' : (n < 5 ? 'дати' : 'дат'));
    el.hidden = false;
    el.classList.toggle('fl-att-err', over > 0);   // перероздача — червоний акцент
    const parts = [];
    if (over > 0) {
        parts.push(`Роздано більше, ніж зібрано залишків — надлишок <b>${fmt(Math.round(over))}</b> кг за ${oDays} ${dw(oDays)}.`);
    }
    if (under > 0) {
        parts.push(`Нерозподілені залишки ЗМР — <b>${fmt(Math.round(under))}</b> кг за ${uDays} ${dw(uDays)}.`);
    }
    el.innerHTML =
        `<span class="fl-att-ico">⚠️</span>`
        + `<span>${parts.join(' ')}</span>`
        + `<span class="fl-att-spacer"></span>`
        + `<button type="button" class="fl-att-btn" data-date="${firstDay}">Виправити →</button>`;
}
document.addEventListener('DOMContentLoaded', () => {
    const el = $('flAttention');
    if (el) el.addEventListener('click', (e) => {
        const btn = e.target.closest('.fl-att-btn');
        if (!btn) return;
        // розгорнути панель залишків
        const body = $('flLeftBody'); const tog = $('flLeftToggle');
        if (body && body.classList.contains('is-collapsed')) {
            body.classList.remove('is-collapsed');
            if (tog) tog.textContent = '▾';
            try { localStorage.setItem('farm:fl_left_collapsed', '0'); } catch (e2) { /**/ }
        }
        flLeftDate = btn.dataset.date || flLeftDate;
        loadLeftPanel();
        const p = $('flLeftPanel');
        if (p) p.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
});

/* ===== Панель «Залишки ЗМР по групах» (над «Рух по секціях») ===== */
let flLeftDate = '';        // обрана дата панелі
let leftSections = [];      // секції годівлі САМЕ на обрану дату (окремий запит)
let leftPoolDest = {};      // {дата: [{dest, qty}]} — розподіл залишків на цю дату

// дати, що є в поточно завантаженому дереві (для дефолтної дати панелі)
function mainDates() {
    const set = new Set();
    sections.forEach((s) => (s.days || []).forEach((d) => set.add(d.date)));
    return [...set].sort().reverse();
}
function daySectionsFor(date) {
    const out = [];
    leftSections.forEach((s) => {
        const d = (s.days || []).find((x) => x.date === date);
        if (d) out.push({ section: s.section, day: d });
    });
    return out;
}
// select групи-отримувача (усі групи на дату + Утилізація)
function poolDestOptions(cur) {
    const groups = daySectionsFor(flLeftDate).map((x) => x.section);
    return ['', FL_DISPOSAL, ...groups].map((n) =>
        `<option value="${escapeHtml(n)}"${n === cur ? ' selected' : ''}>`
        + `${n === '' ? '—' : (n === FL_DISPOSAL ? '♻ Утилізація' : escapeHtml(n))}</option>`).join('');
}
function poolRowHtml(dest, qty) {
    return `<div class="fl-pool-row">
        <select class="fl-pool-dest">${poolDestOptions(dest || '')}</select>
        <input class="fl-pool-qty" type="number" min="0" step="1" value="${qty == null ? '' : qty}" placeholder="кг">
        <button type="button" class="fl-pool-del" title="Прибрати">✕</button></div>`;
}

// Панель самодостатня: тягне дані годівлі саме для обраної дати, тож фіксувати
// залишки можна на будь-який день (не залежно від фільтра періоду зверху).
async function loadLeftPanel() {
    const dsel = $('flLeftDate');
    if (!dsel) return;
    if (!flLeftDate) {
        const md = mainDates();
        flLeftDate = md[0] || new Date().toISOString().slice(0, 10);
    }
    const qs = `?from=${encodeURIComponent(flLeftDate)}&to=${encodeURIComponent(flLeftDate)}`;
    let r;
    try { r = await apiGet('/api/feed/feeding-tree' + qs); }
    catch (e) { r = { ok: false }; }
    if (r && r.ok) { leftSections = r.sections || []; leftPoolDest = r.pool_dest || {}; }
    else { leftSections = []; leftPoolDest = {}; }
    renderLeftPanel();
}

function renderLeftPanel() {
    const dsel = $('flLeftDate');
    const rows = $('flLeftRows');
    if (!dsel || !rows) return;
    if (document.activeElement !== dsel) dsel.value = flLeftDate || '';
    const list = daySectionsFor(flLeftDate);
    if (!list.length) {
        rows.innerHTML = '<tr><td colspan="4" class="empty">На цю дату годівлі немає — оберіть іншу дату</td></tr>';
        $('flPoolRows').innerHTML = '';
        if ($('flPoolKg')) $('flPoolKg').textContent = '0';
        if ($('flLeftSummary')) $('flLeftSummary').innerHTML = '';
        return;
    }
    // 1. Залишок по групах
    rows.innerHTML = list.map((x) => {
        const d = x.day;
        const kg = d.leftover ? Math.round(d.leftover) : '';
        const pct = (d.leftover && d.distributed) ? +(d.leftover / d.distributed * 100).toFixed(1) : '';
        return `<tr data-sec="${escapeHtml(x.section)}" data-dist="${d.distributed || 0}">
            <td>${escapeHtml(x.section)}</td>
            <td class="num">${fmt(d.distributed)}</td>
            <td class="num"><input class="fll-left" type="number" min="0" step="1"
                value="${kg}" placeholder="0"></td>
            <td class="num"><input class="fll-pct" type="number" min="0" step="0.1"
                value="${pct === '' ? '' : pct}" placeholder="%"></td></tr>`;
    }).join('');
    // 2. Розподіл залишків (з наявних даних або порожній рядок)
    const dests = leftPoolDest[flLeftDate] || [];
    const note = $('flPoolAutoNote');
    if (note) {
        const isAuto = dests.length && dests.every((z) => z.auto);
        note.hidden = !isAuto;
        if (isAuto) note.textContent = 'Розподіл проставлено автоматично за зразком '
            + 'попереднього дня — виправте, якщо було інакше.';
    }
    $('flPoolRows').innerHTML = (dests.length ? dests : [{ dest: '', qty: '' }])
        .map((z) => poolRowHtml(z.dest, z.qty)).join('');
    updateLeftSummary();
}

function poolKg() {
    let sum = 0;
    document.querySelectorAll('#flLeftRows tr[data-sec]').forEach((tr) => {
        sum += parseFloat(tr.querySelector('.fll-left').value) || 0;
    });
    return +sum.toFixed(1);
}
function poolDistributed() {
    let sum = 0;
    document.querySelectorAll('#flPoolRows .fl-pool-row').forEach((r) => {
        sum += parseFloat(r.querySelector('.fl-pool-qty').value) || 0;
    });
    return +sum.toFixed(1);
}

function updateLeftSummary() {
    const pool = poolKg();
    const dist = poolDistributed();
    if ($('flPoolKg')) $('flPoolKg').textContent = fmt(pool);
    if ($('flPoolDist')) $('flPoolDist').textContent = '';
    // розбивка по призначеннях
    const byTo = {}; let disp = 0;
    document.querySelectorAll('#flPoolRows .fl-pool-row').forEach((r) => {
        const dest = r.querySelector('.fl-pool-dest').value;
        const qty = parseFloat(r.querySelector('.fl-pool-qty').value) || 0;
        if (!dest || qty <= 0) return;
        if (dest === FL_DISPOSAL) disp += qty; else byTo[dest] = (byTo[dest] || 0) + qty;
    });
    const toStr = Object.keys(byTo).length
        ? Object.entries(byTo).map(([k, v]) => `${escapeHtml(k)} — <b>${fmt(v)}</b>`).join(', ') : '—';
    const unalloc = +(pool - dist).toFixed(1);
    const el = $('flLeftSummary');
    if (el) el.innerHTML = `Залишків разом: <b>${fmt(pool)}</b> кг · Роздано: ${toStr}`
        + ` · Утилізація: <b>${fmt(disp)}</b> кг`
        + (Math.abs(unalloc) < 0.05 ? ' · <span class="ok">розподілено повністю</span>'
            : (unalloc > 0 ? ` · <span class="fll-warn">нерозподілено ${fmt(unalloc)} кг</span>`
                : ` · <span class="fll-warn">перевищення на ${fmt(-unalloc)} кг</span>`));
}

async function saveLeftPanel(btn) {
    const pool = poolKg();
    const dist = poolDistributed();
    if (dist - pool > 0.05) { toast('Розподілено більше, ніж є залишків', 'error'); return; }
    // збираємо розподіл залишків
    const dests = [];
    let bad = false;
    document.querySelectorAll('#flPoolRows .fl-pool-row').forEach((r) => {
        const dest = r.querySelector('.fl-pool-dest').value;
        const qty = parseFloat(r.querySelector('.fl-pool-qty').value) || 0;
        if (qty > 0 && !dest) bad = true;
        if (dest && qty > 0) dests.push({ dest, qty });
    });
    if (bad) { toast('Вкажіть, куди роздано (група / Утилізація)', 'error'); return; }
    btn.disabled = true;
    try {
        // 1) залишки по групах
        const trs = [...document.querySelectorAll('#flLeftRows tr[data-sec]')];
        for (const tr of trs) {
            const left = Math.round(parseFloat(tr.querySelector('.fll-left').value) || 0);
            await apiSend('/api/feed/feeding-leftover', 'POST',
                { section: tr.dataset.sec, day: flLeftDate, qty_kg: left });
        }
        // 2) розподіл залишків
        await apiSend('/api/feed/pool-dest', 'POST', { day: flLeftDate, dests });
        toast('Збережено', 'success');
    } catch (e) {
        toast('Сервер не відповів', 'error');
    } finally {
        btn.disabled = false;   // ЗАВЖДИ знімаємо блок кнопки (інакше 2-й раз не зберігає)
    }
    loadTree();   // перерахунок спожито/СР/конверсії
}

document.addEventListener('DOMContentLoaded', () => {
    const dsel = $('flLeftDate');
    if (dsel) dsel.addEventListener('change', () => {
        flLeftDate = dsel.value; if (flLeftDate) loadLeftPanel();
    });
    // двобічний перерахунок кг ↔ % у таблиці залишків
    const rows = $('flLeftRows');
    if (rows) rows.addEventListener('input', (e) => {
        const tr = e.target.closest('tr[data-sec]');
        if (tr) {
            const dist = parseFloat(tr.dataset.dist) || 0;
            if (e.target.classList.contains('fll-left') && dist > 0) {
                const kg = Math.round(parseFloat(e.target.value) || 0);
                tr.querySelector('.fll-pct').value = kg ? +(kg / dist * 100).toFixed(1) : '';
            } else if (e.target.classList.contains('fll-pct') && dist > 0) {
                const pct = parseFloat(e.target.value) || 0;
                tr.querySelector('.fll-left').value = pct ? Math.round(dist * pct / 100) : '';
            }
        }
        updateLeftSummary();
    });
    const prows = $('flPoolRows');
    if (prows) prows.addEventListener('input', updateLeftSummary);
    if (prows) prows.addEventListener('click', (e) => {
        const del = e.target.closest('.fl-pool-del');
        if (del) { del.closest('.fl-pool-row').remove(); updateLeftSummary(); }
    });
    const add = $('flPoolAdd');
    if (add) add.addEventListener('click', () => {
        $('flPoolRows').insertAdjacentHTML('beforeend', poolRowHtml('', ''));
    });
    const save = $('flLeftSave');
    if (save) save.addEventListener('click', () => saveLeftPanel(save));
    // згортання панелі
    const tog = $('flLeftToggle'); const body = $('flLeftBody');
    if (tog && body) {
        const KEY = 'farm:fl_left_collapsed';
        const apply = (c) => { body.classList.toggle('is-collapsed', c); tog.textContent = c ? '▸' : '▾'; };
        apply(localStorage.getItem(KEY) === '1');
        tog.addEventListener('click', () => {
            const c = !body.classList.contains('is-collapsed'); apply(c);
            try { localStorage.setItem(KEY, c ? '1' : '0'); } catch (e) { /**/ }
        });
    }
});

/* Перемикач ТМР ↔ інгредієнти (сегментований) */
$('flTmrToggle').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tmr]');
    if (!btn) return;
    tmrOn = btn.dataset.tmr === '1';
    $('flTmrToggle').querySelectorAll('.seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b === btn));
    try { localStorage.setItem(KEY_TMR, tmrOn ? '1' : '0'); } catch (err) { /**/ }
    render();
});

/* Пресети періоду */
(() => {
    const presets = $('flPresets'), fromEl = $('flFrom'), toEl = $('flTo');
    const KEY = 'farm:fl_days';
    const iso = (d) => d.toISOString().slice(0, 10);
    const mark = (days) => presets.querySelectorAll('.btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));
    const apply = (days) => {
        toEl.value = iso(new Date());
        fromEl.value = days === 'all' ? '' : iso(new Date(Date.now() - (+days) * 864e5));
        mark(days);
    };
    presets.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-days]');
        if (!btn) return;
        apply(btn.dataset.days);
        try { localStorage.setItem(KEY, btn.dataset.days); } catch (err) { /**/ }
        loadTree();
    });
    [fromEl, toEl].forEach((el) => el.addEventListener('change', () => { mark(null); loadTree(); }));
    $('flSearch').addEventListener('input', render);
    try { tmrOn = localStorage.getItem(KEY_TMR) === '1'; } catch (e) { /**/ }
    $('flTmrToggle').querySelectorAll('.seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.tmr === (tmrOn ? '1' : '0')));

    /* Перемикач День / Період */
    const MODE_KEY = 'farm:fl_mode';
    const dayEl = $('flDay'), modeTgl = $('flModeToggle');
    const show = (id, on) => { const el = $(id); if (el) el.style.display = on ? '' : 'none'; };
    const applyDay = () => {                 // День: from=to=обрана дата
        const d = dayEl.value || iso(new Date());
        dayEl.value = d; fromEl.value = d; toEl.value = d;
    };
    const setMode = (mode, reload) => {
        const day = mode !== 'period';
        modeTgl.querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.mode === mode));
        show('flDayBox', day); show('flPresets', !day);
        show('flFromBox', !day); show('flToBox', !day);
        try { localStorage.setItem(MODE_KEY, mode); } catch (e) { /**/ }
        if (day) applyDay(); else apply(localStorage.getItem(KEY) || '30');
        if (reload) loadTree();
    };
    modeTgl.addEventListener('click', (e) => {
        const b = e.target.closest('[data-mode]'); if (b) setMode(b.dataset.mode, true);
    });
    dayEl.addEventListener('change', () => { applyDay(); loadTree(); });
    const stepDay = (n) => {
        // крок по календарних днях БЕЗ UTC-зсуву (toISOString зміщував дату)
        const s = dayEl.value || iso(new Date());
        const [y, m, dd] = s.split('-').map(Number);
        const d = new Date(y, m - 1, dd + n);
        dayEl.value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        applyDay(); loadTree();
    };
    $('flDayPrev').addEventListener('click', () => stepDay(-1));
    $('flDayNext').addEventListener('click', () => stepDay(1));

    dayEl.value = iso(new Date());
    const startMode = localStorage.getItem(MODE_KEY) || 'day';
    setMode(startMode, false);
    // Дефолт «День» = ОСТАННЯ дата з даними (не сьогодні — на сьогодні даних нема).
    if (startMode !== 'period') {
        apiGet('/api/feed/last-day').then((r) => {
            const d = r && r.ok && r.day;
            if (d) { dayEl.value = d; applyDay(); loadTree(); }
        }).catch(() => { /**/ });
    }
})();

/* Перемикач автосписання годівлі (щоденне) */
(async () => {
    const el = $('flAutoWo');
    if (!el) return;
    try {
        const r = await apiGet('/api/feed/auto-writeoff');
        if (r && r.ok) {
            el.checked = !!r.enabled;
            el.title = 'Щодня о ' + (r.time || '06:30')
                + ' автоматично списувати роздачі зі складу'
                + (r.last ? ' · останнє: ' + r.last : '');
        }
    } catch (e) { /**/ }
    el.addEventListener('change', async () => {
        try {
            const r = await apiSend('/api/feed/auto-writeoff', 'POST', { enabled: el.checked });
            if (!r || !r.ok) { el.checked = !el.checked; toast((r && r.error) || 'Помилка', 'error'); }
            else toast(el.checked ? 'Автосписання увімкнено' : 'Автосписання вимкнено', 'success');
        } catch (err) { el.checked = !el.checked; }
    });
})();

/* Перемикач «Розподіл залишків як учора» */
(async () => {
    const el = $('flPoolAuto');
    if (!el) return;
    const wsel = $('flPoolWhere');
    let DEV = { key: '', name: '', user: '' };
    try {
        const r = await apiGet('/api/feed/pool-auto');
        if (r && r.ok) {
            el.checked = !!r.enabled;
            if (r.last) el.title += ' · останній прогін: ' + r.last;
            DEV = r.device || DEV;
            if (wsel) {
                // «цей пристрій» підписуємо імʼям компʼютера й людини, а чужий
                // вибір показуємо окремим рядком — щоб було видно, ХТО виконує
                const meOpt = $('flPoolWhereMe');
                if (meOpt && DEV.name) meOpt.textContent = 'на цьому пристрої (' + DEV.name
                    + (DEV.user ? ' · ' + DEV.user : '') + ')';
                const w = r.where || '';
                Array.from(wsel.options).forEach((o) => { if (o.dataset.dyn) o.remove(); });
                if (w && DEV.key && w === DEV.key) { wsel.value = 'me'; }
                else if (w.indexOf('dev:') === 0) {
                    const o = document.createElement('option');
                    o.value = w; o.dataset.dyn = '1';
                    o.textContent = 'на: ' + (r.where_name || 'інший компʼютер')
                        + (r.where_user ? ' · ' + r.where_user : '');
                    wsel.appendChild(o); wsel.value = w;
                } else { wsel.value = w; }
            }
        }
    } catch (e) { /**/ }
    if (wsel) wsel.addEventListener('change', async () => {
        let w = wsel.value;
        const body = { enabled: el.checked };
        if (w === 'me') {
            w = DEV.key || 'me';
            body.where_name = DEV.name || '';
            body.where_user = DEV.user || '';
        }
        body.where = w;
        try {
            const r = await apiSend('/api/feed/pool-auto', 'POST', body);
            if (!r || !r.ok) toast((r && r.error) || 'Помилка', 'error');
            else toast('Збережено', 'success');
        } catch (e) { toast('Сервер не відповів', 'error'); }
    });
    el.addEventListener('change', async () => {
        try {
            const r = await apiSend('/api/feed/pool-auto', 'POST',
                { enabled: el.checked, now: el.checked });
            if (!r || !r.ok) { el.checked = !el.checked; toast((r && r.error) || 'Помилка', 'error'); }
            else {
                const n = (r.filled || []).length;
                toast(el.checked
                    ? (n ? ('Заповнено днів: ' + n) : 'Правило увімкнено')
                    : 'Правило вимкнено', 'success');
                if (n) loadLeftPanel();
            }
        } catch (err) { el.checked = !el.checked; }
    });
})();

/* Кнопка «Зафіксувати списання» — списує рівно цей рух за обраний період */
(() => {
    const btn = $('flWriteoffBtn');
    if (!btn) return;
    btn.addEventListener('click', async () => {
        const from = $('flFrom').value || '', to = $('flTo').value || '';
        const period = (from || to) ? `за період ${from || '…'} — ${to || '…'}` : 'за весь період';
        if (!await confirmAction(`Зафіксувати списання годівлі ${period}?\n\n`
            + 'Корми буде знято зі складу рівно за цим рухом (вода — за 0, '
            + 'нестача — в мінус). Повторно вже списане не дублюється.')) return;
        btn.disabled = true;
        try {
            const r = await apiSend('/api/feed/writeoff', 'POST', { from, to });
            if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); }
            else {
                toast(`Списано замісів: ${r.done_count}`
                    + (r.debt_lines ? ` · у мінус: ${r.debt_lines}` : '')
                    + (r.created_products ? ` · нових кормів: ${r.created_products}` : ''), 'success');
                loadTree();
            }
        } catch (e) { toast('Сервер не відповів', 'error'); }
        btn.disabled = false;
    });
})();

/* ===== По кормах: Корм → Категорія → Підкатегорія ===== */
let ingUsage = [];
let fiByDate = false;           // режим: false=Категорії, true=просто по датах
const openIng = new Set();      // ключ = корм (name|code)
const openIngCat = new Set();   // ключ = корм|категорія
const openIngSub = new Set();   // ключ = корм|категорія|підкатегорія

/* Ручна агрегація корму по датах (усі категорії/підкатегорії разом) */
function fiRatioAcc(kg, plan) {
    if (!kg || !plan) return null;
    const r = Math.min(kg, plan) / Math.max(kg, plan);
    return Math.round(r * 1000) / 10;
}
/* % ширини гістограми залишку (0..100) відносно максимуму по цьому корму */
function fiBarPct(val, max) {
    if (val == null || !max || max <= 0) return null;
    return Math.max(0, Math.min(100, Math.round(val / max * 100)));
}
function fiDatesFor(g) {
    const m = {};
    (g.cats || []).forEach((c) => (c.subs || []).forEach((sb) => (sb.days || []).forEach((d) => {
        const e = m[d.date] || (m[d.date] = { date: d.date, plan: 0, kg: 0, dry: 0, sum: 0, hasSum: false });
        e.plan += d.plan || 0; e.kg += d.kg || 0; e.dry += d.dry || 0;
        if (d.sum != null) { e.sum += d.sum; e.hasSum = true; }
    })));
    const tot = g.kg || 0;
    const sb = g.stock_by_date || {};
    return Object.values(m).sort((a, b) => (a.date < b.date ? 1 : -1)).map((e) => ({
        date: e.date, plan: e.plan, kg: e.kg, dry: e.dry,
        dev: e.plan ? (e.kg - e.plan) : null,
        acc: e.plan ? fiRatioAcc(e.kg, e.plan) : null,
        price: (e.hasSum && e.kg) ? (e.sum / e.kg) : null,
        sum: e.hasSum ? e.sum : null,
        share: tot ? Math.round(e.kg / tot * 1000) / 10 : null,
        stock_left: (sb[e.date] != null) ? sb[e.date] : null,   // складський залишок на дату
        stock_bar: fiBarPct(sb[e.date], g._stockMax),
    }));
}

const ingKey = (g) => (g.code || g.name || '');

async function loadIngUsage() {
    const from = $('flFrom').value || '', to = $('flTo').value || '';
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    let r;
    try { r = await apiGet('/api/feed/usage-by-ingredient?' + qs.toString()); }
    catch (e) { r = { ok: false, error: 'Сервер не відповів' }; }
    if (!r || !r.ok) {
        $('fiBody').innerHTML = `<tr><td colspan="10" class="empty">${escapeHtml((r && (r.error || r.note)) || 'Помилка')}</td></tr>`;
        return;
    }
    ingUsage = r.ingredients || [];
    $('fiDiag').textContent = ingUsage.length ? ('Витрата: ' + fmt(r.total_kg) + ' кг') : (r.note || '');
    renderIngUsage();
    if (window.makeColumnsResizable) makeColumnsResizable('fiTable', 'farm:fi_cols');
}

/* 7 числових комірок: план, факт, відх, точн%, СР, ₴/кг, сума без ПДВ */
function fiCells(m) {
    // dev === null → плану немає (ручна годівля) → не показуємо відхилення
    const devHidden = (m.dev === null);
    const dev = devHidden ? 0
        : ((m.dev !== undefined) ? m.dev : ((m.kg || 0) - (m.plan || 0)));
    const st = m.stock_left;
    const bar = (m.stock_bar != null) ? ` style="--bar:${m.stock_bar}%"` : '';
    return `<td class="num fi-stock ${st == null ? '' : (st < 0 ? 'fi-stock-neg' : 'fi-stock-bar')}"${bar}><span class="fi-stock-v">${st == null ? '' : fmt(st)}</span></td>
        <td class="num">${fmt4(m.plan)}</td>
        <td class="num">${fmt4(m.kg)}</td>
        <td class="num ${devHidden ? '' : devCls(dev)}">${devHidden ? '—' : fmt4(dev)}</td>
        <td class="num fi-acc ${accCls(m.acc)}">${m.acc == null ? '—' : fmt(m.acc) + '%'}</td>
        <td class="num">${fmt4(m.dry)}</td>
        <td class="num">${m.price == null ? '—' : price4(m.price)}</td>
        <td class="num">${m.sum == null ? '—' : money(m.sum)}</td>`;
}

function renderIngUsage() {
    const body = $('fiBody');
    if (!ingUsage.length) {
        body.innerHTML = '<tr><td colspan="10" class="empty">Немає даних за період</td></tr>';
        return;
    }
    let totPlan = 0, totKg = 0, totSum = 0, totPVat = 0;
    const rows = ingUsage.map((g, ii) => {
        totPlan += g.plan || 0; totKg += g.kg || 0; totSum += g.sum || 0; totPVat += g.purchase_vat || 0;
        // залишок на рядку корму = залишок на останню (найновішу) дату періоду
        if (fiByDate) {
            const sd = g.stock_by_date || {}; const ds = Object.keys(sd).sort();
            const vals = Object.values(sd);
            g._stockMax = vals.length ? Math.max(...vals) : 0;
            g.stock_left = ds.length ? sd[ds[ds.length - 1]] : null;
            g.stock_bar = fiBarPct(g.stock_left, g._stockMax);
        } else { g.stock_left = undefined; g.stock_bar = null; }
        const gOpen = openIng.has(ingKey(g));
        let html = `<tr class="fi-ing-row inv-row">
            <td class="fi-toggle-cell"><button class="batch-toggle" data-ing-toggle="${ii}"
                title="Категорії">${gOpen ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(g.name)}</strong></td>${fiCells(g)}</tr>`;
        if (gOpen && fiByDate) {
            fiDatesFor(g).forEach((d) => {
                html += `<tr class="fi-cat-row">
                    <td class="fi-toggle-cell"></td>
                    <td class="fi-ind-1">${escapeHtml(d.date)}</td>${fiCells(d)}</tr>`;
            });
        } else if (gOpen) {
            (g.cats || []).forEach((c, ci) => {
                const cKey = ingKey(g) + '|' + c.category;
                const cOpen = openIngCat.has(cKey);
                const canOpenC = (c.subs || []).length > 0;
                html += `<tr class="fi-cat-row">
                    <td class="fi-toggle-cell">${canOpenC
                        ? `<button class="batch-toggle" data-ingcat="${ii}:${ci}"
                            title="Підкатегорії">${cOpen ? '▾' : '▸'}</button>` : ''}</td>
                    <td class="fi-ind-1">${escapeHtml(c.category)}</td>${fiCells(c)}</tr>`;
                if (cOpen) {
                    (c.subs || []).forEach((sb, si) => {
                        const sKey = cKey + '|' + sb.subgroup;
                        const sOpen = openIngSub.has(sKey);
                        const canOpenS = (sb.days || []).length > 0;
                        html += `<tr class="fi-sub-row">
                            <td class="fi-toggle-cell">${canOpenS
                                ? `<button class="batch-toggle" data-ingsub="${ii}:${ci}:${si}"
                                    title="Дати">${sOpen ? '▾' : '▸'}</button>` : ''}</td>
                            <td class="fi-ind-2">${escapeHtml(sb.subgroup)}</td>${fiCells(sb)}</tr>`;
                        if (sOpen) {
                            (sb.days || []).forEach((d) => {
                                html += `<tr class="fi-day-row">
                                    <td></td>
                                    <td class="fi-ind-3">${escapeHtml(d.date)}</td>${fiCells(d)}</tr>`;
                            });
                        }
                    });
                }
            });
        }
        return html;
    }).join('');
    body.innerHTML = rows + `<tr class="fi-total-row">
        <td></td><td><strong>Разом</strong></td>
        <td></td>
        <td class="num">${fmt4(totPlan)}</td><td class="num">${fmt4(totKg)}</td>
        <td class="num">${fmt4(totKg - totPlan)}</td><td></td><td></td><td></td>
        <td class="num">${money(totSum)}</td></tr>` + prodSectionHtml();
}

/* Комірки рядка виробництва: залишок, план, факт, відх, точн%, (СР —), ₴/кг, сума.
   План/відх/точн% беруться з рецепта КК. СР для компонентів не рахуємо. */
function prodCells(m) {
    const st = m.stock_left;
    const bar = (m.stock_bar != null) ? ` style="--bar:${m.stock_bar}%"` : '';
    const dev = (m.dev != null) ? m.dev : null;
    return `<td class="num fi-stock ${st == null ? '' : (st < 0 ? 'fi-stock-neg' : 'fi-stock-bar')}"${bar}><span class="fi-stock-v">${st == null ? '' : fmt(st)}</span></td>
        <td class="num">${m.plan == null ? '' : fmt4(m.plan)}</td>
        <td class="num">${fmt4(m.kg)}</td>
        <td class="num ${dev == null ? '' : devCls(dev)}">${dev == null ? '' : fmt4(dev)}</td>
        <td class="num fi-acc ${accCls(m.acc)}">${m.acc == null ? '' : fmt(m.acc) + '%'}</td>
        <td class="num">${m.dry == null ? '' : fmt4(m.dry)}</td>
        <td class="num">${m.price == null ? '' : price4(m.price)}</td>
        <td class="num">${m.sum == null ? '' : money(m.sum)}</td>`;
}

/* Секція «Виробництво комбікорму — розхід кормів» у таблиці «По кормах».
   Окремий підсумок, не входить у «Разом» вище (щоб не задвоїти роздачу). */
function prodSectionHtml() {
    if (!prodIng.length) return '';
    let pKg = 0, pSum = 0, pPlan = 0, pDry = 0;
    const rows = prodIng.map((g, ii) => {
        pKg += g.kg || 0; pSum += g.sum || 0; pPlan += g.plan || 0; pDry += g.dry || 0;
        // залишок на рядку корму = на останню дату; шкала — до максимуму по корму
        const sd = g.stock_by_date || {}; const vals = Object.values(sd);
        g._stockMax = vals.length ? Math.max(...vals) : 0;
        const ds = Object.keys(sd).sort();
        g.stock_left = ds.length ? sd[ds[ds.length - 1]] : null;
        g.stock_bar = fiBarPct(g.stock_left, g._stockMax);
        const open = openProdIng.has(ingKey(g));
        let h = `<tr class="fi-ing-row inv-row">
            <td class="fi-toggle-cell"><button class="batch-toggle" data-prod-toggle="${ii}"
                title="Дати">${open ? '▾' : '▸'}</button></td>
            <td><strong>${escapeHtml(g.name)}</strong></td>${prodCells(g)}</tr>`;
        if (open) {
            (g.days || []).forEach((d) => {
                d.stock_bar = fiBarPct(d.stock_left, g._stockMax);
                h += `<tr class="fi-cat-row"><td class="fi-toggle-cell"></td>
                    <td class="fi-ind-1">${escapeHtml(d.date)}</td>${prodCells(d)}</tr>`;
            });
        }
        return h;
    }).join('');
    const head = `<tr class="fu-cat-row"><td></td><td colspan="9">
        <strong>🏭 Виробництво комбікорму — розхід кормів</strong>
        <span class="k-sub" style="margin-left:8px;color:var(--text-muted,#9aa1a9)">не входить у «Разом» вище</span></td></tr>`;
    const pDev = pPlan ? (pKg - pPlan) : null;
    const total = `<tr class="fi-total-row"><td></td><td><strong>Разом виробництво</strong></td>
        <td></td><td class="num">${pPlan ? fmt4(pPlan) : ''}</td><td class="num">${fmt4(pKg)}</td>
        <td class="num">${pDev == null ? '' : fmt4(pDev)}</td><td></td>
        <td class="num">${pDry ? fmt4(pDry) : ''}</td><td></td>
        <td class="num">${money(pSum)}</td></tr>`;
    return head + rows + total;
}

$('fiBody').addEventListener('click', (e) => {
    const gBtn = e.target.closest('[data-ing-toggle]');
    if (gBtn) {
        const k = ingKey(ingUsage[+gBtn.dataset.ingToggle]);
        if (openIng.has(k)) openIng.delete(k); else openIng.add(k);
        renderIngUsage(); return;
    }
    const cBtn = e.target.closest('[data-ingcat]');
    if (cBtn) {
        const [ii, ci] = cBtn.dataset.ingcat.split(':').map(Number);
        const k = ingKey(ingUsage[ii]) + '|' + ingUsage[ii].cats[ci].category;
        if (openIngCat.has(k)) openIngCat.delete(k); else openIngCat.add(k);
        renderIngUsage(); return;
    }
    const sBtn = e.target.closest('[data-ingsub]');
    if (sBtn) {
        const [ii, ci, si] = sBtn.dataset.ingsub.split(':').map(Number);
        const c = ingUsage[ii].cats[ci];
        const k = ingKey(ingUsage[ii]) + '|' + c.category + '|' + c.subs[si].subgroup;
        if (openIngSub.has(k)) openIngSub.delete(k); else openIngSub.add(k);
        renderIngUsage(); return;
    }
    const pBtn = e.target.closest('[data-prod-toggle]');
    if (pBtn) {
        const k = ingKey(prodIng[+pBtn.dataset.prodToggle]);
        if (openProdIng.has(k)) openProdIng.delete(k); else openProdIng.add(k);
        renderIngUsage();
    }
});

/* Перемикач «Категорії ⇄ Просто по датах» у «По кормах» */
(() => {
    const seg = $('fiModeToggle');
    if (!seg) return;
    try { fiByDate = localStorage.getItem('farm:fi_bydate') === '1'; } catch (err) { /**/ }
    const sync = () => {
        seg.querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', (b.dataset.fimode === 'date') === fiByDate));
        const title = $('fiTitle'); const col = $('fiColName'); const tbl = $('fiTable');
        if (title) title.textContent = fiByDate ? 'По кормах: Корм → Дата' : 'По кормах: Корм → Категорія → Підкатегорія';
        if (col) col.textContent = fiByDate ? 'Корм / Дата' : 'Корм / Категорія / Підкатегорія / Дата';
        if (tbl) tbl.classList.toggle('fi-hide-stock', !fiByDate);   // залишок лише в режимі «по датах»
    };
    seg.addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn'); if (!b) return;
        fiByDate = (b.dataset.fimode === 'date');
        try { localStorage.setItem('farm:fi_bydate', fiByDate ? '1' : '0'); } catch (err) { /**/ }
        sync(); renderIngUsage();
    });
    sync();
})();

/* Кнопка «Скасувати всі списання» — повертає склад до стану до фіксації */
(() => {
    const btn = $('flUndoWoBtn');
    if (!btn) return;
    btn.addEventListener('click', async () => {
        if (!await confirmAction('Скасувати ВСІ зафіксовані списання годівлі?\n\n'
            + 'Кількість повернеться на партії, рухи ГД- та борги буде видалено, '
            + 'журнал очищено. Склад повернеться до стану ДО списань. '
            + 'Потім можна списати заново.')) return;
        btn.disabled = true;
        try {
            const r = await apiSend('/api/feed/undo-writeoffs', 'POST', {});
            if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); }
            else {
                toast(`Скасовано рухів: ${r.moves} · боргів: ${r.debt_batches} · `
                    + `журнал: ${r.events}`, 'success');
                loadTree();
            }
        } catch (e) { toast('Сервер не відповів', 'error'); }
        btn.disabled = false;
    });
})();

document.addEventListener('DOMContentLoaded', loadTree);
