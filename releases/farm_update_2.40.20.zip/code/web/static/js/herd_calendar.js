/* Календар стада: списки, які ферма складає сама.

   Роман 2026-09-17: «списки я можу створювати дуже гнучко і поглиблено…
   один список на всю ширину… налаштовую відображення параметрів… потім
   переключитися на календар і побачити, яку саме дату цей список буде діяти.
   І ще діаграму Ганта».

   Список = відбір (ті самі фільтри, що в груповому вводі) + дні тижня, на
   які він формується + колонки + подія, яку з нього вносять. «Строку» немає
   (Роман: «це налаштовується параметрами: „Днів з осіменіння“ ≥ 35») — на
   майбутній день параметри «днів від…» просто рахуються на той день.
   Рахується тут, у браузері, з тих самих значень, що й груповий ввід. */
'use strict';

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}
(function () {

const $ = (id) => document.getElementById(id);
const LS_VIEW = 'herd:cal_view', LS_RANGE = 'herd:cal_range';
const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch (_) { return ''; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) { /* ignore */ } };

let LISTS = [], COLORS = [], EVENTS = [], PARAMS = [], CHOICES = {}, ANIMALS = [];
let cur = null;                   // список, який зараз налаштовують
let cfgOpen = false;              // чи відкрито його налаштування
let view = lsGet(LS_VIEW) || 'list';
let month = TODAY_M();            // 'YYYY-MM' у вигляді «Календар» — спільний для всіх
const selDay = {};                // обраний день у кожному списку
let loadedKeys = new Set();
/* згорнуті списки — у кожного свій стан (Роман: «списки скриваються, розкриваються») */
const LS_CLOSED = 'herd:cal_closed';
let closed = new Set((() => { try { return JSON.parse(lsGet(LS_CLOSED) || '[]'); } catch (_) { return []; } })());
const saveClosed = () => lsSet(LS_CLOSED, JSON.stringify([...closed]));
function TODAY_M() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; }

/* ─────────── дати ─────────── */
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const TODAY = iso(new Date());
const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return iso(d); };
const diff = (a, b) => Math.round((parse(a) - parse(b)) / 86400000);
const dmy = (s) => s ? `${s.slice(8, 10)}.${s.slice(5, 7)}.${s.slice(0, 4)}` : '';
const MONTHS = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень', 'Липень',
    'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];
const WD = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];
const WD_LONG = ['понеділок', 'вівторок', 'середа', 'четвер', 'пʼятниця', 'субота', 'неділя'];
const wdOf = (s) => ((parse(s).getDay() + 6) % 7) + 1;      // 1 = пн … 7 = нд
const MON_SHORT = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];

/* ─────────── назви — з конструктора ─────────── */
const paramOf = (k) => PARAMS.find((p) => p.key === k) || null;
const pLabel = (k) => (paramOf(k) || {}).label || herdLabel(k, k);
const evByKey = (k) => EVENTS.find((e) => e.key === k) || null;

function choiceLabel(key, v) {
    const c = (CHOICES[key] || []).find((x) => String(x.value) === String(v));
    return herdOpt(key, v, c ? c.label : v);
}

/* порожня назва — «Подія · варіанти відбору» */
function nameOf(L) {
    if (L.name) return L.name;
    const ev = evByKey(L.event);
    const parts = [ev ? ev.name : herdEvent(L.event, 'Список')];
    (L.filters || []).forEach((f) => {
        // стать у назві не потрібна — вона й так видна з відбору; назву дають
        // лише значення зі списку (секція, код), а не числа
        const vals = f.vals && f.vals.length ? f.vals : (f.v !== undefined && f.v !== '' ? [f.v] : []);
        if (f.key !== 'sex' && (CHOICES[f.key] || []).length && vals.length && ['eq', 'ne'].includes(f.op || 'eq')) {
            parts.push((f.op === 'ne' ? 'не ' : '') + vals.map((v) => choiceLabel(f.key, v)).join(', '));
        }
    });
    return parts.join(' · ');
}

const colLabel = (k) => pLabel(k);
const colOk = (k) => !!paramOf(k);

/* списки зі «Строком» — до фільтрів і днів формування */
function normalize(L) {
    if (L.v !== 3) {
        L.cols = (L.cols || []).filter((k) => !String(k).startsWith('__'));
        if (L.sort && String(L.sort.key).startsWith('__')) L.sort = { key: 'tag', dir: 'asc' };
        if (L.group === 'due') L.group = '';
        L.v = 3;
    }
    L.days = L.days || [];
    // сортування — кількома колонками по черзі (Роман 2026-09-17)
    if (!Array.isArray(L.sorts) || !L.sorts.length) L.sorts = [L.sort || { key: 'tag', dir: 'asc' }];
    delete L.sort;
    // групування — кількома параметрами вкладено (Роман 2026-09-17)
    if (!Array.isArray(L.groups)) L.groups = L.group ? [L.group] : [];
    delete L.group;
    fxInit(L);
    return L;
}

/* ─────────── список = рядок формули ───────────
   Роман 2026-09-24: «всі налаштування в календар через строку формул».
   Тіло, фільтрація, сортування, групування й нумерація пишуться однією
   формулою BODY(…) FILTER(…) VIEW(…) — тією самою мовою, що в «Роботі зі
   стадом» (herd_query.js). Назва, колір, подія, дні, шрифт і аркуш — полями.
   Формула — джерело правди; filters/cols/sorts/groups/rownum виводяться з неї
   при кожному відкритті, тож назва налаштування у формулі бере його ПОТОЧНЕ
   число. Додатковий список — свій рядок FILTER(…). */
function fxFilterQ(f) {
    const o = calFilterQ(f);
    if (['empty', 'nempty'].includes(o.op)) return o;
    // «— не вказано» серед варіантів — це ЗНАЧЕННЯ (у формулі «[]»), а не
    // порожнеча; сама лише порожня умова нікого не відсіювала — її не пишемо
    if (o.vals && o.vals.length) return o;
    if (o.v === undefined || o.v === null) return null;
    if (o.v === '') return (f.vals && f.vals.length) ? o : null;
    return o;
}
function fxOfLegacy(L) {
    const hide = new Set(L.hide || []);
    const q = { cols: ['tag', ...(L.cols || []).filter((k) => k !== 'tag' && !hide.has(k))],
        filters: (L.filters || []).map(fxFilterQ).filter(Boolean),
        sorts: (L.sorts || []).filter((x) => !(L.sorts.length === 1 && x.key === 'tag' && x.dir !== 'desc')),
        groups: L.groups || [], rownum: L.rownum || false, aggs: [],
        // додаткові списки живуть у тому самому рядку: FILTER2([Пропущені] …)
        extra: (L.subs || []).map((sb) => ({ name: sb.name || '',
            filters: (sb.filters || []).map(fxFilterQ).filter(Boolean) }))
            .filter((e) => e.filters.length) };
    return window.herdQuery.format(q, PARAMS);
}
/* формула → поля, якими рахує й малює календар; помилка — лишаємо, що було */
function fxApply(L, text) {
    const src = String(text || '').trim();
    let f = src && !src.startsWith('=') ? '=' + src : src;
    const q = window.herdQuery.parse(f, PARAMS);
    if (q.error) return q.error;
    // додаткові, які ще не встигли переїхати в рядок (формула доти не читалась):
    // переносимо саме зараз, інакше перше ж виправлення стерло б їх назавжди
    if (!(q.extra || []).length && (L.subsLegacy || []).length) {
        q.extra = L.subsLegacy;
        f = window.herdQuery.format(q, PARAMS) || f;
        delete L.subsLegacy;
    }
    L.formula = f;
    L.cols = q.cols.filter((k) => k !== 'tag');
    L.filters = q.filters;
    L.sorts = q.sorts.length ? q.sorts : [{ key: 'tag', dir: 'asc' }];
    L.groups = q.groups;
    L.rownum = q.rownum || false;
    L.hide = [];
    L.aggs = q.aggs || [];
    // FILTER2([Пропущені] …) — ті самі «додаткові списки», лише одним рядком
    const was = (L.subs || []).map((sb) => sb.name);
    L.subs = (q.extra || []).filter((e) => e.filters && e.filters.length)
        .map((e, i) => ({ id: 's' + (i + 2), name: e.name || `Додаткові ${i + 2}`,
            filters: e.filters, formula: '' }));
    // перейменували додатковий — змінна в заголовку таблиці йде за ним.
    // ⚠️ Лише коли це ОДНОЗНАЧНО перейменування: зник рівно один блок і
    // зʼявився рівно один. Інакше видалення чи перестановка блоків підмінили б
    // у заголовку чуже число.
    if (L.title) {
        const now = L.subs.map((sb) => sb.name);
        const gone = was.filter((n) => n && !now.includes(n));
        const born = now.filter((n) => n && !was.includes(n));
        if (gone.length === 1 && born.length === 1) {
            L.title = L.title.split(`{${gone[0]}}`).join(`{${born[0]}}`);
        }
    }
    L.fxErr = '';
    return '';
}
function fxInit(L) {
    // додаткові списки, збережені ОКРЕМО (до 2.39.82), дописуємо в рядок
    const subs0 = (L.subs || []).map((sb) => ({ name: sb.name || '',
        filters: (sb.filters || []).map(fxFilterQ).filter(Boolean) })).filter((e) => e.filters.length);
    if (!L.formula) L.formula = fxOfLegacy(L);
    else if (subs0.length && !/\bFILTER\s*\d/i.test(L.formula)) {
        const q0 = window.herdQuery.parse(L.formula, PARAMS);
        if (!q0.error) {
            q0.extra = subs0;
            L.formula = window.herdQuery.format(q0, PARAMS);
        }
    }
    // помилку (параметр прибрали з конструктора) показуємо в ⚙; рахуємо тим, що було
    L.fxErr = fxApply(L, L.formula);
    if (L.fxErr) {
        // умова на параметр, якого вже немає, доти просто не діяла — лишаємо так
        L.filters = (L.filters || []).map(fxFilterQ).filter((f) => f && paramOf(f.key));
        // формули не зрозуміли, а умов не лишилось — це НЕ «усе стадо»:
        // порожній добір чесніший за список, у якому раптом усі тварини
        L.fxBroken = !L.filters.length;
        // додаткові теж лишаємо, як були, — вони вже в L.subs
        L.subs = (L.subs || []).map((sb) => Object.assign({}, sb,
            { filters: (sb.filters || []).map(fxFilterQ).filter((f) => f && paramOf(f.key)) }));
        // у рядок вони ще не переїхали (формула з помилкою) — памʼятаємо, щоб
        // перенести при першому вдалому розборі, а не втратити
        if (subs0.length && !/\bFILTER\s*\d/i.test(L.formula || '')) L.subsLegacy = subs0;
    } else { L.fxBroken = false; delete L.subsLegacy; }
}

/* ─────────── розрахунок ─────────── */
function formulaOf(k) {
    const p = paramOf(k);
    if (!p || !p.formula) return null;
    const src = String(p.formula).trim();
    if (src.startsWith('=')) {
        // рядок формули: «днів/місяців від дати» — DAYS(TODAY(), x) чи MONTHS(TODAY(), x),
        // можна й усередині IF(…) — тоді на інший день рахуємо так само
        const m = src.match(/\b(DAYS|MONTHS)\s*\(\s*TODAY\s*\(\s*\)\s*[,;]\s*\[?([^\],)]+?)\]?\s*\)/i);
        if (!m) return null;
        const w = m[2].trim().toLowerCase();
        const bp = PARAMS.find((x) => [x.short, x.key, x.label].some((y) => (y || '').toLowerCase() === w));
        return { op: m[1].toUpperCase() === 'DAYS' ? 'date_diff' : 'month_diff',
            a: '__today__', b: bp ? bp.key : '' };
    }
    try { const f = JSON.parse(p.formula); return f && f.op ? f : null; } catch (_) { return null; }
}
/* параметр «днів/місяців від дати» на інший день: сьогодні 30 — через тиждень 37 */
function valueOn(a, k, D) {
    const raw = (a.p || {})[k];
    if (D === TODAY) return raw;
    const f = formulaOf(k);
    if (!f || f.a !== '__today__' || !['date_diff', 'month_diff'].includes(f.op)) return raw;
    if (raw === '' || raw === null || raw === undefined) return raw;   // умова «лише якщо» не виконана
    const n = parseFloat(String(raw).replace(',', '.'));
    if (!isFinite(n)) return raw;
    if (f.op === 'date_diff') return String(n + diff(D, TODAY));
    const b = String((a.p || {})[f.b] || '').slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(b)) {
        const d1 = parse(b), d2 = parse(D);
        let m = (d2.getFullYear() - d1.getFullYear()) * 12 + d2.getMonth() - d1.getMonth();
        if (d2.getDate() < d1.getDate()) m -= 1;
        return String(m);
    }
    return String(n + Math.floor(diff(D, TODAY) / 30.44));
}

const isFormDay = (L, D) => !(L.days || []).length || L.days.includes(wdOf(D));
/* найближчий день формування від сьогодні */
function nextDay(L) {
    for (let i = 0; i < 7; i++) { const d = addDays(TODAY, i); if (isFormDay(L, d)) return d; }
    return TODAY;
}

/* додаткові списки (Роман 2026-09-17: «підсписок пропущених»): фільтри основного,
   а свої умови замінюють умову основного на той самий параметр */
function subFilters(L, sub) {
    const own = sub.filters || [];
    const keys = new Set(own.map((f) => f.key));
    return [...(L.filters || []).filter((f) => !keys.has(f.key)), ...own];
}
/* блоки на день D: основний + додаткові (лише на найближчий день формування);
   тварина, що вже є вище, у нижчий блок не потрапляє */
function blocksOf(L, D) {
    const main = membersOf(L, D);
    const out = [{ name: '', rows: main }];
    if (D !== nextDay(L)) return out;
    const seen = new Set(main.map((a) => a.id));
    (L.subs || []).forEach((sub) => {
        const rows = membersOf(L, D, subFilters(L, sub)).filter((a) => !seen.has(a.id));
        rows.forEach((a) => seen.add(a.id));
        out.push({ name: sub.name || 'Додатковий', rows, sub: true });
    });
    return out;
}
const blocksCount = (bl) => bl.reduce((t, b) => t + b.rows.length, 0);

function membersOf(L, D, filters) {
    if (L.fxBroken) return [];                     // формулу не прочитали — списку немає
    const day = D || TODAY;
    const flt = filters || L.filters || [];
    const out = [];
    ANIMALS.forEach((a) => {
        let x = a;
        if (day !== TODAY) {
            const p = Object.assign({}, a.p);
            flt.forEach((f) => { p[f.key] = valueOn(a, f.key, day); });
            x = { p, pl: a.pl };
        }
        if (window.herdQuery.passes(x, flt)) out.push(a);
    });
    return day === TODAY ? sortRows(L, out) : out;
}

function sortRows(L, rows) {
    const keys = (L.sorts && L.sorts.length ? L.sorts : [{ key: 'tag', dir: 'asc' }]);
    const val = (a, k) => {
        if (k === 'tag') return String(a.tag || '');
        const raw = (a.p || {})[k];
        return raw === null || raw === undefined ? '' : String((a.pl || {})[k] || raw);
    };
    const num = (v) => (/^-?\d+([.,]\d+)?$/.test(v) ? parseFloat(v.replace(',', '.')) : null);
    // списки (секції, коди) — у порядку конструктора, а не за абеткою
    const ord = {};
    keys.forEach((s) => {
        const ch = CHOICES[s.key] || [];
        if (ch.length) {
            ord[s.key] = new Map();
            ch.forEach((c, i) => { ord[s.key].set(String(c.value), i); ord[s.key].set(String(c.label), i); });
        }
    });
    const cmp = (x, y, k, dir) => {
        const a = val(x, k), b = val(y, k);
        if (a === '' && b !== '') return 1;               // порожні — завжди в кінці
        if (b === '' && a !== '') return -1;
        if (ord[k]) {
            const ia = ord[k].has(String((x.p || {})[k])) ? ord[k].get(String((x.p || {})[k])) : (ord[k].has(a) ? ord[k].get(a) : 1e6);
            const ib = ord[k].has(String((y.p || {})[k])) ? ord[k].get(String((y.p || {})[k])) : (ord[k].has(b) ? ord[k].get(b) : 1e6);
            if (ia !== ib) return (ia - ib) * dir;
        }
        const na = num(a), nb = num(b);
        const c = (na !== null && nb !== null) ? na - nb : a.localeCompare(b, 'uk', { numeric: true });
        return c * dir;
    };
    return rows.sort((x, y) => {
        for (const s of keys) {
            const c = cmp(x, y, s.key, s.dir === 'desc' ? -1 : 1);
            if (c) return c;
        }
        return cmp(x, y, 'tag', 1);                       // однакові — за номером
    });
}

/* колонки таблиці на день D: «днів від…» теж на той день */
const withDay = (a, D) => {
    if (D === TODAY) return a;
    const p = Object.assign({}, a.p);
    Object.keys(p).forEach((k) => { p[k] = valueOn(a, k, D); });
    return Object.assign({}, a, { p });
};

/* ─────────── завантаження ─────────── */
function neededKeys() {
    const ks = new Set(['group']);
    LISTS.forEach((L) => {
        (L.filters || []).forEach((f) => ks.add(f.key));
        (L.subs || []).forEach((sb) => (sb.filters || []).forEach((f) => ks.add(f.key)));
        (L.cols || []).forEach((c) => ks.add(c));
        (L.groups || []).forEach((c) => ks.add(c));
        (L.sorts || []).forEach((x) => ks.add(x.key));
        (L.aggs || []).forEach((x) => { if (x.key) ks.add(x.key); });   // VIEW(avg dcc…)
    });
    // від чого рахуються «днів від…» — потрібне, щоб рахувати місяці на інший день
    [...ks].forEach((k) => { const f = formulaOf(k); if (f && f.b && paramOf(f.b)) ks.add(f.b); });
    return [...ks].filter((k) => paramOf(k));
}

async function loadAnimals() {
    const keys = neededKeys();
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(',')));
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    ANIMALS = r.items || [];
    loadedKeys = new Set(keys);
}

async function ensureKeys() {
    if (neededKeys().some((k) => !loadedKeys.has(k))) await loadAnimals();
}

async function boot() {
    const [ev, ls] = await Promise.all([apiGet('/api/herd/events?active=1'), apiGet('/api/herd/cal-lists')]);
    if (!ev || !ev.ok || !ls || !ls.ok) {
        $('clLists').innerHTML = '<div class="cl-empty">Не вдалося завантажити календар</div>';
        return;
    }
    EVENTS = ev.events || [];
    PARAMS = ev.params || [];
    // назви налаштувань ферми у формулі (gestCow, spMax…) — розбір бере їх звідси
    window.HERD_CONSTS = ev.consts || [];
    CHOICES = {};
    PARAMS.forEach((p) => { CHOICES[p.key] = p.choices || []; });
    LISTS = (ls.lists || []).map(normalize);
    LAST_SRV = JSON.stringify(ls.lists || []);
    COLORS = ls.colors || [];
    await loadAnimals();
    renderAll();
    openFromHash();
}

/* прийшли з «Роботи зі стадом» кнопкою «📅 У календар» — одразу до нового списку */
function openFromHash() {
    const m = location.hash.match(/^#l=(.+)$/);
    if (!m) return;
    const L = listById(decodeURIComponent(m[1]));
    history.replaceState(null, '', location.pathname);
    if (!L) return;
    if (view === 'gantt') { view = 'list'; lsSet(LS_VIEW, view); renderAll(); }
    closed.delete(L.id); saveClosed();
    cur = L; cfgOpen = true;
    renderAll();
    const p = panelOf(L);
    if (p) p.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* Списки могли змінити деінде (інша вкладка, «📅 У календар»): повернулись на
   сторінку — перечитуємо, інакше наступне збереження цієї сторінки стерло б
   новий список. Поки своє ще не збережено — не чіпаємо. */
let LAST_SRV = '';
document.addEventListener('visibilitychange', async () => {
    if (document.hidden || save.t || !LAST_SRV) return;
    const ls = await apiGet('/api/herd/cal-lists').catch(() => null);
    if (!ls || !ls.ok || save.t) return;
    const txt = JSON.stringify(ls.lists || []);
    if (txt === LAST_SRV) return;
    const openId = cur && cfgOpen ? cur.id : null;
    LISTS = (ls.lists || []).map(normalize);
    LAST_SRV = txt;
    cur = openId ? listById(openId) : null;
    cfgOpen = !!cur;
    await ensureKeys();
    renderAll();
});

/* ─────────── збереження ─────────── */
function save() {
    clearTimeout(save.t);
    $('cfSaved').textContent = '…';
    save.t = setTimeout(async () => {
        const me = save.t;
        let r = null, fresh = false;
        // сервер ЗАМІНЮЄ всі списки тим, що прийшло: спершу звіряємось із ним,
        // інакше список, доданий тим часом із «Роботи зі стадом», зник би
        try {
            const srv = await apiGet('/api/herd/cal-lists').catch(() => null);
            if (srv && srv.ok) {
                const mine = new Set(LISTS.map((x) => x.id));
                const known = new Set(JSON.parse(LAST_SRV || '[]').map((x) => x.id));
                const add = (srv.lists || []).filter((x) => !mine.has(x.id) && !known.has(x.id));
                if (add.length) { LISTS = LISTS.concat(add.map(normalize)); fresh = true; }
            }
            r = await apiSend('/api/herd/cal-lists', 'POST', { lists: LISTS });
        } catch (e) { r = null; }
        finally { if (save.t === me) save.t = null; }  // інакше сторінка більше не перечитувалась би
        if (r && r.ok) {
            LAST_SRV = JSON.stringify(r.lists || []);
            // відповідь — те саме, що ми щойно послали; ЗАМІНЮВАТИ LISTS не
            // можна: відкриті налаштування тримають сам обʼєкт списку, і нові
            // копії закрили б коробку ⚙ просто під рукою
            const mine = new Set(LISTS.map((x) => x.id));
            const add = (r.lists || []).filter((x) => !mine.has(x.id));
            if (add.length) { LISTS = LISTS.concat(add.map(normalize)); fresh = true; }
            if (fresh) { await ensureKeys(); renderAll(); }
        }
        $('cfSaved').textContent = r && r.ok ? '✓ збережено' : 'не збережено';
        if (r && r.ok) setTimeout(() => { $('cfSaved').textContent = ''; }, 1500);
    }, 600);
}
const changed = async () => { save(); await ensureKeys(); updateAll(); };

/* ─────────── каркас: усі списки один під одним ─────────── */
function renderAll() {
    renderTop();
    const box = $('clLists');
    $('clHold').appendChild($('clCfg'));             // налаштування не губляться при перебудові
    if (view === 'gantt') {
        box.innerHTML = '<div class="cl-gantt" id="clGantt"></div>';
        renderGantt();
        return;
    }
    box.innerHTML = LISTS.map((L) => `<div class="cl-panel" data-id="${escapeHtml(L.id)}">
        <div class="cl-head"><span class="cl-grip" draggable="true" title="Потягніть, щоб переставити">⠿</span>
            <span class="cl-no"></span><span class="cl-chev"></span><h2></h2><span class="cl-cnt"></span>
            <button type="button" class="cl-err" hidden title="Відкрити налаштування">⚠ формула з помилкою</button>
            <span class="hp-sp"></span><a class="cl-go" hidden></a>
            <button type="button" class="cl-print" title="Друк на A4 — з попереднім переглядом">🖨</button>
            <button type="button" class="cl-gear" title="Налаштувати список">⚙</button></div>
        <div class="cl-title" hidden></div><div class="cl-slot"></div><div class="cl-body"></div></div>`).join('')
        || '<div class="cl-empty">Списків немає — «+ список»</div>';
    if (cur && cfgOpen && LISTS.includes(cur)) {
        const slot = box.querySelector(`.cl-panel[data-id="${CSS.escape(cur.id)}"] .cl-slot`);
        if (slot) { slot.appendChild($('clCfg')); renderCfg(); }
    } else {
        cfgOpen = false;
    }
    updateAll();
}

function renderTop() {
    document.querySelectorAll('#clView .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.v === view));
    const t = $('clTools');
    if (view === 'cal') {
        const [y, m] = month.split('-').map(Number);
        t.innerHTML = `<button type="button" data-m="-1">‹</button><b>${MONTHS[m - 1]} ${y}</b>
            <button type="button" data-m="1">›</button><button type="button" data-m="0">Сьогодні</button>`;
    } else if (view === 'gantt') {
        const span = +(lsGet(LS_RANGE) || 60);
        t.innerHTML = `<span class="segmented">${[[30, 'Місяць'], [60, '2 місяці'], [120, '4 місяці'], [365, 'Рік']]
            .map(([v, n]) => `<button type="button" class="seg-btn${v === span ? ' is-active' : ''}" data-r="${v}">${n}</button>`).join('')}</span>`;
    } else {
        t.innerHTML = '';
    }
}

$('clTools').addEventListener('click', (e) => {
    const m = e.target.closest('[data-m]'), r = e.target.closest('[data-r]');
    if (m) {
        const k = +m.dataset.m;
        if (k === 0) month = TODAY_M();
        else { const [y, mo] = month.split('-').map(Number); const d = new Date(y, mo - 1 + k, 1); month = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; }
        renderTop(); updateAll();
    } else if (r) {
        lsSet(LS_RANGE, r.dataset.r);
        renderTop(); renderGantt();
    }
});

function updateAll() {
    if (view === 'gantt') { renderGantt(); return; }
    LISTS.forEach(update);
}

const panelOf = (L) => $('clLists').querySelector(`.cl-panel[data-id="${CSS.escape(L.id)}"]`);
const listById = (id) => LISTS.find((L) => L.id === id) || null;

/* ─────────── налаштування списку ─────────── */
function renderCfg() {
    if (!cur) return;
    $('cfName').value = cur.name || '';
    $('cfName').placeholder = nameOf(Object.assign({}, cur, { name: '' }));
    $('cfEvent').innerHTML = '<option value="">— без події —</option>' + EVENTS.map((e) =>
        `<option value="${escapeHtml(e.key)}"${e.key === cur.event ? ' selected' : ''}>${escapeHtml(e.name)}</option>`).join('');
    $('cfColors').innerHTML = COLORS.map((c) =>
        `<button type="button" data-c="${c}" style="--sw:${c}"${c === cur.color ? ' class="on"' : ''}></button>`).join('');
    fxRender();
    renderSubs();
    renderDays();
    renderView();
}

/* ─── рядок формули списку ─── */
let FX = null;
function fxMsg(el, err, ok) {
    el.textContent = err || ok || '';
    el.classList.toggle('bad', !!err);
}
function fxRender() {
    if (!FX) {
        FX = herdFxEdit($('cfFx'), {
            params: () => PARAMS,
            groups: fxGroups,
            placeholder: 'BODY(id name group dslh) FILTER(rc=4 dslh between 28 35) VIEW(nogroup groupby group sort id)',
            onEnter: () => fxDo(),
            onInput: () => { $('cfFx').classList.remove('is-bad'); },
        });
        FX.input.addEventListener('blur', () => { if (cur && cfgOpen && FX.get().trim() !== fxShown()) fxDo(); });
    }
    FX.set(fxShown());
    $('cfFx').classList.toggle('is-bad', !!cur.fxErr);
    fxMsg($('cfFxMsg'), cur.fxErr, '');
}
const fxShown = () => String((cur && cur.formula) || '').replace(/^\s*=/, '');
// значення для «group=…» — секції, де є тварини
const fxGroups = () => [...new Set(ANIMALS.map((a) => (a.pl || {}).group || (a.p || {}).group).filter(Boolean))]
    .sort((a, b) => String(a).localeCompare(String(b), 'uk', { numeric: true }));
async function fxDo() {
    if (!cur) return;
    const L = cur;
    const err = fxApply(L, FX.get());
    $('cfFx').classList.toggle('is-bad', !!err);
    if (err) { fxMsg($('cfFxMsg'), err); return; }
    FX.set(fxShown());
    $('cfName').placeholder = nameOf(Object.assign({}, L, { name: '' }));
    // назва додаткового могла змінитись — за нею йдуть і підпис, і змінна
    // заголовка; без цього поле заголовка повернуло б стару назву
    $('cfTitle').value = L.title || '';
    renderSubs();
    await changed();
    if (cur !== L || !cfgOpen) return;             // за цей час відкрили інший список
    const D = nextDay(L);
    fxMsg($('cfFxMsg'), '', `✓ застосовано · ${blocksOf(L, D)[0].rows.length} на ${dayWord(D)}`);
}

/* ─── додаткові списки живуть У ТОМУ САМОМУ рядку: FILTER2([Пропущені] …)
   (Роман 2026-09-24: «тоді в календарі можна буде одною строкою все писати»).
   Кнопка лише дописує заготовку в рядок формули. ─── */
function renderSubs() {
    const box = $('cfSubs');
    const subs = cur.subs || [];
    box.innerHTML = subs.length
        ? `<div class="cl-hint0">Додаткові: ${subs.map((sb, i) =>
            `<b>${escapeHtml(sb.name)}</b> — FILTER${i + 2}(…)`).join(' · ')}
            — правити їх у самому рядку формули вище</div>`
        : '';
    renderTokens();
}
$('cfAddSub').addEventListener('click', () => {
    if (!FX) return;
    // найчастіше — ті самі умови, лише пропущений строк: беремо числові умови основного
    const copy = (cur.filters || []).filter((f) => { const p = paramOf(f.key); return p && ['int', 'float'].includes(p.dtype); })
        .map((f) => ({ key: f.key, op: 'gt', v: f.op === 'between' ? f.v2 : f.v }))
        .filter((f) => f.v !== undefined && f.v !== '');
    const n = (cur.subs || []).length + 2;
    const conds = copy.length ? window.herdQuery.format({ cols: [], filters: copy, sorts: [],
        groups: [], rownum: false, aggs: [] }, PARAMS).replace(/^=FILTER\(|\)$/g, '') : '';
    const add = ` FILTER${n}([Пропущені] ${conds})`;
    FX.set((FX.get().trim() + add).trim());
    FX.focus();
    // курсор — перед закриваючою дужкою, щоб одразу дописати умову
    const at = FX.input.value.length - 1;
    FX.input.setSelectionRange(at, at);
    fxMsg($('cfFxMsg'), '', conds ? 'Перевірте умови додаткового списку і натисніть Enter'
        : 'Допишіть умови додаткового списку і натисніть Enter');
});

/* ─── ширина колонок на екрані; шрифт, аркуш і колонки друку — у вікні друку,
   як у «Роботі зі стадом» (Роман 2026-09-24: «налаштування друку в календарі
   абсолютно такі самі») ─── */
const DEF_W = { tag: 90, name: 110, __mark: 24, __no: 36 };
const colW = (L, k) => +((L.widths || {})[k]) || DEF_W[k] || 120;
const hasMarks = (L) => (L.subs || []).length > 0;
const tableWidth = (L) => [...(L.rownum ? ['__no'] : []), ...(hasMarks(L) ? ['__mark'] : []), 'tag', ...shownCols(L)].reduce((t, k) => t + colW(L, k), 0);
function tableStyle(L, all) {
    const f = L.font || {};
    const w = all.reduce((t, k) => t + colW(L, k), 0);
    return `width:${w}px;` + (f.size ? `font-size:${f.size}px;` : '')
        + (f.family ? `font-family:'${f.family}',sans-serif;` : '')
        + (f.bold ? 'font-weight:600;' : '') + (f.italic ? 'font-style:italic;' : '');
}
function renderView() {
    $('cfTitle').value = cur.title || '';
    renderTokens();
    document.querySelectorAll('#cfShort .seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x.dataset.s === (cur.short ? '1' : '0')));
}
$('cfTitle').addEventListener('input', () => { cur.title = $('cfTitle').value; save(); update(cur); });
$('cfTokens').addEventListener('click', (e) => {
    const b = e.target.closest('[data-t]');
    if (!b) return;
    const inp = $('cfTitle');
    const tok = `{${b.dataset.t}}`;
    const at = inp.selectionStart != null ? inp.selectionStart : inp.value.length;
    const endAt = inp.selectionEnd != null ? inp.selectionEnd : at;
    inp.value = inp.value.slice(0, at) + tok + inp.value.slice(endAt);
    inp.focus();
    inp.setSelectionRange(at + tok.length, at + tok.length);
    cur.title = inp.value;
    save();
    update(cur);
});
$('cfShort').addEventListener('click', (e) => {
    const x = e.target.closest('[data-s]');
    if (!x) return;
    cur.short = x.dataset.s === '1';
    renderView();
    changed();
});

/* тягнемо межу в заголовку — ширина зберігається в списку */
$('clLists').addEventListener('mousedown', (e) => {
    const rz = e.target.closest('.cl-rz');
    if (!rz) return;
    e.preventDefault(); e.stopPropagation();
    const L = listById(rz.closest('.cl-panel').dataset.id);
    const th = rz.closest('th'), table = th.closest('table');
    const k = th.dataset.k;
    const col = table.querySelector(`col[data-k="${CSS.escape(k)}"]`);
    const x0 = e.clientX, w0 = colW(L, k);
    rz.classList.add('on');
    const move = (ev) => {
        const w = Math.max(40, Math.round(w0 + ev.clientX - x0));
        L.widths = Object.assign({}, L.widths || {}, { [k]: w });
        col.style.width = w + 'px';
        table.style.width = tableWidth(L) + 'px';
    };
    const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        rz.classList.remove('on');
        save();
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
});

/* ─── друк: попередній перегляд аркушів A4 — спільний модуль herd_print.js ─── */
function printList(L) {
    window.herdPrint.open({
        state: L,                                  // orient / twocol живуть у списку
        twocolToggle: true,
        content: () => {
            const D = nextDay(L);
            const blocks = blocksOf(L, D);
            // пояснення стрілки: якщо кількість уже є в заголовку — лише назва
            // додаткові — як у «Роботі зі стадом»: назва блоку зліва від номера,
            // а в підписі «· додатково: Пропущені · 5»
            const ex = blocks.slice(1).filter((b) => b.rows.length);
            const exSub = ex.length ? ' · додатково: ' + ex.map((b) => `${b.name} · ${b.rows.length}`).join(' · ') : '';
            // кількість — завжди на аркуші: якщо заголовок її не містить, дописуємо
            const tpl = (L.title || '').trim() || '{Назва} · {Дата}';
            const hasN = /\{(Усього|За планом)\}/.test(tpl);
            const nSub = hasN ? '' : ` · ${blocksCount(blocks)} гол.`;
            return { title: nameOf(L), sub: titleOf(L, blocks, D, true) + nSub + exSub,
                body: listHtml(L, blocks, D, true) };
        },
        onChange: () => { save(); update(L); },
    });
}

/* дні формування списку: жодного не обрано — щодня */
function renderDays() {
    const on = new Set(cur.days || []);
    $('cfDays').innerHTML = WD.map((w, i) =>
        `<button type="button" class="seg-btn${on.has(i + 1) ? ' is-active' : ''}" data-d="${i + 1}">${w}</button>`).join('');
    $('cfDaysNote').textContent = on.size ? '' : 'щодня';
}
$('cfDays').addEventListener('click', (e) => {
    const b = e.target.closest('[data-d]');
    if (!b) return;
    const d = +b.dataset.d;
    const on = new Set(cur.days || []);
    if (on.has(d)) on.delete(d); else on.add(d);
    cur.days = [...on].sort();
    renderDays();
    changed();
});
$('cfName').addEventListener('input', () => { cur.name = $('cfName').value.trim(); save(); update(cur); });
$('cfEvent').addEventListener('change', () => {
    cur.event = $('cfEvent').value;
    $('cfName').placeholder = nameOf(Object.assign({}, cur, { name: '' }));
    changed();
});
$('cfColors').addEventListener('click', (e) => {
    const b = e.target.closest('[data-c]');
    if (!b) return;
    cur.color = b.dataset.c;
    renderCfg();
    changed();
});
/* довідка до рядка формули згорнута — розгортається «Як писати», стан памʼятаємо */
const HELP_KEY = 'herd:cal_help';
function helpShow(on) {
    $('cfHelp').hidden = !on;
    $('cfHelpBtn').setAttribute('aria-expanded', on ? 'true' : 'false');
}
try { helpShow(localStorage.getItem(HELP_KEY) === '1'); } catch (e) { helpShow(false); }
$('cfHelpBtn').addEventListener('click', () => {
    const on = $('cfHelp').hidden;
    helpShow(on);
    try { localStorage.setItem(HELP_KEY, on ? '1' : '0'); } catch (e) { /* ignore */ }
});
$('cfDel').addEventListener('click', async () => {
    if (!cur || !(await confirmAction(`Видалити список «${nameOf(cur)}»?`, { ok: 'Видалити' }))) return;
    LISTS = LISTS.filter((L) => L !== cur);
    cur = null; cfgOpen = false;
    save();
    renderAll();
});
$('clNew').addEventListener('click', () => {
    const used = new Set(LISTS.map((L) => L.color));
    const L = {
        id: 'l' + Date.now().toString(36), name: '', event: '',
        color: COLORS.find((c) => !used.has(c)) || COLORS[0] || '#5b7083',
        filters: [], days: [],
        cols: ['name', 'group'], sorts: [{ key: 'tag', dir: 'asc' }], groups: [], v: 3,
    };
    fxInit(L);                                     // формула з тих самих полів: BODY(id name group)
    LISTS.push(L);
    cur = L; cfgOpen = true;
    closed.delete(L.id); saveClosed();
    if (view === 'gantt') { view = 'list'; lsSet(LS_VIEW, view); }
    save();
    renderAll();
    panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'center' });
    $('cfName').focus();
});

$('clView').addEventListener('click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (!b) return;
    view = b.dataset.v;
    lsSet(LS_VIEW, view);
    renderAll();
});

$('clLists').addEventListener('click', (e) => {
    const panel = e.target.closest('.cl-panel');
    const L = panel && listById(panel.dataset.id);
    if (!L) return;
    if (e.target.closest('.cl-gear')) {
        if (cur === L && cfgOpen) {
            cfgOpen = false;
            $('clHold').appendChild($('clCfg'));
        } else {
            cur = L; cfgOpen = true;
            closed.delete(L.id); saveClosed();
            panel.querySelector('.cl-slot').appendChild($('clCfg'));
            renderCfg();
        }
        LISTS.forEach(update);
        return;
    }
    if (e.target.closest('.cl-err')) {
        cur = L; cfgOpen = true;
        closed.delete(L.id); saveClosed();
        panel.querySelector('.cl-slot').appendChild($('clCfg'));
        renderCfg();
        LISTS.forEach(update);
        return;
    }
    if (e.target.closest('.cl-print')) { printList(L); return; }
    if (e.target.closest('.cl-go, .cl-cfg, .cl-grip, .cl-rz')) return;
    if (e.target.closest('.cl-head')) {
        if (closed.has(L.id)) closed.delete(L.id); else closed.add(L.id);
        saveClosed();
        update(L);
        return;
    }
    const day = e.target.closest('.cl-day');
    if (day && !day.classList.contains('off')) { selDay[L.id] = selDay[L.id] === day.dataset.d ? '' : day.dataset.d; update(L); return; }
    if (e.target.closest('.cl-dayx')) { selDay[L.id] = ''; update(L); }
});

/* ─────────── порядок: перетягування за ⠿ ─────────── */
let dragId = null;
$('clLists').addEventListener('dragstart', (e) => {
    const grip = e.target.closest && e.target.closest('.cl-grip');
    if (!grip) return;
    const panel = grip.closest('.cl-panel');
    dragId = panel.dataset.id;
    panel.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', dragId); e.dataTransfer.setDragImage(panel, 20, 16); } catch (_) { /* ignore */ }
});
$('clLists').addEventListener('dragover', (e) => {
    if (!dragId) return;
    const over = e.target.closest('.cl-panel');
    const src = $('clLists').querySelector('.cl-panel.dragging');
    if (!over || !src || over === src) { e.preventDefault(); return; }
    e.preventDefault();
    const r = over.getBoundingClientRect();
    const after = e.clientY > r.top + r.height / 2;
    over.parentNode.insertBefore(src, after ? over.nextSibling : over);
});
$('clLists').addEventListener('drop', (e) => { if (dragId) e.preventDefault(); });
$('clLists').addEventListener('dragend', () => {
    if (!dragId) return;
    dragId = null;
    const order = [...$('clLists').querySelectorAll('.cl-panel')].map((p) => p.dataset.id);
    $('clLists').querySelectorAll('.cl-panel.dragging').forEach((p) => p.classList.remove('dragging'));
    const next = order.map(listById).filter(Boolean);
    if (next.map((L) => L.id).join() === LISTS.map((L) => L.id).join()) return;
    LISTS = next;
    save();
    LISTS.forEach((L) => { const p = panelOf(L); if (p) p.querySelector('.cl-no').textContent = LISTS.indexOf(L) + 1; });
});

/* ─────────── один список ─────────── */
const dayWord = (D) => (D === TODAY ? 'сьогодні' : `${WD_LONG[wdOf(D) - 1]} ${dmy(D).slice(0, 5)}`);

function update(L) {
    const panel = panelOf(L);
    if (!panel) return;
    const isClosed = closed.has(L.id);
    panel.style.setProperty('--c', L.color);
    panel.classList.toggle('closed', isClosed);
    panel.querySelector('.cl-chev').textContent = isClosed ? '▸' : '▾';
    panel.querySelector('h2').textContent = nameOf(L);
    panel.querySelector('.cl-no').textContent = LISTS.indexOf(L) + 1;
    panel.querySelector('.cl-gear').classList.toggle('on', cur === L && cfgOpen);
    // помилку у формулі видно ОДРАЗУ: доти список мовчки рахувався за
    // попередніми умовами, і людина не знала, що її правка не діє
    const err = panel.querySelector('.cl-err');
    err.hidden = !L.fxErr;
    err.title = L.fxErr ? `${L.fxErr}. Показано за попередніми умовами — відкрийте ⚙` : '';
    const D = nextDay(L);
    const blocks = blocksOf(L, D);
    const extra = blocks.slice(1).map((b) => b.rows.length);
    panel.querySelector('.cl-cnt').innerHTML = `<b>${blocks[0].rows.length}</b>`
        + extra.map((n) => ` + <b>${n}</b>`).join('') + ` · ${dayWord(D)}`
        + ((L.days || []).length ? ` · ${L.days.map((d) => WD[d - 1]).join(', ')}` : '');
    // внести подію можна лише в день формування — сьогодні; одна кнопка на всі блоки
    const all = blocks.flatMap((b) => b.rows);
    const ev = evByKey(L.event), go = panel.querySelector('.cl-go');
    const can = ev && all.length && D === TODAY;
    go.hidden = !can;
    if (can) {
        go.textContent = `Внести «${ev.name}» · ${all.length}`;
        go.href = `/herd/group?event=${encodeURIComponent(ev.key)}&ids=${all.map((a) => a.id).join(',')}`;
    }
    // заголовок таблиці — одразу під назвою списку
    const tt = panel.querySelector(':scope > .cl-title');
    const showT = !isClosed && view !== 'cal' && (L.title || '').trim() && blocksCount(blocks);
    tt.hidden = !showT;
    // назва вже стоїть рядком вище — тут її не повторюємо (у друці лишається)
    tt.textContent = showT ? titleOf(L, blocks, D, true) : '';
    tt.hidden = !tt.textContent;
    if (isClosed) return;
    const body = panel.querySelector('.cl-body');
    body.innerHTML = view === 'cal' ? monthHtml(L) : listHtml(L, blocks, D, false, true);
}

/* значення колонки */
function cell(a, k) {
    const raw = (a.p || {})[k];
    if (raw === null || raw === undefined || raw === '') return '';
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = k === 'repro_code' ? '' : (a.pl || {})[k];
    if (lbl) return lbl;
    const num = numText(raw, (paramOf(k) || {}).dtype);
    if (num !== null) return num;
    if (/^\d{4}-\d{2}-\d{2}/.test(String(raw))) return dmy(String(raw).slice(0, 10));
    return String(raw);
}

/* видимі колонки таблиці: без схованих (ними лише сортують і групують) */
const shownCols = (L) => (L.cols || []).filter((k) => colOk(k) && !(L.hide || []).includes(k));

/* marks: id тварини → назва додаткового списку; такі рядки мають позначку зліва від номера */
function tableHtml(L, rows, D, forPrint, marks) {
    const cols = shownCols(L);
    // на друку позначка додаткових — не окрема колонка, а назва блоку ЗЛІВА ВІД
    // НОМЕРА (як у «Роботі зі стадом»); номер вирівняний праворуч, тож не зсувається
    const mk = hasMarks(L) && !forPrint;
    const pmk = hasMarks(L) && forPrint;
    const all = [...(L.rownum ? ['__no'] : []), ...(mk ? ['__mark'] : []), 'tag', ...cols];
    const th = (k, label) => `<th data-k="${escapeHtml(k)}">${escapeHtml(label)}${forPrint || k === '__mark' ? '' : '<span class="cl-rz"></span>'}</th>`;
    let no = 0;                                        // порядковий номер рядка
    // коротка назва — з конструктора («Скорочення»); немає — повна
    const hl = (k, full) => (L.short && (paramOf(k) || {}).short) || full;
    const thTag = forPrint ? `<th class="num">${escapeHtml(hl('tag', herdLabel('tag', 'Номер тварини')))}</th>` : th('tag', hl('tag', herdLabel('tag', 'Номер тварини')));
    const head = `<tr>${L.rownum ? th('__no', '№') : ''}${mk ? th('__mark', '') : ''}${thTag}${cols.map((k) => th(k, hl(k, colLabel(k)))).join('')}</tr>`;
    const colgroup = `<colgroup>${all.map((k) => `<col data-k="${escapeHtml(k)}" style="width:${colW(L, k)}px">`).join('')}</colgroup>`;
    const span = all.length;
    const list = sortRows(L, rows.map((a) => withDay(a, D || TODAY)));
    const markTd = (a) => {
        if (!mk) return '';
        const nm = marks && marks.get(a.id);
        return nm ? `<td class="cl-mk"><span title="${escapeHtml(nm)}">→</span></td>` : '<td class="cl-mk"></td>';
    };
    const tagTd = (a) => (forPrint
        ? `<td class="num">${pmk ? `<i class="exm">${escapeHtml((marks && marks.get(a.id)) || '')}</i>` : ''}<a class="tag">${escapeHtml(a.tag)}</a></td>`
        : `<td><a class="tag" href="/herd/animals/${a.id}">${escapeHtml(a.tag)}</a></td>`);
    // на папері нуль у колонці, де так налаштовано параметр, не друкуємо
    // (Роман 2026-09-25: «щоб економити фарбу в принтері»)
    const cellTxt = (a, k) => {
        const v = cell(a, k);
        if (!forPrint) return v;
        const p = paramOf(k);
        return (p && p.hide_zero && window.herdPrint.isZeroText(v)) ? '' : v;
    };
    const row = (a) => `<tr${marks && marks.has(a.id) ? ' class="is-extra"' : ''}>${L.rownum ? `<td class="cl-rn">${++no}</td>` : ''}${markTd(a)}${tagTd(a)}`
        + cols.map((k) => `<td${k === 'name' ? ' class="nm"' : ''}>${escapeHtml(cellTxt(a, k))}</td>`).join('') + '</tr>';
    let body;
    /* ПІДСУМКИ — як у «Роботі зі стадом» (Роман 2026-09-24: «чому на печатях не
       бачу підсумкових даних»): VIEW(cnt avg sum min max …) дає числа в шапці
       кожної групи У СВОЇХ колонках, а внизу — рядок «Разом» */
    const aggs = L.aggs || [];
    const aggVal = (ag, part) => {
        const filled = (x) => { const v = (x.p || {})[ag.key]; return !(v === null || v === undefined || v === ''); };
        if (ag.fn === 'cnt') return ag.key ? part.filter(filled).length : part.length;
        const nums = part.map((x) => parseFloat(String((x.p || {})[ag.key] ?? '').replace(',', '.')))
            .filter((n) => Number.isFinite(n));
        if (!nums.length) return null;
        if (ag.fn === 'sum') return nums.reduce((t, n) => t + n, 0);
        if (ag.fn === 'min') return Math.min(...nums);
        if (ag.fn === 'max') return Math.max(...nums);
        return nums.reduce((t, n) => t + n, 0) / nums.length;
    };
    const fmtN = (v, dec) => (Math.round(v * 10 ** dec) / 10 ** dec)
        .toLocaleString('uk-UA', { minimumFractionDigits: dec, maximumFractionDigits: dec });
    const shortOf = (k) => { const p = paramOf(k); return p ? (p.short || p.key) : k; };
    const sumRow = (part, title, cls) => {
        const byCol = new Map(), rest = [];
        aggs.forEach((ag) => {
            const v = aggVal(ag, part);
            if (v === null) return;
            const txt = fmtN(v, ag.fn === 'avg' ? 1 : 0);
            if (ag.key && cols.includes(ag.key)) byCol.set(ag.key, [...(byCol.get(ag.key) || []), txt]);
            else if (ag.fn === 'cnt' && !ag.key) rest.push(txt);
            else rest.push(`${ag.fn}${ag.key ? ' ' + escapeHtml(shortOf(ag.key)) : ''} ${txt}`);
        });
        const head = escapeHtml(title) + (aggs.some((ag) => ag.fn === 'cnt' && !ag.key) ? '' : ` · ${part.length}`)
            + (rest.length ? ` · ${rest.join(' · ')}` : '');
        // назва займає колонки до першої з числом — інакше вона розсуне номер
        const first = all.findIndex((k) => byCol.has(k));
        const lead = first < 0 ? all.length : first;
        return `<tr class="${cls}"><td colspan="${lead}">${head}</td>`
            + (first < 0 ? '' : all.slice(first).map((k) =>
                `<td>${byCol.has(k) ? `<b>${byCol.get(k).join(' · ')}</b>` : ''}</td>`).join(''))
            + '</tr>';
    };
    // групувати можна й за параметром, якого немає в BODY — тоді він лише в шапці групи
    const gs = (L.groups || []).filter(colOk);
    // вкладене групування: група → підгрупа → …; рядки всередині — за сортуванням
    const nest = (arr, lvl) => {
        if (lvl >= gs.length) {
            if (L.rownum === 'group') no = 0;              // «у кожній групі» — знову з 1
            return arr.map(row).join('');
        }
        const g = gs[lvl];
        const by = new Map();
        arr.forEach((a) => {
            const t = cell(a, g) || '— не вказано';
            if (!by.has(t)) by.set(t, []);
            by.get(t).push(a);
        });
        // порядок груп — як у конструкторі (секції, варіанти списку); решта — як ідуть за сортуванням
        const order = new Map();
        (CHOICES[g] || []).forEach((c, i) => { order.set(String(c.label), i); order.set(String(c.value), i); });
        const pos = (t) => (t === '— не вказано' ? 1e9 : (order.has(t) ? order.get(t) : 1e8));
        const lbl = gs.length > 1 ? `${escapeHtml(pLabel(g))}: ` : '';
        return [...by.entries()].sort((x, y) => pos(x[0]) - pos(y[0])).map(([t, part]) =>
            (aggs.length ? sumRow(part, `${gs.length > 1 ? pLabel(g) + ': ' : ''}${t}`, `sec l${Math.min(lvl, 2)}`)
                : `<tr class="sec l${Math.min(lvl, 2)}"><td colspan="${span}">${lbl}${escapeHtml(t)} · ${part.length}</td></tr>`)
            + nest(part, lvl + 1)).join('');
    };
    body = nest(list, 0);
    // «Разом» — коли є групи чи агрегації (як у «Роботі зі стадом»)
    if (list.length && (aggs.length || gs.length)) body += sumRow(list, 'Разом', 'tot');
    // друк: ширину колонок підбирає аркуш під вміст (herd_print fitTables), шрифт —
    // з вікна друку; ширини, натягнуті на екрані, на папір не йдуть
    if (forPrint) return `<table class="fit"><thead>${head}</thead><tbody>${body}</tbody></table>`;
    const table = `<table class="cl-tbl fixed" style="${tableStyle(L, all)}">${colgroup}<thead>${head}</thead><tbody>${body}</tbody></table>`;
    return `<div class="cl-scroll">${table}</div>`;
}

/* основний і додаткові — ОДНА таблиця (Роман: «злити в один список, щоб бачити по групах»);
   рядки додаткових позначені зліва від номера */
function mergeBlocks(blocks) {
    const marks = new Map();
    const rows = [];
    blocks.forEach((b, i) => b.rows.forEach((a) => { rows.push(a); if (i) marks.set(a.id, b.name); }));
    return { rows, marks };
}
// кнопки змінних заголовка — оновлюються й тоді, коли додали / перейменували додатковий список
function renderTokens() {
    if (!cur) return;
    $('cfTokens').innerHTML = titleTokens(cur).map((t) => `<button type="button" data-t="${escapeHtml(t)}" title="Вставити в заголовок">{${escapeHtml(t)}}</button>`).join('');
}

/* заголовок таблиці — з налаштувань, зі змінними: {Назва} {Дата} {Усього} {За планом} {<додатковий>} */
function titleTokens(L) {
    return ['Назва', 'Дата', 'Усього', 'За планом', ...(L.subs || []).map((sb) => sb.name || 'Додатковий')];
}
function titleOf(L, blocks, D, noName) {
    let tpl = (L.title || '').trim() || '{Назва} · {Дата}';
    if (noName) tpl = tpl.replace(/\{Назва\}\s*[·:—-]?\s*/g, '').trim();
    const vals = {
        'Назва': nameOf(L), 'Дата': dmy(D), 'Усього': String(blocksCount(blocks)),
        'За планом': String(blocks[0].rows.length),
    };
    blocks.slice(1).forEach((b) => { vals[b.name] = String(b.rows.length); });
    (L.subs || []).forEach((sb) => { const k = sb.name || 'Додатковий'; if (!(k in vals)) vals[k] = '0'; });
    return tpl.replace(/\{([^}]+)\}/g, (m, k) => (k in vals ? vals[k] : m));
}

function listHtml(L, blocks, D, forPrint, noTitle) {
    const { rows, marks } = mergeBlocks(blocks);
    if (!rows.length) {
        return `<div class="cl-empty">${(L.filters || []).length ? `На ${dayWord(D)} нікого` : 'Задайте фільтри — ⚙'}</div>`;
    }
    const legend = blocks.slice(1).filter((b) => b.rows.length).map((b) =>
        `<span class="cl-mk"><span>→</span></span> ${escapeHtml(b.name)} · ${b.rows.length}`).join(' &nbsp; ');
    const title = (L.title || '').trim() && !forPrint && !noTitle ? `<div class="cl-title">${escapeHtml(titleOf(L, blocks, D))}</div>` : '';
    return title + (legend && !forPrint && !(L.title || '').trim() ? `<div class="cl-legend">${legend}</div>` : '') + tableHtml(L, rows, D, forPrint, marks);
}

/* ─────────── календар місяця: список на кожен день формування ─────────── */
function monthHtml(L) {
    const [y, mo] = month.split('-').map(Number);
    const first = new Date(y, mo - 1, 1);
    const start = new Date(first);
    start.setDate(1 - ((first.getDay() + 6) % 7));           // понеділок
    const sd = selDay[L.id] || '';
    let cells = '';
    for (let i = 0; i < 42; i++) {
        const d = new Date(start); d.setDate(start.getDate() + i);
        if (i >= 35 && d.getMonth() !== mo - 1) break;
        const s = iso(d);
        const form = isFormDay(L, s) && s >= TODAY;
        const bl = form ? blocksOf(L, s) : [{ rows: [] }];
        const list = bl.flatMap((b) => b.rows);
        const extraIds = new Set(bl.slice(1).flatMap((b) => b.rows.map((a) => a.id)));
        const extraN = bl.slice(1).reduce((t, b) => t + b.rows.length, 0);
        // пропущені — червоною стрілкою, як у таблиці
        const nTxt = `${bl[0].rows.length}`;
        const cls = ['cl-day', d.getMonth() !== mo - 1 ? 'out' : '', s === TODAY ? 'today' : '',
            s === sd ? 'sel' : '', form ? '' : 'off'].filter(Boolean).join(' ');
        cells += `<div class="${cls}" data-d="${s}"><span class="dt"><span class="dn">${d.getDate()}</span>
            ${list.length ? `<span class="n">${nTxt}</span>` : ''}${extraN ? `<span class="cl-ex"><i class="cl-arr">→</i>${extraN}</span>` : ''}</span>
            ${list.slice(0, 2).map((a) => `<span class="tg">${extraIds.has(a.id) ? '<i class="cl-arr">→</i> ' : ''}${escapeHtml(a.tag)}${a.name ? ' ' + escapeHtml(a.name) : ''}</span>`).join('')}
            ${list.length > 2 ? `<span class="tg">ще ${list.length - 2}</span>` : ''}</div>`;
    }
    const dayBl = sd ? blocksOf(L, sd) : [];
    return `<div class="cl-month">${WD.map((w) => `<div class="cl-wd">${w}</div>`).join('')}${cells}</div>
        ${sd ? `<div class="cl-dayhead">${dayWord(sd)} ${dmy(sd).slice(6)} · ${blocksCount(dayBl)}
            <button type="button" class="cl-dayx">закрити</button></div>
            ${blocksCount(dayBl) ? listHtml(L, dayBl, sd) : '<div class="cl-empty">Цього дня нікого</div>'}` : ''}`;
}

/* ─────────── Гант: рядок = список ─────────── */
function renderGantt() {
    const span = +(lsGet(LS_RANGE) || 60);
    const from = TODAY;
    const days = [];
    for (let i = 0; i < span; i++) days.push(addDays(from, i));
    const cols = `grid-template-columns:repeat(${span}, minmax(0,1fr))`;
    // шкала: місяці
    let marks = '', prevM = '';
    days.forEach((d, i) => {
        const m = d.slice(0, 7);
        if (m !== prevM) {
            prevM = m;
            let len = 0;
            while (i + len < span && days[i + len].slice(0, 7) === m) len++;
            marks += `<span class="cl-gm" style="grid-column:${i + 1} / span ${len}">${MON_SHORT[+m.slice(5) - 1]} ${m.slice(0, 4)}</span>`;
        }
    });
    const rowsHtml = LISTS.map((L) => {
        const cnt = new Map();
        const parts = new Map(), mainN = new Map(), extraN = new Map();
        days.forEach((d) => {
            if (!isFormDay(L, d)) return;
            const bl = blocksOf(L, d);
            cnt.set(d, blocksCount(bl));
            parts.set(d, bl.map((b) => b.rows.length).join(' + '));
            mainN.set(d, bl[0].rows.length);
            extraN.set(d, blocksCount(bl) - bl[0].rows.length);
        });
        const max = Math.max(1, ...cnt.values());
        const cells = days.map((d) => {
            const form = cnt.has(d);
            const n = cnt.get(d) || 0;
            const wk = wdOf(d) === 1;
            const alpha = n ? (0.25 + 0.75 * n / max) : 0;
            // на блідій клітинці біле число не читається — темне
            const bg = n ? `background:color-mix(in srgb, ${L.color} ${Math.round(alpha * 100)}%, transparent)`
                + (alpha < 0.55 ? ';color:var(--text)' : '') : '';
            return `<span class="cl-gc${wk ? ' wk' : ''}${d === TODAY ? ' today' : ''}${form ? '' : ' off'}" data-l="${escapeHtml(L.id)}" data-d="${d}"
                style="${bg}" title="${escapeHtml(nameOf(L))} · ${WD[wdOf(d) - 1]} ${dmy(d)}${form ? ' · ' + parts.get(d) : ' · не формується'}">${n && span <= 60 ? (mainN.get(d) || '') : ''}${extraN.get(d) ? '<i class="cl-arr cl-garr">→</i>' : ''}</span>`;
        }).join('');
        return `<div class="cl-grow">
            <div class="cl-gname" data-l="${escapeHtml(L.id)}" style="--c:${L.color}"><i></i><span>${LISTS.indexOf(L) + 1}. ${escapeHtml(nameOf(L))}</span></div>
            <div class="cl-gcells" style="${cols}">${cells}</div></div>`;
    }).join('');
    const box = $('clGantt');
    if (!box) return;
    box.innerHTML = `
            <div class="cl-grow hdr"><div></div>
                <div class="cl-gcells" style="${cols}">${marks}</div></div>
            ${rowsHtml}
`;
    // клік по назві — до цього списку; по дню — календар із цим днем
    box.querySelectorAll('.cl-gname').forEach((n) => n.addEventListener('click', () => {
        closed.delete(n.dataset.l); saveClosed();
        view = 'list'; lsSet(LS_VIEW, view);
        renderAll();
        const L = listById(n.dataset.l);
        if (L) panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
    box.querySelectorAll('.cl-gc:not(.off)').forEach((c) => c.addEventListener('click', () => {
        closed.delete(c.dataset.l); saveClosed();
        view = 'cal'; lsSet(LS_VIEW, view);
        selDay[c.dataset.l] = c.dataset.d; month = c.dataset.d.slice(0, 7);
        renderAll();
        const L = listById(c.dataset.l);
        if (L) panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
}

boot();
/* Визначення списку — кольоровим рядком формули, як у «Роботі зі стадом»
   (Роман 2026-09-19: «підсвітку кольорами в Календар»). Наведіть мишу на
   назву списку — видно, кого він бере й як показує. */
function calFilterQ(f) {
    const op = f.op || (f.vals ? 'eq' : ((f.from || f.to) ? 'between' : (f.text ? 'has' : 'eq')));
    const o = { key: f.key, op };
    if (op === 'between') {
        o.v = f.v !== undefined ? f.v : f.from;
        o.v2 = f.v2 !== undefined ? f.v2 : f.to;
        if (!o.v2) o.op = 'ge';
        else if (!o.v) { o.op = 'le'; o.v = o.v2; }
    } else if (op === 'has') o.v = f.v !== undefined ? f.v : f.text;
    else if (f.vals && f.vals.length > 1) o.vals = f.vals;
    else if (f.vals && f.vals.length) o.v = f.vals[0];
    else o.v = f.v;
    return o;
}
function calFormula(L) {
    if (!window.herdQuery) return '';
    if (L.formula) return L.formula;
    const q = { cols: ['tag', ...(L.cols || []).filter((k) => k !== 'tag')],
        filters: (L.filters || []).map(calFilterQ), sorts: L.sorts || [],
        groups: L.groups || [], rownum: !!L.rownum, aggs: [] };
    return window.herdQuery.format(q, PARAMS);
}
let calTipT = null;
function calTipHide() { clearTimeout(calTipT); const t = $('calFxTip'); if (t) t.hidden = true; }
document.addEventListener('mouseover', (e) => {
    const h = e.target.closest('.cl-head h2');
    if (!h || h.contains(e.relatedTarget)) return;
    const panel = h.closest('.cl-panel');
    const L = LISTS.find((x) => x.id === (panel && panel.dataset.id));
    if (!L) return;
    clearTimeout(calTipT);
    calTipT = setTimeout(() => {
        let tip = $('calFxTip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'calFxTip';
            tip.className = 'fx-tip';
            document.body.appendChild(tip);
        }
        const hl = (t) => `<code class="qfc">${window.herdQuery.highlight(t, PARAMS)}</code>`;
        const subs = (L.subs || []).filter((sb) => sb.formula).map((sb) =>
            `<div class="fx-tip-h">${escapeHtml(sb.name || 'Додатковий')} — замість тих самих умов</div>`
            + hl(sb.formula)).join('');
        tip.innerHTML = `<div class="fx-tip-h">Список «${escapeHtml(L.name)}» як формула</div>`
            + hl(calFormula(L)) + subs;
        tip.hidden = false;
        const r = h.getBoundingClientRect();
        const w = tip.offsetWidth, ht = tip.offsetHeight;
        tip.style.left = `${Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8)))}px`;
        tip.style.top = `${Math.round(r.bottom + 6 + ht > window.innerHeight ? r.top - ht - 6 : r.bottom + 6)}px`;
    }, 0);          // підказки — миттєво (Роман 2026-09-24)
});
document.addEventListener('mouseout', (e) => {
    const h = e.target.closest('.cl-head h2');
    if (h && !h.contains(e.relatedTarget)) calTipHide();
});
window.addEventListener('scroll', calTipHide, true);

})();
