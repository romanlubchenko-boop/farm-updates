/* ===== Common helpers used everywhere ===== */

/* Назва того, куди видається: у Годівлі «Група тварин», в інших гілках «Блок».
   Значення приходить із base.html (window.BLOCK_WORDS). Запасні варіанти —
   на випадок сторінок без базового шаблона. */
function BW(form) {
    const w = window.BLOCK_WORDS || {};
    return w[form] || ({ nom: 'Блок', nom_pl: 'Блоки', acc: 'блок',
                         gen: 'блоку', gen_pl: 'блоків',
                         loc: 'блоку', loc_pl: 'блоках' })[form] || '';
}

/* Поточний користувач — з <meta> у base.html. На сторінках логіну/налаштування
   тегів немає, тому значення можуть бути null. */
const CURRENT_USER_ID = (function () {
    const m = document.querySelector('meta[name="current-user-id"]');
    const v = m ? parseInt(m.content, 10) : NaN;
    return Number.isFinite(v) ? v : null;
})();
const CURRENT_USER_ROLE = (function () {
    const m = document.querySelector('meta[name="current-user-role"]');
    return m ? m.content : '';
})();
const IS_ADMIN = CURRENT_USER_ROLE === 'admin';

/* Гілки, де в людини рівень «керування» (адмін — усі). Керівні кнопки
   ховаємо саме за цим, а не за роллю: користувач із «керуванням» гілкою
   має бачити ⚙ і проведення (Роман 2026-09-09). */
const CAN_MANAGE = new Set(
    ((document.querySelector('meta[name="can-manage"]') || {}).content || '')
        .split(',').map((x) => x.trim()).filter(Boolean));
function canManage(branch) { return IS_ADMIN || CAN_MANAGE.has(branch); }
window.CAN_MANAGE = CAN_MANAGE;
window.canManage = canManage;

/* Гілки, де людина ВНОСИТЬ дані (рівень «робота» або «керування»).
   За цим ховаємо щоденні операції — проведення, списання; керівні
   (налаштування, довідники, автоматика) лишаються за canManage. */
const CAN_WORK = new Set(
    ((document.querySelector('meta[name="can-work"]') || {}).content || '')
        .split(',').map((x) => x.trim()).filter(Boolean));
function canWork(branch) { return IS_ADMIN || CAN_WORK.has(branch); }
window.CAN_WORK = CAN_WORK;
window.canWork = canWork;

/* Чи має поточний користувач право скасовувати/редагувати операцію.
   Правила: адмін — будь-яку; власник — свою; легасі-операція без власника
   (user_id == null, створена до появи колонки) — дозволяємо будь-якому
   залогіненому, щоб старі записи можна було виправляти. */
function canModify(ownerUserId) {
    if (IS_ADMIN) return true;
    if (ownerUserId == null) return true;     // легасі — без власника
    return Number(ownerUserId) === Number(CURRENT_USER_ID);
}

/* Універсальний конструктор колонок: дозволяє користувачу галочками
   приховувати/показувати стовпці таблиці. Стан зберігається у localStorage.

   Виклик: setupColumnPicker({
       tableId: 'productsTable',
       storageKey: 'vetpharm:products_hidden',
       anchor: document.querySelector('#products .head-actions'),
       columns: [
           { key: 'name', label: 'Назва' },
           { key: 'code', label: 'Код' },
           ...
       ],
   });

   th у шаблоні мають data-col або data-sort з відповідним ключем.
   Спостерігає за tbody і застосовує видимість після кожного перемальовування. */
function setupColumnPicker(opts) {
    const table = document.getElementById(opts.tableId);
    if (!table) return;
    if (table.dataset.colPickerInit === '1') return;
    table.dataset.colPickerInit = '1';

    const storageKey = opts.storageKey;
    const columns = opts.columns || [];

    // Завантажуємо приховані колонки з localStorage
    let hidden = new Set();
    try {
        hidden = new Set(JSON.parse(localStorage.getItem(storageKey) || '[]'));
    } catch (_) { hidden = new Set(); }

    function save() {
        localStorage.setItem(storageKey, JSON.stringify([...hidden]));
    }

    function getKey(th) { return th.dataset.col || th.dataset.sort || null; }

    function apply() {
        const ths = [...table.querySelectorAll('thead th')];
        const indexByKey = {};
        ths.forEach((th, i) => {
            const key = getKey(th);
            if (key) indexByKey[key] = i;
            th.style.display = (key && hidden.has(key)) ? 'none' : '';
        });
        // ⚠️ ЛИШЕ ВЛАСНІ рядки таблиці. Без `:scope >` сюди потрапляли рядки
        // ВКЛАДЕНИХ таблиць (розкритий пакет у журналі, партії на складі) —
        // і якщо в такого рядка випадково стільки ж клітинок, скільки
        // заголовків, вибір колонок ховав у ньому чужу за номером.
        table.querySelectorAll(':scope > tbody > tr').forEach((tr) => {
            // Пропускаємо «службові» рядки із colspan (Завантаження…, Поки що порожньо)
            if (tr.children.length !== ths.length) return;
            for (const key in indexByKey) {
                const td = tr.children[indexByKey[key]];
                if (td) td.style.display = hidden.has(key) ? 'none' : '';
            }
        });
        // У tfoot теж застосовуємо
        table.querySelectorAll(':scope > tfoot > tr').forEach((tr) => {
            if (tr.children.length !== ths.length) return;
            for (const key in indexByKey) {
                const td = tr.children[indexByKey[key]];
                if (td) td.style.display = hidden.has(key) ? 'none' : '';
            }
        });
    }

    // Кнопка + спадне меню
    if (opts.anchor) {
        const wrap = document.createElement('div');
        wrap.className = 'col-picker';
        wrap.innerHTML =
            '<button type="button" class="btn btn-ghost col-picker-btn" ' +
              'title="Налаштування колонок">⚙ Колонки</button>' +
            '<div class="col-picker-menu" hidden>' +
              '<div class="col-picker-title">Видимі колонки</div>' +
              columns.map((c) =>
                '<label class="col-picker-item">' +
                  '<input type="checkbox" data-key="' + c.key + '" ' +
                  (hidden.has(c.key) ? '' : 'checked') + '>' +
                  '<span>' + c.label + '</span>' +
                '</label>'
              ).join('') +
              '<div class="col-picker-actions">' +
                '<button type="button" class="btn btn-ghost" data-col-action="all">Усі</button>' +
                '<button type="button" class="btn btn-ghost" data-col-action="none">Жодної</button>' +
                '<button type="button" class="btn btn-ghost" data-col-action="close">Готово</button>' +
              '</div>' +
            '</div>';
        opts.anchor.appendChild(wrap);

        const btn = wrap.querySelector('.col-picker-btn');
        const menu = wrap.querySelector('.col-picker-menu');

        function positionMenu() {
            // Скидаємо інлайн-стилі, щоб виміри offsetHeight/Width були чистими
            menu.style.top = '';
            menu.style.left = '';
            const btnRect = btn.getBoundingClientRect();
            const menuHeight = menu.offsetHeight;
            const menuWidth  = menu.offsetWidth;
            const spaceBelow = window.innerHeight - btnRect.bottom;
            const spaceAbove = btnRect.top;
            // Вертикаль: за замовчуванням знизу від кнопки. Якщо знизу замало —
            // ставимо над кнопкою (відкривається вгору).
            let top;
            if (spaceBelow < menuHeight + 12 && spaceAbove > spaceBelow) {
                top = btnRect.top - menuHeight - 4;
                if (top < 4) top = 4;
            } else {
                top = btnRect.bottom + 4;
            }
            // Горизонталь: правий край меню вирівняний з правим краєм кнопки;
            // якщо менеджер виходить за лівий край вікна — пресуємо до 4 px.
            let left = btnRect.right - menuWidth;
            if (left < 4) left = 4;
            if (left + menuWidth > window.innerWidth - 4) {
                left = window.innerWidth - menuWidth - 4;
            }
            menu.style.top  = top  + 'px';
            menu.style.left = left + 'px';
        }

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (menu.hidden) {
                menu.hidden = false;
                // Виміри тільки коли елемент видимий → виставляємо позицію
                positionMenu();
            } else {
                menu.hidden = true;
            }
        });
        // Якщо змінився розмір вікна або сторінка прокрутилась —
        // перерахуємо положення, поки меню відкрите
        window.addEventListener('scroll', () => {
            if (!menu.hidden) positionMenu();
        }, { passive: true });
        window.addEventListener('resize', () => {
            if (!menu.hidden) positionMenu();
        });
        document.addEventListener('click', (e) => {
            if (!wrap.contains(e.target)) menu.hidden = true;
        });
        menu.querySelectorAll('input[type="checkbox"]').forEach((inp) => {
            inp.addEventListener('change', () => {
                if (inp.checked) hidden.delete(inp.dataset.key);
                else hidden.add(inp.dataset.key);
                save();
                apply();
            });
        });
        menu.querySelectorAll('[data-col-action]').forEach((b) => {
            b.addEventListener('click', (e) => {
                e.stopPropagation();
                const act = b.dataset.colAction;
                if (act === 'all') {
                    hidden.clear();
                    menu.querySelectorAll('input[type="checkbox"]')
                        .forEach((i) => i.checked = true);
                } else if (act === 'none') {
                    hidden = new Set(columns.map((c) => c.key));
                    menu.querySelectorAll('input[type="checkbox"]')
                        .forEach((i) => i.checked = false);
                } else if (act === 'close') {
                    menu.hidden = true;
                    return;
                }
                save();
                apply();
            });
        });
    }

    // Спостерігаємо за tbody — застосовуємо видимість після кожного перемальовування
    const tbody = table.querySelector('tbody');
    if (tbody) {
        const obs = new MutationObserver(apply);
        obs.observe(tbody, { childList: true });
    }
    apply();
}

/* Робить заголовки таблиці перетягуваними по ширині. Ширина запамʼятовується
   у localStorage під ключем storageKey. Безпечно викликати багато разів —
   ініціалізує лише один раз. */
function makeColumnsResizable(tableId, storageKey) {
    const table = document.getElementById(tableId);
    if (!table) return;
    // Набір колонок міг змінитися (вибір колонок, інша формула) — тоді ручки
    // треба перестворити, інакше таблиця лишається без них назавжди.
    const already = table.dataset.colsResizable === '1';
    // Лише ВЛАСНІ заголовки таблиці. Раніше стояло 'thead th', і селектор
    // захоплював також заголовки вкладених таблиць (розкриті партії, склад
    // рецепта) — ручки чіплялися не туди, а ширини зберігалися впереміш.
    const ths = [...table.querySelectorAll(':scope > thead > tr > th')];
    if (ths.length === 0) return;
    if (already && +table.dataset.colsN === ths.length
        && ths.every((th) => th.querySelector('.col-resizer'))) return;
    ths.forEach((th) => { const h = th.querySelector('.col-resizer'); if (h) h.remove(); });

    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(storageKey) || 'null'); }
    catch (_) { saved = null; }
    if (saved && saved.length !== ths.length) saved = null;   // структура змінилась

    // Поки таблиця прихована (згорнута панель, неактивна вкладка), offsetWidth
    // дорівнює нулю — зафіксувати такі «ширини» означало б зіпсувати таблицю.
    // Якщо збережених ширин ще немає, відкладаємо до появи на екрані.
    if (!saved && table.offsetParent === null) return;
    table.dataset.colsResizable = '1';
    table.dataset.colsN = ths.length;

    // фіксуємо поточні ширини, далі їх можна тягнути мишкою
    // Прихована колонка (вибір колонок) має offsetWidth 0 — їй даємо
    // придатну ширину за замовчуванням, щоб при поверненні вона не була
    // вузькою смужкою.
    const widths = ths.map((th, i) => {
        if (saved && saved[i] > 0) return saved[i];
        return th.offsetWidth > 0 ? Math.max(48, th.offsetWidth) : 120;
    });
    table.style.tableLayout = 'fixed';
    ths.forEach((th, i) => {
        th.style.width = widths[i] + 'px';
        // ручка-resizer позиціонується абсолютно, тож контейнер (th)
        // має бути позиційованим. Робимо це безумовно — інакше ручка
        // «приклеюється» до viewport і drag не працює.
        if (getComputedStyle(th).position === 'static') {
            th.style.position = 'relative';
        }
        const handle = document.createElement('div');
        handle.className = 'col-resizer';
        handle.addEventListener('click', (ev) => ev.stopPropagation());
        handle.addEventListener('mousedown', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const startX = ev.clientX;
            const startW = th.offsetWidth;
            document.body.style.cursor = 'col-resize';
            const onMove = (m) => {
                th.style.width = Math.max(48, startW + (m.clientX - startX)) + 'px';
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                document.body.style.cursor = '';
                // ПРИХОВАНА колонка (вибір колонок → display:none) має
                // offsetWidth 0. Раніше стояла умова «зберігати, лише якщо
                // ВСІ > 0» — тож досить було приховати одну колонку, і жодна
                // ширина на цій таблиці більше не зберігалась (у клієнта на
                // складі кормів «Назва» не трималась). Тепер для нульових
                // беремо ширину зі style, а як немає — раніше збережену.
                let prev = null;
                try { prev = JSON.parse(localStorage.getItem(storageKey) || 'null'); }
                catch (_) { prev = null; }
                if (prev && prev.length !== ths.length) prev = null;
                const w = ths.map((t, i) => {
                    if (t.offsetWidth > 0) return t.offsetWidth;
                    const st = parseFloat(t.style.width);
                    if (st > 0) return Math.round(st);
                    return (prev && prev[i] > 0) ? prev[i] : 48;
                });
                // усі нулі — таблиця цілком прихована, такий набір не пишемо
                if (w.some((x) => x > 48)) {
                    localStorage.setItem(storageKey, JSON.stringify(w));
                }
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        th.appendChild(handle);
    });
}

/* Робить ширину полів у рядку-шапці регульованою мишкою (для flex-рядків,
   де немає колонок таблиці — напр. шапка документа виробництва).
   Ширини зберігаються у localStorage під ключем storageKey.

   selector — які саме елементи всередині контейнера тягнути. */
function makeFieldsResizable(containerId, storageKey, selector) {
    const box = document.getElementById(containerId);
    if (!box) return;
    if (box.dataset.fieldsResizable === '1') return;
    const items = [...box.querySelectorAll(selector || '.doc-f')];
    if (items.length === 0) return;

    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(storageKey) || 'null'); }
    catch (_) { saved = null; }
    if (saved && saved.length !== items.length) saved = null;

    // прихований контейнер має нульові розміри — відкладаємо ініціалізацію
    if (!saved && box.offsetParent === null) return;
    box.dataset.fieldsResizable = '1';

    items.forEach((el, i) => {
        if (saved && saved[i] > 0) {
            el.style.flex = '0 0 auto';
            el.style.width = saved[i] + 'px';
        }
        if (getComputedStyle(el).position === 'static') el.style.position = 'relative';

        const handle = document.createElement('div');
        handle.className = 'col-resizer field-resizer';
        handle.addEventListener('click', (ev) => ev.stopPropagation());
        handle.addEventListener('mousedown', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const startX = ev.clientX;
            const startW = el.offsetWidth;
            document.body.style.cursor = 'col-resize';
            const onMove = (m) => {
                el.style.flex = '0 0 auto';
                el.style.width = Math.max(70, startW + (m.clientX - startX)) + 'px';
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                document.body.style.cursor = '';
                const w = items.map((t) => t.offsetWidth);
                if (w.every((x) => x > 0)) {
                    localStorage.setItem(storageKey, JSON.stringify(w));
                }
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        el.appendChild(handle);
    });
}

/* Кастомне підтвердження дії. На відміну від системного window.confirm
   не виганяє користувача з повноекранного режиму. */
function confirmAction(message, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
        const modal = document.getElementById('confirmModal');
        if (!modal) { resolve(window.confirm(message)); return; }
        const msg = document.getElementById('confirmMsg');
        const okBtn = document.getElementById('confirmOk');
        const cancelBtn = document.getElementById('confirmCancel');
        const backdrop = modal.querySelector('[data-confirm-cancel]');

        msg.textContent = message;
        okBtn.textContent = opts.ok || 'Так';
        cancelBtn.textContent = opts.cancel || 'Скасувати';
        okBtn.className = 'btn ' + (opts.okClass || 'btn-danger');
        modal.hidden = false;

        let closed = false;
        function done(result) {
            closed = true;
            modal.hidden = true;
            okBtn.onclick = null;
            cancelBtn.onclick = null;
            backdrop.onclick = null;
            document.removeEventListener('keydown', keyHandler);
            resolve(result);
        }
        function keyHandler(e) {
            if (e.key === 'Escape') done(false);
            else if (e.key === 'Enter') done(true);
        }
        okBtn.onclick = () => done(true);
        cancelBtn.onclick = () => done(false);
        backdrop.onclick = () => done(false);
        // ⚠️ СЛУХАЧА ВІШАЄМО НАСТУПНИМ КРОКОМ, а не зараз. Вікно часто
        // відкривають Enter-ом у полі, і той САМИЙ Enter ще спливає до
        // document — доданий тут слухач ловив його й відповідав «Так» сам
        // собі. Перепит про дубль у довіднику так просто не показувався:
        // запис лягав повз усі перевірки (спіймано відтворенням у браузері).
        setTimeout(() => {
            if (!closed) document.addEventListener('keydown', keyHandler);
        }, 0);
        cancelBtn.focus();
    });
}



const fmtMoney = (v) => Number(v || 0).toLocaleString('uk-UA', {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
});
/* Ціна — до 4 знаків після коми (для колонок ЦІНИ на складі) */
const fmtPrice4 = (v) => Number(v || 0).toLocaleString('uk-UA', {
    minimumFractionDigits: 2, maximumFractionDigits: 4,
});
const fmtNum = (v) => {
    const n = Number(v || 0);
    return Number.isInteger(n) ? n.toString() : n.toFixed(2);
};
const fmtDateTime = (s) => (s || '').replace('T', ' ').slice(0, 16);
const fmtDate = (s) => (s || '').slice(0, 10);

/* Дозволяє вводити дробові числа з комою АБО крапкою (для сипучих товарів —
   напр. 0,5 кг). Поле нормалізується до формату з крапкою, тож усі подальші
   обчислення й відправка на сервер працюють коректно. */
function attachDecimalInput(el) {
    if (!el) return;
    el.addEventListener('input', () => {
        let v = el.value.replace(/,/g, '.').replace(/[^0-9.]/g, '');
        const dot = v.indexOf('.');
        if (dot !== -1) {
            // лишаємо лише першу крапку
            v = v.slice(0, dot + 1) + v.slice(dot + 1).replace(/\./g, '');
        }
        if (v !== el.value) {
            el.value = v;
            // повторно повідомляємо інші обробники (розрахунки цін/сум)
            // про вже виправлене значення
            el.dispatchEvent(new Event('input', { bubbles: true }));
        }
    });
}

// Авто-підключення до всіх полів з inputmode="decimal" на будь-якій сторінці
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('input[inputmode="decimal"]').forEach(attachDecimalInput);
});

/* ===== Розумний пошук товарів (спільний для приходу й продажу) ===== */

let productsIndex = [];   // повний каталог для пошуку

async function loadProductsIndex() {
    const r = await apiGet('/api/products');
    if (r.ok) productsIndex = r.items || [];
}

function searchProducts(query) {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    const scored = [];
    for (const p of productsIndex) {
        const name = (p.name || '').toLowerCase();
        const barcode = (p.barcode || '').toLowerCase();
        const supplier = (p.supplier || '').toLowerCase();
        const code = (p.code || '').toLowerCase();
        let score = -1;
        if (barcode.startsWith(q)) score = 0;         // штрихкод з початку
        else if (code && code.startsWith(q)) score = 0; // код товару з початку
        else if (name.startsWith(q)) score = 1;       // назва з початку
        else if (barcode.includes(q)) score = 2;      // штрихкод містить
        else if (code && code.includes(q)) score = 2; // код товару містить
        else if (name.includes(q)) score = 3;         // назва містить
        else if (supplier.includes(q)) score = 4;     // збіг по постачальнику
        if (score >= 0) scored.push({ p, score });
    }
    scored.sort((a, b) =>
        a.score - b.score || a.p.name.localeCompare(b.p.name, 'uk'));
    return scored.slice(0, 8).map((s) => s.p);
}

/* Доступний залишок для показу в пошуку/прев'ю: складський мінус те, що вже
   додано в активний список (видача/списання). Сторінка може задати
   window.stockReserved(product) → скільки цього товару вже в кошику. */
function availStock(p) {
    const reserved = (typeof window.stockReserved === 'function')
        ? (window.stockReserved(p) || 0) : 0;
    return (p.total_qty || 0) - reserved;
}

function highlightMatch(text, query) {
    const q = query.trim();
    if (!q) return escapeHtml(text);
    const idx = text.toLowerCase().indexOf(q.toLowerCase());
    if (idx < 0) return escapeHtml(text);
    return escapeHtml(text.slice(0, idx)) +
        '<mark>' + escapeHtml(text.slice(idx, idx + q.length)) + '</mark>' +
        escapeHtml(text.slice(idx + q.length));
}

/**
 * Універсальна фабрика автокомпліту. Прив'язує до поля input випадаючий
 * список dropdown зі збігами з каталогу. onPick(product) викликається при
 * виборі варіанта (кліком або Enter).
 */
function createAutocomplete(input, dropdown, onPick, opts) {
    opts = opts || {};
    let matches = [];
    let activeIndex = -1;

    function hide() { dropdown.hidden = true; activeIndex = -1; }

    // Увесь склад (за назвою) — для показу списку одразу на кліку в поле.
    function allProducts() {
        return (productsIndex || []).slice()
            .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'uk'))
            .slice(0, 200);
    }

    function render(query) {
        matches = (query && query.trim().length >= 2)
            ? searchProducts(query) : allProducts();
        activeIndex = -1;
        if (matches.length === 0) {
            dropdown.innerHTML =
                '<div class="autocomplete-empty">Нічого не знайдено.</div>';
        } else {
            dropdown.innerHTML = matches.map((p, i) => {
                const av = availStock(p);
                const low = av <= (p.min_stock || 0);
                return `
                    <div class="autocomplete-item" data-index="${i}">
                        <div>
                            <div class="ac-name">${highlightMatch(p.name, query)}</div>
                            <div class="ac-meta">${escapeHtml(p.barcode)}${p.supplier ? ' · ' + escapeHtml(p.supplier) : ''}</div>
                        </div>
                        <div class="ac-stock ${low ? 'low' : ''}">
                            ${fmtNum(av)}
                            <small>${escapeHtml(p.unit || 'залишок')}</small>
                        </div>
                    </div>
                `;
            }).join('');
        }
        dropdown.hidden = false;
    }

    function setActive() {
        dropdown.querySelectorAll('.autocomplete-item').forEach((el, i) => {
            el.classList.toggle('is-active', i === activeIndex);
            if (i === activeIndex) el.scrollIntoView({ block: 'nearest' });
        });
    }

    function pick(p) { hide(); onPick(p); }

    input.addEventListener('input', () => {
        const q = input.value;
        if (q.trim().length < 2) {
            if (opts.showAllOnFocus) render('');   // показати весь склад
            else hide();
            return;
        }
        render(q);
    });

    // Клік/фокус у порожньому полі — одразу показати весь склад.
    if (opts.showAllOnFocus) {
        input.addEventListener('focus', () => {
            if (input.value.trim().length < 2) render('');
        });
    }

    input.addEventListener('keydown', (e) => {
        if (dropdown.hidden) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            activeIndex = Math.min(activeIndex + 1, matches.length - 1);
            setActive();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            activeIndex = Math.max(activeIndex - 1, 0);
            setActive();
        } else if (e.key === 'Enter') {
            // Enter спрацьовує лише якщо варіант підсвічено стрілками.
            if (activeIndex >= 0 && matches[activeIndex]) {
                e.preventDefault();
                e.stopImmediatePropagation();
                pick(matches[activeIndex]);
            }
        } else if (e.key === 'Escape') {
            hide();
        }
    });

    // Вибір на mousedown + preventDefault — щоб поле не втрачало фокус.
    dropdown.addEventListener('mousedown', (e) => {
        e.preventDefault();
        const item = e.target.closest('.autocomplete-item');
        if (!item) return;
        const idx = parseInt(item.dataset.index, 10);
        if (matches[idx]) pick(matches[idx]);
    });

    document.addEventListener('click', (e) => {
        if (e.target !== input && !dropdown.contains(e.target)) hide();
    });

    return { hide };
}

const moveTypeLabel = {
    IN: { text: 'Прихід', cls: 'in' },
    OUT: { text: 'Видача', cls: 'out' },
    WRITE_OFF: { text: 'Списання', cls: 'wo' },
    RETURN: { text: 'Повернення', cls: 'ret' },
};

/* Форматує внутрішній sale_no для показу. Префікс залежить від типу операції:
   - ВВ-N   — внутрішня видача
   - ВС-N   — списання
   - ПВ-N   — повернення
   Тип передаємо другим аргументом; якщо не вказано — лишаємо «ВВ-».
   Якщо рядок уже з префіксом — не дублюємо. */
function formatSaleNo(raw, moveType) {
    const s = String(raw == null ? '' : raw);
    if (!s) return '';
    const pre = s.slice(0, 3);
    if (pre === 'ВВ-' || pre === 'ВП-' || pre === 'ПВ-' || pre === 'ВС-') return s;
    let prefix = 'ВВ-';
    if (moveType === 'RETURN') prefix = 'ПВ-';
    else if (moveType === 'WRITE_OFF') prefix = 'ВС-';
    return prefix + s;
}

/* Префікс гілки (для «Матеріалів» — '/m'). Додається до /api/... запитів,
   щоб ті самі сторінки працювали в обох гілках з різними даними. */
function apiUrl(url) {
    const base = window.API_BASE || '';
    return (base && typeof url === 'string' && url.startsWith('/api/')) ? base + url : url;
}

async function apiGet(url) {
    const r = await fetch(apiUrl(url), { headers: { Accept: 'application/json' } });
    return r.json();
}

async function apiSend(url, method, body) {
    const r = await fetch(apiUrl(url), {
        method,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: body ? JSON.stringify(body) : undefined,
    });
    return r.json();
}

/* ===== Toast notifications ===== */
function toast(message, type = '') {
    const root = document.getElementById('toast-root');
    if (!root) return;
    const el = document.createElement('div');
    el.className = 'toast ' + type;
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => {
        el.style.opacity = '0';
        el.style.transition = 'opacity .25s';
        setTimeout(() => el.remove(), 250);
    }, 3500);
}

/* ===== Modal helpers ===== */
function openModal(id) {
    const m = document.getElementById(id);
    if (!m) return;
    m.hidden = false;
    const firstInput = m.querySelector('input, select, textarea');
    if (firstInput) setTimeout(() => firstInput.focus(), 60);
}
function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.hidden = true;
}
document.addEventListener('click', (e) => {
    if (e.target.matches('[data-close]')) {
        const modal = e.target.closest('.modal');
        if (modal) modal.hidden = true;
    }
});
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal:not([hidden])').forEach((m) => (m.hidden = true));
    }
});

/* ===== Зміна власного пароля з топбара ===== */
(function initChangePassword() {
    const btn = document.getElementById('changePasswordBtn');
    const modal = document.getElementById('changePasswordModal');
    const form = document.getElementById('changePasswordForm');
    if (!btn || !modal || !form) return;

    btn.addEventListener('click', () => {
        form.reset();
        openModal('changePasswordModal');
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(form).entries());
        if (data.new !== data.repeat) {
            toast('Новий пароль і повтор не співпадають', 'warn');
            return;
        }
        const r = await apiSend('/api/account/password', 'POST', {
            current: data.current, new: data.new,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Пароль змінено. Залогіньтеся повторно при потребі.', 'success');
        closeModal('changePasswordModal');
    });
})();

/* ===== Бейдж кількості «терміновок» біля пункту меню =====
   Опитує /api/expiring/count і показує цифру біля «Терміни придатності».
   Поріг — 30 днів. Оновлюється раз на хвилину. */
async function refreshExpiringBadge() {
    const badge = document.getElementById('expiringBadge');
    if (!badge) return;
    try {
        const r = await apiGet('/api/expiring/count?days=30');
        if (!r.ok) return;
        const n = r.count || 0;
        if (n > 0) {
            badge.textContent = n > 99 ? '99+' : String(n);
            badge.hidden = false;
        } else {
            badge.hidden = true;
        }
    } catch (_) { /* мережа впала — не блимаємо */ }
}
document.addEventListener('DOMContentLoaded', () => {
    refreshExpiringBadge();
    setInterval(refreshExpiringBadge, 60 * 1000);
});

/* ===== Авто-перевірка оновлень =====
   Показчик у меню — лише в адміна (веде на «База даних»), а ПИТАННЯ про
   оновлення бачить БУДЬ-ЯКИЙ користувач: оновлення свого компʼютера — не
   робота з даними ферми, і в працівника може не бути адміністратора поруч
   (Роман 2026-09-09: «кожен працює окремо»). */
async function refreshUpdateBadge() {
    const badge = document.getElementById('updateBadge');
    const isAdmin = (document.querySelector('meta[name="current-user-role"]') || {}).content === 'admin';
    try {
        const r = await apiGet('/api/update/available');
        if (!r.ok) return;
        if (r.available && !r.staged && window.farmUpdateAsk) {
            window.farmUpdateAsk(r.latest, r.notes || '');
        }
        if (!badge || !isAdmin) return;          // показчик у меню — лише адмін
        // Показуємо лише якщо є новіша версія І вона ще не підготовлена до
        // встановлення (інакше показчик одразу зникає після «Оновити»).
        const link = document.getElementById('databaseLink');
        if (r.available && !r.staged) {
            badge.textContent = 'v' + r.latest;
            badge.hidden = false;
            if (link) {
                link.title = 'Доступне оновлення v' + r.latest + ' — відкрити «База даних»';
                link.classList.add('has-update');
            }
        } else {
            badge.hidden = true;
            if (link) link.classList.remove('has-update');
        }
    } catch (_) { /* тихо */ }
}
window.refreshUpdateBadge = refreshUpdateBadge;   // щоб викликати з database.js

/* ===== Синхронізація з фермою (супутник) — показчик і кнопка «зараз» =====
   Живе в бічному меню, доступна КОЖНОМУ користувачу: панель «Bovio-сервер» у
   Налаштуваннях відкрита лише адміністратору, тож працівник не бачив ні стану
   обміну, ні способу поквапити його (Роман 2026-09-09). */
(function () {
    const box = document.getElementById('satSync');
    if (!box) return;
    const dot = document.getElementById('satDot');
    const info = document.getElementById('satInfo2');
    const btn = document.getElementById('satSyncBtn');
    const hm = (v) => (v ? String(v).slice(11, 16) : '');
    async function load() {
        let r;
        try { r = await (await fetch('/api/satellite/state')).json(); }
        catch (e) { return; }
        if (!r || !r.ok || !r.on) { box.hidden = true; return; }
        box.hidden = false;
        const parts = [];
        if (r.pending) parts.push('чекає надсилання: ' + r.pending);
        if (r.sent) parts.push('віддано ' + hm(r.sent));
        if (r.got) parts.push('отримано ' + hm(r.got));
        info.textContent = r.error ? ('⚠ ' + r.error) : (parts.join(' · ') || 'ще не було');
        dot.className = 'sat-dot' + (r.error ? ' bad' : (r.pending ? ' wait' : ''));
        dot.title = r.error ? r.error
            : (r.pending ? 'Є зміни, які ще не поїхали на ферму' : 'Усе синхронізовано');
    }
    if (btn) btn.addEventListener('click', async () => {
        btn.disabled = true;
        info.textContent = 'Синхронізую…';
        let r;
        try { r = await apiSend('/api/satellite/sync', 'POST', {}); }
        catch (e) { r = { ok: false, error: 'немає звʼязку' }; }
        btn.disabled = false;
        if (r && r.ok) {
            toast(r.sent ? ('Надіслано операцій: ' + r.sent + ', дані оновлено')
                         : 'Дані оновлено', 'success');
            await load();
            setTimeout(() => location.reload(), 700);
        } else {
            toast((r && r.error) || 'Не вдалося', 'error');
            await load();
        }
    });
    load();
    setInterval(load, 60 * 1000);
})();

/* ===== ОНОВЛЕННЯ: СПОВІЩЕННЯ, А ЧЕРЕЗ 3 ХВИЛИНИ — САМЕ ОНОВЛЕННЯ =====
   Роман 2026-09-25: «щоб програма сама через 3 хвилини після того, як помітила
   оновлення, оновлювалась; сповіщення все одно приходить про нову версію».
   Доти оновлення ЧЕКАЛО кліку: хто його не помітив, місяцями працював на
   старому коді, а після кожної викладки на ферму доводилось тиснути Ctrl+F5.

   Дві різні речі, обидві за одним правилом:
   (1) СТОРІНКА — ферму в хмарі вже оновили, а у вкладці лишився старий код:
       вкладка перезавантажується сама (`/api/version/live`);
   (2) ЗАСТОСУНОК НА ПК — вийшов новий пакет: ставиться й перезапускається сам.

   ⚠️ НІКОЛИ посеред роботи: якщо людина в полі або відкрите вікно — відлік
   дочекається, поки звільниться, і аж тоді оновить. Інакше автооновлення
   стерло б недописану форму, і це було б гірше за старий код. */
const UPD_DELAY_MS = 3 * 60 * 1000;          // скільки чекати після сповіщення
const UPD_SNOOZE_MS = 30 * 60 * 1000;        // «Відкласти»
let UPD_SNOOZE_UNTIL = 0;

/* Чому зараз не можна оновлювати (порожньо — можна). */
function updBusyWhy() {
    // ⚠️ звіряємо не лише атрибут, а й ВИДИМІСТЬ: сторінка, де модалку ховає
    // сам CSS, інакше назавжди вважалась би зайнятою й не оновлювалась би
    const m = Array.prototype.some.call(document.querySelectorAll('.modal'),
        (x) => !x.hidden && x.offsetParent !== null);
    if (m) return 'відкрите вікно';
    const a = document.activeElement;
    if (a && ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(a.tagName) >= 0
        && !a.disabled && !a.readOnly) return 'ви заповнюєте поле';
    return '';
}

/* Коробка сповіщення зі зворотним відліком. `action` виконується, коли відлік
   вийшов і робота не перерветься; до того його можна запустити кнопкою. */
function updNotice(o) {
    if (document.getElementById('updAskBox')) return;     // вже показано
    const box = document.createElement('div');
    box.id = 'updAskBox';
    box.className = 'upd-ask';
    box.innerHTML = '<div class="upd-ask-card">'
        + '<div class="upd-ask-h"></div>'
        + '<div class="upd-ask-n"></div>'
        + '<div class="upd-ask-s" id="updAskStatus"></div>'
        + '<div class="upd-ask-b">'
        + '<button type="button" class="btn btn-ghost" id="updAskLater">Відкласти на 30 хв</button>'
        + '<button type="button" class="btn btn-primary" id="updAskGo"></button>'
        + '</div></div>';
    document.body.appendChild(box);
    box.querySelector('.upd-ask-h').textContent = o.title;
    box.querySelector('.upd-ask-n').textContent = o.note || '';
    const st = box.querySelector('#updAskStatus');
    const go = box.querySelector('#updAskGo');
    const later = box.querySelector('#updAskLater');
    go.textContent = o.actionLabel || 'Оновити зараз';

    let left = Math.round(UPD_DELAY_MS / 1000), fired = false, t = null;
    const stop = () => { if (t) { clearInterval(t); t = null; } };
    const fire = async () => {
        if (fired) return;
        const why = updBusyWhy();
        if (why) {
            st.textContent = 'Чекаю: ' + why + '. Оновлю, щойно звільниться.';
            return;
        }
        fired = true;
        stop();
        go.disabled = true;
        later.disabled = true;
        try { await o.action(st); } catch (e) { st.textContent = '⚠ не вдалося оновити'; }
    };
    t = setInterval(() => {
        if (fired) return;
        left -= 1;
        if (left > 0) {
            const mm = Math.floor(left / 60), ss = left % 60;
            st.textContent = 'Оновлю через ' + mm + ':' + String(ss).padStart(2, '0');
        } else fire();
    }, 1000);
    st.textContent = 'Оновлю через ' + Math.floor(left / 60) + ':'
        + String(left % 60).padStart(2, '0');
    later.addEventListener('click', () => {
        stop();
        UPD_SNOOZE_UNTIL = Date.now() + UPD_SNOOZE_MS;
        box.remove();
    });
    go.addEventListener('click', () => { left = 0; fire(); });
}

/* (1) Сторінка відстала від ферми — перезавантажуємо вкладку. */
const UPD_PAGE_VER = (document.querySelector('meta[name="app-version"]') || {}).content || '';
async function updCheckPage() {
    if (!UPD_PAGE_VER || Date.now() < UPD_SNOOZE_UNTIL) return;
    if (document.getElementById('updAskBox')) return;
    let v;
    try { v = await (await fetch('/api/version/live', { cache: 'no-store' })).json(); }
    catch (_) { return; }                                  // немає звʼязку — мовчимо
    if (!v || !v.ok || !v.app_version || v.app_version === UPD_PAGE_VER) return;
    updNotice({
        title: 'Ферма оновилась до ' + String(v.app_version).replace(/[<>&]/g, ''),
        note: 'У цій вкладці ще стара версія (' + UPD_PAGE_VER + '). '
            + 'Сторінка перезавантажиться сама — натискати нічого не треба.',
        actionLabel: 'Оновити зараз',
        action: async (st) => {
            st.textContent = 'Оновлюю сторінку…';
            if (window.farmAllowUnload) window.farmAllowUnload();
            setTimeout(() => location.reload(), 300);
        },
    });
}

/* (2) Вийшов новий пакет — ставимо його на цьому компʼютері. */
window.farmUpdateAsk = function (latest, notes) {
    if (!latest || Date.now() < UPD_SNOOZE_UNTIL) return;
    updNotice({
        title: 'Доступне оновлення ' + String(latest).replace(/[<>&]/g, ''),
        note: notes || 'Застосунок оновиться й перезапуститься сам.',
        actionLabel: 'Оновити зараз',
        action: async (st) => {
            st.textContent = 'Готую оновлення…';
            let r = await apiSend('/api/update/apply', 'POST', {});
            if (!r.ok) { st.textContent = '⚠ ' + (r.error || 'Помилка'); return; }
            st.textContent = 'Перезапускаю застосунок…';
            r = await apiSend('/api/update/restart', 'POST', {});
            if (!r.ok) {
                st.textContent = 'Оновлення готове. Перезапустіть застосунок вручну.';
                return;
            }
            // чекаємо, поки сервер підніметься з новою версією
            let tries = 0;
            const wait = setInterval(async () => {
                tries += 1;
                try {
                    const v = await (await fetch('/api/version', { cache: 'no-store' })).json();
                    if (v && v.ok && v.app_version && v.app_version !== UPD_PAGE_VER) {
                        clearInterval(wait);
                        st.textContent = 'Готово — версія ' + v.app_version;
                        if (window.farmAllowUnload) window.farmAllowUnload();
                        setTimeout(() => location.reload(), 900);
                    }
                } catch (_) { /* сервер ще піднімається */ }
                if (tries > 90) {
                    clearInterval(wait);
                    st.textContent = 'Перезапуск триває довше звичайного — оновіть сторінку.';
                }
            }, 2000);
        },
    });
};
document.addEventListener('DOMContentLoaded', () => {
    refreshUpdateBadge();
    setInterval(refreshUpdateBadge, 30 * 1000);   // новий ПАКЕТ — кожні 30 секунд
    updCheckPage();
    setInterval(updCheckPage, 60 * 1000);         // версія ФЕРМИ — раз на хвилину
});

/* ===== ХРЕСТИК У ВІКНІ-ЗАСТОСУНКУ: ПОПЕРЕДЖЕННЯ =====
   Роман 2026-09-25: «я просив, щоб при натисканні на хрестик було
   попередження — зараз вікно просто закривається». Ідеться про застосунок,
   ВСТАНОВЛЕНИЙ із браузера (окреме вікно без адресного рядка): там хрестик
   закриває саме те вікно, у якому працюють.

   ⚠️ Свій текст у це вікно покласти НЕ МОЖНА — браузер показує лише власний
   напис («Залишити сторінку?»). Усе, що ми вирішуємо, — чи питати взагалі.

   📌 ПИТАЄМО ЛИШЕ У ВСТАНОВЛЕНОМУ ЗАСТОСУНКУ: у звичайній вкладці закрити її —
   звична дешева дія, і перепит там лише заважав би.
   📌 ЯК ВІДРІЗНЯЄМО ХРЕСТИК ВІД ПЕРЕХОДУ ВСЕРЕДИНІ: хрестик — це клік ПОЗА
   сторінкою, тож перед ним у ній нічого не відбувається. А будь-який перехід,
   збереження чи оновлення сторінки йде одразу за дією людини В сторінці. Тому
   не питаємо, якщо останні 2,5 с у сторінці щось натискали. Наші власні
   перезавантаження (автооновлення) кажуть про себе самі — `farmAllowUnload`. */
(function () {
    const appWindow = () => {
        try {
            return window.matchMedia('(display-mode: standalone)').matches
                || window.navigator.standalone === true;
        } catch (e) { return false; }
    };
    let lastAct = 0;
    const act = () => { lastAct = Date.now(); };
    ['click', 'keydown', 'submit'].forEach((t) =>
        document.addEventListener(t, act, true));
    window.farmAllowUnload = act;          // «це ми самі, не питай»
    window.addEventListener('beforeunload', (e) => {
        if (!appWindow()) return;                       // звичайна вкладка
        if (Date.now() - lastAct < 2500) return;        // перехід усередині
        e.preventDefault();
        e.returnValue = '';                             // текст задає браузер
    });
})();


/* ===== PWA: service worker + кнопка встановлення ===== */
(function () {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => { /* ignore */ });
        });
    }
    let deferredPrompt = null;
    const btn = document.getElementById('pwaInstallBtn');
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        if (btn) btn.style.display = '';
    });
    if (btn) {
        btn.addEventListener('click', async () => {
            if (!deferredPrompt) return;
            deferredPrompt.prompt();
            await deferredPrompt.userChoice;
            deferredPrompt = null;
            btn.style.display = 'none';
        });
    }
    window.addEventListener('appinstalled', () => {
        if (btn) btn.style.display = 'none';
    });
})();

/* ===== Перемикач теми (світла/темна) ===== */
(function () {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    const apply = (t) => {
        document.documentElement.setAttribute('data-theme', t);
        // значок живе у власному span, коли кнопка має ще й напис («☾ Тема»),
        // інакше — сам текст кнопки (як було)
        const ico = btn.querySelector('.tt-ico');
        const ch = (t === 'dark') ? '☀' : '☾';
        if (ico) ico.textContent = ch; else btn.textContent = ch;
        btn.title = (t === 'dark') ? 'Перемкнути на світлу тему'
                                   : 'Перемкнути на темну тему';
    };
    apply(document.documentElement.getAttribute('data-theme') || 'light');
    btn.addEventListener('click', () => {
        const cur = document.documentElement.getAttribute('data-theme') === 'dark'
            ? 'dark' : 'light';
        const next = (cur === 'dark') ? 'light' : 'dark';
        try { localStorage.setItem('farm-theme', next); } catch (e) { /* ignore */ }
        apply(next);
    });
})();

/* ===== Clock in topbar ===== */
function updateClock() {
    const el = document.getElementById('nowClock');
    if (!el) return;
    const d = new Date();
    const pad = (n) => n.toString().padStart(2, '0');
    el.textContent = `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
updateClock();
setInterval(updateClock, 30 * 1000);

/* ===== Присутність: хто зараз онлайн ===== */
function _initials(name) {
    const parts = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return '?';
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
}
function _avatarColor(name) {
    let h = 0;
    const s = String(name || '');
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
    return `hsl(${h}, 55%, 45%)`;
}
/* Скільки кружків присутності влазить у верхню смужку. Шість штук — це
   ~240px, і на ноутбуці вони з'їдали назву сторінки (Роман 2026-09-22:
   смужка розпирала вікно). Тому на вужчому вікні показуємо менше, а «+N»
   ПЕРЕРАХОВУЄТЬСЯ — число завжди чесне, скільки людей не видно. */
function _presenceCap() {
    // у віконці під кружком місця досить — обмеження було про ШИРИНУ смужки
    const el = document.getElementById('presence');
    if (el && el.closest('.ubox-pop')) return 8;
    const w = window.innerWidth;
    if (w >= 1560) return 6;
    if (w >= 1300) return 4;
    if (w > 1120) return 2;        // 1120 і вужче блок ховає app.css — межі збігаються
    return 0;                      // місця немає — блок не показуємо
}
let _presenceItems = [];
async function loadPresence() {
    const el = document.getElementById('presence');
    if (!el) return;
    let r;
    try { r = await apiGet('/api/online-users'); } catch (e) { return; }
    if (!r || !r.ok) return;
    _presenceItems = r.items || [];
    drawPresence();
}
function drawPresence() {
    const el = document.getElementById('presence');
    if (!el) return;
    const items = _presenceItems;
    const cap = _presenceCap();
    if (!cap) { el.innerHTML = ''; return; }
    const shown = items.slice(0, cap);
    const extra = items.length - shown.length;
    let html = shown.map((u) => {
        const nm = u.name + (u.is_me ? ' (ви)' : '');
        return `<span class="presence-dot${u.is_me ? ' is-me' : ''}" `
            + `style="background:${_avatarColor(u.name)}" title="${escapeHtml(nm)}">`
            + escapeHtml(_initials(u.name)) + '</span>';
    }).join('');
    if (extra > 0) html += `<span class="presence-more" title="ще ${extra}">+${extra}</span>`;
    if (items.length) html = '<span class="presence-label">Онлайн</span>' + html;
    el.innerHTML = html;
    // скільки ЩЕ людей на фермі — видно на самій кнопці, не відкриваючи вікна
    const n = document.getElementById('uboxN');
    if (n) {
        const others = items.filter((u) => !u.is_me).length;
        n.textContent = others ? String(others) : '';
        n.hidden = !others;
        n.title = others ? `Зараз на фермі ще ${others}` : '';
    }
}

/* Кружки з ініціалами — того самого кольору, що й у переліку присутніх. */
(function () {
    ['uboxAv', 'uboxAvLg'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.style.background = _avatarColor(el.dataset.name || '');
    });
})();
loadPresence();
setInterval(loadPresence, 12 * 1000);
/* вікно змінили — перемальовуємо з новою кількістю кружків */
(function () {
    let t = null;
    window.addEventListener('resize', () => {
        clearTimeout(t); t = setTimeout(drawPresence, 120);
    });
})();

/* ===== Scanner support =====
   USB / Bluetooth scanners act as keyboards: they emit characters very fast,
   then send Enter. We watch any field marked with [data-scan-field]. F2 focuses
   the first scan field on the page from anywhere.
*/
document.addEventListener('keydown', (e) => {
    if (e.key === 'F2') {
        const target = document.querySelector('[data-scan-field]');
        if (target) {
            e.preventDefault();
            target.focus();
            target.select();
        }
    }
});

/* Helper that other pages can call to detect "scanner finished typing" */
function attachScannerHandler(input, onScan) {
    if (!input) return;
    let buffer = '';
    let lastTime = 0;
    let timer = null;

    // Most scanners append Enter — easiest path
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const value = input.value.trim();
            if (value) onScan(value);
        }
    });

    // Also support fast typing without Enter (rare)
    input.addEventListener('input', () => {
        const now = Date.now();
        if (now - lastTime < 40) {
            // looks like scanner burst
            clearTimeout(timer);
            timer = setTimeout(() => {
                const v = input.value.trim();
                if (v && v.length >= 6) onScan(v);
            }, 120);
        }
        lastTime = now;
    });
}

/* Render product preview block (used by receive & sale pages) */
function renderProductPreview(container, product) {
    if (!product) {
        container.innerHTML = '<div class="preview-empty">Товар не знайдено</div>';
        return;
    }
    const low = (product.total_qty || 0) <= (product.min_stock || 0);
    container.innerHTML = `
        <div>
            <div class="preview-name">${escapeHtml(product.name)}</div>
            <div class="preview-meta">
                ${escapeHtml(product.barcode)} · ${escapeHtml(product.unit || 'шт')}
                ${product.supplier ? ' · ' + escapeHtml(product.supplier) : ''}
            </div>
        </div>
        <div class="preview-stock ${low ? 'low' : ''}">
            <div class="preview-stock-value">${fmtNum(product.total_qty)}</div>
            <div class="preview-stock-label">Залишок ${product.unit || ''}</div>
        </div>
    `;
}

function escapeHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ===== Бічна панель: на ПК — згортання, на телефоні — висувна шторка ===== */
/* Стрілки шапки: назад / вперед по сторінках і оновлення (Роман 2026-09-18).
   Назад повертає на попередню сторінку й ПЕРЕЧИТУЄ її — інакше браузер
   показав би знімок із памʼяті зі старими числами. */
(function initTopNav() {
    const KEY = 'farm:nav_depth';
    document.addEventListener('DOMContentLoaded', () => {
        const box = document.getElementById('topNav');
        if (!box) return;
        const back = box.querySelector('[data-go="back"]');
        // перший крок у вкладці — повертатись нікуди
        let depth = 0;
        try { depth = +(sessionStorage.getItem(KEY) || 0); } catch (e) { depth = 0; }
        if (back) back.disabled = depth < 1;
        try { sessionStorage.setItem(KEY, String(depth + 1)); } catch (e) { /* ignore */ }
        box.addEventListener('click', (e) => {
            const b = e.target.closest('[data-go]');
            if (!b) return;
            if (b.dataset.go === 'reload') { location.reload(); return; }
            try { sessionStorage.setItem('farm:nav_reload', '1'); } catch (er) { /* ignore */ }
            if (b.dataset.go === 'back') history.back(); else history.forward();
        });
    });
    // повернулись «назад» — показуємо свіжі дані, а не знімок сторінки
    window.addEventListener('pageshow', (e) => {
        let want = false;
        try {
            want = sessionStorage.getItem('farm:nav_reload') === '1';
            sessionStorage.removeItem('farm:nav_reload');
        } catch (er) { want = false; }
        if (want || e.persisted) location.reload();
    });
}());

(function initSidebarCollapse() {
    const KEY = 'vetpharm:sidebar_collapsed';
    const isMobile = () => window.matchMedia('(max-width: 720px)').matches;
    function applyCollapse(shell, collapsed) {
        shell.classList.toggle('is-collapsed', collapsed);
    }
    document.addEventListener('DOMContentLoaded', () => {
        const shell = document.querySelector('.app-shell');
        const btn = document.getElementById('sidebarToggle');
        if (!shell || !btn) return;

        // підложка для мобільної шторки
        let backdrop = document.querySelector('.nav-backdrop');
        if (!backdrop) {
            backdrop = document.createElement('div');
            backdrop.className = 'nav-backdrop';
            document.body.appendChild(backdrop);
        }
        const closeDrawer = () => document.body.classList.remove('nav-open');
        backdrop.addEventListener('click', closeDrawer);
        // клік по пункту меню на телефоні — закрити шторку
        document.querySelectorAll('.sidebar a').forEach((a) =>
            a.addEventListener('click', () => { if (isMobile()) closeDrawer(); }));

        if (!isMobile()) applyCollapse(shell, localStorage.getItem(KEY) === '1');

        btn.addEventListener('click', () => {
            if (isMobile()) {
                document.body.classList.toggle('nav-open');
            } else {
                const collapsed = !shell.classList.contains('is-collapsed');
                applyCollapse(shell, collapsed);
                localStorage.setItem(KEY, collapsed ? '1' : '0');
            }
        });

        // на телефоні шторка завжди повна (без режиму «лише іконки»)
        window.addEventListener('resize', () => {
            if (isMobile()) {
                shell.classList.remove('is-collapsed');
            } else {
                closeDrawer();
                applyCollapse(shell, localStorage.getItem(KEY) === '1');
            }
        });
        if (isMobile()) shell.classList.remove('is-collapsed');
    });
})();

/* ===== Згортання вибору гілок (по вертикалі) ===== */
(function initBranchSwitcherCollapse() {
    const KEY = 'vetpharm:branch_switcher_collapsed';
    document.addEventListener('DOMContentLoaded', () => {
        const sw = document.getElementById('branchSwitcher');
        const btn = document.getElementById('branchToggle');
        if (!sw || !btn) return;
        if (localStorage.getItem(KEY) === '1') sw.classList.add('collapsed');
        btn.addEventListener('click', () => {
            sw.classList.toggle('collapsed');
            localStorage.setItem(KEY, sw.classList.contains('collapsed') ? '1' : '0');
        });
    });
})();

/* ===== Горизонтальна прокрутка широких таблиць ===== */
/* 1) смужка прокрутки ЗВЕРХУ таблиці (синхронна з нижньою) — щоб зсувати
   вправо, не спускаючись донизу; 2) Shift+колесо = горизонтально.
   Працює для контейнерів .table-scroll і .prod-tblwrap; показується лише
   коли таблиця ширша за екран. */
(function initWideTableScroll() {
    function attachTop(scrollEl) {
        if (scrollEl.dataset.topbar === '1') return;
        const table = scrollEl.querySelector('table');
        if (!table) return;
        scrollEl.dataset.topbar = '1';
        const bar = document.createElement('div');
        bar.className = 'top-scrollbar';
        const inner = document.createElement('div');
        inner.className = 'top-scrollbar-inner';
        bar.appendChild(inner);
        scrollEl.parentNode.insertBefore(bar, scrollEl);
        const sync = () => {
            inner.style.width = table.scrollWidth + 'px';
            const wide = table.scrollWidth > scrollEl.clientWidth + 2;
            bar.style.display = wide ? 'block' : 'none';
            scrollEl.classList.toggle('can-pan', wide);   // курсор «рука», коли є що зсувати
        };
        let lock = false;
        bar.addEventListener('scroll', () => {
            if (lock) return; lock = true; scrollEl.scrollLeft = bar.scrollLeft; lock = false;
        });
        scrollEl.addEventListener('scroll', () => {
            if (lock) return; lock = true; bar.scrollLeft = scrollEl.scrollLeft; lock = false;
        });
        // Shift+колесо → горизонтально
        scrollEl.addEventListener('wheel', (e) => {
            if (e.shiftKey && e.deltaY) {
                scrollEl.scrollLeft += e.deltaY;
                e.preventDefault();
            }
        }, { passive: false });
        // Перетягування мишкою («рука»): затиснув і тягнеш — таблиця їде.
        // Не заважає кнопкам/полям/сортуванню — на них drag не стартує.
        let down = false, startX = 0, startLeft = 0, moved = false;
        const NOPAN = 'button, a, input, select, textarea, [contenteditable], .col-resizer, .batch-toggle';
        scrollEl.addEventListener('mousedown', (e) => {
            if (e.button !== 0 || e.target.closest(NOPAN)) return;
            down = true; moved = false; startX = e.pageX; startLeft = scrollEl.scrollLeft;
            scrollEl.classList.add('is-grabbing');
        });
        window.addEventListener('mousemove', (e) => {
            if (!down) return;
            const dx = e.pageX - startX;
            if (Math.abs(dx) > 3) moved = true;
            scrollEl.scrollLeft = startLeft - dx;
        });
        window.addEventListener('mouseup', () => {
            if (!down) return; down = false; scrollEl.classList.remove('is-grabbing');
        });
        // якщо це було перетягування — не давати кліку спрацювати (не розкривати рядок)
        scrollEl.addEventListener('click', (e) => {
            if (moved) { e.stopPropagation(); e.preventDefault(); moved = false; }
        }, true);
        try { new ResizeObserver(sync).observe(table); } catch (_) { /**/ }
        window.addEventListener('resize', sync);
        sync();
    }
    function init() {
        document.querySelectorAll('.table-scroll, .prod-tblwrap').forEach(attachTop);
    }
    document.addEventListener('DOMContentLoaded', () => { init(); setTimeout(init, 800); });
})();


/* «Кілька чисел» (долі вимені, кінцівки 1–4) — Роман 2026-09-19: запис
   складається ПІД ЧАС набору, а не виправляється потім. Для меж до 9 кожна
   цифра — окреме число: набрали «4», потім «1» — у полі одразу «1, 4»; цифра
   поза межами (5) чи повтор (друга «1») просто не зʼявляється, поле блимає.
   Коми ставити не треба. Для більших меж числа розділяють пробілом чи комою. */
window.multiNorm = function (v, min, max) {
    const lo = min === '' || min == null ? null : Number(min);
    const hi = max === '' || max == null ? null : Number(max);
    const ok = (n) => (lo === null || n >= lo) && (hi === null || n <= hi);
    const single = hi !== null && hi <= 9 && (lo === null || lo >= 0);
    const raw = String(v || '');
    const toks = single ? (raw.match(/\d/g) || []) : (raw.match(/\d+/g) || []);
    const seen = new Set();
    let bad = false;
    toks.map(Number).forEach((n) => {
        if (!ok(n) || seen.has(n)) { bad = true; return; }
        seen.add(n);
    });
    return { value: [...seen].sort((a, b) => a - b).join(', '), bad };
};
window.multiAttrs = function (dtype, min, max) {
    if (dtype !== 'multi') return '';
    const e = (x) => String(x == null ? '' : x).replace(/"/g, '&quot;');
    const rng = (min || max) ? `${min || '…'}–${max || '…'}` : '';
    return ` data-multi="1" data-min="${e(min)}" data-max="${e(max)}" inputmode="numeric"`
        + ` autocomplete="off" placeholder="${rng ? 'цифри ' + rng : 'напр. 1, 4'}"`
        + ` title="Кілька чисел${rng ? ' ' + rng : ''} — порядок і коми стають самі"`;
};
(function () {
    const flash = (el) => {
        el.classList.remove('multi-bad');
        void el.offsetWidth;                 // перезапуск анімації
        el.classList.add('multi-bad');
        setTimeout(() => el.classList.remove('multi-bad'), 450);
    };
    document.addEventListener('input', (e) => {
        const el = e.target;
        if (!el || !el.matches || !el.matches('input[data-multi]')) return;
        const hi = el.dataset.max === '' ? null : Number(el.dataset.max);
        const single = hi !== null && hi <= 9;
        const raw = el.value;
        // великі межі: останнє число ще набирається — його не чіпаємо
        const tail = single ? '' : ((raw.match(/(\d+)$/) || [])[1] || '');
        const done = tail ? raw.slice(0, raw.length - tail.length) : raw;
        const r = window.multiNorm(done, el.dataset.min, el.dataset.max);
        let v = r.value;
        let bad = r.bad;
        if (tail) {
            const n = Number(tail);
            // повтор — лише коли число вже не може стати довшим (1 → 10…12)
            const dup = v.split(', ').includes(String(n)) && (hi === null || n * 10 > hi);
            const tooBig = hi !== null && n > hi;
            if (dup || tooBig) bad = true;
            else v = v ? v + ', ' + tail : tail;
        } else if (!single && /[\s,;]$/.test(raw) && v) {
            v += ', ';                        // розділювач — готові до наступного
        }
        // відмова у великих межах — поле як було до натискання (набране не губиться)
        if (bad && !single) v = el.dataset.prev || '';
        if (v !== raw) {
            el.value = v;
            el.setSelectionRange(v.length, v.length);
        }
        el.dataset.prev = v;
        if (bad) flash(el);
    });
    document.addEventListener('focusin', (e) => {    // поле вже з числами (картка)
        const el = e.target;
        if (el && el.matches && el.matches('input[data-multi]')) el.dataset.prev = el.value;
    });
    document.addEventListener('focusout', (e) => {
        const el = e.target;
        if (el && el.matches && el.matches('input[data-multi]')) {
            const v = window.multiNorm(el.value, el.dataset.min, el.dataset.max).value;
            if (v !== el.value) el.value = v;
        }
    });
}());

/* ── МИТТЄВІ ПІДКАЗКИ (Роман 2026-09-24: «усі спливаючі підказки на проєкті
   мають зʼявлятися миттєво»). Підказка браузера за `title` чекає ~1 с, і цю
   затримку не налаштувати. Тому на час наведення знімаємо `title` (щоб браузер
   не показав свою) і одразу малюємо свою коробку; після виходу `title`
   повертається — код, що його читає чи міняє, працює як раніше. Діє на ВСЕ,
   що має `title`, зокрема намальоване пізніше. ── */
(function () {
    if (window.matchMedia && window.matchMedia('(hover: none)').matches) return; // сенсорні — наведення немає
    const SKIP = { IFRAME: 1, HTML: 1, BODY: 1 };
    let tip = null, cur = null;
    function box() {
        if (!tip) {
            tip = document.createElement('div');
            tip.className = 'qtip';
            tip.setAttribute('role', 'tooltip');
            tip.hidden = true;
            document.body.appendChild(tip);
        }
        return tip;
    }
    function hide() {
        if (cur) {
            const t = cur.getAttribute('data-qtip');
            cur.removeAttribute('data-qtip');
            // title могли змінити, поки наводили, — нове значення не затираємо
            if (t !== null && !cur.hasAttribute('title')) cur.setAttribute('title', t);
            cur = null;
        }
        if (tip) tip.hidden = true;
    }
    function show(el, e) {
        const text = (el.getAttribute('title') || '').trim();
        if (!text) return;
        cur = el;
        el.setAttribute('data-qtip', el.getAttribute('title'));
        el.removeAttribute('title');
        const b = box();
        b.textContent = text;
        b.hidden = false;
        const r = el.getBoundingClientRect();
        const w = b.offsetWidth, h = b.offsetHeight, pad = 8;
        // невеликий елемент — під ним; великий (рядок, панель) — під курсором
        const below = r.height <= 60 ? r.bottom + 6 : e.clientY + 18;
        const above = r.height <= 60 ? r.top - h - 6 : e.clientY - h - 10;
        const x = Math.max(pad, Math.min(e.clientX - 12, window.innerWidth - w - pad));
        const y = below + h + pad > window.innerHeight ? Math.max(pad, above) : below;
        b.style.left = Math.round(x) + 'px';
        b.style.top = Math.round(y) + 'px';
    }
    document.addEventListener('mouseover', (e) => {
        const t = e.target;
        const el = t && t.closest ? t.closest('[title], [data-qtip]') : null;
        if (el === cur) return;
        hide();
        if (el && !SKIP[el.tagName] && el.hasAttribute('title')) show(el, e);
    }, true);
    document.addEventListener('mouseout', (e) => {
        if (cur && !(e.relatedTarget && cur.contains(e.relatedTarget))) hide();
    }, true);
    ['mousedown', 'keydown', 'wheel', 'dragstart'].forEach((ev) =>
        document.addEventListener(ev, hide, true));
    window.addEventListener('scroll', hide, true);
    window.addEventListener('blur', hide);
}());

/* ===== Кнопка облікового запису у верхньому куті (Роман 2026-09-25) =====
   Усе про себе — імʼя, хто ще онлайн, пароль, поділитися, встановлення,
   тема, вихід — живе під одним кружком і відкривається кліком.
   📌 Кнопки всередині зберегли СВОЇ id, тож решта коду (зміна пароля,
   встановлення застосунку, тема) працює як раніше — її не чіпали. */
(function () {
    const box = document.getElementById('ubox');
    const btn = document.getElementById('uboxBtn');
    const pop = document.getElementById('uboxPop');
    if (!box || !btn || !pop) return;

    const share = document.getElementById('uboxShare');
    function open(on) {
        pop.hidden = !on;
        btn.setAttribute('aria-expanded', on ? 'true' : 'false');
        if (!on && share) share.hidden = true;       // закрили — згортаємо й «поділитися»
    }
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        open(pop.hidden);
    });
    // клік повз вікно і Escape — закривають; усередині вікна клік лишає його
    document.addEventListener('click', (e) => {
        if (!pop.hidden && !box.contains(e.target)) open(false);
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !pop.hidden) open(false);
    });
    // дія з меню зроблена — вікно більше не потрібне
    ['changePasswordBtn', 'pwaInstallBtn'].forEach((id) => {
        const b = document.getElementById(id);
        if (b) b.addEventListener('click', () => open(false));
    });

    /* ── Поділитися: кинути людині посилання на ферму ──
       Адреса — та, за якою людина сюди зайшла (location.origin): і в хмарі,
       і в локальній мережі це рівно те, що треба переслати. */
    if (!share) return;
    const url = location.origin + '/';
    // назва ферми — з підпису в меню, якщо вона там є
    const co = (document.querySelector('meta[name="farm-name"]') || {}).content || '';
    const text = co ? ('Облік ферми · ' + co) : 'Облік ферми';
    const inp = document.getElementById('shareUrl');
    const hint = document.getElementById('shareHint');
    if (inp) inp.value = url;
    const sys = share.querySelector('[data-share="sys"]');
    if (sys && navigator.share) sys.hidden = false;

    const say = (t) => { if (hint) { hint.textContent = t; hint.style.color = 'var(--success,#1aa86b)'; } };
    document.getElementById('shareBtn').addEventListener('click', () => {
        share.hidden = !share.hidden;
        if (!share.hidden && inp) { inp.focus(); inp.select(); }
    });
    share.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-share]');
        if (!b) return;
        const how = b.dataset.share;
        if (how === 'copy') {
            try {
                await navigator.clipboard.writeText(url);
            } catch (_) {
                // несекюрний контекст (http у локальній мережі) — старий шлях
                if (inp) { inp.focus(); inp.select(); try { document.execCommand('copy'); } catch (e2) { /* ignore */ } }
            }
            say('Посилання скопійовано — вставте у повідомлення.');
        } else if (how === 'tg') {
            window.open('https://t.me/share/url?url=' + encodeURIComponent(url)
                + '&text=' + encodeURIComponent(text), '_blank', 'noopener');
        } else if (how === 'wa') {
            window.open('https://wa.me/?text=' + encodeURIComponent(text + ' ' + url),
                '_blank', 'noopener');
        } else if (how === 'viber') {
            // Viber відкриває свій застосунок; немає його — нічого не станеться,
            // тому поруч завжди лишається «Копіювати»
            location.href = 'viber://forward?text=' + encodeURIComponent(text + ' ' + url);
        } else if (how === 'sys' && navigator.share) {
            try { await navigator.share({ title: text, text, url }); } catch (_) { /* скасували */ }
        }
    });
}());
