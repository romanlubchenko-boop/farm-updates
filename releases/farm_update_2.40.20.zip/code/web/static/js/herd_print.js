/* Друк на A4 з попереднім переглядом — спільний для гілки стада
   (календар, «Робота зі стадом»). Рядки розкладаються по аркушах так само,
   як ляжуть на папір: висоту рядків міряємо в самій рамці перегляду, шапка
   таблиці повторюється в кожній колонці, назва групи не лишається сама
   внизу, продовження групи підписується «(продовження)».

   herdPrint.open({
       state:   { orient: 'p'|'l', twocol: bool,     // модуль читає й пише сюди
                  font: {family, size, bold, italic} },
       content: () => ({ title, sub, legend, body }), // body — h2/table-розмітка
       twocolToggle: bool,                            // перемикач «1 / 2 колонки» у смужці
       onChange: () => {},                            // після зміни orient/twocol
   }) */
'use strict';

(function () {
    const TWO_GAP_MM = 6;                                   // проміжок між колонками друку
    const esc = (s) => String(s === null || s === undefined ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

    const PRINT_CSS = `
    body{margin:0;background:#8a8f98;font-family:'IBM Plex Sans',Arial,sans-serif;font-size:12px;color:#000}
    .sheet{background:#fff;margin:14px auto;box-shadow:0 2px 10px rgba(0,0,0,.35);box-sizing:border-box;
        padding:10mm 10mm 8mm;overflow:hidden;position:relative}
    .sheet.p{width:210mm;height:297mm}.sheet.l{width:297mm;height:210mm}
    .pn{position:absolute;right:10mm;bottom:2.5mm;font-size:10px;color:#666}
    .over{position:absolute;top:0;bottom:0;border-left:2px dashed #c2333a}
    h1{font-size:14px;margin:0 0 6px}
    .two{display:flex;align-items:flex-start}
    .two .col{flex:1 1 0;min-width:0;padding-right:var(--g)}
    .two .col+.col{padding:0 0 0 var(--g)}
    h1 .sub{display:block;font-size:12.5px;font-weight:600;margin-top:2px}
    h1 .sub:empty{display:none}
    h1 .leg{display:block;font-size:12.5px;margin-top:8px}
    h1 .leg.thin,h1 .leg .thin{font-weight:400}
    h2{font-size:12.5px;margin:10px 0 4px;color:#000}
    table{border-collapse:collapse;table-layout:fixed}
    table.fit{table-layout:auto;width:auto}          /* ширину рахує аркуш, див. fitTables */
    /* підігнана таблиця НЕ переносить рядків: ширину вже пораховано під вміст,
       а якщо вона ширша за аркуш — зменшується весь вміст (Роман 2026-09-22).
       ⚠️ Лише .fitted: у календарі ширини задає людина, і там перенос лишається */
    table.fitted td,table.fitted th{white-space:nowrap}
    /* ⚠️ НА ЧАС ЗАМІРУ знімаємо обрізання: клітинка з overflow:hidden віддає
       браузерові нульову потрібну ширину, і колонку мірялo лише за
       заголовком — «118» не влазило в колонку під «№» (Роман 2026-09-22) */
    th,td{border:1px solid #999;padding:2px 5px;text-align:left;vertical-align:top;overflow:hidden;
        text-overflow:ellipsis;word-wrap:break-word}
    th{font-size:.85em;text-transform:uppercase;background:#eee}
    th .cl-rz,th .col-resizer{display:none}
    td.num,th.num{text-align:right}
    /* назва додаткового блоку зліва від номера (FILTER2) — місце під неї є
       в кожному рядку, тож номери на папері стоять рівно */
    .exm{display:inline-block;min-width:12px;margin-right:4px;font-style:normal;font-weight:700}
    tr.sec td{background:#f3f3f3;font-weight:600;font-size:.85em}
    tr.tot td{font-weight:700;border-top:2px solid #777}
    a{color:#000;text-decoration:none;font-weight:700}
    .cl-over,.cl-today{margin-left:4px;font-size:.9em}
    td.cl-mk{text-align:center;padding:2px 0;font-weight:400;font-size:.85em;color:#c2333a}
    #measure{position:absolute;left:-10000px;top:0}
    @media print{
        body{background:#fff}
        .sheet{margin:0;box-shadow:none;page-break-after:always;break-after:page}
        .sheet:last-child{page-break-after:auto;break-after:auto}
        .over{display:none}
        .sheet.p{height:296mm}.sheet.l{height:209mm}   /* запас, щоб не з'являвся порожній аркуш */
    }`;

    let box = null;         // модал (створюється один раз на сторінку)
    let cur = null;         // поточні налаштування виклику
    let seq = 0;            // лічильник перемальовувань: пізній виклик скасовує ранній

    function ensureBox() {
        if (box) return box;
        box = document.createElement('div');
        box.className = 'cl-prev';
        box.id = 'hpvModal';
        box.hidden = true;
        box.innerHTML = `<div class="cl-prevbox">
            <div class="cl-prevbar">
                <b id="hpvTitle"></b>
                <span class="cl-previnfo" id="hpvInfo"></span>
                <span class="hp-sp"></span>
                <label class="cl-prevf"><span>Шрифт</span>
                    <select id="hpvFamily">
                        <option value="">Як у програмі</option>
                        <option value="Arial">Arial</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Courier New">Courier New</option>
                    </select></label>
                <label class="cl-prevf"><span>Розмір</span>
                    <select id="hpvSize"></select></label>
                <label class="cl-prevf"><span>Масштаб</span>
                    <select id="hpvScale" title="Зменшує весь вміст, щоб умістити в аркуш"></select></label>
                <span class="cl-prevpair">
                    <button type="button" id="hpvBold" title="Жирний"><b>Ж</b></button>
                    <button type="button" id="hpvItalic" title="Курсив"><i>К</i></button>
                </span>
                <span class="segmented" id="hpvTwo" hidden>
                    <button type="button" class="seg-btn" data-c="0" title="Таблиця однією колонкою">1 колонка</button>
                    <button type="button" class="seg-btn" data-c="1" title="Таблиця двома половинами поруч">2 колонки</button>
                </span>
                <span class="segmented" id="hpvOrient">
                    <button type="button" class="seg-btn" data-o="p">Книжковий</button>
                    <button type="button" class="seg-btn" data-o="l">Альбомний</button>
                </span>
                <button type="button" class="btn btn-sm btn-primary" id="hpvPrint">🖨 Друкувати</button>
                <button type="button" class="btn btn-sm" id="hpvClose">Закрити</button>
            </div>
            <div class="cl-prevwarn" id="hpvWarn" hidden></div>
            <iframe id="hpvFrame" class="cl-prevframe" title="Попередній перегляд"></iframe>
        </div>`;
        document.body.appendChild(box);
        const $ = (id) => box.querySelector('#' + id);
        $('hpvOrient').addEventListener('click', (e) => {
            const b = e.target.closest('[data-o]');
            if (!b || !cur) return;
            cur.state.orient = b.dataset.o;
            if (cur.onChange) cur.onChange();
            render();
        });
        $('hpvTwo').addEventListener('click', (e) => {
            const b = e.target.closest('[data-c]');
            if (!b || !cur) return;
            cur.state.twocol = b.dataset.c === '1';
            if (cur.onChange) cur.onChange();
            render();
        });
        const setFont = (k, v) => {
            if (!cur) return;
            cur.state.font = Object.assign({}, cur.state.font || {}, { [k]: v });
            if (cur.onChange) cur.onChange();
            render();
        };
        $('hpvScale').addEventListener('change', () => {
            if (!cur) return;
            cur.state.scale = +$('hpvScale').value || 100;
            if (cur.onChange) cur.onChange();
            render();
        });
        $('hpvFamily').addEventListener('change', () => setFont('family', $('hpvFamily').value));
        $('hpvSize').addEventListener('change', () => setFont('size', +$('hpvSize').value));
        $('hpvBold').addEventListener('click', () => setFont('bold', !((cur.state.font || {}).bold)));
        $('hpvItalic').addEventListener('click', () => setFont('italic', !((cur.state.font || {}).italic)));
        $('hpvPrint').addEventListener('click', () => {
            const w = $('hpvFrame').contentWindow;
            w.focus();
            w.print();
        });
        $('hpvClose').addEventListener('click', close);
        box.addEventListener('click', (e) => { if (e.target === box) close(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !box.hidden) close(); });
        return box;
    }

    function close() {
        if (box) box.hidden = true;
        cur = null;
    }

    function open(opts) {
        ensureBox();
        cur = opts;
        if (!cur.state) cur.state = {};
        box.querySelector('#hpvTwo').hidden = !cur.twocolToggle;
        box.hidden = false;
        render();
    }

    /* ⚠️ ШИРИНА СТОВПЦІВ НА ДРУКУ (Роман 2026-09-22: «дивишся — оптимально
       вибрано, переходиш на друк — завищена ширина, і не всі стовпці
       поміщаються»). Причина: сторінка давала на друк ширини, ЗМІРЯНІ НА ЕКРАНІ,
       а екран удвічі ширший за аркуш (1400 px проти 718 px у книжковому A4) —
       зайве просто зрізалось, бо аркуш має overflow:hidden.
       Лікування: таблиця з класом «fit» приходить БЕЗ ширин, тут їй ставиться
       межа в ширину аркуша, і розкладку за вмістом (друкованим шрифтом, а не
       екранним) рахує сам браузер. Пораховане ЗАМОРОЖУЄМО в colgroup і вертаємо
       table-layout:fixed — інакше у двох колонках і на різних аркушах ті самі
       стовпці стали б різної ширини, бо кожен шматок міряв би себе окремо. */
    function fitTables(d, mz, innerW, zf) {
        const tt = [...mz.querySelectorAll('table.fit')];
        if (!tt.length) return;
        /* ⚠️ ШИРИНУ КОЛОНКИ РАХУЄМО ЗА ТЕКСТОМ, а не питаємо браузер (Роман
           2026-09-22: «сильно звужені рядки і текст переходить на наступну
           строку»). Тричі наступив на граблі, перш ніж дійшло: (1) межа в
           ширину аркуша змушувала стискати колонки й переносити текст;
           (2) клітинка з overflow:hidden не додає своєї ширини до
           автоматичної розкладки — колонку мірялo лише за заголовком, і «118»
           не влазило під «№»; (3) getBoundingClientRect і scrollWidth просто
           повертають уже пораховану, стиснуту ширину. Тому міряємо самі
           текст — шрифтом тієї ж клітинки — і додаємо її поля й рамку. Це
           рівно та ширина, за якої рядок лишається в ОДИН рядок. Не влазить
           у аркуш — нижче весь вміст рівно зменшується масштабом. */
        const win = d.defaultView;
        const g = d.createElement('canvas').getContext('2d');
        const fontOf = (el) => {
            const cs = win.getComputedStyle(el);
            return `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
        };
        const padOf = (el) => {
            const cs = win.getComputedStyle(el);
            return parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight)
                + parseFloat(cs.borderLeftWidth) + parseFloat(cs.borderRightWidth);
        };
        /* ширина вмісту клітинки: КОЖНА частина — СВОЇМ шрифтом (2.39.89). Доти
           все мірялось шрифтом першої клітинки таблиці: жирний номер (<a>),
           жирні підсумки (<b>) і дрібніша шапка групи давали хибну ширину —
           «1023» ставало «10…», «222,0» у «Разом» — «22…». Позначка
           додаткового блоку (.exm) — коробка з min-width навіть порожня. */
        const wOf = (el) => {
            let w = 0;
            el.childNodes.forEach((n) => {
                if (n.nodeType === 3) {
                    const tx = n.textContent.replace(/\s+/g, ' ');
                    if (!tx.trim()) return;
                    g.font = fontOf(el);
                    w += g.measureText(tx).width;
                } else if (n.nodeType === 1) {
                    const cs = win.getComputedStyle(n);
                    if (cs.display === 'none') return;
                    let iw = wOf(n);
                    if (cs.display.startsWith('inline-block')) iw = Math.max(parseFloat(cs.minWidth) || 0, iw);
                    w += iw + (parseFloat(cs.marginLeft) || 0) + (parseFloat(cs.marginRight) || 0)
                        + (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
                }
            });
            return w;
        };
        tt.forEach((t) => {
            const hr = t.tHead && t.tHead.rows[0];
            if (!hr) { t.classList.remove('fit'); return; }
            const n = [...hr.cells].length;
            const need = new Array(n).fill(0);
            let font = '', pad = 0, fontH = '', padH = 0;
            const spans = [];                                // [від, скільки колонок, потрібна ширина]
            [...t.rows].forEach((r) => {
                let i = 0;
                // шапка групи на новій колонці / аркуші дістає « (продовження)» —
                // місце під нього закладаємо в першій клітинці з текстом
                let cont = r.classList.contains('sec');
                const more = (c) => {
                    if (!cont || !c.textContent.trim()) return 0;
                    cont = false;
                    g.font = fontOf(c);
                    return g.measureText(' (продовження)').width;
                };
                [...r.cells].forEach((c) => {
                    const sp = c.colSpan || 1;
                    // клітинка на кілька колонок (назва групи, «Разом») — міряємо
                    // після: якщо не влазить у свої колонки, розширюємо останню з них
                    if (sp > 1) { spans.push([i, sp, wOf(c) + padOf(c) + more(c)]); i += sp; return; }
                    if (i >= n) { i += 1; return; }
                    const isH = c.tagName === 'TH';
                    if (isH) {
                        if (!fontH) { fontH = fontOf(c); padH = padOf(c); }
                        g.font = fontH;
                        const txt = (c.textContent || '').trim().toUpperCase();   // шапка великими
                        need[i] = Math.max(need[i], g.measureText(txt).width + padH);
                    } else {
                        if (!font) { font = fontOf(c); pad = padOf(c); }
                        need[i] = Math.max(need[i], wOf(c) + pad + more(c));
                    }
                    i += 1;
                });
            });
            const ws = need.map((w) => Math.max(Math.ceil(w) + 2, 18));
            spans.forEach(([from, sp, w]) => {
                const to = Math.min(n, from + sp) - 1;
                if (to < from) return;
                const have = ws.slice(from, to + 1).reduce((a, b) => a + b, 0);
                if (w + 2 > have) ws[to] += Math.ceil(w + 2 - have);
            });
            const cg = d.createElement('colgroup');
            cg.innerHTML = ws.map((w) => `<col style="width:${w}px">`).join('');
            const old = t.querySelector('colgroup');
            if (old) old.remove();
            t.insertBefore(cg, t.firstChild);
            t.style.width = ws.reduce((a, b) => a + b, 0) + 'px';
            t.classList.remove('fit');
            t.classList.add('fitted');      // див. правило nowrap у PRINT_CSS
        });
    }

    /* розкладка по аркушах: h2 і таблиці йдуть один за одним; колонка заповнюється
       до низу, далі наступна колонка (права), і лише потім новий аркуш */
    function render() {
        if (!cur) return;
        const $ = (id) => box.querySelector('#' + id);
        const orient = cur.state.orient === 'l' ? 'l' : 'p';
        const two = !!cur.state.twocol;
        box.querySelectorAll('#hpvOrient .seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.o === orient));
        box.querySelectorAll('#hpvTwo .seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.c === (two ? '1' : '0')));
        // шрифт друку: розмір, гарнітура, жирний / курсив
        const f = cur.state.font || {};
        const size = +f.size || 12;
        $('hpvSize').innerHTML = [8, 9, 10, 11, 12, 13, 14, 16, 18].map((n) =>
            `<option value="${n}"${n === size ? ' selected' : ''}>${n}</option>`).join('');
        $('hpvFamily').value = f.family || '';
        $('hpvBold').classList.toggle('on', !!f.bold);
        $('hpvItalic').classList.toggle('on', !!f.italic);
        const scale = Math.min(200, Math.max(40, +cur.state.scale || 100));
        $('hpvScale').innerHTML = [60, 70, 75, 80, 85, 90, 95, 100, 110, 125].map((n) =>
            `<option value="${n}"${n === scale ? ' selected' : ''}>${n}%</option>`).join('');
        // zf може зменшитись після заміру (автопідгонка під ширину аркуша),
        // а шаблонний рядок рахується в мить виклику — тож аркуші, намальовані
        // ПІСЛЯ заміру, беруть уже підігнаний масштаб
        let zf = scale / 100;
        const zm = (html) => `<div class="zm"${zf !== 1 ? ` style="zoom:${zf}"` : ''}>${html}</div>`;
        const fontCss = `.sheet,#measure{font-size:${size}px`
            + (f.family ? `;font-family:'${f.family}',sans-serif` : '')
            + (f.bold ? ';font-weight:600' : '')
            + (f.italic ? ';font-style:italic' : '') + '}';
        const c = cur.content() || {};
        $('hpvTitle').textContent = c.title || '';
        const d = $('hpvFrame').contentWindow.document;
        d.open();
        d.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(c.title)}</title>
            <style>@page{size:A4 ${orient === 'l' ? 'landscape' : 'portrait'};margin:0}${PRINT_CSS}${fontCss}</style></head>
            <body><div id="measure" class="sheet ${orient}">${zm(`<h1>${esc(c.title)}<span class="sub">${esc(c.sub || '')}</span>${c.legend ? `<span class="leg">${c.legend}</span>` : ''}</h1>${c.body || ''}`)}</div></body></html>`);
        d.close();
        const my = ++seq;                       // дві перемальовки поспіль: рахує лише остання
        setTimeout(() => {
            if (!cur || my !== seq) return;
            const m = d.getElementById('measure');
            if (!m) return;
            const mmPx = 96 / 25.4;
            const inner = ((orient === 'l' ? 210 : 297) - 18 - 1) * mmPx;   // мінус поля (номер аркуша — у нижньому полі) і 1 мм запасу
            const per = two ? 2 : 1;                                        // колонок на аркуші
            const sheetW = ((orient === 'l' ? 297 : 210) - 20) * mmPx;
            const innerW = two ? (sheetW - TWO_GAP_MM * mmPx) / 2 : sheetW;
            const mz = m.querySelector('.zm') || m;
            fitTables(d, mz, innerW, zf);
            // ширший за аркуш лишається тільки той стовпець, який нікуди не
            // стиснути (дата не переноситься) — тоді рівно зменшуємо ВЕСЬ вміст,
            // щоб не зрізати останні стовпці; нижче 50 % не опускаємось
            const fitW = Math.max(0, ...[...mz.querySelectorAll('table')]
                .map((t) => t.getBoundingClientRect().width));
            let auto = 1;
            if (fitW > innerW + 1) {
                auto = Math.max(0.5, (innerW - 1) / fitW);
                zf = zf * auto;
                mz.style.zoom = zf;
            }
            const h1 = mz.querySelector('h1');
            const tables = [...mz.querySelectorAll('table')];
            const hOf = (el) => el.getBoundingClientRect().height;      // дробова висота — без похибки округлення
            const headH = (tables.length && tables[0].tHead) ? hOf(tables[0].tHead) : 0;
            const h1H = hOf(h1) + 6;
            // ширина з урахуванням масштабу: rect уже враховує zoom
            const wide = tables.some((t) => t.getBoundingClientRect().width > innerW + 1);
            const colHtml = (items) => items.map((it) => it.h2
                || `<table class="${esc(it.table.className)}" style="${it.table.getAttribute('style') || ''}">`
                   + `${(it.table.querySelector('colgroup') || { outerHTML: '' }).outerHTML}`
                   + `${it.table.tHead ? it.table.tHead.outerHTML : ''}<tbody>${it.rows.join('')}</tbody></table>`).join('');
            const layout = (limit) => {
                const cols = [];
                let page = [], used = h1H, open = null;                 // open — таблиця, у яку зараз пишемо
                const push = () => { cols.push(page); page = []; used = cols.length < per ? h1H : 0; open = null; };
                [...mz.children].forEach((el) => {
                    if (el.tagName === 'H2') {
                        const h = hOf(el) + 14;                         // з полями заголовка
                        if (page.length && used + h + headH + 24 > limit) push();
                        page.push({ h2: el.outerHTML }); used += h; open = null;
                    } else if (el.tagName === 'TABLE') {
                        const t = el;
                        const all = t.tBodies[0] ? [...t.tBodies[0].rows] : [];
                        const stack = [];                               // поточні групи за рівнями
                        all.forEach((r, ri) => {
                            const isSec = r.classList.contains('sec');
                            // назва групи не лишається сама внизу колонки — з нею хоч один рядок
                            const h = hOf(r) + (isSec && all[ri + 1] ? hOf(all[ri + 1]) : 0);
                            if (open !== t && used + headH + h > limit && page.length) push();
                            else if (open === t && used + h > limit) push();
                            if (open !== t) {
                                const cont = page.length === 0 && !isSec && stack.length;
                                page.push({ table: t, rows: [] }); used += headH; open = t;
                                // продовження групи в новій колонці / на новому аркуші — з її назвою
                                if (cont) stack.forEach((sr) => {
                                    const cl = sr.cloneNode(true);
                                    // назва групи може стояти не в першій клітинці (перед нею
                                    // порожня колонка «№») — дописуємо туди, де є текст
                                    const tc = [...cl.cells].find((c) => c.textContent.trim()) || cl.cells[0];
                                    tc.textContent += ' (продовження)';
                                    page[page.length - 1].rows.push(cl.outerHTML); used += hOf(sr);
                                });
                            }
                            if (isSec) {
                                const lv = +((r.className.match(/\bl(\d)/) || [])[1] || 0);
                                stack.length = lv; stack[lv] = r;
                            }
                            page[page.length - 1].rows.push(r.outerHTML); used += hOf(r);
                        });
                    }
                });
                cols.push(page);
                const pages = [];
                for (let i = 0; i < cols.length; i += per) pages.push(cols.slice(i, i + per));
                return pages;
            };
            const draw = (pages) => pages.map((pc, i) => `<div class="sheet ${orient}">
                ${zm(`${i === 0 ? h1.outerHTML : ''}`
                    + `${two ? `<div class="two" style="--g:${TWO_GAP_MM / 2}mm">${pc.map((cc) => `<div class="col">${colHtml(cc)}</div>`).join('')}</div>` : colHtml(pc[0])}`)}
                ${wide ? `<div class="over" style="left:${10 * mmPx + innerW}px"></div>` : ''}
                <span class="pn">${i + 1} / ${pages.length}</span></div>`).join('');
            // перевірка на готових аркушах: якщо щось вилазить за низ — розкласти щільніше
            let limit = inner, pages = [];
            for (let pass = 0; pass < 6; pass++) {
                d.querySelectorAll('.sheet:not(#measure)').forEach((x) => x.remove());
                pages = layout(limit);
                d.body.insertAdjacentHTML('beforeend', draw(pages));
                let over = 0;
                d.querySelectorAll('.sheet:not(#measure)').forEach((sh) => {
                    const top = sh.getBoundingClientRect().top + 10 * mmPx;
                    sh.querySelectorAll('table, h2').forEach((x) => {
                        over = Math.max(over, x.getBoundingClientRect().bottom - top - inner);
                    });
                });
                if (over <= 0.5) break;
                limit -= over + 2;
            }
            m.remove();
            $('hpvInfo').innerHTML = `Аркушів: <b>${pages.length}</b>`
                + (auto < 0.999 ? ` · вміщено: <b>${Math.round(zf * 100)}%</b>` : '');
            // попередження окремим рядком: у смужці воно розсувало кнопки
            $('hpvWarn').textContent = wide
                ? 'Таблиця ширша за аркуш — зменшіть масштаб чи шрифт або візьміть альбомний.' : '';
            $('hpvWarn').hidden = !wide;
        }, 60);
    }

/* ═══ НУЛЬ НА ПАПЕРІ ═══
   Роман 2026-09-25: «якщо DCC дорівнює нулю — просто пустота… це для того,
   щоб економити фарбу в принтері». Нуль у днях доїння, лактації чи номері
   осіменіння нічого не додає, а на аркуші з сотнею рядків це сотня зайвих
   знаків. Вмикається В ПАРАМЕТРІ (Конструктор → Параметри → «Нуль не
   друкувати»), тож рішення за фермою, а не за програмою.
   ⚠️ Лише ДРУК: на екрані, у файлі й у підсумках нуль лишається — у файлі
   він потрібен для рахунку, а порожнеча там читалась би як «немає даних». */
function isZeroText(t) {
    const s0 = String(t == null ? '' : t)
        .replace(/[\s\u00a0]/g, '').replace(',', '.');
    return s0 !== '' && /^-?0(\.0+)?$/.test(s0);
}

    window.herdPrint = { open, TWO_GAP_MM, isZeroText };
}());
