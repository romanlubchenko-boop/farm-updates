/* Налаштування параметрів тварин (стандартні + власні). */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const DTYPE_LABEL = {
    date: 'Дата', text: 'Текст', int: 'Ціле (int)', float: 'Дробове (float)',
    bool: 'Так/Ні', list: 'Список', cod: 'Код', ref: 'Довідник', ref_animal: 'Родовід',
    computed: 'Обчислюване',
    // legacy-аліаси
    number: 'Число', select: 'Список', code: 'Код',
};
// Типи ДАНИХ (обчислюваність — окремо, через «Тип обчислення»)
const ADD_DTYPES = ['int', 'float', 'text', 'date', 'bool', 'list', 'cod', 'ref', 'ref_animal'];
// Опис вбудованих (стандартних) формул — для показу «як обчислюється»
// опис вбудованих формул — назвами параметрів із конструктора
const L_ = (k, fb) => (window.herdLabel ? herdLabel(k, fb) : fb);
const LEGACY_DESC = {
    age: `${L_('age', 'Вік')} = Сьогодні − ${L_('birth_date', 'Дата народження')} (у місяцях)`,
    days_alive: `${L_('days_alive', 'Днів життя')} = Сьогодні − ${L_('birth_date', 'Дата народження')}`,
    dim: `${L_('dim', 'Днів у молоці')} = Сьогодні − ${L_('last_calving', 'Дата останнього отелу')}`,
    days_preg: `${L_('days_preg', 'Днів тільності')} = Сьогодні − ${L_('last_insem', 'Дата ост. осіменіння')}`
        + ` (лише коли «${window.herdOpt ? herdOpt('repro_code', '5', 'Тільна') : 'Тільна'}»)`,
    expected_calving: `${L_('expected_calving', 'Очікуваний отел')} = ${L_('last_insem', 'Дата ост. осіменіння')} + 280 днів`,
    service_period: `${L_('service_period', 'Сервіс-період')} = ${L_('last_insem', 'Дата ост. осіменіння')} − ${L_('last_calving', 'Дата останнього отелу')}`,
};
// Вбудовані формули в термінах конструктора — щоб їх було видно й можна
// було змінити (Роман: «не бачу параметрів обчислення формульних параметрів»).
const LEGACY_AS_CFG = {
    age: { op: 'month_diff', a: '__today__', b: 'birth_date' },
    days_alive: { op: 'date_diff', a: '__today__', b: 'birth_date' },
    dim: { op: 'date_diff', a: '__today__', b: 'last_calving' },
    days_preg: { op: 'date_diff', a: '__today__', b: 'last_insem' },
    expected_calving: { op: 'date_add', a: 'last_insem', b: '280' },
    service_period: { op: 'date_diff', a: 'last_insem', b: 'last_calving' },
};
let FORMULA_OPS = [];     // операції для обчислюваних (date_diff, num_diff…)
let EVENT_OPERANDS = [], SCOPE_OPERANDS = [];   // події та «за життя / у лактації»
let DATE_OPERANDS = [];   // дати-операнди (сьогодні, народження, параметри-дати)
let NUM_OPERANDS = [];    // числові операнди (№ лактації, параметри int/float)
let COD_OPERANDS = [];    // cod-операнди (для code_label — довідник код→мітка)
let ANY_OPERANDS = [];    // будь-який параметр — для «попереднього значення»
let editingLegacy = false; // редагуємо стандартну вбудовану формулу (не конструктор)
const IS_LIST = (dt) => dt === 'list' || dt === 'select';
const IS_COD = (dt) => dt === 'cod' || dt === 'code';
const HAS_OPTS = (dt) => IS_LIST(dt) || IS_COD(dt);
// режим параметра: fixed | history (значення з історії іншого) | computed
function modeOf(formula) {
    const f = (formula || '').trim();
    if (!f) return 'fixed';
    if (f.startsWith('{')) {
        try { if (String(JSON.parse(f).op || '').startsWith('hist_')) return 'history'; }
        catch (e) { /* ignore */ }
    }
    return 'computed';
}
function histCfg(formula) {
    try { return JSON.parse(formula || '{}'); } catch (e) { return {}; }
}

// Розбір значень: list → масив рядків; cod → масив {c,l}
// (діапазон «0-9» розгортається; або числа/пари «1=Телиця» через кому)
function parseOptions(dtype, raw) {
    const s = (raw || '').trim();
    if (IS_COD(dtype)) {
        const rng = s.match(/^(-?\d+)\s*[-–]\s*(-?\d+)$/);   // діапазон N-M
        if (rng) {
            let a = +rng[1], b = +rng[2];
            if (a > b) { const t = a; a = b; b = t; }
            const out = [];
            for (let i = a; i <= b; i++) out.push({ c: String(i), l: String(i) });
            return out;
        }
        return s.split(',').map((x) => x.trim()).filter(Boolean).map((x) => {
            const i = x.indexOf('=');
            return i < 0 ? { c: x, l: x } : { c: x.slice(0, i).trim(), l: x.slice(i + 1).trim() };
        }).filter((o) => o.c !== '');
    }
    return s.split(',').map((x) => x.trim()).filter(Boolean);
}
// чи це суцільний цілочисловий діапазон без власних підписів
function codIsRange(list) {
    if (!list || list.length < 2) return false;
    const nums = list.map((o) => Number(o.c));
    if (nums.some((n) => !Number.isInteger(n))) return false;
    if (list.some((o) => String(o.l) !== String(o.c))) return false;
    for (let i = 1; i < nums.length; i++) if (nums[i] !== nums[i - 1] + 1) return false;
    return true;
}
function formatOptions(dtype, list) {
    if (!list || !list.length) return '';
    if (IS_COD(dtype)) {
        if (codIsRange(list)) return `${list[0].c}-${list[list.length - 1].c}`;
        return list.map((o) => (String(o.l) === String(o.c) ? o.c : `${o.c}=${o.l}`)).join(', ');
    }
    return list.join(', ');
}
function operandLabel(key) {
    const o = DATE_OPERANDS.find((x) => x.key === key);
    return o ? o.label : (key || '');
}
function opLabel(opKey) {
    const f = FORMULA_OPS.find((x) => x.op === opKey);
    return f ? f.label : opKey;
}
function detailText(p) {
    const f = (p.formula || '').trim();
    if (f) {                         // обчислюване
        if (f.startsWith('{')) {
            try {
                const c = JSON.parse(f);
                const lab = (k) => {
                    const o = DATE_OPERANDS.find((x) => x.key === k)
                        || NUM_OPERANDS.find((x) => x.key === k)
                        || COD_OPERANDS.find((x) => x.key === k)
                        || ANY_OPERANDS.find((x) => x.key === k);
                    return o ? o.label : k;   // літерал → саме число
                };
                if (c.op === 'code_label') return `авто: назва коду «${escapeHtml(lab(c.a))}» з його списку`;
                if (c.op === 'list_pos') return `авто: яким за рахунком «${escapeHtml(lab(c.a))}» іде у списку`;
                if (c.op === 'event_count') {
                    const ev = (EVENT_OPERANDS.find((x) => x.key === c.a) || {}).label || c.a;
                    return `авто: скільки разів сталася подія «${escapeHtml(ev)}»`
                        + ((c.scope || c.b) === 'lactation' ? ' у цій лактації' : ' за все життя');
                }
                if (c.op === 'hist_val' || c.op === 'hist_date') {
                    const n = Math.abs(parseInt(c.b, 10) || 1);
                    const nth = n === 1 ? 'останнє' : (n === 2 ? 'передостаннє' : n + '-те з кінця');
                    const what = c.op === 'hist_date' ? 'дата' : 'значення';
                    return `з історії: ${what} — ${nth} «${escapeHtml(lab(c.a))}»`;
                }
                const sign = (c.op === 'num_sum' || c.op === 'date_add') ? '+' : '−';
                return `авто: ${escapeHtml(lab(c.a))} ${sign} ${escapeHtml(lab(c.b))}`;
            } catch (e) { /* ignore */ }
        }
        return 'авто: ' + escapeHtml(LEGACY_DESC[f] || f);
    }
    if (IS_COD(p.dtype)) return escapeHtml(formatOptions(p.dtype, p.options_list || []));
    if (IS_LIST(p.dtype)) return escapeHtml((p.options_list || []).join(', '));
    return '';
}

const $ = (id) => document.getElementById(id);
let SECTIONS = [];
let PARAMS = [];            // усі параметри (за sort_order)
let REFS = [];              // довідники значень (для типу «ref»)
let editing = null;        // параметр, який редагуємо
let ppQuery = '';          // фільтр пошуку

// Параметри, що проходять фільтр (за назвою/скороченням/секцією)
function filteredParams() {
    const q = ppQuery.trim().toLowerCase();
    if (!q) return PARAMS;
    return PARAMS.filter((p) =>
        (p.label || '').toLowerCase().includes(q)
        || (p.short || '').toLowerCase().includes(q)
        || (p.section || '').toLowerCase().includes(q));
}

async function load() {
    const r = await apiGet('/api/herd/params');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    SECTIONS = r.sections || [];
    PARAMS = r.params || [];
    REFS = r.refs || [];
    FORMULA_OPS = r.formula_ops || [];
    DATE_OPERANDS = r.date_operands || [];
    NUM_OPERANDS = r.num_operands || [];
    COD_OPERANDS = r.cod_operands || [];
    ANY_OPERANDS = r.any_operands || [];
    EVENT_OPERANDS = r.event_operands || [];
    SCOPE_OPERANDS = r.scope_operands || [];
    render(filteredParams());
    // сигнал іншим блокам (Події) — оновити списки параметрів
    document.dispatchEvent(new CustomEvent('herd-params-changed'));
}

function opSpec(op) {               // типи слотів A/B для операції ('' = слот сховано)
    const f = FORMULA_OPS.find((x) => x.op === op);
    return f ? { a: f.a || 'date', b: ('b' in f ? f.b : 'date') } : { a: 'date', b: 'date' };
}
function slotList(type) {           // операнди слота (+ «Число (ввести)» для num)
    if (type === 'num') return NUM_OPERANDS.concat([{ key: '__literal__', label: 'Число (ввести)' }]);
    if (type === 'cod') return COD_OPERANDS;
    if (type === 'any') return ANY_OPERANDS;
    if (type === 'event') return EVENT_OPERANDS;
    if (type === 'scope') return SCOPE_OPERANDS;
    return DATE_OPERANDS;
}
const isLiteral = (v) => /^-?\d/.test(String(v || ''));
function fillSlot(type, val, selId, litId) {
    const list = slotList(type);
    $(selId).innerHTML = list.map((o) =>
        `<option value="${escapeHtml(o.key)}">${escapeHtml(o.label)}</option>`).join('');
    const known = list.some((o) => o.key === val);
    const lit = $(litId);
    if (type === 'num' && val && !known && isLiteral(val)) {   // збережений літерал
        $(selId).value = '__literal__'; lit.value = val; lit.hidden = false;
    } else {
        $(selId).value = known ? val : (list[0] ? list[0].key : '');
        lit.hidden = $(selId).value !== '__literal__';
        if (!lit.hidden && isLiteral(val)) lit.value = val;
    }
}
function fillOperandSelects(op, a, b) {
    const spec = opSpec(op);
    const hintEl = $('peOpHint');
    if (hintEl) {
        hintEl.textContent = (op === 'hist_val' || op === 'hist_date')
            ? 'Значення береться з історії подій тварини: −1 — останнє внесене, '
              + '−2 — передостаннє, −3 — і так далі (1, 2 — від найпершого). '
              + 'Працює з будь-яким параметром: надій, дата отелу, нотатка про мастит.'
            : '';
    }
    fillSlot(spec.a, a, 'peOpA', 'peALit');
    const hasB = !!spec.b;                       // '' → операція з одним операндом
    // одна величина (назва коду) — без знака, другого поля й «при помилці»
    ['peOpBLabel', 'peOpB', 'peFbLabel', 'peFallback'].forEach((id) => { if ($(id)) $(id).hidden = !hasB; });
    if (!hasB) $('peBLit').hidden = true;
    if (op === 'code_label' || op === 'list_pos') codeLabelHint(op);
    if (op === 'event_count' && hintEl) {
        hintEl.textContent = 'Рахує, скільки разів подія сталася з твариною: '
            + 'за все життя або від останнього отелу («у цій лактації»). '
            + 'Кількість отелів за життя — це і є номер лактації.';
    }
    if (hasB) {
        const isHist = (op === 'hist_val' || op === 'hist_date');
        fillSlot(spec.b, isHist ? (b || '-1') : b, 'peOpB', 'peBLit');
        if (isHist) {                       // історія: завжди число-зсув
            $('peOpBLabel').textContent = '·';
            $('peOpB').value = '__literal__';
            $('peBLit').hidden = false;
            if (!$('peBLit').value) $('peBLit').value = b || '-1';
            $('peBLit').placeholder = '-1 останнє · -2 передостаннє';
            $('peOpBLabel').textContent = 'Який за рахунком (з кінця)';
        } else {
            // у рядку-реченні досить знака операції
            if (op === 'event_count') {
                $('peOpBLabel').textContent = 'рахувати';
                $('peBLit').hidden = true;
            } else {
                const minus = (op === 'date_diff' || op === 'date_sub'
                    || op === 'num_diff' || op === 'month_diff');
                $('peOpBLabel').textContent = minus ? '−' : '+';
            }
        }
    }
}
/* «Назва коду зі списку» / «Яким за рахунком»: показуємо саму таблицю */
function codeLabelHint(op) {
    const el = $('peOpHint');
    if (!el) return;
    const p = PARAMS.find((x) => x.key === $('peOpA').value);
    if (!p) { el.textContent = ''; return; }
    const pos = (op || $('peOp').value) === 'list_pos';
    const opts = ifOptionsOf(p.key);
    const src = String(p.options || '');
    const live = src === '@sections'
        ? 'Список береться зі «Секцій» Конструктора — у тому порядку, як вони там стоять.'
        : (src.startsWith('@ref:') ? 'Список береться з довідника Конструктора.' : '');
    el.innerHTML = `<span class="pp-cl-how">Бере значення «${escapeHtml(p.label)}» і шукає його у списку.
        ${pos ? 'Показує, яким за рахунком воно йде: 1, 2, 3…' : 'Знайшло — показує назву'};
        немає такого значення — порожньо. ${escapeHtml(live)}</span>`
        + (opts.length
            ? `<table class="pp-cl-map"><thead><tr><th>${escapeHtml(p.label)}</th><th></th>`
              + `<th>Показує</th></tr></thead><tbody>`
              + opts.map((o, i) => `<tr><td>${escapeHtml(o.c)}</td><td>→</td>`
                  + `<td>${pos ? (i + 1) : escapeHtml(o.l)}</td></tr>`).join('')
              + '</tbody></table>'
            : (live ? '' : '<span class="pp-cl-how">У цього параметра список порожній.</span>'));
}
function slotValue(selId, litId) {  // значення операнда (літерал → число)
    if ($(selId).value === '__literal__') return ($(litId).value || '').trim().replace(',', '.');
    return $(selId).value;
}
/* ── Умова «рахувати лише коли…» ──────────────────────────────────────
   Показник без умови рахується завжди — так ялова корова діставала «Днів
   тільності» від останнього осіменіння. Умова дивиться на параметр-код
   (репродуктивний код, статус тільності) і дозволяє рахунок лише для
   обраних значень. */
function ifOptionsOf(key) {
    const p = PARAMS.find((x) => x.key === key);
    if (!p) return [];
    let raw = p.options;
    if (typeof raw === 'string') {
        if (raw.startsWith('@')) return [];      // довідник/секції — свій список
        try { raw = JSON.parse(raw || '[]'); } catch (e) { raw = []; }
    }
    return (raw || []).map((o) => (typeof o === 'object'
        ? { c: String(o.c), l: o.l || String(o.c) } : { c: String(o), l: String(o) }));
}

function renderIfVals(key, picked) {
    const box = $('peIfVals'), eq = $('peIfEq'), hint = $('peIfHint');
    const opts = ifOptionsOf(key);
    const on = (picked || []).map(String);
    if (!key || !opts.length) {
        box.hidden = true; eq.hidden = true; box.innerHTML = '';
        if (hint) { hint.hidden = !key; hint.textContent = key
            ? 'У цього параметра немає готового списку значень — умову за ним задати не можна.' : ''; }
        return;
    }
    if (hint) { hint.hidden = false;
        hint.textContent = 'Поза цими значеннями показник лишається порожнім.'; }
    eq.hidden = false;
    box.hidden = false;
    box.innerHTML = opts.map((o) => `
        <label class="${on.includes(o.c) ? 'on' : ''}">
            <input type="checkbox" value="${escapeHtml(o.c)}" ${on.includes(o.c) ? 'checked' : ''}>
            ${escapeHtml(o.l)}</label>`).join('');
    box.querySelectorAll('input').forEach((c) => c.addEventListener('change', () => {
        c.closest('label').classList.toggle('on', c.checked);
    }));
}

function fillIfSelect(sel, picked) {
    const el = $('peIfA');
    if (!el) return;
    el.innerHTML = '<option value="">— завжди —</option>'
        + COD_OPERANDS.map((o) =>
            `<option value="${escapeHtml(o.key)}"${o.key === sel ? ' selected' : ''}>`
            + `${escapeHtml(o.label)}</option>`).join('');
    renderIfVals(sel, picked);
}

function ifConfig() {
    const key = $('peIfA') ? $('peIfA').value : '';
    if (!key) return null;
    const vals = [...document.querySelectorAll('#peIfVals input:checked')].map((c) => c.value);
    return vals.length ? { a: key, in: vals } : null;
}

function fillFormulaSelects() {
    $('peOp').innerHTML = FORMULA_OPS.map((f) =>
        `<option value="${f.op}">${escapeHtml(f.label)}</option>`).join('');
}

function sectionOptions(sel) {
    return SECTIONS.map((s) =>
        `<option value="${escapeHtml(s)}"${s === sel ? ' selected' : ''}>${escapeHtml(s)}</option>`).join('');
}

/* ---------- список ---------- */
function render(params) {
    $('ppCount').textContent = params.length ? `· ${params.length}` : '';
    const bySec = {};
    params.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    const order = SECTIONS.concat(Object.keys(bySec).filter((s) => !SECTIONS.includes(s)));
    let html = '';
    let seq = 0;                       // суцільна нумерація згори вниз (по блоках)
    order.forEach((sec) => {
        const list = bySec[sec];
        if (!list || !list.length) return;
        html += `<tr class="pp-sec"><td colspan="9">${escapeHtml(sec)} · ${list.length}</td></tr>`;
        list.forEach((p) => {
            const idx = params.indexOf(p);
            seq += 1;
            const detail = detailText(p);
            html += `<tr class="pp-row ${p.is_active ? '' : 'off'}" data-id="${p.id}">
                <td class="pp-c pp-num">${seq}</td>
                <td class="pp-name"><b>${escapeHtml(p.label)}</b></td>
                <td class="pp-short">${escapeHtml(p.short || '')}</td>
                <td class="pp-dtype">${DTYPE_LABEL[p.dtype] || p.dtype}</td>
                <td>${escapeHtml(p.unit || '')}</td>
                <td class="pp-detail">${detail}</td>
                <td><span class="pp-badge ${p.is_standard ? 'std' : 'cus'}">${p.is_standard ? 'системний' : 'створений'}</span></td>
                <td class="pp-c"><input type="checkbox" data-act="toggle" ${p.is_active ? 'checked' : ''}></td>
                <td class="pp-c pp-actions">
                    <button class="pp-move" data-act="up" ${idx === 0 ? 'disabled' : ''} title="Вгору">▲</button>
                    <button class="pp-move" data-act="down" ${idx === params.length - 1 ? 'disabled' : ''} title="Вниз">▼</button>
                    <button data-act="edit" title="Редагувати">✏</button>
                    ${(!p.is_standard || window.canManage('herd')) ? '<button class="pp-del-btn" data-act="del" title="Видалити">−</button>' : ''}
                </td>
            </tr>`;
        });
    });
    $('ppBody').innerHTML = html ||
        `<tr><td colspan="9" class="empty">${ppQuery ? 'Нічого не знайдено' : 'Немає параметрів'}</td></tr>`;
    if (window.makeColumnsResizable) makeColumnsResizable('ppTable', 'farm:pp_cols');
}

/* ---------- модал: додати / редагувати ---------- */
function openEdit(p) {
    editing = p;                       // p == null → новий параметр
    const isNew = !p;
    let dtype = isNew ? 'int' : p.dtype;
    if (dtype === 'computed') dtype = 'int';   // legacy: computed більше не тип даних
    $('peTitle').textContent = isNew ? 'Новий параметр' : ('Параметр: ' + p.label);
    // новий створюється кнопкою, наявний зберігається сам
    $('peSaveBtn').textContent = isNew ? 'Створити' : 'Готово';
    if ($('peCancel')) $('peCancel').hidden = !isNew;
    clearTimeout(peTimer);
    setPeNote(isNew ? '' : 'ok');
    $('peLabel').value = isNew ? '' : (p.label || '');
    $('peShort').value = isNew ? '' : (p.short || '');
    $('peUnit').value = isNew ? '' : (p.unit || '');
    $('peSection').innerHTML = sectionOptions(isNew ? SECTIONS[0] : p.section);
    // тип: новий/власний — можна обрати; стандартний — лише показ.
    // Якщо поточний тип legacy (number/select/code) — додаємо його в список.
    const typeSel = $('peType');
    const types = ADD_DTYPES.slice();
    if (!types.includes(dtype)) types.unshift(dtype);
    typeSel.innerHTML = types
        .map((d) => `<option value="${d}"${d === dtype ? ' selected' : ''}>${DTYPE_LABEL[d] || d}</option>`).join('');
    // тип стандартних заблоковано, але адмін може змінити
    typeSel.disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peOptions').value = (!isNew && IS_LIST(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    $('peCodes').value = (!isNew && IS_COD(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    // межі й крок числового (порожні — вільний ввід)
    $('peMin').value = isNew ? '' : (p.vmin || '');
    $('peMax').value = isNew ? '' : (p.vmax || '');
    $('peStep').value = isNew ? '' : (p.vstep || '');
    // тип обчислення: обчислюване = є формула
    const fml = isNew ? '' : (p.formula || '');
    const mode = modeOf(fml);
    const computed = mode === 'computed';
    editingLegacy = computed && !fml.trim().startsWith('{');   // вбудована (age/dim…)
    $('peCompute').value = mode;
    // «з історії»: джерело · номер запису · значення чи дата
    const hc = mode === 'history' ? histCfg(fml) : {};
    fillHistSrc(hc.a || '');
    $('peHistN').value = hc.b || '-1';
    $('peHistWhat').value = hc.op || 'hist_val';
    $('peCompute').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    fillFormulaSelects();
    let cfg = { op: 'date_diff', a: '__today__', b: 'birth_date', fallback: '' };
    if (fml.trim().startsWith('{')) { try { cfg = Object.assign(cfg, JSON.parse(fml)); } catch (e) { /* ignore */ } }
    else if (LEGACY_AS_CFG[fml.trim()]) cfg = Object.assign(cfg, LEGACY_AS_CFG[fml.trim()]);
    const lbar = $('peLegacyBar');
    if (lbar) lbar.hidden = !(editingLegacy && LEGACY_AS_CFG[fml.trim()]);
    $('peOp').value = cfg.op;
    fillOperandSelects(cfg.op, cfg.a, cfg.b);
    $('peFallback').value = cfg.fallback || '';
    const oi = cfg.only_if || {};
    fillIfSelect(oi.a || '', oi.in || []);
    togglePeOpts();
    // джерело: створений/системний. Системний→створений — лише адмін
    $('peSourceStd').checked = !(isNew || !p.is_standard);
    $('peSourceStd').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peActive').checked = isNew ? true : !!p.is_active;
    // за якими значеннями шукається тварина (UIN, транспондер, чип)
    if ($('peSearch')) $('peSearch').checked = isNew ? false : !!p.searchable;
    const advBox = document.querySelector('.pp-adv');
    if (advBox) advBox.dataset.touched = '0';
    advSet(false);          // при відкритті «Розширені» завжди згорнуті
    advNote();
    $('peHint').textContent = isNew
        ? '«Тип обчислення»: Фіксоване — вводиться руками/подіями; Обчислюване — рахується формулою.'
        : (editingLegacy ? ('Обчислення: ' + (LEGACY_DESC[fml.trim()] || fml.trim()))
            : (p.is_standard && !window.canManage('herd')
                ? 'Стандартний параметр: тип змінити не можна, але можна перейменувати, змінити секцію/одиницю та вимкнути.'
                : ''));
    fillRefSelect(!isNew && (p.options || '').startsWith('@ref:') ? p.options.slice(5) : '');
    $('peDelBtn').style.display = (isNew ? false : (!p.is_standard || window.canManage('herd'))) ? '' : 'none';
    $('ppEditModal').hidden = false;
    $('peLabel').focus();
}

function fillHistSrc(want) {
    const sel = $('peHistSrc');
    if (!sel) return;
    sel.innerHTML = ANY_OPERANDS.map((o) =>
        `<option value="${escapeHtml(o.key)}">${escapeHtml(o.label)}</option>`).join('')
        || '<option value="">— спершу створіть параметр, який вводиться —</option>';
    if (want) sel.value = want;
    histHint();
}
function histHint() {
    const el = $('peHistHint');
    if (!el) return;
    const n = Math.abs(parseInt($('peHistN').value, 10) || 1);
    const nth = n === 1 ? 'останнє' : (n === 2 ? 'передостаннє' : `${n}-те з кінця`);
    el.textContent = `−1 останнє · −2 передостаннє · зараз: ${nth} внесене`;
}

function fillRefSelect(want) {
    const sel = $('peRef');
    sel.innerHTML = REFS.length
        ? REFS.map((r) => `<option value="${escapeHtml(r.key)}">`
            + `${escapeHtml(r.name)} (${r.n_active})</option>`).join('')
        : '<option value="">— довідників ще немає: створіть у вкладці «Довідники» —</option>';
    if (want) sel.value = want;
}

/* Розширені: стан панелі памʼятається; у згорнутому вигляді видно зведення. */
function advSet(open) {
    const box = document.querySelector('.pp-adv');
    if (!box) return;
    box.dataset.open = open ? '1' : '0';
    $('peAdvBody').hidden = !open;
    $('peAdvBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
}
function advNote() {
    const el = $('peAdvNote');
    if (!el) return;
    const bits = [];
    const mode = $('peCompute').value;
    if (mode === 'history') bits.push('з історії');
    else if (mode === 'computed') bits.push('формула');
    if (mode === 'fixed') {
        const lo = ($('peMin').value || '').trim(), hi = ($('peMax').value || '').trim();
        const st = ($('peStep').value || '').trim();
        if (lo || hi) bits.push(`межі ${lo || '…'}–${hi || '…'}${st ? ' крок ' + st : ''}`);
    }
    if ($('peSourceStd').checked) bits.push('системний');
    el.textContent = bits.join(' · ');
}

function togglePeOpts() {
    const dt = $('peType').value;
    const mode = $('peCompute').value;
    const computed = mode === 'computed';
    const histBox = document.querySelector('.pp-e-hist');
    if (histBox) {
        const wasHidden = histBox.hidden;
        histBox.hidden = mode !== 'history';
        if (mode === 'history') {
            if (!$('peHistSrc').options.length) fillHistSrc('');
            histHint();
            // щойно ввімкнули — показуємо блок, щоб його не шукали прокруткою
            if (wasHidden) requestAnimationFrame(() =>
                histBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
        }
    }
    // Поля вводу (списки, коди, довідник, межі) мають сенс ЛИШЕ для
    // фіксованого параметра: обчислюване й «з історії» значення не вводять.
    const typed = mode === 'fixed';
    document.querySelector('.pp-e-opts').hidden = !(IS_LIST(dt) && typed);
    document.querySelector('.pp-e-codes').hidden = !(IS_COD(dt) && typed);
    const isRef = dt === 'ref' && typed;
    document.querySelector('.pp-e-ref').hidden = !isRef;
    if (isRef && !$('peRef').options.length) fillRefSelect();
    // конструктор формули — для обчислюваних (окрім стандартних вбудованих)
    document.querySelector('.pp-e-formula').hidden = !(computed && !editingLegacy);
    advNote();
    // тип із власними налаштуваннями — показуємо їх одразу (інакше не знайти)
    if (mode !== 'fixed' && $('peAdvBody') && $('peAdvBody').hidden
        && document.querySelector('.pp-adv').dataset.touched === '1') advSet(true);
    // межі й крок — для числових, які вводяться
    const isNum = (dt === 'int' || dt === 'float' || dt === 'number') && typed;
    document.querySelector('.pp-e-range').hidden = !isNum;
    if (isNum) {
        // у цілого дробового кроку бути не може
        $('peStep').placeholder = isIntType(dt) ? 'напр. 1' : 'напр. 0,25';
        rangeHint();
    }
}

const isIntType = (dt) => dt === 'int';

// Скільки значень дасть задана градація — показуємо одразу, щоб було видно,
// що саме побачить оператор.
const RANGE_LIMIT = 60;
function rangeScale() {
    const n = (el) => {
        const v = ($(el).value || '').replace(',', '.').trim();
        if (!v) return null;
        const f = parseFloat(v);
        return isFinite(f) ? f : null;
    };
    let lo = n('peMin'), hi = n('peMax'), st = n('peStep');
    if (lo === null || hi === null || !st || st <= 0 || hi < lo) return null;
    if (isIntType($('peType').value)) {          // ціле: усе округлюємо до цілих
        lo = Math.round(lo); hi = Math.round(hi); st = Math.max(1, Math.round(st));
        if (hi < lo) return null;
    }
    const cnt = Math.round((hi - lo) / st);
    if (cnt < 1 || cnt + 1 > RANGE_LIMIT) return null;
    const s = String(st), dec = s.includes('.') ? s.split('.')[1].length : 0;
    const out = [];
    for (let i = 0; i <= cnt; i++) out.push((lo + st * i).toFixed(dec));
    return out;
}
function rangeHint() {
    const el = $('peRangeHint');
    if (!el) return;
    const stRaw = ($('peStep').value || '').replace(',', '.').trim();
    if (isIntType($('peType').value) && stRaw && !Number.isInteger(parseFloat(stRaw))) {
        el.textContent = 'Ціле число — крок теж цілий; 0,25 тут неможливий'
            + ' (для дробових балів оберіть тип «Дробове»).';
        return;
    }
    const list = rangeScale();
    if (list) {
        const show = list.length > 8
            ? list.slice(0, 5).join(' · ') + ' … ' + list[list.length - 1]
            : list.join(' · ');
        el.textContent = `Вибір зі списку (${list.length}): ${show}`;
        return;
    }
    const has = ($('peMin').value || '').trim() || ($('peMax').value || '').trim();
    el.textContent = has
        ? 'Без кроку — ввід вільний, перевіряються лише межі.'
        : (isIntType($('peType').value)
            ? 'Порожньо — будь-яке число. «1 · 4 · 1» дасть вибір 1 · 2 · 3 · 4.'
            : 'Порожньо — будь-яке число. «3 · 4 · 0,25» дасть 3.00 · 3.25 · 3.50 · 3.75 · 4.00.');
}

/* Автозбереження у вікні параметра: кнопки «Зберегти» немає, кожна зміна
   фіксується сама. Новий параметр спершу треба створити кнопкою — доти
   в нього немає id, і зберігати нічого. */
let peTimer = null, peSaving = false, peAgain = false;

function setPeNote(state) {
    const el = $('peSaved');
    if (!el) return;
    el.className = 'pe-saved ' + state;
    el.textContent = { wait: 'зміни не збережено', busy: 'збереження…',
        ok: 'збережено', bad: 'не збережено' }[state] || '';
}

function markParamDirty() {
    if (!editing) return;          // новий створюється кнопкою
    setPeNote('wait');
    clearTimeout(peTimer);
    peTimer = setTimeout(flushParam, 700);
}

async function flushParam() {
    clearTimeout(peTimer);
    if (!editing) return;
    if (peSaving) { peAgain = true; return; }
    peSaving = true; setPeNote('busy');
    await saveEdit(true);
    peSaving = false;
    if (peAgain) { peAgain = false; return flushParam(); }
}

async function saveEdit(auto) {
    const isNew = !editing;
    if (auto && isNew) return;
    const warn = (msg, el) => {
        if (auto) { setPeNote('bad'); return; }
        toast(msg, 'warn');
        if (el) el.focus();
    };
    const label = $('peLabel').value.trim();
    if (!label) { warn('Вкажіть назву', $('peLabel')); return; }
    const payload = {
        label, short: $('peShort').value.trim(),
        unit: $('peUnit').value.trim(), section: $('peSection').value,
        is_active: $('peActive').checked,
        searchable: $('peSearch') ? $('peSearch').checked : false,
    };
    // межі й крок — доступні завжди (не міняють типу даних)
    payload.vmin = $('peMin').value.trim();
    payload.vmax = $('peMax').value.trim();
    payload.vstep = $('peStep').value.trim();
    // тип даних + обчислення + джерело: для нового, власного або адміна на системному
    if (isNew || !editing.is_standard || window.canManage('herd')) {
        payload.is_standard = $('peSourceStd').checked ? 1 : 0;
        const dtype = $('peType').value;
        payload.dtype = dtype;
        const mode = $('peCompute').value;
        const computed = mode === 'computed';
        if (mode === 'history') {               // значення з історії іншого параметра
            const src = $('peHistSrc').value;
            if (!src) { warn('Оберіть параметр-джерело'); return; }
            let n = parseInt($('peHistN').value, 10);
            if (!n || isNaN(n)) n = -1;
            payload.formula = JSON.stringify(
                { op: $('peHistWhat').value, a: src, b: String(n), fallback: '' });
            payload.options = [];               // свого списку значень немає
        }
        if (!computed && mode !== 'history' && dtype === 'ref') {
            const rk = $('peRef').value;
            if (!rk) { warn('Оберіть довідник'); return; }
            payload.options = '@ref:' + rk;   // не список, а посилання на довідник
        } else if (!computed && mode !== 'history' && IS_LIST(dtype)) {
            payload.options = parseOptions(dtype, $('peOptions').value);
            if (!payload.options.length) { warn('Додайте значення списку'); return; }
        } else if (!computed && mode !== 'history' && IS_COD(dtype)) {
            payload.options = parseOptions(dtype, $('peCodes').value);
            if (!payload.options.length) { warn('Задайте коди (напр. 0-9)'); return; }
        }
        if (!editingLegacy && mode !== 'history') {   // legacy-формулу не чіпаємо
            if (computed) {
                const op = $('peOp').value, spec = opSpec(op);
                const a = slotValue('peOpA', 'peALit');
                const b = spec.b ? slotValue('peOpB', 'peBLit') : '';
                if (!a || (spec.b && !b)) { warn('Заповніть операнди'); return; }
                const cond = ifConfig();
                const out = { op, a, b, fallback: $('peFallback').value.trim() };
                if (cond) out.only_if = cond;
                payload.formula = JSON.stringify(out);
            } else {
                payload.formula = '';   // фіксоване — очищаємо формулу
            }
        }
    }
    const url = isNew ? '/api/herd/params' : ('/api/herd/params/' + editing.id);
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) {
        if (auto) { setPeNote('bad'); toast(r.error || 'Не збережено', 'error'); return; }
        toast(r.error || 'Помилка', 'error'); return;
    }
    if (auto) {
        // вікно лишається відкритим; список під ним оновлюємо тихо
        Object.assign(editing, payload);
        setPeNote('ok');
        load();
        return;
    }
    $('ppEditModal').hidden = true;
    toast(isNew ? 'Додано' : 'Збережено', 'success');
    load();
}

async function delEdit() {
    if (!editing) return;
    if (editing.is_standard && !window.canManage('herd')) return;
    if (!(await confirmAction(`Видалити параметр «${editing.label}» і всі його значення?`, { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/params/' + editing.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('ppEditModal').hidden = true;
    load();
}

async function delParam(p) {
    if (!p) return;
    if (p.is_standard && !window.canManage('herd')) {
        toast('Стандартний параметр може видалити лише адміністратор', 'warn');
        return;
    }
    const warn = p.is_standard ? ' (СТАНДАРТНИЙ!)' : '';
    if (!(await confirmAction(`Видалити параметр «${p.label}»${warn} і всі його значення?`, { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/params/' + p.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Видалено', 'success');
    load();
}

/* ---------- переміщення / вкл-викл ---------- */
async function moveParam(id, dir) {
    const i = PARAMS.findIndex((p) => String(p.id) === String(id));
    const j = dir === 'up' ? i - 1 : i + 1;
    if (i < 0 || j < 0 || j >= PARAMS.length) return;
    const arr = PARAMS.slice();
    [arr[i], arr[j]] = [arr[j], arr[i]];
    PARAMS = arr;
    render(filteredParams());   // оптимістично
    await apiSend('/api/herd/params/reorder', 'POST', { order: arr.map((p) => p.id) });
}

async function toggleActive(id, checked) {
    const r = await apiSend('/api/herd/params/' + id, 'POST', { is_active: checked });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); load(); return; }
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (p) p.is_active = checked ? 1 : 0;
    render(filteredParams());
}

/* ---------- події таблиці ---------- */
$('ppBody').addEventListener('click', (e) => {
    const row = e.target.closest('.pp-row'); if (!row) return;
    const id = row.dataset.id; const act = e.target.dataset.act;
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (act === 'edit') { if (p) openEdit(p); }
    else if (act === 'up' || act === 'down') moveParam(id, act);
    else if (act === 'del') delParam(p);
    // клік будь-де по рядку (окрім кнопок/галочки) — відкрити редагування
    else if (!e.target.closest('button, input') && p) openEdit(p);
});
$('ppBody').addEventListener('change', (e) => {
    if (e.target.dataset.act === 'toggle') {
        toggleActive(e.target.closest('.pp-row').dataset.id, e.target.checked);
    }
});

/* ---------- ініт ---------- */
$('peCompute').addEventListener('change', () => {
    const box = document.querySelector('.pp-adv');
    if (box) box.dataset.touched = '1';       // зміна типу людиною → показати блок
});
$('peAdvBtn').addEventListener('click', () =>
    advSet(document.querySelector('.pp-adv').dataset.open !== '1'));
['peMin', 'peMax', 'peStep', 'peSourceStd', 'peCompute'].forEach((id) => {
    const el = $(id);
    if (el) ['input', 'change'].forEach((ev) => el.addEventListener(ev, advNote));
});
if ($('peLegacyEdit')) $('peLegacyEdit').addEventListener('click', () => {
    // вбудована формула переїжджає в конструктор: видно, як рахується, і можна змінити
    editingLegacy = false;
    $('peLegacyBar').hidden = true;
    advSet(true);
    $('peHint').textContent = 'Формула розібрана на операцію й операнди — змінюйте як завгодно.';
    togglePeOpts();
    const box = document.querySelector('.pp-e-formula');
    if (box) requestAnimationFrame(() => box.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
    markParamDirty();
});
$('peType').addEventListener('change', togglePeOpts);
['peMin', 'peMax', 'peStep'].forEach((id) =>
    $(id).addEventListener('input', rangeHint));   // підказка оновлюється на очах
['peHistSrc', 'peHistN', 'peHistWhat'].forEach((id) => {
    const el = $(id);
    if (el) ['input', 'change'].forEach((ev) => el.addEventListener(ev, histHint));
});
$('peCompute').addEventListener('change', togglePeOpts);
$('peOp').addEventListener('change', () => fillOperandSelects($('peOp').value));
$('peOpA').addEventListener('change', () => {
    $('peALit').hidden = $('peOpA').value !== '__literal__';
    if (['code_label', 'list_pos'].includes($('peOp').value)) codeLabelHint();
});
$('peOpB').addEventListener('change', () => { $('peBLit').hidden = $('peOpB').value !== '__literal__'; });
if ($('peIfA')) $('peIfA').addEventListener('change', () => renderIfVals($('peIfA').value, []));
if ($('ppSearch')) $('ppSearch').addEventListener('input', (e) => {
    ppQuery = e.target.value || ''; render(filteredParams());
});
$('ppAddBtn').addEventListener('click', () => openEdit(null));
// та сама дія з шапки панелі — кругле «+» унизу списку помітне не всім
if ($('ppAddBtn2')) $('ppAddBtn2').addEventListener('click', () => openEdit(null));
$('peSaveBtn').addEventListener('click', async () => {
    if (editing) { await flushParam(); $('ppEditModal').hidden = true; return; }
    await saveEdit(false);          // новий параметр створюється явно
});
// будь-яка зміна у вікні фіксується сама (для вже створеного параметра)
['input', 'change'].forEach((evt) =>
    $('ppEditModal').addEventListener(evt, (e) => {
        if (e.target.closest('.actions')) return;
        markParamDirty();
    }));
$('peDelBtn').addEventListener('click', delEdit);
document.querySelectorAll('#ppEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('ppEditModal').hidden = true; }));
if ($('ppTable')) load();   // запускаємось лише за наявності розмітки
})();
