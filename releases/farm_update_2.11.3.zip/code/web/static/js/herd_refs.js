/* Довідники значень стада: спільні списки (бики-плідники, причини вибуття…),
   з яких обирають параметри типу «Довідник». Значення можна деактивувати —
   у нових подіях воно не пропонується, а вже внесене лишається як було.
   Модуль в IIFE і стартує лише за наявності своєї розмітки. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let REFS = [];
// Джерело людей одне — спільний список «Ветеринари» (слово Романа
// 2026-09-16: «тільки із ветеринарів і свій список, і все»).
let VET_KEY = 'vet';
let VET_NAME = 'Ветеринари';
let openRef = 0;          // розкритий довідник

async function load() {
    const r = await apiGet('/api/herd/refs');
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    REFS = r.refs || [];
    const src = (r.sources || [])[0];
    if (src) { VET_KEY = src.key; VET_NAME = src.name; }
    render();
    document.dispatchEvent(new CustomEvent('herd-refs-changed'));
}

function render() {
    $('rfCount').textContent = REFS.length ? '· ' + REFS.length : '';
    if (!REFS.length) {
        $('rfList').innerHTML = '<p class="hp-empty">Довідників ще немає — '
            + 'створіть перший, наприклад «Бики-плідники»</p>';
        return;
    }
    $('rfList').innerHTML = REFS.map((rf) => {
        const open = rf.id === openRef;
        const items = rf.items || [];
        const used = (rf.used_by || []).length
            ? `використовує: ${rf.used_by.map(escapeHtml).join(', ')}`
            : 'поки не використовується жодним параметром';
        return `<div class="rf-item${open ? ' is-open' : ''}" data-id="${rf.id}">
            <div class="rf-head">
                <span class="rf-chev">${open ? '▾' : '▸'}</span>
                <span class="rf-name">${escapeHtml(rf.name)}</span>
                <span class="rf-meta">${rf.n_active} з ${rf.n_items} активні · ${used}</span>
                <button type="button" class="rf-del" data-del="${rf.id}"
                        title="Прибрати довідник">−</button>
            </div>
            ${open ? `<div class="rf-body">
                <div class="rf-src">
                    <span>Що в довіднику:</span>
                    <select class="rf-in rf-srcsel" data-ref="${rf.id}">
                        <option value=""${!rf.src_key ? ' selected' : ''}>власні значення</option>
                        <option value="${VET_KEY}"${rf.src_key ? ' selected' : ''}>
                            люди зі списку «${escapeHtml(VET_NAME)}»</option>
                    </select>
                    ${rf.src_key ? '<span class="rf-srchint">познач, хто входить у цей довідник — '
                        + 'одна людина може бути в кількох</span>' : ''}
                </div>

                ${rf.src_key ? `<div class="rf-pick">${
                    (rf.candidates || []).length
                        ? rf.candidates.map((c) => `
                            <label class="rf-p${c.on ? ' on' : ''}">
                                <input type="checkbox" class="rf-pon" data-src="${c.id}"
                                       data-ref="${rf.id}"${c.on ? ' checked' : ''}>
                                <b>${escapeHtml(c.label || c.code)}</b>
                                ${c.note ? `<span class="rf-pnote">${escapeHtml(c.note)}</span>` : ''}
                            </label>`).join('')
                        : '<p class="hp-empty">Спільний список порожній — заповніть вкладку «' + escapeHtml(VET_NAME) + '»</p>'
                }</div>` : `
                <table class="hp-tbl rf-tbl">
                    <thead><tr>
                        <th>Код</th><th>Значення</th><th>Примітка</th>
                        <th class="c">Активне</th><th class="c"></th>
                    </tr></thead>
                    <tbody>${items.length ? items.map((it) => `
                        <tr data-item="${it.id}" class="${it.is_active ? '' : 'is-off'}">
                            <td><input type="text" class="rf-in rf-code" value="${escapeHtml(it.code || '')}"
                                       placeholder="—"></td>
                            <td><input type="text" class="rf-in rf-label" value="${escapeHtml(it.label || '')}"></td>
                            <td><input type="text" class="rf-in rf-note" value="${escapeHtml(it.note || '')}"
                                       placeholder="лінія, походження…"></td>
                            <td class="c"><input type="checkbox" class="rf-on"${it.is_active ? ' checked' : ''}></td>
                            <td class="c"><button type="button" class="eb-x" data-idel="${it.id}"
                                    title="Видалити значення">✕</button></td>
                        </tr>`).join('')
                        : '<tr><td colspan="5" class="hp-empty">Значень ще немає</td></tr>'}
                    </tbody>
                </table>
                <div class="rf-newrow">
                    <input type="text" class="rf-in rf-ncode" placeholder="код">
                    <input type="text" class="rf-in rf-nlabel" placeholder="нове значення">
                    <button type="button" class="btn btn-ghost btn-sm rf-iadd" data-add="${rf.id}">+ Додати</button>
                </div>`}
            </div>` : ''}
        </div>`;
    }).join('');
    bind();
}

function bind() {
    const box = $('rfList');
    // звідки довідник бере значення: свій список чи підбірка зі спільного
    box.querySelectorAll('.rf-srcsel').forEach((sel) => sel.addEventListener('change', async () => {
        const r = await apiSend('/api/herd/refs/' + sel.dataset.ref, 'POST',
            { src_key: sel.value });
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }));
    // хто входить у підбірку
    box.querySelectorAll('.rf-pon').forEach((c) => c.addEventListener('change', async () => {
        c.closest('.rf-p').classList.toggle('on', c.checked);
        const r = await apiSend('/api/herd/ref-pick', 'POST',
            { ref_id: +c.dataset.ref, src_item_id: +c.dataset.src, on: c.checked });
        if (!r || !r.ok) {
            toast((r && r.error) || 'Не збережено', 'error');
            c.checked = !c.checked;
            c.closest('.rf-p').classList.toggle('on', c.checked);
        }
    }));
    box.querySelectorAll('.rf-head').forEach((h) => h.addEventListener('click', (e) => {
        if (e.target.closest('.rf-del')) return;
        const id = +h.closest('.rf-item').dataset.id;
        openRef = (openRef === id) ? 0 : id;
        render();
    }));
    box.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
        const rf = REFS.find((x) => x.id === +b.dataset.del);
        if (!(await confirmAction(`Прибрати довідник «${rf.name}» разом зі значеннями?`, { ok: 'Прибрати' }))) return;
        const r = await apiSend('/api/herd/refs/' + rf.id, 'DELETE');
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        toast('Довідник прибрано', 'success');
        load();
    }));
    box.querySelectorAll('[data-idel]').forEach((b) => b.addEventListener('click', async () => {
        const r = await apiSend('/api/herd/ref-items/' + b.dataset.idel, 'DELETE');
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }));
    box.querySelectorAll('[data-add]').forEach((b) => b.addEventListener('click', async () => {
        const row = b.closest('.rf-newrow');
        const label = row.querySelector('.rf-nlabel').value.trim();
        const code = row.querySelector('.rf-ncode').value.trim();
        if (!label && !code) { row.querySelector('.rf-nlabel').focus(); return; }
        const r = await apiSend('/api/herd/ref-items', 'POST',
            { ref_id: +b.dataset.add, code, label });
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }));
    // Enter у полі нового значення = натиснути «Додати»
    box.querySelectorAll('.rf-nlabel, .rf-ncode').forEach((inp) =>
        inp.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') e.target.closest('.rf-newrow').querySelector('.rf-iadd').click();
        }));
    // правки значень зберігаються самі
    box.querySelectorAll('tr[data-item]').forEach((tr) => {
        const id = +tr.dataset.item;
        let t = null;
        const save = (extra) => {
            clearTimeout(t);
            t = setTimeout(async () => {
                const body = Object.assign({
                    id,
                    code: tr.querySelector('.rf-code').value.trim(),
                    label: tr.querySelector('.rf-label').value.trim(),
                    note: tr.querySelector('.rf-note').value.trim(),
                }, extra || {});
                const r = await apiSend('/api/herd/ref-items', 'POST', body);
                if (!r || !r.ok) toast((r && r.error) || 'Не збережено', 'error');
                else document.dispatchEvent(new CustomEvent('herd-refs-changed'));
            }, 600);
        };
        tr.querySelectorAll('.rf-in').forEach((i) => i.addEventListener('input', () => save()));
        tr.querySelector('.rf-on').addEventListener('change', (e) => {
            tr.classList.toggle('is-off', !e.target.checked);
            save({ is_active: e.target.checked });
        });
    });
}

/* Новий довідник — одразу з відповіддю на головне питання: це перелік
   людей із спільного списку («Ветеринари») чи власні значення
   (бики-плідники, причини вибуття). Роман 2026-09-16: «при створенні
   довідника потрібно вказати, чи це список ветеринарів, чи інше». */
function openNewRef() {
    const m = $('rfNewModal');
    $('rfNewName').value = '';
    $('rfNewPeople').textContent = `Люди зі списку «${VET_NAME}»`;
    m.querySelectorAll('#rfNewKind .seg-btn').forEach((b, i) =>
        b.classList.toggle('is-active', i === 0));
    m.hidden = false;
    setTimeout(() => $('rfNewName').focus(), 30);
}

function newRefKind() {
    const on = $('rfNewKind').querySelector('.seg-btn.is-active');
    return on ? on.dataset.kind : 'own';
}

async function saveNewRef() {
    const name = $('rfNewName').value.trim();
    if (!name) { $('rfNewName').focus(); return; }
    const src = newRefKind() === 'people' ? VET_KEY : '';
    const r = await apiSend('/api/herd/refs', 'POST', { name, src_key: src });
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    $('rfNewModal').hidden = true;
    openRef = r.id;
    toast(`Довідник «${r.name}» створено`, 'success');
    load();
}

$('rfAdd').addEventListener('click', openNewRef);
$('rfNewSave').addEventListener('click', saveNewRef);
$('rfNewName').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveNewRef(); });
$('rfNewKind').addEventListener('click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (!b) return;
    $('rfNewKind').querySelectorAll('.seg-btn').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
});
$('rfNewModal').querySelectorAll('[data-close]').forEach((x) =>
    x.addEventListener('click', () => { $('rfNewModal').hidden = true; }));

if ($('rfList')) load();
})();
