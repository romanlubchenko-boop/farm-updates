/* Фільтри тварин, які людина збирає сама (спільні для групового вводу й
   календаря). Кожен фільтр — {key, op, v, v2, vals}:
     списки — op «=»/«≠» + vals:[…];
     числа й дати — op = ≠ > ≥ < ≤ «між» + v (і v2 для «між»);
     текст — op «містить» = ≠ + v;
     будь-який — «порожньо» / «не порожньо».
   Старі фільтри {from, to} / {text} читаються як «між» / «містить».

   window.herdFilters({
       listEl, addBtn,
       params:  () => [...],      // параметри тварини з конструктора
       choices: () => {key:[{value,label}]},
       animals: () => [...],      // тварини з p/pl — для варіантів «з самих тварин»
       filters: () => [...],      // масив фільтрів (змінюється на місці)
       onChange: (kind, key) => {} // 'value' | 'add' | 'remove'
   }) → { render, passes(a, fl), passesAll(a), close } */
'use strict';
(function () {

const norm = (s) => String(s || '').toLowerCase().replace(/[\s ]+/g, '');

function place(pop, anchor) {
    const r = anchor.getBoundingClientRect();
    pop.style.top = `${window.scrollY + r.bottom + 4}px`;
    const left = Math.min(window.scrollX + r.left,
        window.scrollX + document.documentElement.clientWidth - pop.offsetWidth - 12);
    pop.style.left = `${Math.max(8, left)}px`;
}
function closePop() { document.querySelectorAll('.hf-pop.hf-flt').forEach((x) => x.remove()); }

window.herdFilters = function (o) {
    const paramOf = (key) => (o.params() || []).find((x) => x.key === key) || null;
    const CH = () => o.choices() || {};
    const isList = (pr) => (CH()[pr.key] || []).length > 0 || pr.key === 'group'
        || ['cod', 'code', 'ref', 'list'].includes(pr.dtype);
    const isNum = (pr) => ['int', 'float'].includes(pr.dtype);
    const isDate = (pr) => pr.dtype === 'date';
    const changed = (kind, key) => { if (o.onChange) o.onChange(kind, key); };

    /* варіанти: секції — з самих тварин, решта — з конструктора; плюс «не вказано» */
    function choicesOf(pr) {
        const animals = o.animals() || [];
        let out;
        if (pr.key === 'group') {
            // секції — у порядку конструктора, далі ті, що є лише в тварин
            out = (CH()[pr.key] || []).map((c) => ({ value: String(c.value), label: c.label }));
            const known = new Set(out.map((c) => c.value));
            [...new Set(animals.map((a) => String((a.p || {}).group || '')).filter((n) => n && !known.has(n)))]
                .sort((x, y) => x.localeCompare(y, 'uk')).forEach((n) => out.push({ value: n, label: n }));
        } else {
            out = (CH()[pr.key] || []).map((c) => ({ value: String(c.value), label: c.label }));
            const known = new Set(out.map((c) => c.value));
            animals.forEach((a) => {
                const v = String((a.p || {})[pr.key] ?? '');
                if (v && !known.has(v)) {
                    known.add(v);
                    out.push({ value: v, label: (a.pl || {})[pr.key] || v });
                }
            });
        }
        out.push({ value: '', label: '— не вказано' });
        return out;
    }

    const OPS_NUM = [['eq', '='], ['ne', '≠'], ['gt', '>'], ['ge', '≥'], ['lt', '<'], ['le', '≤'],
        ['between', 'між'], ['empty', 'порожньо'], ['nempty', 'не порожньо']];
    const OPS_TEXT = [['has', 'містить'], ['eq', '='], ['ne', '≠'], ['empty', 'порожньо'], ['nempty', 'не порожньо']];
    const OPS_LIST = [['eq', '='], ['ne', '≠'], ['empty', 'порожньо'], ['nempty', 'не порожньо']];
    const NOVAL = ['empty', 'nempty'];
    /* старий запис {from,to}/{text} → op/v */
    function norm1(fl, pr) {
        if (fl.op) return fl;
        if (fl.from || fl.to) {
            if (fl.from && fl.to) { fl.op = 'between'; fl.v = fl.from; fl.v2 = fl.to; }
            else if (fl.from) { fl.op = 'ge'; fl.v = fl.from; } else { fl.op = 'le'; fl.v = fl.to; }
            delete fl.from; delete fl.to;
        } else if (fl.text) {
            fl.op = 'has'; fl.v = fl.text; delete fl.text;
        } else {
            fl.op = pr && isList(pr) ? 'eq' : (pr && (isNum(pr) || isDate(pr)) ? 'ge' : 'has');
        }
        return fl;
    }
    const active = (fl) => NOVAL.includes(fl.op) || (fl.vals && fl.vals.length)
        || (fl.v !== undefined && fl.v !== '') || fl.from || fl.to || fl.text;

    function listSummary(fl, pr) {
        if (!fl.vals || !fl.vals.length) return 'усі';
        const lbl = new Map(choicesOf(pr).map((c) => [c.value, c.label]));
        const names = fl.vals.map((v) => lbl.get(v) || v);
        return names.length > 2 ? `${names.slice(0, 2).join(', ')} +${names.length - 2}` : names.join(', ');
    }

    function render() {
        const FL = o.filters();
        o.listEl.innerHTML = FL.map((fl, i) => {
            const pr = paramOf(fl.key);
            if (!pr) return '';
            norm1(fl, pr);
            const ops = isList(pr) ? OPS_LIST : ((isNum(pr) || isDate(pr)) ? OPS_NUM : OPS_TEXT);
            const opSel = `<select class="hf-op" data-i="${i}" title="Умова">${ops.map(([k, t]) =>
                `<option value="${k}"${k === fl.op ? ' selected' : ''}>${t}</option>`).join('')}</select>`;
            let val = '', listBox = '';
            if (!NOVAL.includes(fl.op)) {
                if (isList(pr)) {
                    // варіанти одразу галочками (Роман: «групи краще вибирати галочкою»)
                    const on = new Set(fl.vals || []);
                    val = `<span class="hf-cnt">${on.size ? `обрано ${on.size}` : 'усі'}</span>`;
                    listBox = `<div class="hf-checks" data-i="${i}">${choicesOf(pr).map((c) =>
                        `<label class="hf-ck${on.has(c.value) ? ' on' : ''}"><input type="checkbox" value="${escapeHtml(c.value)}"${on.has(c.value) ? ' checked' : ''}>${escapeHtml(c.label)}</label>`).join('')}</div>`;
                } else if (isNum(pr) || isDate(pr)) {
                    const t = isDate(pr) ? 'date' : 'number';
                    const step = pr.dtype === 'float' ? ' step="any"' : '';
                    val = `<input type="${t}"${step} class="hf-in" data-i="${i}" data-f="v" value="${escapeHtml(fl.v || '')}">`
                        + (fl.op === 'between' ? `<i>–</i><input type="${t}"${step} class="hf-in" data-i="${i}" data-f="v2" value="${escapeHtml(fl.v2 || '')}">` : '');
                } else {
                    val = `<input type="text" class="hf-in hf-text" data-i="${i}" data-f="v" value="${escapeHtml(fl.v || '')}">`;
                }
            }
            const body = `<span class="hf-range">${opSel}${val}</span>`;
            return `<div class="hf${active(fl) ? ' is-on' : ''}${isDate(pr) ? ' is-date' : ''}${listBox ? ' is-list' : ''}" data-i="${i}">
                <div class="hf-head"><span>${escapeHtml(pr.label)}${pr.unit ? `, ${escapeHtml(pr.unit)}` : ''}</span>
                    <button type="button" class="hf-x" data-i="${i}" title="Прибрати фільтр">✕</button></div>
                ${body}${listBox}</div>`;
        }).join('');

        o.listEl.querySelectorAll('.hf-x').forEach((b) => b.addEventListener('click', () => {
            const [gone] = FL.splice(+b.dataset.i, 1);
            render();
            changed('remove', gone && gone.key);
        }));
        o.listEl.querySelectorAll('.hf-in').forEach((inp) => inp.addEventListener('input', () => {
            const fl = FL[+inp.dataset.i];
            fl[inp.dataset.f] = inp.value.trim();
            if (!fl[inp.dataset.f]) delete fl[inp.dataset.f];
            inp.closest('.hf').classList.toggle('is-on', !!active(fl));
            changed('value', fl.key);
        }));
        o.listEl.querySelectorAll('.hf-op').forEach((sel) => sel.addEventListener('change', () => {
            const fl = FL[+sel.dataset.i];
            fl.op = sel.value;
            if (NOVAL.includes(fl.op)) { delete fl.v; delete fl.v2; delete fl.vals; }
            if (fl.op !== 'between') delete fl.v2;
            render();
            changed('value', fl.key);
        }));
        o.listEl.querySelectorAll('.hf-checks').forEach((box) => box.addEventListener('change', () => {
            const fl = FL[+box.dataset.i];
            fl.vals = [...box.querySelectorAll('input:checked')].map((x) => x.value);
            if (!fl.vals.length) delete fl.vals;
            box.querySelectorAll('.hf-ck').forEach((l) => l.classList.toggle('on', l.querySelector('input').checked));
            const card = box.closest('.hf');
            card.classList.toggle('is-on', !!active(fl));
            card.querySelector('.hf-cnt').textContent = fl.vals ? `обрано ${fl.vals.length}` : 'усі';
            changed('value', fl.key);
        }));
        o.listEl.querySelectorAll('.hf-pick').forEach((b) => b.addEventListener('click', (e) => {
            e.stopPropagation();
            openValues(b);
        }));
    }

    function openValues(btn) {
        closePop();
        const fl = o.filters()[+btn.dataset.i];
        const pr = paramOf(fl.key);
        const on = new Set(fl.vals || []);
        const pop = document.createElement('div');
        pop.className = 'hf-pop hf-flt';
        pop.innerHTML = `<div class="hf-poplist">${choicesOf(pr).map((c) => `
            <label class="hf-opt"><input type="checkbox" value="${escapeHtml(c.value)}"${on.has(c.value) ? ' checked' : ''}>
                <span>${escapeHtml(c.label)}</span></label>`).join('')}</div>
            <div class="hf-popfoot"><button type="button" class="hg-mini" data-a="none">скинути</button></div>`;
        document.body.appendChild(pop);
        place(pop, btn);
        const apply = () => {
            fl.vals = [...pop.querySelectorAll('input:checked')].map((x) => x.value);
            if (!fl.vals.length) delete fl.vals;
            btn.textContent = listSummary(fl, pr);
            btn.closest('.hf').classList.toggle('is-on', !!active(fl));
            changed('value', fl.key);
        };
        pop.addEventListener('change', apply);
        pop.querySelector('[data-a="none"]').addEventListener('click', () => {
            pop.querySelectorAll('input').forEach((x) => { x.checked = false; });
            apply();
        });
    }

    /* «+ фільтр»: параметри з пошуком, згруповані за секціями конструктора */
    function openAdd() {
        closePop();
        const used = new Set(o.filters().map((f) => f.key));
        const pop = document.createElement('div');
        pop.className = 'hf-pop hf-flt hf-addpop';
        pop.innerHTML = `<input type="search" class="hf-q" placeholder="пошук параметра…">
            <div class="hf-poplist"></div>`;
        document.body.appendChild(pop);
        place(pop, o.addBtn);
        const listEl = pop.querySelector('.hf-poplist');
        const draw = () => {
            const q = norm(pop.querySelector('.hf-q').value);
            const avail = (o.params() || []).filter((pr) => !used.has(pr.key) && pr.key !== 'tag'
                && (!q || norm(`${pr.label} ${pr.short || ''}`).includes(q)));
            const bySec = new Map();
            avail.forEach((pr) => {
                const sec = pr.section || 'Інше';
                if (!bySec.has(sec)) bySec.set(sec, []);
                bySec.get(sec).push(pr);
            });
            listEl.innerHTML = avail.length ? [...bySec.entries()].map(([sec, arr]) =>
                `<div class="hf-sec">${escapeHtml(sec)}</div>` + arr.map((pr) =>
                    `<button type="button" class="hf-add" data-k="${escapeHtml(pr.key)}">${escapeHtml(pr.label)}`
                    + `${pr.formula ? '<i>обчислюється</i>' : ''}</button>`).join('')).join('')
                : '<div class="hf-none">Нічого не знайдено</div>';
            listEl.querySelectorAll('.hf-add').forEach((b) => b.addEventListener('click', () => {
                o.filters().push({ key: b.dataset.k });
                closePop();
                render();
                changed('add', b.dataset.k);
            }));
        };
        pop.querySelector('.hf-q').addEventListener('input', draw);
        draw();
        setTimeout(() => pop.querySelector('.hf-q').focus(), 20);
    }

    if (o.addBtn) {
        o.addBtn.addEventListener('click', (e) => { e.stopPropagation(); openAdd(); });
    }
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.hf-pop') && !e.target.closest('.hf-pick')
            && !(o.addBtn && o.addBtn.contains(e.target))) closePop();
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePop(); });

    function passes(a, fl) {
        const pr = paramOf(fl.key);
        if (!pr) return true;
        norm1(fl, pr);
        const raw = (a.p || {})[fl.key];
        const v = raw === null || raw === undefined ? '' : String(raw);
        const op = fl.op;
        if (op === 'empty') return v === '';
        if (op === 'nempty') return v !== '';
        if (isList(pr)) {
            if (!fl.vals || !fl.vals.length) return true;
            return op === 'ne' ? !fl.vals.includes(v) : fl.vals.includes(v);
        }
        if (fl.v === undefined || fl.v === '') return true;          // значення не задано — не відсіює
        if (isNum(pr) || isDate(pr)) {
            if (v === '') return op === 'ne';
            let x, a1, a2;
            if (isDate(pr)) { x = v.slice(0, 10); a1 = String(fl.v); a2 = String(fl.v2 || ''); }
            else {
                x = parseFloat(v.replace(',', '.'));
                a1 = parseFloat(String(fl.v).replace(',', '.'));
                a2 = parseFloat(String(fl.v2 || '').replace(',', '.'));
                if (!isFinite(x) || !isFinite(a1)) return op === 'ne';
            }
            switch (op) {
                case 'eq': return x === a1;
                case 'ne': return x !== a1;
                case 'gt': return x > a1;
                case 'ge': return x >= a1;
                case 'lt': return x < a1;
                case 'le': return x <= a1;
                case 'between': return x >= a1 && ((isDate(pr) ? !a2 : !isFinite(a2)) || x <= a2);
                default: return true;
            }
        }
        const hay = norm(`${v} ${(a.pl || {})[fl.key] || ''}`), needle = norm(fl.v);
        if (op === 'eq') return norm(v) === needle || norm((a.pl || {})[fl.key] || '') === needle;
        if (op === 'ne') return norm(v) !== needle && norm((a.pl || {})[fl.key] || '') !== needle;
        return hay.includes(needle);
    }

    return {
        render, passes, close: closePop,
        passesAll: (a) => (o.filters() || []).every((fl) => passes(a, fl)),
    };
};
})();
