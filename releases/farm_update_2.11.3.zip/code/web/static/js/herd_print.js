/* Друк на A4 з попереднім переглядом — спільний для гілки стада
   (календар, «Робота зі стадом»). Рядки розкладаються по аркушах так само,
   як ляжуть на папір: висоту рядків міряємо в самій рамці перегляду, шапка
   таблиці повторюється в кожній колонці, назва групи не лишається сама
   внизу, продовження групи підписується «(продовження)».

   herdPrint.open({
       state:   { orient: 'p'|'l', twocol: bool,     // модуль читає й пише сюди
                  font: {family, size, bold, italic} },
       content: () => ({ title, sub, legend, body }), // body — h2/table-розмітка
       twocolToggle: bool,                            // перемикач «1 / 2 колонки» у смужці
       onChange: () => {},                            // після зміни orient/twocol
   }) */
'use strict';

(function () {
    const TWO_GAP_MM = 6;                                   // проміжок між колонками друку
    const esc = (s) => String(s === null || s === undefined ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

    const PRINT_CSS = `
    body{margin:0;background:#8a8f98;font-family:'IBM Plex Sans',Arial,sans-serif;font-size:12px;color:#000}
    .sheet{background:#fff;margin:14px auto;box-shadow:0 2px 10px rgba(0,0,0,.35);box-sizing:border-box;
        padding:10mm 10mm 8mm;overflow:hidden;position:relative}
    .sheet.p{width:210mm;height:297mm}.sheet.l{width:297mm;height:210mm}
    .pn{position:absolute;right:10mm;bottom:2.5mm;font-size:10px;color:#666}
    .over{position:absolute;top:0;bottom:0;border-left:2px dashed #c2333a}
    h1{font-size:14px;margin:0 0 6px}
    .two{display:flex;align-items:flex-start}
    .two .col{flex:1 1 0;min-width:0;padding-right:var(--g)}
    .two .col+.col{padding:0 0 0 var(--g)}
    h1 .sub{display:block;font-size:12.5px;font-weight:600;margin-top:2px}
    h1 .sub:empty{display:none}
    h1 .leg{display:block;font-size:12.5px;margin-top:8px}
    h1 .leg.thin,h1 .leg .thin{font-weight:400}
    h2{font-size:12.5px;margin:10px 0 4px;color:#000}
    table{border-collapse:collapse;table-layout:fixed}
    th,td{border:1px solid #999;padding:2px 5px;text-align:left;vertical-align:top;overflow:hidden;
        text-overflow:ellipsis;word-wrap:break-word}
    th{font-size:.85em;text-transform:uppercase;background:#eee}
    th .cl-rz,th .col-resizer{display:none}
    td.num,th.num{text-align:right}
    tr.sec td{background:#f3f3f3;font-weight:600;font-size:.85em}
    tr.tot td{font-weight:700;border-top:2px solid #777}
    a{color:#000;text-decoration:none;font-weight:700}
    .cl-over,.cl-today{margin-left:4px;font-size:.9em}
    td.cl-mk{text-align:center;padding:2px 0;font-weight:400;font-size:.85em;color:#c2333a}
    #measure{position:absolute;left:-10000px;top:0}
    @media print{
        body{background:#fff}
        .sheet{margin:0;box-shadow:none;page-break-after:always;break-after:page}
        .sheet:last-child{page-break-after:auto;break-after:auto}
        .over{display:none}
        .sheet.p{height:296mm}.sheet.l{height:209mm}   /* запас, щоб не з'являвся порожній аркуш */
    }`;

    let box = null;         // модал (створюється один раз на сторінку)
    let cur = null;         // поточні налаштування виклику
    let seq = 0;            // лічильник перемальовувань: пізній виклик скасовує ранній

    function ensureBox() {
        if (box) return box;
        box = document.createElement('div');
        box.className = 'cl-prev';
        box.id = 'hpvModal';
        box.hidden = true;
        box.innerHTML = `<div class="cl-prevbox">
            <div class="cl-prevbar">
                <b id="hpvTitle"></b>
                <span class="cl-previnfo" id="hpvInfo"></span>
                <span class="hp-sp"></span>
                <label class="cl-prevf"><span>Шрифт</span>
                    <select id="hpvFamily">
                        <option value="">Як у програмі</option>
                        <option value="Arial">Arial</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Courier New">Courier New</option>
                    </select></label>
                <label class="cl-prevf"><span>Розмір</span>
                    <select id="hpvSize"></select></label>
                <label class="cl-prevf"><span>Масштаб</span>
                    <select id="hpvScale" title="Зменшує весь вміст, щоб умістити в аркуш"></select></label>
                <span class="cl-prevpair">
                    <button type="button" id="hpvBold" title="Жирний"><b>Ж</b></button>
                    <button type="button" id="hpvItalic" title="Курсив"><i>К</i></button>
                </span>
                <span class="segmented" id="hpvTwo" hidden>
                    <button type="button" class="seg-btn" data-c="0" title="Таблиця однією колонкою">1 колонка</button>
                    <button type="button" class="seg-btn" data-c="1" title="Таблиця двома половинами поруч">2 колонки</button>
                </span>
                <span class="segmented" id="hpvOrient">
                    <button type="button" class="seg-btn" data-o="p">Книжковий</button>
                    <button type="button" class="seg-btn" data-o="l">Альбомний</button>
                </span>
                <button type="button" class="btn btn-sm btn-primary" id="hpvPrint">🖨 Друкувати</button>
                <button type="button" class="btn btn-sm" id="hpvClose">Закрити</button>
            </div>
            <div class="cl-prevwarn" id="hpvWarn" hidden></div>
            <iframe id="hpvFrame" class="cl-prevframe" title="Попередній перегляд"></iframe>
        </div>`;
        document.body.appendChild(box);
        const $ = (id) => box.querySelector('#' + id);
        $('hpvOrient').addEventListener('click', (e) => {
            const b = e.target.closest('[data-o]');
            if (!b || !cur) return;
            cur.state.orient = b.dataset.o;
            if (cur.onChange) cur.onChange();
            render();
        });
        $('hpvTwo').addEventListener('click', (e) => {
            const b = e.target.closest('[data-c]');
            if (!b || !cur) return;
            cur.state.twocol = b.dataset.c === '1';
            if (cur.onChange) cur.onChange();
            render();
        });
        const setFont = (k, v) => {
            if (!cur) return;
            cur.state.font = Object.assign({}, cur.state.font || {}, { [k]: v });
            if (cur.onChange) cur.onChange();
            render();
        };
        $('hpvScale').addEventListener('change', () => {
            if (!cur) return;
            cur.state.scale = +$('hpvScale').value || 100;
            if (cur.onChange) cur.onChange();
            render();
        });
        $('hpvFamily').addEventListener('change', () => setFont('family', $('hpvFamily').value));
        $('hpvSize').addEventListener('change', () => setFont('size', +$('hpvSize').value));
        $('hpvBold').addEventListener('click', () => setFont('bold', !((cur.state.font || {}).bold)));
        $('hpvItalic').addEventListener('click', () => setFont('italic', !((cur.state.font || {}).italic)));
        $('hpvPrint').addEventListener('click', () => {
            const w = $('hpvFrame').contentWindow;
            w.focus();
            w.print();
        });
        $('hpvClose').addEventListener('click', close);
        box.addEventListener('click', (e) => { if (e.target === box) close(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !box.hidden) close(); });
        return box;
    }

    function close() {
        if (box) box.hidden = true;
        cur = null;
    }

    function open(opts) {
        ensureBox();
        cur = opts;
        if (!cur.state) cur.state = {};
        box.querySelector('#hpvTwo').hidden = !cur.twocolToggle;
        box.hidden = false;
        render();
    }

    /* розкладка по аркушах: h2 і таблиці йдуть один за одним; колонка заповнюється
       до низу, далі наступна колонка (права), і лише потім новий аркуш */
    function render() {
        if (!cur) return;
        const $ = (id) => box.querySelector('#' + id);
        const orient = cur.state.orient === 'l' ? 'l' : 'p';
        const two = !!cur.state.twocol;
        box.querySelectorAll('#hpvOrient .seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.o === orient));
        box.querySelectorAll('#hpvTwo .seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.c === (two ? '1' : '0')));
        // шрифт друку: розмір, гарнітура, жирний / курсив
        const f = cur.state.font || {};
        const size = +f.size || 12;
        $('hpvSize').innerHTML = [8, 9, 10, 11, 12, 13, 14, 16, 18].map((n) =>
            `<option value="${n}"${n === size ? ' selected' : ''}>${n}</option>`).join('');
        $('hpvFamily').value = f.family || '';
        $('hpvBold').classList.toggle('on', !!f.bold);
        $('hpvItalic').classList.toggle('on', !!f.italic);
        const scale = Math.min(200, Math.max(40, +cur.state.scale || 100));
        $('hpvScale').innerHTML = [60, 70, 75, 80, 85, 90, 95, 100, 110, 125].map((n) =>
            `<option value="${n}"${n === scale ? ' selected' : ''}>${n}%</option>`).join('');
        const zm = (html) => `<div class="zm"${scale !== 100 ? ` style="zoom:${scale / 100}"` : ''}>${html}</div>`;
        const fontCss = `.sheet,#measure{font-size:${size}px`
            + (f.family ? `;font-family:'${f.family}',sans-serif` : '')
            + (f.bold ? ';font-weight:600' : '')
            + (f.italic ? ';font-style:italic' : '') + '}';
        const c = cur.content() || {};
        $('hpvTitle').textContent = c.title || '';
        const d = $('hpvFrame').contentWindow.document;
        d.open();
        d.write(`<!doctype html><html><head><meta charset="utf-8"><title>${esc(c.title)}</title>
            <style>@page{size:A4 ${orient === 'l' ? 'landscape' : 'portrait'};margin:0}${PRINT_CSS}${fontCss}</style></head>
            <body><div id="measure" class="sheet ${orient}">${zm(`<h1>${esc(c.title)}<span class="sub">${esc(c.sub || '')}</span>${c.legend ? `<span class="leg">${c.legend}</span>` : ''}</h1>${c.body || ''}`)}</div></body></html>`);
        d.close();
        const my = ++seq;                       // дві перемальовки поспіль: рахує лише остання
        setTimeout(() => {
            if (!cur || my !== seq) return;
            const m = d.getElementById('measure');
            if (!m) return;
            const mmPx = 96 / 25.4;
            const inner = ((orient === 'l' ? 210 : 297) - 18 - 1) * mmPx;   // мінус поля (номер аркуша — у нижньому полі) і 1 мм запасу
            const per = two ? 2 : 1;                                        // колонок на аркуші
            const sheetW = ((orient === 'l' ? 297 : 210) - 20) * mmPx;
            const innerW = two ? (sheetW - TWO_GAP_MM * mmPx) / 2 : sheetW;
            const mz = m.querySelector('.zm') || m;
            const h1 = mz.querySelector('h1');
            const tables = [...mz.querySelectorAll('table')];
            const hOf = (el) => el.getBoundingClientRect().height;      // дробова висота — без похибки округлення
            const headH = (tables.length && tables[0].tHead) ? hOf(tables[0].tHead) : 0;
            const h1H = hOf(h1) + 6;
            // ширина з урахуванням масштабу: rect уже враховує zoom
            const wide = tables.some((t) => t.getBoundingClientRect().width > innerW + 1);
            const colHtml = (items) => items.map((it) => it.h2
                || `<table style="${it.table.getAttribute('style') || ''}">`
                   + `${(it.table.querySelector('colgroup') || { outerHTML: '' }).outerHTML}`
                   + `${it.table.tHead ? it.table.tHead.outerHTML : ''}<tbody>${it.rows.join('')}</tbody></table>`).join('');
            const layout = (limit) => {
                const cols = [];
                let page = [], used = h1H, open = null;                 // open — таблиця, у яку зараз пишемо
                const push = () => { cols.push(page); page = []; used = cols.length < per ? h1H : 0; open = null; };
                [...mz.children].forEach((el) => {
                    if (el.tagName === 'H2') {
                        const h = hOf(el) + 14;                         // з полями заголовка
                        if (page.length && used + h + headH + 24 > limit) push();
                        page.push({ h2: el.outerHTML }); used += h; open = null;
                    } else if (el.tagName === 'TABLE') {
                        const t = el;
                        const all = t.tBodies[0] ? [...t.tBodies[0].rows] : [];
                        const stack = [];                               // поточні групи за рівнями
                        all.forEach((r, ri) => {
                            const isSec = r.classList.contains('sec');
                            // назва групи не лишається сама внизу колонки — з нею хоч один рядок
                            const h = hOf(r) + (isSec && all[ri + 1] ? hOf(all[ri + 1]) : 0);
                            if (open !== t && used + headH + h > limit && page.length) push();
                            else if (open === t && used + h > limit) push();
                            if (open !== t) {
                                const cont = page.length === 0 && !isSec && stack.length;
                                page.push({ table: t, rows: [] }); used += headH; open = t;
                                // продовження групи в новій колонці / на новому аркуші — з її назвою
                                if (cont) stack.forEach((sr) => {
                                    const cl = sr.cloneNode(true);
                                    // назва групи може стояти не в першій клітинці (перед нею
                                    // порожня колонка «№») — дописуємо туди, де є текст
                                    const tc = [...cl.cells].find((c) => c.textContent.trim()) || cl.cells[0];
                                    tc.textContent += ' (продовження)';
                                    page[page.length - 1].rows.push(cl.outerHTML); used += hOf(sr);
                                });
                            }
                            if (isSec) {
                                const lv = +((r.className.match(/\bl(\d)/) || [])[1] || 0);
                                stack.length = lv; stack[lv] = r;
                            }
                            page[page.length - 1].rows.push(r.outerHTML); used += hOf(r);
                        });
                    }
                });
                cols.push(page);
                const pages = [];
                for (let i = 0; i < cols.length; i += per) pages.push(cols.slice(i, i + per));
                return pages;
            };
            const draw = (pages) => pages.map((pc, i) => `<div class="sheet ${orient}">
                ${zm(`${i === 0 ? h1.outerHTML : ''}`
                    + `${two ? `<div class="two" style="--g:${TWO_GAP_MM / 2}mm">${pc.map((cc) => `<div class="col">${colHtml(cc)}</div>`).join('')}</div>` : colHtml(pc[0])}`)}
                ${wide ? `<div class="over" style="left:${10 * mmPx + innerW}px"></div>` : ''}
                <span class="pn">${i + 1} / ${pages.length}</span></div>`).join('');
            // перевірка на готових аркушах: якщо щось вилазить за низ — розкласти щільніше
            let limit = inner, pages = [];
            for (let pass = 0; pass < 6; pass++) {
                d.querySelectorAll('.sheet:not(#measure)').forEach((x) => x.remove());
                pages = layout(limit);
                d.body.insertAdjacentHTML('beforeend', draw(pages));
                let over = 0;
                d.querySelectorAll('.sheet:not(#measure)').forEach((sh) => {
                    const top = sh.getBoundingClientRect().top + 10 * mmPx;
                    sh.querySelectorAll('table, h2').forEach((x) => {
                        over = Math.max(over, x.getBoundingClientRect().bottom - top - inner);
                    });
                });
                if (over <= 0.5) break;
                limit -= over + 2;
            }
            m.remove();
            $('hpvInfo').innerHTML = `Аркушів: <b>${pages.length}</b>`;
            // попередження окремим рядком: у смужці воно розсувало кнопки
            $('hpvWarn').textContent = wide
                ? 'Таблиця ширша за аркуш — зменшіть масштаб чи шрифт або візьміть альбомний.' : '';
            $('hpvWarn').hidden = !wide;
        }, 60);
    }

    window.herdPrint = { open, TWO_GAP_MM };
}());
