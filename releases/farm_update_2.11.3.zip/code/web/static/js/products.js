/* ============ Склад: довідник товарів ============ */

const productsBody = document.querySelector('#productsTable tbody');
const searchInput   = document.getElementById('productSearch');
const productForm   = document.getElementById('productForm');
const productModalTitle = document.getElementById('productModalTitle');

const filterSupplier = document.getElementById('filterSupplier');
const filterUnit     = document.getElementById('filterUnit');
const filterStock    = document.getElementById('filterStock');
const filterExpiry   = document.getElementById('filterExpiry');
const filterCountEl  = document.getElementById('filterCount');
const resetFiltersBtn = document.getElementById('resetFiltersBtn');

let allProducts = [];

// Стан сортування
let sortColumn = 'name';
let sortDir    = 'asc';   // 'asc' | 'desc'

/* ---------- завантаження ---------- */

async function loadProducts() {
    const r = await apiGet('/api/products');
    if (!r.ok) { toast('Помилка завантаження товарів', 'error'); return; }
    allProducts = r.items || [];
    rebuildFilterOptions();
    renderProducts();
    makeColumnsResizable('productsTable', 'vetpharm:products_cols');
}

function rebuildFilterOptions() {
    const suppliers = new Set();
    const units     = new Set();
    for (const p of allProducts) {
        if (p.supplier) suppliers.add(p.supplier);
        if (p.unit) units.add(p.unit);
    }

    function fillSelect(sel, values, currentValue) {
        const sorted = [...values].sort((a, b) => a.localeCompare(b, 'uk'));
        sel.innerHTML = '<option value="">Всі</option>' +
            sorted.map(v => `<option value="${escapeHtml(v)}"${v === currentValue ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
    }

    fillSelect(filterSupplier, suppliers, filterSupplier.value);
    fillSelect(filterUnit,     units,     filterUnit.value);
}

/* ---------- фільтрація + сортування ---------- */

function applyFiltersAndSort(items) {
    const q = (searchInput.value || '').trim().toLowerCase();
    const fSupplier = filterSupplier.value;
    const fUnit     = filterUnit.value;
    const fStock    = filterStock.value;
    const fExpiry   = filterExpiry.value;

    const today = new Date().toISOString().slice(0, 10);
    const in30 = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
    const in90 = new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10);

    let result = items.filter((p) => {
        // глобальний пошук
        if (q && !((p.name + ' ' + p.barcode + ' ' + (p.supplier || '') + ' ' + (p.notes || '')).toLowerCase().includes(q))) return false;
        // постачальник
        if (fSupplier && p.supplier !== fSupplier) return false;
        // одиниця
        if (fUnit && p.unit !== fUnit) return false;
        // запас
        if (fStock === 'low' && !(p.total_qty <= p.min_stock)) return false;
        if (fStock === 'zero' && p.total_qty > 0) return false;
        if (fStock === 'in_stock' && p.total_qty <= 0) return false;
        // термін придатності
        if (fExpiry === 'expired') {
            if (!p.nearest_expiry || p.nearest_expiry >= today) return false;
        } else if (fExpiry === 'soon30') {
            if (!p.nearest_expiry || p.nearest_expiry >= in30 || p.nearest_expiry < today) return false;
        } else if (fExpiry === 'soon90') {
            if (!p.nearest_expiry || p.nearest_expiry >= in90 || p.nearest_expiry < today) return false;
        } else if (fExpiry === 'no_expiry') {
            if (p.nearest_expiry) return false;
        }
        return true;
    });

    // сортування
    const dir = sortDir === 'desc' ? -1 : 1;
    result.sort((a, b) => {
        const va = a[sortColumn];
        const vb = b[sortColumn];
        // null/undefined завжди вкінець
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
        return String(va).localeCompare(String(vb), 'uk', { numeric: true }) * dir;
    });

    return result;
}

function renderProducts() {
    const items = applyFiltersAndSort(allProducts);

    // індикатори в заголовках
    document.querySelectorAll('#productsTable .sortable-th').forEach((th) => {
        th.classList.remove('sort-asc', 'sort-desc');
        if (th.dataset.sort === sortColumn) {
            th.classList.add(sortDir === 'desc' ? 'sort-desc' : 'sort-asc');
        }
    });

    // лічильник
    if (allProducts.length === items.length) {
        filterCountEl.textContent = `${items.length} товар${pluralize(items.length, '', 'и', 'ів')}`;
    } else {
        filterCountEl.textContent = `Показано ${items.length} з ${allProducts.length}`;
    }

    if (items.length === 0) {
        productsBody.innerHTML = '<tr><td colspan="13" class="empty">Нічого не знайдено за обраними фільтрами</td></tr>';
        return;
    }

    const today = new Date().toISOString().slice(0, 10);
    const in30  = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);

    productsBody.innerHTML = items.map((p) => {
        const low = p.total_qty <= p.min_stock;
        const zero = p.total_qty <= 0;
        let expiry = '<span class="text-mute">—</span>';
        if (p.nearest_expiry) {
            const expired = p.nearest_expiry < today;
            const soon = !expired && p.nearest_expiry < in30;
            const cls = expired ? 'badge danger' : (soon ? 'badge warn' : 'text-mute');
            expiry = `<span class="${cls}">${fmtDate(p.nearest_expiry)}</span>`;
        }
        const stockClass = zero ? 'text-danger' : (low ? 'text-warn' : '');
        return `
            <tr data-id="${p.id}">
                <td>
                    <button class="batch-toggle" data-toggle="${p.id}" title="Показати партії">▸</button>
                    <strong>${escapeHtml(p.name)}</strong>
                    ${p.notes ? `<div class="text-mute" style="font-size:11px;margin-left:22px;">${escapeHtml(p.notes)}</div>` : ''}
                </td>
                <td class="text-mute">${escapeHtml(p.code || '')}</td>
                <td class="text-mute">${escapeHtml(p.barcode)}</td>
                <td>${escapeHtml(p.unit)}</td>
                <td class="num ${stockClass}"><strong>${fmtNum(p.total_qty)}</strong></td>
                <td class="num text-mute">${fmtNum(p.min_stock)}</td>
                <td class="num">${fmtPrice4(p.avg_price_in_no_vat)}</td>
                <td class="num" title="Сума по партіях (точна). Ціна — середня округлена, тож ціна×кількість може відрізнятись на копійки.">${fmtMoney(p.stock_value_no_vat)}</td>
                <td class="num text-mute">${fmtPrice4(p.avg_price_in)}</td>
                <td class="num text-mute" title="Сума по партіях (точна). Ціна — середня округлена, тож ціна×кількість може відрізнятись на копійки.">${fmtMoney(p.stock_value)}</td>
                <td>${escapeHtml(p.supplier || '')}</td>
                <td>${expiry}</td>
                <td class="col-actions">
                    <div class="row-actions">
                        <button class="btn btn-icon" data-adjust="${escapeHtml(p.barcode)}"
                                data-name="${escapeHtml(p.name)}" data-qty="${p.total_qty}"
                                data-unit="${escapeHtml(p.unit || '')}"
                                title="Вирівняти залишок (інвентаризація)">⚖</button>
                        <button class="btn btn-icon" data-edit="${p.id}" title="Редагувати">✎</button>
                        <button class="btn btn-icon btn-icon-danger" data-delete="${p.id}" title="Видалити">🗑</button>
                    </div>
                </td>
            </tr>
            <tr class="batch-detail" data-detail="${p.id}" hidden>
                <td colspan="13">
                    <div class="batch-box"><div class="batch-empty">Завантаження…</div></div>
                </td>
            </tr>
        `;
    }).join('');
}

/* ---------- розкривні партії товару ---------- */

function renderBatchBox(box, batches, product) {
    // «Вирівняти залишок» — тут, під самим товаром: колонка дій у широкій
    // таблиці ховається праворуч, і до неї доводилось прокручувати
    const alignBtn = product ? `<button class="btn btn-sm batch-align"
            data-adjust="${escapeHtml(product.barcode)}"
            data-name="${escapeHtml(product.name)}" data-qty="${product.total_qty}"
            data-unit="${escapeHtml(product.unit || '')}"
            title="Виставити фактичний залишок (інвентаризація)">⚖ Вирівняти залишок</button>` : '';
    if (!batches.length) {
        box.innerHTML = `<div class="batch-empty">Немає партій у наявності</div>${
            alignBtn ? `<div class="batch-box-foot">${alignBtn}</div>` : ''}`;
        return;
    }
    const today = new Date().toISOString().slice(0, 10);
    const in30 = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
    const rows = batches.map((b) => {
        const expired = b.expires_on && b.expires_on < today;
        const soon = b.expires_on && !expired && b.expires_on < in30;
        const expCls = expired ? 'input-error' : (soon ? 'input-warn' : '');
        // ціна закупки без ПДВ; для старих партій без збереженого значення
        // — обчислюємо за ставкою ПДВ цієї партії
        const rate = (b.vat_rate != null) ? b.vat_rate : 20;
        let priceNoVat = b.price_in_no_vat || 0;
        if (!priceNoVat && b.price_in) {
            priceNoVat = rate > 0 ? b.price_in / (1 + rate / 100) : b.price_in;
        }
        const qty = b.qty || 0;
        const sumNoVat = qty * priceNoVat;
        const sumVat   = qty * (b.price_in || 0);
        return `
            <tr>
                <td>
                    <input type="date" class="batch-exp-edit ${expCls}"
                           data-batch="${b.id}" value="${b.expires_on || ''}" title="Термін придатності">
                </td>
                <td class="num text-mute">${fmtNum(b.received_qty)}</td>
                <td class="num"><strong>${fmtNum(b.qty)}</strong></td>
                <td class="num">${fmtPrice4(priceNoVat)}</td>
                <td class="num">${fmtPrice4(b.price_in)}</td>
                <td class="num text-mute">${fmtMoney(sumNoVat)}</td>
                <td class="num text-mute">${fmtMoney(sumVat)}</td>
                <td>${escapeHtml(b.supplier || '—')}</td>
                <td>${escapeHtml(b.invoice_number || '—')}</td>
                <td>${b.receipt_date ? fmtDate(b.receipt_date) : '—'}</td>
                <td class="num">
                    <button class="btn btn-icon" data-adjust-batch="${b.id}"
                            data-qty="${b.qty}"
                            data-price="${b.price_in || 0}"
                            title="Коригування партії (інвентаризація, бій, пересортиця)">±</button>
                    <button class="btn btn-icon btn-icon-danger" data-del-batch="${b.id}"
                            title="Видалити партію">🗑</button>
                </td>
            </tr>
        `;
    }).join('');
    box.innerHTML = `
        <div class="batch-box-title">Надходження (${batches.length})${alignBtn}</div>
        <table class="batch-table">
            <thead>
                <tr>
                    <th>Термін</th>
                    <th class="num">Отримано</th>
                    <th class="num">Залишок</th>
                    <th class="num">Ціна без ПДВ</th>
                    <th class="num">Ціна з ПДВ</th>
                    <th class="num">Сума без ПДВ</th>
                    <th class="num">Сума з ПДВ</th>
                    <th>Постачальник</th>
                    <th>Накладна</th>
                    <th>Дата приходу</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>${rows}</tbody>
        </table>
    `;
}

async function toggleBatches(productId, btn) {
    const row = productsBody.querySelector(`tr.batch-detail[data-detail="${productId}"]`);
    if (!row) return;
    if (!row.hidden) {
        row.hidden = true;
        btn.textContent = '▸';
        return;
    }
    row.hidden = false;
    btn.textContent = '▾';
    const box = row.querySelector('.batch-box');
    box.innerHTML = '<div class="batch-empty">Завантаження…</div>';
    const r = await apiGet('/api/products/' + productId + '/batches');
    if (!r.ok) {
        box.innerHTML = '<div class="batch-empty">Не вдалося завантажити партії</div>';
        return;
    }
    renderBatchBox(box, r.items || [],
                   allProducts.find((x) => String(x.id) === String(productId)));
}

function pluralize(n, one, few, many) {
    n = Math.abs(n) % 100;
    const n1 = n % 10;
    if (n > 10 && n < 20) return many;
    if (n1 > 1 && n1 < 5) return few;
    if (n1 === 1) return one;
    return many;
}

/* ---------- обробники подій ---------- */

searchInput.addEventListener('input', renderProducts);
filterSupplier.addEventListener('change', renderProducts);
filterUnit.addEventListener('change', renderProducts);
filterStock.addEventListener('change', renderProducts);
filterExpiry.addEventListener('change', renderProducts);

resetFiltersBtn.addEventListener('click', () => {
    searchInput.value = '';
    filterSupplier.value = '';
    filterUnit.value = '';
    filterStock.value = '';
    filterExpiry.value = '';
    sortColumn = 'name';
    sortDir = 'asc';
    renderProducts();
});

// клік по заголовку → сортування
document.querySelectorAll('#productsTable .sortable-th').forEach((th) => {
    th.addEventListener('click', () => {
        const col = th.dataset.sort;
        if (!col) return;
        if (sortColumn === col) {
            sortDir = (sortDir === 'asc') ? 'desc' : 'asc';
        } else {
            sortColumn = col;
            // числові колонки за замовчуванням — спадання (більше зверху)
            sortDir = ['total_qty', 'min_stock', 'avg_price_in', 'stock_value',
                       'avg_price_in_no_vat', 'stock_value_no_vat'].includes(col)
                ? 'desc' : 'asc';
        }
        renderProducts();
    });
});

/* ---------- сівба довідника кормів (лише гілка Годівля) ---------- */

const seedFeedBtn = document.getElementById('seedFeedBtn');
if (seedFeedBtn) {
    seedFeedBtn.addEventListener('click', async () => {
        if (!await confirmAction('Додати у довідник відомі корми з Profeed?\n\n' +
            'Наявні позиції не змінюються — додається лише те, чого немає. ' +
            'Разом додаються коди Profeed і рецепти комбікормів К2/К4/К5/К7.')) return;
        seedFeedBtn.disabled = true;
        const r = await apiSend('/api/feed/seed-catalog', 'POST', {});
        seedFeedBtn.disabled = false;
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        const d = r.data || r;
        toast(d.added_count
            ? `Додано ${d.added_count} кормів, рецептів: ${d.recipes}`
            : 'Довідник уже заповнено — нових позицій немає', 'success');
        loadProducts();
    });
}

/* ---------- модал додавання/редагування ---------- */

document.getElementById('addProductBtn').addEventListener('click', async () => {
    productForm.reset();
    productForm.id.value = '';
    productModalTitle.textContent = 'Новий товар';
    openModal('productModal');
    // підставляємо наступний вільний код товару
    const r = await apiGet('/api/generate-code');
    if (r.ok) productForm.code.value = r.code;
});

productsBody.addEventListener('click', async (e) => {
    // розгортання/згортання партій товару
    const toggle = e.target.closest('[data-toggle]');
    if (toggle) { toggleBatches(toggle.dataset.toggle, toggle); return; }

    // видалення партії з розкритого вмісту
    const delBatch = e.target.closest('[data-del-batch]');
    if (delBatch) {
        if (!await confirmAction('Видалити цю партію приходу? Її залишок буде вилучено зі складу.')) return;
        const r = await apiSend('/api/receipts/' + delBatch.dataset.delBatch, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Партію видалено', 'success');
        loadProducts();
        return;
    }

    // коригування КОНКРЕТНОЇ партії (інвентаризація / бій / пересортиця)
    const adjBatch = e.target.closest('[data-adjust-batch]');
    if (adjBatch) {
        // Знайдемо назву товару — вона у головному рядку, на 2 рівні вище
        const productRow = adjBatch.closest('tr.batch-detail');
        const mainRow = productRow ? productRow.previousElementSibling : null;
        const productName = mainRow ? (mainRow.querySelector('strong')?.textContent || '')
                                    : '';
        const form = document.getElementById('batchAdjustForm');
        form.reset();
        form.batch_id.value = adjBatch.dataset.adjustBatch;
        document.getElementById('baLine').textContent = productName || '—';
        document.getElementById('baQty').textContent = fmtNum(adjBatch.dataset.qty);
        document.getElementById('baPrice').textContent =
            fmtMoney(adjBatch.dataset.price);
        document.getElementById('baSign').value = '-';
        document.getElementById('baSum').textContent = '0,00';
        openModal('batchAdjustModal');
        return;
    }

    // вирівнювання залишку товару: вводиться ФАКТ, різницю рахує програма
    const adj = e.target.closest('[data-adjust]');
    if (adj) {
        const form = document.getElementById('adjustForm');
        form.reset();
        form.barcode.value = adj.dataset.adjust;
        form.dataset.qty = adj.dataset.qty || '0';
        form.dataset.unit = adj.dataset.unit || '';
        document.getElementById('adjProductLine').textContent = adj.dataset.name;
        // облік показуємо ТОЧНО так, як підставляємо в поле — інакше «470,00»
        // проти «470,003» виглядає розбіжністю, якої немає
        const exact = String(Math.round((+adj.dataset.qty || 0) * 10000) / 10000)
            .replace('.', ',');
        document.getElementById('adjCurrentQty').textContent =
            exact + ' ' + (adj.dataset.unit || '');
        const fact = document.getElementById('adjFact');
        fact.value = exact;
        adjShowDiff();
        openModal('adjustModal');
        setTimeout(() => { fact.focus(); fact.select(); }, 60);
        return;
    }

    const editId = e.target.dataset.edit;
    const delId = e.target.dataset.delete;
    if (editId) {
        const p = allProducts.find((x) => String(x.id) === editId);
        if (!p) return;
        productForm.reset();
        productForm.id.value = p.id;
        productForm.name.value = p.name;
        productForm.barcode.value = p.barcode;
        productForm.code.value = (p.code || '').replace(/\D/g, '');
        productForm.unit.value = p.unit;
        productForm.min_stock.value = p.min_stock;
        productForm.notes.value = p.notes || '';
        productForm.dose_unit.value = p.dose_unit || '';
        productForm.pack_content.value = p.pack_content || '';
        productForm.exclude_from_order.checked = !!p.exclude_from_order;
        productModalTitle.textContent = 'Редагування товару';
        openModal('productModal');
    } else if (delId) {
        if (!await confirmAction('Видалити (приховати) цей товар?')) return;
        const r = await apiSend('/api/products/' + delId, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Товар видалено', 'success');
        loadProducts();
    }
});

// Редагування терміну придатності партії прямо в таблиці
productsBody.addEventListener('change', async (e) => {
    const expInp = e.target.closest('.batch-exp-edit');
    if (expInp) {
        const r = await apiSend('/api/batches/' + expInp.dataset.batch + '/expiry',
                                'POST', { expires_on: expInp.value });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Термін придатності оновлено', 'success');
        const today = new Date().toISOString().slice(0, 10);
        expInp.classList.toggle('input-error', !!expInp.value && expInp.value < today);
    }
});

// Код товару — лише цифри (літери прибираються одразу при введенні)
productForm.code.addEventListener('input', () => {
    productForm.code.value = productForm.code.value.replace(/\D/g, '');
});

productForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(productForm).entries());
    // чекбокс: FormData пропускає невідмічений — виставляємо явно 0/1
    data.exclude_from_order = productForm.exclude_from_order.checked ? 1 : 0;
    const id = data.id;
    delete data.id;
    let r;
    if (id) r = await apiSend('/api/products/' + id, 'PUT', data);
    else    r = await apiSend('/api/products', 'POST', data);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Збережено', 'success');
    closeModal('productModal');
    loadProducts();
});

/* ---------- коригування КОНКРЕТНОЇ партії ---------- */
(function initBatchAdjust() {
    const form = document.getElementById('batchAdjustForm');
    if (!form) return;
    const baAmount = document.getElementById('baAmount');
    const baSign   = document.getElementById('baSign');
    const baSum    = document.getElementById('baSum');

    function recalc() {
        // Сума з price_in цієї партії (атрибут на кнопці передається у поле)
        const price = parseFloat(document.getElementById('baPrice')
            .textContent.replace(/[^\d.,-]/g, '').replace(',', '.')) || 0;
        const qty = parseFloat((baAmount.value || '').replace(',', '.')) || 0;
        baSum.textContent = fmtMoney(qty * price);
    }
    baAmount.addEventListener('input', recalc);
    baSign.addEventListener('change', recalc);

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const batchId = form.batch_id.value;
        const sign = baSign.value;
        const qty = parseFloat((baAmount.value || '').replace(',', '.'));
        const reasonType = document.getElementById('baReasonType').value;
        const note = document.getElementById('baNote').value;
        if (!qty || qty <= 0) {
            toast('Введіть кількість > 0', 'warn');
            return;
        }
        if (!reasonType) {
            toast('Вкажіть підставу коригування', 'warn');
            return;
        }
        const delta = sign === '+' ? qty : -qty;
        const r = await apiSend('/api/batches/' + batchId + '/adjust', 'POST', {
            delta: delta,
            reason_type: reasonType,
            note: note,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast(`Коригування партії проведено (${reasonType})`, 'success');
        closeModal('batchAdjustModal');
        loadProducts();
    });
})();

/* ---------- корекція залишків (по товару, FIFO; залишена для сумісності) ---------- */
/* різниця між фактом і обліком — показуємо одразу, ще до збереження */
function adjDelta() {
    const form = document.getElementById('adjustForm');
    const fact = parseFloat((document.getElementById('adjFact').value || '')
        .replace(/\s| /g, '').replace(',', '.'));
    if (!isFinite(fact)) return null;
    return Math.round((fact - (parseFloat(form.dataset.qty) || 0)) * 10000) / 10000;
}

function adjShowDiff() {
    const form = document.getElementById('adjustForm');
    const el = document.getElementById('adjDiff');
    const d = adjDelta();
    if (d === null) { el.textContent = '—'; el.className = 'text-mute'; return; }
    const unit = form.dataset.unit || '';
    el.textContent = (d > 0 ? '+' : '') + fmtNum(d) + (unit ? ' ' + unit : '');
    el.className = d === 0 ? '' : (d < 0 ? 'text-danger' : 'text-warn');
}

document.getElementById('adjFact').addEventListener('input', adjShowDiff);

document.getElementById('adjustForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const delta = adjDelta();
    if (delta === null) { toast('Вкажіть фактичний залишок', 'warn'); return; }
    if (delta === 0) {
        toast('Фактичний залишок збігається з обліковим — вирівнювати нічого', 'warn');
        return;
    }
    const r = await apiSend('/api/adjust', 'POST', {
        barcode: form.barcode.value,
        delta: delta,
        reason: document.getElementById('adjReason').value,
    });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast(`Залишок вирівняно (${delta > 0 ? '+' : ''}${fmtNum(delta)} `
          + `${form.dataset.unit || ''})`, 'success');
    closeModal('adjustModal');
    loadProducts();
});

document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    // Конструктор видимих колонок
    setupColumnPicker({
        tableId: 'productsTable',
        storageKey: 'vetpharm:products_cols_hidden',
        anchor: document.querySelector('#productsTable')
                    .closest('.panel').querySelector('.head-actions'),
        columns: [
            { key: 'name',          label: 'Назва' },
            { key: 'code',          label: 'Код товару' },
            { key: 'barcode',       label: 'Штрихкод' },
            { key: 'unit',          label: 'Одиниця' },
            { key: 'total_qty',     label: 'Залишок' },
            { key: 'min_stock',     label: 'Мін. залишок' },
            { key: 'avg_price_in_no_vat', label: 'Ціна закупки без ПДВ' },
            { key: 'stock_value_no_vat',  label: 'Сума закупки без ПДВ' },
            { key: 'avg_price_in',  label: 'Ціна закупки з ПДВ' },
            { key: 'stock_value',   label: 'Сума закупки з ПДВ' },
            { key: 'supplier',      label: 'Постачальник' },
            { key: 'nearest_expiry', label: 'Найближчий термін' },
        ],
    });
});
