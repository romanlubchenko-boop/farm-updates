/* Реєстр тварин (поголівний облік) — Фаза 1. */
'use strict';

/* Типи подій живуть у ДОВІДНИКУ (herd_event_defs) — проведення через
   Журнал (/herd/log): одна система, ефекти застосовуються завжди. */

let ALL_GROUPS = [];
let STATUSES = {};

const $ = (id) => document.getElementById(id);
const bind = (id, ev, fn) => { const el = $(id); if (el) el.addEventListener(ev, fn); };
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------- фільтри ----------
   Вибір фільтрів памʼятається між сторінками (Роман 2026-09-15): перемикач
   тварин у шапці гілки гортає САМЕ цю вибірку, тож він має знати, що обрано,
   навіть коли людина пішла з реєстру на календар чи рух поголівʼя. */
const FLT_KEY = 'herd:filters';

function selText(id) {
    const el = $(id);
    const o = el && el.options[el.selectedIndex];
    return (o && o.value) ? o.textContent.trim() : '';
}

function curFilters() {
    return {
        q: $('animSearch').value.trim(),
        status: $('animStatus').value,
        sex: $('animSex').value,
        group_id: $('animGroup').value,
        // назви — щоб перемикач у шапці підписував вибірку словами
        // («Нетелі»), а не кодом: на інших сторінках цих списків немає
        group_name: selText('animGroup'),
        status_name: selText('animStatus'),
    };
}

function saveFilters(f) {
    try { localStorage.setItem(FLT_KEY, JSON.stringify(f)); } catch (e) { /* ignore */ }
}

function restoreFilters() {
    let f = null;
    try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
    if (!f) return;
    if (f.q) $('animSearch').value = f.q;
    // статус і секцію ставимо ПІСЛЯ того, як наповняться списки (fillFilters)
    pendingFilters = f;
}

let pendingFilters = null;

/* ---------- колонки ----------
   Роман 2026-09-17: «таке саме налаштування колонок у реєстрі тварин», як у
   груповому вводі. Бирка є завжди; решта — параметри з КОНСТРУКТОРА (назви
   теж звідти: «усі параметри повинні йти із списку, із конструктора»).
   Частину з них реєстр уже має в самій тварині — такі клітинки малюємо з
   неї, без запиту значень. Набір свій у кожного й лежить на сервері. */
const DEFAULT_COLS = ['name', 'sex', 'age_months', 'breed', 'group', 'lactation', 'status'];
let COLS = null;
let PARAMS = [];
let LAST_ITEMS = [];
// колонки, що беруться з самої тварини (без запиту параметрів)
const CORE_COLS = {
    name: { label: 'Кличка', cell: (a) => escapeHtml(a.name || '') },
    sex: { label: 'Стать', cell: (a) => escapeHtml(a.sex ? herdOpt('sex', a.sex) : '') },
    age_months: { label: 'Вік, міс', num: true, cell: (a) => (a.age_months == null ? '' : a.age_months) },
    breed: { label: 'Порода', cell: (a) => escapeHtml(a.breed || '') },
    group: { label: 'Секція', cell: (a) => escapeHtml(a.group_name || '') },
    // 0 — це телиці, нетелі й бики: показуємо нуль, а не порожнечу
    lactation: { label: 'Лакт.', num: true,
        cell: (a) => (a.lactation_no == null ? '' : a.lactation_no) },
    status: { label: 'Статус',
        cell: (a) => `<span class="anim-badge ${a.status}">${escapeHtml(a.status_label || '')}</span>` },
};
const paramOf = (k) => PARAMS.find((p) => p.key === k) || null;

function colLabel(k) {
    const p = paramOf(k);                  // назва — як у конструкторі
    if (p) return p.label;
    return CORE_COLS[k] ? CORE_COLS[k].label : k;
}

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}

function paramCell(a, k) {
    const raw = (a.p || {})[k];
    if (raw === null || raw === undefined || raw === '') return '';
    const num = numText(raw, (paramOf(k) || {}).dtype);
    if (num !== null) return escapeHtml(num);
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = k === 'repro_code' ? '' : (a.pl || {})[k];
    if (lbl) return escapeHtml(lbl);
    const p = paramOf(k);
    if (p && p.dtype === 'date' && /^\d{4}-\d{2}-\d{2}/.test(String(raw))) {
        const [y, m, d] = String(raw).slice(0, 10).split('-');
        return `${d}.${m}.${y}`;
    }
    // довгі номери (транспондер) — по три цифри, як у картці тварини
    if (/^\d{9,}$/.test(String(raw))) return String(raw).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
    return escapeHtml(String(raw));
}

/* ---------- вкладка «Робота зі стадом» ----------
   Рядок-формула своєю мовою (herd_query.js): ФІЛЬТР(…) ПОКАЗАТИ(…)
   ГРУПУВАТИ(…) СОРТУВАТИ(…). Нічого не зберігається — це разова вибірка. */
const AW_KEY = 'herd:work_formula';
/* прочитані тварини лежать у памʼяті: поки формула не просить НОВИХ
   параметрів, наступний запуск миттєвий — без звернення до сервера */
let WORK_CACHE = null;
const CACHE_TTL = 120000;
let TAB = 'reg';
let Q = null;                        // розібрана формула
let ALL_ITEMS = [];
const qOn = () => TAB === 'work' && !!(Q && (Q.cols.length || Q.filters.length
    || Q.sorts.length || Q.groups.length));
const effCols = () => (qOn() && Q.cols.length ? Q.cols : COLS);
const stripTags = (h) => String(h === null || h === undefined ? '' : h)
    .replace(/<[^>]*>/g, '').trim();          // «0» лишається нулем, не порожнечею

let colsSaveT = null;
function saveCols() {
    clearTimeout(colsSaveT);
    colsSaveT = setTimeout(() => {
        apiSend('/api/herd/ui-columns', 'POST', { scope: 'registry', columns: COLS })
            .then((r) => { if (!r || !r.ok) toast('Колонки не збережено', 'error'); });
    }, 500);
}

async function loadColumns() {
    const [c, ev] = await Promise.all([
        apiGet('/api/herd/ui-columns?scope=registry'),
        apiGet('/api/herd/events?active=1'),        // перелік параметрів — там же
    ]);
    PARAMS = (ev && ev.ok) ? (ev.params || []) : [];
    const saved = c && c.ok ? c.columns : null;
    // лише те, що є в конструкторі
    COLS = (saved || DEFAULT_COLS).filter((k) => paramOf(k));
}

/* ---------- список ---------- */
async function loadList() {
    const f = curFilters();
    const params = new URLSearchParams();
    // у «Роботі зі стадом» добір задає формула, а не панель фільтрів
    if (TAB !== 'work') Object.keys(f).forEach((k) => { if (f[k]) params.set(k, f[k]); });
    saveFilters(f);
    if (COLS === null) await loadColumns();
    // значення параметрів: колонки + усе, що згадала формула
    const need = [...new Set([...effCols(), ...((qOn() && Q.keys) || [])])]
        .filter((k) => qOn() || !CORE_COLS[k]);
    if (need.length) params.set('params', need.join(','));
    // у «Роботі зі стадом» беремо лише потрібні поля — відповідь удвічі легша
    if (TAB === 'work') params.set('lean', '1');
    const r = await apiGet('/api/herd/animals?' + params.toString());
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    STATUSES = r.statuses || {};
    ALL_GROUPS = r.groups || [];
    fillFilters();
    if (pendingFilters) {                   // списки готові — ставимо збережене
        const f0 = pendingFilters;
        pendingFilters = null;
        if (f0.status) $('animStatus').value = f0.status;
        if (f0.sex) $('animSex').value = f0.sex;
        if (f0.group_id) $('animGroup').value = f0.group_id;
        if (f0.status || f0.sex || f0.group_id) { loadList(); return; }
    }
    renderStats(r.stats || {});
    ALL_ITEMS = r.items || [];
    if (TAB === 'work') {                          // запамʼятовуємо, що вже прочитано
        WORK_CACHE = { keys: new Set(need), items: ALL_ITEMS, at: Date.now() };
    }
    renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
    // перемикач у шапці гортає цю саму вибірку — віддаємо йому свіжий
    // порядок замість того, щоб він питав сервер удруге
    if (window.herdNav) window.herdNav.cacheList(r.items || []);
}

function fillFilters() {
    const st = $('animStatus');
    if (st.options.length <= 1) {
        // «вибулі» — не окремий статус, а всі, крім тих, що в стаді; те саме
        // значення розуміють перемикач у смужці й панель добору
        const gone = document.createElement('option');
        gone.value = 'gone'; gone.textContent = 'Вибулі';
        st.appendChild(gone);
        Object.entries(STATUSES).forEach(([k, v]) => {
            const o = document.createElement('option'); o.value = k; o.textContent = v;
            st.appendChild(o);
        });
    }
    const g = $('animGroup');
    if (g.options.length <= 1) {
        ALL_GROUPS.forEach((gr) => {
            const o = document.createElement('option'); o.value = gr.id; o.textContent = gr.name;
            g.appendChild(o);
        });
    }
}

function renderStats(s) {
    $('animStats').innerHTML =
        `<div class="anim-stat"><b>${s.active || 0}</b><span>${escapeHtml(herdOpt('status', 'active', 'В стаді'))}</span></div>` +
        `<div class="anim-stat"><b>${s.cows || 0}</b><span>${escapeHtml(herdOpt('sex', 'F', 'Корів/телиць'))}</span></div>`;
}

/* порядок секцій — ПОВНИЙ список Конструктора (у варіантах параметра лише
   секції з чинним періодом, тож секція без періоду випадала з порядку) */
function sortParamsFor() {
    if (!ALL_GROUPS.length) return PARAMS;
    return PARAMS.map((p) => (p.key === 'group'
        ? Object.assign({}, p, { choices: ALL_GROUPS.map((g) => ({ value: g.name, label: g.name })) })
        : p));
}

/* добір і порядок — за формулою */
function applyQ(items) {
    if (!qOn()) return items;
    let out = items.filter((a) => window.herdQuery.passes(a, Q.filters));
    // порядок груп — за Конструктором; «sort <параметр групи> desc» перевертає групи
    const dirOf = (k) => ((Q.sorts.find((sx) => sx.key === k) || {}).dir || 'asc');
    const order = Q.groups.map((k) => ({ key: k, dir: dirOf(k) }))
        .concat(Q.sorts.filter((sx) => !Q.groups.includes(sx.key)));
    if (order.length) out = window.herdQuery.sortRows(out, order, sortParamsFor());
    return out;
}

const TAG_KEYS = ['tag', 'id'];
/* у «Роботі зі стадом» шапка коротка — тими самими словами, що й у формулі */
function headLabel(k) {
    const p = paramOf(k);
    return qOn() ? (p ? awShort(p) : k) : colLabel(k);
}
const tagInCols = () => effCols().some((k) => TAG_KEYS.includes(k));

function renderHead() {
    $('animHead').innerHTML = (qOn() && Q.rownum ? '<th class="num">№</th>' : '')
        + (tagInCols() ? '' : `<th>${escapeHtml(qOn()
            ? (paramOf('tag') ? awShort(paramOf('tag')) : 'id')
            : herdLabel('tag', 'Номер тварини'))}</th>`)
        + effCols().map((k) => {
        const p = paramOf(k);
        const num = (CORE_COLS[k] && CORE_COLS[k].num) || (!CORE_COLS[k] && p && ['int', 'float'].includes(p.dtype));
        const p2 = paramOf(k);
        return `<th${num ? ' class="num"' : ''}`
            + `${qOn() && p2 ? ` title="${escapeHtml(p2.label)}"` : ''}>`
            + `${escapeHtml(headLabel(k))}</th>`;
    }).join('');
}

let ROW_NO = 0;
function rowHtml(a) {
    ROW_NO += 1;
    return `
        <tr data-id="${a.id}">
            ${qOn() && Q.rownum ? `<td class="num">${ROW_NO}</td>` : ''}
            ${tagInCols() ? '' : `<td><b>${escapeHtml(a.tag)}</b></td>`}
            ${effCols().map((k) => {
                if (CORE_COLS[k]) {
                    return `<td${CORE_COLS[k].num ? ' class="num"' : ''}>${CORE_COLS[k].cell(a)}</td>`;
                }
                const p = paramOf(k);
                const num = p && ['int', 'float'].includes(p.dtype);
                return `<td${num ? ' class="num"' : ''}>${paramCell(a, k)}</td>`;
            }).join('')}
        </tr>`;
}

/* підсумки: кількість і середнє/сума по числових параметрах */
const numFmt = (v, dec) => (Math.round(v * 10 ** dec) / 10 ** dec)
    .toLocaleString('uk-UA', { minimumFractionDigits: dec, maximumFractionDigits: dec });

function aggText(rows) {
    const aggs = (qOn() && Q.aggs) || [];
    // «N гол.» показуємо, поки не попросили cnt окремо
    const out = aggs.some((a) => a.fn === 'cnt') ? [] : [`<b>${rows.length}</b> гол.`];
    aggs.forEach((a) => {
        if (a.fn === 'cnt') {                     // кількість: усіх або із заповненим параметром
            const n = a.key
                ? rows.filter((x) => {
                    const v = (x.p || {})[a.key];
                    return !(v === null || v === undefined || v === '');
                }).length
                : rows.length;
            const p0 = a.key ? paramOf(a.key) : null;
            out.push(`cnt${p0 ? ' ' + escapeHtml(p0.short || p0.key) : ''} <b>${n}</b>`);
            return;
        }
        const nums = rows.map((x) => {
            const raw = (x.p || {})[a.key];
            const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
            return Number.isFinite(n) ? n : null;
        }).filter((n) => n !== null);
        if (!nums.length) return;
        const p = paramOf(a.key);
        const nm = p ? (p.short || p.key) : a.key;
        const v = a.fn === 'sum' ? nums.reduce((t, n) => t + n, 0)
            : a.fn === 'min' ? Math.min(...nums)
            : a.fn === 'max' ? Math.max(...nums)
            : nums.reduce((t, n) => t + n, 0) / nums.length;
        // назви агрегацій — ті самі слова, що й у формулі
        const dec = ['sum', 'min', 'max'].includes(a.fn) ? 0 : 1;
        out.push(`${a.fn} ${escapeHtml(nm)} <b>${numFmt(v, dec)}</b>`);
    });
    return out.join(' · ');
}

/* одне число агрегації */
function aggValue(a, rows) {
    if (a.fn === 'cnt') {
        return a.key
            ? rows.filter((x) => {
                const v = (x.p || {})[a.key];
                return !(v === null || v === undefined || v === '');
            }).length
            : rows.length;
    }
    const nums = rows.map((x) => {
        const raw = (x.p || {})[a.key];
        const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
        return Number.isFinite(n) ? n : null;
    }).filter((n) => n !== null);
    if (!nums.length) return null;
    if (a.fn === 'sum') return nums.reduce((t, n) => t + n, 0);
    if (a.fn === 'min') return Math.min(...nums);
    if (a.fn === 'max') return Math.max(...nums);
    return nums.reduce((t, n) => t + n, 0) / nums.length;
}

/* підсумковий рядок таблиці: числа стоять У СВОЇХ колонках, без підписів
   (Роман 2026-09-18: «вигрупування напроти стовпця — чіткіше») */
function sumRowHtml(rows, title, cls) {
    const aggs = (qOn() && Q.aggs) || [];
    const cols = effCols();
    const byCol = new Map();
    const rest = [];
    aggs.forEach((a) => {
        const v = aggValue(a, rows);
        if (v === null) return;
        const dec = a.fn === 'avg' ? 1 : 0;
        const txt = numFmt(v, dec);
        if (a.key && cols.includes(a.key)) {           // кілька агрегацій на колонку — поруч
            const cur = byCol.get(a.key) || { fns: [], txts: [] };
            cur.fns.push(a.fn); cur.txts.push(txt);
            byCol.set(a.key, cur);
        } else if (a.fn === 'cnt' && !a.key) rest.push(txt);   // просто кількість, без підпису
        else rest.push(`${a.fn}${a.key ? ' ' + escapeHtml(colShort(a.key)) : ''} ${txt}`);
    });
    const head = escapeHtml(title) + (aggs.some((a) => a.fn === 'cnt' && !a.key)
        ? '' : ` · ${rows.length}`)
        + (rest.length ? ` · ${rest.join(' · ')}` : '');
    // назва групи займає колонки ДО першої з числом — інакше вона розсуває «id»
    const lead = (qOn() && Q.rownum ? 1 : 0) + (tagInCols() ? 0 : 1);
    let firstNum = cols.findIndex((k) => byCol.has(k));
    if (firstNum < 0) firstNum = cols.length;
    const titleSpan = lead + firstNum - (qOn() && Q.rownum ? 1 : 0);
    let html = `<tr class="${cls}">`;
    if (qOn() && Q.rownum) html += '<td></td>';
    html += `<td colspan="${Math.max(1, titleSpan)}">${head}</td>`;
    cols.slice(tagInCols() ? firstNum : firstNum).forEach((k, i) => {
        if (i + firstNum < firstNum) return;
        const hit = byCol.get(k);
        html += `<td${isNumCol(k) ? ' class="num"' : ''}`
            + `${hit ? ` title="${hit.fns.join(' · ')}"` : ''}>`
            + `${hit ? `<b>${hit.txts.join(' · ')}</b>` : ''}</td>`;
    });
    return html + '</tr>';
}

const colShort = (k) => { const p = paramOf(k); return p ? (p.short || p.key) : k; };
const isNumCol = (k) => {
    if (CORE_COLS[k] && CORE_COLS[k].num) return true;
    const p = paramOf(k);
    return !!p && ['int', 'float', 'number'].includes(p.dtype);
};

function aggRow(rows, cls) {
    if (!qOn() || (!Q.aggs.length && !Q.groups.length)) return '';
    const span = effCols().length + (tagInCols() ? 0 : 1) + (Q.rownum ? 1 : 0);
    return `<tr class="anim-sum ${cls || ''}"><td colspan="${span}">${aggText(rows)}</td></tr>`;
}

/* групи формули — рядком-шапкою, як у календарі */
function groupedHtml(items, lvl) {
    const gs = (qOn() && Q.groups) || [];
    if (lvl >= gs.length) return items.map(rowHtml).join('');
    const k = gs[lvl];
    let by = new Map();
    items.forEach((a) => {
        const _t = stripTags(CORE_COLS[k] ? CORE_COLS[k].cell(a) : paramCell(a, k));
        const t = _t === '' || _t == null ? '— не вказано' : _t;   // «0» — теж значення
        if (!by.has(t)) by.set(t, []);
        by.get(t).push(a);
    });
    // порядок самих груп: якщо в sort стоїть параметр, однаковий у межах групи
    // (напр. «№ секції» при групуванні за секцією) — групи шикуються за ним
    const gsort = ((qOn() && Q.sorts) || []).find((sx) => {
        if (sx.key === k) return true;
        return [...by.values()].every((part) => {
            const v0 = (part[0].p || {})[sx.key];
            return part.every((a) => (a.p || {})[sx.key] === v0);
        });
    });
    if (gsort) {
        const rows = [...by.entries()].map(([t, part]) => ({ t, part, a: part[0] }));
        const sorted = window.herdQuery.sortRows(rows.map((x) => x.a),
            [{ key: gsort.key, dir: gsort.dir }], sortParamsFor());
        const pos = new Map(sorted.map((a, idx) => [a, idx]));
        rows.sort((x, y) => pos.get(x.a) - pos.get(y.a));
        by = new Map(rows.map((x) => [x.t, x.part]));
    }
    const span = effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0);
    const pre = gs.length > 1 ? `${escapeHtml(headLabel(k))}: ` : '';
    // шапка групи: назва + числа агрегацій у своїх колонках
    // рівень групи — у класі (l0, l1…): друк повторює на новому аркуші й батьківську шапку
    const gcls = `anim-grp l${Math.min(lvl, 2)}`;
    return [...by.entries()].map(([t, part]) =>
        (qOn() && Q.aggs.length
            ? sumRowHtml(part, pre + t, gcls)
            : `<tr class="${gcls}"><td colspan="${span}">${pre}${escapeHtml(t)} · ${part.length}</td></tr>`)
        + groupedHtml(part, lvl + 1)).join('');
}

function renderTable(items, total) {
    LAST_ITEMS = items;
    // у «Роботі зі стадом» таблиця по ширині вмісту, а не на все вікно
    const tbl = document.querySelector('.anim-table');
    tbl.classList.toggle('auto-w', qOn());
    delete tbl.dataset.colsResizable;              // шапка перемальовується
    delete tbl.dataset.colsFixed;
    tbl.classList.remove('is-sized');
    tbl.style.tableLayout = '';
    tbl.style.width = '';
    renderHead();
    const all = total === undefined ? items.length : total;
    $('animCount').textContent = items.length
        ? `· ${items.length}${qOn() && all !== items.length ? ` із ${all}` : ''}` : '';
    const tb = $('animBody');
    if (!items.length) {
        tb.innerHTML = `<tr><td colspan="${effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0)}" class="empty">${qOn()
            ? 'За цією формулою нікого' : 'Немає тварин. Додайте або імпортуйте.'}</td></tr>`;
        return;
    }
    ROW_NO = 0;
    tb.innerHTML = groupedHtml(items, 0)
        + (qOn() && Q.aggs.length ? sumRowHtml(items, 'Разом', 'anim-sum all')
            : (qOn() && Q.groups.length ? aggRow(items, 'all') : ''));
    // ширину колонок можна тягнути за межу заголовка; памʼятається в браузері
    // У «Роботі зі стадом» ширину не чіпаємо руками: колонка сама стає
    // за найширшим вмістом (Роман 2026-09-18). Ручний ресайз — лише в реєстрі.
    if (!qOn()) requestAnimationFrame(() => makeColumnsResizable('animTable', 'herd:reg_colw'));
    tb.querySelectorAll('tr[data-id]').forEach((tr) => {
        tr.addEventListener('click', () => {
            const a = items.find((x) => String(x.id) === String(tr.dataset.id));
            if (a && window.herdNav) window.herdNav.setCurrent(a);
            location.href = '/herd/animals/' + tr.dataset.id;
        });
    });
}

/* ---------- модал додати/редагувати ---------- */
function groupOptions(sel) {
    return '<option value="">—</option>' + ALL_GROUPS.map((g) =>
        `<option value="${g.id}"${String(g.id) === String(sel || '') ? ' selected' : ''}>${escapeHtml(g.name)}</option>`).join('');
}

function openEdit(a) {
    const isNew = !a;
    $('animEditTitle').textContent = isNew ? 'Нова тварина' : 'Редагувати тварину';
    $('afTag').value = a ? a.tag : '';
    $('afName').value = a ? (a.name || '') : '';
    $('afSex').value = a ? a.sex : 'F';
    $('afBirth').value = a ? (a.birth_date || '') : '';
    $('afBreed').value = a ? (a.breed || '') : '';
    $('afGroup').innerHTML = groupOptions(a ? a.group_id : '');
    $('afDam').value = a ? (a.dam_tag || '') : '';
    $('afSire').value = a ? (a.sire_code || '') : '';
    $('afLact').value = a ? (a.lactation_no || 0) : 0;
    $('afSource').value = a ? (a.source || 'born') : 'born';
    $('afEntry').value = a ? (a.entry_date || '') : todayISO();
    $('afNotes').value = a ? (a.notes || '') : '';
    $('afSaveBtn').dataset.id = a ? a.id : '';
    show('animEditModal');
    $('afTag').focus();
}

async function saveAnimal() {
    const id = $('afSaveBtn').dataset.id;
    const payload = {
        tag: $('afTag').value, name: $('afName').value, sex: $('afSex').value,
        birth_date: $('afBirth').value, breed: $('afBreed').value,
        group_id: $('afGroup').value, dam_tag: $('afDam').value,
        sire_code: $('afSire').value, lactation_no: $('afLact').value,
        source: $('afSource').value, entry_date: $('afEntry').value,
        notes: $('afNotes').value,
    };
    const url = id ? '/api/herd/animals/' + id : '/api/herd/animals';
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Збережено', 'success');
    hide('animEditModal');
    // одна картка тварини на всю гілку: після збереження — одразу в неї
    // (окреме спрощене вікно картки прибрано, Роман 2026-09-17)
    const newId = id || (r && r.id);
    if (newId) { location.href = '/herd/animals/' + newId; return; }
    await loadList();
}

/* ---------- імпорт ---------- */
async function doImport(file) {
    const st = $('animImportStatus');
    st.textContent = 'Завантаження…';
    const fd = new FormData(); fd.append('file', file);
    try {
        const r = await fetch('/api/herd/animals/import', { method: 'POST', body: fd });
        const j = await r.json();
        if (!j.ok) { st.textContent = 'Помилка: ' + (j.error || 'невідома'); return; }
        // Кажемо не лише «скільки», а й ЩО саме зайшло: коли у файлі були
        // колонки параметрів (транспондер, UIN), людина має бачити, що їх
        // розпізнано — інакше незрозуміло, чи спрацювало
        const pc = (j.param_columns || []);
        st.textContent = `Готово: додано ${j.added}, оновлено ${j.updated}` +
            (j.skipped ? `, пропущено ${j.skipped}` : '') +
            (j.missing ? `, не знайдено в реєстрі ${j.missing}` : '') +
            (pc.length ? ` · ${pc.join(', ')}: заповнено ${j.params_set || 0}` : '') +
            (j.errors && j.errors.length ? ` · помилок ${j.errors.length}` : '');
        loadList();
    } catch (e) { st.textContent = 'Сервер не відповів'; }
}

/* ---------- модал helpers ---------- */
function show(id) { const m = $(id); if (m) m.hidden = false; }
function hide(id) { const m = $(id); if (m) m.hidden = true; }
document.querySelectorAll('[data-close]').forEach((el) =>
    el.addEventListener('click', () => { el.closest('.modal').hidden = true; }));

/* ---------- init ---------- */
let searchTimer = null;
bind('animSearch', 'input', () => {
    clearTimeout(searchTimer); searchTimer = setTimeout(loadList, 250);
});
['animStatus', 'animSex', 'animGroup'].forEach((id) => bind(id, 'change', loadList));
bind('animAddBtn', 'click', () => openEdit(null));
bind('afSaveBtn', 'click', saveAnimal);
bind('animImportBtn', 'click', () => $('animImportFile').click());
bind('animImportFile', 'change', (e) => {
    if (e.target.files && e.target.files[0]) doImport(e.target.files[0]);
    e.target.value = '';
});

/* ---------- збережені списки (вкладка «Списки») ----------
   Формула з назвою, категорією і коментарем; лежать на сервері — одні на
   ферму, як списки календаря. Відкритий список лишається «приєднаним», тож
   виправлену формулу можна перезберегти однією кнопкою. */
let WLISTS = [], WCATS = [], WCUR = null;

async function wlLoad() {
    const r = await apiGet('/api/herd/work-lists').catch(() => null);
    WLISTS = (r && r.ok) ? (r.lists || []) : [];
    WCATS = (r && r.ok) ? (r.categories || []) : [];
    const sel = $('wlCat');
    if (sel && sel.options.length <= 1) {
        WCATS.forEach((c) => sel.insertAdjacentHTML('beforeend',
            `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
    }
    const save = $('awSaveCat');
    if (save && !save.options.length) {
        save.innerHTML = '<option value="">Без категорії</option>'
            + WCATS.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    }
    wlRender();
}

async function wlSave() {
    const r = await apiSend('/api/herd/work-lists', 'POST', { lists: WLISTS });
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося зберегти', 'error'); return false; }
    WLISTS = r.lists || [];
    wlRender();
    return true;
}

function wlRender() {
    const box = $('wlBody');
    if (!box) return;
    const q = ($('wlSearch') ? $('wlSearch').value : '').trim().toLowerCase();
    const cat = $('wlCat') ? $('wlCat').value : '';
    const rows = WLISTS.filter((L) => (!cat || L.category === cat)
        && (!q || `${L.name} ${L.note || ''} ${L.formula}`.toLowerCase().includes(q)));
    const tbl = $('wlTbl');
    if (!rows.length) {
        if (tbl) tbl.classList.add('is-empty');
        box.innerHTML = `<tr><td colspan="3" class="wl-empty">${WLISTS.length
            ? 'За цим добором нічого немає.'
            : 'Збережених списків ще немає. Наберіть формулу у «Роботі зі стадом» і збережіть її значком 💾.'}</td></tr>`;
        return;
    }
    if (tbl) tbl.classList.remove('is-empty');
    // теми йдуть у порядку Конструктора, «Без категорії» — останньою
    const secs = [];
    (WCATS.length ? WCATS : [...new Set(rows.map((L) => L.category))].filter(Boolean))
        .forEach((c) => {
            const got = rows.filter((L) => L.category === c);
            if (got.length) secs.push([c, got]);
        });
    const rest = rows.filter((L) => !L.category);
    if (rest.length) secs.push(['Без категорії', rest]);

    const rowHtml = (L) => `<tr class="wl-row" data-id="${escapeHtml(L.id)}">
        <td class="wl-cname"><span class="wl-name" data-act="open" title="Відкрити">${escapeHtml(L.name)}</span></td>
        <td>
            <code class="wl-f">${awHlHtml(L.formula)}</code>
            ${L.note ? `<div class="wl-note">${escapeHtml(L.note)}</div>` : ''}
        </td>
        <td class="wl-acts">
            <button type="button" data-act="rename" title="Перейменувати">✎</button>
            <button type="button" data-act="del" title="Видалити">✕</button>
        </td>
    </tr>`;
    box.innerHTML = secs.map(([c, got]) => `<tr class="wl-sec"><td colspan="3">
        ${escapeHtml(c)}<span class="wl-n">${got.length}</span></td></tr>`
        + got.map(rowHtml).join('')).join('');
}

/* який список зараз відкрито у «Роботі зі стадом» */
function wlSetCur(L) {
    WCUR = L || null;
    if (WCUR) OV_CUR = null;
    awCurShow();
}

/* смужка під рядком: що саме зараз відкрито — список чи панель «Огляду» */
function awCurShow() {
    const box = $('awCur');
    if (!box) return;
    const cur = WCUR || OV_CUR;
    box.hidden = !cur;
    if (!cur) return;
    $('awCurName').innerHTML = (WCUR ? 'Список ' : 'Панель ')
        + `<b>${escapeHtml(cur.name)}</b>`;
}

function wlOpen(L) {
    $('awInput').value = L.formula;
    try { localStorage.setItem(AW_KEY, L.formula); } catch (e) { /* ignore */ }
    wlSetCur(L);
    setTab('work');
    awPaint();
}

/* ---------- вкладки: Огляд / Робота зі стадом / Списки ---------- */
function setTab(t) {
    TAB = ['work', 'lists'].includes(t) ? t : 'reg';
    document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.tab === TAB));
    $('animWork').hidden = TAB !== 'work';
    $('animLists').hidden = TAB !== 'lists';
    $('animOver').hidden = TAB !== 'reg';       // «Огляд» — самі панелі-показники
    $('animFilters').hidden = true;             // добір живе у формулі, не в панелі фільтрів
    $('animStats').hidden = true;
    // таблиця тварин — лише у «Роботі зі стадом»
    $('animTableWrap').hidden = TAB !== 'work';
    $('animCount').hidden = TAB !== 'work';
    try { sessionStorage.setItem('herd:anim_tab', TAB); } catch (e) { /* ignore */ }
    if (TAB === 'work') runFormula();
    else if (TAB === 'lists') wlLoad();
    else { Q = null; ovLoad(); }
}

/* ---------- «Огляд»: налаштовані панелі-показники ----------
   Панель — назва + формула добору (та сама мова, що в «Роботі зі стадом»).
   Роман 2026-09-18: «прибрати реєстр і зробити налаштовані панелі». */
let OV = [], OV_ITEMS = [], OV_EDIT = null, OV_CUR = null, SAVE_WHERE = 'list';
let OV_COLOR = '', OV_BG = '', OV_EDGE = '', OV_LAST = {};
/* Палітри (Роман 2026-09-19: «для шрифту, фону — палітри»): 15 тонів × 5
   кроків світлоти + сірі. Для шрифту й канта — насичені, для фону — світлі. */
const OV_HUES = [0, 15, 30, 45, 60, 90, 130, 160, 185, 205, 225, 255, 285, 315, 340];
function hslHex(h, s, l) {
    s /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return '#' + [f(0), f(8), f(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}
const OV_PAL_INK = [].concat(
    ...[28, 38, 48, 58, 68].map((l) => OV_HUES.map((h) => hslHex(h, 70, l))),
    [10, 25, 40, 55, 70, 80].map((l) => hslHex(215, 12, l)));
const OV_PAL_BG = [].concat(
    ...[97, 93, 89, 84, 78].map((l) => OV_HUES.map((h) => hslHex(h, 70, l))),
    [98, 95, 92, 88, 84, 80].map((l) => hslHex(215, 14, l)));
// ранні коди фону: основні кольори показувались блідим тоном — лишаємо їх блідими
const OV_BG_OLD = { '#2f5fb0': '#e3ebf7', '#1aa86b': '#e1f4ea', '#7c3aed': '#ece3fc',
    '#b45309': '#f6e8dc', '#0e7490': '#dcedf1', '#e5484d': '#fbe2e3', '#5b7083': '#e6e9ed',
    '#f5f8fd': '#f5f8fd', '#f4fbf7': '#f4fbf7', '#f8f6fd': '#f8f6fd', '#fdf9f3': '#fdf9f3',
    '#f2f9fb': '#f2f9fb', '#fdecec': '#fdecec', '#f7f8fa': '#f7f8fa' };
const ovBgOf = (c) => OV_BG_OLD[c] || c;
const ovTint = (c) => (c ? ovBgOf(c) : '');

const OV_CACHE = 'herd:ov_cache';

async function ovLoad() {
    // торішні числа з памʼяті браузера — щоб панелі були видні одразу,
    // а не спалахували порожнечею, поки читаються дані (Роман 2026-09-18)
    if (!OV.length) {
        try {
            const c = JSON.parse(localStorage.getItem(OV_CACHE) || 'null');
            if (c && Array.isArray(c.tiles) && c.tiles.length) {
                OV = c.tiles;
                OV_LAST = c.counts || {};
                ovRender();
            }
        } catch (e) { /* ignore */ }
    }
    const r = await apiGet('/api/herd/overview-tiles');
    OV = (r && r.tiles) || [];
    ovRender();                                  // спершу назви, числа — після читання
    if (COLS === null) await loadColumns();
    const keys = new Set();
    OV.forEach((t) => {
        const q = window.herdQuery.parse(t.formula, PARAMS);
        if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
    });
    const p = new URLSearchParams();
    if (keys.size) p.set('params', [...keys].join(','));
    p.set('lean', '1');
    p.set('status', 'active');            // панелі рахують тих, хто в стаді
    const a = await apiGet('/api/herd/animals?' + p.toString());
    OV_ITEMS = (a && a.items) || [];
    if (a && a.groups) ALL_GROUPS = a.groups;
    ovRender();
    try {                                        // запамʼятовуємо на наступний вхід
        const counts = {};
        OV.forEach((t) => { const n = ovCount(t); if (typeof n === 'number') counts[t.id] = n; });
        OV_LAST = counts;
        localStorage.setItem(OV_CACHE, JSON.stringify({ tiles: OV, counts }));
    } catch (e) { /* ignore */ }
}

function ovCount(t) {
    if (!OV_ITEMS.length) return null;
    const q = window.herdQuery.parse(t.formula, PARAMS);
    if (q.error) return q.error;
    return OV_ITEMS.filter((a) => window.herdQuery.passes(a, q.filters)).length;
}

function ovRender() {
    const box = $('ovGrid');
    if (!box) return;
    if (!OV.length) {
        box.innerHTML = '<div class="ov-hint">Панелей ще немає — натисніть «+ Панель».</div>';
        return;
    }
    const tileHtml = (t) => {
        let n = ovCount(t);
        if (n === null && OV_LAST[t.id] !== undefined) n = OV_LAST[t.id];   // поки читаємо
        const bad = typeof n === 'string';
        // чорний шрифт у темній темі стає світлим (інакше не видно)
        const ink = (c) => (c === '#101418' ? 'var(--ov-ink)' : escapeHtml(c));
        const st = (t.color ? `--sp:${ink(t.color)};` : '')
            + (t.edge ? `--edge:${ink(t.edge)};` : '')
            + (t.bg ? `--spbg:${ovTint(escapeHtml(t.bg))};` : '');
        const c = st ? ` style="${st}"` : '';
        return `<div class="ov-tile" draggable="true" data-id="${escapeHtml(t.id)}"
                data-sec="${escapeHtml(t.section || '')}"${c}
                title="${escapeHtml(t.formula)}">
            <b>${bad ? '—' : (n === null ? '…' : n)}</b>
            <span>${escapeHtml(t.name)}</span>
            <span class="ov-acts">
                <button type="button" data-act="edit" title="Змінити">✎</button>
                <button type="button" data-act="del" title="Прибрати">✕</button>
            </span>
        </div>`;
    };
    // розділи — смугами, у порядку першої появи; без розділу йдуть першими
    const secs = [];
    OV.forEach((t) => {
        const k = (t.section || '').trim();
        let g = secs.find((x) => x.k === k);
        if (!g) { g = { k, list: [] }; secs.push(g); }
        g.list.push(t);
    });
    box.innerHTML = secs.map((g) =>
        (g.k ? `<div class="ov-sec">${escapeHtml(g.k)}</div>` : '')
        + g.list.map(tileHtml).join('')).join('');
    // розділи, які вже є — у підказку поля
    const dl = $('ovSections');
    if (dl) dl.innerHTML = [...new Set(OV.map((t) => (t.section || '').trim()).filter(Boolean))]
        .map((k) => `<option value="${escapeHtml(k)}">`).join('');
}

function ovPaintColors() {
    const cur = { color: OV_COLOR, edge: OV_EDGE, bg: OV_BG };
    document.querySelectorAll('.ov-sw').forEach((b) => {
        const v = cur[b.dataset.for];
        const dflt = b.dataset.for === 'color' ? 'var(--text)'
            : (b.dataset.for === 'edge' ? 'var(--primary)' : 'var(--surface)');
        b.style.background = v ? (b.dataset.for === 'bg' ? ovBgOf(v) : v) : dflt;
    });
}

/* спливна палітра біля зразка */
let OV_PAL_FOR = '';
function ovPalOpen(btn) {
    const box = $('ovPal');
    if (!box) return;
    if (box.parentElement !== document.body) document.body.appendChild(box);
    OV_PAL_FOR = btn.dataset.for;
    const list = OV_PAL_FOR === 'bg' ? OV_PAL_BG : OV_PAL_INK;
    const cur = { color: OV_COLOR, edge: OV_EDGE, bg: ovBgOf(OV_BG) }[OV_PAL_FOR] || '';
    const none = { color: 'звичайний', edge: 'колір гілки', bg: 'без фону' }[OV_PAL_FOR];
    box.innerHTML = `<div class="ov-pal-top">
            <button type="button" class="ov-pal-none" data-pc="">${none}</button>
            <label>свій колір <input type="color" id="ovPalCustom"
                value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#808080'}"></label>
        </div>
        <div class="ov-pal-grid">${list.map((c) =>
            `<button type="button" data-pc="${c}" style="background:${c}"
                ${c.toLowerCase() === cur.toLowerCase() ? 'class="on"' : ''}></button>`).join('')}</div>`;
    box.hidden = false;
    const r = btn.getBoundingClientRect();
    const w = box.offsetWidth, h = box.offsetHeight;
    box.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - w - 8))}px`;
    box.style.top = `${(r.bottom + 6 + h < window.innerHeight) ? r.bottom + 6 : Math.max(8, r.top - h - 6)}px`;
}
function ovPalSet(c) {
    if (OV_PAL_FOR === 'color') OV_COLOR = c;
    else if (OV_PAL_FOR === 'edge') OV_EDGE = c;
    else if (OV_PAL_FOR === 'bg') OV_BG = c;
    ovPaintColors();
}

async function ovSave() {
    const r = await apiSend('/api/herd/overview-tiles', 'POST', { tiles: OV });
    if (!r || r.ok === false) { toast((r && r.error) || 'Не збереглося', 'error'); return false; }
    OV = r.tiles || OV;
    await ovLoad();          // нова панель могла спитати параметр, якого ще не читали
    return true;
}

function awHelpHtml() {
    return '<h4>Як писати</h4>'
        + '<p>Рядок складається з трьох частин — як налаштування списку в календарі: '
        + '<b>BODY</b> (тіло — які параметри показати), <b>FILTER</b> (фільтрація — кого брати), '
        + '<b>VIEW</b> (відображення — як показати). Усередині дужок пишемо через пробіл, '
        + 'параметри — короткими назвами.</p>'
        + '<p><code>=BODY(name group dslh)</code> — колонки таблиці.</p>'
        + '<p><code>FILTER(dslh&gt;=35 rc=4)</code> — добір. Умови: '
        + '<code>=</code> <code>&lt;&gt;</code> <code>&gt;</code> <code>&gt;=</code> '
        + '<code>&lt;</code> <code>&lt;=</code>, ще <code>dslh між 28 35</code>, '
        + '<code>name містить Рай</code>, <code>name не порожньо</code>, '
        + '<code>group=Група-1 або Група-2</code>.</p>'
        + '<p><code>VIEW(no groupby group sort dslh desc avg dslh)</code> — '
        + '<code>no</code> колонка № з/п, <code>groupby &lt;параметр&gt;</code> групи, '
        + '<code>sort &lt;параметр&gt; desc</code> порядок (а <code>groupby group desc</code> '
        + 'перевертає самі групи), '
        + '<code>cnt</code> кількість (сама по собі — голів, з назвою параметра — '
        + 'скільки тварин мають це значення), <code>avg</code> середнє, <code>sum</code> сума, '
        + '<code>min</code> найменше, <code>max</code> найбільше. '
        + 'Числа стають у своїх колонках — у рядку групи й у рядку «Разом»; '
        + 'на одну колонку можна поставити кілька агрегацій, вони стануть поруч. '
        + 'Ширину колонки тягніть за межу заголовка — вона памʼятається. '
        + '«🖨 Друк» — попередній перегляд на A4, як у календарі: аркуш, колонки, '
        + 'шрифт і його розмір.</p>'
        + '<p>Підказка вискакує сама: стрілки <b>↑↓</b> — вибрати, <b>Tab</b> — підтвердити, '
        + '<b>Esc</b> — закрити. <b>Enter</b> — прочитати список за формулою (окремої кнопки немає).</p>'
        + '<p>Після Enter рядок сам набуває акуратного вигляду: дії великими літерами, '
        + 'параметри — короткими назвами, зайві пробіли й коми прибираються.</p>'
        + '<p>Частини пишуться в один рядок одна за одною; будь-яку можна пропустити. '
        + 'Українські слова (ТІЛО, ФІЛЬТРАЦІЯ, ВІДОБРАЖЕННЯ, групувати, сортувати, спад) теж працюють.</p>';
}

function awWordsHtml() {
    const bySec = {};
    PARAMS.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    return '<h4>Параметри з конструктора</h4>'
        + Object.keys(bySec).map((sec) => `<div class="aw-sec"><h4>${escapeHtml(sec)}</h4>`
            + '<div class="aw-words">'
            + bySec[sec].map((p) => `<button type="button" data-w="${escapeHtml(awShort(p))}"`
                + ` title="${escapeHtml(p.label)}">${escapeHtml(awShort(p))}</button>`).join('')
            + '</div></div>').join('');
}

/* коротка назва параметра — нею й пишемо у формулі */
function awShort(p) { return (p.short || p.key || '').trim() || p.label; }

/* кольорова підсвітка формули: дія чорним, усередині — своїми кольорами */
const AW_ACT_RE = /^(body|filter|view|тіло|фільтрація|фільтр|відображення|вигляд|показати|колонки|де|sort|group|groupby)$/i;
const AW_WORD_RE = /^(groupby|sort|no|num|cnt|count|avg|sum|min|max|desc|asc|кількість|середнє|сума|мін|макс|групувати|групи|сортувати|порядок|нумерація|номер|спад|зрост|між|містить|порожньо|не|або)$/i;

/* розфарбований HTML формули — той самий вигляд у рядку й у «Списках» */
function awHlHtml(txt) {
    let out = '';
    // токени: слова, числа, дужки, знаки умов, решта
    const re = /([A-Za-zА-Яа-яЇїІіЄєҐґ_][A-Za-zА-Яа-яЇїІіЄєҐґ_\d.-]*)|(\d+[.,]?\d*)|(>=|<=|<>|!=|≠|≥|≤|=|>|<)|([()[\];,])|(\s+)|(.)/g;
    let m;
    let afterAct = false;                         // одразу після дії йде «(»
    while ((m = re.exec(txt))) {
        const t = m[0];
        const esc = escapeHtml(t);
        if (m[1]) {
            const isAct = AW_ACT_RE.test(t) && txt.slice(re.lastIndex).trimStart().startsWith('(');
            if (isAct) { out += `<span class="k">${esc}</span>`; afterAct = true; }
            else if (AW_WORD_RE.test(t)) out += `<span class="w">${esc}</span>`;
            else if (PARAMS.some((p) => awShort(p).toLowerCase() === t.toLowerCase()
                || (p.label || '').toLowerCase() === t.toLowerCase())) out += `<span class="p">${esc}</span>`;
            else out += `<span class="n">${esc}</span>`;
        } else if (m[2]) out += `<span class="n">${esc}</span>`;
        else if (m[3]) out += `<span class="o">${esc}</span>`;
        else if (m[4]) out += `<span class="b">${esc}</span>`;
        else out += esc;
        void afterAct;
    }
    return out;
}

function awPaint() {
    const hl = $('awHl');
    if (!hl) return;
    const txt = $('awInput').value;
    hl.innerHTML = awHlHtml(txt);
    hl.scrollLeft = $('awInput').scrollLeft;
    if ($('awClear')) $('awClear').hidden = !txt;
}

/* ── підказки під час набору ──────────────────────────────────────────
   Роман 2026-09-18: «немає підказок при вводі». Підказуємо дію, слово
   всередині ВІДОБРАЖЕННЯ і короткі назви параметрів після «[». */
const AW_ACTS = [
    { w: 'BODY', t: 'тіло — які параметри показати' },
    { w: 'FILTER', t: 'фільтрація — кого брати' },
    { w: 'VIEW', t: 'відображення — групи й порядок' },
];
const AW_DISP = [
    { w: 'groupby', t: 'групувати — групи в таблиці' },
    { w: 'sort', t: 'сортувати — порядок рядків' },
    { w: 'no', t: 'нумерація — колонка № з/п' },
    { w: 'cnt', t: 'кількість — усіх або з даними в параметрі' },
    { w: 'avg', t: 'середнє по числовому параметру' },
    { w: 'sum', t: 'сума по числовому параметру' },
    { w: 'min', t: 'найменше значення' },
    { w: 'max', t: 'найбільше значення' },
    { w: 'desc', t: 'спад — від більшого до меншого' },
];
const AW_COND = [
    { w: '>=', t: 'більше або дорівнює' }, { w: '<=', t: 'менше або дорівнює' },
    { w: '<>', t: 'не дорівнює' }, { w: 'між', t: 'між 200 260' },
    { w: 'містить', t: 'частина тексту' }, { w: 'порожньо', t: 'значення немає' },
    { w: 'не порожньо', t: 'значення є' }, { w: 'або', t: 'кілька значень' },
];
let AW_SUG = [], AW_POS = 0, AW_FROM = 0;

/* яка дія відкрита в місці курсора */
function awContext(txt) {
    let open = null, depth = 0;
    const re = /([\p{L}]+)\s*\(|\)/gu;
    let m;
    while ((m = re.exec(txt))) {
        if (m[0] === ')') { depth = Math.max(0, depth - 1); if (!depth) open = null; }
        else { depth += 1; open = (m[1] || '').toLowerCase(); }
    }
    return depth ? open : null;
}

function awParamItems(word, close) {
    return PARAMS.filter((p) => !word
        || awShort(p).toLowerCase().startsWith(word)
        || (p.label || '').toLowerCase().includes(word))
        .map((p) => ({ ins: awShort(p) + (close ? '] ' : ' '), w: awShort(p), t: p.label }));
}

function awSuggest() {
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    const left = el.value.slice(0, at);
    const inBr = left.lastIndexOf('[') > left.lastIndexOf(']');
    let items = [];
    if (inBr) {                                   // назва параметра в дужках
        AW_FROM = left.lastIndexOf('[') + 1;
        items = awParamItems(left.slice(AW_FROM).toLowerCase(), true);
    } else {
        const m = left.match(/[\p{L}\d_<>=№]+$/u);
        AW_FROM = at - (m ? m[0].length : 0);
        const word = (m ? m[0] : '').toLowerCase();
        const ctx = awContext(left);
        if (!ctx) {                               // поза дужками — дія
            items = AW_ACTS.filter((x) => !word || x.w.toLowerCase().startsWith(word))
                .map((x) => ({ ins: x.w + '(', w: x.w, t: x.t }));
        } else if (ctx === 'view' || ctx === 'відображення' || ctx === 'вигляд') {
            const w = AW_DISP.filter((x) => !word || x.w.toLowerCase().startsWith(word))
                .map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t }));
            items = w.concat(awParamItems(word, false));
        } else if (ctx === 'filter' || ctx === 'фільтрація' || ctx === 'фільтр'
                   || ctx === 'де' || ctx === 'відібрати' || ctx === 'вибрати') {
            // після назви параметра підказуємо умову, інакше — назви
            const after = /(\]|[\p{L}\d_]+)\s*$/u.test(left) && !word
                ? AW_COND : (word ? AW_COND.filter((x) => x.w.toLowerCase().startsWith(word)) : AW_COND);
            items = awParamItems(word, false).concat(
                after.map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t })));
        } else {
            items = awParamItems(word, false);
        }
    }
    AW_SUG = items;                               // усі — список гортається
    AW_POS = 0;
    awDrawSug();
}

/* підказка «висить» над сторінкою: панель її обрізала, коли таблиці немає */
function awPlaceSug() {
    const box = $('awSug'), wrap = document.querySelector('.aw-wrap');
    if (!box || !wrap || box.hidden) return;
    const r = wrap.getBoundingClientRect();
    const below = window.innerHeight - r.bottom - 10;
    const above = r.top - 10;
    const up = below < 140 && above > below;     // унизу тісно — відкриваємо вгору
    box.style.left = `${Math.round(r.left)}px`;
    box.style.width = `${Math.round(r.width)}px`;
    box.style.maxHeight = `${Math.min(320, Math.max(120, up ? above : below))}px`;
    box.style.top = up ? '' : `${Math.round(r.bottom + 4)}px`;
    box.style.bottom = up ? `${Math.round(window.innerHeight - r.top + 4)}px` : '';
}

function awDrawSug() {
    const box = $('awSug');
    if (!AW_SUG.length) { box.hidden = true; return; }
    box.innerHTML = AW_SUG.map((x, i) =>
        `<div data-i="${i}"${i === AW_POS ? ' class="on"' : ''}><b>${escapeHtml(x.w)}</b>`
        + `<span>${escapeHtml(x.t)}</span></div>`).join('');
    box.hidden = false;
    awPlaceSug();
}

function awTake(i) {
    const x = AW_SUG[i];
    if (!x) return;
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    el.value = el.value.slice(0, AW_FROM) + x.ins + el.value.slice(at);
    const pos = AW_FROM + x.ins.length;
    el.focus();
    el.selectionStart = el.selectionEnd = pos;
    $('awSug').hidden = true;
    AW_SUG = [];
    awPaint();
    awSuggest();
}

function awInsert(word) {
    const t = $('awInput');
    const at = t.selectionStart === null ? t.value.length : t.selectionStart;
    const before = t.value.slice(0, at), after = t.value.slice(at);
    t.value = before + '[' + word + ']' + after;
    t.focus();
    t.selectionStart = t.selectionEnd = (before + '[' + word + ']').length;
}

function runFormula() {
    const text = $('awInput').value.trim();
    try { localStorage.setItem(AW_KEY, text); } catch (e) { /* ignore */ }
    const msg = $('awMsg');
    // порожній рядок — стада не показуємо (Роман 2026-09-18)
    if (!text) {
        Q = null;
        msg.textContent = 'Наберіть формулу і натисніть Enter.';
        msg.classList.remove('bad');
        $('animTableWrap').hidden = true;
        $('animCount').hidden = true;
        return;
    }
    const q = window.herdQuery.parse(text, PARAMS);
    if (q.error) { msg.textContent = q.error; msg.classList.add('bad'); return; }
    Q = q;
    $('animTableWrap').hidden = false;
    $('animCount').hidden = false;
    // акуратний вигляд: дії великими, без зайвих пробілів, короткі назви
    const tidy = window.herdQuery.format(q, PARAMS);
    // страховка: упорядкований рядок має означати рівно те саме, інакше лишаємо як є
    const same = (x, y) => JSON.stringify([x.cols, x.filters, x.sorts, x.groups, x.aggs, x.rownum])
        === JSON.stringify([y.cols, y.filters, y.sorts, y.groups, y.aggs, y.rownum]);
    if (tidy && tidy !== text && same(q, window.herdQuery.parse(tidy, PARAMS))) {
        $('awInput').value = tidy;
        try { localStorage.setItem(AW_KEY, tidy); } catch (e) { /* ignore */ }
        awPaint();
    }
    msg.classList.remove('bad');
    const need = [...new Set([...(q.cols.length ? q.cols : COLS || []), ...q.keys])];
    const fresh = WORK_CACHE && (Date.now() - WORK_CACHE.at) < CACHE_TTL
        && need.every((k) => WORK_CACHE.keys.has(k));
    const done = () => {
        msg.textContent = LAST_ITEMS.length
            ? `Знайдено ${LAST_ITEMS.length} із ${ALL_ITEMS.length}`
            : `Нікого із ${ALL_ITEMS.length}`;
    };
    if (fresh) {                                   // усе вже прочитано — рахуємо на місці
        ALL_ITEMS = WORK_CACHE.items;
        renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
        done();
        return;
    }
    msg.textContent = 'Читаю…';
    loadList().then(done);
}

/* таблиця так, як вона на екрані: шапка, групи з числами, «Разом» */
function awTableData() {
    const head = (qOn() && Q.rownum ? ['№'] : [])
        .concat(tagInCols() ? [] : [headLabel('tag')])
        .concat(effCols().map(headLabel));
    const rows = [];
    document.querySelectorAll('#animBody tr').forEach((tr) => {
        const kind = tr.classList.contains('anim-grp') ? 'group'
            : (tr.classList.contains('anim-sum') ? 'total' : 'row');
        const cells = [];
        [...tr.cells].forEach((td) => {
            const span = td.colSpan || 1;
            // саме текст: innerHTML лишав «&nbsp;» у розрядах числа
            cells.push((td.textContent || '').replace(/\u00a0/g, ' ').trim());
            for (let i = 1; i < span; i++) cells.push('');
        });
        rows.push({ kind, cells });
    });
    return { head, rows, title: 'Робота зі стадом', formula: $('awInput').value.trim() };
}

async function awXlsx() {
    const btn = $('awXlsx');
    btn.disabled = true;
    try {
        const r = await fetch('/api/herd/export-xlsx', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(awTableData()),
        });
        if (!r.ok) { toast('Не вдалося зібрати файл', 'error'); return; }
        const blob = await r.blob();
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'stado.xlsx';
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    } catch (e) {
        toast('Сервер не відповів', 'error');
    } finally { btn.disabled = false; }
}

/* друк на A4 — як у календарі: спільний модуль herd_print.js */
const AW_PRINT_KEY = 'herd:work_print';
let AW_PRINT = { orient: 'p', twocol: false, font: { family: '', size: 11, bold: false, italic: false } };
try { AW_PRINT = Object.assign(AW_PRINT, JSON.parse(localStorage.getItem(AW_PRINT_KEY) || '{}')); } catch (e) { /* ignore */ }

/* таблиця для друку: та сама шапка й рядки; ширини колонок — як на екрані */
function awPrintHtml() {
    const src = document.getElementById('animTable');
    const ths = [...src.tHead.rows[0].cells];
    const widths = ths.map((th) => Math.max(36, Math.round(th.getBoundingClientRect().width)));
    const total = widths.reduce((t, w) => t + w, 0);
    const colgroup = '<colgroup>' + widths.map((w) => `<col style="width:${w}px">`).join('') + '</colgroup>';
    const head = '<tr>' + ths.map((th) => `<th${th.classList.contains('num') ? ' class="num"' : ''}>`
        + `${escapeHtml(th.textContent.trim())}</th>`).join('') + '</tr>';
    const rows = [...src.tBodies[0].rows].map((tr) => {
        const lv = (tr.className.match(/\bl(\d)\b/) || [])[1] || '0';
        const cls = tr.classList.contains('anim-grp') ? ` class="sec l${lv}"`
            : (tr.classList.contains('anim-sum') ? ' class="tot"' : '');
        return `<tr${cls}>` + [...tr.cells].map((td) => `<td${td.classList.contains('num') ? ' class="num"' : ''}`
            + `${td.colSpan > 1 ? ` colspan="${td.colSpan}"` : ''}>${escapeHtml(td.textContent.trim())}</td>`).join('')
            + '</tr>';
    }).join('');
    return `<table style="width:${total}px">${colgroup}<thead>${head}</thead><tbody>${rows}</tbody></table>`;
}

function awPrint() {
    if (!LAST_ITEMS.length) { toast('Немає що друкувати', 'error'); return; }
    const today = new Date();
    const dmy = `${String(today.getDate()).padStart(2, '0')}.${String(today.getMonth() + 1).padStart(2, '0')}.${today.getFullYear()}`;
    window.herdPrint.open({
        state: AW_PRINT,
        twocolToggle: true,
        content: () => ({
            title: 'Робота зі стадом',
            sub: `${LAST_ITEMS.length} із ${ALL_ITEMS.length} · ${dmy}`,
            body: awPrintHtml(),                       // формулу на папір не виносимо
        }),
        onChange: () => {
            try { localStorage.setItem(AW_PRINT_KEY, JSON.stringify(AW_PRINT)); } catch (e) { /* ignore */ }
        },
    });
}

function awCsv() {
    // те саме, що в Excel: короткі назви колонок, групи й «Разом»
    const d = awTableData();
    const num = (v) => String(v === null || v === undefined ? '' : v)
        .replace(/(\d)[\s\u00a0]+(?=\d)/g, '$1');            // 2 349 → 2349
    const esc = (v) => (/[;"\n]/.test(num(v)) ? '"' + num(v).replace(/"/g, '""') + '"' : num(v));
    const lines = [d.head.map(esc).join(';')]
        .concat(d.rows.map((r) => (r.cells || []).map(esc).join(';')));
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'stado.csv';
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 2000);
}

document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
    b.addEventListener('click', () => setTab(b.dataset.tab)));

/* збереження набраної формули під назвою */
function awSaveWhere(w) {
    SAVE_WHERE = w === 'tile' ? 'tile' : 'list';
    document.querySelectorAll('#awSaveWhere .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.w === SAVE_WHERE));
    const tile = SAVE_WHERE === 'tile';
    $('awSaveCat').hidden = tile;               // список має категорію й коментар,
    $('awSaveNote').hidden = tile;              // панель — розділ, колір і фон
    $('ovSection').hidden = !tile;
    $('ovPickColor').hidden = !tile;
    $('ovPickEdge').hidden = !tile;
    $('ovPickBg').hidden = !tile;
    if (!tile && $('ovPal')) $('ovPal').hidden = true;
    $('awSaveName').placeholder = tile ? 'Назва панелі' : 'Назва списку';
    if (tile) ovPaintColors();
}

function awSaveOpen() {
    const f = $('awInput').value.trim();
    if (!f) { toast('Спершу наберіть формулу', 'error'); return; }
    if (!WCATS.length) wlLoad();
    $('awSaveBox').hidden = false;
    // прийшли з панелі — пропонуємо зберегти назад у панель
    awSaveWhere(OV_CUR && !WCUR ? 'tile' : 'list');
    const cur = WCUR || OV_CUR;
    $('awSaveName').value = cur ? cur.name : '';
    $('ovSection').value = OV_CUR ? (OV_CUR.section || '')
        : (OV.length ? (OV[OV.length - 1].section || '') : '');
    OV_COLOR = OV_CUR ? (OV_CUR.color || '') : '';
    OV_EDGE = OV_CUR ? (OV_CUR.edge || '') : '';
    OV_BG = OV_CUR ? ovBgOf(OV_CUR.bg || '') : '';
    $('awSaveCat').value = WCUR ? (WCUR.category || '') : '';
    $('awSaveNote').value = WCUR ? (WCUR.note || '') : '';
    $('awSaveName').focus();
    $('awSaveName').select();
}

/* зберегти набране панеллю-показником «Огляду» */
async function awSaveTile(name, formula) {
    const paint = { section: $('ovSection').value.trim(), color: OV_COLOR, edge: OV_EDGE, bg: OV_BG };
    if (!OV.length) {
        const r = await apiGet('/api/herd/overview-tiles');
        OV = (r && r.tiles) || [];
    }
    let t = OV.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (t) {
        const own = OV_CUR && String(OV_CUR.id) === String(t.id);
        if (!own && !await confirmAction(`Панель «${name}» уже є. Замінити?`,
            { ok: 'Замінити' })) return;
        Object.assign(t, { name, formula }, paint);
    } else {
        t = Object.assign({ id: 'o' + (Date.now() % 100000), name, formula }, paint);
        OV.push(t);
    }
    const r = await apiSend('/api/herd/overview-tiles', 'POST', { tiles: OV });
    if (!r || r.ok === false) { toast((r && r.error) || 'Не збереглося', 'error'); return; }
    OV = r.tiles || OV;
    OV_CUR = OV.find((x) => x.name === name) || t;
    $('awSaveBox').hidden = true;
    awCurShow();
    toast(`Панель «${name}» збережено`, 'success');
}

async function awSaveDo() {
    const name = $('awSaveName').value.trim();
    const formula = $('awInput').value.trim();
    if (!name) { $('awSaveName').focus(); return; }
    if (!formula) { toast('Спершу наберіть формулу', 'error'); return; }
    if (SAVE_WHERE === 'tile') { await awSaveTile(name, formula); return; }
    if (!WLISTS.length) await wlLoad();
    const fields = { name, formula, category: $('awSaveCat').value, note: $('awSaveNote').value.trim() };
    let L = WLISTS.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (L) {
        // свій же відкритий список зберігається без запитання, чужий однойменний — із ним
        const own = WCUR && String(WCUR.id) === String(L.id);
        if (!own && !await confirmAction(`Список «${name}» уже є. Замінити?`, { ok: 'Замінити' })) return;
        Object.assign(L, fields);
    } else {
        L = Object.assign({ id: 'w' + (WLISTS.length + 1) + '-' + name.slice(0, 8) }, fields);
        WLISTS.push(L);
    }
    if (await wlSave()) {
        $('awSaveBox').hidden = true;
        wlSetCur(WLISTS.find((x) => x.name === name) || L);
        toast(`Список «${name}» збережено`, 'success');
    }
}

/* панелі «Огляду» — колір і фон живуть у вікні збереження «Роботи зі стадом» */
/* палітри шрифту, канта й фону */
document.addEventListener('click', (e) => {
    const sw = e.target.closest('.ov-sw');
    const box = $('ovPal');
    if (sw) {
        e.stopPropagation();
        if (box && !box.hidden && OV_PAL_FOR === sw.dataset.for) { box.hidden = true; return; }
        ovPalOpen(sw);
        return;
    }
    if (!box || box.hidden) return;
    const pc = e.target.closest('#ovPal [data-pc]');
    if (pc) { ovPalSet(pc.dataset.pc); box.hidden = true; return; }
    if (!e.target.closest('#ovPal')) box.hidden = true;
});
document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'ovPalCustom') ovPalSet(e.target.value);
});

/* перетягування панелей: порядок і розділ — куди кинули, там і стоїть */
let OV_DRAG = null;
bind('ovGrid', 'dragstart', (e) => {
    const t = e.target.closest('.ov-tile');
    if (!t) return;
    OV_DRAG = t.dataset.id;
    t.classList.add('dragging');
    try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', OV_DRAG); } catch (er) { /* ignore */ }
});
bind('ovGrid', 'dragover', (e) => {
    if (!OV_DRAG) return;
    const t = e.target.closest('.ov-tile');
    e.preventDefault();
    document.querySelectorAll('#ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('drop-before', 'drop-after'));
    if (!t || t.dataset.id === OV_DRAG) return;
    const r = t.getBoundingClientRect();
    t.classList.add(e.clientX < r.left + r.width / 2 ? 'drop-before' : 'drop-after');
});
bind('ovGrid', 'dragend', () => {
    OV_DRAG = null;
    document.querySelectorAll('#ovGrid .dragging, #ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('dragging', 'drop-before', 'drop-after'));
});
bind('ovGrid', 'drop', async (e) => {
    e.preventDefault();
    const target = e.target.closest('.ov-tile');
    const id = OV_DRAG;
    OV_DRAG = null;
    if (!target || !id || target.dataset.id === id) { ovRender(); return; }
    const after = target.classList.contains('drop-after');
    const moved = OV.find((x) => String(x.id) === String(id));
    const dest = OV.find((x) => String(x.id) === String(target.dataset.id));
    if (!moved || !dest) return;
    OV = OV.filter((x) => x !== moved);
    moved.section = dest.section || '';        // кинули в інший розділ — туди й переїхала
    const at = OV.indexOf(dest) + (after ? 1 : 0);
    OV.splice(at, 0, moved);
    ovRender();
    await ovSave();
});
bind('ovSection', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('ovGrid', 'click', async (e) => {
    const tile = e.target.closest('.ov-tile');
    if (!tile) return;
    const t = OV.find((x) => String(x.id) === String(tile.dataset.id));
    if (!t) return;
    const act = (e.target.closest('[data-act]') || {}).dataset;
    if (act && act.act === 'edit') {         // правити — у «Роботі зі стадом»
        ovOpenInWork(t);
        setTimeout(awSaveOpen, 300);
        return;
    }
    if (act && act.act === 'del') {
        const ok = await confirmAction(`Прибрати панель «${t.name}»?`,
            { ok: 'Прибрати', okClass: 'btn-danger' });
        if (!ok) return;
        OV = OV.filter((x) => x !== t);
        await ovSave();
        return;
    }
    ovOpenInWork(t);                        // клік по панелі — показати самих тварин
});

function ovOpenInWork(t) {
    $('awInput').value = t.formula;
    try { localStorage.setItem(AW_KEY, t.formula); } catch (er) { /* ignore */ }
    WCUR = null;
    OV_CUR = t;
    awCurShow();
    setTab('work');
    awPaint();
}

bind('awSaveWhere', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awSaveWhere(b.dataset.w);
});
bind('awSave', 'click', awSaveOpen);
bind('awSaveOk', 'click', awSaveDo);
bind('awSaveCancel', 'click', () => { $('awSaveBox').hidden = true; });
bind('awSaveName', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('awSaveNote', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
});

/* добір у «Списках» */
bind('wlSearch', 'input', wlRender);
bind('wlCat', 'change', wlRender);

/* дії над збереженими списками */
bind('animLists', 'click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const row = b.closest('.wl-row');
    const L = WLISTS.find((x) => String(x.id) === String(row.dataset.id));
    if (!L) return;
    if (b.dataset.act === 'open') { wlOpen(L); return; }
    if (b.dataset.act === 'rename') {
        const span = row.querySelector('.wl-name');
        if (row.querySelector('input')) return;
        const inp = document.createElement('input');
        inp.className = 'aw-namein';
        inp.value = L.name;
        inp.maxLength = 80;
        span.replaceWith(inp);
        inp.focus();
        inp.select();
        const done = async (save) => {
            const v = inp.value.trim();
            if (save && v) { L.name = v; await wlSave(); } else wlRender();
        };
        inp.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') done(true);
            if (ev.key === 'Escape') done(false);
        });
        inp.addEventListener('blur', () => done(true));
        return;
    }
    if (b.dataset.act === 'del') {
        const ok = await confirmAction(`Видалити список «${L.name}»?`,
            { ok: 'Видалити', okClass: 'btn-danger' });
        if (!ok) return;
        if (WCUR && WCUR.id === L.id) wlSetCur(null);
        WLISTS = WLISTS.filter((x) => x !== L);
        await wlSave();
    }
});

/* рядок формули: підсвітка, підказки, Enter */
bind('awInput', 'input', () => { awPaint(); awSuggest(); });   // підказка вискакує сама
bind('awInput', 'scroll', () => { $('awHl').scrollLeft = $('awInput').scrollLeft; });
bind('awInput', 'keyup', awPaint);
bind('awInput', 'click', awSuggest);
bind('awInput', 'focus', awSuggest);
bind('awInput', 'blur', () => setTimeout(() => { $('awSug').hidden = true; }, 150));
bind('awInput', 'keydown', (e) => {
    const open = AW_SUG.length && !$('awSug').hidden;
    if (open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        AW_POS = (AW_POS + (e.key === 'ArrowDown' ? 1 : AW_SUG.length - 1)) % AW_SUG.length;
        awDrawSug();
        return;
    }
    // Tab — підтвердити вибір із підказки
    if (e.key === 'Tab' && open) { e.preventDefault(); awTake(AW_POS); return; }
    if (e.key === 'Escape') { $('awSug').hidden = true; AW_SUG = []; return; }
    // Enter — прочитати список за формулою
    if (e.key === 'Enter') {
        e.preventDefault();
        $('awSug').hidden = true; AW_SUG = [];
        runFormula();
    }
});
window.addEventListener('scroll', awPlaceSug, true);
window.addEventListener('resize', awPlaceSug);
bind('awClear', 'click', () => {
    const el = $('awInput');
    el.value = '';
    awPaint();
    runFormula();                                  // таблиця ховається, рядок чистий
    el.focus();
    awSuggest();
});
bind('awSug', 'mousedown', (e) => {
    const d = e.target.closest('[data-i]');
    if (d) { e.preventDefault(); awTake(+d.dataset.i); }
});
bind('awHelpBtn', 'click', () => { $('awHelp').hidden = !$('awHelp').hidden; });
bind('awWordsBtn', 'click', () => { $('awWords').hidden = !$('awWords').hidden; });
bind('awCsv', 'click', awCsv);
bind('awXlsx', 'click', awXlsx);
bind('awPrint', 'click', awPrint);
bind('awWords', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awInsert(b.dataset.w);
});

// підказка живе в <body>: у панелі є transform, а він ловить position:fixed
if ($('awSug')) document.body.appendChild($('awSug'));

restoreFilters();
try { $('awInput').value = localStorage.getItem(AW_KEY) || ''; } catch (e) { /* ignore */ }
awPaint();
loadList().then(() => {
    $('awHelp').innerHTML = awHelpHtml();
    $('awWords').innerHTML = awWordsHtml();
    // перехід на «Головну» — завжди «Огляд» (Роман 2026-09-19); оновлення
    // чи «назад» лишають вкладку, на якій людина була в цьому візиті
    let t = 'reg', nav = 'navigate';
    try { nav = (performance.getEntriesByType('navigation')[0] || {}).type || 'navigate'; } catch (e) { /* ignore */ }
    if (nav === 'reload' || nav === 'back_forward') {
        try { t = sessionStorage.getItem('herd:anim_tab') || 'reg'; } catch (e) { t = 'reg'; }
    }
    // посилання з формулою (напр. зі сторінки «Перевірка») — одразу ці тварини
    const fq = new URLSearchParams(location.search).get('f');
    if (fq) {
        $('awInput').value = fq;
        try { localStorage.setItem(AW_KEY, fq); } catch (e) { /* ignore */ }
        history.replaceState(null, '', location.pathname);   // оновлення не повторює
        t = 'work';
        awPaint();
    }
    setTab(t);                      // «Огляд» теж має свою розкладку (панелі)
});

// «⚙ Колонки» — спільний компонент гілки (herd_colpicker.js)
if ($('animCols') && window.herdColPicker) {
    herdColPicker({
        button: $('animCols'),
        params: () => PARAMS,
        hide: ['tag'],
        selected: () => COLS || [],
        onToggle: (k, on) => {
            if (on) { if (!COLS.includes(k)) COLS.push(k); }
            else COLS = COLS.filter((x) => x !== k);
            saveCols();
            // значень нового параметра в завантаженому списку ще немає
            const first = LAST_ITEMS[0];
            const missing = on && !CORE_COLS[k] && first
                && !Object.prototype.hasOwnProperty.call(first.p || {}, k);
            if (missing) loadList(); else renderTable(LAST_ITEMS);
        },
    });
}

/* Перемикач «Живі · Вибулі · Усі» у смужці гілки має рухати й саму таблицю:
   інакше вгорі написано одне, а в списку інше (Роман 2026-09-16 просив
   перевірити перемикач на всіх сторінках стада). */
window.herdRegistry = {
    reload() {
        let f = null;
        try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
        if (!f) return;
        $('animSearch').value = f.q || '';
        $('animStatus').value = f.status || '';
        $('animSex').value = f.sex || '';
        $('animGroup').value = f.group_id || '';
        return loadList();
    },
};

/* ---------- Нумерація приплоду ----------
   Роман 2026-09-16: «номер він іде похідний, а довгий номер UA він є
   основний» + «1-й варіант + перемикач на останній найбільший». Тож
   рахуємо довгий номер, а бирка — його хвіст; правило обирається тут. */
(function () {
    const box = $('animNumBox');
    if (!box) return;
    let CFG = {};

    const q = (id) => $(id);
    const setMode = (m) => {
        CFG.mode = (m === 'max') ? 'max' : 'counter';
        $('animNumMode').querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.m === CFG.mode));
        // у режимі «найбільший» лічильник не потрібен — програма дивиться в базу
        $('animNumNextWrap').style.opacity = CFG.mode === 'max' ? '.45' : '';
        $('animNumNext').disabled = CFG.mode === 'max';
        $('animNumHint').textContent = CFG.mode === 'max'
            ? 'Бере найбільший номер із цим префіксом і додає одиницю. Чужі серії не враховуються, але випадково великий номер зсуне нумерацію.'
            : 'Свій лічильник: не збивається ні імпортом архіву, ні купленою твариною з чужим номером. Після кожного отелу зсувається сам.';
        $('animNumHint').textContent += ' Бирка — не коротша за 5 знаків: чотиризначні номери лишаються вільними для нашийників дійних корів.';
        preview();
    };

    async function preview() {
        try {
            const r = await apiGet('/api/herd/next-uin');
            $('animNumPrev').innerHTML = (r && r.ok && r.uin)
                ? `${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))}: <b>${escapeHtml(r.uin)}</b> · ${escapeHtml(herdLabel('tag', 'Номер тварини'))}: <b>${escapeHtml(r.tag || '')}</b>`
                : 'номер поки нема від чого рахувати';
        } catch (e) { $('animNumPrev').textContent = ''; }
    }

    async function load() {
        const r = await apiGet('/api/herd/calf-numbering');
        CFG = (r && r.ok && r.cfg) || {};
        $('animNumPrefix').value = CFG.prefix || '';
        $('animNumNext').value = CFG.next || '';
        $('animNumTagLen').value = CFG.tag_len || '';
        setMode(CFG.mode);
    }

    $('animNumBtn') && $('animNumBtn').addEventListener('click', () => {
        box.hidden = !box.hidden;
        if (!box.hidden) load();
    });
    $('animNumMode').addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (b) setMode(b.dataset.m);
    });
    $('animNumSave').addEventListener('click', async () => {
        const r = await apiSend('/api/herd/calf-numbering', 'POST', {
            mode: CFG.mode,
            prefix: $('animNumPrefix').value.trim(),
            next: $('animNumNext').value.trim(),
            tag_len: $('animNumTagLen').value.trim(),
        });
        if (!r.ok) {
            toast(r.error || 'Помилка', 'error');
            $('animNumTagLen').focus(); $('animNumTagLen').select();
            return;
        }
        CFG = r.cfg || CFG;
        toast('Збережено', 'success');
        preview();
    });
})();
