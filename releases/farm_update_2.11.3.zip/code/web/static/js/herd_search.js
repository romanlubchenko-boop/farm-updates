/* ============ Центральний пошук тварини ============
   Роман 2026-09-15: «центральне поле пошуку тварин по різним критеріям —
   номер, кличка, номер UIN, транспондер». Живе в шапці всіх сторінок
   гілки стада: набрав будь-який із номерів → вибрав → картка тварини.

   Що саме шукається, вирішує конструктор параметрів (галочка «шукати»),
   тож завтрашній «номер чипа» запрацює без правки коду. */
(function () {
    const box = document.getElementById('hSearch');
    if (!box) return;                       // не гілка стада — модуль мовчить
    const inp = document.getElementById('hSearchInp');
    const list = document.getElementById('hSearchList');
    let items = [];
    let hot = 0;
    let timer = null;
    let seq = 0;                            // відповіді можуть прийти не в тому порядку

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
        (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

    const SEX = { F: '♀', M: '♂' };
    // у стаді — без позначки; показуємо лише тих, кого вже немає

    function render() {
        if (!items.length) {
            list.innerHTML = '<div class="hs-empty">Нічого не знайшли</div>';
            list.hidden = false;
            return;
        }
        list.innerHTML = items.map((a, i) => {
            // назва статусу — з конструктора (сервер віддає її разом із твариною)
            const st = (a.status && a.status !== 'active') ? String(a.status_label || a.status).toLowerCase() : '';
            // показуємо, ЧИМ збіглося: інакше незрозуміло, чому знайшлась
            // саме ця тварина (шукали транспондер — бачимо бирку)
            const hit = (a.hit_label && !a.hit_is_tag)
                ? `<span class="hs-hit">${esc(a.hit_label)}: ${esc(a.hit_value)}</span>` : '';
            return `<div class="hs-row${i === hot ? ' hot' : ''}" data-i="${i}">
                <span class="hs-tag">${esc(a.tag)}</span>
                <span class="hs-sex hs-${a.sex === 'M' ? 'm' : 'f'}">${SEX[a.sex] || ''}</span>
                <span class="hs-name">${esc(a.name || '')}</span>
                ${hit}
                <span class="hs-grp">${esc(a.group_name || '')}</span>
                ${st ? `<span class="hs-st">${esc(st)}</span>` : ''}
            </div>`;
        }).join('');
        list.hidden = false;
        list.querySelectorAll('.hs-row').forEach((r) => {
            r.onclick = () => go(items[+r.dataset.i]);
        });
    }

    function go(a) {
        if (!a) return;
        close();
        if (window.herdNav) window.herdNav.setCurrent(a);
        if (window.herdCardGo) { window.herdCardGo(a.id); return; }  // вже на картці
        location.href = '/herd/animals/' + a.id;   // окрема сторінка картки
    }

    function close() { list.hidden = true; items = []; hot = 0; }

    async function search(q) {
        const my = ++seq;
        try {
            const r = await fetch('/api/herd/search?q=' + encodeURIComponent(q),
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            if (my !== seq) return;          // прийшла відповідь на старіший запит
            items = (d && d.items) || [];
            hot = 0;
            render();
        } catch (e) { /* мережа впала — просто не показуємо підказок */ }
    }

    inp.addEventListener('input', () => {
        const q = inp.value.trim();
        clearTimeout(timer);
        if (q.length < 1) { close(); return; }
        timer = setTimeout(() => search(q), 180);
    });

    inp.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { close(); inp.blur(); return; }
        if (list.hidden || !items.length) return;
        if (e.key === 'ArrowDown') { hot = Math.min(hot + 1, items.length - 1); render(); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { hot = Math.max(hot - 1, 0); render(); e.preventDefault(); }
        else if (e.key === 'Enter') { e.preventDefault(); go(items[hot]); }
    });

    inp.addEventListener('focus', () => { if (items.length) list.hidden = false; });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#hSearch')) close();
    });
    // Ctrl/Cmd+K — стати в пошук із будь-якого місця гілки
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault(); inp.focus(); inp.select();
        }
    });
})();


/* ============ Перемикач тварин «◄ ►» ============
   Роман 2026-09-15: «додай перемикач вправо вліво, де можна перейти на іншу
   тварину, ніби як перемикач дат, тільки тварин» + «перемикати по вибраним
   фільтрам». Тож гортання йде тим самим списком, що показує реєстр: обмежив
   секцією чи статусом — гортаєш саме їх, а не все стадо.

   Поточна тварина живе між сторінками (localStorage): відкрив картку з
   календаря — і на «Русі поголів'я» перемикач уже показує її. */
(function () {
    const bar = document.getElementById('hNav');
    if (!bar) return;                       // не гілка стада — модуль мовчить
    const prevBtn = document.getElementById('hNavPrev');
    const nextBtn = document.getElementById('hNavNext');
    const curEl = document.getElementById('hNavCur');
    const scopeEl = document.getElementById('hNavScope');

    const CUR_KEY = 'herd:current';         // {id, tag, name} останньої тварини
    const FLT_KEY = 'herd:filters';         // фільтри реєстру (пише herd_animals.js)

    let list = [];
    let cur = null;                         // {id, tag, name}

    const jget = (store, key) => {
        try { return JSON.parse(store.getItem(key) || 'null'); } catch (e) { return null; }
    };
    const jset = (store, key, val) => {
        try { store.setItem(key, JSON.stringify(val)); } catch (e) { /* повне сховище */ }
    };

    const FLT_KEYS = ['q', 'status', 'sex', 'group_id'];

    function filters() {
        return jget(localStorage, FLT_KEY) || {};
    }

    function query() {
        const f = filters();
        const p = new URLSearchParams();
        FLT_KEYS.forEach((k) => { if (f[k]) p.set(k, f[k]); });
        return p.toString();
    }

    /* Назва вибірки, якою гортаємо: щоб людина бачила, ЧОМУ наступна саме ця
       (а не дивувалась, що з 1943 тварин стрілка веде через одну). */
    function scopeName() {
        const f = filters();
        const parts = [];
        if (f.group_id) parts.push(f.group_name
            || (window.herdLabel ? herdLabel('group', 'група') : 'група').toLowerCase());
        if (f.status) parts.push(f.status_name || 'статус');
        if (f.sex) parts.push(f.sex === 'M' ? '♂' : '♀');
        if (f.q) parts.push('«' + f.q + '»');
        return parts.join(' · ');
    }

    function idx() {
        if (!cur) return -1;
        return list.findIndex((a) => String(a.id) === String(cur.id));
    }

    function render() {
        const i = idx();
        if (cur) {
            // номер — окремим елементом, щоб виділити його кольором
            curEl.textContent = '';
            if (cur.tag) {
                const t = document.createElement('b');
                t.className = 'hnav-tag';
                t.textContent = cur.tag;
                curEl.appendChild(t);
                // нерозривний пробіл: у flex-полі звичайний на краю тексту зникає
                if (cur.name) curEl.appendChild(document.createTextNode('\u00a0· ' + cur.name));
            } else {
                curEl.textContent = '…';    // бирка ще не приїхала
            }
            curEl.href = '/herd/animals/' + cur.id;
            curEl.classList.remove('is-empty');
        } else {
            curEl.textContent = 'оберіть тварину';
            curEl.removeAttribute('href');
            curEl.classList.add('is-empty');
        }
        const scope = scopeName();
        if (list.length) {
            // тварина поза вибіркою — кажемо про це прямо, інакше незрозуміло,
            // чому немає позиції і куди поведе стрілка
            const where = (cur && i < 0) ? ' · поза вибіркою' : '';
            scopeEl.textContent = (i >= 0 ? (i + 1) + ' / ' : '') + list.length
                + (scope ? ' · ' + scope : '') + where;
        } else {
            scopeEl.textContent = '';
        }
        const none = !list.length;
        prevBtn.disabled = none;
        nextBtn.disabled = none;
    }

    async function loadList() {
        const qs = query();
        const key = 'herd:navlist:' + qs;
        const hit = jget(sessionStorage, key);
        if (hit && hit.length !== undefined) { list = hit; render(); return; }
        try {
            const r = await fetch('/api/herd/animals/nav?' + qs,
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            list = (d && d.items) || [];
            jset(sessionStorage, key, list);
        } catch (e) { list = []; }
        render();
    }

    /* Крок стрілкою. Тварина поза поточною вибіркою (фільтри змінили після
       того, як її відкрили) — заходимо з краю: «◄» на останню, «►» на першу. */
    function step(d) {
        if (!list.length) return;
        const i = idx();
        let n;
        if (i < 0) n = d > 0 ? 0 : list.length - 1;
        else n = (i + d + list.length) % list.length;
        const a = list[n];
        if (!a) return;
        cur = { id: a.id, tag: a.tag, name: a.name };
        jset(localStorage, CUR_KEY, cur);
        // на самій картці міняємо ЛИШЕ її вміст: перезавантаження сторінки
        // заради сусідньої тварини гасило екран і тягло всю обгортку заново
        if (window.herdCardGo) { render(); window.herdCardGo(a.id); return; }
        location.href = '/herd/animals/' + a.id;
    }

    prevBtn.addEventListener('click', () => step(-1));
    nextBtn.addEventListener('click', () => step(1));

    /* Перемикач «Живі · Вибулі · Усі» — кого гортати стрілками. Пише в ті
       самі фільтри, що й реєстр, тож добір скрізь один. «Вибулі» це не
       один статус, а всі, крім тих, що в стаді, — сервер знає слово gone. */
    const live = document.getElementById('hLive');
    function markLive() {
        if (!live) return;
        const cur = (filters().status || '');
        live.querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', (b.dataset.s || '') === cur));
    }
    if (live) {
        live.addEventListener('click', (e) => {
            const b = e.target.closest('.seg-btn');
            if (!b) return;
            const f = filters();
            f.status = b.dataset.s || '';
            f.status_name = b.textContent.trim();
            if (!f.status) delete f.status_name;
            jset(localStorage, FLT_KEY, f);
            markLive();
            // панель добору спершу приймає новий вибір у свої поля, і лише
            // потім обидві сторони читають список — інакше вона перепише
            // його старим
            // сторінки, що показують власний список тварин (панель добору
            // на картці, таблиця реєстру), спершу приймають новий вибір —
            // інакше вони лишаються зі старим фільтром або переписують
            // спільний список
            const others = [window.herdSide, window.herdRegistry]
                .filter((x) => x && x.reload).map((x) => x.reload());
            Promise.all(others).then(loadList, loadList);
        });
        markLive();
    }

    // Поточна тварина: сторінка картки задає її сама, решта — з памʼяті.
    const m = location.pathname.match(/^\/herd\/animals\/(\d+)/);
    if (m) {
        const id = parseInt(m[1], 10);
        const was = jget(localStorage, CUR_KEY);
        cur = (was && String(was.id) === String(id)) ? was : { id: id, tag: '', name: '' };
        jset(localStorage, CUR_KEY, cur);
    } else {
        cur = jget(localStorage, CUR_KEY);
    }
    render();

    // Список даємо іншим модулям оновлювати (реєстр уже має свіжі дані —
    // навіщо питати сервер удруге) і дізнаватись, кого зараз гортаємо.
    window.herdNav = {
        setCurrent(a) {
            if (!a || !a.id) return;
            cur = { id: a.id, tag: a.tag || '', name: a.name || '' };
            jset(localStorage, CUR_KEY, cur);
            render();
        },
        /* Кого картка має підвезти наперед: сусіди зліва й справа. */
        neighbours(id) {
            const i = list.findIndex((a) => String(a.id) === String(id));
            if (i < 0) return [];
            const n = list.length;
            return [list[(i + 1) % n], list[(i - 1 + n) % n]]
                .filter(Boolean).map((a) => a.id)
                .filter((x) => String(x) !== String(id));
        },
        cacheList(items) {
            list = (items || []).map((a) => ({ id: a.id, tag: a.tag, name: a.name }));
            jset(sessionStorage, 'herd:navlist:' + query(), list);
            render();
        },
        reload: loadList,
    };

    loadList().then(async () => {
        // Підпис картки, відкритої прямим посиланням. Бирку беремо зі списку,
        // а якщо тварини там немає (вона поза вибіркою) — питаємо сервер.
        // ⚠️ Без цього в полі світився ВНУТРІШНІЙ номер запису і читався як
        // номер тварини — груба підміна: 1011 замість бирки 20204.
        if (!cur || cur.tag) return;
        const a = list.find((x) => String(x.id) === String(cur.id));
        if (a) { window.herdNav.setCurrent(a); return; }
        try {
            const r = await fetch('/api/herd/animals/' + cur.id,
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            if (d && d.tag) window.herdNav.setCurrent({ id: cur.id, tag: d.tag, name: d.name });
        } catch (e) { /* не дісталися — краще без підпису, ніж чужий номер */ }
    });
})();
