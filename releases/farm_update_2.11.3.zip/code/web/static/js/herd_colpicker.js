/* «⚙ Колонки» гілки стада — один компонент для групового вводу й реєстру.
   Роман 2026-09-17: «таке саме налаштування колонок» спершу в останніх
   подіях, потім у груповому вводі й у реєстрі. Колонки тут — параметри
   тварини (їх десятки), тож список з пошуком і розділами конструктора.

   herdColPicker({
     button,                 — кнопка, під якою відкривається список
     params,                 — [{key, label, section, formula}] або функція, що
                               їх повертає (параметри часто вантажаться пізніше)
     extra,                  — [{key, label}] колонки поза параметрами (кличка…)
     hide,                   — ключі, яких не пропонувати (напр. номер тварини)
     selected: () => [...],  — поточні видимі колонки
     onToggle: (key, on) => void,
   }) → {open, close} */
'use strict';
window.herdColPicker = function (opts) {
    const norm = (s) => String(s || '').toLowerCase().replace(/[\s ]+/g, '');
    const hide = new Set(opts.hide || []);
    let pop = null;

    function close() {
        if (pop) { pop.remove(); pop = null; }
    }

    function place() {
        const r = opts.button.getBoundingClientRect();
        pop.style.top = `${window.scrollY + r.bottom + 4}px`;
        // правим краєм до кнопки: вона зазвичай праворуч у рядку
        const w = pop.offsetWidth;
        const left = Math.min(window.scrollX + r.right - w,
            window.scrollX + document.documentElement.clientWidth - w - 8);
        pop.style.left = `${Math.max(8, left)}px`;
    }

    function open() {
        close();
        document.querySelectorAll('.hf-pop').forEach((x) => x.remove());
        pop = document.createElement('div');
        pop.className = 'hf-pop hf-colpop';
        pop.innerHTML = `<div class="hf-poptitle">Видимі колонки</div>
            <input type="search" class="hf-q" placeholder="пошук параметра…">
            <div class="hf-poplist"></div>
            <div class="hf-popfoot"><button type="button" class="hg-mini" data-a="done">Готово</button></div>`;
        document.body.appendChild(pop);
        const listEl = pop.querySelector('.hf-poplist');
        const item = (key, label, extra) => `<label class="hf-opt">
            <input type="checkbox" data-k="${escapeHtml(key)}"${opts.selected().includes(key) ? ' checked' : ''}>
            <span>${escapeHtml(label)}</span>${extra || ''}</label>`;
        const draw = () => {
            const q = norm(pop.querySelector('.hf-q').value);
            const ex = (opts.extra || []).filter((c) => !q || norm(c.label).includes(q));
            const params = (typeof opts.params === 'function' ? opts.params() : opts.params) || [];
            const avail = params.filter((pr) => !hide.has(pr.key)
                && !(opts.extra || []).some((c) => c.key === pr.key)
                && (!q || norm(`${pr.label} ${pr.short || ''}`).includes(q)));
            const bySec = new Map();
            avail.forEach((pr) => {
                const sec = pr.section || 'Інше';
                if (!bySec.has(sec)) bySec.set(sec, []);
                bySec.get(sec).push(pr);
            });
            listEl.innerHTML = (ex.map((c) => item(c.key, c.label)).join('')
                + [...bySec.entries()].map(([sec, arr]) => `<div class="hf-sec">${escapeHtml(sec)}</div>`
                    + arr.map((pr) => item(pr.key, pr.label,
                        pr.formula ? '<i class="hf-calc">обчислюється</i>' : '')).join('')).join(''))
                || '<div class="hf-none">Нічого не знайдено</div>';
        };
        listEl.addEventListener('change', (e) => {
            const k = e.target.dataset.k;
            if (k) opts.onToggle(k, e.target.checked);
        });
        pop.querySelector('.hf-q').addEventListener('input', draw);
        pop.querySelector('[data-a="done"]').addEventListener('click', close);
        draw();
        place();
        setTimeout(() => { if (pop) pop.querySelector('.hf-q').focus(); }, 20);
    }

    opts.button.addEventListener('click', (e) => {
        e.stopPropagation();
        if (pop) close(); else open();
    });
    document.addEventListener('click', (e) => {
        if (pop && !pop.contains(e.target) && e.target !== opts.button) close();
    });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    return { open, close };
};
