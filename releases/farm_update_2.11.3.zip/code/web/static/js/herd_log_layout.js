/* Вигляд сторінки внесення подій.
   Схему задає адміністратор у конструкторі («Як це побачить оператор»),
   вона одна на ферму — тут її лише застосовуємо. */
'use strict';
(function () {

const layout = document.getElementById('lgLayout');
if (!layout) return;

const zone = (n) => layout.querySelector(`.lg-zone[data-zone="${n}"]`);

function setWidth(p, pct) {
    const v = Math.max(20, Math.min(100, parseFloat(pct) || 100));
    // без власної ширини панель займає ВЕСЬ ряд — наступна стає під нею.
    // Щоб дві стояли поруч, ширину задають обом (напр. 30% і 70%).
    p.style.flex = (v >= 100) ? '1 1 100%' : `0 0 ${v}%`;
}

(async function load() {
    let lay = null;
    try {
        const r = await apiGet('/api/herd/ui-layout');
        if (r && r.ok) lay = r.layout;
    } catch (_) { /* схеми немає — типовий вигляд */ }
    if (!lay) return;

    const all = {};
    layout.querySelectorAll('[data-panel]').forEach((p) => { all[p.dataset.panel] = p; });
    // у старих схемах була окрема панель «animal» — тепер це поле всередині форми
    ['left', 'right', 'wide'].forEach((n) => {
        ((lay.zones && lay.zones[n]) || []).forEach((k) => {
            if (all[k]) zone(n).appendChild(all[k]);
        });
    });

    const hid = new Set(lay.hidden || []);
    const W = lay.width || {};
    layout.querySelectorAll('[data-panel]').forEach((p) => {
        p.classList.toggle('is-hidden', hid.has(p.dataset.panel));
        setWidth(p, W[p.dataset.panel] || 100);
    });

    // ширина окремих полів форми
    const FW = lay.fields || {};
    const applyFields = () => {
        document.querySelectorAll('#lgInputs .hp-fl[data-field]').forEach((f) => {
            const w = FW[f.dataset.field] || 50;
            f.style.flex = `0 0 calc(${w}% - 6px)`;
        });
        // рядок приплоду: ширину мають параметри події «Народження»
        document.querySelectorAll('#lgCalves .cf-x[data-field]').forEach((x) => {
            const w = FW[x.dataset.field];
            if (w) x.style.flex = `0 0 calc(${w}% - 6px)`;
        });
    };
    applyFields();
    // поля перемальовуються при зміні події — застосовуємо ширину знову
    const box = document.getElementById('lgInputs');
    if (box) new MutationObserver(applyFields).observe(box, { childList: true });
    const calves = document.getElementById('lgCalves');
    if (calves) new MutationObserver(applyFields).observe(calves, { childList: true });

    if (lay.split) {
        const v = Math.max(25, Math.min(78, parseFloat(lay.split)));
        layout.style.setProperty('--lg-left', v + 'fr');
        layout.style.setProperty('--lg-right', (100 - v) + 'fr');
    }
})();
})();
