"""Звʼязок із сервером, який переживає збій DNS (Роман 2026-09-19).

19.09 реєстратор на кілька годин підмінив адресу домену bovio.pro, а після
відновлення провайдери ферм ще годину віддавали стару адресу — ПК ферми
падали з «[WinError 10061] … actively refused». Сервер при цьому працював.

Тут — заміна urllib.request.urlopen для запитів до наших серверів. Коли
з'єднання не вдалося через мережу (не через відповідь сервера), пробуємо:
  1. адресу домену, взяту напряму в Cloudflare/Google (DNS через HTTPS —
     повз провайдера й роутер ферми);
  2. останню адресу, з якою обмін працював (збережена на диску — рятує,
     коли домен підмінено скрізь);
  3. запасний домен (*.bovio.pro → *.bovio.app).
Сертифікат перевіряється за іменем домену, як і завжди, тож чужий сервер
на підставленій адресі не пройде — безпека та сама, що й без обходу.
"""
from __future__ import annotations

import http.client
import ipaddress
import json
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

_STORE = Path(__file__).resolve().parent / "config" / "net_hosts.json"
_LOCK = threading.Lock()
_DOH_TTL = 300            # відповідь DNS через HTTPS памʼятаємо 5 хв
_SEEN_EVERY = 600         # «робочу» адресу переписуємо не частіше, ніж раз на 10 хв
_doh_cache: dict[str, tuple[float, list[str]]] = {}
_seen_at: dict[str, float] = {}
_ALT = ((".bovio.pro", ".bovio.app"),)
_DOH = (
    ("https://1.1.1.1/dns-query?type=A&name=", {"Accept": "application/dns-json"}),
    ("https://8.8.8.8/resolve?type=A&name=", {"Accept": "application/json"}),
)


def _log(msg: str) -> None:
    try:
        print(f"[net] {msg}", flush=True)
    except Exception:  # noqa: BLE001
        pass


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _load() -> dict:
    try:
        return json.loads(_STORE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _save(host: str, ip: str) -> None:
    with _LOCK:
        d = _load()
        if (d.get(host) or {}).get("ip") == ip:
            return
        d[host] = {"ip": ip, "at": time.strftime("%Y-%m-%d %H:%M:%S")}
        try:
            _STORE.parent.mkdir(parents=True, exist_ok=True)
            tmp = _STORE.with_suffix(".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(_STORE)
        except Exception:  # noqa: BLE001
            pass


def _sys_ips(host: str) -> list[str]:
    try:
        return list(dict.fromkeys(
            a[4][0] for a in socket.getaddrinfo(host, 443, socket.AF_INET, socket.SOCK_STREAM)))
    except Exception:  # noqa: BLE001
        return []


def _remember(host: str) -> None:
    """Обмін пройшов звичайним шляхом — запамʼятати адресу, на яку ходили."""
    now = time.time()
    if now - _seen_at.get(host, 0) < _SEEN_EVERY:
        return
    _seen_at[host] = now
    ips = _sys_ips(host)
    if ips:
        _save(host, ips[0])


def _doh(host: str, context) -> list[str]:
    hit = _doh_cache.get(host)
    if hit and time.time() - hit[0] < _DOH_TTL:
        return hit[1]
    out: list[str] = []
    for base, hdrs in _DOH:
        try:
            req = urllib.request.Request(base + urllib.parse.quote(host), headers=hdrs)
            with urllib.request.urlopen(req, timeout=6, context=context) as r:
                ans = json.loads(r.read().decode("utf-8", "replace")).get("Answer") or []
            # обидва сервіси: вузол одного може ще тримати стару адресу
            out += [a["data"] for a in ans if a.get("type") == 1 and _is_ip(a.get("data", ""))]
        except Exception:  # noqa: BLE001
            continue
    out = list(dict.fromkeys(out))
    _doh_cache[host] = (time.time(), out)
    return out


class _PinnedHTTPS(urllib.request.HTTPSHandler):
    """HTTPS на задану адресу; імʼя сервера (SNI, перевірка сертифіката,
    заголовок Host) лишається доменним."""

    def __init__(self, ip: str, context):
        super().__init__(context=context)
        self._ip = ip

    def https_open(self, req):
        ip = self._ip

        def conn(host, **kw):
            c = http.client.HTTPSConnection(host, **kw)
            c._create_connection = (lambda addr, timeout=socket._GLOBAL_DEFAULT_TIMEOUT,
                                    source_address=None:
                                    socket.create_connection((ip, addr[1]), timeout,
                                                             source_address))
            return c
        return self.do_open(conn, req, context=self._context)


def _open_pinned(req, ip: str, timeout, context):
    return urllib.request.build_opener(_PinnedHTTPS(ip, context)).open(req, timeout=timeout)


def _net_error(exc: BaseException) -> bool:
    """Мережева невдача (адреса, з'єднання, чужий сертифікат) — не відповідь сервера."""
    if isinstance(exc, urllib.error.HTTPError):
        return False
    return isinstance(exc, (urllib.error.URLError, OSError, http.client.HTTPException))


def _with_host(req, host: str):
    p = urllib.parse.urlsplit(req.full_url)
    netloc = host + (f":{p.port}" if p.port else "")
    r = urllib.request.Request(urllib.parse.urlunsplit(p._replace(netloc=netloc)),
                               data=req.data, method=req.get_method())
    for k, v in req.header_items():
        if k.lower() != "host":
            r.add_header(k, v)
    return r


def _bypass(req, host: str, timeout, context, why):
    """Повз системний DNS: адреса з Cloudflare/Google, далі остання робоча.
    None — жодна не підійшла. HTTPError (відповів справжній сервер) — наверх."""
    bad = set(_sys_ips(host))
    tried: set[str] = set()
    last_ip = (_load().get(host) or {}).get("ip") or ""
    for how, ips in (("DNS через HTTPS", lambda: _doh(host, context)),
                     ("остання робоча адреса", lambda: [last_ip] if last_ip else [])):
        for ip in ips():
            if ip in tried or ip in bad:
                continue
            tried.add(ip)
            try:
                resp = _open_pinned(req, ip, timeout, context)
            except urllib.error.HTTPError:
                raise
            except Exception:  # noqa: BLE001
                continue
            _log(f"{host}: звичайна адреса не відповідає ({why}), "
                 f"з'єдналися через {how} → {ip}")
            _save(host, ip)
            return resp
    return None


def _open_host(req, host: str, timeout, context):
    """Звичайний шлях, а при мережевій невдачі — обхід DNS."""
    try:
        resp = urllib.request.urlopen(req, timeout=timeout, context=context)
        _remember(host)
        return resp
    except Exception as exc:  # noqa: BLE001
        if not _net_error(exc) or _is_ip(host) \
                or not req.full_url.lower().startswith("https:"):
            raise
        resp = _bypass(req, host, timeout, context, exc)
        if resp is None:
            raise
        return resp


def urlopen(req, timeout: float = 30, context=None):
    """Як urllib.request.urlopen, але з обходом збою DNS (див. опис модуля).
    Помилку сервера (HTTPError) віддає як є — обходимо лише мережу."""
    if isinstance(req, str):
        req = urllib.request.Request(req)
    if context is None:
        context = ssl.create_default_context()
    host = urllib.parse.urlsplit(req.full_url).hostname or ""
    try:
        return _open_host(req, host, timeout, context)
    except Exception as exc:  # noqa: BLE001
        if not _net_error(exc) or not host:
            raise
        first = exc
    for a, b in _ALT:                          # запасний домен — теж повз DNS
        if host.endswith(a):
            alt = host[: -len(a)] + b
            try:
                resp = _open_host(_with_host(req, alt), alt, timeout, context)
            except Exception:  # noqa: BLE001
                continue
            _log(f"{host}: з'єдналися через запасний домен {alt}")
            return resp
    raise first
