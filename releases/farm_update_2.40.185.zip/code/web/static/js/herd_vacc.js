/* ВАКЦИНАЦІЯ ЗА СХЕМАМИ — ОДИН РАХУНОК ДЛЯ СТОРІНКИ «ЗДОРОВ’Я» І ДЛЯ СПИСКІВ (Роман 2026-10-01: «прописувати схему
   вакцинації й впроваджувати в списки»).
   📌 У мові списків — віртуальний параметр `vacc` («Вакцинація зараз»): кроки схем, які тварині зараз у своєму вікні й
      ще не проведені. `FILTER(vacc=[Хіпра 1])` — кому зараз «Хіпра 1»; `BODY(… vacc)` — колонка «крок (препарат · доза)».
   📌 Проведено — подія «Вакцинація»: зі сторінки «Здоров’я» вона несе крок (__vstep); внесена деінде (груповий ввід,
      картка) зараховується кроку, якщо препарат той самий і дата — у вікні кроку ± 7 днів.
   📌 Дані — /api/herd/vacc (схеми, подія, проведені); на старті — з памʼяті браузера, потім свіжі, і подія
      «herdvacc:ready» — сторінка перераховує списки. */
'use strict';
(function () {
/* 📌 КРОК — ЛИШЕ РЯДОК ФОРМУЛИ (Роман 2026-10-01: «всі дані фільтрація від строки формул… прибрати від чого рахувати;
      залишити крок, препарат, доза, активний/неактивний»): `st.fx` = FILTER(…) мовою списків, напр.
      FILTER(lact=0 rc<9 days_life between 49 55). Зараз — тварина підходить під формулу й крок у ЦЬОМУ вікні ще не проведено.
      Вікно — суцільні дні, коли тварина підходить: лічильники днів (параметри з DAYS(TODAY(), …): дні життя, DIM, дні тільності…)
      зсуваються на ±N днів, місяці (MONTHS(TODAY(), …)) — від своєї дати; решта значень — як сьогодні. Так рахуються
      «скоро» (підійде за ≤14 дн.) і «прострочено» (вікно закінчилось ≤30 дн. тому, а не проведено).
   📌 Давні кроки (base/from/to — до 2.40.173) — як були, доки їх не перепишуть формулою (fxOfLegacy дає готову, коли може). */
/* «від чого рахувати» — параметр-дата (Роман 2026-10-01: «від чого рахувати — потрібно вводити параметр») або попередній
   крок; дні від’ємні — до дати (за 60–45 днів до очікуваного отелу: з -60 по -45). Давні схеми (age/calving/due/dryoff)
   читаються як відповідні параметри. */
const LEGACY = { age: 'birth_date', calving: 'last_calving', due: 'expected_calving', dryoff: 'last_dryoff' };
function normStep(st) {
    if (!st || !LEGACY[st.base]) return st;
    const k = LEGACY[st.base];
    return st.base === 'due' ? Object.assign(st, { base: k, from: -st.to, to: -st.from }) : Object.assign(st, { base: k });
}
/* активний / неактивний — на кожен крок (Роман 2026-10-01); давня схема «на паузі» — усі її кроки неактивні */
const normSchemes = (list) => {
    (list || []).forEach((sc) => {
        (sc.steps || []).forEach(normStep);
        if (sc.off) { (sc.steps || []).forEach((st) => { st.off = 1; }); sc.off = 0; }
    });
    return list || [];
};
const whoText = (w) => { const t = String(w || '').trim(); return /^FILTER\s*\(/i.test(t) ? t : (t ? `FILTER(${t})` : ''); };
const LATE_MAX = 30, SOON_MAX = 14, NEAR = 7;
let SOON = SOON_MAX, LATE = LATE_MAX;       // LATE — «прострочено — за 30 · 60 · 90 дн.» (Роман 2026-10-01)
try {
    const hs = JSON.parse(localStorage.getItem('herd:health_state') || 'null');
    if (hs && +hs.soon) SOON = Math.max(1, Math.min(60, +hs.soon));
    if (hs && +hs.late) LATE = Math.max(1, Math.min(180, +hs.late));
} catch (e) { /* ignore */ }                             // «скоро» — підійде протягом SOON днів (сторінка «Здоров’я» перемикає 7 · 14 · 30)
const MEM = 'herd:vacc';
let SCHEMES = [], EVENT = null, BY_STEP = new Map(), BY_STEP_ALL = new Map(), BY_DRUG = new Map(), DONE_RAW = [];
let paramsOf = () => [];
const MEMO = new Map();                          // id тварини → {t, v}
const QMEMO = new Map();                         // умова «кого» → розбір

const parseD = (s) => { const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null; };
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const sk = (sc, st) => `${sc.id}:${st.id}`;
const norm = (s) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');

function setData(d) {
    SCHEMES = normSchemes((d && d.schemes) || []);
    EVENT = (d && d.event) || null;
    setDone((d && d.done) || []);
}
function setSchemes(list) { SCHEMES = normSchemes(list); QMEMO.clear(); MEMO.clear(); }
function setDone(done) {
    DONE_RAW = done || [];
    BY_STEP = new Map(); BY_STEP_ALL = new Map(); BY_DRUG = new Map();
    done.forEach((x) => {
        if (x.s) {                               // останнє проведення кроку в тварини
            const k = x.a + '|' + x.s;
            if (!BY_STEP.has(k) || BY_STEP.get(k) < x.d) BY_STEP.set(k, x.d);
            if (!BY_STEP_ALL.has(k)) BY_STEP_ALL.set(k, []);
            BY_STEP_ALL.get(k).push(x.d);
        }
        if (x.g) {
            const k = x.a + '|' + norm(x.g);
            if (!BY_DRUG.has(k)) BY_DRUG.set(k, []);
            BY_DRUG.get(k).push(x.d);
        }
    });
    MEMO.clear();
}

function whoQ(sc) {
    const w = whoText(sc.who);
    if (!w) return { filters: [], keys: [] };
    const key = w + '\u0001' + paramsOf().length;
    if (!QMEMO.has(key)) {
        const q = window.herdQuery.parse(w, paramsOf());
        // «кого» через саму вакцинацію — коло, не рахуємо
        QMEMO.set(key, q.error ? q : (q.keys.some((k) => /^vacc(_late|_soon)?$/.test(k)) ? { error: 'умова «Кого» не може містити vacc' } : q));
    }
    return QMEMO.get(key);
}
/* формула кроку → розбір (лише FILTER; vacc у ній — коло) */
function stepQ(st) {
    const f = String(st.fx || '').trim();
    if (!f) return { error: 'формула кроку порожня' };
    const key = 'S\u0001' + f + '\u0001' + paramsOf().length;
    if (!QMEMO.has(key)) {
        const q = window.herdQuery.parse(f, paramsOf());
        QMEMO.set(key, q.error ? q : (q.keys.some((k) => /^vacc(_late|_soon)?$/.test(k)) ? { error: 'формула кроку не може містити vacc' } : q));
    }
    return QMEMO.get(key);
}
/* які параметри рухаються з днями: DAYS(TODAY(), X) — +1 на день; MONTHS(TODAY(), X) — з дати X */
let SHIFT = null;
function shiftMap() {
    if (SHIFT && SHIFT.n === paramsOf().length) return SHIFT.m;
    const m = new Map();
    const byShort = new Map();
    paramsOf().forEach((p) => { byShort.set(String(p.short || p.key).toLowerCase(), p.key); byShort.set(String(p.key).toLowerCase(), p.key); });
    paramsOf().forEach((p) => {
        const f = String(p.formula || '');
        if (/DAYS\s*\(\s*TODAY\s*\(\s*\)/i.test(f)) m.set(p.key, { t: 'd', cond: /^\s*=?\s*IF\s*\(/i.test(f) });
        const mm = f.match(/MONTHS\s*\(\s*TODAY\s*\(\s*\)\s*,\s*([\w.]+)\s*\)/i);
        if (mm) m.set(p.key, { t: 'm', b: byShort.get(mm[1].toLowerCase()) || '' });
    });
    SHIFT = { n: paramsOf().length, m };
    return m;
}
/* тварина «через k днів» (k < 0 — у минулому): зсуваються лише лічильники днів і місяців */
function shifted(a, k, keys) {
    if (!k) return a;
    const sm = shiftMap();
    const p = Object.assign({}, a.p);
    keys.forEach((key) => {
        const s = sm.get(key);
        if (!s) return;
        const raw = p[key];
        if (raw === '' || raw === null || raw === undefined) return;
        const n = parseFloat(String(raw).replace(',', '.'));
        if (!Number.isFinite(n)) return;
        if (s.t === 'd') { if (!(s.cond && n === 0)) p[key] = String(n + k); return; }
        const bd = parseD(s.b ? p[s.b] || (s.b === 'birth_date' ? a.birth_date : '') : '');
        if (!bd) { p[key] = String(n + Math.trunc(k / 30.44)); return; }
        const d2 = addD(today(), k);
        let mo = (d2.getFullYear() - bd.getFullYear()) * 12 + d2.getMonth() - bd.getMonth();
        if (d2.getDate() < bd.getDate()) mo -= 1;
        p[key] = String(Math.max(mo, 1));
    });
    return { id: a.id, birth_date: a.birth_date, p, pl: a.pl };
}
/* лічильник, яким тварина входить у крок (Роман 2026-10-01: «не розумію суть вікна» → показувати вік і межі кроку):
   [{key, label, t: d|m, now, lo, hi}] — з умов формули кроку на параметри, що ростуть із днями (DAYS/MONTHS від TODAY) */
function counterOf(a, st) {
    const q = stepQ(st);
    if (q.error) return [];
    const sm = shiftMap();
    const num = (x) => { const v = parseFloat(String(x === undefined || x === null ? '' : x).replace(',', '.')); return Number.isFinite(v) ? v : null; };
    const by = new Map();
    (q.filters || []).forEach((f) => {
        if (!sm.has(f.key)) return;
        const r = by.get(f.key) || { lo: null, hi: null };
        const v = num(f.v);
        if (f.op === 'between') { r.lo = v; r.hi = num(f.v2); } else if (f.op === 'ge') r.lo = v; else if (f.op === 'gt') r.lo = v === null ? null : v + 1;
        else if (f.op === 'le') r.hi = v; else if (f.op === 'lt') r.hi = v === null ? null : v - 1; else if (f.op === 'eq') { r.lo = v; r.hi = v; } else return;
        by.set(f.key, r);
    });
    return [...by].map(([key, r]) => {
        const p = paramsOf().find((x) => x.key === key) || {};
        return { key, label: p.label || key, t: sm.get(key).t, now: num(a.p ? a.p[key] : null), lo: r.lo, hi: r.hi };
    });
}
const matchOn = (a, q, k) => window.herdQuery.passes(shifted(a, k, q.keys || []), q.filters);
/* вікно, у якому тварина підходить у день k: [від, до] днів відносно сьогодні */
const movable = (q) => (q.keys || []).some((k) => shiftMap().has(k));
function runAt(a, q, k) {
    if (!movable(q)) return [k - 400, k + 400];   // без лічильників днів — підходить «завжди»
    let lo = k, hi = k;
    while (lo > k - 400 && matchOn(a, q, lo - 1)) lo -= 1;
    while (hi < k + 400 && matchOn(a, q, hi + 1)) hi += 1;
    return [lo, hi];
}
/* проведено в цьому вікні: за кроком (__vstep) або тим самим препаратом; ±7 дн. від меж вікна */
function doneIn(a, sc, st, t, lo, hi) {
    const from = addD(t, lo - NEAR), to = addD(t, hi + NEAR);
    const inside = (d) => { const x = parseD(d); return x && x >= from && x <= to; };
    const tagged = BY_STEP_ALL.get(a.id + '|' + sk(sc, st)) || [];
    if (tagged.some(inside)) return true;
    return !!(st.drug && (BY_DRUG.get(a.id + '|' + norm(st.drug)) || []).some(inside));
}
/* ПРОСТРОЧКА — ЛИШЕ ПІСЛЯ ДАТИ «ДІЄ З» (Роман 2026-10-01: «прострочка — від дати створення схеми»): крок, межі якого минули
   до того, як схему завели, не прострочений — його тоді ще не було кому проводити. Без дати — як доти (давні схеми) */
const endedBefore = (sc, st, w2) => { const d = parseD((st && st.start) || (sc && sc.start)); return !!(d && w2 < d); };   // «діє з» — на кожен крок (давні — дата схеми)
function fxState(a, sc, st, t0) {
    const q = stepQ(st);
    if (q.error) return null;
    const k0 = diff(t0, today());                  // Календар питає про інший день
    if (matchOn(a, q, k0)) {
        const [lo, hi] = runAt(a, q, k0);
        if (doneIn(a, sc, st, today(), lo, hi)) return null;
        return { st: 'now', w1: addD(today(), lo), w2: addD(today(), hi), n: 0 };
    }
    if (!movable(q)) return null;
    for (let i = 1; i <= LATE; i++) {              // вікно минуло (до LATE днів тому), а не проведено
        if (matchOn(a, q, k0 - i)) {
            const [lo, hi] = runAt(a, q, k0 - i);
            // проведено будь-коли від початку кроку й досі (і запізно) — уже не прострочено
            if (doneIn(a, sc, st, today(), lo, Math.max(hi, 0))) return null;
            if (endedBefore(sc, st, addD(today(), hi))) return null;    // межі кроку минули ще до того, як схема діє
            return { st: 'late', w1: addD(today(), lo), w2: addD(today(), hi), n: i };
        }
    }
    for (let i = 1; i <= SOON; i++) {          // підійде незабаром
        if (matchOn(a, q, k0 + i)) {
            const [lo, hi] = runAt(a, q, k0 + i);
            return { st: 'soon', w1: addD(today(), lo), w2: addD(today(), hi), n: i };
        }
    }
    return null;
}
/* давній крок (дата + дні) → формула, коли є лічильник днів від тієї дати (дні життя від дати народження, DIM від отелу) */
function fxOfLegacy(sc, st) {
    if (st.fx || !st.base || st.base === 'step') return st.fx || '';
    const bp = paramsOf().find((p) => p.key === st.base);
    if (!bp) return '';
    const bs = String(bp.short || bp.key).toLowerCase();
    const cnt = paramsOf().find((p) => new RegExp(`^\\s*=?\\s*DAYS\\s*\\(\\s*TODAY\\s*\\(\\s*\\)\\s*,\\s*${bs.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\)\\s*$`, 'i').test(p.formula || ''));
    if (!cnt) return '';
    const who = String(sc.who || '').trim();
    return `FILTER(${who ? who + ' ' : ''}${cnt.short || cnt.key} between ${st.from} ${st.to})`;
}
function deps() {
    const ks = new Set(['birth_date']);
    SCHEMES.forEach((sc) => {
        const q = whoQ(sc);
        (q.keys || []).forEach((k) => ks.add(k));
        (sc.steps || []).forEach((st) => {
            if (st.fx) { (stepQ(st).keys || []).forEach((k) => ks.add(k)); return; }
            if (st.base && st.base !== 'step') ks.add(st.base);
        });
    });
    // з чого рахуються місяці (вік) — дата теж потрібна
    const sm = shiftMap();
    [...ks].forEach((k) => { const s = sm.get(k); if (s && s.b) ks.add(s.b); });
    return [...ks];
}
function baseOf(a, sc, st) {
    if (st.base === 'step') {
        const prev = sc.steps.find((x) => x.id === st.prev);
        const d = prev && doneOn(a, sc, prev);
        return d ? parseD(d) : null;
    }
    return parseD((a.p || {})[st.base] || (st.base === 'birth_date' ? a.birth_date : ''));
}
/* вікно кроку для тварини: [w1, w2] або null */
function windowOf(a, sc, st) {
    const b = baseOf(a, sc, st);
    if (!b) return null;
    return { b, w1: addD(b, st.from), w2: addD(b, st.to) };
}
/* дата, коли крок проведено (останнє проведення), або '' */
function doneOn(a, sc, st) {
    const tagged = BY_STEP.get(a.id + '|' + sk(sc, st)) || '';
    if (tagged) return tagged;
    if (!st.drug || st.base === 'step') return '';
    const ds = BY_DRUG.get(a.id + '|' + norm(st.drug));
    if (!ds) return '';
    const w = windowOf(a, sc, st);
    if (!w) return '';
    const lo = addD(w.w1, -NEAR), hi = addD(w.w2, NEAR);
    return ds.filter((d) => { const x = parseD(d); return x && x >= lo && x <= hi; }).sort().pop() || '';
}
/* до якого кроку належить проведена вакцинація ev {a, s, d, g}: за кроком (__vstep) або за препаратом і вікном ±7 дн. */
function stepOf(a, ev) {
    if (ev.s) {
        for (const sc of SCHEMES) for (const st of sc.steps) if (sk(sc, st) === ev.s) return { sc, st };
        return null;
    }
    const d = parseD(ev.d);
    if (!d || !ev.g) return null;
    for (const sc of SCHEMES) {
        for (const st of sc.steps) {
            if (!st.drug || norm(st.drug) !== norm(ev.g)) continue;
            if (st.fx) {                              // подія — у вікні кроку (±7 дн.)
                const q = stepQ(st);
                if (q.error) continue;
                const k = diff(d, today());
                for (let j = -NEAR; j <= NEAR; j++) if (matchOn(a, q, k + j)) return { sc, st };
                continue;
            }
            if (st.base === 'step') continue;
            const w = windowOf(a, sc, st);
            if (w && d >= addD(w.w1, -NEAR) && d <= addD(w.w2, NEAR)) return { sc, st };
        }
    }
    return null;
}
/* стан кроку: null — не стосується; {st: now|late|soon, x, w1, w2, n} */
function stateOf(a, sc, st, t0) {
    if (st.fx) return fxState(a, sc, st, t0);
    const w = windowOf(a, sc, st);
    if (!w) return null;
    const done = doneOn(a, sc, st);
    if (done) {
        const dd = parseD(done);
        // від дати народження — раз на життя; від іншої дати — у цьому вікні (ця лактація, цей запуск, ця тільність)
        if (st.base === 'birth_date' || (dd && dd >= addD(w.w1, -LATE_MAX))) return null;
    }
    const x = diff(t0, w.b);                      // днів від дати (від’ємне — ще до неї)
    if (t0 < w.w1) { const n = diff(w.w1, t0); return n <= SOON ? { st: 'soon', x, w1: w.w1, w2: w.w2, n } : null; }
    if (t0 > w.w2) { const n = diff(t0, w.w2); return n <= LATE && !endedBefore(sc, st, w.w2) ? { st: 'late', x, w1: w.w1, w2: w.w2, n } : null; }
    return { st: 'now', x, w1: w.w1, w2: w.w2, n: 0 };
}
/* ДЕНЬ ПРОВЕДЕННЯ (Роман 2026-10-01): у кроку — дні тижня (1 пн … 7 нд); кому час — рахуємо на найближчий такий день
   від сьогодні (сьогодні такий — сьогодні). Без днів — щодня. */
const wdOf = (d) => ((d.getDay() + 6) % 7) + 1;
function dayOf(st, from) {
    const t = from || today();
    const ds = st.days || [];
    if (!ds.length) return t;
    for (let i = 0; i < 7; i++) { const d = addD(t, i); if (ds.includes(wdOf(d))) return d; }
    return t;
}
/* кроки тварини в стані kind (now — для vacc, late — для vacc_late): [{sc, st}] */
function stepsIn(a, kind) {
    const t0 = (a.__vday && parseD(a.__vday)) || today();   // Календар питає й про інший день
    const mk = kind + '|' + a.id + '|' + (+t0);
    const m = MEMO.get(mk);
    if (m && m.p === a.p) return m.v;
    const out = [];
    SCHEMES.forEach((sc) => {
        if (!sc.steps.some((st) => !st.off)) return;
        const q = whoQ(sc);
        const whoOk = !q.error && window.herdQuery.passes(a, q.filters);
        sc.steps.forEach((st) => {
            if (st.off) return;                       // неактивний крок — не рахується
            if (!st.fx && !whoOk) return;             // давній крок — ще й «Кого» схеми
            // Календар — на свій день (__vday); список — на найближчий день проведення кроку (як «До вакцинації»)
            const s = stateOf(a, sc, st, a.__vday ? t0 : dayOf(st, t0));
            if (s && s.st === kind) out.push({ sc, st });
        });
    });
    if (MEMO.size > 20000) MEMO.clear();
    MEMO.set(mk, { p: a.p, v: out });
    return out;
}
const nowSteps = (a) => stepsIn(a, 'now');
const lateSteps = (a) => stepsIn(a, 'late');
const soonSteps = (a) => stepsIn(a, 'soon');
const stepLab = (x) => x.st.name + ([x.st.drug, x.st.dose].filter(Boolean).length
    ? ` (${[x.st.drug, x.st.dose].filter(Boolean).join(' · ')})` : '');
const stepChoices = () => {
    const seen = new Set();
    return SCHEMES.flatMap((sc) => sc.steps.filter((st) => !st.off).map((st) => st.name))
        .filter((n) => !seen.has(n) && seen.add(n)).map((n) => ({ value: n, label: n }));
};

window.herdQuery.virtual('vacc', {
    param: { key: 'vacc', label: 'Вакцинація зараз', short: 'vacc', dtype: 'text', virtual: true,
        get choices() { return stepChoices(); } },
    deps,
    val: (a) => nowSteps(a).map((x) => x.st.name),
    lab: (a) => nowSteps(a).map(stepLab).join('; '),
});
/* vacc_late (Роман 2026-10-01): кроки, межі яких минули (до LATE днів тому — перемикач на «Здоров’ї», і вже після «діє з» кроку), а не проведено */
window.herdQuery.virtual('vacc_late', {
    param: { key: 'vacc_late', label: 'Вакцинація прострочена', short: 'vacc_late', dtype: 'text', virtual: true,
        get choices() { return stepChoices(); } },
    deps,
    val: (a) => lateSteps(a).map((x) => x.st.name),
    lab: (a) => lateSteps(a).map(stepLab).join('; '),
});
/* vacc_soon (Роман 2026-10-01): кроки, до яких тварина дійде протягом межі «скоро» (7 · 14 · 30 дн. — та сама, що на «Здоров’ї»
   в цьому браузері) */
window.herdQuery.virtual('vacc_soon', {
    param: { key: 'vacc_soon', label: 'Вакцинація скоро', short: 'vacc_soon', dtype: 'text', virtual: true,
        get choices() { return stepChoices(); } },
    deps,
    val: (a) => soonSteps(a).map((x) => x.st.name),
    lab: (a) => soonSteps(a).map(stepLab).join('; '),
});

let LOADING = null;
function load() {
    if (!LOADING) {
        LOADING = (async () => {
            const r = await apiGet('/api/herd/vacc').catch(() => null);
            if (!r || !r.ok) return false;
            setData(r);
            try { localStorage.setItem(MEM, JSON.stringify({ schemes: r.schemes, event: r.event, done: r.done })); } catch (e) { /* ignore */ }
            document.dispatchEvent(new CustomEvent('herdvacc:ready'));
            return r;
        })().finally(() => { LOADING = null; });
    }
    return LOADING;
}
try { const m = JSON.parse(localStorage.getItem(MEM) || 'null'); if (m) setData(m); } catch (e) { /* ignore */ }

window.herdVacc = {
    use(cfg) { if (cfg && cfg.params) { paramsOf = cfg.params; QMEMO.clear(); MEMO.clear(); SHIFT = null; } },
    setSoon(n) { SOON = Math.max(1, Math.min(60, +n || SOON_MAX)); MEMO.clear(); }, soon: () => SOON,
    setLate(n) { LATE = Math.max(1, Math.min(180, +n || LATE_MAX)); MEMO.clear(); }, late: () => LATE,
    load, setData, setSchemes, setDone, whoQ, stepQ, deps, stateOf, windowOf, doneOn, nowSteps, lateSteps, soonSteps, stepOf, counterOf, fxOfLegacy, dayOf, wdOf,
    done: () => DONE_RAW,
    schemes: () => SCHEMES, event: () => EVENT, sk, normSchemes, whoText, LATE_MAX, SOON_MAX,
};
}());
