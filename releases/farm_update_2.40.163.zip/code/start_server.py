"""Лаунчер веб-сервера ветаптеки.

Що робить:
1. Перевіряє, чи встановлений Flask (якщо ні — пропонує встановити).
2. Знаходить вільний порт (за замовчуванням 5000, якщо зайнятий — 5001…).
3. Запускає Flask-сервер у поточному процесі.
4. Через 1 секунду автоматично відкриває браузер на головній сторінці.

Запуск:
    python3 start_server.py            # 127.0.0.1, авто-порт, відкрити браузер
    python3 start_server.py --host 0.0.0.0 --port 8080
    python3 start_server.py --no-browser
"""

from __future__ import annotations

import argparse
import atexit
import os
import signal
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path


HERE = Path(__file__).resolve().parent

# На Windows консоль/пайп часто у cp1251/cp866 — друк українських рядків і
# рамки Unicode валив би сервер (UnicodeEncodeError). Переводимо вивід у UTF-8
# з errors="replace", щоб жоден print ніколи не зупиняв запуск.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        pass


def _local_state_dir() -> Path:
    """Локальна папка стану (поза OneDrive) — та сама, де жива база."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "FarmDB"


# PID-файл тримаємо локально (а не в OneDrive), щоб запис був надійний.
PID_FILE = _local_state_dir() / "server.pid"
# Стара локація PID (у OneDrive) — щоб новий старт прибрав і інстанси,
# запущені до переходу на локальний PID-файл.
LEGACY_PID_FILE = HERE / "data" / "server.pid"


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        # На Windows os.kill(pid, 0) ненадійний (кидає WinError 6 / SystemError).
        # Перевіряємо через ctypes: відкриваємо процес і дивимось код виходу.
        try:
            import ctypes
            STILL_ACTIVE = 259
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        except Exception:        # noqa: BLE001 — будь-що → вважаємо мертвим
            return False
    try:
        os.kill(pid, 0)          # POSIX: сигнал 0 — лише перевірка існування
    except ProcessLookupError:
        return False
    except PermissionError:
        return True              # існує, але не наш — вважаємо живим
    except Exception:            # noqa: BLE001
        return False
    return True


def _kill_pid_from(pid_file: Path) -> None:
    """Гасить процес, записаний у вказаному PID-файлі (якщо живий і не наш)."""
    try:
        pid = int((pid_file.read_text(encoding="utf-8") or "0").strip())
    except (OSError, ValueError):
        return
    if pid == os.getpid() or not _pid_alive(pid):
        return
    print(f"ℹ  Зупиняю попередній сервер (PID {pid})…")
    sig_kill = getattr(signal, "SIGKILL", signal.SIGTERM)
    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):                 # до ~3 с на коректне завершення
            time.sleep(0.1)
            if not _pid_alive(pid):
                break
        else:
            os.kill(pid, sig_kill)          # не вийшов — примусово
    except Exception:                       # noqa: BLE001 — старт не має падати
        pass


def _stop_previous() -> None:
    """Гасить попередні інстанси сервера (якщо живі), щоб не плодити копії.
    Саме накопичення паралельних серверів давало «привидні» помилки старої
    версії коду після правок. Перевіряємо і новий (локальний), і старий
    (OneDrive) PID-файли."""
    _kill_pid_from(PID_FILE)
    if LEGACY_PID_FILE.resolve() != PID_FILE.resolve():
        _kill_pid_from(LEGACY_PID_FILE)


def _write_pid() -> None:
    """Запис PID-файлу, щоб «Зупинити сервер» / новий запуск знайшов процес."""
    try:
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass


def _remove_pid() -> None:
    try:
        PID_FILE.unlink()
    except OSError:
        pass


def ensure_dependencies() -> None:
    """Перевіряє, чи встановлені Flask + waitress + openpyxl.
    Якщо чогось бракує — пропонує встановити через pip із requirements.txt."""
    missing = []
    for name in ("flask", "waitress", "openpyxl", "cryptography", "segno"):
        try:
            __import__(name)
        except ImportError:
            missing.append(name)
    if not missing:
        return

    print(f"⚠  Не встановлено: {', '.join(missing)}")
    req = HERE / "requirements.txt"

    # Чи є інтерактивний термінал? Якщо ні (запуск значком/у фоні) — ставимо
    # автоматично, без запитань (інакше input() падає з EOFError).
    interactive = bool(getattr(sys.stdin, "isatty", lambda: False)())
    if interactive:
        answer = input("Встановити автоматично через pip? [Y/n] ").strip().lower()
        if answer not in ("", "y", "yes", "т", "так"):
            print("Завершую. Встановіть залежності і запустіть знову:")
            print(f"    {sys.executable} -m pip install -r requirements.txt")
            sys.exit(1)
    else:
        print("Встановлюю потрібні бібліотеки автоматично (одноразово)…")

    cmd = [sys.executable, "-m", "pip", "install", "-r", str(req)]
    print("→", " ".join(cmd))
    result = subprocess.run(cmd)
    if result.returncode != 0:
        # Повтор для «externally-managed» Python (Homebrew / PEP 668)
        print("ℹ  Повторюю з --break-system-packages…")
        result = subprocess.run(cmd + ["--break-system-packages"])
    if result.returncode != 0:
        print("✗  Не вдалося встановити залежності. Спробуйте вручну:")
        print(f"    {sys.executable} -m pip install -r {req}")
        sys.exit(1)


def find_free_port(preferred: int, host: str = "127.0.0.1", max_tries: int = 20) -> int:
    """Шукає вільний порт починаючи з preferred.
    Використовує SO_REUSEADDR — щоб після Ctrl+C порт, що ще не вийшов
    з TIME_WAIT (~30-240 c у різних ОС), не лічився «зайнятим». На активний
    сервер SO_REUSEADDR не дозволяє binditись, тож безпечно."""
    for offset in range(max_tries):
        port = preferred + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"Не знайшов вільний порт у діапазоні {preferred}..{preferred + max_tries}")


def open_browser_later(url: str, delay: float = 1.0) -> None:
    def _open() -> None:
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception as exc:  # noqa: BLE001
            print(f"(не вдалося відкрити браузер: {exc})")

    threading.Thread(target=_open, daemon=True).start()


def _lan_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return ""


def _reexec_arm64_if_rosetta() -> None:
    """На Apple Silicon під Rosetta (процес x86_64) перезапускаємось нативно
    arm64 — щоб завантажувалась установлена arm64-криптобібліотека (потрібна
    для перевірки підпису оновлень). Робимо один раз (guard через env-змінну),
    лише коли `arch` доступний. Якщо не під Rosetta — нічого не змінюємо."""
    if sys.platform != "darwin":
        return
    if os.environ.get("FARM_ARCH_REEXEC") == "1":
        return
    try:
        translated = subprocess.run(
            ["sysctl", "-n", "sysctl.proc_translated"],
            capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:  # noqa: BLE001
        translated = ""
    if translated != "1":            # не під Rosetta — залишаємось як є
        return
    arch = "/usr/bin/arch"
    if not os.path.exists(arch):
        return
    # БЕЗПЕКА: os.execv замінює процес, тож ЯКЩО arm64-зрізу немає — сервер би
    # загинув. Тому спершу тихо перевіряємо, що `arch -arm64 python` реально
    # стартує; лише за успіху робимо execv. Інакше лишаємось на x86_64 (HTTP ок).
    try:
        probe = subprocess.run(
            [arch, "-arm64", sys.executable, "-c", "pass"],
            capture_output=True, timeout=15)
        if probe.returncode != 0:
            print("[ARCH] arm64-зріз недоступний — лишаюсь на x86_64.", flush=True)
            return
    except Exception as exc:  # noqa: BLE001
        print(f"[ARCH] перевірка arm64 не вдалася ({exc}) — лишаюсь на x86_64.",
              flush=True)
        return
    os.environ["FARM_ARCH_REEXEC"] = "1"
    try:
        print("[ARCH] перезапуск нативно під arm64 (Apple Silicon)…", flush=True)
        os.execv(arch, [arch, "-arm64", sys.executable, *sys.argv])
    except Exception as exc:  # noqa: BLE001 — лишаємось на x86_64, HTTP працює
        print(f"[ARCH] не вдалося перезапустити під arm64 ({exc}).", flush=True)


def main() -> int:
    # Найперше: якщо ми під Rosetta — перезапуститись нативно arm64.
    _reexec_arm64_if_rosetta()

    parser = argparse.ArgumentParser(description="Запуск сервера ветаптеки")
    parser.add_argument("--host", default=None,
                        help="IP для прослуховування (за замовч. 127.0.0.1 — "
                             "лише цей компʼютер).")
    parser.add_argument("--port", type=int, default=5050,
                        help="Бажаний порт (за замовч. 5050)")
    parser.add_argument("--no-browser", action="store_true",
                        help="Не відкривати браузер автоматично")
    parser.add_argument("--debug", action="store_true",
                        help="Режим debug (Flask reloader)")
    # parse_known_args — щоб зайві службові слова з .bat (напр. "gui")
    # не валили сервер; вони просто ігноруються.
    args, _ignored = parser.parse_known_args()

    # Працюємо у директорії скрипта, щоб шляхи до templates/static знайшлись
    os.chdir(HERE)
    sys.path.insert(0, str(HERE))

    # Хост: лише цей компʼютер. Доступ з інших пристроїв мережі прибрано в
    # 2.40.56 (ферма працює в хмарі, телефони йдуть туди), тож давній прапорець
    # config/server_mode більше не читаємо — інакше ПК, де його колись увімкнули,
    # лишився б відкритим у мережі без жодного способу це вимкнути. Явний
    # --host лишився для запуску вручну.
    host = args.host or "127.0.0.1"
    if host not in ("127.0.0.1", "localhost", "::1"):
        os.environ["FARM_ALLOW_LAN"] = "1"     # запустили вручну на мережу — пускаємо

    ensure_dependencies()

    # Один інстанс: гасимо попередній сервер, щоб не плодити паралельні копії
    # (інакше старі процеси зі старим кодом/базою сиплять привидні помилки).
    _stop_previous()

    try:
        port = find_free_port(args.port, host)
    except RuntimeError as exc:
        print(f"✗  {exc}")
        return 1

    if port != args.port:
        print(f"ℹ  Порт {args.port} зайнятий, використовую {port}")

    # Фактичний HTTP-порт — у середовище, щоб застосунок міг показати
    # посилання за іменем ПК у футері (http://ІМ'ЯПК:порт).
    os.environ["FARM_HTTP_PORT"] = str(port)

    # відкладене відкриття браузера ще ДО старту сервера
    visible_host = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    url = f"http://{visible_host}:{port}/"

    print()
    print("┌─────────────────────────────────────────────────────────┐")
    print("│  Ветаптека — веб-сервер запущено                        │")
    print("├─────────────────────────────────────────────────────────┤")
    print(f"│  На цьому компʼютері:  {url:<33}│")
    if host in ("127.0.0.1", "localhost", "::1"):
        print("│  Доступ лише на цьому компʼютері (host=127.0.0.1).      │")
    else:
        print(f"│  Слухає також: {host:<41}│")
    print("│                                                         │")
    print("│  Зупинити: Ctrl+C                                       │")
    print("└─────────────────────────────────────────────────────────┘")
    print()

    if not args.no_browser:
        open_browser_later(url, delay=1.2)

    # PID-файл для коректної зупинки ззовні
    _write_pid()
    atexit.register(_remove_pid)

    # Застосувати підготовлене оновлення ДО імпорту коду — щоб не замінювати
    # зайняті файли. Робить копію поточного коду й відкат, якщо новий не валідний.
    try:
        import updater
        _up = updater.apply_staged_update(HERE)
        if _up.get("applied"):
            print(f"✓ Оновлення застосовано до версії {_up.get('app_version')}.")
        elif _up.get("error"):
            print("⚠ Оновлення не застосовано: " + str(_up["error"])
                  + (" (код відкочено до робочого стану)" if _up.get("rolled_back") else ""))
    except Exception as _exc:  # noqa: BLE001
        print(f"⚠ Помилка апдейтера (пропускаю): {_exc}")

    # Імпортуємо Flask-додаток вже після перевірки залежностей
    from web_app import app

    try:
        if args.debug:
            # Debug-режим — рідний Flask-сервер з авто-перезавантаженням
            # (потрібно лише програмістам).
            app.run(host=host, port=port, debug=True, use_reloader=True)
        else:
            # Production-режим — waitress: багатопотоковий WSGI-сервер,
            # стабільний під одночасні запити, без лякливого «dev server»-попередження.
            import logging
            # Приглушуємо «Task queue depth» — це інформаційне повідомлення,
            # яке зʼявляється при короткочасних піках і нічого не зламано.
            logging.getLogger("waitress.queue").setLevel(logging.ERROR)
            from waitress import serve
            serve(app, host=host, port=port,
                  threads=8,           # вистачить на 5-10 одночасних касирів
                  ident="Vetpharm")
    except KeyboardInterrupt:
        print("\nЗупинено.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
