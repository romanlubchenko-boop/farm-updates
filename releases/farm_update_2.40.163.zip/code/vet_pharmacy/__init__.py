"""Vet pharmacy inventory app."""
