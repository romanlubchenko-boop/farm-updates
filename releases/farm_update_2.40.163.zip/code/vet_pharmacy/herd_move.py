# -*- coding: utf-8 -*-
"""Мова рядків «Руху поголівʼя» (Роман 2026-09-28: «треба зробити строку формул і
мову розробити, щоб просунутий юзер міг користуватися… рух по голівʼї повинен бути
формулами… достатньо фільтр і що входить в цей фільтр»).

Рядок таблиці — одне число на кожен період (стовпець):

    EVENT(Подія) FILTER(умови)   скільки подій за період (умови — мовою списків;
                                 поле, якого подія не питає, — стан тварини напередодні)
    EVENT(birth) FILTER(умови)   скільки народилось на фермі (живі й мертві; FILTER(alive) —
                                 живі, FILTER(dead) — мертвонароджені)
    EVENT(entry) FILTER(умови)   скільки куплено (надійшло в стадо не народженими)

Один стандарт запису (Роман 2026-09-29: «чому є BORN(), а не EVENT(born) — усе повинно бути
в єдиному стандарті»): народження й купівля пишуться так само, як будь-яка подія. Народження
рахується з реєстру (народжені НА ФЕРМІ, мертвонароджені — теж), а не з подій «Народження»,
що є в кожної тварини, зокрема купленої; купівлі окремої події немає — «entry» знає мова.
Давні BORN() (живі), BORN(dead), BORN(all), ENTRY() читаються як і доти.

Єдина система запису (Роман 2026-09-29: «event calving filter lact більше нуля… щоб це
була якась єдина система написання формул; івент — замість боді»): як у «Роботі зі
стадом» BODY(…) FILTER(…), тут EVENT(…) — що рахуємо, FILTER(…) — кого. Давній запис
з умовами в самих дужках, EVENT(calving lact>0), читається так само.

    EVENT(…) FILTER(…) VIEW(avg поле)   не скільки подій, а середнє / сума / мін / макс поля
                                        (cnt — кількість, як без VIEW); поле — як у списках
    EVENT(…) VIEW(month_1)              період — лише на плитці «Огляду» й у списках (у таблиці
                                        період — це стовпці): today, yesterday, day_N, 7d / 30d,
                                        week, week_N, month, month_N, last_month, quarter,
                                        quarter_N, year, year_N, last_year; без нього — month
    START(група)                 скільки голів у групі на початок періоду
    група                        скільки голів на кінець періоду: [Дійні], FILTER(…), HERD
    IN(група [from=група] [by=EVENT(…)])                     скільки увійшло в групу
    OUT(група [to=група] [by=EVENT(…)])                      скільки вийшло з групи
    [Рядок] + − * / ( ) числа    арифметика з рядків цієї таблиці (Разом — та сама
                                 формула на підсумках, частка лишається часткою)

Група — будь-що, що розуміє «Робота зі стадом»: [Панель], [Список], FILTER(…) з
BODY/VIEW/FILTER2, або HERD — усе стадо. Склад групи на кожен день рахує ТОЙ САМИЙ
модуль сторінки (herd_query.js / herd_panels.js у Node) на тваринах, відтворених з
подій, тож «на початок + увійшло − вийшло = на кінець» сходиться завжди.

Тут — лише розбір і опис, без бази: parse(текст, події) → дерево або MoveError
(з місцем помилки), describe(дерево) → речення, total_kind(дерево) → як рахувати «Разом».
"""
from __future__ import annotations

import bisect
import difflib
import re

FLOWS = ("EVENT", "BORN", "ENTRY")
CALLS = FLOWS + ("START", "IN", "OUT")
# дії мови «Роботи зі стадом»: з них складається група
_GROUP_ACT = re.compile(
    r"^(body|filter\d*|view|sort|groupby|тіло|фільтрація\d*|фільтр\d*|де|відображення|"
    r"вигляд|показати|колонки|сортувати|порядок|групувати|групи)$", re.I)
_WORD = re.compile(r"[A-Za-zА-Яа-яЇїІіЄєҐґʼ'_][A-Za-zА-Яа-яЇїІіЄєҐґʼ'_\d]*")
_NUM = re.compile(r"\d+(?:[.,]\d+)?")
_FLAGS = {"EVENT": ("first",), "BORN": ("alive", "dead", "all"), "ENTRY": ()}
_ALL_FLAGS = ("first", "alive", "dead", "all")
# FILTER(…) одразу після EVENT/BORN/ENTRY — умови цієї події (не окрема група)
_FILTER_WORD = re.compile(r"^(filter|фільтр|фільтрація|де)$", re.I)
_VIEW_WORD = re.compile(r"^(view|відображення|вигляд)$", re.I)
# VIEW(avg поле) — те саме слово, що в «Роботі зі стадом» (herd_query.js)
_AGG = {"cnt": "cnt", "count": "cnt", "кількість": "cnt", "sum": "sum", "сума": "sum",
        "avg": "avg", "середнє": "avg", "середне": "avg", "min": "min", "мін": "min",
        "max": "max", "макс": "max"}
_AGG_WORDS = {"cnt": "кількість", "sum": "сума", "avg": "середнє", "min": "мінімум", "max": "максимум"}
# період плитки й списку (Роман 2026-09-29: «механізм датування… month, last_month, month_1…»)
_PERIOD = re.compile(r"^(today|сьогодні|yesterday|вчора|(day|week|month|quarter|year)(?:_(\d{1,3}))?|"
                     r"last_(week|month|quarter|year)|(\d{1,3})d)$", re.I)
_OPS = ("=", "<", ">", "!", "≠", "≥", "≤")
# знаки, які люди копіюють з тексту: − (мінус), – (тире), × і ÷ — по одному символу
_ADD = {"+": "+", "-": "-", "−": "-", "–": "-"}
_MUL = {"*": "*", "/": "/", "×": "*", "÷": "/"}


class MoveError(ValueError):
    """Помилка рядка: текст для людини і де саме (символи від–до)."""

    def __init__(self, msg: str, pos=None):
        super().__init__(msg)
        self.pos = pos


def norm(s) -> str:
    return " ".join(str(s or "").lower().replace("ʼ", "'").replace("’", "'").split())


def ev_ref(e: dict) -> str:
    """Як писати подію у формулі: англійська назва (Конструктор → Події), без неї —
    українська, у [..], коли в ній пробіл чи дужки."""
    en = str(e.get("en") or "").strip()
    if en:
        return en
    nm = str(e.get("name") or e.get("key") or "").strip()
    return "[%s]" % nm if re.search(r"[\s()]", nm) else nm


def _close(i: int, s: str, what: str) -> int:
    """s[i] == '(' → індекс парної ')' (усередині [..] дужки — просто текст)."""
    depth, j = 0, i
    while j < len(s):
        c = s[j]
        if c == "[":
            k = s.find("]", j + 1)
            if k < 0:
                raise MoveError("не закрита дужка «[»", (j, len(s)))
            j = k + 1
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return j
        j += 1
    raise MoveError("не закрита дужка після %s(" % what, (i, len(s)))


def _top_tokens(s: str) -> list:
    """Слова верхнього рівня з їхнім місцем: [..] і (..) — одним словом."""
    out, j, n = [], 0, len(s)
    while j < n:
        if s[j].isspace() or s[j] == ",":
            j += 1
            continue
        a = j
        while j < n and not s[j].isspace() and s[j] != ",":
            if s[j] == "[":
                k = s.find("]", j + 1)
                j = n if k < 0 else k + 1
            elif s[j] == "(":
                try:
                    j = _close(j, s, "") + 1
                except MoveError:
                    j = n
            else:
                j += 1
        out.append((s[a:j], a, j))
    return out


# народження й купівля — «події» мови, хоч і рахуються з реєстру (див. угорі). Народження
# ферма має й справжньою подією (ключ birth) — тоді назви беремо її; інакше — ці.
_BIRTH = {"key": "birth", "name": "Народження", "en": "birth"}
_ENTRY = {"key": "__entry", "name": "Надходження", "en": "entry"}
_AS_FLOW = {"birth": "BORN", "__entry": "ENTRY"}


def with_virtual(events: list) -> list:
    """Події ферми + народження й купівля, яких у переліку немає (для розбору й підказок)."""
    evs = list(events or [])
    keys = {e.get("key") for e in evs}
    ens = {norm(e.get("en")) for e in evs} | {norm(e.get("name")) for e in evs}
    for v in (_BIRTH, _ENTRY):
        if v["key"] not in keys and norm(v["en"]) not in ens:
            evs.append(dict(v))
    return evs


class _Parser:
    def __init__(self, text: str, events: list):
        self.src = str(text or "")
        self.events = with_virtual(events)

    # ── вхід ──
    def parse(self) -> dict:
        s = self.src
        i = 0
        while i < len(s) and s[i].isspace():
            i += 1
        if i < len(s) and s[i] == "=":
            i += 1
        if not s[i:].strip():
            raise MoveError("формули немає")
        self.i = i
        node = self.expr()
        self.ws()
        if self.i < len(s):
            raise MoveError("зайве «%s»" % s[self.i:].strip()[:30], (self.i, len(s)))
        return node

    def ws(self):
        s = self.src
        while self.i < len(s) and s[self.i].isspace():
            self.i += 1

    def peek(self) -> str:
        self.ws()
        return self.src[self.i] if self.i < len(self.src) else ""

    # ── арифметика ──
    def expr(self):
        node = self.term()
        while self.peek() in _ADD:
            op = _ADD[self.src[self.i]]
            self.i += 1
            node = {"t": "bin", "op": op, "a": node, "b": self.term()}
        return node

    def term(self):
        node = self.factor()
        while self.peek() in _MUL:
            op = _MUL[self.src[self.i]]
            self.i += 1
            node = {"t": "bin", "op": op, "a": node, "b": self.factor()}
        return node

    def factor(self):
        c = self.peek()
        s, a = self.src, self.i
        if not c:
            raise MoveError("незавершена формула", (a, a))
        if _ADD.get(c) == "-":
            self.i += 1
            return {"t": "neg", "x": self.factor()}
        if c == "(":
            # той самий розбирач і ті самі місця, що й у всій формулі: перейменування
            # панелі й підкреслення помилки мусять влучати в текст рядка
            j = _close(a, s, "")
            if not s[a + 1:j].strip():
                raise MoveError("порожні дужки", (a, j + 1))
            self.i = a + 1
            node = self.expr()
            self.ws()
            if self.i != j:
                raise MoveError("зайве «%s»" % s[self.i:j].strip()[:30], (self.i, j))
            self.i = j + 1
            return node
        if c == "[":
            k = s.find("]", a + 1)
            if k < 0:
                raise MoveError("не закрита дужка «[»", (a, len(s)))
            name = s[a + 1:k].strip()
            if not name:
                raise MoveError("порожні дужки «[]»", (a, k + 1))
            self.i = k + 1
            return {"t": "ref", "name": name, "pos": (a, k + 1)}
        m = _NUM.match(s, a)
        if m:
            self.i = m.end()
            return {"t": "num", "v": float(m.group(0).replace(",", "."))}
        m = _WORD.match(s, a)
        if not m:
            raise MoveError("незрозуміле «%s»" % s[a:a + 12], (a, a + 1))
        word = m.group(0)
        self.i = m.end()
        up = word.upper()
        if up == "HERD":
            return {"t": "group", "g": {"k": "herd"}, "pos": (a, self.i)}
        if self.peek() != "(":
            raise MoveError("незрозуміле «%s» — функція пишеться з дужками, назва рядка чи "
                            "панелі — у квадратних: [%s]" % (word, word), (a, self.i))
        if up in CALLS:
            node = self.call(up, a)
            if node.get("t") == "flow":
                self.flow_filters(node)
            else:
                self.flow_filters(node, only_view=True)
            return node
        if _GROUP_ACT.match(word):
            return {"t": "group", "g": self.group_fx(a), "pos": (a, self.i)}
        if up == "END":
            raise MoveError("END не потрібен: на кінець — це просто сама група, напр. [Дійні]",
                            (a, self.i))
        guess = difflib.get_close_matches(up, CALLS, n=1, cutoff=0.6)
        raise MoveError("невідома функція «%s»" % word
                        + (" — мабуть, %s?" % guess[0] if guess else
                           " — є EVENT, START, IN, OUT"), (a, self.i))

    def group_fx(self, a: int) -> dict:
        """FILTER(…) BODY(…) VIEW(…) FILTER2(…) поспіль — одна група мовою списків."""
        s = self.src
        j = a
        end = a
        while True:
            m = _WORD.match(s, j)
            if not m or not _GROUP_ACT.match(m.group(0)):
                break
            k = m.end()
            while k < len(s) and s[k].isspace():
                k += 1
            if k >= len(s) or s[k] != "(":
                break
            end = _close(k, s, m.group(0)) + 1
            j = end
            while j < len(s) and s[j].isspace():
                j += 1
        self.i = end
        return {"k": "fx", "text": s[a:end].strip()}

    # ── виклики ──
    def call(self, fn: str, a: int) -> dict:
        s = self.src
        o = self.i
        c = _close(o, s, fn)
        args = s[o + 1:c]
        base = o + 1
        self.i = c + 1
        pos = (a, c + 1)
        if fn in FLOWS:
            return self.flow(fn, args, base, pos)
        if fn == "START":
            g = self.group(args, base, fn)
            return {"t": "start", "g": g, "pos": pos}
        return self.move(fn, args, base, pos)

    def flow(self, fn: str, args: str, base: int, pos) -> dict:
        node = {"t": "flow", "fn": fn, "ev": "", "evname": "", "flags": [], "conds": "",
                "pos": pos}
        rest, off = args, base
        if fn == "EVENT":
            ev, used, (ea, eb) = self.event_name(args, base)
            node["ev"], node["evname"] = ev["key"], ev["name"]
            node["evpos"] = (base + ea, base + eb)     # де сама назва — для перейменування
            rest, off = args[used:], base + used
            if ev["key"] in _AS_FLOW:                  # EVENT(birth) / EVENT(entry) — з реєстру
                node["fn"], node["as_ev"], node["ev"] = _AS_FLOW[ev["key"]], ev["key"], ""
        self.conds(node, node["fn"], rest, off)
        return node

    def flow_filters(self, node: dict, only_view: bool = False):
        self._flow_filters(node, only_view)
        # EVENT(birth) без alive / dead — усі народжені (як будь-яка подія — усі записи);
        # давнє BORN() лишається «живі»
        if node.get("as_ev") == "birth" and not node.get("flags"):
            node["flags"] = ["all"]

    def _flow_filters(self, node: dict, only_view: bool = False):
        """EVENT(calving) FILTER(lact>0) — FILTER одразу після події додає їй умови
        (кілька FILTER поспіль — усі разом)."""
        s = self.src
        while True:
            save = self.i
            self.ws()
            m = _WORD.match(s, self.i)
            if m and _VIEW_WORD.match(m.group(0)):
                k = m.end()
                while k < len(s) and s[k].isspace():
                    k += 1
                if k < len(s) and s[k] == "(":
                    if node.get("view"):
                        raise MoveError("VIEW двічі — усе в одних дужках: VIEW(avg lkd month)",
                                        (m.start(), k))
                    c = _close(k, s, "VIEW")
                    self.view(node, s[k + 1:c], k + 1, (m.start(), c + 1))
                    if only_view and node.get("agg"):
                        raise MoveError("у START / IN / OUT — лише період: VIEW(month_1)",
                                        node["agg"]["pos"])
                    node["pos"] = (node["pos"][0], c + 1)
                    self.i = c + 1
                    continue
            if only_view or not m or not _FILTER_WORD.match(m.group(0)):
                self.i = save
                return
            k = m.end()
            while k < len(s) and s[k].isspace():
                k += 1
            if k >= len(s) or s[k] != "(":
                self.i = save
                return
            c = _close(k, s, m.group(0).upper())
            if not s[k + 1:c].strip():
                raise MoveError("FILTER() порожній — напишіть умову, напр. FILTER(lact>0)",
                                (m.start(), c + 1))
            self.conds(node, node["fn"], s[k + 1:c], k + 1)
            node["pos"] = (node["pos"][0], c + 1)
            self.i = c + 1

    def view(self, node: dict, args: str, off: int, vpos):
        """VIEW(avg поле) — що рахувати з подій; VIEW(month_1) — за який період
        (лише на плитці й у списку); разом: VIEW(avg lkd month_1)."""
        node["view"] = True
        node["vpos"] = vpos
        toks = _top_tokens(args)
        if not toks:
            raise MoveError("VIEW() порожній — напишіть, що рахувати (avg поле) чи за який "
                            "період (month, month_1, year…)", vpos)
        i = 0
        while i < len(toks):
            t, x, y = toks[i]
            lw = t.lower()
            if lw in _AGG:
                if node.get("agg"):
                    raise MoveError("одна функція на подію: cnt, sum, avg, min або max",
                                    (off + x, off + y))
                fn = _AGG[lw]
                fld, fx, fy = "", y, y
                if i + 1 < len(toks) and not _PERIOD.match(toks[i + 1][0]) \
                        and toks[i + 1][0].lower() not in _AGG:
                    fld, fx, fy = toks[i + 1]
                    fld = fld[1:-1].strip() if fld.startswith("[") and fld.endswith("]") else fld
                    i += 1
                if fn != "cnt" and not fld:
                    raise MoveError("%s чого? напр. VIEW(%s lkd) — поле події чи параметр"
                                    % (lw, lw), (off + x, off + y))
                node["agg"] = {"fn": fn, "field": fld, "pos": (off + x, off + fy)}
            elif _PERIOD.match(t):
                if node.get("period"):
                    raise MoveError("один період на подію", (off + x, off + y))
                node["period"] = {"w": lw, "pos": (off + x, off + y)}
            else:
                guess = difflib.get_close_matches(lw, list(_AGG) + ["month", "month_1", "last_month",
                                                                   "year", "week", "today"], n=1, cutoff=0.6)
                raise MoveError("у VIEW незрозуміле «%s»" % t + (" — мабуть, %s?" % guess[0] if guess else
                                " — є avg / sum / min / max поле, cnt і період: month, month_1, year…"),
                                (off + x, off + y))
            i += 1

    def conds(self, node: dict, fn: str, rest: str, off: int):
        """Умови й прапорці (first, dead…) — з дужок самої події чи з FILTER(…) після неї."""
        toks = _top_tokens(rest)
        keep, flagged = [], []
        prev = ""
        for t, x, y in toks:
            lw = t.lower()
            is_flag = lw in _ALL_FLAGS and not (prev and (prev[-1] in _OPS or prev.lower()
                                                           in ("between", "між", "contains", "містить")))
            if is_flag:
                if lw not in _FLAGS[fn]:
                    where = {"first": "EVENT(calving)", "alive": "EVENT(birth)", "dead": "EVENT(birth)",
                             "all": "EVENT(birth)"}[lw]
                    raise MoveError("%s буває лише в %s" % (lw, where), (off + x, off + y))
                if lw == "first" and node["ev"] != "calving":
                    raise MoveError("first буває лише в EVENT(calving) — перший отел",
                                    (off + x, off + y))
                if lw in node["flags"]:
                    raise MoveError("%s двічі" % lw, (off + x, off + y))
                if fn == "BORN" and node["flags"]:
                    raise MoveError("вибирайте одне: alive (живі) або dead (мертві)", (off + x, off + y))
                node["flags"].append(lw)
                flagged.append((x, y))
            else:
                keep.append((t, x, y))
            prev = t
        if keep:
            a0, b0 = keep[0][1], keep[-1][2]
            txt = list(rest[a0:b0])
            for x, y in flagged:                     # прапорець посеред умов — пробілами
                if a0 <= x < b0:
                    txt[x - a0:y - a0] = " " * (y - x)
            part = "".join(txt)                   # довжина та сама — місця умов не зсуваються
            node["conds"] = (node["conds"] + " " + part) if node["conds"] else part
            cp = (off + a0, off + b0)
            was = node.get("cpos")
            node["cpos"] = (min(was[0], cp[0]), max(was[1], cp[1])) if was else cp

    # назви події в порядку сили: англійська (для формул), українська, внутрішній ключ
    _EV_NAMES = ("en", "name", "key")

    def event_name(self, args: str, base: int):
        """Назва події на початку дужок → (подія, скільки символів зʼїла, (від, до) самої
        назви). Найдовша назва, з якої починається текст (англійська, українська чи
        ключ; однакова довжина — сильніша назва); інакше — однозначний початок назви."""
        txt = args.replace("ʼ", "'").replace("’", "'")
        lead = len(txt) - len(txt.lstrip())
        if not txt.strip():
            raise MoveError("EVENT(…) — яка подія? напр. EVENT(calving) або EVENT(Отел)",
                            (base, base + len(args)))
        if txt[lead] == "[":                         # [Переведення в секцію]
            k = txt.find("]", lead)
            if k < 0:
                raise MoveError("не закрита дужка «[»", (base + lead, base + len(args)))
            want = norm(txt[lead + 1:k])
            for f in self._EV_NAMES:
                hit = [e for e in self.events if want and norm(e.get(f)) == want]
                if len(hit) > 1:
                    raise MoveError("«%s» — так звуться кілька подій; напишіть англійську назву "
                                    "події" % args[lead + 1:k], (base + lead, base + k + 1))
                if hit:
                    return hit[0], k + 1, (lead, k + 1)
            raise self.no_event(args[lead + 1:k], base + lead, base + k + 1)
        best, used, rank = None, 0, 9
        for e in self.events:
            for r, f in enumerate(self._EV_NAMES):
                words = norm(e.get(f)).split()
                if not words:
                    continue
                pat = r"\s*" + r"\s+".join(re.escape(w) for w in words) + r"(?=\s|,|$)"
                m = re.match(pat, txt, re.I)
                if m and (m.end() > used or (m.end() == used and r < rank)):
                    best, used, rank = e, m.end(), r
        if best:
            return best, used, (lead, used)
        m = re.match(r"\s*([^\s,]+)", txt)
        if not m:
            raise MoveError("EVENT(…) — яка подія? напр. EVENT(calving) або EVENT(Отел)",
                            (base, base + len(args)))
        word = args[m.start(1):m.end(1)]
        w = norm(word)
        starts = [e for e in self.events
                  if norm(e.get("name")).startswith(w) or (e.get("en") and norm(e["en"]).startswith(w))]
        if len(starts) == 1:
            return starts[0], m.end(), (m.start(1), m.end(1))
        if len(starts) > 1:
            raise MoveError("«%s» — кілька подій (%s), уточніть назву"
                            % (word, ", ".join(ev_ref(e) for e in starts[:4])),
                            (base + m.start(1), base + m.end(1)))
        raise self.no_event(word, base + m.start(1), base + m.end(1))

    def no_event(self, word: str, a: int, b: int) -> MoveError:
        low = {}
        for e in self.events:
            for f in ("en", "name"):
                if e.get(f):
                    low.setdefault(str(e[f]).lower(), ev_ref(e) if f == "en" else e[f])
        guess = difflib.get_close_matches(str(word).lower(), list(low), n=1, cutoff=0.5)
        return MoveError("немає події «%s»" % word + (" — мабуть, «%s»?" % low[guess[0]] if guess else ""),
                         (a, b))

    def move(self, fn: str, args: str, base: int, pos) -> dict:
        """IN(група from=… by=…) / OUT(група to=… by=…)."""
        cuts = []
        depth, j = 0, 0
        while j < len(args):
            c = args[j]
            if c == "[":
                k = args.find("]", j + 1)
                j = len(args) if k < 0 else k + 1
                continue
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif depth == 0:
                m = re.match(r"(from|to|by)\s*=", args[j:], re.I)
                if m and (j == 0 or not (args[j - 1].isalnum() or args[j - 1] == "_")):
                    cuts.append((j, j + m.end(), m.group(1).lower()))
                    j += m.end()
                    continue
            j += 1
        head_end = cuts[0][0] if cuts else len(args)
        node = {"t": fn.lower(), "g": self.group(args[:head_end], base, fn), "via": None,
                "by": None, "pos": pos}
        for n, (a, b, name) in enumerate(cuts):
            end = cuts[n + 1][0] if n + 1 < len(cuts) else len(args)
            val = args[b:end]
            vpos = (base + b, base + end)
            if name == "by":
                if node["by"] is not None:
                    raise MoveError("by= двічі", (base + a, base + b))
                v = val.strip()
                m = re.match(r"(EVENT|BORN|ENTRY)\s*\(", v, re.I)
                if not m:
                    raise MoveError("by= чекає подію: EVENT(calving), EVENT(birth), EVENT(entry)…", vpos)
                sub = _Parser(val, self.events)
                sub.i = 0
                try:
                    got = sub.factor()
                    sub.ws()
                    if sub.i < len(sub.src):
                        raise MoveError("зайве «%s» після by=" % sub.src[sub.i:].strip()[:20])
                except MoveError as exc:
                    p = exc.pos
                    raise MoveError(str(exc), (base + b + p[0], base + b + p[1]) if p else vpos)
                for x in walk(got):                  # місця — у всій формулі, а не в by=…
                    for k in ("pos", "cpos", "evpos"):
                        if x.get(k):
                            x[k] = (x[k][0] + base + b, x[k][1] + base + b)
                if (got.get("agg") or {}).get("fn") not in (None, "cnt") or got.get("period"):
                    raise MoveError("у by= — лише подія й умови: VIEW тут не діє (період — у самого %s)" % fn,
                                    tuple(x + base + b for x in got["vpos"]) if got.get("vpos") else vpos)
                node["by"] = got
            else:
                right = "from" if fn == "IN" else "to"
                if name != right:
                    raise MoveError("в %s пишемо %s=… (%s); %s=… — лише в %s"
                                    % (fn, right, "звідки" if fn == "IN" else "куди", name,
                                       "IN" if name == "from" else "OUT"), (base + a, base + b))
                if node["via"] is not None:
                    raise MoveError("%s= двічі" % name, (base + a, base + b))
                node["via"] = self.group(val, base + b, name + "=")
        return node

    def group(self, text: str, base: int, where: str) -> dict:
        t = text.strip(" \t\r\n,")                 # IN([Дійні], from=…) — кома не заважає
        lead = len(text) - len(text.lstrip(" \t\r\n,"))
        a, b = base + lead, base + lead + len(t)
        hint = "%s чекає групу: [Панель], FILTER(…) або HERD" % (
            where + "(…)" if where.isalpha() and where.isupper() else where)
        if not t:
            raise MoveError(hint, (a, b))
        if where in ("IN", "OUT") and t.startswith("[") and t.count("[") >= 2:
            raise MoveError("звідки пишемо так: IN([Дійні] from=[Нетелі])" if where == "IN"
                            else "куди пишемо так: OUT([Дійні] to=[Сухостій])", (a, b))
        if t.upper() == "HERD":
            return {"k": "herd", "pos": (a, b)}
        if t.startswith("[") and t.endswith("]") and t.count("[") == 1:
            name = t[1:-1].strip()
            if not name:
                raise MoveError(hint, (a, b))
            return {"k": "ref", "name": name, "pos": (a, b)}
        m = _WORD.match(t)
        if m and _GROUP_ACT.match(m.group(0)) and t[m.end():].lstrip().startswith("("):
            sub = _Parser(t, self.events)
            sub.i = 0
            g = sub.group_fx(0)
            sub.ws()
            if sub.i < len(t):
                raise MoveError("зайве «%s» у групі" % t[sub.i:].strip()[:20], (a + sub.i, b))
            g["pos"] = (a, b)
            return g
        if m and m.group(0).upper() in CALLS:
            raise MoveError("%s — це число, а не група тварин; %s" % (m.group(0).upper(), hint), (a, b))
        raise MoveError(hint + " — напр. [%s]" % t if re.fullmatch(r"[\w\s\-ʼ']+", t) else hint, (a, b))


def parse(text: str, events: list = None) -> dict:
    """Текст рядка → дерево. events — [{key, name, en}] подій ферми (для назви в EVENT)."""
    return _Parser(text, events or []).parse()


def reevent(text: str, was: list, now: list) -> str:
    """Рядок після зміни назв подій (was/now — [{key, name, en}] до й після). Посилання
    старою англійською назвою → нова англійська; старою українською → нова українська;
    скорочення чи ключ, що з новими назвами вже веде не туди, — на назву для формул.
    Решта рядка — байт у байт та сама; нерозбірний рядок не чіпаємо."""
    try:
        tree = parse(text, was)
    except Exception:  # noqa: BLE001
        return text
    old = {e.get("key"): e for e in was}
    new = {e.get("key"): e for e in now}
    reps = {}
    for n in walk(tree):
        if n.get("t") != "flow" or not (n.get("fn") == "EVENT" or n.get("as_ev")) or not n.get("evpos"):
            continue
        k, (a, b) = n.get("as_ev") or n["ev"], n["evpos"]
        o, e = old.get(k) or {}, new.get(k)
        if not e:                               # подію прибрали — рядок чесно скаже «немає події»
            continue
        cur = text[a:b]
        br = cur.startswith("[") and cur.endswith("]")
        inner = norm(cur[1:-1] if br else cur)
        if o.get("en") and inner == norm(o["en"]) and (e.get("en") or "") != o["en"]:
            reps[(a, b)] = ev_ref(e)
        elif inner == norm(o.get("name")) and (e.get("name") or "") != (o.get("name") or ""):
            nm = e.get("name") or ""
            reps[(a, b)] = "[%s]" % nm if (br or re.search(r"[\s()]", nm)) else nm
        else:
            try:
                got, used, _ = _Parser(cur, now).event_name(cur, 0)
                if got.get("key") == k and used >= len(cur.rstrip()):
                    continue
            except MoveError:
                pass
            reps[(a, b)] = ev_ref(e)
    out = text
    for a, b in sorted(reps, reverse=True):
        out = out[:a] + reps[(a, b)] + out[b:]
    return out


def walk(node: dict):
    """Усі вузли дерева (для збору груп і умов)."""
    if not isinstance(node, dict):
        return
    yield node
    for k in ("a", "b", "x", "by"):
        if isinstance(node.get(k), dict):
            yield from walk(node[k])


def groups_of(node: dict) -> list:
    """Групи, які рядок читає: [(група, роль)] — роль 'end' | 'start' | 'in' | 'out' | 'via'."""
    out = []
    for n in walk(node):
        t = n.get("t")
        if t == "group":
            out.append((n["g"], "end"))
        elif t == "start":
            out.append((n["g"], "start"))
        elif t in ("in", "out"):
            out.append((n["g"], t))
            if n.get("via"):
                out.append((n["via"], "via"))
    return out


def total_kind(node: dict) -> str:
    """Як рахувати «Разом»: sum — сума стовпців, first — перший (на початок),
    last — останній (на кінець), calc — та сама формула на підсумках, ref — як рядок."""
    t = node.get("t")
    if t == "flow" and node.get("agg") and node["agg"]["fn"] != "cnt":
        return node["agg"]["fn"]               # «Разом» — та сама функція на всіх подіях
    if t in ("flow", "in", "out"):
        return "sum"
    if t == "start":
        return "first"
    if t == "group":
        return "last"
    if t == "ref":
        return "ref"
    if t == "neg":
        return total_kind(node["x"])
    return "calc"


def gname(g: dict) -> str:
    if not g:
        return ""
    if g.get("k") == "herd":
        return "усе стадо"
    if g.get("k") == "ref":
        return "«%s»" % g["name"]
    return g.get("text") or ""


def _flow_words(n: dict) -> str:
    fn = n["fn"]
    if fn == "EVENT":
        s = "подій «%s»" % (n.get("evname") or n.get("ev"))
        if "first" in n["flags"]:
            s += " (перший отел)"
    elif fn == "BORN":
        f = n["flags"]
        s = ("мертвонароджених" if "dead" in f else
             "народжених (живих і мертвих)" if "all" in f else "живих народжених на фермі")
    else:
        s = "куплених тварин"
    if n.get("conds"):
        s += " з умовою %s" % n["conds"]
    return s


def _in_group(g: dict) -> str:
    return "у стаді" if g.get("k") == "herd" else "у групі %s" % gname(g)


def describe(node: dict) -> str:
    """Людське речення: що рахує рядок (підказка на назві рядка)."""
    t = node.get("t")
    if t in ("start", "group", "in", "out") and node.get("period"):
        pw = period_words(node["period"]["w"])
        return (describe(dict(node, period=None)).replace(" на початок періоду", " на початок періоду " + pw)
                .replace(" на кінець періоду", " на кінець періоду " + pw).replace(" за період", " " + pw))
    if t == "flow":
        ag = node.get("agg") or {}
        pw = period_words(node["period"]["w"]) if node.get("period") else "за період"
        if ag.get("fn") and ag["fn"] != "cnt":
            return "%s «%s» у %s %s" % (_AGG_WORDS[ag["fn"]].capitalize(), ag["field"],
                                         _flow_words(node).replace("подій", "подіях", 1), pw)
        if ag.get("field"):
            return "Скільки %s, де є «%s», %s" % (_flow_words(node), ag["field"], pw)
        return "Скільки %s %s" % (_flow_words(node), pw)
    if t == "start":
        return "Скільки голів %s на початок періоду" % _in_group(node["g"])
    if t == "group":
        return "Скільки голів %s на кінець періоду" % _in_group(node["g"])
    if t in ("in", "out"):
        g = node["g"]
        if g.get("k") == "herd":
            s = "Скільки тварин %s за період" % ("прийшло в стадо" if t == "in" else "вибуло зі стада")
        else:
            s = "Скільки тварин %s групи %s за період" % ("увійшло до" if t == "in" else "вийшло з",
                                                         gname(g))
        v = node.get("via")
        if v:
            s += (" — з тих, хто напередодні був %s" if t == "in" else " — і того ж дня опинились %s") \
                % _in_group(v)
        if node.get("by"):
            s += " — разом із %s того ж дня" % _flow_words(node["by"])
        return s
    if t == "ref":
        return "Те саме, що рядок чи панель «%s»" % node["name"]
    if t == "num":
        return "Число"
    return "Розрахунок з інших рядків"


class Members:
    """Склад групи по днях із відповіді Node (склад першого дня + зміни): скільки
    голів на день, чи була тварина в групі того дня, хто увійшов і вийшов."""

    def __init__(self, res: dict, start: str, days: list):
        res = res or {}
        self.err = res.get("err") or ""
        self.mode = res.get("mode") or ""
        self.start = start
        self.end = days[-1] if days else start
        self.base = set(res.get("d0") or [])
        self.ch = res.get("ch") or {}
        self.size: dict = {}
        self.tog: dict = {}
        if self.mode == "set":
            cur = len(self.base)
            for d in days:
                c = self.ch.get(d)
                if c and d != start:
                    cur += len(c[0]) - len(c[1])
                    for i in list(c[0]) + list(c[1]):
                        self.tog.setdefault(i, []).append(d)
                self.size[d] = cur
        elif self.mode == "val":
            self.size = dict(res.get("v") or {})

    def at(self, day: str):
        return self.size.get(day)

    def has(self, aid, day: str):
        """Чи в групі на кінець дня (None — день поза відомим)."""
        if day < self.start or day > self.end or self.mode != "set":
            return None
        t = self.tog.get(aid) or []
        return (aid in self.base) != (bisect.bisect_right(t, day) % 2 == 1)

    def members(self, day: str) -> list:
        if day < self.start or day > self.end or self.mode != "set":
            return []
        return sorted(a for a in self.base | set(self.tog) if self.has(a, day))

    def moves(self, a: str, b: str):
        """[(тварина, день)] увійшли і вийшли за дні [a, b]."""
        ins, outs = [], []
        for d, (i, o) in self.ch.items():
            if a <= d <= b and d != self.start:
                ins.extend((x, d) for x in i)
                outs.extend((x, d) for x in o)
        return ins, outs


def period_range(word: str, today: str):
    """Слово періоду → (від, до) у ISO; сьогодні — межа «до» для поточних періодів.
    None — не період."""
    from datetime import date, timedelta
    m = _PERIOD.match(str(word or "").strip())
    if not m:
        return None
    w = m.group(0).lower()
    t = date.fromisoformat(str(today)[:10])
    mon = lambda y, mo: date(y + (mo - 1) // 12, (mo - 1) % 12 + 1, 1)
    last_day = lambda d1: mon(d1.year, d1.month + 1) - timedelta(days=1)
    if w in ("today", "сьогодні"):
        return t.isoformat(), t.isoformat()
    if w in ("yesterday", "вчора"):
        d = t - timedelta(days=1)
        return d.isoformat(), d.isoformat()
    if m.group(5):                               # 30d — останні 30 днів разом із сьогодні
        n = max(1, int(m.group(5)))
        return (t - timedelta(days=n - 1)).isoformat(), t.isoformat()
    unit = (m.group(2) or m.group(4) or "").lower()
    n = int(m.group(3) or 0) if m.group(2) else 1
    if unit == "day":
        d = t - timedelta(days=n)
        return d.isoformat(), d.isoformat()
    if unit == "week":
        a = t - timedelta(days=t.weekday()) - timedelta(days=7 * n)
        return a.isoformat(), (t if n == 0 else a + timedelta(days=6)).isoformat()
    if unit == "month":
        a = mon(t.year, t.month - n)
        return a.isoformat(), (t if n == 0 else last_day(a)).isoformat()
    if unit == "quarter":
        q0 = (t.month - 1) // 3 * 3 + 1
        a = mon(t.year, q0 - 3 * n)
        return a.isoformat(), (t if n == 0 else last_day(mon(a.year, a.month + 2))).isoformat()
    if unit == "year":
        a = date(t.year - n, 1, 1)
        return a.isoformat(), (t if n == 0 else date(a.year, 12, 31)).isoformat()
    return None


_PW = {"today": "сьогодні", "сьогодні": "сьогодні", "yesterday": "вчора", "вчора": "вчора",
       "week": "за цей тиждень", "month": "за цей місяць", "quarter": "за цей квартал",
       "year": "за цей рік", "last_week": "за минулий тиждень", "last_month": "за минулий місяць",
       "last_quarter": "за минулий квартал", "last_year": "за минулий рік"}


def period_words(word: str) -> str:
    """month_1 → «місяць тому», 30d → «за 30 днів» — для опису рядка й підпису плитки."""
    w = str(word or "").lower()
    if w in _PW:
        return _PW[w]
    m = _PERIOD.match(w)
    if not m:
        return "за період"
    if m.group(5):
        return "за %s дн." % m.group(5)
    unit, n = (m.group(2) or "").lower(), int(m.group(3) or 0)
    if not n:
        return _PW.get(unit, "за період")
    if n == 1:
        return "вчора" if unit == "day" else _PW["last_" + unit]
    nm = {"day": "день", "week": "тиждень", "month": "місяць", "quarter": "квартал", "year": "рік"}[unit]
    ago = {"day": "дн.", "week": "тиж.", "month": "міс.", "quarter": "кв.", "year": "р."}[unit]
    return "за %s %d %s тому" % (nm, n, ago)


# ── ОДИН ФОРМАТ ФОРМУЛИ (Роман 2026-09-30: «строка формул у русі поголівʼя повинна завжди бути в одному
# форматі»). Доти та сама мова стояла по-різному: «=FILTER(lact >0)» у поголівʼї для годівлі, «FILTER(lact>0)»
# у русі, «EVENT(calving)FILTER(…)». Правило — лише вигляд, зміст не міняється: без «=» на початку; одинарні
# пробіли; біля знаків порівняння (> < = >= <= <> !=) — без пробілів; одразу після «(» і перед «)» — без
# пробілів; слова мови перед «(» — великими; між частинами «…) СЛОВО(» — один пробіл; + - * / між рядками й
# групами (поза дужками) — з пробілами. Усе в [квадратних дужках] і "лапках" — як набрали.
# ⚠️ Та сама функція є в herd.js (fxCanon) — міняти обидві разом.
_CANON_WORDS = {"event", "filter", "view", "body", "start", "in", "out", "born", "entry", "herd"}


def canon(text) -> str:
    s = str(text if text is not None else "").strip()
    s = re.sub(r"^=\s*", "", s)
    out, i, depth, n = [], 0, 0, len(s)
    while i < n:
        c = s[i]
        if c in "[\"'":                                    # вміст дужок/лапок — як є
            end = s.find("]" if c == "[" else c, i + 1)
            end = n - 1 if end < 0 else end
            out.append(s[i:end + 1])
            i = end + 1
            continue
        if c.isspace():
            j = i
            while j < n and s[j].isspace():
                j += 1
            out.append(" ")
            i = j
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        out.append(c)
        i += 1
    s = "".join(out)
    # розбиваємо знову на «захищене» ([…], "…") і решту — правила лише для решти
    parts = re.split(r'(\[[^\]]*\]?|"[^"]*"?|\'[^\']*\'?)', s)
    for k in range(0, len(parts), 2):
        p = parts[k]
        p = re.sub(r"\s*(>=|<=|<>|!=|=|>|<)\s*", r"\1", p)
        p = re.sub(r"\(\s+", "(", p)
        p = re.sub(r"\s+\)", ")", p)
        p = re.sub(r"\b([A-Za-z]+\d*)\s*\(",
                   lambda m: (m.group(1).upper() if re.sub(r"\d+$", "", m.group(1)).lower() in _CANON_WORDS
                              else m.group(1)) + "(", p)
        p = re.sub(r"\)\s*(?=[A-Za-zА-Яа-яІіЇїЄєҐґ\[])", ") ", p)
        parts[k] = p
    s = "".join(parts)
    # + - * / на верхньому рівні (між рядками, групами, числами) — з пробілами
    res, depth, i, n = [], 0, 0, len(s)
    while i < n:
        c = s[i]
        if c in "[\"'":
            end = s.find("]" if c == "[" else c, i + 1)
            end = n - 1 if end < 0 else end
            res.append(s[i:end + 1])
            i = end + 1
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth = max(0, depth - 1)
        if depth == 0 and c in "+-*/":
            prev = "".join(res).rstrip()
            unary = not prev or prev[-1] in "+-*/(="
            while res and res[-1] == " ":
                res.pop()
            if unary:
                res.append((" " if prev else "") + c)
            else:
                res.append(" " + c + " ")
            i += 1
            while i < n and s[i] == " ":
                i += 1
            continue
        res.append(c)
        i += 1
    return re.sub(r" {2,}", " ", "".join(res)).strip()
