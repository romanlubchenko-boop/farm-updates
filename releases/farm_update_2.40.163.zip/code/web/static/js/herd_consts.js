/* Конструктор → «Налаштування»: числа ферми, які пишуться у формулах за
   назвою (Роман 2026-09-24: «тільність при отелі корів, нетелів, дата
   запуску корів — ті параметри, які можна в списках задіювати»).
   Цикл відтворення — готові рядки, міняється лише значення; власні —
   додаються й прибираються. Зберігається все однією кнопкою. */
'use strict';
(function () {
    const sysBody = document.getElementById('cnSys');
    const ownBody = document.getElementById('cnOwn');
    if (!sysBody || !ownBody) return;

    const esc = (t) => String(t === null || t === undefined ? '' : t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const canEdit = !!window.IS_ADMIN;
    const dis = canEdit ? '' : ' disabled';
    let SYS = [], OWN = [], dirty = false, saving = false, loaded = false;

    // як писати у формулі: коротка назва — одним словом, інакше [Назва]
    const fxName = (c) => (c.short ? c.short : `[${c.label}]`);
    const fmt = (v) => (v === null || v === undefined ? '' : String(v).replace('.', ','));

    function msg(text, cls) {
        const m = document.getElementById('cnMsg');
        m.textContent = text || '';
        m.className = 'cn-msg' + (cls ? ' ' + cls : '');
    }
    function markDirty() {
        dirty = true;
        msg('Є незбережені зміни', 'is-dirty');
    }

    function sysRow(c) {
        return `<tr data-key="${esc(c.key)}">
            <td class="cn-name">${esc(c.label)}</td>
            <td><span class="cn-code" title="Клік — скопіювати">${esc(fxName(c))}</span></td>
            <td><input type="text" inputmode="numeric" class="cn-in num cn-v"
                       value="${esc(fmt(c.value))}"${dis}></td>
            <td class="cn-note">${esc(c.unit)}</td>
            <td class="cn-note">${esc(c.note)}</td>
            <td></td></tr>`;
    }
    function ownRow(c) {
        return `<tr data-key="${esc(c.key || '')}">
            <td><input type="text" class="cn-in cn-l" maxlength="60" placeholder="Назва"
                       value="${esc(c.label)}"${dis}></td>
            <td><input type="text" class="cn-in cn-s" maxlength="30"
                       placeholder="одним словом" value="${esc(c.short)}"${dis}></td>
            <td><input type="text" inputmode="decimal" class="cn-in num cn-v"
                       value="${esc(fmt(c.value))}"${dis}></td>
            <td><input type="text" class="cn-in cn-u" maxlength="12" placeholder="дн"
                       value="${esc(c.unit)}"${dis}></td>
            <td><input type="text" class="cn-in cn-n" maxlength="200"
                       placeholder="навіщо це число" value="${esc(c.note)}"${dis}></td>
            <td>${canEdit ? '<button type="button" class="cn-del" title="Прибрати">✕</button>' : ''}</td></tr>`;
    }

    function render() {
        sysBody.innerHTML = SYS.map(sysRow).join('');
        ownBody.innerHTML = OWN.length ? OWN.map(ownRow).join('')
            : `<tr><td colspan="6" class="cn-empty">Власних налаштувань ще немає.
               ${canEdit ? 'Натисніть «+ Додати», щоб завести число, яке потрібне у ваших формулах.' : ''}</td></tr>`;
        document.getElementById('cnCount').textContent = OWN.length ? `· ${OWN.length}` : '';
        document.getElementById('cnAdd').hidden = !canEdit;
        document.getElementById('cnSave').hidden = !canEdit;
    }

    // назва у формулі теж має жити на сторінці: підсвітка формул параметрів
    // (herd_fxhl) бере її з window.HERD_CONSTS
    function publish() { window.HERD_CONSTS = SYS.concat(OWN); }

    async function load() {
        const r = await apiGet('/api/herd/consts');
        if (!r || !r.ok) { sysBody.innerHTML = '<tr><td colspan="6" class="cn-empty">Не вдалося прочитати налаштування</td></tr>'; return; }
        SYS = r.system || []; OWN = r.custom || [];
        loaded = true;
        publish();
        render();
        dirty = false;
        msg(canEdit ? '' : 'Змінювати може лише той, хто керує гілкою стада');
    }

    // рядки власних — із полів, як є зараз на екрані
    function readOwn() {
        return [...ownBody.querySelectorAll('tr[data-key]')].map((tr) => ({
            key: tr.dataset.key || '',
            label: tr.querySelector('.cn-l').value.trim(),
            short: tr.querySelector('.cn-s').value.trim(),
            value: tr.querySelector('.cn-v').value.trim(),
            unit: tr.querySelector('.cn-u').value.trim(),
            note: tr.querySelector('.cn-n').value.trim(),
        }));
    }

    // перемальовування бере значення з SYS, тож набране в полях циклу, але ще
    // не збережене, треба спершу забрати з екрана — інакше «+ Додати» чи ✕
    // тихо повертали б старі числа
    function keepSys() {
        sysBody.querySelectorAll('tr[data-key]').forEach((tr) => {
            const c = SYS.find((x) => x.key === tr.dataset.key);
            if (c) c.value = tr.querySelector('.cn-v').value;
        });
    }

    // число в полі: пробіли між тисячами й кома — дозволені, решта — ні
    const numOk = (v) => /^-?\d+([.,]\d+)?$/.test(String(v).replace(/[\s ]/g, ''));

    // поля й кнопки на час запиту гасимо: набране під час збереження
    // перемальовування мовчки затерло б
    function lockAll(on) {
        document.querySelectorAll('#bldConsts .cn-in, #cnAdd, #cnSave, .cn-del')
            .forEach((el) => { el.disabled = on || !canEdit; });
    }

    async function save() {
        // замок — першим рядком (урок 2.39.55); не прочитали — не пишемо, інакше
        // порожня таблиця на екрані стерла б усі власні налаштування
        if (saving || !loaded) return;
        saving = true;
            try {
            let bad = null;
            const system = {};
            sysBody.querySelectorAll('tr[data-key]').forEach((tr) => {
                const inp = tr.querySelector('.cn-v');
                const ok = numOk(inp.value) && parseFloat(inp.value.replace(',', '.')) > 0;
                inp.classList.toggle('is-bad', !ok);
                if (!ok && !bad) bad = inp;
                system[tr.dataset.key] = inp.value.trim();
            });
            ownBody.querySelectorAll('tr[data-key]').forEach((tr) => {
                const v = tr.querySelector('.cn-v'), l = tr.querySelector('.cn-l');
                const empty = !l.value.trim() && !v.value.trim();
                const vOk = empty || numOk(v.value), lOk = empty || !!l.value.trim();
                v.classList.toggle('is-bad', !vOk);
                l.classList.toggle('is-bad', !lOk);
                if (!vOk && !bad) bad = v;
                if (!lOk && !bad) bad = l;
            });
            if (bad) {
                msg('Виправте поле, виділене червоним: потрібне число або назва', 'is-err');
                bad.focus();
                return;
            }
            lockAll(true);
            const r = await apiSend('/api/herd/consts', 'POST', { system, custom: readOwn() });
            if (!r || !r.ok) {
                msg((r && r.error) || 'Сервер не відповів', 'is-err');
                return;
            }
            SYS = r.system || []; OWN = r.custom || [];
            publish();
            render();
            dirty = false;
            msg('Збережено — формули вже рахують з новими числами');
            if (window.toast) toast('Налаштування збережено', 'success');
        } finally {
            saving = false;
            lockAll(false);
        }
    }

    document.getElementById('cnAdd').addEventListener('click', () => {
        if (!loaded) return;
        keepSys();
        OWN = readOwn();
        OWN.push({ key: '', label: '', short: '', value: '', unit: '', note: '' });
        render();
        markDirty();
        const rows = ownBody.querySelectorAll('tr[data-key]');
        const last = rows[rows.length - 1];
        if (last) last.querySelector('.cn-l').focus();
    });
    ownBody.addEventListener('click', (e) => {
        const del = e.target.closest('.cn-del');
        if (!del) return;
        del.closest('tr').remove();
        keepSys();
        OWN = readOwn();
        render();
        markDirty();
    });
    document.getElementById('bldConsts').addEventListener('input', (e) => {
        if (e.target.classList.contains('cn-in')) {
            e.target.classList.remove('is-bad');
            markDirty();
        }
    });
    // Enter у будь-якому полі — зберегти (як у довідниках)
    document.getElementById('bldConsts').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.classList.contains('cn-in')) {
            e.preventDefault();
            save();
        }
    });
    document.getElementById('cnSave').addEventListener('click', save);
    // клік по назві — у буфер, щоб вставити у формулу
    document.getElementById('bldConsts').addEventListener('click', async (e) => {
        const c = e.target.closest('.cn-code');
        if (!c) return;
        try {
            await navigator.clipboard.writeText(c.textContent);
            if (window.toast) toast(`Скопійовано: ${c.textContent}`, 'success');
        } catch (_) { /* буфер недоступний — назву видно, можна переписати */ }
    });
    // не загубити зміни, пішовши зі сторінки
    window.addEventListener('beforeunload', (e) => {
        if (dirty) { e.preventDefault(); e.returnValue = ''; }
    });

    load();
})();

/* Telegram: кожне внесення подій стада — у гілку «Управління стада» групи ферми
   (Роман 2026-09-27). Галочка зберігається одразу; під нею — що зараз відбувається. */
(function () {
    const box = document.getElementById('tgOn');
    const st = document.getElementById('tgState');
    const sum = document.getElementById('tgSum');
    const sumNote = document.getElementById('tgSumNote');
    if (!box || !st) return;
    // зведення стада (Роман 2026-09-27): з яких панелей «Огляду» беруться числа
    const SUM_LINES = { fur: 'фуражні', milk: 'дійні', dry: 'сухостій',
        hef: 'телиці', net: 'нетелі', bull: 'бики' };
    function showSum(d) {
        if (!sum || !sumNote) return;
        sum.checked = !!d.sum_on;
        sum.disabled = !window.IS_ADMIN || !!d.satellite || !d.channel || !d.on;
        const p = d.sum_panels || {};
        const keys = Object.keys(SUM_LINES);
        const miss = keys.filter((k) => !p[k]);
        let t = `О ${d.sum_hour}:00 — нове зі звуком, далі за день переписується, коли змінюються`
            + ' числа. Поголівʼя — з панелей «Огляду»: '
            + keys.filter((k) => p[k]).map((k) => `${SUM_LINES[k]} — «${p[k]}»`).join(' · ')
            + '; за день — запуск, отел, приплід, вибуття (за датою події).';
        if (miss.length) {
            t += ` Немає панелі для: ${miss.map((k) => SUM_LINES[k]).join(', ')} — там стоятиме «—».`;
        }
        if (!d.on) t = 'Працює разом із галочкою «Кожне внесення подій».';
        else if (d.sum_on && d.sum_error) t += ' Не порахувалось: ' + d.sum_error;
        sumNote.textContent = t;
        sumNote.classList.toggle('is-err', !!d.on && (miss.length > 0 || (!!d.sum_on && !!d.sum_error)));
    }
    const at = (s) => (s ? `${s.slice(8, 10)}.${s.slice(5, 7)} о ${s.slice(11, 16)}` : '');
    function show(d) {
        box.checked = !!d.on;
        box.disabled = !window.IS_ADMIN || !!d.satellite || !d.channel;
        let t;
        let bad = false;
        if (d.satellite) t = 'На цьому компʼютері не діє: у гілку пише сервер ферми.';
        else if (!d.channel) {
            t = 'Немає звʼязку з ботом: у налаштуваннях молока не вказано адресу сервера й токен.';
            bad = true;
        } else if (!d.on) t = 'Вимкнено.';
        else if (d.error) { t = 'Бот не прийняв: ' + d.error; bad = true; }
        else {
            t = `Повідомлення йде через ${d.grace} хв після останньої правки внесення`
                + (d.last ? ` · востаннє ${at(d.last)}.` : ' · від увімкнення ще нічого не вносили.');
        }
        st.textContent = t;
        st.classList.toggle('is-err', bad);
        showSum(d);
    }
    async function load() {
        const r = await apiGet('/api/herd/tg').catch(() => null);
        if (r && r.ok) show(r);
        else st.textContent = 'Не вдалося прочитати стан.';
    }
    box.addEventListener('change', async () => {
        const want = box.checked;
        box.disabled = true;
        const r = await apiSend('/api/herd/tg', 'POST', { on: want }).catch(() => null);
        if (!r || !r.ok) {
            if (window.toast) toast((r && r.error) || 'Не вдалося зберегти', 'error');
            await load();
            return;
        }
        show(r);
        if (window.toast) {
            toast(r.on ? 'Увімкнено: внесення підуть у гілку «Управління стада»' : 'Вимкнено', 'success');
        }
    });
    if (sum) {
        sum.addEventListener('change', async () => {
            const want = sum.checked;
            sum.disabled = true;
            const r = await apiSend('/api/herd/tg', 'POST', { sum: want }).catch(() => null);
            if (!r || !r.ok) {
                if (window.toast) toast((r && r.error) || 'Не вдалося зберегти', 'error');
                await load();
                return;
            }
            show(r);
            if (window.toast) {
                toast(r.sum_on ? `Зведення стада — щодня о ${r.sum_hour}:00 у «Управління стада»`
                    : 'Зведення вимкнено', 'success');
            }
        });
    }
    load();
})();
