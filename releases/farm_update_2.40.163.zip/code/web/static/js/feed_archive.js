/* Архів звітів годівлі: перенос файлів у _archive + дані в БД. */
const $ = (id) => document.getElementById(id);
const kb = (n) => (n ? (n / 1024).toLocaleString('uk-UA', { maximumFractionDigits: 0 }) + ' КБ' : '');
let files = [];

/* Архівування йде ФОНОМ (Роман 2026-09-28: «заархівувала, просто не видало ніякого
   зворотного звʼязку»): запит лише запускає роботу, а сторінка щосекунди питає, на якому
   вона кроці, і пише це біля кнопки. Оновили сторінку посеред роботи — показ продовжиться. */
let JOB_ID = '', JOB_T = null, POLL = false, PGEN = 0;
const fw = (n) => { const d = n % 10, h = n % 100; return d === 1 && h !== 11 ? 'файл' : (d >= 2 && d <= 4 && (h < 12 || h > 14) ? 'файли' : 'файлів'); };
function jobLine(job) {
    const el = $('faJob');
    const btn = $('faArchiveBtn');
    const run = !!(job && job.state === 'running');
    if (btn) btn.disabled = run;
    if (!el) return;
    const step = job && job.step === 'move'
        ? (job.where === 'onedrive' ? 'переношу файли в OneDrive' : 'переношу файли в _archive')
        : 'зберігаю заміси в базу';
    el.innerHTML = run ? `<span class="fa-spin" aria-hidden="true"></span>Архівую ${job.n} ${fw(job.n)} · ${step}…` : '';
}
async function pollJob() {
    clearTimeout(JOB_T);
    POLL = true;
    const my = ++PGEN;                                                  // один ланцюжок опитування
    let r;
    try { r = await apiGet('/api/feed/archive-status'); } catch (e) { r = null; }
    if (my !== PGEN) return;
    const job = r && r.ok !== false ? r.job : null;
    if (!job) { JOB_T = setTimeout(pollJob, 2000); return; }       // мережа мигнула — питаємо далі
    if (job.state === 'running') {
        if (!JOB_ID) JOB_ID = job.id;
        jobLine(job);
        JOB_T = setTimeout(pollJob, 1000);
        return;
    }
    POLL = false;
    jobLine(null);
    if (!JOB_ID) return;
    if (job.id !== JOB_ID) {                                          // сервер перезапустився посеред роботи
        toast('Архівування перервалось: сервер перезапустився. Що не встигло перенестись, лишилось у теці — можна повторити.', 'error');
    } else {
        const res = job.result || {};
        if (res.error) toast(res.error, 'error');
        else {
            toast(`Архівовано ${res.moved} ${fw(res.moved)} · замісів у базі: ${res.stored}`, 'success');
            if (res.warn) toast(res.warn, 'error');                   // частину не перенесло — які саме
        }
    }
    JOB_ID = '';
    load();
}

function statCard(cap, val, sub) {
    return `<div class="fl-kpi-card"><span class="k-cap">${cap}</span>
        <span class="k-val">${val}</span>${sub ? `<span class="k-sub">${sub}</span>` : ''}</div>`;
}

function render() {
    const body = $('faBody');
    if (!files.length) {
        body.innerHTML = '<tr><td colspan="4" class="empty">Файлів немає</td></tr>';
        $('faCount').textContent = '';
        return;
    }
    body.innerHTML = files.map((f, i) => {
        const per = (f.date_from || f.date_to)
            ? `${f.date_from || '…'} — ${f.date_to || '…'}` : '';
        return `<tr data-i="${i}">
            <td class="fa-cbcell"><input type="checkbox" class="fa-cb" data-i="${i}"></td>
            <td title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</td>
            <td class="fa-per">${per}</td>
            <td class="num">${kb(f.size)}</td></tr>`;
    }).join('');
    $('faCount').textContent = `Файлів: ${files.length}`;
    syncRowSel();
}

function syncRowSel() {
    document.querySelectorAll('#faBody tr').forEach((tr) => {
        const cb = tr.querySelector('.fa-cb');
        tr.classList.toggle('is-sel', !!(cb && cb.checked));
    });
}

async function load() {
    $('faBody').innerHTML = '<tr><td colspan="4" class="empty">Завантаження…</td></tr>';
    let r;
    try { r = await apiGet('/api/feed/files'); }
    catch (e) { r = { ok: false }; }
    if (!r || !r.ok) { $('faBody').innerHTML = '<tr><td colspan="4" class="empty">Помилка</td></tr>'; return; }
    files = r.files || [];
    const dirInp = $('fsDir');
    if (dirInp && document.activeElement !== dirInp) dirInp.value = r.folder || '';
    $('faArchDir').textContent = r.archive_dir || '—';
    $('faStats').innerHTML = statCard('Файлів у теці', files.length)
        + statCard('Замісів у базі', (r.db_events || 0).toLocaleString('uk-UA'))
        + statCard('Файлів у архіві', r.archived_count || 0);
    if (r.note && !files.length) {
        $('faBody').innerHTML = `<tr><td colspan="4" class="empty">${escapeHtml(r.note)}</td></tr>`;
        $('faCount').textContent = '';
        return;
    }
    showDirInfo();
    const all = $('faAll'); if (all) all.checked = false;
    const old = $('faOld'); if (old) old.checked = false;
    render();
    const job = r.archive_job;
    if (job && job.state === 'running' && !POLL) { jobLine(job); pollJob(); }
}

/* Показати, куди НАСПРАВДІ пишуться звіти. Роман 2026-09-03: журнал каже
   «оновлено», а файла в теці немає — бо теку, якої нема, застосунок мовчки
   створює і пише туди. Повний шлях і найсвіжіший файл роблять це очевидним. */
async function showDirInfo() {
    const box = $('fsDirInfo');
    if (!box) return;
    let r;
    try { r = await apiGet('/api/feed/profeed/dir'); } catch (e) { r = null; }
    if (!r || !r.ok) { box.textContent = ''; return; }
    if (!r.dir) { box.textContent = 'Теку ще не вказано.'; return; }
    if (!r.exists) {
        box.innerHTML = '<b style="color:#b4232a">Теки не існує:</b> '
            + escapeHtml(r.abs || r.dir)
            + ' — завантажені звіти опиняться саме тут (тека створиться сама).';
        return;
    }
    box.innerHTML = 'Файли зберігаються тут: <b>' + escapeHtml(r.abs || r.dir) + '</b>'
        + ' · звітів у теці: <b>' + (r.files || 0) + '</b>'
        + (r.newest ? ' · найсвіжіший: <b>' + escapeHtml(r.newest) + '</b> ('
                      + escapeHtml(r.newest_at) + ')' : '');
}

document.addEventListener('DOMContentLoaded', () => {
    load();
    $('faReload').addEventListener('click', load);

    // Згортання панелей — СТАНДАРТ налаштувань: клік по .panel-head тогліт
    // .is-collapsed на самій панелі (стан памʼятається за data-collapse).
    document.querySelectorAll('.settings-airy .panel[data-collapse]').forEach((p) => {
        const key = 'farm:fs_sect_' + p.dataset.collapse;
        try {
            if (localStorage.getItem(key) === '1') p.classList.add('is-collapsed');
        } catch (e) { /**/ }
        const head = p.querySelector('.panel-head');
        if (!head) return;
        head.addEventListener('click', () => {
            const c = p.classList.toggle('is-collapsed');
            try { localStorage.setItem(key, c ? '1' : '0'); } catch (e) { /**/ }
        });
    });

    // Тека звітів Profeed — зберегти / вибрати
    const save = $('fsSave');
    if (save) save.addEventListener('click', async () => {
        const dir = ($('fsDir').value || '').trim();
        try {
            const r = await apiSend('/api/feed/profeed/dir', 'POST', { dir });
            if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); }
            else { toast('Теку збережено', 'success'); load(); }
        } catch (e) { toast('Сервер не відповів', 'error'); }
    });
    const pick = $('fsPick');
    if (pick) pick.addEventListener('click', async () => {
        try {
            const r = await apiSend('/api/feed/profeed/pick-dir', 'POST', {});
            if (r && r.ok && r.dir) { $('fsDir').value = r.dir; toast('Обрано теку', 'success'); load(); }
            else if (r && r.error) { toast(r.error, 'error'); }
        } catch (e) { toast('Сервер не відповів', 'error'); }
    });

    $('faAll').addEventListener('change', (e) => {
        document.querySelectorAll('#faBody .fa-cb').forEach((c) => { c.checked = e.target.checked; });
        syncRowSel();
    });
    // «Виділити до дати» — усі файли, чий кінець періоду ≤ обраної дати
    const applyOld = () => {
        const on = $('faOld').checked;
        const dt = $('faOldDate').value;
        document.querySelectorAll('#faBody .fa-cb').forEach((c) => {
            const f = files[+c.dataset.i];
            const end = f.date_to || f.date_from || '';
            c.checked = on && dt && end && end <= dt;
        });
        syncRowSel();
    };
    $('faOld').addEventListener('change', applyOld);
    $('faOldDate').addEventListener('change', () => { $('faOld').checked = true; applyOld(); });

    $('faBody').addEventListener('change', (e) => {
        if (e.target.classList.contains('fa-cb')) syncRowSel();
    });
    // клік по рядку теж перемикає чекбокс (окрім самого чекбокса)
    $('faBody').addEventListener('click', (e) => {
        if (e.target.closest('input')) return;
        const tr = e.target.closest('tr[data-i]');
        if (!tr) return;
        const cb = tr.querySelector('.fa-cb');
        if (cb) { cb.checked = !cb.checked; syncRowSel(); }
    });

    const arch = $('faArchiveBtn');
    if (arch) arch.addEventListener('click', async () => {
        const names = [...document.querySelectorAll('#faBody .fa-cb:checked')]
            .map((c) => files[+c.dataset.i].name);
        if (!names.length) { toast('Виберіть файли', 'error'); return; }
        if (!await confirmAction(`Архівувати вибрані файли (${names.length})?\n\n`
            + 'Дані збережуться в БД, файли переїдуть у теку _archive. Склад не зміниться.')) return;
        arch.disabled = true;
        let r;
        try { r = await apiSend('/api/feed/archive-files', 'POST', { names }); } catch (e) { r = null; }
        if (!r || !r.ok) {
            toast((r && r.error) || 'Сервер не відповів', 'error');
            arch.disabled = false;
            return;
        }
        if (r.busy) toast('Архівування вже йде — показую, як воно просувається', 'error');
        JOB_ID = (r.job && r.job.id) || '';
        jobLine(r.job);
        pollJob();
    });
});
