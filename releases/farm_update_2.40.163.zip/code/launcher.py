#!/usr/bin/env python3
"""Пульт керування сервером «Облік ферми» (вікно, без термінала).

Показує стан (встановлення бібліотек / запуск / працює / зупинено), журнал,
і кнопки: Відкрити в браузері · Перезапустити · Зупинити. Вікно можна згорнути.
Сервер запускається як окремий процес (start_server.py); пульт ним керує.

Якщо Tkinter недоступний — просто запускає сервер напряму (без вікна).
"""
from __future__ import annotations

import os
import sys
import subprocess
import threading
import time
import webbrowser
import urllib.request
import urllib.error
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _pick_free_port(preferred: int = 5000, tries: int = 20) -> int:
    """Вибрати ВІЛЬНИЙ порт, починаючи з preferred. Це критично: на macOS
    порт 5000 часто зайнятий AirPlay Receiver. Лаунчер і сервер мають
    домовитись про ОДИН порт, інакше браузер відкривається не туди."""
    import socket
    for off in range(tries):
        p = preferred + off
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return preferred


# Бажаний порт можна задати через FARM_PORT, але якщо він зайнятий —
# беремо наступний вільний (і саме на ньому відкриваємо браузер).
PORT = _pick_free_port(int(os.environ.get("FARM_PORT", "5050")))
URL = f"http://127.0.0.1:{PORT}/"


# ─── «Застосунок має бути завжди відкритим» ────────────────────────────────
#: Роман 2026-09-25: «якщо людина випадково натиснула хрестик і закрила
#: застосунок, треба вікно: "Застосунок повинен завжди бути відкритим. Ви точно
#: хочете його закрити?"». Поки застосунок закритий, компʼютер НЕ обмінюється з
#: фермою і не виконує автоматичних дій — а виглядає це просто як «нічого не
#: оновлюється», тож помилку помічають нескоро.
CLOSE_TITLE = "Застосунок має бути завжди відкритим"
CLOSE_TEXT = (
    "Поки «Облік ферми» закритий, цей компʼютер не обмінюється даними з фермою "
    "й не виконує автоматичних дій (списання, оновлення).\n\n"
    "Ви точно хочете його закрити?")


def _child_env() -> dict:
    """Середовище для сервера. `FARM_LAUNCHER_NEW` — ознака, що цей запускач
    уміє заміщати САМ СЕБЕ після оновлення (з 2.40.13). Старий запускач її не
    ставить, тож сервер бачить, що людині треба один раз закрити й відкрити
    застосунок — інакше виправлення в запускачі лежать на диску мертвими."""
    env = dict(os.environ)
    env["FARM_LAUNCHER_NEW"] = "1"
    return env


def _reexec_self() -> None:
    """Перезапустити САМ ЛАУНЧЕР (а не лише сервер) після оновлення.

    🛑 Урок 2026-09-25: оновлення підміняє файли, але `launcher.py` уже
    прочитаний у памʼять — і працює СТАРИЙ код, доки процес живий. Тому
    виправлення в самому лаунчері (перепит на закриття, «не відкривати
    вкладку») не діяли: сервер перезапускався, лаунчер лишався старий.
    Тепер на прохання про перезапуск лаунчер заміщає себе новим собою.

    ⚠️ Додаємо `--quiet`: це перезапуск, а не перший старт — вкладку
    відкривати не треба. Якщо заміщення не вдалося, повертаємось і
    перезапускаємо сервер звичайним способом.
    """
    try:
        args = [a for a in sys.argv[1:] if a != "--quiet"] + ["--quiet"]
        _dbg("перезапускаю сам лаунчер: " + " ".join(args))
        sys.stdout.flush()
        os.execv(sys.executable, [sys.executable, str(HERE / "launcher.py")] + args)
    except Exception as exc:  # noqa: BLE001
        _dbg("не вдалося замістити лаунчер: " + str(exc))


def _confirm_close(title: str = CLOSE_TITLE, text: str = CLOSE_TEXT) -> bool:
    """Перепитати перед закриттям. True — людина справді хоче закрити.

    ⚠️ Вікно малюємо ЗАСОБАМИ СИСТЕМИ, а не Tkinter: у режимі трею (ярлики
    інсталятора — саме він) жодного вікна Tk не існує, і створювати його
    заради питання не можна. Якщо нічого не вдалося показати — НЕ тримаємо
    людину силоміць: дозволяємо закрити.
    """
    try:
        if os.name == "nt":
            import ctypes
            MB_YESNO, MB_ICONWARNING, MB_DEFBUTTON2 = 0x4, 0x30, 0x100
            MB_TOPMOST, MB_SETFOREGROUND = 0x40000, 0x10000
            r = ctypes.windll.user32.MessageBoxW(
                0, text, title,
                MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2 | MB_TOPMOST | MB_SETFOREGROUND)
            return r == 6                      # IDYES
        if sys.platform == "darwin":
            scr = ('display dialog {t} with title {ttl} buttons '
                   '{{"Залишити відкритим", "Закрити"}} default button '
                   '"Залишити відкритим" with icon caution').format(
                       t=_osa_str(text), ttl=_osa_str(title))
            r = subprocess.run(["osascript", "-e", scr],
                               capture_output=True, text=True, timeout=120)
            return "Закрити" in (r.stdout or "")
    except Exception:  # noqa: BLE001
        pass
    try:                                        # запасний шлях — вікно Tkinter
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        ans = messagebox.askyesno(title, text, default="no", icon="warning")
        r.destroy()
        return bool(ans)
    except Exception:  # noqa: BLE001
        return True                             # показати не вдалося — не тримаємо


def _osa_str(s: str) -> str:
    """Рядок для osascript: лапки й похилі риски мають бути екрановані."""
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


# ─── Захист від подвійного запуску (single-instance) ───────────────────────
# Порт-замок (атомарно на рівні ОС, без «застряглих» lock-файлів) + файл із
# реальною адресою працюючого сервера, щоб другий запуск просто відкрив браузер.
_LOCK_PORT = 49677
_single_lock = None  # тримаємо сокет відкритим увесь час життя процесу


def _restart_watch(do_restart, alive=lambda: True) -> None:
    """Сервер просить перезапуск (після встановлення оновлення) міткою
    `restart.flag` у теці стану. Лаунчер її бачить, прибирає і перезапускає
    процес РІДНИМ способом — тоді трей/вікно й далі керують сервером.
    Роман 2026-09-09: «було б гарно, якби і сервер на локальному ПК
    автоматом перезапустився»."""
    import threading

    def loop() -> None:
        mark = _state_dir() / "restart.flag"
        while alive():
            time.sleep(1.0)
            try:
                if not mark.exists():
                    continue
                mark.unlink(missing_ok=True)
            except OSError:
                continue
            _dbg("отримано прохання перезапуску (restart.flag)")
            try:
                do_restart()
            except Exception as exc:     # noqa: BLE001
                _dbg("перезапуск не вдався: " + str(exc))

    threading.Thread(target=loop, daemon=True, name="restart-watch").start()


def _state_dir() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    p = Path(base) / "FarmDB"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return p


def _acquire_single_instance() -> bool:
    """True — ми перша (єдина) копія; False — сервер уже працює деінде."""
    global _single_lock
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", _LOCK_PORT))
        s.listen(1)
        _single_lock = s
        return True
    except OSError:
        try:
            s.close()
        except OSError:
            pass
        return False


def _running_url() -> str:
    try:
        return (_state_dir() / "farm_server_url.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def _write_running_url(url: str) -> None:
    try:
        (_state_dir() / "farm_server_url.txt").write_text(url, encoding="utf-8")
    except OSError:
        pass


def _server_reachable(url: str) -> bool:
    """Чи хтось слухає на адресі url (звичайна TCP-перевірка порту)."""
    if not url:
        return False
    import socket
    try:
        host = url.split("//", 1)[1].split("/", 1)[0]
        h, _, p = host.partition(":")
        with socket.create_connection((h or "127.0.0.1", int(p or "80")), timeout=1):
            return True
    except Exception:  # noqa: BLE001
        return False

# macOS: уникнути падінь Cocoa при fork() з підпроцесу
os.environ.setdefault("OBJC_DISABLE_INITIALIZE_FORK_SAFETY", "YES")

# Онлайн-страховка для Windows: якщо у вбудованому Python немає Tkinter —
# докачуємо його з НАШОГО GitHub (надійно, ми ним керуємо) і розпаковуємо.
WIN_TKINTER_URL = ("https://github.com/romanlubchenko-boop/farm-updates/"
                   "releases/download/win-deps/win-tkinter.zip")


def _ensure_tkinter_windows() -> None:
    """Windows + вбудований Python без Tkinter → докачати його з GitHub.
    Системний Python (де Tkinter уже є) не чіпаємо."""
    if os.name != "nt":
        return
    pyhome = Path(sys.executable).resolve().parent
    if (pyhome / "DLLs" / "_tkinter.pyd").exists():
        return  # Tkinter уже на місці (вшито інсталятором)
    try:
        import urllib.request as _ur
        import ssl
        import io
        import zipfile
        _dbg("Tkinter відсутній — качаю з GitHub…")
        req = _ur.Request(WIN_TKINTER_URL, headers={"User-Agent": "Mozilla/5.0"})
        try:
            data = _ur.urlopen(req, timeout=90,
                               context=ssl.create_default_context()).read()
        except Exception:  # noqa: BLE001 — антивірус/проксі підміняє TLS
            data = _ur.urlopen(req, timeout=90,
                               context=ssl._create_unverified_context()).read()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            z.extractall(pyhome)          # розпакує DLLs/, tcl/, Lib/tkinter
        _dbg("Tkinter докладено з GitHub")
    except Exception as exc:  # noqa: BLE001
        _dbg(f"не вдалось докласти Tkinter: {exc}")


def _set_tcl_env() -> None:
    """Вказати tcl/tk-бібліотеки поряд із python.exe (щоб не було помилки
    «can't find a usable init.tcl»)."""
    if os.name != "nt":
        return
    pyhome = Path(sys.executable).resolve().parent
    tcl = pyhome / "tcl" / "tcl8.6"
    tk = pyhome / "tcl" / "tk8.6"
    if (tcl / "init.tcl").exists():
        os.environ.setdefault("TCL_LIBRARY", str(tcl))
    if tk.exists():
        os.environ.setdefault("TK_LIBRARY", str(tk))

# Детальний лог поряд із кодом (доступний для діагностики)
import datetime as _dt
_LOG_PATH = HERE / "launcher_debug.log"
try:
    _logf = open(_LOG_PATH, "a", buffering=1, encoding="utf-8")
    sys.stderr = _logf
except Exception:  # noqa: BLE001
    _logf = None


def _dbg(msg: str) -> None:
    line = f"[{_dt.datetime.now().strftime('%H:%M:%S')}] {msg}"
    try:
        if _logf:
            _logf.write(line + "\n")
            _logf.flush()
    except Exception:  # noqa: BLE001
        pass


_dbg("=" * 50)
_dbg(f"СТАРТ пульта. Python={sys.version.split()[0]} exe={sys.executable}")
_dbg(f"PORT={PORT} HERE={HERE}")


def _server_up() -> bool:
    try:
        urllib.request.urlopen(URL, timeout=1.0)
        return True
    except urllib.error.HTTPError:
        return True          # відповідає (напр. редірект на /login) — живий
    except Exception:        # noqa: BLE001
        return False


def _tray_importable() -> bool:
    try:
        import pystray, PIL  # noqa: F401,E401
        return True
    except Exception:        # noqa: BLE001
        return False


def _ensure_tray_deps() -> bool:
    """Windows: довстановити pystray + pillow для іконки в треї, якщо їх ще
    немає. Повертає True, якщо трей доступний."""
    if os.name != "nt":
        return _tray_importable()
    if _tray_importable():
        return True
    _dbg("встановлюю pystray/pillow для трея…")
    kw = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    for extra in ([], ["--user"], ["--break-system-packages"]):
        try:
            rc = subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "--disable-pip-version-check", "-q",
                 "pystray", "pillow"] + extra, **kw).returncode
            _dbg(f"pip pystray rc={rc} extra={extra}")
            if rc == 0 and _tray_importable():
                _dbg("pystray/pillow встановлено")
                return True
        except Exception as exc:   # noqa: BLE001
            _dbg("tray deps install fail: " + str(exc))
    return False


def _notify_mac(text: str) -> None:
    if sys.platform != "darwin":
        return
    try:
        subprocess.run(["osascript", "-e",
                        f'display notification "{text}" with title "Облік ферми"'],
                       timeout=5)
    except Exception:  # noqa: BLE001
        pass


def _run_no_gui(open_browser: bool = True) -> None:
    """Немає Tkinter (напр. вбудований Python у Windows-інсталяторі) або застарілий
    Tk 8.5. Якщо доступний pystray — показуємо ІКОНКУ В ТРЕЇ для керування
    сервером (Tkinter їй не потрібен). Інакше — просто запускаємо сервер напряму."""
    try:
        import pystray
        from PIL import Image, ImageDraw
    except Exception as exc:        # noqa: BLE001
        _dbg(f"трей недоступний ({exc}) → exec start_server.py")
        _notify_mac("Сервер запускається, зачекайте. Браузер відкриється сам. "
                    "Щоб зупинити — вийдіть із програми (Cmd-Q).")
        os.execv(sys.executable,
                 [sys.executable, str(HERE / "start_server.py"), "--port", str(PORT)])
        return

    _dbg("режим без вікна з треєм (pystray)")
    st = {"proc": None}

    def _start() -> None:
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        st["proc"] = subprocess.Popen(
            [sys.executable, str(HERE / "start_server.py"),
             "--no-browser", "--port", str(PORT)], cwd=str(HERE),
            env=_child_env(), **kw)

    def _stop() -> None:
        p = st.get("proc")
        if p and p.poll() is None:
            try:
                p.terminate()
                for _ in range(20):
                    if p.poll() is not None:
                        break
                    time.sleep(0.1)
                if p.poll() is None:
                    p.kill()
            except Exception:    # noqa: BLE001
                pass
        st["proc"] = None

    def _open_when_ready() -> None:
        for _ in range(60):
            try:
                urllib.request.urlopen(URL, timeout=1)
                webbrowser.open(URL)
                return
            except Exception:    # noqa: BLE001
                time.sleep(0.5)

    _start()
    if open_browser:
        threading.Thread(target=_open_when_ready, daemon=True).start()

    img = Image.new("RGB", (64, 64), "#1e9e5a")
    ImageDraw.Draw(img).ellipse((18, 18, 46, 46), fill="white")

    def _do_open(icon, item):
        webbrowser.open(URL)

    # ⚠️ ПЕРЕЗАПУСК НЕ ВІДКРИВАЄ ВКЛАДКУ (Роман 2026-09-25: «при перезапуску
    # застосунку щоб не відкривав нову вкладку в браузері»). Відколи
    # оновлення ставиться саме, перезапусків стало більше, і щоразу
    # зʼявлялась зайва вкладка — а та, у якій працюють, і так перечитує
    # себе сама. Відкрити браузер руками — пункт «Відкрити в браузері».
    def _do_restart(icon, item):
        _stop()
        time.sleep(0.4)
        _start()

    def _do_quit(icon, item):
        if not _confirm_close():
            return                       # передумали — застосунок працює далі
        _stop()
        icon.stop()

    def _restart_now() -> None:          # прохання від сервера (після оновлення)
        _stop()
        time.sleep(0.4)
        _reexec_self()                   # новий код лаунчера; не повернеться
        _start()                         # сюди доходимо, лише якщо не вдалося

    _restart_watch(_restart_now)

    menu = pystray.Menu(
        pystray.MenuItem("Відкрити в браузері", _do_open, default=True),
        pystray.MenuItem("Перезапустити сервер", _do_restart),
        pystray.MenuItem("Зупинити і вийти", _do_quit))
    icon = pystray.Icon("farm", img, "FarmApp — сервер (" + URL + ")", menu)
    try:
        icon.run()           # блокує, поки користувач не обере «Зупинити і вийти»
    finally:
        _stop()


def main() -> int:
    # Захист від подвійного запуску: якщо ми не перша копія — просто відкриваємо
    # браузер на вже працюючому сервері й виходимо (не плодимо другий сервер).
    if not _acquire_single_instance():
        existing = _running_url()
        if existing and _server_reachable(existing):
            _dbg("FarmApp уже працює → відкриваю " + existing)
            try:
                # --quiet: це заміщення себе після оновлення, а не клік
                # ярлика — вкладку відкривати НЕ треба
                if "--quiet" not in sys.argv:
                    webbrowser.open(existing)
            except Exception:  # noqa: BLE001
                pass
            _notify_mac("FarmApp уже запущено — відкрив у браузері.")
            return 0
        # Замок зайнятий, але сервера немає (стороння програма зайняла порт-замок)
        # — продовжуємо звичайний запуск.
        _dbg("порт-замок зайнятий, але сервера немає → стартуємо звичайно")
    _write_running_url(URL)

    # --tray: працювати БЕЗ вікна (іконка в треї) — типовий режим ярликів
    # з інсталятора: сервер живе у фоні, ярлик просто відкриває браузер.
    # --quiet: не відкривати браузер (для автозапуску при вході в Windows).
    if "--tray" in sys.argv:
        _ensure_tray_deps()
        _run_no_gui(open_browser=("--quiet" not in sys.argv))
        return 0

    # Онлайн-страховка: докачати Tkinter з GitHub, якщо його немає (Windows),
    # і вказати tcl/tk-бібліотеки — перед спробою імпорту.
    _ensure_tkinter_windows()
    _set_tcl_env()

    try:
        import tkinter as tk
        from tkinter import ttk
        from tkinter.scrolledtext import ScrolledText
        _dbg(f"tkinter імпортовано. TkVersion={getattr(tk,'TkVersion','?')}")
    except Exception as exc:        # noqa: BLE001
        _dbg(f"НЕМАЄ tkinter ({exc}) → запуск без вікна")
        _run_no_gui()
        return 0

    # Tk 8.5 на macOS малює «биті»/порожні вікна — не намагаємось, працюємо
    # без вікна (сервер + браузер). Для повноцінного пульта потрібен Tk 8.6+
    # (Python із python.org).
    try:
        tkver = float(getattr(tk, "TkVersion", 0) or 0)
    except (TypeError, ValueError):
        tkver = 0.0
    if sys.platform == "darwin" and tkver and tkver < 8.6:
        _dbg(f"Tk {tkver} застарілий (<8.6) → headless")
        _run_no_gui()
        return 0

    # --quiet: не відкривати вкладку на старті (так стартує заміщений лаунчер)
    state = {"proc": None, "stopping": False, "up": False,
             "opened": ("--quiet" in sys.argv)}

    root = tk.Tk()
    root.title("Облік ферми — сервер")
    root.geometry("680x455")
    _dbg("вікно Tk створено")
    root.minsize(620, 385)

    # Дрібніший шрифт + щільні кнопки, щоб усе вміщалось одним рядком.
    style = ttk.Style(root)
    style.configure("TButton", font=("", 11), padding=(6, 3))
    style.configure("TLabel", font=("", 11))
    style.configure("TCheckbutton", font=("", 11))

    top = ttk.Frame(root, padding=(14, 10, 14, 4))
    top.pack(fill="x")
    dot = tk.Label(top, text="●", font=("", 14), fg="#b0b6bf")
    dot.pack(side="left")
    status = tk.StringVar(value="Зупинено")
    ttk.Label(top, textvariable=status, font=("", 13, "bold")).pack(side="left", padx=(6, 0))

    urlrow = ttk.Frame(root, padding=(14, 0))
    urlrow.pack(fill="x")
    urlvar = tk.StringVar(value="")
    url_lbl = tk.Label(urlrow, textvariable=urlvar, foreground="#2f5fb0",
                       cursor="hand2", bg=root.cget("bg"))
    url_lbl.pack(side="left")
    url_lbl.bind("<Button-1>", lambda _e: webbrowser.open(state.get("local_url") or URL))

    btns = ttk.Frame(root, padding=(14, 6))
    btns.pack(fill="x")
    b_open = ttk.Button(btns, text="Відкрити")
    b_open.pack(side="left")
    b_restart = ttk.Button(btns, text="Перезапустити")
    b_restart.pack(side="left", padx=4)
    b_stop = ttk.Button(btns, text="Зупинити")
    b_stop.pack(side="left")
    b_min = ttk.Button(btns, text="Згорнути")
    b_min.pack(side="left", padx=4)
    b_upd = ttk.Button(btns, text="Оновити бібл.")
    b_upd.pack(side="right")
    b_copy = ttk.Button(btns, text="Копіювати лог")
    b_copy.pack(side="right", padx=4)

    # ---- Середовище: Python / бібліотеки / режим бази ----
    envrow = ttk.Frame(root, padding=(14, 0, 14, 4))
    envrow.pack(fill="x")
    envvar = tk.StringVar(value="")
    ttk.Label(envrow, textvariable=envvar, foreground="#6b7785",
              font=("", 11)).pack(side="left")

    logbox = ScrolledText(root, height=12, font=("Menlo", 10),
                          background="#0f1b2d", foreground="#cfe3ff",
                          insertbackground="#cfe3ff", relief="flat")
    logbox.pack(fill="both", expand=True, padx=12, pady=(4, 12))

    def log(line: str) -> None:
        logbox.insert("end", line if line.endswith("\n") else line + "\n")
        logbox.see("end")

    def set_status(text: str, color: str) -> None:
        status.set(text)
        dot.config(fg=color)

    # ---- середовище: Python / бібліотеки / режим бази ----
    def _lib_ver(name: str) -> str:
        try:
            import importlib.metadata as _md
            return _md.version(name)
        except Exception:  # noqa: BLE001
            return "—"

    def _refresh_env() -> None:
        pyv = sys.version.split()[0]
        try:
            tkv = getattr(tk, "TkVersion", "?")
        except Exception:  # noqa: BLE001
            tkv = "?"
        dbm = state.get("dbmode") or "—"
        envvar.set(
            f"Python {pyv} · Tk {tkv} · Flask {_lib_ver('flask')} · "
            f"openpyxl {_lib_ver('openpyxl')} · waitress {_lib_ver('waitress')} · "
            f"База: {dbm.upper()}")

    # ---- читання виводу серверного процесу ----
    def _reader(p) -> None:
        try:
            for raw in iter(p.stdout.readline, ""):
                line = raw.rstrip("\n")
                low = line.lower()
                _dbg("СЕРВЕР: " + line)
                root.after(0, log, line)
                if "журнал:" in low:
                    state["dbmode"] = line.split(":", 1)[1].strip()
                    root.after(0, _refresh_env)
                if "не встановлено" in low or "встановлюю" in low or "pip install" in low:
                    root.after(0, set_status, "Встановлення бібліотек…", "#e0a800")
            p.stdout.close()
        except Exception as exc:    # noqa: BLE001
            _dbg("_reader помилка: " + str(exc))

    def _refresh_addr() -> None:
        if not state.get("up"):
            urlvar.set("")
            return
        state["local_url"] = URL
        urlvar.set("Адреса (цей ПК): " + URL)

    def _on_up() -> None:
        # виконується в головному потоці (через root.after)
        set_status("Працює", "#1e9e5a")
        _refresh_addr()
        # вкладку відкриваємо ЛИШЕ коли сервер піднявся ВПЕРШЕ за цей запуск:
        # інакше кожен перезапуск (а з автооновленням вони часті) додавав би
        # ще одну вкладку поверх тієї, у якій і так працюють
        if not state.get("opened"):
            state["opened"] = True
            webbrowser.open(URL)

    def _on_died() -> None:
        set_status("Зупинено (процес завершився)", "#c0392b")

    # ---- моніторинг доступності сервера (НЕ чіпає віджети напряму) ----
    def _monitor() -> None:
        while True:
            time.sleep(1.0)
            p = state["proc"]
            if p is None:
                continue
            if p.poll() is not None and not state["stopping"]:
                state["up"] = False
                state["proc"] = None
                root.after(0, _on_died)
                continue
            if _server_up():
                if not state["up"]:
                    state["up"] = True
                    root.after(0, _on_up)

    def start() -> None:
        if state["proc"] and state["proc"].poll() is None:
            return
        state["stopping"] = False
        state["up"] = False
        set_status("Запускається…", "#e0a800")
        urlvar.set("")
        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        _dbg("start(): запускаю start_server.py …")
        try:
            p = subprocess.Popen(
                [sys.executable, str(HERE / "start_server.py"),
                 "--no-browser", "--port", str(PORT)],
                cwd=str(HERE), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                env=_child_env(), **kwargs)
        except Exception as exc:   # noqa: BLE001
            _dbg("start() ПОМИЛКА Popen: " + str(exc))
            log("✗ Не вдалося запустити: " + str(exc))
            set_status("Помилка", "#c0392b")
            return
        _dbg(f"start(): підпроцес PID={p.pid}")
        state["proc"] = p
        threading.Thread(target=_reader, args=(p,), daemon=True).start()

    def stop() -> None:
        state["stopping"] = True
        p = state["proc"]
        if p and p.poll() is None:
            try:
                p.terminate()
                for _ in range(20):
                    if p.poll() is not None:
                        break
                    time.sleep(0.1)
                if p.poll() is None:
                    p.kill()
            except Exception:    # noqa: BLE001
                pass
        state["proc"] = None
        set_status("Зупинено", "#b0b6bf")
        urlvar.set("")

    def restart() -> None:
        log("— Перезапуск —")
        stop()
        root.after(700, start)

    def _restart_after_update() -> None:
        # те саме, що в треї: після оновлення в памʼяті лишається СТАРИЙ
        # лаунчер, тож заміщаємо себе новим (а вкладку не відкриваємо)
        stop()
        time.sleep(0.4)
        _reexec_self()
        restart()                       # сюди доходимо, лише якщо не вдалося

    _restart_watch(lambda: root.after(0, _restart_after_update))

    def update_libs() -> None:
        b_upd.config(state="disabled")
        log("— Оновлення бібліотек (pip) … —")
        set_status("Оновлення бібліотек…", "#e0a800")

        def worker() -> None:
            req = str(HERE / "requirements.txt")

            def L(msg):
                root.after(0, log, msg)

            def _has_pip() -> bool:
                try:
                    return subprocess.run(
                        [sys.executable, "-m", "pip", "--version"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
                except Exception:  # noqa: BLE001
                    return False

            def _fix_embeddable_pth() -> None:
                """Windows embeddable Python: увімкнути site і додати
                Lib\\site-packages у python*._pth, щоб pip і встановлені пакети
                працювали. Правки лише ДОДАТКОВІ; робимо резервну копію .bak."""
                try:
                    import glob
                    pydir = os.path.dirname(os.path.abspath(sys.executable))
                    pths = glob.glob(os.path.join(pydir, "python*._pth"))
                    if not pths:
                        return
                    pth = pths[0]
                    with open(pth, "r", encoding="utf-8") as fh:
                        orig = fh.read().splitlines()
                    out, has_site, has_sp = [], False, False
                    for ln in orig:
                        s = ln.strip()
                        if s in ("#import site", "# import site"):
                            out.append("import site"); has_site = True; continue
                        if s == "import site":
                            has_site = True
                        if "site-packages" in s:
                            has_sp = True
                        out.append(ln)
                    if not has_site:
                        out.append("import site")
                    if not has_sp:
                        out.append("Lib\\site-packages")
                    if out != orig:
                        try:
                            with open(pth + ".bak", "w", encoding="utf-8") as fb:
                                fb.write("\n".join(orig) + "\n")
                        except Exception:  # noqa: BLE001
                            pass
                        with open(pth, "w", encoding="utf-8") as fh:
                            fh.write("\n".join(out) + "\n")
                        L("Налаштовано середовище Python (site-packages).")
                except Exception as exc:  # noqa: BLE001
                    L("✗ ._pth: " + str(exc))

            def _bootstrap_pip() -> bool:
                """Підняти pip у середовищі без нього (embeddable Python):
                спершу ensurepip, потім get-pip.py із bootstrap.pypa.io."""
                try:
                    subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except Exception:  # noqa: BLE001
                    pass
                if _has_pip():
                    return True
                try:
                    import tempfile
                    L("Завантажую get-pip.py …")
                    dest = os.path.join(tempfile.gettempdir(), "get-pip.py")
                    urllib.request.urlretrieve("https://bootstrap.pypa.io/get-pip.py", dest)
                    p = subprocess.Popen([sys.executable, dest, "--no-warn-script-location"],
                                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         text=True, encoding="utf-8", errors="replace", bufsize=1)
                    for raw in iter(p.stdout.readline, ""):
                        L(raw.rstrip("\n"))
                    p.stdout.close(); p.wait()
                except Exception as exc:  # noqa: BLE001
                    L("✗ get-pip: " + str(exc))
                return _has_pip()

            # Якщо pip немає (Windows embeddable) — налаштовуємо середовище й
            # ставимо pip, щоб бібліотеки реально оновлювались і на Windows.
            if not _has_pip():
                L("pip не знайдено — налаштовую середовище та встановлюю pip…")
                _fix_embeddable_pth()
                if not _bootstrap_pip():
                    L("✗ Не вдалося встановити pip (перевірте інтернет).")
                    L("  Застосунок працює й без цього — потрібні бібліотеки вбудовані.")
                    root.after(0, lambda: b_upd.config(state="normal"))
                    root.after(0, lambda: set_status("Працює" if state["up"] else "Зупинено",
                                                     "#1e9e5a" if state["up"] else "#b0b6bf"))
                    return
                L("✓ pip готовий.")

            cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "-r", req]
            for extra in ([], ["--break-system-packages"]):
                try:
                    p = subprocess.Popen(cmd + extra, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True,
                                         encoding="utf-8", errors="replace", bufsize=1)
                    for raw in iter(p.stdout.readline, ""):
                        root.after(0, log, raw.rstrip("\n"))
                    p.stdout.close()
                    if p.wait() == 0:
                        break
                except Exception as exc:  # noqa: BLE001
                    root.after(0, log, "✗ " + str(exc))
            root.after(0, log, "— Готово. Перезапустіть сервер, щоб застосувати. —")
            root.after(0, _refresh_env)
            root.after(0, lambda: b_upd.config(state="normal"))
            root.after(0, lambda: set_status("Працює" if state["up"] else "Зупинено",
                                             "#1e9e5a" if state["up"] else "#b0b6bf"))

        threading.Thread(target=worker, daemon=True).start()

    def copy_log() -> None:
        try:
            txt = logbox.get("1.0", "end").strip()
            root.clipboard_clear()
            root.clipboard_append(txt)
            log("— Лог скопійовано в буфер обміну. —")
        except Exception as exc:  # noqa: BLE001
            _dbg("copy_log fail: " + str(exc))

    b_open.config(command=lambda: webbrowser.open(URL))
    b_restart.config(command=restart)
    b_stop.config(command=stop)
    b_upd.config(command=update_libs)
    b_copy.config(command=copy_log)
    _refresh_env()

    # ── Трей (біля годинника) + підтвердження закриття ──
    def _make_tray():
        try:
            import pystray
            from PIL import Image, ImageDraw
        except Exception as exc:        # noqa: BLE001
            _dbg("трей недоступний: " + str(exc))
            return None
        img = Image.new("RGB", (64, 64), "#1e9e5a")
        ImageDraw.Draw(img).ellipse((18, 18, 46, 46), fill="white")

        def _open(icon, item):
            icon.stop()
            root.after(0, show_window)

        def _quit(icon, item):
            icon.stop()
            root.after(0, lambda: quit_app(confirm=True))

        menu = pystray.Menu(
            pystray.MenuItem("Відкрити пульт", _open, default=True),
            pystray.MenuItem("Зупинити і вийти", _quit))
        return pystray.Icon("farm", img, "Облік ферми — сервер", menu)

    def show_window() -> None:
        ic = state.get("tray")
        if ic:
            try:
                ic.stop()
            except Exception:           # noqa: BLE001
                pass
            state["tray"] = None
        try:
            root.deiconify()
            root.lift()
            root.attributes("-topmost", True)
            root.after(800, lambda: root.attributes("-topmost", False))
            root.focus_force()
        except Exception:               # noqa: BLE001
            pass

    def hide_to_tray() -> None:
        if sys.platform == "darwin":
            # macOS: ховаємо вікно повністю; повернути — кліком по іконці в Dock.
            # (iconify на macOS лишає «биту» порожню рамку.)
            root.withdraw()
            log("— Згорнуто. Клацніть іконку застосунку в Dock (внизу екрана), "
                "щоб відкрити пульт знову. —")
            _notify_mac("Пульт згорнуто. Клацніть іконку в Dock (внизу екрана), "
                        "щоб відкрити знову.")
            return
        icon = _make_tray()
        if icon is None:                # немає pystray — згортаємо на панель задач
            if not state.get("tray_ok"):
                log("Трей ще встановлюється — згорнув на панель задач. "
                    "Після перезапуску пульта «Згорнути» сховає вікно біля годинника.")
            root.iconify()
            return
        state["tray"] = icon
        root.withdraw()
        threading.Thread(target=icon.run, daemon=True).start()
        log("— Згорнуто біля годинника. Сервер працює у фоні. —")

    def quit_app(confirm: bool = False) -> None:
        if confirm and not _confirm_close():
            return                      # передумали — застосунок працює далі
        ic = state.get("tray")
        if ic:
            try:
                ic.stop()
            except Exception:           # noqa: BLE001
                pass
            state["tray"] = None
        stop()
        root.destroy()

    def on_close() -> None:
        # ⚠️ Хрестик найчастіше тиснуть, щоб ПРИБРАТИ вікно з очей, а не щоб
        # зупинити ферму (Роман 2026-09-25). Тому спершу кажемо, чим це
        # загрожує, і головною дією лишаємо «згорнути».
        from tkinter import messagebox
        ans = messagebox.askyesnocancel(
            CLOSE_TITLE,
            "Поки «Облік ферми» закритий, цей компʼютер не обмінюється даними "
            "з фермою й не виконує автоматичних дій.\n\n"
            "• Ні — згорнути біля годинника, застосунок працюватиме далі "
            "(так і треба)\n"
            "• Так — все одно зупинити й закрити\n"
            "• Скасувати — повернутися до вікна\n\n"
            "Ви точно хочете його закрити?")
        if ans is True:
            quit_app()
        elif ans is False:
            hide_to_tray()
        # ans is None → нічого не робимо

    b_min.config(command=hide_to_tray)
    root.protocol("WM_DELETE_WINDOW", on_close)

    # macOS: клік по іконці в Dock повертає сховане вікно
    if sys.platform == "darwin":
        try:
            root.createcommand("tk::mac::ReopenApplication", show_window)
        except Exception:  # noqa: BLE001
            pass

    # Спершу даємо вікну повністю промалюватися, і ЛИШЕ ПОТІМ стартуємо сервер
    # (на macOS породження підпроцесу до промальовки «вішає» вікно).
    root.update_idletasks()
    try:
        root.lift()
        root.after(2500, lambda: root.attributes("-topmost", False))
        root.attributes("-topmost", True)
    except Exception:  # noqa: BLE001
        pass
    def _prepare_tray() -> None:
        if os.name != "nt":
            state["tray_ok"] = _tray_importable()
            return
        if _tray_importable():
            state["tray_ok"] = True
            return
        root.after(0, log, "Готую згортання в трей (встановлюю pystray)…")
        ok = _ensure_tray_deps()
        state["tray_ok"] = ok
        root.after(0, log, "✓ Трей готовий — «Згорнути» сховає вікно біля годинника."
                   if ok else "⚠ Трей недоступний — «Згорнути» згорне на панель задач.")

    threading.Thread(target=_monitor, daemon=True).start()
    threading.Thread(target=_prepare_tray, daemon=True).start()
    root.after(600, start)
    _dbg("вхід у mainloop")
    try:
        root.mainloop()
    except Exception as exc:  # noqa: BLE001
        _dbg("mainloop ПОМИЛКА: " + str(exc))
    _dbg("вихід з mainloop")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException as _exc:  # noqa: BLE001
        import traceback
        _dbg("ФАТАЛЬНА ПОМИЛКА:\n" + traceback.format_exc())
        raise
