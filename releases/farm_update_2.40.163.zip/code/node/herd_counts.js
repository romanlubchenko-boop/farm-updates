// Числа панелей «Огляду» поза браузером — ТИМ САМИМ кодом, що й сторінка
// (herd_query.js + herd_panels.js). Потрібно зведенню стада в Telegram (Роман
// 2026-09-27): число в групі не сміє розходитись з тим, що на «Огляді», а
// друга копія розбору формул рано чи пізно розійшлась би з першою.
//
// stdin (JSON): {mode: "keys"|"fkeys"|"counts"|"rows"|"days", ids, formulas, params, consts, tiles,
//               lists, items, days, animals}
//   ids — панелі «Огляду» за id; formulas — {ключ: формула} (колонки поголівʼя по
//   днях, Роман 2026-09-27: «по формулам формувати поголівʼя») — рахуються так само;
//   keys   → {keys: [...]}  — які параметри тварин потрібні;
//   counts → {counts: {id|ключ: {v} | {err}}} — числа на переданих тваринах;
//   rows   → {rows: {id|ключ: [id тварин]}} — хто саме (перший показник формули);
//   fkeys  → {keys: [...], per: {ключ: [...]}} — лише ключі умов і підсумків (склад по днях);
//   conds  → {conds: {ключ: {keys} | {err}}} — умови подій руху (мовою списків);
//   match  → {match: {ключ: {ids} | {err}}} — хто з поданих pools підпадає під умову;
//   days   → {days: {ключ: {mode:'set', d0:[id…], ch:{день:[[увійшли],[вийшли]]}}
//                        | {mode:'val', v:{день: число}} | {err}}} — склад по днях.
'use strict';
// Два режими: разовий (JSON у stdin → JSON у stdout, як і доти) і --serve — процес живе й відповідає на запити
// рядок-за-рядком (JSON у рядку → JSON у рядку): сервер тримає кілька таких і не платить за старт Node щоразу
// (Роман 2026-09-29: «треба, щоб миттєво працювало»). Кожен запит — свій чистий контекст (скрипти скомпільовані раз).
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const JS = path.join(__dirname, '..', 'web', 'static', 'js');
const SCRIPTS = ['herd_query.js', 'herd_panels.js'].map((f) =>
    new vm.Script(fs.readFileSync(path.join(JS, f), 'utf8'), { filename: f }));
const SERVE = process.argv.includes('--serve');
const quiet = { log() {}, info() {}, warn() {}, error() {}, debug() {} };   // stdout — лише відповіді

function handle(input) {
const ctx = { window: {}, console: SERVE ? quiet : console };
vm.createContext(ctx);
SCRIPTS.forEach((sc) => sc.runInContext(ctx));
const W = ctx.window;
W.HERD_CONSTS = input.consts || [];
const params = input.params || [];
const tiles = input.tiles || [];
const lists = input.lists || [];
W.herdPanels.use({ lists: () => lists, tiles: () => tiles, params: () => params });
const ids = (input.ids || []).map(String);
const want = tiles.filter((t) => ids.includes(String(t.id)))
    .concat(Object.entries(input.formulas || {}).map(([k, f]) => ({ id: k, formula: f })));

/* ── Рух групи по днях (Роман 2026-09-28: «рух по голівʼї… достатньо фільтр і що
   входить в цей фільтр»). Склад групи на кожен день рахує ТОЙ САМИЙ модуль, що й
   «Огляд», — лише тварини подаються такими, якими вони були того дня (часові ряди
   значень з подій готує сервер, herd_state_series). ── */
function prepDays(f) {
    const parts = W.herdPanels.fxAllParts(f) || [];
    if (!parts.length || !String(f || '').trim()) return { err: 'формули немає' };
    if (parts.length === 1) {
        const fx = W.herdPanels.fxSides(parts[0]);
        if (fx.error) return { err: fx.error };
        if (fx.sides.length === 1) {
            const q = W.herdQuery.parse(fx.sides[0], params);
            if (q.error) return { err: q.error };
            // «скільки голів» — склад; середнє, сума, частка — число на день
            if (!(q.aggs || []).some((a) => a.fn !== 'cnt' || a.key)) return { mode: 'set', q };
        }
    }
    return { mode: 'val', f };
}

let out;
if (input.mode === 'fkeys') {
    // лише те, від чого залежить СКЛАД (умови й підсумки), без колонок BODY:
    // їх рахувати на кожен день — даремна праця
    const keys = new Set();
    const per = {};
    want.forEach((t) => {
        const mine = new Set();
        (W.herdPanels.fxAllParts(t.formula) || []).forEach((part) => {
            const fx = W.herdPanels.fxSides(part);
            if (fx.error) return;
            fx.sides.forEach((f) => {
                const q = W.herdQuery.parse(f, params);
                if (q.error) return;
                (q.filters || []).forEach((c) => mine.add(c.key));
                (q.extra || []).forEach((e) => (e.filters || []).forEach((c) => mine.add(c.key)));
                (q.aggs || []).forEach((a) => { if (a.key) mine.add(a.key); });
            });
        });
        per[t.id] = [...mine];
        mine.forEach((k) => keys.add(k));
    });
    out = { keys: [...keys], per };
} else if (input.mode === 'conds') {
    // умови подій «Руху поголівʼя» (EVENT/BORN/ENTRY): та сама мова, що в списках
    // значення зі списку, якого немає в довіднику, — помилка, а не мовчазний нуль
    // (у списках так не робимо: там стоять давні формули, і їх не ламаємо)
    const byKey = {};
    params.forEach((p) => { byKey[p.key] = p; });
    const res = {};
    Object.entries(input.conds || {}).forEach(([k, text]) => {
        const r = W.herdQuery.conds(text, params);
        if (r.error) { res[k] = { err: r.error }; return; }
        for (const f of r.filters) {
            const p = byKey[f.key] || {};
            const ch = p.choices || [];
            if (!ch.length || !['eq', 'ne'].includes(f.op)) continue;
            const known = new Set(ch.map((c) => String(c.value)));
            const miss = (f.vals || [f.v]).find((v) => v !== '' && !known.has(String(v)));
            if (miss !== undefined) {
                const some = ch.slice(0, 6).map((c) => String(c.label || c.value)
                    .replace(/^\S+ — /, '')).join(', ');
                res[k] = { err: `у «${p.label || p.key}» немає «${miss}» — є: ${some}${ch.length > 6 ? '…' : ''}` };
                return;
            }
        }
        res[k] = { keys: [...new Set(r.filters.map((f) => f.key))] };
    });
    out = { conds: res };
} else if (input.mode === 'match') {
    // хто з поданих (подій, телят, куплених) підпадає під умову
    const res = {};
    Object.entries(input.conds || {}).forEach(([k, text]) => {
        const r = W.herdQuery.conds(text, params);
        if (r.error) { res[k] = { err: r.error }; return; }
        res[k] = { ids: ((input.pools || {})[k] || []).filter((it) => W.herdQuery.passes(it, r.filters))
            .map((it) => it.id) };
    });
    out = { match: res };
} else if (input.mode === 'days') {
    // тварина: {id, a: перший день у стаді, b: день вибуття ('' — у стаді),
    //           t: {ключ: [[день, значення, підпис], …]}} — точки зміни значень
    const days = input.days || [];
    const F = {};
    want.forEach((t) => { F[t.id] = prepDays(t.formula); });
    const st = (input.animals || []).map((x) => ({ x, it: { id: x.id, p: {}, pl: {} }, ptr: {} }));
    const res = {}, prev = {};
    Object.keys(F).forEach((k) => {
        res[k] = F[k].err ? { err: F[k].err }
            : (F[k].mode === 'set' ? { mode: 'set', d0: [], ch: {} } : { mode: 'val', v: {} });
    });
    days.forEach((d, di) => {
        const items = [];
        st.forEach((s) => {
            const x = s.x;
            if (!(x.a && x.a <= d && (!x.b || x.b > d))) return;
            Object.keys(x.t).forEach((k) => {
                const pts = x.t[k];
                let i = s.ptr[k] === undefined ? -1 : s.ptr[k];
                while (i + 1 < pts.length && pts[i + 1][0] <= d) i += 1;
                if (i !== s.ptr[k]) {
                    s.ptr[k] = i;
                    const pt = i >= 0 ? pts[i] : null;
                    s.it.p[k] = pt ? pt[1] : '';
                    if (pt && pt[2]) s.it.pl[k] = pt[2]; else delete s.it.pl[k];
                }
            });
            items.push(s.it);
        });
        Object.keys(F).forEach((k) => {
            const fx = F[k];
            if (fx.err) return;
            if (fx.mode === 'set') {
                const cur = new Set(W.herdPanels.qRows(fx.q, items).map((a) => a.id));
                if (di === 0) res[k].d0 = [...cur];
                else {
                    const p = prev[k];
                    const inn = [...cur].filter((i) => !p.has(i));
                    const gone = [...p].filter((i) => !cur.has(i));
                    if (inn.length || gone.length) res[k].ch[d] = [inn, gone];
                }
                prev[k] = cur;
                return;
            }
            let r;
            try { r = W.herdPanels.ovCountOn(fx.f, items); } catch (e) { r = String(e && e.message || e); }
            if (r && typeof r === 'object' && !r.err && r.v !== undefined && r.v !== null) res[k].v[d] = r.v;
            else if (typeof r === 'string' || (r && r.err)) fx.last = typeof r === 'string' ? r : r.err;
        });
    });
    // день без числа (напр. ділення на нуль) — порожня клітинка; помилка — коли жодного
    Object.keys(F).forEach((k) => {
        if (F[k].mode === 'val' && F[k].last && !Object.keys(res[k].v).length) res[k] = { err: F[k].last };
    });
    out = { days: res };
} else if (input.mode === 'keys') {
    // як сторінка («Огляд» → ключі з формул панелей, у частці — обидві сторони)
    const keys = new Set();
    want.forEach((t) => W.herdPanels.fxAllParts(t.formula).forEach((part) => {
        const fx = W.herdPanels.fxSides(part);
        if (fx.error) return;
        fx.sides.forEach((f) => {
            const q = W.herdQuery.parse(f, params);
            if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
        });
    }));
    out = { keys: [...keys] };
} else if (input.mode === 'rows') {
    // хто саме стоїть за формулою (підказка рядка поголівʼя в конструкторі руху):
    // перший показник формули, як і число панелі
    const items = input.items || [];
    const rows = {};
    want.forEach((t) => {
        try {
            const part = (W.herdPanels.fxAllParts(t.formula) || [])[0] || '';
            const fx = W.herdPanels.fxSides(part);
            if (fx.error || !fx.sides.length) return;
            const q = W.herdQuery.parse(fx.sides[0], params);
            if (q.error) return;
            rows[t.id] = W.herdPanels.qRows(q, items).map((a) => a.id);
        } catch (e) { /* без переліку — лише число */ }
    });
    out = { rows };
} else {
    const items = input.items || [];
    const counts = {};
    want.forEach((t) => {
        if (!String(t.formula || '').trim()) { counts[t.id] = { err: 'формули немає' }; return; }
        let r;
        try {
            r = W.herdPanels.ovCountOn(t.formula, items);
        } catch (e) {
            r = String(e && e.message || e);
        }
        if (r === null || r === undefined) counts[t.id] = { err: 'порожня панель' };
        else if (typeof r === 'string') counts[t.id] = { err: r };
        else if (r.err) counts[t.id] = { err: r.err };
        else counts[t.id] = { v: r.v };
    });
    out = { counts };
}
return out;
}

if (!SERVE) {
    process.stdout.write(JSON.stringify(handle(JSON.parse(fs.readFileSync(0, 'utf8') || '{}'))));
} else {
    const rl = require('readline').createInterface({ input: process.stdin, crlfDelay: Infinity });
    rl.on('line', (line) => {
        let res;
        try { res = handle(JSON.parse(line || '{}')); } catch (e) { res = { __err: String((e && e.message) || e) }; }
        process.stdout.write(JSON.stringify(res) + '\n');
    });
    rl.on('close', () => process.exit(0));
}
