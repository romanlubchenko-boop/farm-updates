/* ============ Нова видача: накладні + історія ============
   Дизайн затверджено на макеті mockups/vydacha_new.html (Роман, 2026-09-04):
   кілька накладних одночасно (кожна на свою групу/людину), скан у активну,
   проведення кожної окремо, історія картками з періодами. Проведення — тим
   самим /api/sale/bulk, що й стара видача; редагування/скасування — ті самі
   ендпоінти. */

/* ---------- формати чисел ---------- */
// кількість: # ### — ціла без дробової, дробова з комою
const nf = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
// ціна і сума: завжди # ###,##
const money = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rawNum = (v) => +String(v).replace(/\s| /g, '').replace(',', '.') || 0;

const opLabel = {
    OUT: { text: 'Видача', cls: 'out' },
    WRITE_OFF: { text: 'Списання', cls: 'wo' },
    RETURN: { text: 'Повернення', cls: 'ret' },
};
const KIND_LABEL = { cow: 'Корови', young: 'Молодняк', pig: 'Свині' };

function optionsHtml(list, selectedId, placeholder) {
    const opts = [`<option value="">${placeholder || '—'}</option>`];
    for (const it of list) {
        const sel = String(it.id) === String(selectedId) ? ' selected' : '';
        opts.push(`<option value="${it.id}"${sel}>${escapeHtml(it.name)}</option>`);
    }
    return opts.join('');
}

/* ---------- довідники ---------- */
let blocksList = [];
let recipientsList = [];
async function loadBlocks() {
    const r = await apiGet('/api/blocks');
    blocksList = (r && r.items) || [];
}
async function loadRecipients() {
    const r = await apiGet('/api/recipients');
    recipientsList = (r && r.items) || [];
}
const blocksForKind = (k) => blocksList.filter((b) => (b.herd_kind || '') === k);
const prodByBarcode = (bc) => productsIndex.find((p) => p.barcode === bc);

/* Памʼять «останній блок для товару в групі» — щоб блок підставлявся сам */
const BLKMEM_KEY = 'farm:vyd_lastblk:' + location.pathname;
let blkMem = {};
try { blkMem = JSON.parse(localStorage.getItem(BLKMEM_KEY) || '{}') || {}; } catch (e) { blkMem = {}; }
function rememberBlock(kind, barcode, blockId) {
    if (!blockId) return;
    blkMem[kind + '|' + barcode] = blockId;
    try { localStorage.setItem(BLKMEM_KEY, JSON.stringify(blkMem)); } catch (e) { /**/ }
}
function defaultBlock(kind, barcode) {
    const remembered = blkMem[kind + '|' + barcode];
    if (remembered && blocksForKind(kind).some((b) => String(b.id) === String(remembered))) {
        return remembered;
    }
    const list = blocksForKind(kind);
    return list.length ? list[0].id : '';
}

/* ---------- стан: накладні ---------- */
let invSeq = 0;
let invs = [];
let activeId = 0;
let mode = 'OUT';

function newInv(kind, recipientId) {
    invSeq += 1;
    return { id: invSeq, kind: kind || lastKind(), recipient_id: recipientId || lastRecipient(),
             reason: '', collapsed: false, items: [] };   // items: {barcode, qty, block_id}
}
const invOf = (id) => invs.find((x) => x.id === id);
function invSum(v) {
    return v.items.reduce((a, r) => {
        const p = prodByBarcode(r.barcode);
        return a + r.qty * (p ? (+p.avg_price_in_no_vat || 0) : 0);
    }, 0);
}
function lastKind() { try { return localStorage.getItem('farm:vyd_kind:' + location.pathname) || 'cow'; } catch (e) { return 'cow'; } }
function lastRecipient() { try { return localStorage.getItem('farm:vyd_who:' + location.pathname) || ''; } catch (e) { return ''; } }
function rememberCtx(kind, who) {
    try {
        if (kind) localStorage.setItem('farm:vyd_kind:' + location.pathname, kind);
        if (who) localStorage.setItem('farm:vyd_who:' + location.pathname, who);
    } catch (e) { /**/ }
}

/* Чернетки: накладні переживають закриття сторінки */
const DRAFT_KEY = 'farm:vyd_drafts:' + location.pathname;
function saveDraft() {
    try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify({ seq: invSeq, mode, invs }));
    } catch (e) { /**/ }
}
function loadDraft() {
    try {
        const d = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
        if (!d || !Array.isArray(d.invs)) return false;
        invSeq = d.seq || d.invs.length;
        mode = d.mode === 'WRITE_OFF' ? 'WRITE_OFF' : 'OUT';
        invs = d.invs.filter((v) => v && Array.isArray(v.items));
        return invs.length > 0;
    } catch (e) { return false; }
}

/* ---------- елементи ---------- */
const scan = document.getElementById('saleSearch');
const ac = document.getElementById('vydAc');
const issueDate = document.getElementById('issueDate');
function focusScan() { if (scan) scan.focus(); }
function todayISO() { return new Date().toISOString().slice(0, 10); }

/* ---------- маркер терміну партії, що спишеться FIFO ---------- */
function expTag(p) {
    const exp = (p && p.nearest_expiry || '').slice(0, 10);
    if (!exp) return '';
    const dd = exp.slice(8, 10) + '.' + exp.slice(5, 7);
    const today = todayISO();
    if (exp < today) return ` <span class="expb" title="Найстарша партія прострочена — FIFO спише саме її">терм. ${dd}</span>`;
    const lim = new Date(); lim.setDate(lim.getDate() + 30);
    if (exp <= lim.toISOString().slice(0, 10)) {
        return ` <span class="expw" title="Термін найстаршої партії закінчується — FIFO спише саме її">терм. ${dd}</span>`;
    }
    return '';
}

/* ---------- рендер накладних ---------- */
function render() {
    const box = document.getElementById('invs');
    if (!invs.length) {
        box.innerHTML = '<div class="inv"><div class="inv-empty">'
            + 'Натисніть «＋ Накладна» або скануйте товар — накладна створиться сама</div></div>';
        saveDraft();
        return;
    }
    const isOut = mode === 'OUT';
    box.innerHTML = invs.map((v) => {
        const sum = invSum(v), n = v.items.length, act = v.id === activeId;
        const rows = v.items.map((r, i) => {
            const p = prodByBarcode(r.barcode);
            if (!p) return '';
            const over = r.qty > (+p.total_qty || 0);
            const price = +p.avg_price_in_no_vat || 0;
            const blkOpts = blocksForKind(v.kind).map((b) =>
                `<option value="${b.id}"${String(b.id) === String(r.block_id) ? ' selected' : ''}>${escapeHtml(b.name)}</option>`).join('');
            return `<tr class="${over ? 'rowbad' : ''}">
                <td><b>${escapeHtml(p.name)}</b>${expTag(p)}${over
                    ? `<span class="badstock">лише ${nf.format(p.total_qty || 0)} ${escapeHtml(p.unit || '')} на складі</span>`
                    : `<span class="leftline">лишиться ${nf.format((p.total_qty || 0) - r.qty)} ${escapeHtml(p.unit || '')}</span>`}</td>
                <td>${isOut
                    ? `<select class="blocksel" data-inv="${v.id}" data-i="${i}">${blkOpts}</select>`
                    : '<span class="unit">—</span>'}</td>
                <td class="num qtycell"><input class="qty${over ? ' bad' : ''}" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${nf.format(r.qty)}">
                    <span class="unit">${escapeHtml(p.unit || '')}</span></td>
                <td class="num">${money.format(price)}</td>
                <td class="num"><b>${money.format(r.qty * price)}</b></td>
                <td><button class="rm" data-inv="${v.id}" data-i="${i}" title="Прибрати">✕</button></td>
            </tr>`;
        }).join('');
        const head = isOut
            ? `<select class="inv-sel inv-who" data-inv="${v.id}" data-f="who">${optionsHtml(recipientsList, v.recipient_id, '— кому —')}</select>
               <select class="inv-sel" data-inv="${v.id}" data-f="kind">${['cow', 'young', 'pig'].map((k) =>
                   `<option value="${k}"${k === v.kind ? ' selected' : ''}>${KIND_LABEL[k]}</option>`).join('')}</select>`
            : `<span class="inv-who">Списання</span>`;
        const reason = isOut ? '' :
            `<input type="text" class="inv-reason hist-q" data-inv="${v.id}" placeholder="Причина списання…"
                    value="${escapeHtml(v.reason || '')}" style="width:220px">`;
        return `<div class="inv${act ? ' is-active' : ''}${v.collapsed ? ' is-collapsed' : ''}" data-inv="${v.id}">
          <div class="inv-head" data-inv="${v.id}">
            <span class="inv-caret">▾</span>
            ${head}
            <span class="inv-no-sub">Накладна ${v.id}</span>
            <span class="inv-sum">${n} поз. · ${money.format(sum)} ₴ <span class="unit">без ПДВ</span></span>
            <button class="inv-del" data-inv="${v.id}" title="Видалити накладну"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/></svg></button>
          </div>
          <div class="inv-body">
            <table>
              <colgroup><col class="c-name"><col class="c-blk"><col class="c-qty">
                <col class="c-price"><col class="c-sum"><col class="c-rm"></colgroup>
              <thead><tr>
                <th>${window.ITEM_WORD || 'Товар'}</th><th>${isOut ? (window.BLOCK_WORD || 'Блок') + ' (куди)' : ''}</th>
                <th class="num" style="padding-right:55px">К-сть</th>
                <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th><th></th>
              </tr></thead>
              <tbody>${rows || '<tr><td colspan="6" class="inv-empty">Скануйте товар — він потрапить сюди</td></tr>'}</tbody>
            </table>
            <div class="inv-foot">
              <span class="t">${n} поз. · <b>${money.format(sum)} ₴</b> <span class="unit">без ПДВ</span></span>
              ${reason}
              <span class="spacer"></span>
              <button class="inv-go" data-inv="${v.id}" ${n ? '' : 'disabled'}>${isOut ? 'Провести видачу' : 'Провести списання'}</button>
            </div>
          </div>
        </div>`;
    }).join('');
    bindInvs();
    saveDraft();
}

function focusQty(inv, i) {
    const el = document.querySelector(`.qty[data-inv="${inv}"][data-i="${i}"]`);
    if (el) { el.focus(); el.select(); }
}

function softRefresh(q, v) {
    const r = v.items[+q.dataset.i];
    const p = prodByBarcode(r.barcode);
    if (!p) return;
    const over = r.qty > (+p.total_qty || 0);
    const price = +p.avg_price_in_no_vat || 0;
    q.classList.toggle('bad', over);
    q.closest('tr').classList.toggle('rowbad', over);
    const td = q.closest('tr').querySelector('td');
    let bs = td.querySelector('.badstock'), ll = td.querySelector('.leftline');
    if (over) {
        if (ll) ll.remove();
        if (!bs) { bs = document.createElement('span'); bs.className = 'badstock'; td.appendChild(bs); }
        bs.textContent = `лише ${nf.format(p.total_qty || 0)} ${p.unit || ''} на складі`;
    } else {
        if (bs) bs.remove();
        if (!ll) { ll = document.createElement('span'); ll.className = 'leftline'; td.appendChild(ll); }
        ll.textContent = `лишиться ${nf.format((p.total_qty || 0) - r.qty)} ${p.unit || ''}`;
    }
    q.closest('tr').querySelector('td:nth-child(5) b').textContent = money.format(r.qty * price);
    const card = q.closest('.inv');
    card.querySelector('.inv-sum').innerHTML =
        `${v.items.length} поз. · ${money.format(invSum(v))} ₴ <span class="unit">без ПДВ</span>`;
    card.querySelector('.inv-foot .t').innerHTML =
        `${v.items.length} поз. · <b>${money.format(invSum(v))} ₴</b> <span class="unit">без ПДВ</span>`;
    saveDraft();
}

function bindInvs() {
    const box = document.getElementById('invs');
    box.querySelectorAll('.inv-head').forEach((h) => h.addEventListener('click', (e) => {
        if (e.target.closest('select') || e.target.closest('.inv-del')) return;
        const id = +h.dataset.inv, v = invOf(id);
        if (activeId !== id) { activeId = id; v.collapsed = false; }
        else v.collapsed = !v.collapsed;
        render();
        if (!v.collapsed) focusScan();
    }));
    box.querySelectorAll('.inv-sel').forEach((sel) => sel.addEventListener('change', () => {
        const v = invOf(+sel.dataset.inv);
        if (sel.dataset.f === 'kind') {
            v.kind = sel.value;
            // блоки іншої групи — перепідставити за памʼяттю нової групи
            v.items.forEach((r) => { r.block_id = defaultBlock(v.kind, r.barcode); });
            rememberCtx(v.kind, null);
        } else {
            v.recipient_id = sel.value;
            rememberCtx(null, v.recipient_id);
        }
        activeId = v.id; render(); focusScan();
    }));
    box.querySelectorAll('.inv-reason').forEach((inp) => inp.addEventListener('input', () => {
        invOf(+inp.dataset.inv).reason = inp.value; saveDraft();
    }));
    box.querySelectorAll('.qty').forEach((q) => {
        const v = invOf(+q.dataset.inv);
        const row = () => v.items[+q.dataset.i];
        q.addEventListener('input', () => { row().qty = rawNum(q.value); softRefresh(q, v); });
        q.addEventListener('focus', () => {
            activeId = v.id;
            const x = row().qty;
            q.value = x ? String(x).replace('.', ',') : '';
            q.select();
        });
        q.addEventListener('blur', () => { q.value = nf.format(row().qty); });
        q.addEventListener('keydown', (e) => { if (e.key === 'Enter') { render(); focusScan(); } });
    });
    box.querySelectorAll('.blocksel').forEach((sel) => sel.addEventListener('change', () => {
        const v = invOf(+sel.dataset.inv), r = v.items[+sel.dataset.i];
        r.block_id = sel.value;
        rememberBlock(v.kind, r.barcode, sel.value);
        saveDraft(); focusScan();
    }));
    box.querySelectorAll('.rm').forEach((b) => b.onclick = () => {
        invOf(+b.dataset.inv).items.splice(+b.dataset.i, 1);
        render(); focusScan();
    });
    box.querySelectorAll('.inv-del').forEach((b) => b.onclick = async (e) => {
        e.stopPropagation();
        const v = invOf(+b.dataset.inv);
        const what = v.items.length
            ? `${v.items.length} поз. — позиції не проведуться` : 'порожня';
        if (!await confirmAction(`Видалити накладну ${v.id} (${what})?`)) return;
        invs = invs.filter((x) => x !== v);
        if (activeId === v.id && invs.length) activeId = invs[0].id;
        render(); focusScan();
    });
    box.querySelectorAll('.inv-go').forEach((b) => b.onclick = () => processInvoice(+b.dataset.inv));
}

/* ---------- додавання товару ---------- */
function addRow(p) {
    if (scan) scan.value = '';
    if (ac) ac.hidden = true;
    let v = invOf(activeId);
    if (!v) { v = newInv(); invs.push(v); activeId = v.id; }
    v.collapsed = false;
    const ex = v.items.findIndex((r) => r.barcode === p.barcode);
    if (ex >= 0) {
        render(); focusQty(v.id, ex);
        toast('Товар уже в цій накладній — виправте кількість');
        return;
    }
    v.items.push({ barcode: p.barcode, qty: 1, block_id: defaultBlock(v.kind, p.barcode) });
    render(); focusQty(v.id, v.items.length - 1);
}

/* ---------- проведення накладної ---------- */
async function processInvoice(id) {
    const v = invOf(id);
    if (!v || !v.items.length) return;
    if (mode === 'OUT') {
        const noBlock = v.items.findIndex((r) => !r.block_id);
        if (noBlock >= 0) {
            render();
            toast('Оберіть блок (куди) для кожної позиції', 'error');
            return;
        }
    }
    const btn = document.querySelector(`.inv-go[data-inv="${id}"]`);
    if (btn) btn.disabled = true;
    const payload = {
        move_type: mode,
        note: mode === 'WRITE_OFF' ? (v.reason || '') : '',
        date: issueDate ? (issueDate.value || '') : '',
        items: v.items.map((r) => ({
            barcode: r.barcode,
            qty: r.qty,
            block_id: mode === 'OUT' ? r.block_id : '',
            recipient_id: mode === 'OUT' ? v.recipient_id : '',
        })),
    };
    const r = await apiSend('/api/sale/bulk', 'POST', payload);
    if (!r || !r.ok) {
        if (btn) btn.disabled = false;
        toast((r && r.error) || 'Помилка проведення', 'error');
        return;
    }
    const lbl = opLabel[mode] ? opLabel[mode].text : 'Операція';
    toast(`${lbl} ${formatSaleNo(r.sale_no, mode)}: ${r.positions} поз.`, 'success');
    invs = invs.filter((x) => x !== v);
    if (activeId === id && invs.length) activeId = invs[0].id;
    render();
    histDirty = true;
    await loadProductsIndex();   // свіжі залишки в пошуку і рядках
    render();                    // перерахувати «лишиться» рештою накладних
    focusScan();
}

/* ---------- пошук / сканування ---------- */
let hot = 0, hits = [];
function renderAc() {
    if (!hits.length) { ac.hidden = true; return; }
    ac.innerHTML = hits.map((p, k) => {
        const stock = +p.total_qty || 0;
        return `<div class="ac-row${k === hot ? ' hot' : ''}" data-bc="${escapeHtml(p.barcode)}">
            <span class="ac-name">${escapeHtml(p.name)}</span>
            <span class="ac-stock${stock <= 0 ? ' low' : ''}">залишок ${nf.format(stock)} ${escapeHtml(p.unit || '')}</span>
            <span class="ac-price">${money.format(+p.avg_price_in_no_vat || 0)} ₴</span>
        </div>`;
    }).join('');
    ac.hidden = false;
    ac.querySelectorAll('.ac-row').forEach((r) => r.onclick = () => {
        const p = prodByBarcode(r.dataset.bc);
        if (p) addRow(p);
    });
}
if (scan) {
    scan.addEventListener('input', () => {
        const q = scan.value.trim();
        if (q.length < 2) { ac.hidden = true; hits = []; return; }
        hits = searchProducts(q);
        hot = 0; renderAc();
    });
    scan.addEventListener('keydown', (e) => {
        if (ac.hidden && e.key === 'Enter' && scan.value.trim()) {
            // «скан»: точний збіг штрихкоду або перший результат пошуку
            const q = scan.value.trim();
            const p = prodByBarcode(q) || (hits[0] || null);
            if (p) addRow(p);
            else toast(`Товар «${q}» не знайдено`, 'error');
            return;
        }
        if (ac.hidden) return;
        if (e.key === 'ArrowDown') { hot = Math.min(hot + 1, hits.length - 1); renderAc(); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { hot = Math.max(hot - 1, 0); renderAc(); e.preventDefault(); }
        else if (e.key === 'Enter') { addRow(hits[hot]); e.preventDefault(); }
        else if (e.key === 'Escape') { ac.hidden = true; }
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.scanbox')) ac.hidden = true;
    });
}

/* камера телефона: скан → товар у активну накладну (той самий ZXing) */
if (window.attachScanShortcut) {
    attachScanShortcut(scan, document.getElementById('cameraScanBtn'));
}
(function () {
    const camBtn = document.getElementById('cameraScanBtn');
    if (!camBtn || !window.openCameraScanner) return;
    camBtn.addEventListener('click', () => {
        const scanner = openCameraScanner(async (code) => {
            const p = prodByBarcode(code);
            if (p) addRow(p);
            if (scanner) scanner.setStatus(p
                ? '✓ Додано: ' + p.name
                : '✗ Не знайдено: ' + code);
            if (window.scanBeep) window.scanBeep(!!p);
            const a = document.activeElement;
            if (a && a.blur) a.blur();
        });
    });
})();

/* ---------- верхні керування ---------- */
document.getElementById('addInv').onclick = () => {
    const v = newInv(); invs.push(v); activeId = v.id; render(); focusScan();
};
document.getElementById('collapseAll').onclick = () => {
    const anyOpen = invs.some((v) => !v.collapsed);
    invs.forEach((v) => { v.collapsed = anyOpen; });
    document.getElementById('collapseAll').title =
        anyOpen ? 'Розгорнути всі накладні' : 'Згорнути всі накладні';
    render(); focusScan();
};
document.querySelectorAll('#modeSeg .seg-btn').forEach((b) => b.onclick = () => {
    document.querySelectorAll('#modeSeg .seg-btn').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
    mode = b.dataset.mode;
    render(); focusScan();
});

/* перемикач дат */
function shiftDay(k) {
    const d = issueDate.value ? new Date(issueDate.value + 'T00:00:00') : new Date();
    d.setDate(d.getDate() + k);
    issueDate.value = d.toISOString().slice(0, 10);
    focusScan();
}
issueDate.value = todayISO();
issueDate.max = todayISO();
document.getElementById('dPrev').onclick = () => shiftDay(-1);
document.getElementById('dNext').onclick = () => shiftDay(1);
document.getElementById('dToday').onclick = () => { issueDate.value = todayISO(); focusScan(); };
issueDate.onchange = focusScan;

/* ---------- розділи Видача / Історія ---------- */
let histDirty = true;
document.querySelectorAll('#viewSeg .cat-tab').forEach((b) => b.onclick = () => {
    document.querySelectorAll('#viewSeg .cat-tab').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
    const hist = b.dataset.view === 'hist';
    document.getElementById('viewIssue').hidden = hist;
    document.getElementById('viewHist').hidden = !hist;
    document.getElementById('modeSeg').style.display = hist ? 'none' : 'inline-flex';
    if (hist) loadHist(); else focusScan();
});

/* ---------- історія ---------- */
let histPer = 'today';
let histOps = [];
const MONTHS = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень',
                'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];
let histMonth = todayISO().slice(0, 7);
let mpYear = +histMonth.slice(0, 4);

function histBounds() {
    const iso = (d) => d.toISOString().slice(0, 10);
    const t = new Date();
    if (histPer === 'today') return [iso(t), iso(t)];
    if (histPer === 'week') { const f = new Date(t); f.setDate(f.getDate() - 6); return [iso(f), iso(t)]; }
    if (histPer === 'month') {
        const [y, m] = histMonth.split('-').map(Number);
        const last = new Date(y, m, 0).getDate();
        return [`${histMonth}-01`, `${histMonth}-${String(last).padStart(2, '0')}`];
    }
    return [document.getElementById('histFrom').value || '',
            document.getElementById('histTo').value || ''];
}

async function loadHist() {
    const [d1, d2] = histBounds();
    const box = document.getElementById('histRows');
    box.innerHTML = '<div class="inv"><div class="inv-empty">Завантаження…</div></div>';
    const r = await apiGet(`/api/sales/recent?from=${encodeURIComponent(d1)}&to=${encodeURIComponent(d2)}`);
    histOps = (r && r.items) || [];
    histDirty = false;
    renderHist(document.getElementById('histQ').value);
}

function renderHist(q) {
    const box = document.getElementById('histRows');
    const qq = (q || '').toLowerCase();
    const ops = histOps.filter((o) => !qq
        || String(o.sale_no).includes(qq)
        || formatSaleNo(o.sale_no, o.move_type).toLowerCase().includes(qq)
        || (o.recipient_name || '').toLowerCase().includes(qq)
        || (o.items || []).some((i) => (i.name || '').toLowerCase().includes(qq)));
    if (!ops.length) {
        box.innerHTML = '<div class="inv"><div class="inv-empty">За цей період операцій немає</div></div>';
        return;
    }
    box.innerHTML = ops.map((o) => {
        const lbl = opLabel[o.move_type] || { text: o.move_type, cls: '' };
        const kind = KIND_LABEL[o.herd_kind] || '';
        const who = o.recipient_name || '';
        const dt = (o.created_at || '').slice(8, 10) + '.' + (o.created_at || '').slice(5, 7)
            + ' ' + (o.created_at || '').slice(11, 16);
        const rows = (o.items || []).map((i) => `<tr>
            <td><b>${escapeHtml(i.name)}</b></td>
            <td class="unit">${escapeHtml(i.block_name || '')}</td>
            <td class="num qtycell">${nf.format(i.qty)}</td>
            <td class="num"><b>${money.format(+i.total_no_vat || 0)}</b></td>
        </tr>`).join('');
        const acts = o.can_edit
            ? `<button class="h-ed h-rep" data-no="${o.sale_no}" title="Повторити — нова накладна з цими позиціями">↻</button>
               <button class="h-ed h-edit" data-no="${o.sale_no}" title="Редагувати операцію">✎</button>
               <button class="h-ed h-void" data-no="${o.sale_no}" title="Скасувати — повернути на склад">⊘</button>`
            : `<button class="h-ed h-rep" data-no="${o.sale_no}" title="Повторити — нова накладна з цими позиціями">↻</button>`;
        const sumNv = (o.items || []).reduce((a, i) => a + (+i.total_no_vat || 0), 0);
        return `<div class="inv h-op is-collapsed">
          <div class="inv-head">
            <span class="inv-caret">▾</span>
            <span class="inv-no"><b>${formatSaleNo(o.sale_no, o.move_type)}</b></span>
            <span class="tag ${lbl.cls}">${lbl.text}</span>
            ${who ? `<span class="h-who">${escapeHtml(who)}</span>` : ''}
            ${kind ? `<span class="h-meta">${kind}</span>` : ''}
            <span class="h-meta">${dt}</span>
            <span class="inv-sum">${(o.items || []).length} поз. · ${money.format(sumNv)} ₴ <span class="unit">без ПДВ</span></span>
            ${acts}
          </div>
          <div class="inv-body">
            <table>
              <colgroup><col class="c-name"><col class="c-blk"><col class="c-qty"><col class="c-hsum"></colgroup>
              <tbody>${rows}</tbody>
            </table>
          </div>
        </div>`;
    }).join('');
    box.querySelectorAll('.h-op .inv-head').forEach((h) => h.onclick = (e) => {
        if (e.target.closest('.h-ed')) return;
        h.closest('.h-op').classList.toggle('is-collapsed');
    });
    box.querySelectorAll('.h-edit').forEach((b) => b.onclick = (e) => {
        e.stopPropagation(); openEditSale(b.dataset.no);
    });
    box.querySelectorAll('.h-void').forEach((b) => b.onclick = async (e) => {
        e.stopPropagation();
        const no = b.dataset.no;
        if (!await confirmAction(`Відмінити операцію ${formatSaleNo(no)}? Товар повернеться на склад.`)) return;
        const r = await apiSend('/api/sales/' + encodeURIComponent(no), 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast(`Операцію ${formatSaleNo(no)} відмінено`, 'success');
        loadHist(); loadProductsIndex();
    });
    box.querySelectorAll('.h-rep').forEach((b) => b.onclick = (e) => {
        e.stopPropagation();
        const o = histOps.find((x) => String(x.sale_no) === String(b.dataset.no));
        if (!o) return;
        const v = newInv(o.herd_kind || lastKind(),
            (recipientsList.find((x) => x.name === o.recipient_name) || {}).id || lastRecipient());
        for (const i of (o.items || [])) {
            const p = prodByBarcode(i.barcode);
            if (!p) continue;
            const blk = blocksList.find((x) => x.name === i.block_name
                && (x.herd_kind || '') === (o.herd_kind || ''));
            v.items.push({ barcode: i.barcode, qty: +i.qty || 1,
                           block_id: blk ? blk.id : defaultBlock(v.kind, i.barcode) });
        }
        invs.push(v); activeId = v.id;
        document.querySelector('#viewSeg [data-view="issue"]').click();
        render();
        toast(`Створено накладну ${v.id} за зразком ${formatSaleNo(o.sale_no, o.move_type)} — перевірте й проведіть`);
    });
}

document.getElementById('histQ').addEventListener('input', (e) => renderHist(e.target.value));
document.querySelectorAll('#histPer .seg-btn').forEach((b) => b.onclick = () => {
    document.querySelectorAll('#histPer .seg-btn').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active'); histPer = b.dataset.per;
    document.getElementById('histRange').hidden = histPer !== 'range';
    document.getElementById('histMonthBox').hidden = histPer !== 'month';
    loadHist();
});
['histFrom', 'histTo'].forEach((id) => document.getElementById(id)
    .addEventListener('change', loadHist));
document.getElementById('histCollapseAll').onclick = () => {
    const cards = [...document.querySelectorAll('.h-op')];
    const anyOpen = cards.some((c) => !c.classList.contains('is-collapsed'));
    cards.forEach((c) => c.classList.toggle('is-collapsed', anyOpen));
    document.getElementById('histCollapseAll').title =
        anyOpen ? 'Розгорнути всі накладні' : 'Згорнути всі накладні';
};

/* пікер місяця */
const mpPop = document.getElementById('mpPop');
function mpLabel() {
    const [y, m] = histMonth.split('-').map(Number);
    document.getElementById('histMonthBtn').innerHTML =
        `${MONTHS[m - 1]} ${y} <span class="unit">▾</span>`;
}
function mpRender() {
    document.getElementById('mpYear').textContent = mpYear;
    const [sy, sm] = histMonth.split('-').map(Number);
    const nowM = todayISO().slice(0, 7);
    document.getElementById('mpGrid').innerHTML = MONTHS.map((n, i) => {
        const sel = (mpYear === sy && i + 1 === sm);
        const now = (`${mpYear}-${String(i + 1).padStart(2, '0')}` === nowM);
        return `<button type="button" class="mp-m${sel ? ' sel' : ''}${now ? ' now' : ''}" data-m="${i + 1}">${n.slice(0, 3)}</button>`;
    }).join('');
    mpPop.querySelectorAll('.mp-m').forEach((b) => b.onclick = () => {
        histMonth = `${mpYear}-${String(+b.dataset.m).padStart(2, '0')}`;
        mpLabel(); mpPop.hidden = true;
        loadHist();
    });
}
document.getElementById('histMonthBtn').onclick = (e) => {
    e.stopPropagation();
    mpYear = +histMonth.slice(0, 4);
    mpPop.hidden = !mpPop.hidden;
    if (!mpPop.hidden) mpRender();
};
document.getElementById('mpPrev').onclick = () => { mpYear--; mpRender(); };
document.getElementById('mpNext').onclick = () => { mpYear++; mpRender(); };
document.addEventListener('click', (e) => {
    if (!e.target.closest('#histMonthBox')) mpPop.hidden = true;
});
mpLabel();

/* ---------- редагування операції (перенесено зі старої видачі) ---------- */
const editSaleNoEl = document.getElementById('editSaleNo');
const editSaleInfo = document.getElementById('editSaleInfo');
const editSaleBody = document.querySelector('#editSaleTable tbody');
const editSaleNoteInp = document.getElementById('editSaleNoteInp');
const editSaleDateInp = document.getElementById('editSaleDateInp');
const editSaleDateLabel = document.getElementById('editSaleDateLabel');
const editSaleGroup = document.getElementById('editSaleGroup');
let editSaleCurrent = null;

function editBlocksForGroup() {
    const k = editSaleGroup ? editSaleGroup.value : '';
    if (!k) return blocksList;
    return blocksList.filter((b) => (b.herd_kind || '') === k);
}
function renderEditSaleRows(strict) {
    if (!editSaleCurrent || !editSaleBody) return;
    const base = editBlocksForGroup();
    editSaleBody.innerHTML = editSaleCurrent.positions.map((p, i) => {
        let rowBlocks = base;
        if (!strict && p.block_id && !base.some((b) => String(b.id) === String(p.block_id))) {
            rowBlocks = base.concat(blocksList.filter((b) => String(b.id) === String(p.block_id)));
        }
        return `
            <tr data-i="${i}">
                <td>${escapeHtml(p.name)}<div class="text-mute" style="font-size:11px;">${escapeHtml(p.barcode || '')}</div></td>
                <td class="num"><input type="number" class="es-qty" value="${p.qty}" min="0" step="any" style="width:80px;text-align:right;"></td>
                <td class="es-dest"><select class="es-block ref-select">${optionsHtml(rowBlocks, p.block_id, '— блок —')}</select></td>
                <td class="es-dest"><select class="es-recipient ref-select">${optionsHtml(recipientsList, p.recipient_id, '— не вказано —')}</select></td>
            </tr>`;
    }).join('');
}
function snapshotEditRows() {
    if (!editSaleCurrent || !editSaleBody) return;
    editSaleBody.querySelectorAll('tr[data-i]').forEach((tr) => {
        const i = parseInt(tr.dataset.i, 10);
        const p = editSaleCurrent.positions[i];
        if (!p) return;
        const bs = tr.querySelector('.es-block'), rs = tr.querySelector('.es-recipient');
        if (bs) p.block_id = bs.value;
        if (rs) p.recipient_id = rs.value;
    });
}
if (editSaleGroup) {
    editSaleGroup.addEventListener('change', () => {
        snapshotEditRows();
        renderEditSaleRows(true);
    });
}
async function openEditSale(saleNo) {
    const r = await apiGet('/api/sales/' + encodeURIComponent(saleNo) + '/edit');
    if (!r.ok) { toast(r.error || 'Не вдалося завантажити операцію', 'error'); return; }
    const sale = r.sale;
    editSaleCurrent = sale;
    editSaleNoEl.textContent = formatSaleNo(sale.sale_no, sale.move_type);
    const isOut = sale.move_type === 'OUT';
    editSaleInfo.textContent = isOut
        ? 'Видача: можна змінити кількість, дату, блок, отримувача та примітку. Зміна кількості коригує залишок складу.'
        : 'Списання: можна змінити кількість, дату та примітку. Зміна кількості коригує залишок складу.';
    if (editSaleDateLabel) editSaleDateLabel.textContent = isOut ? 'Дата видачі' : 'Дата списання';
    if (editSaleDateInp) {
        editSaleDateInp.value = (sale.created_at || '').slice(0, 10);
        editSaleDateInp.max = todayISO();
    }
    document.querySelectorAll('#editSaleTable .es-dest')
        .forEach((el) => { el.style.display = isOut ? '' : 'none'; });
    if (document.getElementById('editSaleGroupField')) {
        document.getElementById('editSaleGroupField').style.display = isOut ? '' : 'none';
    }
    if (editSaleGroup && isOut) {
        const kinds = sale.positions.map((p) => {
            const b = blocksList.find((x) => String(x.id) === String(p.block_id));
            return b ? (b.herd_kind || '') : '';
        }).filter(Boolean);
        editSaleGroup.value = kinds[0] || 'cow';
    }
    editSaleNoteInp.value = sale.note || '';
    renderEditSaleRows(false);
    openModal('editSaleModal');
}
document.getElementById('saveEditSaleBtn').addEventListener('click', async () => {
    if (!editSaleCurrent) return;
    const positions = [];
    editSaleBody.querySelectorAll('tr[data-i]').forEach((tr) => {
        const i = parseInt(tr.dataset.i, 10);
        const p = editSaleCurrent.positions[i];
        const blockSel = tr.querySelector('.es-block');
        const recSel = tr.querySelector('.es-recipient');
        const qtyInp = tr.querySelector('.es-qty');
        positions.push({
            product_id: p.product_id,
            block_id: blockSel ? blockSel.value : '',
            recipient_id: recSel ? recSel.value : '',
            qty: qtyInp ? qtyInp.value : undefined,
        });
    });
    const r = await apiSend('/api/sales/' + encodeURIComponent(editSaleCurrent.sale_no) + '/edit',
        'POST', { positions, note: editSaleNoteInp.value,
                  date: editSaleDateInp ? editSaleDateInp.value : '' });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Зміни збережено', 'success');
    closeModal('editSaleModal');
    editSaleCurrent = null;
    loadHist();
    loadProductsIndex();
});

/* ---------- старт ---------- */
(async function init() {
    await Promise.all([loadProductsIndex(), loadBlocks(), loadRecipients()]);
    if (!loadDraft()) {
        invs = [newInv()];
    }
    // режим із чернетки — підсвітити правильну кнопку
    document.querySelectorAll('#modeSeg .seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x.dataset.mode === mode));
    activeId = invs.length ? invs[0].id : 0;
    render();
    focusScan();
})();
