/* Поля події — ОДИН помічник на весь застосунок.

   Форма питань події малюється у трьох місцях: «Нова подія», «Груповий ввід»
   і правка події в картці тварини. Доти кожне місце мало свою копію, і вони
   розійшлись: у картці не було ні меж («від / до»), ні звʼязаних грошей, ні
   умовних полів, ні полів-довідок — тож правка поводилась НЕ ТАК, як внесення.
   📌 ПРАВИЛО (те саме, що з `qRows` у списках 2.39.82): де малюється ТЕ САМЕ,
   має малювати ОДИН помічник.

   herdFields.init({ params })                     — один раз на сторінку
   herdFields.render(box, def, { values, showVals, eventId })
   herdFields.collect(box, { keepEmpty })          — {ключ: значення}
   herdFields.missingRequired(box, { onlyFilled })
   herdFields.outOfBounds(box, extraSel)
   herdFields.bind(box)                            — живі гроші, умови, довідки
   herdFields.applyConds(box) / recalcMoney(box, role) / recalcShow(box)

   ⚠️ Розмітку НЕ міняти: `label.hp-fl[data-field]` + `.hp-in.lg-in[data-key]`.
   За неї тримаються збережені ширини полів (herd_log_layout.js) і стилі. */
'use strict';

(function () {

const PARAMS = {};      // ключ → означення параметра
const CHOICES = {};     // ключ → список значень
const UNITS = {};       // ключ → одиниця
const BOUNDS = {};      // ключ → {min, max, step}
const FXNAME = {};      // назва у формулі → ключ параметра
const esc = (s) => (window.escapeHtml ? window.escapeHtml(s)
    : String(s === null || s === undefined ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

function init(o) {
    const list = (o && o.params) || [];
    list.forEach((p) => {
        PARAMS[p.key] = p;
        [p.short, p.label, p.key].forEach((n) => {
            const k = String(n || '').trim().toLowerCase();
            if (k && !FXNAME[k]) FXNAME[k] = p.key;
        });
        CHOICES[p.key] = p.choices || [];
        if (p.unit) UNITS[p.key] = p.unit;
        if (p.vmin !== undefined || p.vmax !== undefined || p.vstep !== undefined)
            BOUNDS[p.key] = { min: p.vmin || '', max: p.vmax || '', step: p.vstep || '' };
    });
}

/* поля, які справді питаються: вимкнені в конструкторі не малюємо */
const effsOf = (def) => ((def && def.effects) || [])
    .filter((e) => (e.mode === 'input' || e.mode === 'show') && (!('enabled' in e) || e.enabled));

/* ── значення довідника: ПАМʼЯТАЄМО, ЯК ВОНО БУЛО ЗАПИСАНЕ ──
   На буртах той самий бик в одних подіях лежить кодом (US3252198586), в
   інших назвою («Меджікмола Ет») — так склалось історично. Правка не сміє
   це міняти: інакше виправлення техніка мовчки переписало б ще й бика, і
   списки за биком розійшлись би надвоє. Тому позицію шукаємо і за кодом, і
   за назвою, а віддаємо ТЕ САМЕ представлення, що прийшло.
   📌 Та сама думка, що `vsrc` у рядку формули: причісування не міняє набране. */
function optionFor(key, saved) {
    const ch = CHOICES[key] || [];
    const s = String(saved === null || saved === undefined ? '' : saved).trim();
    if (!s) return { value: '', as: '' };
    const byVal = ch.find((c) => String(c.value) === s);
    if (byVal) return { value: byVal.value, as: 'code' };
    const byLbl = ch.find((c) => String(c.label).trim() === s
        || String(c.label).split(' — ').pop().trim() === s);
    if (byLbl) return { value: byLbl.value, as: 'label', label: s };
    return { value: s, as: 'gone' };          // позицію прибрали з довідника
}

function showControl(eff, showVals) {
    const v = (showVals || {})[eff.param_key];
    return `<input type="text" class="hp-in lg-show" readonly tabindex="-1"`
        + ` data-key="${esc(eff.param_key)}"`
        + ` value="${esc(v === undefined || v === null ? '' : String(v))}"`
        + ` placeholder="—">`;
}

function inputControl(eff, evId, saved, useDef) {
    const ev = evId ? ` data-event-id="${esc(evId)}"` : '';
    const ch = CHOICES[eff.param_key] || [];
    const has = saved !== undefined && saved !== null && String(saved).trim() !== '';
    // ⚠️ Значення «за замовчуванням» — лише для ВНЕСЕННЯ. У правці воно
    // дописало б у стару подію поле, якого там не було: людина відкрила
    // виправити дату, а в записі мовчки зʼявилось нове значення.
    const val = has ? String(saved) : (useDef ? String(eff.arg || '') : '');
    if (ch.length) {
        const isCod = eff.param_dtype === 'cod' || eff.param_dtype === 'code';
        const isNum = ['int', 'float', 'number'].includes(eff.param_dtype);
        const isRef = eff.param_dtype === 'ref';
        const pick = optionFor(eff.param_key, val);
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) => {
            const lbl = (isRef && !c.label.includes(' — ')) ? `${i + 1} — ${c.label}`
                : ((isCod || isNum || isRef) ? c.label : `${i + 1}. ${c.label}`);
            const on = String(c.value) === String(pick.value);
            // як саме віддавати назад: кодом чи назвою — так, як було записано
            return `<option value="${esc(c.value)}" data-as="${on ? esc(pick.as) : 'code'}"`
                + `${on ? ' data-was="' + esc(pick.label || '') + '" selected' : ''}>${esc(lbl)}</option>`;
        }).join('');
        // позиції вже немає в довіднику — показуємо її окремим пунктом, щоб
        // правка сусіднього поля не стерла збережене значення мовчки
        const gone = pick.as === 'gone'
            ? `<option value="${esc(pick.value)}" data-as="gone" selected>${esc(pick.value)} — немає в довіднику</option>`
            : '';
        return `<select class="hp-in lg-in" data-key="${esc(eff.param_key)}" data-listtype="${isCod ? 'cod' : 'text'}"`
            + ` data-req="${eff.required ? 1 : 0}" data-label="${esc(eff.param_label || '')}"${ev}>${opts}${gone}</select>`;
    }
    const dt = eff.param_dtype;
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float') ? 'number' : 'text');
    const b = BOUNDS[eff.param_key] || {};
    let step = dt === 'float' ? ' step="0.01"' : '';
    if (type === 'number') {
        if (b.step) step = ` step="${esc(b.step)}"`;
        if (b.min) step += ` min="${esc(b.min)}"`;
        if (b.max) step += ` max="${esc(b.max)}"`;
    }
    return `<input type="${type}"${step} class="hp-in lg-in" data-key="${esc(eff.param_key)}"`
        + ` data-req="${eff.required ? 1 : 0}" data-label="${esc(eff.param_label || '')}"${ev}`
        + (dt === 'multi' ? window.multiAttrs(dt, b.min, b.max)
            : ((dt === 'text' && b.max) ? ` maxlength="${esc(b.max)}" placeholder="до ${esc(b.max)} символів"`
                : ' placeholder="значення"'))
        + ` value="${esc(val)}">`;
}

const widthClass = (eff) => {
    if ((CHOICES[eff.param_key] || []).length) return ' w-md';
    const dt = eff.param_dtype;
    if (dt === 'date') return ' w-sm';
    if (dt === 'int' || dt === 'float' || dt === 'number') return ' w-xs';
    return ' w-lg';
};
const colorOf = (eff) => {
    const c = String((PARAMS[eff.param_key] || {}).color || '').trim();
    if (!c) return { cls: '', style: '' };
    if (/^#[0-9a-f]{6}$/i.test(c)) return { cls: ' fc-own', style: ` style="--fc:${c}"` };
    return { cls: ' fc-' + c, style: '' };
};

/* малюємо поля події в `box`. values — збережені відповіді (правка). */
function render(box, def, o) {
    if (!box) return 0;
    const opt = o || {};
    const vals = opt.values || {};
    const effs = effsOf(def);
    box.innerHTML = effs.map((eff) => {
        const col = colorOf(eff);
        return `<label class="hp-fl${widthClass(eff)}${col.cls}" data-field="${esc(eff.param_key)}"${col.style}><span>`
            + `${esc(eff.param_label)}`
            + `${UNITS[eff.param_key] ? ', ' + esc(UNITS[eff.param_key]) : ''}`
            + `${eff.required ? '<span class="hp-req"> *</span>' : ''}`
            + `</span>${eff.mode === 'show' ? showControl(eff, opt.showVals)
                : inputControl(eff, opt.eventId || (def && def.id), vals[eff.param_key],
                    opt.useDefaults !== false)}</label>`;
    }).join('');
    box.dataset.defId = String((def && def.id) || '');
    DEFS.set(box, def);
    applyConds(box);
    recalcMoney(box, '');
    recalcShow(box, opt.showVals);
    return effs.length;
}

const DEFS = new WeakMap();       // box → означення події (для умов і грошей)
const SHOW = new WeakMap();       // box → значення параметрів тварини

/* ── звʼязані гроші: ввели будь-яке поле — решта порахувалась ── */
const MONEY_ROLES = ['qty', 'price_nv', 'sum_nv', 'vat', 'price_v', 'sum_v'];
const r4 = (x) => Math.round(x * 10000) / 10000;
const r2 = (x) => Math.round(x * 100) / 100;
function moneyFields(box) {
    const out = {};
    effsOf(DEFS.get(box)).forEach((e) => {
        const p = PARAMS[e.param_key];
        const role = p && (p.money_role || '').trim();
        if (!role || !MONEY_ROLES.includes(role)) return;
        const el = box.querySelector(`[data-key="${CSS.escape(e.param_key)}"]`);
        if (el) out[role] = el;
    });
    return out;
}
const mVal = (el) => {
    if (!el) return null;
    const v = parseFloat(String(el.value || '').trim().replace(',', '.'));
    return isFinite(v) ? v : null;
};
const mPut = (el, v, dec) => {
    if (!el || el === document.activeElement) return;
    el.value = (v === null || !isFinite(v)) ? '' : String(Number(v.toFixed(dec)));
};
function recalcMoney(box, changedRole) {
    if (!box) return;
    const f = moneyFields(box);
    if (!f.price_nv && !f.price_v && !f.sum_nv && !f.sum_v) return;
    const qty = mVal(f.qty);
    const vat = mVal(f.vat);
    const k = 1 + (vat === null ? 0 : vat) / 100;
    let pnv = mVal(f.price_nv), pv = mVal(f.price_v);
    if (changedRole === 'sum_nv') {
        const s = mVal(f.sum_nv);
        pnv = (s !== null && qty) ? r4(s / qty) : pnv;
    } else if (changedRole === 'sum_v') {
        const s = mVal(f.sum_v);
        pv = (s !== null && qty) ? r4(s / qty) : pv;
        pnv = (pv !== null && k) ? r4(pv / k) : pnv;
    } else if (changedRole === 'price_v') {
        pnv = (pv !== null && k) ? r4(pv / k) : pnv;
    }
    if (pnv !== null) pv = r4(pnv * k);
    else if (pv !== null) pnv = r4(pv / k);
    mPut(f.price_nv, pnv, 4);
    mPut(f.price_v, pv, 4);
    mPut(f.sum_nv, (qty !== null && pnv !== null) ? r2(qty * pnv) : null, 2);
    mPut(f.sum_v, (qty !== null && pv !== null) ? r2(qty * pv) : null, 2);
}
function moneyRoleOf(key) {
    const p = PARAMS[key];
    const r = p && (p.money_role || '').trim();
    return MONEY_ROLES.includes(r) ? r : '';
}

/* ── поля-довідки: формула рахується з того, що вже у формі ── */
function recalcShow(box, showVals) {
    if (!box) return;
    if (showVals) SHOW.set(box, showVals);
    const sv = SHOW.get(box) || {};
    const resolve = (name) => {
        const key = FXNAME[String(name || '').trim().toLowerCase()] || name;
        const el = box.querySelector(`.lg-in[data-key="${CSS.escape(key)}"]`);
        if (el) return el.value;
        const v = sv[key];
        return (v === undefined || v === null) ? '' : v;
    };
    box.querySelectorAll('.lg-show').forEach((el) => {
        const p = PARAMS[el.dataset.key];
        const fml = p && (p.formula || '').trim();
        if (!fml) return;
        const r = window.herdFxCalc ? window.herdFxCalc(fml, resolve) : { ok: false };
        if (r.ok) el.value = (r.value === null || r.value === undefined) ? '' : String(r.value);
        else if (!r.server) el.value = '';
    });
}

/* ── поле з умовою: покупець питається лише для продажу ── */
function condOf(eff) {
    try {
        const c = JSON.parse(eff.cond || '{}');
        return (c && c.if) ? { if: c.if, op: c.op || 'eq', eq: c.eq == null ? '' : String(c.eq) } : null;
    } catch (e) { return null; }
}
function condHolds(box, c) {
    const el = box.querySelector(`.lg-in[data-key="${CSS.escape(c.if)}"]`);
    const raw = el ? String(el.value || '').trim() : '';
    if (!raw) return false;
    if (c.op === 'eq') return raw.toLowerCase() === c.eq.toLowerCase();
    if (c.op === 'ne') return raw.toLowerCase() !== c.eq.toLowerCase();
    const x = parseFloat(raw.replace(',', '.')), y = parseFloat(String(c.eq).replace(',', '.'));
    if (!isFinite(x) || !isFinite(y)) return false;
    return { gt: x > y, ge: x >= y, lt: x < y, le: x <= y }[c.op] || false;
}
function applyConds(box) {
    if (!box) return;
    effsOf(DEFS.get(box)).forEach((eff) => {
        const c = condOf(eff);
        if (!c) return;
        const lab = box.querySelector(`.hp-fl[data-field="${CSS.escape(eff.param_key)}"]`);
        if (!lab) return;
        const on = condHolds(box, c);
        lab.hidden = !on;
        const el = lab.querySelector('.lg-in, .lg-show');
        if (el) el.dataset.req = (on && eff.required) ? '1' : '0';
    });
}

/* ── читання назад ──
   keepEmpty — віддати й порожні (груповий ввід питає їх покроково).
   ⚠️ Для довідника віддаємо ТЕ САМЕ представлення, що було збережено. */
function collect(box, o) {
    const keep = !!(o && o.keepEmpty);
    const out = {};
    if (!box) return out;
    box.querySelectorAll('.lg-in').forEach((el) => {
        const lab = el.closest('.hp-fl');
        if (lab && lab.hidden) return;          // сховане умовою — не пишемо
        let v = String(el.value || '').trim();
        if (el.tagName === 'SELECT') {
            const op = el.selectedOptions[0];
            if (op && op.dataset.as === 'label' && op.dataset.was) v = op.dataset.was;
        }
        if (v === '' && !keep) return;
        out[el.dataset.key] = v;
    });
    return out;
}

/* те саме, але розкладене по подіях (груповий ввід шле кілька означень) */
function collectByEvent(box, fallbackId) {
    const map = {};
    if (!box) return map;
    box.querySelectorAll('.lg-in').forEach((el) => {
        const lab = el.closest('.hp-fl');
        if (lab && lab.hidden) return;
        const v = String(el.value || '').trim();
        if (v === '') return;
        const eid = el.dataset.eventId || String(fallbackId || '');
        (map[eid] = map[eid] || {})[el.dataset.key] = v;
    });
    return map;
}

/* обовʼязкові порожні.
   onlyFilled — правка ДАВНЬОЇ події: якщо поле й доти було порожнє, не
   змушуємо його заповнювати (інакше виправити дату в події 2019 року стало б
   неможливо), але щойно людина щось у нього ввела — вимога діє. */
function missingRequired(box, o) {
    const out = [];
    if (!box) return out;
    const was = (o && o.was) || null;
    box.querySelectorAll('.lg-in').forEach((el) => {
        if (el.dataset.req !== '1') return;
        if (String(el.value || '').trim()) return;
        if (was && !String(was[el.dataset.key] || '').trim()) return;   // було порожнє — лишаємо
        out.push({ el, label: el.dataset.label || el.dataset.key });
    });
    return out;
}

function outOfBounds(box, extraSel) {
    const out = [];
    if (!box) return out;
    const list = [...box.querySelectorAll('.lg-in')];
    if (extraSel) document.querySelectorAll(extraSel).forEach((el) => list.push(el));
    list.forEach((el) => {
        const b = BOUNDS[el.dataset.key];
        const raw = String(el.value || '').trim();
        if (!b || !raw) return;
        const v = parseFloat(raw.replace(',', '.'));
        if (!isFinite(v)) return;
        const lo = b.min === '' ? null : parseFloat(b.min);
        const hi = b.max === '' ? null : parseFloat(b.max);
        const name = el.dataset.label || el.dataset.key;
        if (lo !== null && v < lo) out.push({ el, msg: `${name}: не менше ${b.min}` });
        else if (hi !== null && v > hi) out.push({ el, msg: `${name}: не більше ${b.max}` });
    });
    return out;
}

/* живі перерахунки в межах свого блоку (слухачі — на самому блоці, тож
   кілька форм на сторінці не заважають одна одній) */
function bind(box) {
    if (!box || box.dataset.fieldsBound) return;
    box.dataset.fieldsBound = '1';
    box.addEventListener('change', () => { applyConds(box); recalcShow(box); });
    box.addEventListener('input', (ev) => {
        const t = ev.target;
        if (!t || !t.dataset) return;
        const role = moneyRoleOf(t.dataset.key);
        if (role) recalcMoney(box, role);
        recalcShow(box);
    });
}

window.herdFields = { init, render, collect, collectByEvent, missingRequired,
    outOfBounds, applyConds, recalcMoney, recalcShow, bind, moneyRoleOf,
    effsOf, params: PARAMS, choices: CHOICES, bounds: BOUNDS, units: UNITS };
}());
