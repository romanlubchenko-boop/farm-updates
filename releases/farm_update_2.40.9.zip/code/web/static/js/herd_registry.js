/* Вкладка «Реєстр» Конструктора: нумерація приплоду + ІМПОРТ ДАНИХ ФАЙЛОМ.

   Роман 2026-09-25: «я спочатку набиваю параметри, вигружаю файл CSV, кладу
   туди дані, а потім імпортую… і це може бути з будь-якими параметрами —
   хоч переважка, хоч оцінка вгодованості».

   📌 ІМПОРТ ІДЕ ЧЕРЕЗ ПОДІЮ, А НЕ ПРОСТО «ЗАПИСУЄ ЗНАЧЕННЯ»: у програмі
   значення має дату лише тоді, коли його записала подія — з подій будується
   вся історія параметра. Тож файл зважування з колонкою «Дата» — це те саме,
   що внести «Зважування» кожній тварині своїм числом.
   📌 Перед записом ЗАВЖДИ показуємо розбір: скільки рядків готові, кого немає
   в реєстрі, де що не так. Масовий запис наосліп відкотити можна лише по
   одній тварині. */
'use strict';

/* ---------- Нумерація приплоду ----------
   Переїхало з «Огляду» в Конструктор (Роман 2026-09-25).
   Роман 2026-09-16: «номер він іде похідний, а довгий номер UA він є
   основний» + «1-й варіант + перемикач на останній найбільший». Тож
   рахуємо довгий номер, а бирка — його хвіст; правило обирається тут. */
(function () {
    const box = document.getElementById('animNumBox');
    if (!box) return;
    const $ = (id) => document.getElementById(id);
    let CFG = {};

    const q = (id) => $(id);
    const setMode = (m) => {
        CFG.mode = (m === 'max') ? 'max' : 'counter';
        $('animNumMode').querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.m === CFG.mode));
        // у режимі «найбільший» лічильник не потрібен — програма дивиться в базу
        $('animNumNextWrap').style.opacity = CFG.mode === 'max' ? '.45' : '';
        $('animNumNext').disabled = CFG.mode === 'max';
        $('animNumHint').textContent = CFG.mode === 'max'
            ? 'Бере найбільший номер із цим префіксом і додає одиницю. Чужі серії не враховуються, але випадково великий номер зсуне нумерацію.'
            : 'Свій лічильник: не збивається ні імпортом архіву, ні купленою твариною з чужим номером. Після кожного отелу зсувається сам.';
        $('animNumHint').textContent += ' Бирка — не коротша за 5 знаків: чотиризначні номери лишаються вільними для нашийників дійних корів.';
        preview();
    };

    async function preview() {
        try {
            const r = await apiGet('/api/herd/next-uin');
            $('animNumPrev').innerHTML = (r && r.ok && r.uin)
                ? `${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))}: <b>${escapeHtml(r.uin)}</b> · ${escapeHtml(herdLabel('tag', 'Номер тварини'))}: <b>${escapeHtml(r.tag || '')}</b>`
                : 'номер поки нема від чого рахувати';
        } catch (e) { $('animNumPrev').textContent = ''; }
    }

    async function load() {
        const r = await apiGet('/api/herd/calf-numbering');
        CFG = (r && r.ok && r.cfg) || {};
        $('animNumPrefix').value = CFG.prefix || '';
        $('animNumNext').value = CFG.next || '';
        $('animNumTagLen').value = CFG.tag_len || '';
        setMode(CFG.mode);
    }

    load();                       // у Конструкторі блок відкритий одразу
    $('animNumMode').addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (b) setMode(b.dataset.m);
    });
    $('animNumSave').addEventListener('click', async () => {
        const r = await apiSend('/api/herd/calf-numbering', 'POST', {
            mode: CFG.mode,
            prefix: $('animNumPrefix').value.trim(),
            next: $('animNumNext').value.trim(),
            tag_len: $('animNumTagLen').value.trim(),
        });
        if (!r.ok) {
            toast(r.error || 'Помилка', 'error');
            $('animNumTagLen').focus(); $('animNumTagLen').select();
            return;
        }
        CFG = r.cfg || CFG;
        toast('Збережено', 'success');
        preview();
    });
})();


/* ---------- Імпорт даних файлом ---------- */
(function () {
    const $ = (id) => document.getElementById(id);
    const sel = $('imEvent');
    if (!sel) return;
    let EVENTS = [], FILE = null;

    const esc = (t) => String(t == null ? '' : t)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    /* поля, які подія питає в людини — саме вони стануть колонками файла */
    const asks = (e) => (e.effects || []).filter((x) =>
        x.mode === 'input' && (x.enabled === undefined || x.enabled));

    async function load() {
        const r = await apiGet('/api/herd/events?active=1');
        EVENTS = ((r && r.events) || []).filter((e) => asks(e).length);
        const cats = r && r.categories ? r.categories : {};
        const by = {};
        EVENTS.forEach((e) => { (by[e.category] = by[e.category] || []).push(e); });
        sel.innerHTML = Object.keys(by).map((c) =>
            `<optgroup label="${esc(cats[c] || c)}">` + by[c].map((e) =>
                `<option value="${e.id}">${esc(e.name)}</option>`).join('') + '</optgroup>').join('')
            || '<option value="">подій із полями немає</option>';
        try {
            const last = localStorage.getItem('herd:imp_event') || '';
            if (last && sel.querySelector(`option[value="${last}"]`)) sel.value = last;
        } catch (_) { /* ignore */ }
        pick();
    }

    /* ПЕРЕЛІК ПОДІЙ ДЛЯ ЗМІШАНОГО ФАЙЛА (Роман 2026-09-25: «дозволити імпорт
       кількох подій одним файлом»). Обрані події дають ОБʼЄДНАННЯ колонок у
       зразку; у самому файлі вид рядка каже колонка «Подія». */
    function multiBox() {
        const box = $('imMultiBox');
        if (!box.dataset.ready) {
            box.innerHTML = EVENTS.map((e) =>
                `<label><input type="checkbox" value="${e.id}"> ${esc(e.name)}</label>`).join('');
            box.dataset.ready = '1';
            box.addEventListener('change', pick);
        }
        return box;
    }
    const multiOn = () => $('imMulti').checked;
    const chosen = () => [...multiBox().querySelectorAll('input:checked')]
        .map((c) => c.value);

    /* які колонки чекає файл і що можна писати у списках — видно ДО того,
       як людина почне заповнювати; інакше значення довелось би вгадувати */
    function pick() {
        const box = $('imCols');
        if (multiOn()) {
            const ids = chosen();
            $('imTpl').href = '/api/herd/import/template?events=' + encodeURIComponent(ids.join(','));
            const list = EVENTS.filter((e) => ids.includes(String(e.id)));
            const seen = new Set(), cols = [];
            list.forEach((e) => asks(e).forEach((x) => {
                const nm = x.param_label || x.param_key;
                if (!seen.has(nm)) { seen.add(nm); cols.push(esc(nm)); }
            }));
            box.innerHTML = ids.length
                ? `<div class="im-cl"><span>Колонки файла:</span> <b>Номер тварини</b> · `
                    + `<b>Дата</b> · <b>Подія</b> · ${cols.join(' · ')} · Нотатка`
                    + '<br><span>У колонці «Подія» пишіть назву події; у рядку діють '
                    + 'лише її поля, решта колонок для нього порожні.</span></div>'
                : '<div class="im-cl"><span>Відмітьте події, які будуть у файлі.</span></div>';
            return;
        }
        const e = EVENTS.find((x) => String(x.id) === String(sel.value));
        $('imTpl').href = '/api/herd/import/template?event=' + encodeURIComponent(sel.value || '');
        try { localStorage.setItem('herd:imp_event', sel.value || ''); } catch (_) { /* ignore */ }
        if (!e) { box.innerHTML = ''; return; }
        const cols = ['<b>Номер тварини</b>', '<b>Дата</b>']
            .concat(asks(e).map((x) => esc(x.param_label || x.param_key)
                + (x.required ? ' <i class="im-req">обовʼязково</i>' : '')))
            .concat(['Нотатка']);
        box.innerHTML = `<div class="im-cl"><span>Колонки файла:</span> ${cols.join(' · ')}`
            + '<br><span>У зразку є рядок-приклад — він показує формат; видаліть '
            + 'його або лишіть, програма його однаково пропустить.</span></div>';
    }

    async function send(dry) {
        if (!FILE) return;
        const res = $('imRes');
        res.hidden = false;
        res.innerHTML = '<p class="im-wait">Читаю файл…</p>';
        const fd = new FormData();
        fd.append('file', FILE);
        if (!multiOn()) fd.append('event', sel.value || '');
        if (dry) fd.append('dry', '1');
        let j;
        try {
            const r = await fetch('/api/herd/import/events', { method: 'POST', body: fd });
            j = await r.json();
        } catch (_) { res.innerHTML = '<p class="im-bad">Сервер не відповів</p>'; return; }
        if (!j.ok) { res.innerHTML = `<p class="im-bad">${esc(j.error || 'Помилка')}</p>`; return; }
        res.innerHTML = dry ? preview(j) : done(j);
        const go = $('imGo');
        if (go) go.addEventListener('click', () => { go.disabled = true; send(false); });
    }

    function preview(j) {
        const bad = (j.problems || []).map((p) =>
            `<tr><td class="num">${p.row}</td><td>${esc(p.tag)}</td><td>${esc(p.error)}</td></tr>`).join('');
        const many = (j.by_event || []).length > 1;
        const sample = (j.sample || []).map((x) =>
            `<tr><td>${esc(x.tag)}</td><td>${esc(dmy(x.date))}</td>`
            + (many ? `<td>${esc(x.event)}</td>` : '')
            + `<td>${esc(Object.values(x.values || {}).join(' · '))}</td></tr>`).join('');
        const byEv = (j.by_event || []).length > 1
            ? ' · ' + j.by_event.map((b) => `${esc(b.name)} — ${b.n}`).join(' · ') : '';
        return `<div class="im-sum"><b>${j.ready}</b> ${plural(j.ready, 'рядок', 'рядки', 'рядків')} готові`
            + byEv
            + (j.problems_n ? ` · <span class="im-bad">${j.problems_n} з помилками</span>` : '')
            + (j.ignored && j.ignored.length
                ? ` · колонки поза увагою: ${esc(j.ignored.join(', '))}` : '')
            + '</div>'
            + (sample ? `<table class="table im-tbl"><thead><tr><th>Тварина</th><th>Дата</th>`
                + (many ? '<th>Подія</th>' : '')
                + `<th>Значення</th></tr></thead><tbody>${sample}</tbody></table>` : '')
            + (bad ? `<div class="im-badbox"><b>Не зайдуть:</b><table class="table im-tbl">`
                + `<thead><tr><th class="num">Рядок</th><th>Тварина</th><th>Чому</th></tr></thead>`
                + `<tbody>${bad}</tbody></table></div>` : '')
            + (j.ready ? `<button type="button" class="btn btn-primary" id="imGo">`
                + `Записати ${j.ready} ${plural(j.ready, 'подію', 'події', 'подій')}</button>` : '');
    }

    function done(j) {
        const fail = (j.failed || []).map((f) =>
            `<tr><td>${esc(f.tag)}</td><td>${esc(f.error)}</td></tr>`).join('');
        return `<div class="im-ok">Записано <b>${j.applied}</b> `
            + `${plural(j.applied, 'подію', 'події', 'подій')}`
            + (j.batch_id ? ` · внесення №${esc(j.batch_id)}` : '')
            + ' · <a href="/herd/animals">подивитись в історії</a></div>'
            + (fail ? `<div class="im-badbox"><b>Не записалось:</b><table class="table im-tbl">`
                + `<tbody>${fail}</tbody></table></div>` : '');
    }

    const dmy = (d) => (String(d || '').length >= 10
        ? `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}` : (d || ''));
    function plural(n, one, few, many) {
        const a = Math.abs(n) % 100, b = a % 10;
        if (a > 10 && a < 20) return many;
        if (b === 1) return one;
        if (b >= 2 && b <= 4) return few;
        return many;
    }

    sel.addEventListener('change', () => { pick(); $('imRes').hidden = true; });
    $('imMulti').addEventListener('change', () => {
        const on = multiOn();
        multiBox().hidden = !on;
        sel.disabled = on;                 // вид рядка бере колонка «Подія»
        $('imRes').hidden = true;
        pick();
    });
    $('imFile').addEventListener('change', (e) => {
        FILE = (e.target.files || [])[0] || null;
        e.target.value = '';
        if (FILE) send(true);              // спершу ЗАВЖДИ розбір, не запис
    });
    load();
}());

/* ---------- Імпорт тварин і параметрів (переїхав із «Огляду») ----------
   Значення тут стають ПОТОЧНИМИ, без дати: це про реєстр (транспондер, UIN,
   кличка), а не про роботу на фермі. Дані з датою заходять імпортом подій. */
(function () {
    const inp = document.getElementById('imAnFile');
    if (!inp) return;
    const st = document.getElementById('imAnStatus');
    inp.addEventListener('change', async (e) => {
        const f = (e.target.files || [])[0];
        e.target.value = '';
        if (!f) return;
        st.textContent = 'Завантаження…';
        const fd = new FormData();
        fd.append('file', f);
        let j;
        try {
            const r = await fetch('/api/herd/animals/import', { method: 'POST', body: fd });
            j = await r.json();
        } catch (_) { st.textContent = 'Сервер не відповів'; return; }
        if (!j.ok) { st.textContent = 'Помилка: ' + (j.error || 'невідома'); return; }
        // кажемо не лише «скільки», а й ЩО зайшло: коли у файлі були колонки
        // параметрів, людина має бачити, що їх розпізнано
        const pc = j.param_columns || [];
        st.textContent = `Готово: додано ${j.added}, оновлено ${j.updated}`
            + (j.skipped ? `, пропущено ${j.skipped}` : '')
            + (j.missing ? `, не знайдено в реєстрі ${j.missing}` : '')
            + (pc.length ? ` · ${pc.join(', ')}: заповнено ${j.params_set || 0}` : '')
            + (j.errors && j.errors.length ? ` · помилок ${j.errors.length}` : '');
    });
}());
