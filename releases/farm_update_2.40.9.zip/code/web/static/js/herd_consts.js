/* Конструктор → «Налаштування»: числа ферми, які пишуться у формулах за
   назвою (Роман 2026-09-24: «тільність при отелі корів, нетелів, дата
   запуску корів — ті параметри, які можна в списках задіювати»).
   Цикл відтворення — готові рядки, міняється лише значення; власні —
   додаються й прибираються. Зберігається все однією кнопкою. */
'use strict';
(function () {
    const sysBody = document.getElementById('cnSys');
    const ownBody = document.getElementById('cnOwn');
    if (!sysBody || !ownBody) return;

    const esc = (t) => String(t === null || t === undefined ? '' : t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const canEdit = !!window.IS_ADMIN;
    const dis = canEdit ? '' : ' disabled';
    let SYS = [], OWN = [], dirty = false, saving = false, loaded = false;

    // як писати у формулі: коротка назва — одним словом, інакше [Назва]
    const fxName = (c) => (c.short ? c.short : `[${c.label}]`);
    const fmt = (v) => (v === null || v === undefined ? '' : String(v).replace('.', ','));

    function msg(text, cls) {
        const m = document.getElementById('cnMsg');
        m.textContent = text || '';
        m.className = 'cn-msg' + (cls ? ' ' + cls : '');
    }
    function markDirty() {
        dirty = true;
        msg('Є незбережені зміни', 'is-dirty');
    }

    function sysRow(c) {
        return `<tr data-key="${esc(c.key)}">
            <td class="cn-name">${esc(c.label)}</td>
            <td><span class="cn-code" title="Клік — скопіювати">${esc(fxName(c))}</span></td>
            <td><input type="text" inputmode="numeric" class="cn-in num cn-v"
                       value="${esc(fmt(c.value))}"${dis}></td>
            <td class="cn-note">${esc(c.unit)}</td>
            <td class="cn-note">${esc(c.note)}</td>
            <td></td></tr>`;
    }
    function ownRow(c) {
        return `<tr data-key="${esc(c.key || '')}">
            <td><input type="text" class="cn-in cn-l" maxlength="60" placeholder="Назва"
                       value="${esc(c.label)}"${dis}></td>
            <td><input type="text" class="cn-in cn-s" maxlength="30"
                       placeholder="одним словом" value="${esc(c.short)}"${dis}></td>
            <td><input type="text" inputmode="decimal" class="cn-in num cn-v"
                       value="${esc(fmt(c.value))}"${dis}></td>
            <td><input type="text" class="cn-in cn-u" maxlength="12" placeholder="дн"
                       value="${esc(c.unit)}"${dis}></td>
            <td><input type="text" class="cn-in cn-n" maxlength="200"
                       placeholder="навіщо це число" value="${esc(c.note)}"${dis}></td>
            <td>${canEdit ? '<button type="button" class="cn-del" title="Прибрати">✕</button>' : ''}</td></tr>`;
    }

    function render() {
        sysBody.innerHTML = SYS.map(sysRow).join('');
        ownBody.innerHTML = OWN.length ? OWN.map(ownRow).join('')
            : `<tr><td colspan="6" class="cn-empty">Власних налаштувань ще немає.
               ${canEdit ? 'Натисніть «+ Додати», щоб завести число, яке потрібне у ваших формулах.' : ''}</td></tr>`;
        document.getElementById('cnCount').textContent = OWN.length ? `· ${OWN.length}` : '';
        document.getElementById('cnAdd').hidden = !canEdit;
        document.getElementById('cnSave').hidden = !canEdit;
    }

    // назва у формулі теж має жити на сторінці: підсвітка формул параметрів
    // (herd_fxhl) бере її з window.HERD_CONSTS
    function publish() { window.HERD_CONSTS = SYS.concat(OWN); }

    async function load() {
        const r = await apiGet('/api/herd/consts');
        if (!r || !r.ok) { sysBody.innerHTML = '<tr><td colspan="6" class="cn-empty">Не вдалося прочитати налаштування</td></tr>'; return; }
        SYS = r.system || []; OWN = r.custom || [];
        loaded = true;
        publish();
        render();
        dirty = false;
        msg(canEdit ? '' : 'Змінювати може лише той, хто керує гілкою стада');
    }

    // рядки власних — із полів, як є зараз на екрані
    function readOwn() {
        return [...ownBody.querySelectorAll('tr[data-key]')].map((tr) => ({
            key: tr.dataset.key || '',
            label: tr.querySelector('.cn-l').value.trim(),
            short: tr.querySelector('.cn-s').value.trim(),
            value: tr.querySelector('.cn-v').value.trim(),
            unit: tr.querySelector('.cn-u').value.trim(),
            note: tr.querySelector('.cn-n').value.trim(),
        }));
    }

    // перемальовування бере значення з SYS, тож набране в полях циклу, але ще
    // не збережене, треба спершу забрати з екрана — інакше «+ Додати» чи ✕
    // тихо повертали б старі числа
    function keepSys() {
        sysBody.querySelectorAll('tr[data-key]').forEach((tr) => {
            const c = SYS.find((x) => x.key === tr.dataset.key);
            if (c) c.value = tr.querySelector('.cn-v').value;
        });
    }

    // число в полі: пробіли між тисячами й кома — дозволені, решта — ні
    const numOk = (v) => /^-?\d+([.,]\d+)?$/.test(String(v).replace(/[\s ]/g, ''));

    // поля й кнопки на час запиту гасимо: набране під час збереження
    // перемальовування мовчки затерло б
    function lockAll(on) {
        document.querySelectorAll('#bldConsts .cn-in, #cnAdd, #cnSave, .cn-del')
            .forEach((el) => { el.disabled = on || !canEdit; });
    }

    async function save() {
        // замок — першим рядком (урок 2.39.55); не прочитали — не пишемо, інакше
        // порожня таблиця на екрані стерла б усі власні налаштування
        if (saving || !loaded) return;
        saving = true;
            try {
            let bad = null;
            const system = {};
            sysBody.querySelectorAll('tr[data-key]').forEach((tr) => {
                const inp = tr.querySelector('.cn-v');
                const ok = numOk(inp.value) && parseFloat(inp.value.replace(',', '.')) > 0;
                inp.classList.toggle('is-bad', !ok);
                if (!ok && !bad) bad = inp;
                system[tr.dataset.key] = inp.value.trim();
            });
            ownBody.querySelectorAll('tr[data-key]').forEach((tr) => {
                const v = tr.querySelector('.cn-v'), l = tr.querySelector('.cn-l');
                const empty = !l.value.trim() && !v.value.trim();
                const vOk = empty || numOk(v.value), lOk = empty || !!l.value.trim();
                v.classList.toggle('is-bad', !vOk);
                l.classList.toggle('is-bad', !lOk);
                if (!vOk && !bad) bad = v;
                if (!lOk && !bad) bad = l;
            });
            if (bad) {
                msg('Виправте поле, виділене червоним: потрібне число або назва', 'is-err');
                bad.focus();
                return;
            }
            lockAll(true);
            const r = await apiSend('/api/herd/consts', 'POST', { system, custom: readOwn() });
            if (!r || !r.ok) {
                msg((r && r.error) || 'Сервер не відповів', 'is-err');
                return;
            }
            SYS = r.system || []; OWN = r.custom || [];
            publish();
            render();
            dirty = false;
            msg('Збережено — формули вже рахують з новими числами');
            if (window.toast) toast('Налаштування збережено', 'success');
        } finally {
            saving = false;
            lockAll(false);
        }
    }

    document.getElementById('cnAdd').addEventListener('click', () => {
        if (!loaded) return;
        keepSys();
        OWN = readOwn();
        OWN.push({ key: '', label: '', short: '', value: '', unit: '', note: '' });
        render();
        markDirty();
        const rows = ownBody.querySelectorAll('tr[data-key]');
        const last = rows[rows.length - 1];
        if (last) last.querySelector('.cn-l').focus();
    });
    ownBody.addEventListener('click', (e) => {
        const del = e.target.closest('.cn-del');
        if (!del) return;
        del.closest('tr').remove();
        keepSys();
        OWN = readOwn();
        render();
        markDirty();
    });
    document.getElementById('bldConsts').addEventListener('input', (e) => {
        if (e.target.classList.contains('cn-in')) {
            e.target.classList.remove('is-bad');
            markDirty();
        }
    });
    // Enter у будь-якому полі — зберегти (як у довідниках)
    document.getElementById('bldConsts').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.target.classList.contains('cn-in')) {
            e.preventDefault();
            save();
        }
    });
    document.getElementById('cnSave').addEventListener('click', save);
    // клік по назві — у буфер, щоб вставити у формулу
    document.getElementById('bldConsts').addEventListener('click', async (e) => {
        const c = e.target.closest('.cn-code');
        if (!c) return;
        try {
            await navigator.clipboard.writeText(c.textContent);
            if (window.toast) toast(`Скопійовано: ${c.textContent}`, 'success');
        } catch (_) { /* буфер недоступний — назву видно, можна переписати */ }
    });
    // не загубити зміни, пішовши зі сторінки
    window.addEventListener('beforeunload', (e) => {
        if (dirty) { e.preventDefault(); e.returnValue = ''; }
    });

    load();
})();
