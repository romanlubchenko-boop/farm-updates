/* Розкладка сторінок стада: ширину колонок задає сам користувач.
   Роздільник вставляється в будь-який .hp-2col, ширина памʼятається окремо
   для кожної сторінки. Подвійний клік по роздільнику — типове співвідношення.
   Зроблено за зразком роздільника на сторінці видачі. */
'use strict';
(function () {

const MIN = 25, MAX = 78;              // межі, за якими колонка стає нечитабельною
/* Ключ ширини — за сторінкою. Якщо та сама розкладка живе на кількох
   адресах (група подій відкривається і з /herd/log, і з /herd/group),
   у неї своє імʼя — щоб ширина не залежала від того, звідки прийшли. */
const key = (layout) => 'herd:split:'
    + ((layout && layout.dataset.splitKey) || location.pathname);

function init(layout) {
    if (layout.dataset.splitReady === '1') return;
    layout.dataset.splitReady = '1';

    // перша колонка — гнучка, друга тримає решту; керуємо змінною
    /* Ширину задаємо ЗМІННИМИ, а не готовим grid-template-columns: інлайн
       правило перебивало медіазапит, і на вузькому екрані бічна колонка
       лишалась стиснутою до нуля (Роман 2026-09-16). Змінні читає правило
       в herd-pages.css — воно живе всередині @media, тож на вузькому
       екрані сторінка спокійно стає одноколонковою. */
    const setPct = (pct) => {
        layout.style.setProperty('--split-a', pct + 'fr');
        layout.style.setProperty('--split-b', (100 - pct) + 'fr');
    };
    const saved = parseFloat(localStorage.getItem(key(layout)));
    if (isFinite(saved) && saved >= MIN && saved <= MAX) setPct(saved);

    const sp = document.createElement('div');
    sp.className = 'hp-split';
    sp.title = 'Перетягніть, щоб змінити ширину · подвійний клік — типова';
    // роздільник стоїть між колонками
    layout.insertBefore(sp, layout.children[1] || null);

    sp.addEventListener('mousedown', (ev) => {
        ev.preventDefault();
        sp.classList.add('dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        const onMove = (m) => {
            const r = layout.getBoundingClientRect();
            let pct = ((m.clientX - r.left) / r.width) * 100;
            pct = Math.max(MIN, Math.min(MAX, pct));
            setPct(pct);
            layout.dataset.pct = pct.toFixed(1);
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            sp.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            if (layout.dataset.pct) {
                try { localStorage.setItem(key(layout), layout.dataset.pct); } catch (_) { /* приватний режим */ }
            }
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });

    sp.addEventListener('dblclick', () => {
        layout.style.removeProperty('--split-a');
        layout.style.removeProperty('--split-b');
        delete layout.dataset.pct;
        try { localStorage.removeItem(key(layout)); } catch (_) { /* ignore */ }
        toast('Ширину повернуто до типової', 'success');
    });
}

document.querySelectorAll('.hp-2col').forEach(init);
})();
