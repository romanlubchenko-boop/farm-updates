/* Рядок формули з кольоровою підсвіткою й підказками — той самий, що в
   «Роботі зі стадом», але окремим модулем, щоб ним жив і Календар
   (Роман 2026-09-24: «всі налаштування в календар через строку формул»).

   herdFxEdit(host, {
       params: () => PARAMS,              // параметри конструктора
       groups: () => ['Група-1', …],      // назви секцій — значення для «group»
       acts: ['BODY','FILTER','VIEW'],    // які дії підказувати (додатковий список — лише FILTER)
       placeholder, onEnter(text), onInput(text),
   }) → { get(), set(text), focus(), input }

   Мова — herdQuery (herd_query.js): підсвітка й розбір спільні. */
'use strict';
(function () {
    const esc = (t) => String(t === null || t === undefined ? '' : t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const ACTS = {
        BODY: 'тіло — які параметри показати',
        FILTER: 'фільтрація — кого брати',
        FILTER2: 'додати тварин до списку: FILTER2([Пропущені] dcc>226)',
        VIEW: 'відображення — групи й порядок',
    };
    const DISP = [
        { w: 'groupby', t: 'групувати — групи в таблиці' },
        { w: 'sort', t: 'сортувати — порядок рядків' },
        { w: 'no', t: 'нумерація — колонка № з/п' },
        { w: 'nogroup', t: 'нумерація з 1 у кожній групі' },
        { w: 'desc', t: 'спад — від більшого до меншого' },
    ];
    const COND = [
        { w: '=', t: 'дорівнює' }, { w: '>', t: 'більше' }, { w: '<', t: 'менше' },
        { w: '>=', t: 'більше або дорівнює' }, { w: '<=', t: 'менше або дорівнює' },
        { w: '<>', t: 'не дорівнює' }, { w: 'between', t: 'між: between 200 260' },
        { w: 'contains', t: 'містить частину тексту' }, { w: 'empty', t: 'порожньо — значення немає' },
        { w: 'notempty', t: 'не порожньо — значення є' }, { w: 'or', t: 'або — кілька значень' },
    ];
    const TOK = '([\\p{L}\\d_./№]+|\\[[^\\]]+\\])';
    const short = (p) => (p.short || p.key || '').trim() || p.label;

    /* яка дія відкрита в місці курсора */
    function context(txt) {
        let open = null, depth = 0;
        const re = /([\p{L}]+\d*)\s*\(|\)/gu;   // FILTER2( — теж дія
        let m;
        while ((m = re.exec(txt))) {
            if (m[0] === ')') { depth = Math.max(0, depth - 1); if (!depth) open = null; }
            else { depth += 1; open = (m[1] || '').toLowerCase(); }
        }
        return depth ? open : null;
    }

    window.herdFxEdit = function (host, opt) {
        const o = opt || {};
        const params = () => (o.params ? o.params() : []) || [];
        const hl = (t) => window.herdQuery.highlight(t, params());
        host.classList.add('fxe');
        host.innerHTML = `<div class="fxe-hl" aria-hidden="true"></div>
            <input type="text" class="fxe-in" spellcheck="false" autocomplete="off"
                   placeholder="${esc(o.placeholder || '')}">`;
        const el = host.querySelector('.fxe-in'), hlBox = host.querySelector('.fxe-hl');
        const sug = document.createElement('div');
        sug.className = 'fxe-sug';
        sug.hidden = true;
        document.body.appendChild(sug);
        let SUG = [], POS = 0, FROM = 0, NAV = false;

        function paint() {
            hlBox.innerHTML = hl(el.value);
            hlBox.scrollLeft = el.scrollLeft;
        }
        function paramItems(word, close) {
            const w = (word || '').toLowerCase();
            const starts = (x) => String(x || '').toLowerCase().startsWith(w);
            return params().filter((p) => !w || starts(short(p)) || starts(p.key)
                || (p.label || '').toLowerCase().includes(w))
                .sort((a, b) => (Number(!starts(short(a))) - Number(!starts(short(b))))
                    || (short(a).length - short(b).length))
                .map((p) => ({ ins: short(p) + (close ? '] ' : ' '), w: short(p), t: p.label, k: 'p' }));
        }
        function valueItems(p, word) {
            const w = (word || '').toLowerCase();
            const list = p.key === 'group'
                ? ((o.groups ? o.groups() : []) || []).map((g) => ({ v: String(g), l: '' }))
                : (p.choices || []).map((c) => ({ v: String(c.value), l: String(c.label || '') }));
            return list.filter((x) => !w || x.v.toLowerCase().startsWith(w) || x.l.toLowerCase().includes(w))
                // значення з пробілом — у квадратних дужках, інакше формула розірветься
                .map((x) => ({ ins: (/\s/.test(x.v) ? `[${x.v}]` : x.v) + ' ', w: x.v,
                    t: x.l && x.l !== x.v ? x.l : '', k: 'v' }));
        }
        function suggest() {
            const at = el.selectionStart === null ? el.value.length : el.selectionStart;
            const left = el.value.slice(0, at);
            const inBr = left.lastIndexOf('[') > left.lastIndexOf(']');
            const findP = (tok) => window.herdQuery.findParam(tok, params());
            let items = [];
            if (inBr) {
                FROM = left.lastIndexOf('[') + 1;
                items = paramItems(left.slice(FROM), true);
            } else {
                const m = left.match(/[\p{L}\d_./№]*$/u);
                const word = m ? m[0] : '';
                FROM = at - word.length;
                const ctx = context(left);
                const lw = word.toLowerCase();
                if (!ctx) {
                    items = (o.acts || Object.keys(ACTS)).filter((w) => !lw || w.toLowerCase().startsWith(lw))
                        .map((w) => ({ ins: w + '(', w: w + '(', t: ACTS[w], k: 'a' }));
                } else if (['view', 'відображення', 'вигляд'].includes(ctx)) {
                    const grp = left.match(/\b(groupby|sort|групувати|сортувати)\s+([\p{L}\d_./]*)$/iu);
                    if (grp) items = paramItems(word, false);
                    else {
                        items = DISP.filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                            .map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t, k: 'w' }))
                            .concat(lw ? paramItems(word, false) : []);
                    }
                } else if (/^(filter|фільтр|фільтрація)\d*$/.test(ctx) || ctx === 'де') {
                    const vm = left.match(new RegExp(TOK + '\\s*(=|<>|!=|>=|<=|>|<)\\s*'
                        + '((?:[^\\s()]+\\s+(?:or|або)\\s+)*)([^\\s()]*)$', 'u'));
                    const cm = left.match(new RegExp(TOK + '\\s+([\\p{L}]*)$', 'u'));
                    const vp = vm ? findP(vm[1]) : null;
                    if (vp) {
                        FROM = at - vm[4].length;
                        items = valueItems(vp, vm[4]);
                    } else if (cm && findP(cm[1]) && !/^(between|між|contains|містить)$/i.test(cm[1])) {
                        const cw = cm[2].toLowerCase();
                        items = COND.filter((x) => !cw || x.w.toLowerCase().startsWith(cw))
                            .map((x) => ({ ins: x.w + (/^[<>=]/.test(x.w) ? '' : ' '), w: x.w, t: x.t, k: 'w' }));
                        if (cw) items = items.concat(paramItems(cm[2], false));
                    } else if (!/[<>=]$/.test(left.trimEnd())) {
                        items = paramItems(word, false);
                    }
                } else {
                    items = paramItems(word, false);
                }
            }
            SUG = items.slice(0, 40);
            POS = 0;
            NAV = false;
            draw();
        }
        function place() {
            if (sug.hidden) return;
            const r = el.getBoundingClientRect();
            const cs = getComputedStyle(el);
            const cv = place.cv || (place.cv = document.createElement('canvas'));
            const g = cv.getContext('2d');
            g.font = `${cs.fontSize} ${cs.fontFamily}`;
            const x0 = r.left + parseFloat(cs.paddingLeft)
                + g.measureText(el.value.slice(0, FROM)).width - el.scrollLeft;
            const w = sug.offsetWidth;
            sug.style.left = `${Math.round(Math.max(8, Math.min(x0, r.right - 40, window.innerWidth - w - 8)))}px`;
            const below = window.innerHeight - r.bottom - 10, above = r.top - 10;
            const up = below < 140 && above > below;
            sug.style.maxHeight = `${Math.min(320, Math.max(120, up ? above : below))}px`;
            sug.style.top = up ? '' : `${Math.round(r.bottom + 4)}px`;
            sug.style.bottom = up ? `${Math.round(window.innerHeight - r.top + 4)}px` : '';
        }
        function hint(t) {
            const m = String(t || '').match(/^(.*?:\s)([A-Za-z=(\[].*)$/);
            return m ? esc(m[1]) + `<i class="fxe-ex">${hl(m[2])}</i>` : esc(t || '');
        }
        function draw() {
            if (!SUG.length) { sug.hidden = true; return; }
            sug.innerHTML = SUG.map((x, i) =>
                `<div data-i="${i}"${i === POS ? ' class="on"' : ''}><b class="${x.k || ''}">${esc(x.w)}</b>`
                + `<span>${hint(x.t)}</span></div>`).join('')
                + '<div class="foot">↑↓ вибрати · Tab — вставити · Enter — застосувати · Esc — закрити</div>';
            sug.hidden = false;
            place();
        }
        function take(i) {
            const x = SUG[i];
            if (!x) return;
            const at = el.selectionStart === null ? el.value.length : el.selectionStart;
            el.value = el.value.slice(0, FROM) + x.ins + el.value.slice(at);
            const pos = FROM + x.ins.length;
            el.focus();
            el.selectionStart = el.selectionEnd = pos;
            sug.hidden = true;
            SUG = [];
            paint();
            suggest();
            if (o.onInput) o.onInput(el.value);
        }
        const close = () => { sug.hidden = true; SUG = []; };

        el.addEventListener('input', () => { paint(); suggest(); if (o.onInput) o.onInput(el.value); });
        el.addEventListener('scroll', () => { hlBox.scrollLeft = el.scrollLeft; });
        el.addEventListener('keyup', paint);
        el.addEventListener('click', suggest);
        el.addEventListener('focus', suggest);
        el.addEventListener('blur', () => setTimeout(() => { sug.hidden = true; }, 150));
        el.addEventListener('keydown', (e) => {
            const open = SUG.length && !sug.hidden;
            if (open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
                e.preventDefault();
                POS = (POS + (e.key === 'ArrowDown' ? 1 : SUG.length - 1)) % SUG.length;
                NAV = true;                          // обрали стрілками — Enter вставляє
                draw();
                const on = sug.querySelector('.on');
                if (on) on.scrollIntoView({ block: 'nearest' });
                return;
            }
            if (e.key === 'Enter' && open && NAV) { e.preventDefault(); take(POS); return; }
            if (e.key === 'Tab' && open) { e.preventDefault(); take(POS); return; }
            if (e.key === 'Escape') { close(); return; }
            if (e.key === 'Enter') {
                e.preventDefault();
                close();
                if (o.onEnter) o.onEnter(el.value);
            }
        });
        // клік у підказці — вставити (mousedown, щоб поле не втратило фокус)
        sug.addEventListener('mousedown', (e) => {
            const d = e.target.closest('[data-i]');
            if (!d) return;
            e.preventDefault();
            take(+d.dataset.i);
        });
        // редактор живе стільки, скільки його поле: коробка підказок лежить на
        // сторінці окремо, тож без прибирання вони копичились би з кожним малюванням
        function destroy() {
            window.removeEventListener('scroll', onWin, true);
            window.removeEventListener('resize', onWin);
            sug.remove();
        }
        function onWin() {
            if (!el.isConnected) { destroy(); return; }
            place();
        }
        window.addEventListener('scroll', onWin, true);
        window.addEventListener('resize', onWin);

        return {
            input: el,
            get: () => el.value,
            set(t) { el.value = t || ''; paint(); },
            focus() { el.focus(); },
            repaint: paint,
            destroy,
        };
    };
})();
