/* Сторінка «Події»: одна тварина ↔ група — один перемикач, одна сторінка.
   (Роман 2026-09-25: «події і груповий ввід обʼєднати в одну сторінку і на
   цій сторінці перемикатися між одиничним вводом події і груповим».)

   📌 Кожен режим веде СВІЙ модуль (herd_log.js і herd_group.js), тут лише
   показуємо потрібну половину. Модуль читає дані ЛИШЕ коли на його режим
   перемкнулись уперше — інакше сторінка на старті двічі тягнула б усе стадо
   й перелік подій.
   📌 Вибір режиму памʼятаємо, але лише КЛІК людини: коли режим задала
   адреса (з календаря — /herd/group?ids=…), наступний вхід у «Події»
   лишається таким, яким його лишила сама людина. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
const sw = $('evMode');
const page = document.querySelector('.hp[data-ev-mode]');
if (!sw || !page) return;

const LS = 'herd:ev_mode';
const PFX = { one: 'lg', many: 'hg' };      // префікс полів режиму
const booted = { one: false, many: false };
let mode = '';

function show(m) {
    document.querySelectorAll('.ev-one').forEach((e) => { e.hidden = (m !== 'one'); });
    document.querySelectorAll('.ev-many').forEach((e) => { e.hidden = (m !== 'many'); });
    sw.querySelectorAll('.seg-btn').forEach((b) => {
        b.classList.toggle('is-active', b.dataset.mode === m);
    });
}

/* Подія й дата переносяться між режимами: перемикач не має скидати те, що
   людина вже обрала. Значення випадайки — id події, однаковий в обох.
   `fire` — чи сповіщати модуль: якщо він щойно стартує, значення він
   прочитає сам, а зайва подія 'change' спричинила б друге читання стада. */
function carry(from, to, fire) {
    const a = PFX[from], b = PFX[to];
    if (!a || !b) return;
    const s1 = $(a + 'Event'), s2 = $(b + 'Event');
    if (s1 && s2 && s1.value && s2.value !== s1.value
        && s2.querySelector(`option[value="${s1.value}"]`)) {
        s2.value = s1.value;
        if (fire) s2.dispatchEvent(new Event('change'));
    }
    const d1 = $(a + 'Date'), d2 = $(b + 'Date');
    if (d1 && d2 && d1.value && d2.value !== d1.value) {
        d2.value = d1.value;
        if (fire) d2.dispatchEvent(new Event('change'));
    }
}

function setMode(m, byHand) {
    if (m !== 'one' && m !== 'many') m = 'one';
    if (m === mode) return;
    const prev = mode;
    mode = m;
    show(m);
    if (byHand) { try { localStorage.setItem(LS, m); } catch (_) { /* ignore */ } }

    const first = !booted[m];
    if (prev) carry(prev, m, !first);
    if (first) {
        booted[m] = true;
        const boot = (m === 'one') ? window.herdOneBoot : window.herdGroupBoot;
        if (typeof boot === 'function') boot();
    }
    if (!prev) return;                       // перший показ — фокус не забираємо
    const f = (m === 'one') ? $('lgAnimal') : $('hnInput');
    if (f && !first) f.focus();              // при першому старті фокус ставить сам модуль
}

sw.addEventListener('click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (b) setMode(b.dataset.mode, true);
});

let start = page.dataset.evMode || '';       // задано адресою (/herd/group)
if (!start) { try { start = localStorage.getItem(LS) || ''; } catch (_) { /* ignore */ } }
setMode(start || 'one', false);
page.removeAttribute('data-ev-wait');
})();
