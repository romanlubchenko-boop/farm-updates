/* Рядок запиту реєстру тварин: «мова» зі слів конструктора.
   Роман 2026-09-18: «контекстне поле, щоб зробити будь-який звіт і не
   обовʼязково його зберігати». Приклад:

     днів з осіменіння >= 35, репродуктивний код = 4,
     показати кличка, група, днів з осіменіння,
     групувати група, сортувати номер тварини

   Слова — ті самі, що в конструкторі параметрів: назва, скорочення або ключ.
   Порівняння: = ≠ > >= < <= , «between 28 35», «empty», «notempty»,
   «contains», кілька значень через «or». Службові слова — англійською
   (Роман 2026-09-19), як і дії FILTER/BODY/VIEW; українські (між, містить,
   порожньо, не порожньо, або) лишаються запасними — старі формули працюють. */
'use strict';

(function () {
    const norm = (s) => String(s === null || s === undefined ? '' : s)
        .trim().toLowerCase().replace(/[ʼ`´]/g, "'").replace(/\s+/g, ' ');
    const numOf = (v) => {
        const s = String(v === null || v === undefined ? '' : v).replace(',', '.').trim();
        if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
        return parseFloat(s);
    };

    // слова, з яких починається розділ запиту
    const HEADS = [
        { re: /^(body|тіло|показати|вивести|колонки)(?=\s|$)/, mode: 'show' },
        { re: /^(sort|сортувати|сортування|порядок)(?=\s|$)/, mode: 'sort' },
        { re: /^(groupby|групувати|групування|по групах)(?=\s|$)/, mode: 'group' },
        { re: /^(filter|де|фільтр|відбір)(?=\s|$)/, mode: 'where' },
    ];
    const DESC = /^(desc|спад|спадання|спадаюче|назад|↓)$/;
    const ASC = /^(asc|зрост|зростання|зростаюче|↑)$/;

    /* Параметр за словом: назва, скорочення, ключ або однозначний початок. */
    function findParam(word, params) {
        const w = norm(String(word).replace(/^\s*\[|\]\s*$/g, ''));
        if (!w) return null;
        const eq = params.find((p) => norm(p.label) === w || norm(p.short) === w
            || norm(p.key) === w);
        if (eq) return eq;
        const starts = params.filter((p) => norm(p.label).startsWith(w)
            || norm(p.short).startsWith(w) || norm(p.key).startsWith(w));
        if (starts.length === 1) return starts[0];
        const inside = params.filter((p) => norm(p.label).includes(w));
        if (inside.length === 1) return inside[0];
        return null;
    }

    /* Налаштування ферми (Конструктор → «Налаштування»): замість числа в
       умові можна написати назву — FILTER(dslh >= vwp),
       FILTER(dcc >= [Тільність корів]). Сторінка кладе їх у
       window.HERD_CONSTS, коли читає перелік параметрів. */
    function constOf(word) {
        const w = norm(String(word || '').replace(/^\s*\[|\]\s*$/g, ''));
        if (!w || numOf(w) !== null) return null;
        const c = (window.HERD_CONSTS || []).find((x) => norm(x.label) === w
            || norm(x.short) === w || norm(x.key) === w);
        return c && c.value !== null && c.value !== undefined ? String(c.value) : null;
    }

    /* Дату можна писати звично: 25.09.2026 (у базі вона ISO — 2026-09-25) */
    function dateNorm(v) {
        const m = String(v).match(/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{2,4})$/);
        if (!m) return v;
        const y = m[3].length === 2 ? '20' + m[3] : m[3];
        return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    }
    const isDateP = (p) => (p.dtype || '') === 'date';

    const NUM_DT = ['int', 'float', 'number'];
    function constFor(p, raw) {
        if ((p.choices || []).length || !NUM_DT.includes(p.dtype || '')) return null;
        return constOf(raw);
    }
    /* Як писати значення назад у формулу: назву налаштування — назвою, щоб
       причесаний після Enter рядок і збережений список далі стежили за ним,
       а не за числом, яке воно мало в мить набору. */
    function srcOf(p, raw) {
        const v = String(raw || '').trim().replace(/^\[(.*)\]$/, '$1').trim();
        // дату лишаємо в рядку такою, як її набрали (25.09.2026), хоч у базі
        // вона ISO — причісування не сміє міняти те, що людина написала
        if ((p.dtype || '') === 'date' && dateNorm(v) !== v) return v;
        return constFor(p, v) !== null ? v : null;
    }

    /* Значення умови: для списків приймається і назва, і код. */
    function valueOf(p, raw) {
        // значення з пробілами пишуться в дужках: group=[Група 0-3]
        const v0 = String(raw || '').trim().replace(/^\[(.*)\]$/, '$1').trim();
        const v = isDateP(p) ? dateNorm(v0) : v0;
        const ch = p.choices || [];
        // у ЧИСЛОВОГО параметра назва налаштування = його число; у текстового
        // слово лишається словом (кличка «Vwp» не повинна ставати числом 60)
        const cv = constFor(p, v);
        if (cv !== null) return cv;
        if (!ch.length || v === '') return v;      // «[]» — саме «не вказано», а не перший варіант
        const w = norm(v);
        const hit = ch.find((c) => norm(c.value) === w || norm(c.label) === w)
            || ch.find((c) => norm(c.label).startsWith(w))
            || ch.find((c) => norm(c.label).includes(w));
        return hit ? String(hit.value) : v;
    }

    function parseWhere(part, params) {
        const src = part.trim();
        // «empty» / «notempty» (і «порожньо» / «не порожньо»)
        let m = src.match(/^(.+?)\s+(notempty|not\s+empty|empty|(?:не\s+)?порожн\S*)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            return { f: { key: p.key, op: /^(не|not)/i.test(m[2]) ? 'nempty' : 'empty' } };
        }
        // «between 28 35», «between 28 and 35» (і «між 28 35»)
        m = src.match(/^(.+?)\s+(?:between|між)\s+(\[[^\]]+\]|.+?)\s*(?:,|—|-|\s+and\s+|\s+і\s+|\s+та\s+|\s)\s*(\[[^\]]+\]|\S+)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            const f = { key: p.key, op: 'between', v: valueOf(p, m[2]), v2: valueOf(p, m[3]) };
            const s1 = srcOf(p, m[2]), s2 = srcOf(p, m[3]);
            if (s1 !== null) f.vsrc = s1;
            if (s2 !== null) f.v2src = s2;
            return { f };
        }
        // «contains текст» (і «містить»)
        m = src.match(/^(.+?)\s+(?:contains|містить)\s+(.+)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            return { f: { key: p.key, op: 'has', v: m[2].trim().replace(/^\[(.*)\]$/, '$1').trim() } };
        }
        // звичайне порівняння
        m = src.match(/^(.+?)\s*(>=|<=|<>|!=|≠|≥|≤|=|>|<)\s*(.+)$/);
        if (!m) return { error: `не зрозуміла умова «${src}»` };
        const p = findParam(m[1], params);
        if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
        const opMap = { '>=': 'ge', '≥': 'ge', '<=': 'le', '≤': 'le', '<>': 'ne', '!=': 'ne', '≠': 'ne', '=': 'eq', '>': 'gt', '<': 'lt' };
        const op = opMap[m[2]];
        // «[]» — свідоме «не вказано» (так писався порожній варіант у старих
        // списках календаря); решта порожніх — сміття від розбиття
        const raws = m[3].split(/\s+(?:or|або)\s+|\s*\|\s*/)
            .filter((x) => x.trim() === '[]' || valueOf(p, x) !== '');
        const vals = raws.map((x) => valueOf(p, x));
        const srcs = raws.map((x) => srcOf(p, x));
        const named = srcs.some((x) => x !== null);
        if ((op === 'eq' || op === 'ne') && vals.length > 1) {
            const f = { key: p.key, op, vals };
            if (named) f.vsrcs = srcs.map((x, i) => (x !== null ? x : vals[i]));
            return { f };
        }
        const f = { key: p.key, op, v: vals[0] || '' };
        if (named && srcs[0] !== null) f.vsrc = srcs[0];
        return { f };
    }

    /* Функції формули (одним рядком, як в Excel):
       =ФІЛЬТР([Днів з осіменіння]>=35; [Репродуктивний код]=4)
        ПОКАЗАТИ([Кличка]; [Група]) ГРУПУВАТИ([Група]) СОРТУВАТИ([Номер тварини]; спад) */
    // три частини, як у налаштуваннях списку календаря:
    // ТІЛО (які параметри) · ФІЛЬТРАЦІЯ (кого брати) · ВІДОБРАЖЕННЯ (як показати)
    const FUNCS = {
        'body': 'show', 'тіло': 'show', 'показати': 'show', 'колонки': 'show',
        'filter': 'where', 'фільтрація': 'where', 'фільтр': 'where', 'де': 'where',
        'view': 'display', 'відображення': 'display', 'вигляд': 'display',
        'sort': 'sort', 'сортувати': 'sort', 'порядок': 'sort',
        'groupby': 'group', 'групувати': 'group', 'групи': 'group',
    };
    // слова всередині ВІДОБРАЖЕННЯ(…)
    const SHOW_WORDS = [
        { re: /^(groupby|групувати|групи|за групами)(?=\s|$)/, mode: 'group' },
        { re: /^(sort|сортувати|порядок|за)(?=\s|$)/, mode: 'sort' },
    ];
    const isFormula = (text) => {
        const t = String(text || '');
        if (/^\s*=/.test(t)) return true;
        return new RegExp('(' + Object.keys(FUNCS).join('|') + ')\\d*\\s*\\(', 'i').test(t);
    };
    /* Формула → ті самі розділи, що й рядки. */
    /* Частини ТІЛО(…) ФІЛЬТРАЦІЯ(…) ВІДОБРАЖЕННЯ(…): усередині можна писати
       і через пробіл, і через «;» — як зручніше (Роман 2026-09-18). */
    const NAME = '(\\[[^\\]]+\\]|[^\\s;,[\\]<>=!≠≥≤]+)';
    const ONE = '(?:\\[[^\\]]+\\]|[^\\s;,]+)';
    /* Межа діапазону: дата, число, потім уже будь-яке слово. Порядок важливий —
       інакше «220-226» ковтається одним шматком, і межі виходять «220-22» і «6»
       (Роман 2026-09-24: «уклав between у строку формул, воно не працює»). */
    const EDGE = '(?:\\[[^\\]]+\\]|\\d{4}-\\d{2}-\\d{2}|\\d{1,2}\\.\\d{1,2}\\.\\d{2,4}'
        + '|-?\\d+(?:[.,]\\d+)?|[^\\s;,]+)';
    const VAL = ONE + '(?:\\s+(?:or|або)\\s+' + ONE + ')*';
    const CONDS = new RegExp(
        NAME + '\\s*(?:'
        + '(>=|<=|<>|!=|≠|≥|≤|=|>|<)\\s*(' + VAL + ')'          // dslh>=35
        // роздільник між межами ОБОВʼЯЗКОВИЙ: інакше «220,226» читалось би як
        // одне дробове число, а друга межа набиралась би з його хвоста
        + '|(between|між)\\s+(' + EDGE + ')(?:\\s*(?:and|і|та|-|—|,)\\s*|\\s+)(' + EDGE + ')'
        + '|(contains|містить)\\s+(' + ONE + ')'                     // name contains Рай
        + '|(notempty|not\\s+empty|empty|не\\s+порожньо|порожньо)'   // name notempty
        + ')', 'giu');

    function splitNames(src) {                    // «name group dslh» або «[name]; [group]»
        return String(src).split(/[;,]|\s+/).map((x) => x.trim()).filter(Boolean);
    }

    /* → { list, rest }: rest — те, чого не впізнали. ⚠️ Доти залишок мовчки
       ПРОПАДАВ: «dcc between 220» (одна межа) чи одруківка просто зникали з
       рядка після Enter, і список рахувався без цієї умови
       (Роман 2026-09-24: «при натисканні Ентер просто зникає»). */
    function splitConds(src) {                    // «dslh>=35 rc=4» або «dslh >= 35; rc = 4»
        const txt = String(src).trim();
        if (!txt) return { list: [], rest: '' };
        const out = [];
        const eaten = [];
        let m;
        CONDS.lastIndex = 0;
        while ((m = CONDS.exec(txt))) {
            const nm = m[1];
            if (m[2]) out.push(`${nm} ${m[2]} ${m[3]}`);
            else if (m[4]) out.push(`${nm} between ${m[5]} ${m[6]}`);
            else if (m[7]) out.push(`${nm} contains ${m[8]}`);
            else if (m[9]) out.push(`${nm} ${/^(не|not)/i.test(m[9]) ? 'notempty' : 'empty'}`);
            else continue;
            eaten.push([m.index, m.index + m[0].length]);
        }
        if (!out.length) {
            return { list: txt.split(/[;,]/).map((x) => x.trim()).filter(Boolean), rest: '' };
        }
        // що лишилось поза впізнаними умовами
        let rest = txt;
        eaten.slice().reverse().forEach(([a, b]) => { rest = rest.slice(0, a) + ' '.repeat(b - a) + rest.slice(b); });
        rest = rest.replace(/[;,]/g, ' ').trim().replace(/\s+/g, ' ');
        return { list: out, rest };
    }

    /* ВІДОБРАЖЕННЯ: слова-дії, далі назви; «спад» діє на попереднє сортування */
    function splitDisplay(src, out, params) {
        const toks = String(src).split(/[;,]|\s+/).map((x) => x.trim()).filter(Boolean);
        let mode = '';
        let expect = false;                       // одразу після «group»/«sort» іде назва
        const isKw = (n) => /^(groupby|групувати|групи|sort|сортувати|порядок)$/.test(n);
        for (let ti = 0; ti < toks.length; ti++) {
            const t = toks[ti];
            const n = norm(t);
            // «group» — і слово-дія, і коротка назва параметра «Група». Якщо далі
            // назви немає — це сам параметр (VIEW(group) = групувати за групою).
            const nextT = toks[ti + 1];
            const asKw = isKw(n) && !expect
                && (!findParam(t, params) || (nextT && !!findParam(nextT, params)));
            if (asKw && /^(groupby|групувати|групи)$/.test(n)) { mode = 'group'; expect = true; continue; }
            if (asKw && /^(sort|сортувати|порядок)$/.test(n)) { mode = 'sort'; expect = true; continue; }
            // «nogroup» — нумерація з 1 у кожній групі (як у Календарі)
            if (/^(nogroup|no-group|нумераціягруп)$/.test(n)) { out.push({ mode: 'rownum', text: 'group' }); continue; }
            if (/^(no|num|нумерація|нумерувати|номер|№)$/.test(n)) { out.push({ mode: 'rownum', text: '1' }); continue; }
            if (/^(cnt|count|кількість|к-сть)$/.test(n)) {
                const nx = toks[ti + 1];
                const hasP = nx && !isKw(norm(nx)) && !DESC.test(norm(nx)) && !ASC.test(norm(nx))
                    && !/^(cnt|count|avg|sum|min|max|no|num|кількість|середнє|сума|мін|макс|нумерація)$/.test(norm(nx))
                    && !!findParam(nx, params);
                out.push({ mode: 'cnt', text: hasP ? nx : '' });
                if (hasP) ti += 1;
                expect = false;
                continue;
            }
            if (/^(avg|середнє|середне)$/.test(n)) { mode = 'avg'; expect = true; continue; }
            if (/^(sum|сума)$/.test(n)) { mode = 'sum'; expect = true; continue; }
            if (/^(min|мін|мінімум)$/.test(n)) { mode = 'min'; expect = true; continue; }
            if (/^(max|макс|максимум)$/.test(n)) { mode = 'max'; expect = true; continue; }
            if (DESC.test(n) || ASC.test(n)) {
                // «desc» діє на попереднє сортування, а якщо його немає —
                // на попереднє групування: VIEW(groupby group desc) = групи навпаки
                let hit = -1;
                for (let i = out.length - 1; i >= 0; i--) {
                    if (out[i].mode === 'sort' || out[i].mode === 'group') { hit = i; break; }
                }
                if (hit >= 0 && out[hit].mode === 'sort') out[hit].text += ' ' + t;
                else if (hit >= 0) out.push({ mode: 'sort', text: `${out[hit].text} ${t}` });
                continue;
            }
            if (!mode) mode = 'group';            // сама назва у VIEW = групування
            out.push({ mode, text: t });
            expect = false;
        }
        return '';
    }

    /* Назва додаткового блоку: «FILTER2([Пропущені] dcc>226)». Це назва лише
       тоді, коли за дужками НЕ йде умова — інакше це параметр із пробілом
       («[Днів тільності] > 30»). */
    function pickName(src) {
        const m = String(src).match(/^\s*\[([^\]]+)\]\s*(.*)$/s);
        if (!m) return { name: '', rest: src };
        const tail = m[2].trim();
        const isCond = !tail || /^(?:[<>=!≠≥≤]|between\b|між\b|contains\b|містить\b|empty\b|notempty\b|not\s+empty\b|порожн|не\s+порожн)/i.test(tail);
        return isCond ? { name: '', rest: src } : { name: m[1].trim(), rest: m[2] };
    }

    function formulaParts(text, params) {
        const src = String(text || '').replace(/^\s*=/, '');
        const out = [];
        const re = /([\p{L}]+\d*)\s*\(([^()]*)\)/gu;
        let m, seen = 0;
        // те, що не вклалось у ДІЯ(...) — напр. незакрита дужка «VIEW(groupby group»
        // або зайве слово: не мовчати й НЕ губити при впорядкуванні рядка
        const left = src.replace(re, ' ').trim();
        if (left) return { error: `не зрозуміло «${left}» — перевірте дужки` };
        let extraNo = 0;
        while ((m = re.exec(src))) {
            const word = norm(m[1]);
            // FILTER2, FILTER3… — додаткові тварини до основного списку
            // (Роман 2026-09-24: «фільтр 2, який додає до основного списку»)
            const ex = word.match(/^(filter|фільтр|фільтрація)(\d+)$/);
            if (ex) {
                if (+ex[2] < 2) return { error: `невідома дія «${m[1]}»` };
                const got0 = pickName(m[2]);
                const got = splitConds(got0.rest);
                if (got.rest) return { error: `не зрозуміла умова «${got.rest}»` };
                if (!got.list.length) return { error: `${m[1]}(…) без умов — кого додавати?` };
                const idx = extraNo++;
                out.push({ mode: 'extraname', text: got0.name, idx });
                got.list.forEach((c) => out.push({ mode: 'extra', text: c, idx }));
                seen += 1;
                continue;
            }
            const fn = FUNCS[word];
            if (!fn) return { error: `невідома дія «${m[1]}»` };
            seen += 1;
            if (fn === 'display') {
                const err = splitDisplay(m[2], out, params);
                if (err) return { error: err };
            } else if (fn === 'where') {
                const got = splitConds(m[2]);
                if (got.rest) {
                    // дві найчастіші причини: немає назви параметра або одна межа
                    const noName = /^(between|між)\b/i.test(got.rest);
                    const hint = noName
                        ? ' — перед «between» має стояти назва параметра: dcc between 213 220'
                        : (/\b(between|між)\b/i.test(got.rest)
                            ? ' — для проміжку потрібні ДВІ межі: dcc between 213 220' : '');
                    return { error: `не зрозуміла умова «${got.rest}»${hint}` };
                }
                got.list.forEach((c) => out.push({ mode: 'where', text: c }));
            } else if (fn === 'sort') {
                const toks = splitNames(m[2]);
                const dir = toks.filter((t) => DESC.test(norm(t)) || ASC.test(norm(t))).pop() || '';
                toks.filter((t) => !DESC.test(norm(t)) && !ASC.test(norm(t)))
                    .forEach((t) => out.push({ mode: 'sort', text: dir ? `${t} ${dir}` : t }));
            } else {
                splitNames(m[2]).forEach((t) => out.push({ mode: fn, text: t }));
            }
        }
        if (!seen) return { error: 'не бачу жодної дії — напр. FILTER(rc=4)' };
        return { parts: out };
    }

    /* Текст → {cols, filters, sorts, groups, keys, error}. */
    function parse(text, params) {
        const out = { cols: [], filters: [], sorts: [], groups: [], rownum: false,
            aggs: [], extra: [], keys: [], error: '' };
        const src = String(text || '').trim();
        if (!src) return out;
        let mode = 'where';
        let parts;
        let modes = null;
        let idxs = null;
        if (isFormula(src)) {
            const f = formulaParts(src, params);
            if (f.error) { out.error = f.error; return out; }
            parts = f.parts.map((x) => x.text);
            modes = f.parts.map((x) => x.mode);
            idxs = f.parts.map((x) => (x.idx === undefined ? -1 : x.idx));
        } else {
            parts = src.split(/[,;\n]+/).map((x) => x.trim()).filter(Boolean);
        }
        for (let pi = 0; pi < parts.length; pi++) {
            let part = parts[pi];
            if (modes) mode = modes[pi];
            if (mode === 'extraname' || mode === 'extra') {
                const i = idxs[pi];
                while (out.extra.length <= i) out.extra.push({ name: '', filters: [] });
                if (mode === 'extraname') { out.extra[i].name = part; continue; }
                const r = parseWhere(part, params);
                if (r.error) { out.error = r.error; return out; }
                out.extra[i].filters.push(r.f);
                continue;
            }
            if (mode === 'rownum') { out.rownum = part === 'group' ? 'group' : (out.rownum || true); continue; }
            if (mode === 'cnt' && !part) { out.aggs.push({ fn: 'cnt', key: '' }); continue; }
            if (mode === 'cnt') {
                const p = part ? findParam(part, params) : null;
                if (part && !p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.aggs.push({ fn: 'cnt', key: p ? p.key : '' });
                continue;
            }
            if (['avg', 'sum', 'min', 'max'].includes(mode)) {
                const p = findParam(part, params);
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.aggs.push({ fn: mode, key: p.key });
                continue;
            }
            for (const h of (modes ? [] : HEADS)) {
                if (h.re.test(norm(part))) {
                    mode = h.mode;
                    part = part.replace(/^\S+\s*/, '').trim();
                    break;
                }
            }
            if (!part) continue;
            if (mode === 'show' || mode === 'group') {
                let p = findParam(part, params);
                if (!p && parts[pi + 1]) {          // назва з комою: «Вік, міс»
                    const joined = part + ', ' + parts[pi + 1];
                    p = findParam(joined, params);
                    if (p) pi += 1;
                }
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                (mode === 'show' ? out.cols : out.groups).push(p.key);
            } else if (mode === 'sort') {
                const w = part.split(/\s+/);
                let dir = 'asc';
                if (w.length > 1 && (DESC.test(norm(w[w.length - 1])) || ASC.test(norm(w[w.length - 1])))) {
                    dir = DESC.test(norm(w.pop())) ? 'desc' : 'asc';
                }
                let p = findParam(w.join(' '), params);
                if (!p && parts[pi + 1]) {
                    p = findParam(w.join(' ') + ', ' + parts[pi + 1], params);
                    if (p) pi += 1;
                }
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.sorts.push({ key: p.key, dir });
            } else {
                let r = parseWhere(part, params);
                if (r.error && parts[pi + 1]) {     // назва з комою: «Вік, міс > 24»
                    const r2 = parseWhere(part + ', ' + parts[pi + 1], params);
                    if (!r2.error) { r = r2; pi += 1; }
                }
                if (r.error) { out.error = r.error; return out; }
                out.filters.push(r.f);
            }
        }
        out.cols = [...new Set(out.cols)];       // «вік, міс» не двоїться
        out.groups = [...new Set(out.groups)];
        out.keys = [...new Set([...out.cols, ...out.groups, ...out.aggs.map((a) => a.key),
            ...out.sorts.map((s) => s.key), ...out.filters.map((f) => f.key),
            ...out.extra.flatMap((e) => e.filters.map((f) => f.key))])];
        return out;
    }

    /* ── перевірка умов ───────────────────────────────────────────────── */
    const valOf = (a, k) => (a.p || {})[k];
    const labOf = (a, k) => (a.pl || {})[k];

    function cmp(a, f) {
        const raw = valOf(a, f.key);
        const has = !(raw === null || raw === undefined || raw === '');
        if (f.op === 'empty') return !has;
        if (f.op === 'nempty') return has;
        // «не вказано» пишеться значенням «[]» (так було в старих списках
        // календаря): порожнє в тварини теж підходить під таку умову
        const wantsEmpty = (f.vals || []).includes('') || f.v === '';
        // «<>» порожніх НЕ бере (так було доти в «Роботі зі стадом» — не міняємо
        // мовчки зміст збережених формул)
        if (!has) return f.op === 'eq' && wantsEmpty;
        const n = numOf(raw);
        const list = (f.vals || []).map(norm).filter((x) => x !== '');
        const one = norm(f.v);
        const lab = norm(labOf(a, f.key));
        const me = norm(raw);
        // порожню назву в порівняння не пускаємо — інакше умова «= не вказано»
        // збігалася б із КОЖНОЮ твариною, у якої немає підпису значення
        const hitOne = me === one || (!!lab && lab === one);
        if (f.op === 'has') return me.includes(one) || (!!lab && lab.includes(one));
        if (f.op === 'eq') return (list.length || f.vals) ? (list.includes(me) || (!!lab && list.includes(lab)))
            : (one !== '' && hitOne);
        if (f.op === 'ne') return (list.length || f.vals) ? !(list.includes(me) || (!!lab && list.includes(lab)))
            : (one === '' || !hitOne);
        if (f.op === 'between') {
            const lo = numOf(f.v), hi = numOf(f.v2);
            if (n !== null && lo !== null && hi !== null) return n >= Math.min(lo, hi) && n <= Math.max(lo, hi);
            if (n !== null || lo !== null || hi !== null) return false;
            // дати (РРРР-ММ-ДД) — рядками, як і > < для дат
            const x = String(raw).slice(0, 10), a = String(f.v), b = String(f.v2);
            return x >= (a < b ? a : b) && x <= (a < b ? b : a);
        }
        const x = numOf(f.v);
        if (n === null || x === null) {            // дати й текст — як рядки
            const s = String(raw), t = String(f.v);
            if (f.op === 'gt') return s > t;
            if (f.op === 'ge') return s >= t;
            if (f.op === 'lt') return s < t;
            if (f.op === 'le') return s <= t;
            return false;
        }
        if (f.op === 'gt') return n > x;
        if (f.op === 'ge') return n >= x;
        if (f.op === 'lt') return n < x;
        if (f.op === 'le') return n <= x;
        return false;
    }

    const passes = (a, filters) => (filters || []).every((f) => cmp(a, f));

    /* Додатковий блок (FILTER2) бере умови ОСНОВНОГО, а свої замінюють умову
       на той самий параметр — так само, як «додатковий список» у Календарі. */
    function extraFilters(main, own) {
        const keys = new Set((own || []).map((f) => f.key));
        return [...(main || []).filter((f) => !keys.has(f.key)), ...(own || [])];
    }

    /* Сортування кількома ключами; порожні — в кінець. */
    function sortRows(rows, sorts, params) {
        const order = new Map();
        (params || []).forEach((p) => {
            const m = new Map();
            (p.choices || []).forEach((c, i) => { m.set(String(c.value), i); });
            order.set(p.key, m);
        });
        // значення для порівняння: [ранг, число] або [ранг, рядок]. Ранг ділить
        // числа/позиції у списку (0) і текст (1) — інакше порівняння числа з
        // рядком дає NaN, і сортування мовчки розвалюється (секція, якої немає
        // у списку конструктора, ламала порядок усіх груп)
        const val = (a, k) => {
            const raw = valOf(a, k);
            if (raw === null || raw === undefined || raw === '') return null;
            const pos = order.get(k);
            if (pos && pos.size && pos.has(String(raw))) return [0, pos.get(String(raw))];
            const n = numOf(raw);
            return n === null ? [1, norm(raw)] : [0, n];
        };
        const cmpv = (a, b) => {
            if (a[0] !== b[0]) return a[0] - b[0];
            if (a[1] < b[1]) return -1;
            if (a[1] > b[1]) return 1;
            return 0;
        };
        return rows.slice().sort((x, y) => {
            for (const s of (sorts || [])) {
                const a = val(x, s.key), b = val(y, s.key);
                if (a === null && b === null) continue;
                if (a === null) return 1;
                if (b === null) return -1;
                const c = cmpv(a, b);
                if (c) return s.dir === 'desc' ? -c : c;
            }
            return 0;
        });
    }

    /* Акуратний вигляд формули: дії великими, без зайвих пробілів,
       параметри — короткими назвами (Роман 2026-09-18). */
    const OP_SIGN = { eq: '=', ne: '<>', gt: '>', ge: '>=', lt: '<', le: '<=' };

    function shortOf(key, params) {
        const p = (params || []).find((x) => x.key === key);
        return p ? ((p.short || p.key || '').trim() || p.label) : key;
    }

    function format(q, params) {
        if (!q || q.error) return '';
        const nm = (k) => shortOf(k, params);
        const parts = [];
        const condTxt = (fs) => fs.map((f) => {
            const k = nm(f.key);
            if (f.op === 'empty') return `${k} empty`;
            if (f.op === 'nempty') return `${k} notempty`;
            const q2 = (x) => (/[\s;,]/.test(String(x)) ? `[${x}]` : x);
            const e2 = (x) => (String(x) === '' ? '[]' : q2(x));
            if (f.op === 'between') return `${k} between ${q2(f.vsrc || f.v)} ${q2(f.v2src || f.v2)}`;
            if (f.op === 'has') return `${k} contains ${q2(f.v)}`;
            const v = (f.vals && f.vals.length) ? (f.vsrcs || f.vals).map(e2).join(' or ')
                : e2(f.vsrc || f.v);
            return `${k}${OP_SIGN[f.op] || '='}${v}`;
        }).join(' ');
        if (q.cols.length) parts.push(`BODY(${q.cols.map(nm).join(' ')})`);
        if (q.filters.length) parts.push('FILTER(' + condTxt(q.filters) + ')');
        // додаткові блоки — одразу за основною фільтрацією
        (q.extra || []).forEach((e, i) => {
            if (!e || !e.filters || !e.filters.length) return;
            parts.push(`FILTER${i + 2}(${e.name ? `[${e.name}] ` : ''}${condTxt(e.filters)})`);
        });
        const view = [];
        if (q.rownum) view.push(q.rownum === 'group' ? 'nogroup' : 'no');
        q.groups.forEach((k) => view.push(`groupby ${nm(k)}`));
        q.sorts.forEach((sx) => view.push(`sort ${nm(sx.key)}${sx.dir === 'desc' ? ' desc' : ''}`));
        (q.aggs || []).forEach((a) => view.push(a.key ? `${a.fn} ${nm(a.key)}` : a.fn));
        if (view.length) parts.push(`VIEW(${view.join(' ')})`);
        return parts.length ? '=' + parts.join(' ') : '';
    }

    /* Кольорова підсвітка рядка формули — одна для «Роботи зі стадом»,
       «Списків», «Огляду» і Календаря (Роман 2026-09-19). Класи:
       k — дія, w — службове слово, p — параметр, o — умова, n — значення,
       b — дужки й розділові. */
    const ACT_RE = /^(body|filter\d*|view|тіло|фільтрація\d*|фільтр\d*|відображення|вигляд|показати|колонки|де|sort|group|groupby)$/i;
    const WORD_RE = /^(groupby|sort|no|nogroup|num|cnt|count|avg|sum|min|max|desc|asc|кількість|середнє|сума|мін|макс|групувати|групи|сортувати|порядок|нумерація|номер|спад|зрост|між|містить|порожньо|не|або|between|and|contains|empty|notempty|not|or)$/i;
    const hEsc = (t) => String(t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    function highlight(txt, params) {
        const ps = params || [];
        const short = (p) => ((p.short || p.key || '').trim() || p.label || '').toLowerCase();
        const isP = (w) => {
            const x = String(w).trim().toLowerCase();
            return ps.some((p) => short(p) === x || (p.label || '').toLowerCase() === x);
        };
        const src = String(txt || '');
        // назва може містити «/» і «.» (milk/lkd); значення з пробілом — у [дужках]
        const re = /([A-Za-zА-Яа-яЇїІіЄєҐґ_][A-Za-zА-Яа-яЇїІіЄєҐґ_\d.\-]*(?:\/[A-Za-zА-Яа-яЇїІіЄєҐґ_\d.\-]+)*)|(\d+[.,]?\d*)|(>=|<=|<>|!=|≠|≥|≤|=|>|<)|(\[[^\]]*\]?)|([()\];,])|(\s+)|(.)/g;
        let out = '', m;
        while ((m = re.exec(src))) {
            const t = m[0], e = hEsc(t);
            if (m[1]) {
                if (ACT_RE.test(t) && src.slice(re.lastIndex).trimStart().startsWith('(')) out += `<span class="k">${e}</span>`;
                else if (WORD_RE.test(t)) out += `<span class="w">${e}</span>`;
                else out += `<span class="${isP(t) ? 'p' : 'n'}">${e}</span>`;
            } else if (m[2]) out += `<span class="n">${e}</span>`;
            else if (m[3]) out += `<span class="o">${e}</span>`;
            else if (m[4]) out += `<span class="${isP(t.replace(/^\[|\]$/g, '')) ? 'p' : 'n'}">${e}</span>`;
            else if (m[5]) out += `<span class="b">${e}</span>`;
            else out += e;
        }
        return out;
    }

    window.herdQuery = { parse, passes, extraFilters, sortRows, findParam, valOf, labOf,
        isFormula, format, highlight };
}());
