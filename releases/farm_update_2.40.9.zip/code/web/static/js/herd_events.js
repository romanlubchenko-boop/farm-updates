/* Налаштування подій стада — сторінка за макетом «Події ВРХ»:
   крихти · заголовок із випадайкою події · дія праворуч, три кроки
   (Доступ · Поля · Перегляд) в одній картці, нижче — коло відтворення
   і самоперевірка. Дії та правила «Якщо» редагуються прямо в кроці «Поля». */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let EVENTS = [], PARAMS = [], ALL_PARAMS = [], CATS = {}, MODES = {}, USERS = [];
let cur = null;          // подія, яку налаштовуємо
let WORK = [];           // робоча копія її полів/дій
let ACCESS = [];         // id людей, яким дозволено вносити подію
let step = 1, openRow = '', dirty = false, dragCode = '';
let pkQ = '', pkCat = 'Усі';

/* Памʼять місця: після F5 повертаємось до тієї самої події, кроку і прокрутки. */
const LS_EV = 'herd:ev_id', LS_STEP = 'herd:ev_step', LS_SCROLL = 'herd:ev_scroll';
const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch (_) { return ''; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, String(v)); } catch (_) { /* приватний режим */ } };
let scrollRestored = false;   // прокрутку відновлюємо один раз за завантаження

const ARG_MODES = new Set(['const', 'inc']);
const TYPES = { date: 'дата', text: 'текст', int: 'ціле', float: 'число', number: 'число',
    bool: 'так / ні', list: 'список', cod: 'код', ref_animal: 'тварина' };

const dmy = (d) => d ? `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}` : '';

async function load(keepId) {
    const r = await apiGet('/api/herd/events');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    EVENTS = r.events || [];
    // ефектам події обчислювані параметри не годяться, а шаблону деталей —
    // цілком (їх значення рахується на дату події)
    ALL_PARAMS = (r.params || []).slice()
        .sort((a, b) => (a.label || '').localeCompare(b.label || '', 'uk'));
    PARAMS = ALL_PARAMS.filter((p) => !(p.formula || '').trim());
    CATS = r.categories || {};
    FACTS = r.facts || {};
    MODES = r.modes || {};
    USERS = r.users || [];
    const today = new Date();
    $('hpToday').textContent = dmy(`${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`);
    fillEventSelect(keepId || (cur && cur.id) || lsGet(LS_EV));
    renderCycle();
}

function fillEventSelect(wantId) {
    // події обираються списком під шапкою — окремої випадайки більше немає
    const ev = EVENTS.find((e) => e.id === +wantId) || EVENTS[0];
    if (ev) selectEvent(ev.id);
}

/* Список усіх подій під шапкою — щоб було видно, що є, без розкриття
   випадайки (саме його бракувало після переходу на select). */
function renderEventList(activeId) {
    const box = $('ebList');
    if (!box) return;
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    box.innerHTML = order.filter((c) => (bySec[c] || []).length).map((c) =>
        `<div class="eb-cat">${escapeHtml(CATS[c] || c)}</div>`
        + bySec[c].map((e) => `<button type="button" class="eb-ev${e.id === +activeId ? ' on' : ''}`
            + `${e.is_active ? '' : ' off'}" data-id="${e.id}"`
            + `${e.is_standard ? '' : ' title="створена подія"'}>${escapeHtml(e.name)}</button>`).join('')
    ).join('');
    box.querySelectorAll('.eb-ev').forEach((b) => b.addEventListener('click', async () => {
        await flushSave();       // зміни фіксуються самі — питати нема про що
        selectEvent(+b.dataset.id);
    }));
}

// ⚠️ шукаємо серед УСІХ параметрів, не лише тих, що подія може змінити:
// інакше поле-довідка (обчислюване) підписувалось технічним ключем
// «exit_sum_nv» замість «Сума без ПДВ, ₴» (Роман 2026-09-20 «не бачу, де воно»)
function paramByKey(k) { return ALL_PARAMS.find((p) => p.key === k); }
function typeLabel(p) { return (p && TYPES[p.dtype]) || (p && p.dtype) || ''; }
function codeLabel(paramKey, val) {
    const p = paramByKey(paramKey);
    const c = ((p && p.choices) || []).find((x) => String(x.value) === String(val));
    return c ? c.label : (val || '—');
}
const isInput = (e) => e.mode === 'input';
const isOn = (e) => !('enabled' in e) || !!e.enabled;

/* ═══════════ ВИБІР ПОДІЇ ═══════════ */
function selectEvent(id) {
    const ev = EVENTS.find((e) => e.id === +id);
    if (!ev) return;
    cur = ev;
    WORK = (ev.effects || []).map((e) => ({
        param_key: e.param_key, mode: e.mode, arg: e.arg || '',
        required: e.required ? 1 : 0,
        quick: ('quick' in e && !e.quick) ? 0 : 1,
        enabled: ('enabled' in e && !e.enabled) ? 0 : 1,
    }));
    ACCESS = (ev.access_list || []).slice();
    openRow = ''; dirty = false;
    $('ebName').value = ev.name || '';
    if ($('ebCurName')) $('ebCurName').textContent = ev.name || '';
    $('ebCat').innerHTML = Object.entries(CATS).map(([k, v]) =>
        `<option value="${k}"${ev.category === k ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
    $('ebActive').checked = !!ev.is_active;
    $('ebPanel').checked = ev.show_on_panel === undefined ? true : !!ev.show_on_panel;
    $('ebAttach').innerHTML = '<option value="">— самостійна, вноситься окремо —</option>'
        + EVENTS.filter((x) => x.id !== ev.id && (x.attach_to || '') !== ev.key).map((x) =>
            `<option value="${escapeHtml(x.key)}"${x.key === (ev.attach_to || '') ? ' selected' : ''}>${escapeHtml(x.name)}</option>`).join('');
    renderAlso(ev);
    $('ebDel').style.display = (!ev.is_standard || window.canManage('herd')) ? '' : 'none';
    syncAttachWarn();
    renderEventList(ev.id);
    renderAllowRc();                 // чипи станів «захисту від помилок»
    renderDetailKeys();              // що подія пише в «Деталі» історії
    advEvSet(false);                 // розширені при відкритті завжди сховані
    renderPreview();                 // макет завжди показує поточну подію
    lsSet(LS_EV, ev.id);
    setStep(+lsGet(LS_STEP) || 1);
    if (!scrollRestored) {
        scrollRestored = true;
        const y = +lsGet(LS_SCROLL) || 0;
        if (y) setTimeout(() => window.scrollTo(0, y), 80);
    }
}

/* Подія-частина не вноситься окремо — попереджаємо прямо біля поля,
   інакше вона мовчки зникає зі списку на сторінці внесення. */
function syncAttachWarn() {
    const box = $('ebAttachWarn');
    if (!box) return;
    const v = $('ebAttach').value;
    if (!v) { box.hidden = true; box.textContent = ''; return; }
    const parent = EVENTS.find((e) => e.key === v);
    box.hidden = false;
    box.innerHTML = 'ця подія зникне зі списку внесення — вноситься у формі «'
        + escapeHtml(parent ? parent.name : v) + '»';
}

/* ═══════════ КРОКИ ═══════════ */
function setStep(n) {
    step = n;
    lsSet(LS_STEP, n);
    document.querySelectorAll('#ebSteps .hp-tab').forEach((b) =>
        b.classList.toggle('is-active', +b.dataset.step === n));
    $('ebS1').hidden = n !== 1;
    $('ebS2').hidden = n !== 2;
    $('ebS3').hidden = n !== 3;
    $('ebNote').textContent = { 1: 'Крок 1 з 3 — хто може вносити подію',
        2: 'Крок 2 з 3 — поля, що зʼявляться у формі',
        3: 'Крок 3 з 3 — перевірка перед збереженням' }[n];
    $('ebNext').textContent = n === 3 ? 'Готово' : 'Далі';
    $('ebPrev').disabled = n === 1;
    if (n === 1) renderUsers();
    if (n === 2) { renderFields(); renderAllowRc(); renderDetailKeys(); }
    if (n === 3) renderReview();
}

/* --- крок 1: доступ --- */
function renderUsers() {
    $('ebEvName').textContent = cur ? cur.name : '';
    const box = $('ebUsers');
    if (!USERS.length) { box.innerHTML = '<div class="hp-empty">Користувачів немає</div>'; return; }
    box.innerHTML = USERS.map((u) => `<div class="hp-user${ACCESS.includes(u.id) ? ' on' : ''}" data-uid="${u.id}">
        <span class="ini">${escapeHtml(u.ini)}</span>
        <span><span class="nm">${escapeHtml(u.name)}</span><br><span class="rl">${escapeHtml(u.role)}</span></span>
    </div>`).join('');
    box.querySelectorAll('.hp-user').forEach((el) => el.addEventListener('click', () => {
        const id = +el.dataset.uid;
        ACCESS = ACCESS.includes(id) ? ACCESS.filter((x) => x !== id) : ACCESS.concat([id]);
        markDirty(); renderUsers();
    }));
    $('ebAllUsers').textContent = ACCESS.length === USERS.length ? 'Зняти всіх' : 'Обрати всіх';
}

/* --- крок 2: поля --- */
/* Редактор дії просто в рядку таблиці — те, що раніше жило у вікні «Розширено»:
   режим автоматичної дії, її значення і правила «Якщо». */
// Підпис у колонці «Що робить»: що саме підставиться оператору.
function defLabel(e, p) {
    const raw = String(e.arg || '').trim();
    if (!raw) return 'без значення за замовчуванням';
    const hit = ((p && p.choices) || []).find((c) => String(c.value) === raw);
    return 'за замовчуванням: ' + (hit ? hit.label : raw);
}

// Значення за замовчуванням вводиться ТИМ САМИМ контролом, що й у формі:
// список — випадайкою, число — з межами параметра, дата — календарем.
function defControlHtml(p, val) {
    const ch = (p && p.choices) || [];
    const v = val || '';
    if (ch.length) {
        return '<select class="ref-select eb-def"><option value="">— оператор обере сам —</option>'
            + lostOptionHtml(p, v)
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"`
                + `${String(c.value) === String(v) ? ' selected' : ''}>`
                + `${escapeHtml(c.label)}</option>`).join('') + '</select>';
    }
    const dt = (p && p.dtype) || 'text';
    if (dt === 'date')
        return `<input type="date" class="ref-select eb-def" value="${escapeHtml(v)}">`;
    if (['int', 'float', 'number'].includes(dt)) {
        const at = [];
        if (p && p.vmin) at.push(`min="${escapeHtml(p.vmin)}"`);
        if (p && p.vmax) at.push(`max="${escapeHtml(p.vmax)}"`);
        at.push(`step="${escapeHtml((p && p.vstep) || (dt === 'float' ? '0.01' : '1'))}"`);
        return `<input type="number" class="ref-select eb-def" ${at.join(' ')}`
            + ` value="${escapeHtml(v)}" placeholder="порожньо — вводить оператор">`;
    }
    return `<input type="text" class="ref-select eb-def" value="${escapeHtml(v)}"`
        + ' placeholder="порожньо — оператор вводить сам">';
}

function detEditorHtml(e, p, ask) {
    const desc = escapeHtml((p && p.desc) || 'параметр із довідника «Параметри тварин»');
    if (ask) {
        return `<div class="row">
            <span class="k">Значення за замовчуванням</span>
            ${defControlHtml(p, e.arg)}
            <span class="k">${desc}</span></div>`;
    }
    const mode = e.mode || 'const';
    const argHtml = mode === 'when'
        ? whenBlockHtml(p, e.arg)
        : (ARG_MODES.has(mode) ? argControlHtml(p, e.arg) : '');
    return `<div class="row eb-act${mode === 'when' ? ' has-when' : ''}">
        <span class="k">Дія</span>
        <select class="ref-select eb-mode">${autoModeOptions(mode)}</select>
        <span class="eb-argwrap">${argHtml}</span>
        <span class="k">${desc}</span></div>`
        + condRowHtml(e);
}
/* Умова дії: «тільки якщо Днів тільності > 200» — дія виконується не завжди
   (пізній аборт записує дату отелу, ранній — ні). Порожній параметр = завжди. */
function parseCond(raw) {
    let c = {};
    try { if (raw && String(raw).trim().startsWith('{')) c = JSON.parse(raw); } catch (e) { c = {}; }
    return { if: (c && c.if) || '', op: (c && c.op) || 'eq', eq: (c && c.eq) || '' };
}
function condRowHtml(e) {
    const c = parseCond(e.cond);
    const ifParam = paramByKey(c.if);
    return `<div class="row eb-cond">
        <span class="k">Тільки якщо</span>
        ${paramSelectHtml(c.if, 'ec-if', true)}
        ${opSelectHtml(c.op, ifParam, 'ec-opsel')}
        ${valControlHtml(ifParam, c.eq, 'ec-val')}
        <span class="k">${c.if ? 'інакше дія пропускається' : 'без умови дія виконується завжди'}</span></div>`;
}
function readCond(scope) {
    const k = (scope.querySelector('.ec-if') || {}).value || '';
    if (!k) return '';
    return JSON.stringify({ if: k, op: (scope.querySelector('.ec-opsel') || {}).value || 'eq',
        eq: (scope.querySelector('.ec-val') || {}).value || '' });
}

/* Живий макет форми внесення: показує ФАКТ — що саме побачить оператор
   із поточних налаштувань (поля, порядок, обовʼязкові, приховані, приплід). */
// Той самий контрол, що й у формі внесення, лише заблокований: макет має
// збігатися з тим, що побачить оператор, а не бути схематичним натяком.
function previewControl(e, p) {
    const ch = (p && p.choices) || [];
    const dt = (p && p.dtype) || 'text';
    if (ch.length) {
        const isCod = dt === 'cod' || dt === 'code';
        const isNum = ['int', 'float', 'number'].includes(dt);   // градація — без номерів
        const isRef = dt === 'ref';
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) =>
            `<option${String(c.value) === String(e.arg || '') ? ' selected' : ''}>`
            + escapeHtml((isRef && !c.label.includes(' — ')) ? `${i + 1} — ${c.label}`
                : ((isCod || isNum || isRef) ? c.label : `${i + 1}. ${c.label}`)) + '</option>').join('');
        return `<select class="hp-in" disabled>${opts}</select>`;
    }
    if (dt === 'ref_animal')
        return '<select class="hp-in" disabled><option>— оберіть тварину —</option></select>';
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float' || dt === 'number') ? 'number' : 'text');
    return `<input type="${type}" class="hp-in" disabled`
        + ` value="${escapeHtml(e.arg || '')}" placeholder="значення">`;
}

/* Схема розкладки форми внесення — одна на ферму, задається тут. */
let FACTS = {};                  // службові факти події (приплід, мертві)
let PREV_LAY = null;
const DEF_LAY = { zones: { left: ['form'], right: ['history'], wide: ['feed'] },
                  hidden: [], split: null };
const PANEL_TITLE = { form: 'Поля події', history: 'Історія тварини',
                      feed: 'Останні події' };

async function loadPrevLayout() {
    try {
        const r = await apiGet('/api/herd/ui-layout');
        PREV_LAY = (r && r.ok && r.layout) ? r.layout : JSON.parse(JSON.stringify(DEF_LAY));
    } catch (_) { PREV_LAY = JSON.parse(JSON.stringify(DEF_LAY)); }
    renderPreview();
}

let prevSaveT = null;
function savePrevLayout() {
    clearTimeout(prevSaveT);
    prevSaveT = setTimeout(async () => {
        const r = await apiSend('/api/herd/ui-layout', 'POST', { layout: PREV_LAY });
        if (!r || !r.ok) toast((r && r.error) || 'Вигляд не збережено', 'error');
    }, 400);
}

const KNOWN_PANELS = new Set(['form', 'history', 'feed']);
function dropUnknownPanels() {
    if (!PREV_LAY || !PREV_LAY.zones) return false;
    let changed = false;
    ['left', 'right', 'wide'].forEach((n) => {
        const was = PREV_LAY.zones[n] || [];
        const now = was.filter((k) => KNOWN_PANELS.has(k));
        if (now.length !== was.length) { PREV_LAY.zones[n] = now; changed = true; }
    });
    if (PREV_LAY.width) {
        Object.keys(PREV_LAY.width).forEach((k) => {
            if (!KNOWN_PANELS.has(k)) { delete PREV_LAY.width[k]; changed = true; }
        });
    }
    return changed;
}

// Комірка рядка приплоду: ширину задають так само, як у полів форми.
// Вбудовані поля мають службові ключі (__uin, __tag…), бо параметра не мають.
function calfCell(key, title, inner) {
    const w = (PREV_LAY && PREV_LAY.fields && PREV_LAY.fields[key]) || 0;
    return `<span class="cf-x pv-field" data-field="${escapeHtml(key)}"
                title="${escapeHtml(title)}"${w ? ` style="flex:0 0 calc(${w}% - 6px)"` : ''}>`
        + '<span class="pv-fgrip" title="Потягніть — ширина поля"></span>'
        + inner + '</span>';
}

// Пʼять вбудованих полів рядка теляти. Параметра за ними немає, тож ширину
// памʼятаємо під службовими ключами (__alive, __uin…).
function calfBase() {
    return calfCell('__alive', 'Живе чи мертвонароджене',
               '<select class="hp-in" disabled><option>🐮 Живе</option></select>')
        + calfCell('__uin', herdLabel('uin', 'Ідентифікаційний номер'),
               `<input class="hp-in" disabled value="UA" placeholder="${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))}">`)
        + calfCell('__tag', herdLabel('tag', 'Номер тварини'),
               `<input class="hp-in" disabled placeholder="${escapeHtml(herdLabel('tag', 'Номер тварини'))}">`)
        + calfCell('__sex', herdLabel('sex', 'Стать'),
               `<select class="hp-in" disabled><option>— ${escapeHtml(herdLabel('sex', 'Стать'))} —</option></select>`)
        + calfCell('__name', herdLabel('name', 'Кличка'),
               `<input class="hp-in" disabled placeholder="${escapeHtml(herdLabel('name', 'Кличка'))}">`);
}

function renderPreview() {
    const box = $('ebPreview');
    if (!box || !cur) return;
    const wrap = document.querySelector('.eb-prev-wrap');
    if (wrap && wrap.dataset.open === '0') return;   // згорнутий — не малюємо
    if (!PREV_LAY) { loadPrevLayout(); return; }
    if (dropUnknownPanels()) savePrevLayout();
    const asks = WORK.filter((e) => isInput(e) && isOn(e));
    const autos = WORK.filter((e) => !isInput(e) && isOn(e));
    // приплід: сама подія або прив'язана до неї реєструє новонароджених
    const birthEv = cur.births ? cur
        : EVENTS.find((x) => (x.attach_to || '') === cur.key && x.births);
    const births = !!birthEv;
    // поля рядка теляти беруться з події народження (базові — вбудовані)
    const CALF_BASE = new Set(['sex', 'name', 'tag', 'uin']);
    const calfExtra = births
        ? (birthEv.effects || []).filter((e) => e.mode === 'input'
            && (!('enabled' in e) || e.enabled) && !CALF_BASE.has(e.param_key))
        : [];

    let pvNo = 1;                        // «Тварина» завжди перша
    const FW = PREV_LAY.fields || {};    // ширина окремих полів у формі, %
    const field = (e) => {
        const p = paramByKey(e.param_key);
        const w = FW[e.param_key] || 50;
        // ⚠️ Тягнемо за РУЧКУ, а не за саме поле: <label> з полем усередині
        // браузер за перетягування не бере (клік іде контролу), тож
        // draggable на ньому виглядав робочим, але нічого не робив.
        return `<label class="hp-fl pv-field" data-field="${escapeHtml(e.param_key)}"
            style="flex:0 0 calc(${w}% - 6px)">
            <span class="pv-fdrag" title="Потягніть — порядок питань у формі">⠿</span>
            <span class="pv-fgrip" title="Потягніть — ширина поля.&#10;Подвійний клік — на всю ширину · половина · третина · чверть"></span>
            <span class="pv-fw">${Math.round(w)}%</span>
            <span class="pv-no">${++pvNo}</span>
            <span>${escapeHtml(p ? p.label : e.param_key)}`
            + `${(p && p.unit) ? ', ' + escapeHtml(p.unit) : ''}`
            + `${e.required ? '<b class="hp-req"> *</b>' : ''}</span>
            ${previewControl(e, p)}</label>`;
    };

    // вміст кожної панелі так, як його побачить оператор
    const body = {
        form: '<div class="hp-sech"><h3>Швидке додавання</h3></div>'
            // поле «Тварина» — теж частина сітки: ширину йому задають так
            // само (порядок не міняється — воно завжди перше)
            + `<div class="pv-grid hp-fields"><label class="hp-fl pv-field pv-fixed"
                 data-field="__animal" style="flex:0 0 calc(${FW.__animal || 100}% - 6px)">
                 <span class="pv-fgrip" title="Потягніть — ширина поля.&#10;Подвійний клік — на всю ширину · половина · третина · чверть"></span>
                 <span class="pv-fw">${Math.round(FW.__animal || 100)}%</span>
                 <span class="pv-no">1</span><span>Тварина * (${escapeHtml([herdLabel('tag', '№'), herdLabel('name', 'кличка')].join(', '))})</span>
                 <input type="text" class="hp-in" disabled placeholder="почніть вводити номер…">
               </label></div>`
            + (asks.length ? `<div class="pv-grid hp-fields">${asks.map(field).join('')}</div>`
                : '<div class="pv-none">оператор нічого не вводить — подія лише '
                  + 'проставляє значення сама (нижче)</div>')
            + (births ? `<div class="hp-birth">
                 <div class="hp-sech"><h3>🐣 Приплід (нові тварини)</h3>
                   <span class="hp-note">поля рядка — з події «${escapeHtml(birthEv ? birthEv.name : 'Народження')}»</span></div>
                 <div class="lg-calf">`
                 + calfBase()
                 + calfExtra.map((e) => {
                       const p = paramByKey(e.param_key);
                       const lbl = (p ? p.label : e.param_key) + (p && p.unit ? ', ' + p.unit : '');
                       // ⚠️ У рядку приплоду підписів над полями немає, тож
                       // назва мусить бути В САМОМУ полі — саме так робить
                       // справжня форма. Без цього макет показував «значення»
                       // і обіцяв не те, що побачить оператор.
                       const ctl = previewControl(e, p)
                           .replace('placeholder="значення"', `placeholder="${escapeHtml(lbl)}"`)
                           .replace('<option value="">— (за замовч.)</option>',
                                    `<option>— ${escapeHtml(p ? p.label : e.param_key)} —</option>`);
                       return calfCell(e.param_key, lbl, ctl);
                   }).join('')
                 + `</div></div>` : '')
            + `<label class="hp-fl" style="margin-top:12px"><span>Нотатка</span>
                 <input type="text" class="hp-in hp-wide" disabled placeholder="коментар…"></label>`
            + `<div class="pv-foot"><span class="hp-sp"></span>
                 <span class="pv-btn">Зберегти подію</span></div>`,
        history: '<div class="hp-sech"><h3>Історія тварини</h3></div>'
            + '<div class="hp-empty">останні події обраної тварини</div>',
        feed: '<div class="hp-sech"><h3>Останні події</h3></div>'
            + '<div class="hp-empty">стрічка внесених подій із пошуком</div>',
    };
    const hid = new Set(PREV_LAY.hidden || []);
    const W = PREV_LAY.width || {};          // ширина панелі в межах зони, %
    const panel = (k) => `<div class="pv-panel${hid.has(k) ? ' is-hidden' : ''}"
            data-panel="${k}" draggable="true"
            style="flex:${(W[k] || 100) >= 100 ? '1 1 100%' : '0 0 ' + W[k] + '%'}">
            <div class="pv-wgrip" title="Потягніть — ширина; подвійний клік — на весь ряд"></div>
            <div class="pv-pbar"><span class="pv-grip">⠿</span>
                <span class="pv-pname">${PANEL_TITLE[k] || k}</span>
                <button type="button" class="pv-phide" title="${hid.has(k) ? 'Повернути' : 'Сховати від оператора'}">${hid.has(k) ? '👁' : '✕'}</button>
            </div>${body[k] || ''}</div>`;
    const known = (k) => Object.prototype.hasOwnProperty.call(body, k);
    const zn = (n) => `<div class="pv-zone" data-zone="${n}">`
        + ((PREV_LAY.zones && PREV_LAY.zones[n]) || []).filter(known).map(panel).join('')
        + '</div>';

    // подія-частина: у формі вона не окрема, а рядок приплоду в батьківській
    const parent = cur.attach_to
        ? EVENTS.find((x) => x.key === cur.attach_to) : null;
    if (parent) {
        const own = (WORK || []).filter((e) => isInput(e) && isOn(e)
            && !['sex', 'name', 'tag', 'uin'].includes(e.param_key));
        box.innerHTML = `
          <div class="pv-form">
            <div class="pv-head">
                <span class="pv-title">${escapeHtml(parent.name)}</span>
                <span class="pv-date">ця подія вноситься тут — рядком приплоду</span>
            </div>
            <div class="hp-birth">
              <div class="hp-sech"><h3>🐣 ${escapeHtml(cur.name)} (нові тварини)</h3></div>
              <div class="lg-calf">`
              + calfBase()
              + own.map((e) => {
                    const p = paramByKey(e.param_key);
                    const lbl = (p ? p.label : e.param_key) + (p && p.unit ? ', ' + p.unit : '');
                    return calfCell(e.param_key, lbl, previewControl(e, p));
                }).join('')
              + `</div>
            </div>
          </div>
          <p class="hp-hint pv-hint" data-ins="2.4">Перші пʼять полів вбудовані — без них тварину
             не завести. Решта береться з кроку «Поля» цієї події: додайте параметр
             (вага при народженні, оцінка) — і він зʼявиться в рядку теляти.
             Ширину будь-якого поля задають, потягнувши його правий край.</p>`;
        bindFieldGrips(box);
        bindFieldDrag(box);
        bindFieldCtx(box);
        return;
    }

    box.innerHTML = `
      <div class="pv-form">
        <div class="pv-head">
            <span class="pv-title">${escapeHtml(cur.name || 'Подія')}</span>
            <span class="pv-date">дата: сьогодні</span>
        </div>
        <div class="pv-layout" style="grid-template-columns:${PREV_LAY.split || 63}fr 0 ${100 - (PREV_LAY.split || 63)}fr">
            ${zn('left')}<div class="pv-split" id="pvSplit" title="Перетягніть — ширина колонок у оператора"></div>${zn('right')}${zn('wide')}
        </div>
      </div>
      <p class="hp-hint pv-hint" data-ins="2.3">Перетягніть панелі, щоб задати вигляд форми для
         операторів; тягніть край — ширина, <b>подвійний клік по краю</b> — на весь
         ряд (тоді сусідня панель стає під нею); <b>✕</b> ховає панель.
         Схема одна на ферму і зберігається сама.
         <button type="button" class="hp-link" id="pvReset">Повернути типовий вигляд</button></p>`;
    bindPreviewDnd();
}

function bindPreviewDnd() {
    const box = $('ebPreview');
    const reset = box.querySelector('#pvReset');
    if (reset) reset.addEventListener('click', async () => {
        if (!(await confirmAction('Повернути типовий вигляд форми для всіх операторів?', { ok: 'Повернути', okClass: 'btn-primary' }))) return;
        PREV_LAY = JSON.parse(JSON.stringify(DEF_LAY));
        savePrevLayout(); renderPreview();
        toast('Вигляд форми повернуто до типового', 'success');
    });
    let dragKey = '';
    box.querySelectorAll('.pv-panel').forEach((p) => {
        p.addEventListener('dragstart', () => { dragKey = p.dataset.panel; p.classList.add('is-drag'); });
        p.addEventListener('dragend', () => {
            p.classList.remove('is-drag');
            box.querySelectorAll('.pv-zone').forEach((z) => z.classList.remove('drop'));
            dragKey = '';
        });
    });
    box.querySelectorAll('.pv-zone').forEach((z) => {
        z.addEventListener('dragover', (e) => {
            if (!dragKey) return;
            e.preventDefault();
            box.querySelectorAll('.pv-zone').forEach((x) => x.classList.toggle('drop', x === z));
        });
        z.addEventListener('drop', (e) => {
            if (!dragKey) return;
            e.preventDefault();
            const to = z.dataset.zone;
            const over = e.target.closest('.pv-panel');
            // прибрати з попередньої зони і покласти в нову
            ['left', 'right', 'wide'].forEach((n) => {
                PREV_LAY.zones[n] = (PREV_LAY.zones[n] || []).filter((k) => k !== dragKey);
            });
            const arr = PREV_LAY.zones[to] || (PREV_LAY.zones[to] = []);
            const at = over ? arr.indexOf(over.dataset.panel) : -1;
            if (at >= 0) arr.splice(at, 0, dragKey); else arr.push(dragKey);
            savePrevLayout(); renderPreview();
        });
    });
    // ширина панелі — тягнемо її правий край у межах колонки
    box.querySelectorAll('.pv-wgrip').forEach((g) => g.addEventListener('dblclick', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        const k = g.closest('.pv-panel').dataset.panel;
        const w = Object.assign({}, PREV_LAY.width);
        delete w[k];                       // без своєї ширини = на весь ряд
        PREV_LAY.width = w;
        savePrevLayout(); renderPreview();
        toast('Панель на весь ряд — сусідня стане під нею', 'success');
    }));
    box.querySelectorAll('.pv-wgrip').forEach((g) => g.addEventListener('mousedown', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        const panelEl = g.closest('.pv-panel');
        const zoneEl = panelEl.parentElement;
        panelEl.draggable = false;                  // щоб не почалося перетягування панелі
        g.classList.add('dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        // Межі беремо ОДИН раз: під час звуження сусідня панель стає поруч
        // і зсуває нашу — тоді перерахована left смикала б ширину.
        const zoneW = zoneEl.getBoundingClientRect().width || 1;
        const pLeft = panelEl.getBoundingClientRect().left;
        const minPct = Math.max(20, (260 / zoneW) * 100);   // вужче панель нечитабельна
        const onMove = (m) => {
            let pct = ((m.clientX - pLeft) / zoneW) * 100;
            pct = Math.max(minPct, Math.min(100, pct));
            panelEl.style.flex = (pct >= 100) ? '1 1 100%' : `0 0 ${pct}%`;
            panelEl.dataset.pct = pct.toFixed(1);
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            g.classList.remove('dragging');
            panelEl.draggable = true;
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            if (panelEl.dataset.pct) {
                PREV_LAY.width = Object.assign({}, PREV_LAY.width,
                    { [panelEl.dataset.panel]: +panelEl.dataset.pct });
                savePrevLayout();
            }
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }));
    // межа колонок: ширина, яку побачать оператори
    const sp = box.querySelector('#pvSplit');
    if (sp) sp.addEventListener('mousedown', (ev) => {
        ev.preventDefault();
        const lay = box.querySelector('.pv-layout');
        sp.classList.add('dragging');
        document.body.style.userSelect = 'none';
        const onMove = (m) => {
            const r = lay.getBoundingClientRect();
            const pct = Math.max(25, Math.min(78, ((m.clientX - r.left) / r.width) * 100));
            lay.style.gridTemplateColumns = `${pct}fr 0 ${100 - pct}fr`;
            lay.dataset.pct = pct.toFixed(1);
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            sp.classList.remove('dragging');
            document.body.style.userSelect = '';
            if (lay.dataset.pct) { PREV_LAY.split = parseFloat(lay.dataset.pct); savePrevLayout(); }
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });
    bindFieldGrips(box);
    bindFieldDrag(box);
    bindFieldCtx(box);
    box.querySelectorAll('.pv-phide').forEach((b) => b.addEventListener('click', (e) => {
        e.stopPropagation();
        const k = b.closest('.pv-panel').dataset.panel;
        const hid = new Set(PREV_LAY.hidden || []);
        hid.has(k) ? hid.delete(k) : hid.add(k);
        PREV_LAY.hidden = [...hid];
        savePrevLayout(); renderPreview();
    }));
}

// Праву кнопку на полі макета — те саме меню, що й у таблиці.
function bindFieldCtx(box) {
    box.querySelectorAll('[data-field]').forEach((f) => {
        const key = f.dataset.field;
        if (!key || key.startsWith('__')) return;    // вбудовані поля теляти
        f.addEventListener('contextmenu', (ev) => { ev.stopPropagation(); openCtx(ev, key); });
    });
}

/* Сітка форми просто в макеті (Роман 2026-09-16: «може сітку зробити, щоб
   розміщати поля для питань?»). Порядок міняється перетягуванням поля, а
   ширина — ручкою або подвійним кліком по ній: на всю ширину · половина ·
   третина · чверть. Порядок ТОЙ САМИЙ, що в таблиці кроку «Поля» — обидва
   місця рухають один масив, тож розходитись їм нічим. */
const GRID_STEPS = [100, 50, 33, 25];

function bindFieldDrag(box) {
    /* ⚠️ НЕ HTML5-drag: у макеті поле — це <label> з контролом усередині,
       і браузер перетягування не починав. Курсор обіцяв, що поле рухається,
       а воно стояло (Роман 2026-09-16: «бачу що можна перетягнути, але не
       перетягується»). Тягнемо мишею — так само, як ручку ширини. */
    box.querySelectorAll('.pv-field .pv-fdrag').forEach((h) => {
        h.addEventListener('mousedown', (ev) => {
            ev.preventDefault(); ev.stopPropagation();
            const f = h.closest('.pv-field');
            const key = f && f.dataset.field;
            if (!key || key.startsWith('__')) return;
            const panelEl = f.closest('.pv-panel');
            if (panelEl) panelEl.draggable = false;
            f.classList.add('is-drag');
            document.body.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            let over = null;
            const mark = (el) => {
                if (over && over !== el) over.classList.remove('drag-over');
                over = el;
                if (over) over.classList.add('drag-over');
            };
            const onMove = (m) => {
                const el = document.elementFromPoint(m.clientX, m.clientY);
                const tgt = el && el.closest('.pv-field');
                mark((tgt && tgt !== f && !(tgt.dataset.field || '').startsWith('__'))
                     ? tgt : null);
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                f.classList.remove('is-drag');
                if (panelEl) panelEl.draggable = true;
                document.body.style.cursor = '';
                document.body.style.userSelect = '';
                const dst = over;
                mark(null);
                if (!dst) return;
                const from = WORK.findIndex((x) => x.param_key === key);
                const to = WORK.findIndex((x) => x.param_key === dst.dataset.field);
                if (from < 0 || to < 0 || from === to) return;
                WORK.splice(to, 0, WORK.splice(from, 1)[0]);
                markDirty(); renderFields(); renderPreview();
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    });
}

function bindFieldGrips(box) {
    // подвійний клік по ручці — ходить простими частками ряду
    box.querySelectorAll('.pv-fgrip').forEach((g) => g.addEventListener('dblclick', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        const f = g.closest('.pv-field');
        if (!f) return;
        const cur = Math.round(+(f.dataset.pct || (PREV_LAY.fields || {})[f.dataset.field] || 100));
        const i = GRID_STEPS.findIndex((v) => Math.abs(v - cur) <= 3);
        const next = GRID_STEPS[(i < 0 ? 0 : i + 1) % GRID_STEPS.length];
        f.style.flex = `0 0 calc(${next}% - 6px)`;
        f.dataset.pct = String(next);
        const lbl = f.querySelector('.pv-fw');
        if (lbl) lbl.textContent = next + '%';
        PREV_LAY.fields = Object.assign({}, PREV_LAY.fields, { [f.dataset.field]: next });
        savePrevLayout();
    }));
    // ширина окремого поля у формі
    box.querySelectorAll('.pv-fgrip').forEach((g) => g.addEventListener('mousedown', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        const f = g.closest('.pv-field');
        const row = f.parentElement;                 // .pv-grid
        const panelEl = f.closest('.pv-panel');
        if (panelEl) panelEl.draggable = false;
        g.classList.add('dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        // Ліву межу й ширину ряду беремо ОДИН раз, на початку перетягування.
        // Інакше при звуженні комірка переносилась на інший ряд, її left
        // стрибав — і ширина смикалась замість того, щоб слухатись миші.
        const rowW = row.getBoundingClientRect().width || 1;
        const left = f.getBoundingClientRect().left;
        const minPct = Math.max(6, (96 / rowW) * 100);   // не вужче за поле вводу
        const onMove = (m) => {
            let pct = ((m.clientX - left) / rowW) * 100;
            pct = Math.max(minPct, Math.min(100, pct));
            f.style.flex = `0 0 calc(${pct}% - 6px)`;
            f.dataset.pct = pct.toFixed(1);
            const lbl = f.querySelector('.pv-fw');
            if (lbl) lbl.textContent = Math.round(pct) + '%';
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            g.classList.remove('dragging');
            if (panelEl) panelEl.draggable = true;
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            if (f.dataset.pct) {
                PREV_LAY.fields = Object.assign({}, PREV_LAY.fields,
                    { [f.dataset.field]: +f.dataset.pct });
                savePrevLayout();
            }
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }));
}

/* ═══ контекстне меню параметра (права кнопка) ═══
   Одне меню і для таблиці «Поля», і для макета: порядок переходу, обовʼязковість,
   показ у формі, значення за замовчуванням, видалення. */
function askList() {
    // поля, які вводить оператор, у порядку переходу (без вимкнених)
    return WORK.filter((e) => isInput(e) && isOn(e));
}

function setAskOrder(e, want) {
    const asks = askList();
    const cur = asks.indexOf(e);
    if (cur < 0) return;
    // №1 — поле «Тварина», тож перше поле події має номер 2
    let pos = Math.round(want) - 2;
    pos = Math.max(0, Math.min(asks.length - 1, pos));
    if (pos === cur) return;
    // ставимо перед тим полем, що зараз на потрібній позиції
    const before = asks[pos < cur ? pos : pos + 1] || null;
    const from = WORK.indexOf(e);
    WORK.splice(from, 1);
    const to = before ? WORK.indexOf(before) : WORK.length;
    WORK.splice(to < 0 ? WORK.length : to, 0, e);
    markDirty(); renderFields(); renderPreview();
}

function closeCtx() {
    const old = document.getElementById('ebCtx');
    if (old) old.remove();
}

function openCtx(ev, key) {
    ev.preventDefault();
    closeCtx();
    // не плутати з window.find(): шукаємо ефект у робочому наборі події
    const e = WORK.find((x) => x.param_key === key);
    if (!e) return;
    const p = paramByKey(key);
    const ask = isInput(e);
    const asks = askList();
    const no = ask && isOn(e) ? asks.indexOf(e) + 2 : 0;
    const box = document.createElement('div');
    box.id = 'ebCtx';
    box.className = 'eb-ctx';
    box.innerHTML = `
        <div class="eb-ctx-h">${escapeHtml(p ? p.label : key)}</div>`
        + (no ? `<label class="eb-ctx-row">
                <span>Порядок переходу</span>
                <input type="number" id="ebCtxNo" min="2" max="${asks.length + 1}" value="${no}">
             </label>
             <div class="eb-ctx-hint">№1 — поле «Тварина»; далі Enter/Tab ведуть за цими номерами</div>
             <button type="button" class="eb-ctx-i" data-act="up">↑ Раніше</button>
             <button type="button" class="eb-ctx-i" data-act="down">↓ Пізніше</button>
             <div class="eb-ctx-sep"></div>` : '')
        + (ask ? `<button type="button" class="eb-ctx-i" data-act="req">`
                 + `${e.required ? '✓ ' : ''}Обовʼязкове</button>` : '')
        + `<button type="button" class="eb-ctx-i" data-act="who">`
        + `${ask ? 'Хай ставить програма' : 'Хай вводить оператор'}</button>`
        + `<button type="button" class="eb-ctx-i" data-act="def">Значення за замовчуванням…</button>`
        + `<button type="button" class="eb-ctx-i" data-act="off">`
        + `${isOn(e) ? 'Вимкнути (не показувати)' : 'Увімкнути'}</button>`
        + '<div class="eb-ctx-sep"></div>'
        + '<button type="button" class="eb-ctx-i danger" data-act="del">Прибрати з події</button>';
    document.body.appendChild(box);
    // тримаємо меню у вікні
    const w = box.offsetWidth, h = box.offsetHeight;
    box.style.left = Math.min(ev.clientX, innerWidth - w - 8) + 'px';
    box.style.top = Math.min(ev.clientY, innerHeight - h - 8) + 'px';

    const noInp = box.querySelector('#ebCtxNo');
    if (noInp) {
        noInp.focus(); noInp.select();
        noInp.addEventListener('change', () => {
            setAskOrder(e, +noInp.value || no); closeCtx();
        });
        noInp.addEventListener('keydown', (k) => {
            if (k.key === 'Enter') { k.preventDefault(); setAskOrder(e, +noInp.value || no); closeCtx(); }
        });
    }
    box.querySelectorAll('.eb-ctx-i').forEach((b) => b.addEventListener('click', () => {
        const act = b.dataset.act;
        if (act === 'up') setAskOrder(e, no - 1);
        else if (act === 'down') setAskOrder(e, no + 1);
        else if (act === 'req') { e.required = e.required ? 0 : 1; markDirty(); renderFields(); renderPreview(); }
        else if (act === 'who') {
            if (isInput(e)) { e.mode = 'const'; e.arg = ''; }
            else { e.mode = 'input'; e.quick = 1; if (e.required === undefined) e.required = 0; }
            markDirty(); renderFields(); renderPreview();
        } else if (act === 'def') { openRow = key; renderFields(); }
        else if (act === 'off') { e.enabled = isOn(e) ? 0 : 1; markDirty(); renderFields(); renderPreview(); }
        else if (act === 'del') { WORK = WORK.filter((x) => x !== e); markDirty(); renderFields(); renderPreview(); }
        closeCtx();
    }));
}
document.addEventListener('click', (ev) => {
    if (!ev.target.closest('#ebCtx')) closeCtx();
});
if ($('ebAdvBtn')) $('ebAdvBtn').addEventListener('click', () =>
    advEvSet(document.querySelector('.eb-adv').dataset.open !== '1'));
/* макет оператора: стан памʼятається — кому він не потрібен, тримає згорнутим */
const PREV_OPEN_KEY = 'herd:prevOpen';
function prevSet(open) {
    const box = document.querySelector('.eb-prev-wrap');
    if (!box) return;
    box.dataset.open = open ? '1' : '0';
    const b = $('ebPrevBtn');
    if (b) b.setAttribute('aria-expanded', open ? 'true' : 'false');
    lsSet(PREV_OPEN_KEY, open ? '1' : '0');
    if (open) renderPreview();
}
if ($('ebPrevBtn')) {
    $('ebPrevBtn').addEventListener('click', () =>
        prevSet(document.querySelector('.eb-prev-wrap').dataset.open !== '1'));
    prevSet(lsGet(PREV_OPEN_KEY) !== '0');   // типово розгорнутий
}
/* «Коло відтворення» і «Перевірка алгоритму» — так само згортаються */
function foldCard(btnId, key, onOpen) {
    const btn = $(btnId);
    if (!btn) return;
    const card = btn.closest('.hp-card');
    const set = (open) => {
        card.dataset.fold = open ? '1' : '0';
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        lsSet(key, open ? '1' : '0');
        if (open && onOpen) onOpen();
    };
    btn.addEventListener('click', () => set(card.dataset.fold !== '1'));
    set(lsGet(key) !== '0');
}
foldCard('ebCycBtn', 'herd:cycOpen', () => { try { renderCycle(); } catch (e) { /* ignore */ } });
foldCard('ebChkBtn', 'herd:chkOpen');
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') closeCtx(); });

function renderFields() {
    // Показуємо ВСЕ, що подія чіпає: і поля-питання, і автоматичні дії.
    // Інакше в подій на кшталт «Народження» крок «Поля» був порожній, хоч
    // подія робить три дії — і не було де зафіксувати, що з них вносить людина.
    const rows = WORK.slice();
    // Нумерація та сама, що й у формі: №1 — поле «Тварина» (воно перше
    // завжди), далі поля події. Доти таблиця рахувала з 1, а макет із 2 —
    // і номери розходились.
    let askNo = 1;
    const box = $('ebFields');
    box.innerHTML = rows.length ? rows.map((e) => {
        const p = paramByKey(e.param_key);
        const name = p ? p.label : e.param_key;
        const unit = (p && p.unit) ? ', ' + p.unit : '';
        const ask = isInput(e);
        const det = openRow === e.param_key
            ? `<tr class="eb-det" data-det="${escapeHtml(e.param_key)}"><td></td>
                <td colspan="7">${detEditorHtml(e, p, ask)}</td></tr>` : '';
        // поле оператора завжди видно у формі; для автоматичної дії
        // показуємо саме речення дії
        const defLbl = defLabel(e, p);          // що стоїть за замовчуванням
        const placeCell = ask
            ? `<button type="button" class="eb-defbtn" title="Натисніть, щоб задати значення за замовчуванням">`
              + `поле у формі · <b>${escapeHtml(defLbl)}</b></button>`
            : (e.mode === 'show'
                ? `<span class="eb-auto">показує <b>${escapeHtml((p && p.formula) || '—')}</b></span>`
                : `<span class="eb-auto">${sentence(e) || 'автоматична дія'}</span>`);
        // номер = порядок переходу по Enter/Tab у формі (лише поля оператора)
        const no = ask && isOn(e) ? (++askNo) : 0;
        return `<tr data-code="${escapeHtml(e.param_key)}" draggable="true" class="${isOn(e) ? '' : 'is-off'}">
            <td class="eb-drag" title="Перетягніть, щоб змінити порядок переходу">⠿`
            + (no ? `<span class="eb-no" title="Порядок переходу по Enter/Tab — права кнопка миші міняє">${no}</span>` : '')
            + `</td>
            <td><button type="button" class="eb-col" data-code="${escapeHtml(e.param_key)}"
                    title="Колір картки поля у формі"
                    style="${colorDotStyle(p)}"></button><span class="nm">${escapeHtml(name + unit)}</span>
                <span class="sub">${escapeHtml(e.param_key)}${p && p.section ? ' · ' + escapeHtml(p.section) : ''}</span></td>
            <td><span class="hp-type">${escapeHtml(typeLabel(p))}</span></td>
            <td><button type="button" class="hp-who${ask ? ' ask' : ''}${e.mode === 'show' ? ' show' : ''}"
                    title="${e.mode === 'show'
                        ? 'Рахується формулою і лише показується у формі — змінити не можна'
                        : (ask ? 'Оператор вводить це у формі' : 'Програма ставить сама, без питання')}"
                >${e.mode === 'show' ? 'Довідка' : (ask ? 'Оператор' : 'Автоматично')}</button></td>
            <td>${placeCell}</td>
            <td class="c"><input type="checkbox" class="eb-req"${e.required ? ' checked' : ''}${ask ? '' : ' disabled'}></td>
            <td class="c"><input type="checkbox" class="eb-on"${isOn(e) ? ' checked' : ''}
                    title="${e.mode === 'show' ? 'Показувати це поле у формі події' : 'Поле діє в події'}"></td>
            <td class="c"><button type="button" class="eb-x" title="Прибрати з події">✕</button></td>
        </tr>${det}`;
    }).join('')
        : '<tr><td colspan="8" class="hp-empty">Подія поки нічого не робить — '
          + 'додайте параметр</td></tr>';
    const asks = WORK.filter(isInput).length;
    $('ebAutoNote').innerHTML = asks
        ? `Оператор вносить <b>${asks}</b> ${asks === 1 ? 'поле' : 'поля/полів'}; `
          + 'решта ставиться сама. Правила «Якщо» — у «Розширено».'
        : 'Оператор нічого не вносить — подія лише ставить значення сама. '
          + 'Щоб запитати щось у людини, перемкніть «Хто вносить» на «Оператор».';
    bindFieldRows();
    renderPreview();
}

/* КОЛІР КАРТКИ просто в таблиці полів (Роман 2026-09-20: «це саме краще
   робити в конструкторі події — одразу бачиш, який колір вибрав і які треба
   для інших»). Колір лишається властивістю ПАРАМЕТРА, тож однаковий скрізь. */
const FC_PALETTE = [['', 'без кольору'], ['blue', 'синій'], ['green', 'зелений'],
    ['violet', 'фіолетовий'], ['amber', 'бурштиновий'], ['teal', 'бірюзовий'],
    ['gray', 'сірий']];
const FC_HEX = { blue: '#2f5fb0', green: '#1aa86b', violet: '#7c3aed',
    amber: '#b45309', teal: '#0e7490', gray: '#5b7083' };
function colorHex(c) {
    const v = String(c || '').trim();
    return /^#[0-9a-f]{6}$/i.test(v) ? v : (FC_HEX[v] || '');
}
function colorDotStyle(p) {
    const hex = colorHex(p && p.color);
    return hex ? `background:${hex};border-color:${hex}` : '';
}
function closeColorBox() {
    const b = document.getElementById('ebColorBox');
    if (b) b.remove();
}
async function setParamColor(code, value) {
    const p = paramByKey(code);
    if (!p || !p.id) return;
    const r = await apiSend('/api/herd/params/' + p.id, 'POST', { color: value });
    if (!r || !r.ok) { toast((r && r.error) || 'Не збережено', 'error'); return; }
    p.color = value;                       // без перезавантаження списку
    renderFields();
    toast('Колір збережено');
}
function openColorBox(btn, code) {
    closeColorBox();
    const p = paramByKey(code);
    const cur = String((p && p.color) || '');
    const box = document.createElement('div');
    box.id = 'ebColorBox';
    box.className = 'eb-colbox';
    box.innerHTML = FC_PALETTE.map(([v, nm]) => {
        const hex = colorHex(v);
        return `<button type="button" class="eb-colopt${v === cur ? ' on' : ''}" data-v="${v}"
            title="${escapeHtml(nm)}"><i style="${hex ? `background:${hex};border-color:${hex}` : ''}"></i>`
            + `<span>${escapeHtml(nm)}</span></button>`;
    }).join('')
        + `<label class="eb-colown" title="свій відтінок"><input type="color"
             value="${colorHex(cur) || '#2f5fb0'}"><span>свій колір…</span></label>`;
    document.body.appendChild(box);
    const r = btn.getBoundingClientRect();
    box.style.top = (window.scrollY + r.bottom + 6) + 'px';
    box.style.left = (window.scrollX + r.left) + 'px';
    box.querySelectorAll('.eb-colopt').forEach((b) => b.addEventListener('click', () => {
        closeColorBox(); setParamColor(code, b.dataset.v);
    }));
    const own = box.querySelector('.eb-colown input');
    own.addEventListener('change', () => { closeColorBox(); setParamColor(code, own.value); });
}
document.addEventListener('click', (ev) => {
    if (!ev.target.closest('#ebColorBox') && !ev.target.closest('.eb-col')) closeColorBox();
});

function bindFieldRows() {
    const box = $('ebFields');
    const find = (code) => WORK.find((x) => x.param_key === code);
    box.querySelectorAll('tr[data-code]').forEach((tr) => {
        const code = tr.dataset.code, e = find(code);
        if (!e) return;
        tr.querySelector('.eb-req').addEventListener('change', (ev) => {
            e.required = ev.target.checked ? 1 : 0; markDirty();
        });
        tr.querySelector('.eb-on').addEventListener('change', (ev) => {
            e.enabled = ev.target.checked ? 1 : 0; markDirty(); renderFields();
        });
        // «Хто вносить»: питання ↔ автоматична дія. Повертаючись до автоматичної,
        // віддаємо той режим, який був (правило «Якщо» не губиться — arg цілий).
        tr.querySelector('.hp-who').addEventListener('click', () => {
            const prm = paramByKey(e.param_key);
            if (prm && (prm.formula || '').trim()) {
                toast('«' + prm.label + '» рахується формулою — його можна лише '
                    + 'показати у формі', 'warn');
                return;
            }
            if (isInput(e)) {
                e.mode = e._auto || 'const';
            } else {
                e._auto = e.mode;
                e.mode = 'input';
                e.quick = 1;            // поділу на приховані більше немає
                if (e.required === undefined) e.required = 0;
            }
            markDirty(); renderFields();
        });
        const colBtn = tr.querySelector('.eb-col');
        if (colBtn) colBtn.addEventListener('click', (ev) => {
            ev.stopPropagation();
            openColorBox(colBtn, code);
        });
        tr.querySelector('.eb-x').addEventListener('click', () => {
            WORK = WORK.filter((x) => x !== e); markDirty(); renderFields();
        });
        tr.addEventListener('contextmenu', (ev) => openCtx(ev, code));
        const toggleRow = () => { openRow = openRow === code ? '' : code; renderFields(); };
        tr.querySelector('.nm').addEventListener('click', toggleRow);
        const defBtn = tr.querySelector('.eb-defbtn');
        if (defBtn) defBtn.addEventListener('click', toggleRow);
        tr.addEventListener('dragstart', () => { dragCode = code; });
        tr.addEventListener('dragover', (ev) => { ev.preventDefault(); tr.classList.add('drag-over'); });
        tr.addEventListener('dragleave', () => tr.classList.remove('drag-over'));
        tr.addEventListener('drop', (ev) => {
            ev.preventDefault(); tr.classList.remove('drag-over');
            if (!dragCode || dragCode === code) return;
            const from = WORK.findIndex((x) => x.param_key === dragCode);
            const to = WORK.findIndex((x) => x.param_key === code);
            if (from < 0 || to < 0) return;
            WORK.splice(to, 0, WORK.splice(from, 1)[0]);
            dragCode = ''; markDirty(); renderFields();
        });
    });
    box.querySelectorAll('.eb-det').forEach((tr) => {
        const e = find(tr.dataset.det); if (!e) return;

        // поле-питання: лише значення за замовчуванням
        const def = tr.querySelector('.eb-def');
        if (def) ['input', 'change'].forEach((ev) => def.addEventListener(ev, () => {
            e.arg = def.value; markDirty(); renderPreview();
            // підпис у рядку таблиці оновлюємо на місці: повний перерендер
            // забрав би фокус просто під час набору
            const btn = document.querySelector(
                `#ebFields tr[data-code="${CSS.escape(e.param_key)}"] .eb-defbtn`);
            if (btn) btn.innerHTML = 'поле у формі · <b>'
                + escapeHtml(defLabel(e, paramByKey(e.param_key))) + '</b>';
        }));

        // умова дії («тільки якщо Днів тільності > 200»)
        const condRow = document.querySelector(
            `#ebFields tr.eb-det[data-det="${CSS.escape(e.param_key)}"] .eb-cond`);
        if (condRow) condRow.addEventListener('change', (ev) => {
            e.cond = readCond(condRow); markDirty();
            // зміна параметра умови міняє набір операторів і список значень
            if (ev.target.classList.contains('ec-if')) renderFields();
        });

        // автоматична дія: режим + значення (або правила «Якщо»)
        const modeSel = tr.querySelector('.eb-mode');
        if (modeSel) modeSel.addEventListener('change', () => {
            e.mode = modeSel.value;
            e.arg = '';              // значення від попереднього режиму не підходить
            markDirty(); renderFields();
        });
        const wrap = tr.querySelector('.eb-argwrap');
        if (!wrap) return;

        // просте значення дії (ставить / лічильник)
        const arg = wrap.querySelector('.ee-arg');
        if (arg) {
            const put = () => { e.arg = arg.value.trim(); markDirty(); };
            arg.addEventListener('input', put);
            arg.addEventListener('change', put);
        }

        // правила «Якщо»: додати рядок, прибрати рядок, змінити умову чи значення
        const readWhen = () => { e.arg = JSON.stringify(readWhenBlock(wrap)); markDirty(); };
        wrap.addEventListener('click', (ev) => {
            if (ev.target.closest('.ee-when-add')) {
                const s = readWhenBlock(wrap);
                s.rules.push({ if: '', eq: '', val: '', op: 'eq' });
                e.arg = JSON.stringify(s); markDirty(); renderFields();
            } else if (ev.target.closest('.ee-line-del')) {
                const line = ev.target.closest('.ee-when-line');
                const idx = [...wrap.querySelectorAll('.ee-when-line[data-role="rule"]')].indexOf(line);
                const s = readWhenBlock(wrap);
                s.rules.splice(idx, 1);
                e.arg = JSON.stringify(s); markDirty(); renderFields();
            }
        });
        wrap.addEventListener('change', (ev) => {
            // зміна параметра умови міняє список його значень — перемальовуємо
            if (ev.target.classList.contains('ee-if')) { readWhen(); renderFields(); }
            else if (ev.target.closest('.ee-when-line')) readWhen();
        });
    });
}

/* --- крок 3: перегляд --- */
function condSentence(e) {
    const c = parseCond(e.cond);
    if (!c.if) return '';
    const OPL = { eq: '=', ne: '≠', gt: '>', ge: '≥', lt: '<', le: '≤' };
    const nm = (paramByKey(c.if) || {}).label || c.if;
    return ` <span class="eb-ifnote">— тільки якщо ${escapeHtml(nm)} `
        + `${OPL[c.op] || '='} ${escapeHtml(codeLabel(c.if, c.eq))}</span>`;
}
function sentence(e) {
    const p = paramByKey(e.param_key);
    if (!p) return null;
    if (e.param_key === 'group' && e.mode === 'const')
        return `переводить у секцію <b>${escapeHtml(e.arg || '—')}</b>`;
    if (e.mode === 'event_date') return `записує дату події → <b>${escapeHtml(p.label)}</b>`;
    if (e.mode === 'const') return `ставить <b>${escapeHtml(p.label)}</b> = ${escapeHtml(codeLabel(e.param_key, e.arg))}`;
    if (e.mode === 'inc') return `<b>${escapeHtml(p.label)}</b> ${+e.arg >= 0 ? '+' : ''}${escapeHtml(e.arg)}`;
    if (e.mode === 'clear') return `очищає <b>${escapeHtml(p.label)}</b>`;
    if (e.mode === 'when') {
        const s = parseWhenSpec(e.arg);
        const OPL = { eq: '=', ne: '≠', gt: '>', ge: '≥', lt: '<', le: '≤' };
        const parts = s.rules.filter((r) => r.if).map((r) => {
            const a = codeLabel(r.if, r.eq), b = codeLabel(e.param_key, r.val);
            const op = r.op && r.op !== 'eq' ? r.op : '';
            // порівняння читається реченням: «Днів тільності > 200 → Новотільна»
            if (op) {
                const nm = (paramByKey(r.if) || {}).label || r.if;
                return `${nm} ${OPL[op] || ''} ${a} → ${b}`;
            }
            return a === b ? a : `${a} → ${b}`;
        });
        if (s.default) parts.push(`інакше → ${codeLabel(e.param_key, s.default)}`);
        return `<b>${escapeHtml(p.label)}</b> — за відповіддю: ${escapeHtml(parts.join(' · '))}`;
    }
    return null;
}

function renderReview() {
    const autos = WORK.filter((e) => !isInput(e) && isOn(e));
    const asks = WORK.filter((e) => isInput(e) && isOn(e));
    const req = asks.filter((e) => e.required);
    const defs = asks.filter((e) => (e.arg || '').trim());
    const none = (t) => `<div class="none">${t}</div>`;
    $('ebChanges').innerHTML = autos.length
        ? autos.map((e) => { const s = sentence(e); return s ? `<div class="li">→ ${s}${condSentence(e)}</div>` : ''; }).join('')
        : none('Подія нічого не змінює сама');
    $('ebRequired').innerHTML = req.length
        ? req.map((e) => {
            const p = paramByKey(e.param_key);
            const hint = p && (p.choices || []).length ? 'вибір зі списку' : ((p && p.desc) || 'вводить оператор');
            return `<div class="li"><span><b>${escapeHtml(p ? p.label : e.param_key)}</b><br>
                <span style="font-size:12px;color:var(--text-mute)">${escapeHtml(hint)}</span></span></div>`;
        }).join('')
        : none('Обовʼязкових полів немає');
    $('ebDefaults').innerHTML = defs.length
        ? defs.map((e) => {
            const p = paramByKey(e.param_key);
            return `<div class="li"><span>${escapeHtml(p ? p.label : e.param_key)}</span>
                <span class="v">${escapeHtml(codeLabel(e.param_key, e.arg))}</span></div>`;
        }).join('')
        : none('Значень за замовчуванням немає');
}

/* ═══════════ ЗБЕРЕЖЕННЯ ═══════════ */
/* ═══════════ АВТОЗБЕРЕЖЕННЯ ═══════════
   Кнопки «Зберегти» немає: кожна зміна фіксується сама за 700 мс тиші.
   Стан показує напис біля списку подій. */
let saveTimer = null, saving = false, againAfterSave = false;

function setSavedNote(state) {
    const el = $('ebSaved');
    if (!el) return;
    el.className = 'eb-saved ' + state;
    el.textContent = { wait: 'зміни не збережено', busy: 'збереження…',
        ok: 'збережено', bad: 'не збережено' }[state] || '';
}

function markDirty() {
    dirty = true;
    setSavedNote('wait');
    scheduleSave();
}

function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { flushSave(); }, 700);
}

async function flushSave() {
    clearTimeout(saveTimer);
    if (!dirty || !cur) return true;
    if (saving) { againAfterSave = true; return true; }
    saving = true;
    setSavedNote('busy');
    const okRes = await saveNow();
    saving = false;
    if (againAfterSave) { againAfterSave = false; return flushSave(); }
    return okRes;
}

// Тихий запис без перечитування сторінки: інакше під час набору назви
// інтерфейс перемальовувався б і збивав курсор.
/* Захист від помилок: чипи станів (репродуктивних кодів), з яких
   подію дозволено вносити. Порожньо = без перевірки. */
/* «Розширені» в конструкторі подій. При кожному відкритті події — ЗГОРНУТІ
   (слово Романа), розкриваються лише кліком. */
/* Супутня подія: «також проводить подію … тільки якщо …».
   Пізній аборт (тільність > 200) має лягати в історію і як аборт, і як отел —
   тоді № лактації рахується звичним COUNT(calving) (Роман 2026-09-20). */
function renderAlso(ev) {
    const sel = $('ebAlso');
    if (!sel) return;
    sel.innerHTML = '<option value="">— не проводить —</option>'
        + EVENTS.filter((x) => x.id !== ev.id && x.is_active && !(x.attach_to || '')).map((x) =>
            `<option value="${escapeHtml(x.key)}"${x.key === (ev.also_event || '') ? ' selected' : ''}>${escapeHtml(x.name)}</option>`).join('');
    const c = parseCond(ev.also_cond);
    const p = paramByKey(c.if);
    $('ebAlsoIf').innerHTML = (ev.also_event || '')
        ? `<span class="k">тільки якщо</span> ${paramSelectHtml(c.if, 'ea-if', true)} `
          + `${opSelectHtml(c.op, p, 'ea-opsel')} ${valControlHtml(p, c.eq, 'ea-val')}`
          + `<span class="k">${c.if ? '' : 'без умови — завжди'}</span>`
        : '';
}
function bindAlso() {
    const row = $('ebAlsoRow');
    if (!row) return;
    row.addEventListener('change', (ev) => {
        if (!cur) return;
        if (ev.target.id === 'ebAlso') {
            cur.also_event = ev.target.value;
            if (!cur.also_event) cur.also_cond = '';
            markDirty(); renderAlso(cur); return;
        }
        const k = (row.querySelector('.ea-if') || {}).value || '';
        cur.also_cond = k ? JSON.stringify({ if: k,
            op: (row.querySelector('.ea-opsel') || {}).value || 'eq',
            eq: (row.querySelector('.ea-val') || {}).value || '' }) : '';
        markDirty();
        if (ev.target.classList.contains('ea-if')) renderAlso(cur);
    });
}
bindAlso();

function advEvSet(open) {
    const box = document.querySelector('.eb-adv');
    if (!box) return;
    box.dataset.open = open ? '1' : '0';
    const body = $('ebAdvBody');
    if (body) body.hidden = !open;
    const btn = $('ebAdvBtn');
    if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
}
function advEvNote() {
    const el = $('ebAdvNote');
    if (!el || !cur) return;
    const on = String(cur.allow_rc || '').split(',').map((x) => x.trim()).filter(Boolean);
    const bits = [on.length ? `станів: ${on.length}` : 'стан не перевіряється'];
    if ((cur.detail_tpl || '').trim()) bits.push('деталі за шаблоном');
    el.textContent = bits.join(' · ');
}

/* Що подія пише в «Деталі» історії: її поля + службові факти (приплід,
   мертвонароджені). Порожньо — усе, що записала. */
// Обробники поля шаблону вішаються ОДИН раз, а приклад будується на
// кожен перемальовок події — тримаємо посилання на свіжий, інакше він
// лишається від події, яку відкрили першою (і бреше «немає такого»).
let tplPreview = () => {};

function renderDetailKeys() {
    const box = $('ebDetailKeys');
    const inp = $('ebDetailTpl');
    if (!box || !cur || !inp) return;
    inp.value = cur.detail_tpl || '';
    // підстановки — КОРОТКИМИ назвами параметрів (як у вузьких колонках),
    // повна назва лишається в підказці чипа
    const items = (WORK || []).filter((e) => isOn(e)).map((e) => {
        const p = paramByKey(e.param_key);
        return { n: (p && (p.short || p.label)) || e.param_key,
                 full: (p && p.label) || e.param_key,
                 demo: (p && p.dtype === 'date') ? '2026-09-14' : '2' };
    });
    const used = new Set(items.map((x) => x.n.toLowerCase()));
    const add = (n, demo, full) => {
        // якщо таку назву вже має поле події — розводимо підписом «на момент»
        const nm = used.has(n.toLowerCase()) ? `${n} на момент` : n;
        used.add(nm.toLowerCase());
        items.push({ n: nm, demo, full });
    };
    add('приплід', '9001, 9002', 'бирки новонароджених');
    add('к-сть', '2', 'скільки народилось');
    add('приплід+', '9001 ♀ живе · — ♂ мертве', 'кожне теля: бирка · стать · живе/мертве');
    add('приплід№', '1-9001 живе · 2-9002 мертве', 'нумеровано: номер-бирка живе/мертве');
    items.push({ n: 'приплід:"{№}-{бирка} {стан}"', demo: '1-9001 живе · 2-9002 мертве',
                 full: 'свій формат теляти — поля нижче вставляються всередину лапок' });
    // поля ОДНОГО теляти: діють усередині {приплід:"…"}
    [['№', '1', 'порядковий номер теляти'], ['бирка', '9001', 'номер теляти'],
     ['стать', '♀', 'стать теляти'], ['стан', 'живе', 'живе або мертве'],
     ['кличка', 'Зірка', 'кличка теляти'], ['uin', 'UA9001', 'реєстраційний номер']]
        .forEach(([n, demo, full]) => items.push(
            { n, demo, full: full + ' — лише всередині {приплід:"…"}', calf: true }));
    // параметри, яких ця подія не питає: у шаблоні вони теж працюють —
    // береться значення, чинне на дату події
    const others = [];
    ALL_PARAMS.forEach((p) => {
        const nm = p.short || p.label;
        if (!nm || used.has(String(nm).toLowerCase())) return;
        used.add(String(nm).toLowerCase());
        others.push({ n: nm, demo: p.dtype === 'date' ? '2026-09-14' : '2',
                      full: (p.label || '') + ' — значення на момент події' });
    });
    add('мертві', '1 (Ч×1)', 'мертвонароджені');
    add('DIM', '96', 'днів лактації на момент події');
    add('лакт.', '4', '№ лактації на момент події');
    add('тільн.', '35', 'днів тільності на момент події');
    add('вік', '60', 'вік у місяцях на момент події');
    box.innerHTML = items.map((it) =>
        `<button type="button" class="eb-rc-chip${it.calf ? ' is-calf' : ''}"
                 data-nm="${escapeHtml(it.n)}"
                 data-demo="${escapeHtml(it.demo)}"${it.calf ? ' data-calf="1"' : ''}
                 title="${escapeHtml(it.full || it.n)} — вставити {${escapeHtml(it.n)}}; Alt+клік додасть підпис і підказку">${escapeHtml(it.n)}</button>`).join('')
        || '<span class="hp-note">спершу додайте поля події</span>';
    // вигляд значення в прикладі — те саме правило, що й на сервері
    function fmtDemo(v, spec) {
        v = String(v == null ? '' : v); spec = (spec || '').trim();
        if (!v || !spec) return v;
        const md = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        if (md && /[дмрdMy]/.test(spec)) {
            let out = spec;
            [['рррр', md[1]], ['yyyy', md[1]], ['дд', md[3]], ['dd', md[3]],
             ['мм', md[2]], ['MM', md[2]], ['рр', md[1].slice(2)], ['yy', md[1].slice(2)]]
                .forEach(([a, b]) => { out = out.split(a).join(b); });
            return out;
        }
        const x = parseFloat(v.replace(/[\s\u00a0]/g, '').replace(',', '.'));
        if (!isFinite(x)) return v;
        const ms = /^([^.,]*)(?:([.,])(0+))?$/.exec(spec);
        if (!ms || !/^[0#\s]*$/.test(ms[1] || '')) return v;
        const dec = (ms[3] || '').length;
        let t = Math.abs(x).toFixed(dec);
        let [ip, fp] = t.split('.');
        if ((ms[1] || '').includes('#') || /\s/.test((ms[1] || '').replace(/0/g, ''))) {
            ip = ip.replace(/\B(?=(\d{3})+$)/g, '\u00a0');
        }
        return (x < 0 ? '-' : '') + ip + (dec ? (ms[2] || ',') + fp : '');
    }

    const preview = tplPreview = () => {
        const el = $('ebTplPrev');
        if (!el) return;
        const t = (inp.value || '').trim();
        // порожній шаблон = порожній рядок в історії (рішення Романа)
        if (!t) { el.textContent = 'порожньо — в історії деталей не буде'; return; }
        const demo = {};
        items.concat(others).forEach((it) => { demo[it.n.toLowerCase()] = it.demo; });
        const unknown = [];          // назви, яких немає серед параметрів
        const out = t.replace(/\{((?:[^{}]|\{[^{}]*\})+)\}/g, (m, body) => {
            if (/^\s*приплід\s*:/i.test(body)) {
                // показуємо приклад ЗА ВКАЗАНИМ форматом, а не загальний
                const fmt = (body.split(':').slice(1).join(':') || '').trim()
                    .replace(/^["']|["']$/g, '');
                // «@» перед назвою робить значення посиланням — у прикладі
                // показуємо саме значення
                const one = (vals) => fmt.replace(/\{([^{}]+)\}/g, (mm, kk) => {
                    const kn = kk.trim().replace(/^@/, '').split(';')[0].trim();
                    const low = kn.toLowerCase();
                    if (!(low in vals) && !(low in demo) && !unknown.includes(kn))
                        unknown.push(kn);
                    return vals[low] ?? '';
                })
                    .replace(/\[([^\[\]]*)\]/g, '$1')
                    .replace(/\s{2,}/g, ' ').trim();
                return [one({ '№': '1', 'бирка': '9001', 'стать': '♀', 'стан': 'живе',
                              'кличка': 'Зірка', 'uin': 'UA9001' }),
                        one({ '№': '2', 'бирка': '9002', 'стать': '♂', 'стан': 'мертве',
                              'кличка': '', 'uin': '' })].filter(Boolean).join(' · ');
            }
            // {Параметр;підпис;"підказка";формат} — «підпис значення»
            const parts = body.split(';').map((x) => x.trim().replace(/^["']|["']$/g, ''));
            const nm = (parts[0] || '').replace(/^@/, '');
            const key = nm.toLowerCase();
            if (!(key in demo) && nm && !unknown.includes(nm)) unknown.push(nm);
            const v = fmtDemo(demo[key] ?? '…', parts[3] || '');
            return parts[1] ? `${parts[1]} ${v}` : v;
        });
        // Помилку в назві видно ОДРАЗУ: інакше подія мовчки перестає
        // показувати значення, і причину доводиться шукати навмання.
        el.innerHTML = 'вийде: ' + escapeHtml(out)
            + (unknown.length
                ? `<span class="eb-tpl-bad">немає такого: ${escapeHtml(unknown.join(', '))}</span>`
                : '');
    };
    box.querySelectorAll('.eb-rc-chip').forEach((b) => b.addEventListener('click', (ev) => {
        // Alt+клік одразу дає повний вигляд із підписом і підказкою
        const ph = (ev.altKey && !b.dataset.calf)
            ? `{${b.dataset.nm};підпис;"підказка"}` : `{${b.dataset.nm}}`;
        const a = inp.selectionStart ?? inp.value.length;
        const z = inp.selectionEnd ?? a;
        inp.value = inp.value.slice(0, a) + ph + inp.value.slice(z);
        inp.focus();
        inp.selectionStart = inp.selectionEnd = a + ph.length;
        cur.detail_tpl = inp.value;
        preview(); advEvNote(); markDirty();
    }));
    // ── автодоповнення, як формули в Excel ──────────────────────────────
    // Дивимось, де стоїть курсор: усередині {…} пропонуємо поля події,
    // усередині {приплід:"…"} — поля теляти, після «;» — підпис і підказку.
    const CALF_FIELDS = [
        ['№', 'порядковий номер теляти'], ['бирка', 'номер теляти'],
        ['стать', '♀ / ♂'], ['стан', 'живе або мертве'],
        ['кличка', 'кличка теляти'], ['uin', 'реєстраційний номер'],
    ];
    const ac = $('ebTplAC');
    let acItems = [], acIdx = 0, acFrom = 0, acTo = 0, acWrap = '', acBraces = false;

    function acContext() {
        const pos = inp.selectionStart ?? 0;
        const left = inp.value.slice(0, pos);
        // остання НЕзакрита «{» ліворуч від курсора
        let open = -1, depth = 0;
        for (let i = left.length - 1; i >= 0; i--) {
            const ch = left[i];
            if (ch === '}') depth++;
            else if (ch === '{') {
                if (!depth) { open = i; break; }
                depth--;
            }
        }
        // чи ми всередині лапок формату приплоду: {приплід:"…курсор…"}
        const inQuotes = (() => {
            const q = left.lastIndexOf(':"');
            if (q < 0) return false;
            const closed = left.indexOf('"', q + 2);
            return closed < 0;            // закривної лапки ще немає — ми всередині
        })();
        if (open >= 0) {
            const frag = left.slice(open + 1);
            if (inQuotes && open > left.lastIndexOf(':"')) {
                return { kind: 'calf', from: open + 1, to: pos, frag };
            }
            if (!inQuotes) {
                const semi = frag.lastIndexOf(';');
                if (semi >= 0)
                    return { kind: 'part', from: pos, to: pos, frag: frag.slice(semi + 1) };
                return { kind: 'root', from: open + 1, to: pos, frag };
            }
        }
        // всередині лапок, але поза «{}» — підкажемо поля, вставимо з дужками
        if (inQuotes) return { kind: 'calf', from: pos, to: pos, frag: '', wrap: true };
        return null;
    }

    function acRender() {
        const ctx = acContext();
        if (!ctx) { ac.hidden = true; return; }
        acFrom = ctx.from; acTo = ctx.to; acWrap = ctx.kind;
        acBraces = !!ctx.wrap;
        const frag = (ctx.frag || '').toLowerCase();
        let list;
        if (ctx.kind === 'calf') {
            list = CALF_FIELDS.map(([k, d]) => ({ k, d }));
            // плюс параметри самого теляти (вага при народженні тощо)
            const birth = EVENTS.find((x) => (x.attach_to || '') === cur.key && x.births)
                || (cur.births ? cur : null);
            if (birth) (birth.effects || []).forEach((ef) => {
                const p = paramByKey(ef.param_key);
                if (!p) return;
                const nm = p.short || p.label;
                const low = String(nm).toLowerCase();
                if (CALF_FIELDS.some(([k]) => k.toLowerCase() === low)) return;
                if (list.some((x) => x.k.toLowerCase() === low)) return;
                list.push({ k: nm, d: (p.label || '') + ' — параметр теляти' });
            });
        } else if (ctx.kind === 'part') {
            // блоки після «;»: підпис · "підказка" · формат значення
            list = [{ k: 'підпис', d: 'слово перед значенням' },
                    { k: '"підказка"', d: 'спливає при наведенні' },
                    { k: '0.0', d: 'число з одним знаком: 27,4' },
                    { k: '0', d: 'ціле: 27' },
                    { k: '0.00', d: 'два знаки: 27,45' },
                    { k: '# ##0', d: 'розряди по три: 1 240' },
                    { k: 'дд.мм.рррр', d: 'дата: 03.10.2025' },
                    { k: 'дд.мм', d: 'дата без року: 03.10' }];
        } else {
            // поля теляти працюють лише всередині {приплід:"…"} — у корені не пропонуємо
            list = items.filter((it) => !it.calf).concat(others)
                .map((it) => ({ k: it.n, d: it.full || it.demo || '' }));
        }
        // шукаємо і за назвою, і за поясненням — короткі назви бувають англійські
        const hitK = list.filter((x) => x.k.toLowerCase().includes(frag));
        const hitD = list.filter((x) => !x.k.toLowerCase().includes(frag)
            && (x.d || '').toLowerCase().includes(frag));
        acItems = !frag ? list : hitK.concat(hitD);
        if (!acItems.length) { ac.hidden = true; return; }
        acIdx = Math.min(acIdx, acItems.length - 1);
        const head = ctx.kind === 'calf' ? 'поля теляти'
            : (ctx.kind === 'part' ? 'далі: підпис ; "підказка"' : 'що підставити');
        ac.innerHTML = `<div class="eb-ac-hint">${head} — ↑↓ і Enter</div>`
            + acItems.map((x, i) => `<div class="eb-ac-item${i === acIdx ? ' on' : ''}"
                 data-i="${i}"><span class="k">${escapeHtml(x.k)}</span>`
                + `<span class="d">${escapeHtml(x.d)}</span></div>`).join('');
        ac.hidden = false;
        ac.querySelectorAll('.eb-ac-item').forEach((el) =>
            el.addEventListener('mousedown', (e) => { e.preventDefault(); acPick(+el.dataset.i); }));
    }

    function acPick(i) {
        const it = acItems[i];
        if (!it) return;
        const isCalfTpl = /^приплід:/.test(it.k);
        let ins = it.k, caret;
        if (acWrap === 'part' || acBraces) {
            const t = acBraces ? `{${ins}}` : ins;
            inp.value = inp.value.slice(0, acTo) + t + inp.value.slice(acTo);
            caret = acTo + t.length;
        } else {
            const after = inp.value.slice(acTo);
            const closed = after.startsWith('}');
            const tail = closed ? '' : '}';
            if (isCalfTpl) {                   // каркас списку — курсор усередину лапок
                inp.value = inp.value.slice(0, acFrom) + ins + (closed ? '' : '}')
                    + after.slice(closed ? 1 : 0);
                caret = acFrom + ins.lastIndexOf('"');   // перед закривною лапкою
            } else {
                inp.value = inp.value.slice(0, acFrom) + ins + tail + after;
                caret = acFrom + ins.length + tail.length;
            }
        }
        inp.focus();
        inp.selectionStart = inp.selectionEnd = caret;
        cur.detail_tpl = inp.value;
        preview(); advEvNote(); markDirty();
        acIdx = 0; acRender();   // одразу підказуємо наступний крок (як в екселі)
    }

    if (!inp.dataset.acBound) {
        inp.dataset.acBound = '1';
        inp.addEventListener('keydown', (ev) => {
            if (ac.hidden) return;
            if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
                ev.preventDefault();
                acIdx = (acIdx + (ev.key === 'ArrowDown' ? 1 : -1) + acItems.length)
                    % acItems.length;
                acRender();
            } else if (ev.key === 'Enter' || ev.key === 'Tab') {
                ev.preventDefault(); acPick(acIdx);
            } else if (ev.key === 'Escape') {
                ev.preventDefault(); ac.hidden = true;
            }
        });
        inp.addEventListener('input', () => { acIdx = 0; acRender(); });
        inp.addEventListener('click', acRender);
        inp.addEventListener('blur', () => setTimeout(() => { ac.hidden = true; }, 120));
    }

    if (!inp.dataset.bound) {
        inp.dataset.bound = '1';
        // Другий пробіль ловимо ДО того, як його побачить система: macOS
        // сама міняє «  » на «. », тож у input-обробнику було б уже пізно.
        inp.addEventListener('keydown', (ev) => {
            if (ev.key !== ' ' || ev.ctrlKey || ev.metaKey || ev.altKey) return;
            const a = inp.selectionStart, z = inp.selectionEnd;
            if (a !== z || a < 1 || inp.value[a - 1] !== ' ') return;
            ev.preventDefault();
            inp.value = inp.value.slice(0, a - 1) + ' · ' + inp.value.slice(a);
            inp.selectionStart = inp.selectionEnd = a + 2;
            cur.detail_tpl = inp.value; tplPreview(); advEvNote(); markDirty();
        });
        inp.addEventListener('input', () => {
            // запасний шлях: якщо система встигла поставити «. » замість пробілів
            const a = inp.selectionStart;
            if (a >= 2 && inp.value.slice(a - 2, a) === '. '
                && !/\d\.\s$/.test(inp.value.slice(0, a))) {
                inp.value = inp.value.slice(0, a - 2) + ' · ' + inp.value.slice(a);
                inp.selectionStart = inp.selectionEnd = a + 1;
            }
            cur.detail_tpl = inp.value; tplPreview(); advEvNote(); markDirty();
        });
    }
    preview();
}

function renderAllowRc() {
    const box = $('ebAllowRc');
    if (!box || !cur) return;
    const p = paramByKey('repro_code');
    const ch = (p && p.choices) || [];
    const on = new Set(String(cur.allow_rc || '').split(',')
        .map((x) => x.trim()).filter(Boolean));
    box.innerHTML = ch.map((c) =>
        `<button type="button" class="eb-rc-chip${on.has(String(c.value)) ? ' on' : ''}"
                 data-rc="${escapeHtml(c.value)}">${escapeHtml(c.label)}</button>`).join('');
    advEvNote();
    box.querySelectorAll('.eb-rc-chip').forEach((b) => b.addEventListener('click', () => {
        const v = b.dataset.rc;
        on.has(v) ? on.delete(v) : on.add(v);
        cur.allow_rc = [...on].join(',');
        b.classList.toggle('on', on.has(v));
        advEvNote();
        markDirty();
    }));
}

async function saveNow() {
    const payload = {
        name: $('ebName').value.trim() || cur.name,
        category: $('ebCat').value,
        is_active: $('ebActive').checked,
        show_on_panel: $('ebPanel').checked,
        attach_to: $('ebAttach').value || '',
        also_event: cur.also_event || '', also_cond: cur.also_cond || '',
        allow_rc: cur.allow_rc || '',
        detail_keys: cur.detail_keys || '',
        detail_tpl: cur.detail_tpl || '',
        access: ACCESS,
        effects: WORK.map((e) => ({ param_key: e.param_key, mode: e.mode, arg: e.arg || '',
            required: e.required ? 1 : 0, quick: 1, enabled: e.enabled ? 1 : 0,
            cond: e.cond || '' })),
    };
    const r = await apiSend('/api/herd/events/' + cur.id, 'POST', payload);
    if (!r || !r.ok) { setSavedNote('bad'); toast((r && r.error) || 'Не збережено', 'error'); return false; }
    dirty = false;
    // тримаємо локальний список у тому ж стані, що й база
    cur.name = payload.name; cur.category = payload.category;
    cur.is_active = payload.is_active ? 1 : 0;
    cur.show_on_panel = payload.show_on_panel ? 1 : 0;
    cur.attach_to = payload.attach_to;
    cur.also_event = payload.also_event; cur.also_cond = payload.also_cond;
    cur.allow_rc = payload.allow_rc;
    cur.detail_keys = payload.detail_keys;
    cur.detail_tpl = payload.detail_tpl;
    cur.effects = payload.effects;
    cur.access_list = ACCESS.slice();
    const idx = EVENTS.findIndex((e) => e.id === cur.id);
    if (idx >= 0) EVENTS[idx] = cur;
    renderEventList(cur.id);
    setSavedNote('ok');
    renderCycle();
    return true;
}


/* ═══════════ КАТЕГОРІЇ ПОДІЙ ═══════════ */
// Вбудовані пʼять прибрати не можна — у них немає кнопки «−».
const BUILTIN_CATS = new Set(['repro', 'health', 'move', 'prod', 'other']);

function openCatMgr() {
    renderCatList();
    $('evCatModal').hidden = false;
    setTimeout(() => $('ebCatName').focus(), 60);
}
function closeCatMgr() { $('evCatModal').hidden = true; }

function renderCatList() {
    const used = {};
    EVENTS.forEach((e) => { used[e.category] = (used[e.category] || 0) + 1; });
    $('ebCatList').innerHTML = Object.entries(CATS).map(([k, v]) => {
        const n = used[k] || 0;
        const own = !BUILTIN_CATS.has(k);
        // 1 подія · 2-4 події · 5+ подій (11-14 теж «подій»)
        const word = (n % 100 >= 11 && n % 100 <= 14) ? 'подій'
            : (n % 10 === 1 ? 'подія' : (n % 10 >= 2 && n % 10 <= 4 ? 'події' : 'подій'));
        return `<div class="cat-row">
            <span class="cat-nm">${escapeHtml(v)}</span>
            <span class="cat-n">${n ? n + ' ' + word : 'порожня'}</span>
            ${own ? `<button type="button" class="cat-del" data-key="${escapeHtml(k)}"
                        title="Прибрати категорію">−</button>`
                  : '<span class="cat-lock" title="вбудована категорія">вбудована</span>'}
        </div>`;
    }).join('');
    $('ebCatList').querySelectorAll('.cat-del').forEach((b) =>
        b.addEventListener('click', () => delCategory(b.dataset.key)));
}

async function addCategory() {
    const inp = $('ebCatName');
    const name = (inp.value || '').trim();
    if (!name) { inp.focus(); return; }
    const r = await apiSend('/api/herd/event-categories', 'POST', { name });
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    CATS[r.key] = r.name;
    inp.value = '';
    renderCatList();
    refreshCatSelect();
    toast(`Категорію «${r.name}» створено`, 'success');
}

async function delCategory(key) {
    if (BUILTIN_CATS.has(key)) return;
    if (!(await confirmAction(`Прибрати категорію «${CATS[key]}»? Її події перейдуть в «Інше».`, { ok: 'Прибрати' }))) return;
    const r = await apiSend('/api/herd/event-categories/' + encodeURIComponent(key), 'DELETE');
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    toast('Категорію прибрано', 'success');
    closeCatMgr();
    await load(cur && cur.id);
}

// перемалювати випадайку категорій події, зберігши поточний вибір
function refreshCatSelect() {
    const keep = $('ebCat').value;
    $('ebCat').innerHTML = Object.entries(CATS).map(([k, v]) =>
        `<option value="${k}"${k === keep ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
}

/* ═══════════ ВИБІР ПАРАМЕТРА ═══════════ */
function openPicker() {
    pkQ = ''; pkCat = 'Усі';
    $('pkQuery').value = '';
    $('evPicker').hidden = false;
    renderPicker();
    setTimeout(() => $('pkQuery').focus(), 60);
}
function renderPicker() {
    const cats = ['Усі'].concat([...new Set(ALL_PARAMS.map((p) => p.section).filter(Boolean))]);
    $('pkCats').innerHTML = cats.map((c) =>
        `<button type="button" class="pk-cat${pkCat === c ? ' on' : ''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
    $('pkCats').querySelectorAll('.pk-cat').forEach((b) => b.addEventListener('click', () => {
        pkCat = b.dataset.cat; renderPicker();
    }));
    const q = pkQ.toLowerCase();
    const list = ALL_PARAMS.filter((p) => (pkCat === 'Усі' || p.section === pkCat)
        && (!q || (p.label + ' ' + p.key).toLowerCase().includes(q)));
    const inEvent = (code) => WORK.some((x) => x.param_key === code
        && (isInput(x) || x.mode === 'show'));
    $('pkList').innerHTML = list.length ? list.map((p) => `<div class="pk-row${inEvent(p.key) ? ' on' : ''}" data-code="${escapeHtml(p.key)}">
        <input type="checkbox" ${inEvent(p.key) ? 'checked' : ''}>
        <span><span class="nm">${escapeHtml(p.label)}${p.unit ? ', ' + escapeHtml(p.unit) : ''}</span><br>
            <span class="sub">${escapeHtml(p.key)}${p.section ? ' · ' + escapeHtml(p.section) : ''}</span></span>
        <span class="hp-type">${escapeHtml(typeLabel(p))}</span></div>`).join('')
        : '<div class="hp-empty">Нічого не знайдено за цим запитом</div>';
    $('pkList').querySelectorAll('.pk-row').forEach((row) => row.addEventListener('click', () => {
        const code = row.dataset.code;
        const prm = ALL_PARAMS.find((x) => x.key === code);
        const fx = !!(prm && (prm.formula || '').trim());
        if (inEvent(code)) WORK = WORK.filter((x) => !(x.param_key === code && (isInput(x) || x.mode === 'show')));
        else WORK.push({ param_key: code, mode: fx ? 'show' : 'input', arg: '',
            required: 0, quick: 1, enabled: 1 });
        markDirty(); renderPicker();
    }));
    const n = WORK.filter(isInput).length;
    $('pkNote').textContent = `У події «${cur ? cur.name : ''}»: ${n} ${n === 1 ? 'поле' : 'полів'}`;
}
function closePicker() { $('evPicker').hidden = true; renderFields(); }

/* ═══════════ РОЗШИРЕНО ═══════════ */
function autoModeOptions(sel) {
    return Object.entries(MODES).filter(([k]) => k !== 'input').map(([k, v]) =>
        `<option value="${k}"${k === sel ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
}
function argControlHtml(param, val) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ee-arg"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ee-arg" placeholder="значення" value="${escapeHtml(val || '')}">`;
}
function paramSelectHtml(sel, cls, withFormula) {
    // ⚠️ у дії подія може ЗМІНИТИ лише те, що не рахується формулою, а в УМОВІ
    // обчислюване саме й потрібне: «якщо Днів тільності > 200» (Роман 2026-09-20)
    const list = withFormula ? ALL_PARAMS : PARAMS;
    return `<select class="ref-select ${cls}"><option value="">— параметр —</option>`
        + list.map((p) => `<option value="${escapeHtml(p.key)}"${p.key === sel ? ' selected' : ''}>${escapeHtml(p.label)}</option>`).join('')
        + '</select>';
}
const WHEN_OPS = [['eq', '='], ['ne', '≠'], ['gt', '>'], ['ge', '≥'], ['lt', '<'], ['le', '≤']];
function opSelectHtml(op, param, cls) {
    // для списків і тексту «більше/менше» безглузді — лишаємо = і ≠
    const dt = (param && param.dtype) || '';
    const num = ['int', 'float', 'number', 'date'].includes(dt) || (param && (param.formula || '').trim());
    const list = num ? WHEN_OPS : WHEN_OPS.slice(0, 2);
    const cur = op || 'eq';
    return `<select class="ref-select ${cls || 'ee-opsel'}" title="спосіб порівняння">`
        + list.map(([k, l]) => `<option value="${k}"${k === cur ? ' selected' : ''}>${l}</option>`).join('')
        + '</select>';
}
/* значення, ПРИБРАНЕ з довідника (напр. «Продаж» після переходу на
   накладні), лишається в правилі окремим пунктом: інакше select віддав би
   порожнє, збереження записало б умову без значення — і правило тихо
   перестало б діяти (знайдено перевіркою 2026-09-21) */
function lostOptionHtml(param, val) {
    const v = String(val || '');
    if (!v) return '';
    const ch = (param && param.choices) || [];
    if (ch.some((c) => String(c.value) === v)) return '';
    const off = ((param && param.choices_off) || []).find((c) => String(c.value) === v);
    const lbl = off ? `${off.label} (прибрано зі списку)` : `${v} (немає в списку)`;
    return `<option value="${escapeHtml(v)}" selected>${escapeHtml(lbl)}</option>`;
}
function valControlHtml(param, val, cls) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ${cls}"><option value="">—</option>`
            + lostOptionHtml(param, val)
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ${cls}" value="${escapeHtml(val || '')}" placeholder="значення" style="width:88px">`;
}
function parseWhenSpec(arg) {
    let d = {};
    try { if (arg && arg.trim().startsWith('{')) d = JSON.parse(arg); } catch (e) { d = {}; }
    if (d && Array.isArray(d.rules)) {
        return { rules: d.rules.map((r) => ({ if: r.if || '', eq: r.eq || '', val: r.val || '', op: r.op || 'eq' })),
            default: d.default || '' };
    }
    if (d && (d.if || d.eq || d.val)) {
        if (!d.if) return { rules: [], default: d.val || '' };
        return { rules: [{ if: d.if, eq: d.eq || '', val: d.val || '', op: d.op || 'eq' }], default: '' };
    }
    return { rules: [], default: '' };
}
function whenRuleLineHtml(targetParam, r) {
    const ifParam = paramByKey(r.if);
    return `<div class="ee-when-line" data-role="rule">`
        + `<span class="ee-op">якщо</span> ${paramSelectHtml(r.if, 'ee-if', true)} `
        + `${opSelectHtml(r.op, ifParam)} ${valControlHtml(ifParam, r.eq, 'ee-ifval')} `
        + `<span class="ee-op">→</span> ${valControlHtml(targetParam, r.val, 'ee-val')}`
        + `<button type="button" class="ee-line-del" title="Прибрати умову">✕</button></div>`;
}
function whenDefaultLineHtml(targetParam, val) {
    return `<div class="ee-when-line ee-when-def" data-role="default">`
        + `<span class="ee-op">інакше</span> <span class="ee-op">→</span> `
        + `${valControlHtml(targetParam, val, 'ee-val')}</div>`;
}
function whenBlockHtml(targetParam, arg) {
    const spec = parseWhenSpec(arg);
    const rules = spec.rules.length ? spec.rules : [{ if: '', eq: '', val: '', op: 'eq' }];
    return `<div class="ee-when"><div class="ee-when-lines">`
        + rules.map((r) => whenRuleLineHtml(targetParam, r)).join('')
        + whenDefaultLineHtml(targetParam, spec.default)
        + `</div><button type="button" class="ee-when-add">+ ще «якщо»</button></div>`;
}
function readWhenBlock(scope) {
    const rules = [];
    scope.querySelectorAll('.ee-when-line[data-role="rule"]').forEach((l) => {
        rules.push({ if: (l.querySelector('.ee-if') || {}).value || '',
            op: (l.querySelector('.ee-opsel') || {}).value || 'eq',
            eq: (l.querySelector('.ee-ifval') || {}).value || '',
            val: (l.querySelector('.ee-val') || {}).value || '' });
    });
    const dl = scope.querySelector('.ee-when-line[data-role="default"] .ee-val');
    return { rules, default: dl ? dl.value : '' };
}

/* ═══════════ КОЛО ВІДТВОРЕННЯ ═══════════ */
function cycleRoles() {
    const roles = { set: {}, branch: null };
    EVENTS.filter((e) => e.is_active).forEach((e) => {
        (e.effects || []).forEach((f) => {
            if (f.param_key !== 'repro_code') return;
            if (f.mode === 'const' && ['2', '4', '6', '9'].includes(String(f.arg).trim())) {
                if (!roles.set[String(f.arg).trim()]) roles.set[String(f.arg).trim()] = e;
            } else if (f.mode === 'when') {
                const s = parseWhenSpec(f.arg);
                const vals = s.rules.map((r) => String(r.val));
                if (vals.includes('5') && vals.includes('3')) roles.branch = e;
            }
        });
    });
    return roles;
}
function renderCycle() {
    const _c = document.getElementById('ebCycBtn');
    if (_c && _c.closest('.hp-card').dataset.fold === '0') return;
    const svg = $('evCycle'); if (!svg) return;
    const R = cycleRoles();
    // назви станів — з варіантів «Репродуктивного коду» в конструкторі
    // (доти код 3 тут звався «Ялова», а в конструкторі «Осіменена не тільна»)
    const st = (c, fb) => (window.herdOpt ? herdOpt('repro_code', c, fb) : fb);
    const N = {
        '0': { x: 70,  y: 55,  t: st('0', 'Телиця'),     c: '0' },
        '4': { x: 250, y: 140, t: st('4', 'Осіменена'),  c: '4' },
        '3': { x: 250, y: 265, t: st('3', 'Ялова'),      c: '3' },
        '5': { x: 470, y: 140, t: st('5', 'Тільна'),     c: '5' },
        '6': { x: 660, y: 140, t: st('6', 'Сухостій'),   c: '6' },
        '2': { x: 660, y: 265, t: st('2', 'Новотільна'), c: '2' },
    };
    const ev4 = R.set['4'], ev6 = R.set['6'], ev2 = R.set['2'], br = R.branch;
    const edges = [
        ['0', '4', ev4, '', [-14, -16], 0],
        // підписи розгалуження — варіанти «Результату» з конструктора
        ['4', '5', br, herdOpt('preg_result', '5', 'тільна').toLowerCase(), [0, -14], 0],
        ['4', '3', br, herdOpt('preg_result', '3', 'ялова').toLowerCase(), [78, 3], -26],
        ['3', '4', ev4, '', [-64, 3], 0],
        ['5', '6', ev6, '', [0, -14], 0],
        ['6', '2', ev2, '', [14, 3], 0],
        ['2', '4', ev4, 'через 60 дн', [0, 16], 26],
    ];
    const W = 118, H = 44;
    const defs = `<defs><marker id="cycArr" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#bfa87f"/></marker>
        <marker id="cycArrBad" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#b3372f"/></marker></defs>`;
    const port = (n, side) => {
        const p = N[n];
        if (side === 'l') return [p.x - W / 2, p.y];
        if (side === 'r') return [p.x + W / 2, p.y];
        if (side === 't') return [p.x, p.y - H / 2];
        return [p.x, p.y + H / 2];
    };
    let g = '', labels = '';
    edges.forEach(([a, b, ev, extra, lo, dx]) => {
        const A = N[a], B = N[b];
        let p1, p2, path, mid;
        const shift = (pt) => [pt[0] + (dx || 0), pt[1]];
        if (a === '2' && b === '4') {
            p1 = port(a, 'b'); p2 = shift(port(b, 'b'));
            path = `M${p1[0]},${p1[1]} C ${p1[0]},324 ${p2[0]},324 ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, 314];
        } else if (a === '3' && b === '4') {
            p1 = port(a, 'l'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} C ${p1[0] - 70},${p1[1]} ${p2[0] - 70},${p2[1]} ${p2[0]},${p2[1]}`;
            mid = [p1[0] - 56, (p1[1] + p2[1]) / 2];
        } else if (A.y === B.y) {
            p1 = port(a, 'r'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, p1[1]];
        } else if (A.x === B.x) {
            p1 = shift(port(a, 'b')); p2 = shift(port(b, 't'));
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [p1[0], (p1[1] + p2[1]) / 2];
        } else {
            p1 = port(a, 'b'); p2 = port(b, 't');
            path = `M${p1[0]},${p1[1]} C ${p1[0]},${p1[1] + 40} ${p2[0]},${p2[1] - 40} ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2];
        }
        const ok = !!ev;
        g += `<path class="cyc-edge${ok ? '' : ' bad'}" d="${path}"
                marker-end="url(#${ok ? 'cycArr' : 'cycArrBad'})"></path>`;
        const lbl = extra ? `${ok ? ev.name : 'немає події!'} · ${extra}` : (ok ? ev.name : 'немає події!');
        labels += `<text class="cyc-lbl${ok ? '' : ' bad'}" x="${mid[0] + lo[0]}" y="${mid[1] + lo[1]}"
                text-anchor="middle" ${ok ? `data-ev="${ev.id}"` : ''}>${escapeHtml(lbl)}</text>`;
    });
    let nodes = '';
    Object.values(N).forEach((n) => {
        nodes += `<g class="cyc-node">
            <rect x="${n.x - W / 2}" y="${n.y - H / 2}" width="${W}" height="${H}" rx="10"></rect>
            <text x="${n.x}" y="${n.y + 1}" text-anchor="middle">${escapeHtml(n.t)}</text>
            <text class="cyc-code" x="${n.x}" y="${n.y + 15}" text-anchor="middle">код ${n.c}</text>
        </g>`;
    });
    svg.innerHTML = defs + g + nodes + labels;
    svg.querySelectorAll('.cyc-lbl[data-ev]').forEach((t) => t.addEventListener('click', () => {
        selectEvent(+t.dataset.ev);
        document.querySelector('.hp-head').scrollIntoView({ block: 'start', behavior: 'smooth' });
    }));
}

/* ═══════════ САМОПЕРЕВІРКА ═══════════ */
$('evSelftestBtn').addEventListener('click', async () => {
    const out = $('evSelftestOut');
    out.hidden = false;
    out.innerHTML = '<div class="hp-note">Проганяю тестову тварину по колу…</div>';
    const r = await apiSend('/api/herd/repro-selftest', 'POST', {});
    if (!r || !r.ok) { out.innerHTML = `<div class="hp-verdict bad">Помилка: ${escapeHtml((r && r.error) || '')}</div>`; return; }
    const ok = r.checks.every((c) => c.ok);
    out.innerHTML = `<div class="hp-verdict ${ok ? 'ok' : 'bad'}">${ok
        ? '✅ Алгоритм виконується, коло замкнене' : '⚠ Знайдено проблеми — дивіться червоні рядки'}</div>`
        + r.checks.map((c) => `<div class="row ${c.ok ? 'ok' : 'bad'}">
            <span class="m">${c.ok ? '✓' : '✗'}</span>
            <span>${escapeHtml(c.label)}</span>
            ${c.note ? `<span class="note">· ${escapeHtml(c.note)}</span>` : ''}
        </div>`).join('');
});

/* ═══════════ ПОДІЇ ІНТЕРФЕЙСУ ═══════════ */
document.querySelectorAll('#ebSteps .hp-tab').forEach((b) =>
    b.addEventListener('click', () => setStep(+b.dataset.step)));
$('ebPrev').addEventListener('click', () => { if (step > 1) setStep(step - 1); });
$('ebNext').addEventListener('click', async () => {
    if (step < 3) { setStep(step + 1); return; }
    await flushSave();          // усе вже збережено; це лише підстраховка
    toast('Налаштування збережено', 'success');
});
$('ebAllUsers').addEventListener('click', () => {
    ACCESS = ACCESS.length === USERS.length ? [] : USERS.map((u) => u.id);
    markDirty(); renderUsers();
});
$('ebAddParam').addEventListener('click', openPicker);
$('ebCatMgr').addEventListener('click', openCatMgr);
$('ebCatAdd').addEventListener('click', addCategory);
$('ebCatName').addEventListener('keydown', (e) => { if (e.key === 'Enter') addCategory(); });
document.querySelectorAll('#evCatModal [data-cclose]').forEach((el) =>
    el.addEventListener('click', closeCatMgr));
$('ebName').addEventListener('input', () => {
    if ($('ebCurName')) $('ebCurName').textContent = $('ebName').value.trim();
});
['ebName', 'ebCat', 'ebActive', 'ebPanel', 'ebAttach'].forEach((id) =>
    $(id).addEventListener('change', () => { markDirty(); }));
$('ebAttach').addEventListener('change', syncAttachWarn);
$('ebName').addEventListener('input', () => { markDirty(); });

$('ebDel').addEventListener('click', async () => {
    if (!cur) return;
    if (cur.is_standard && !window.canManage('herd')) { toast('Системну подію видаляє лише адмін', 'warn'); return; }
    if (!(await confirmAction(`Видалити подію «${cur.name}»?`, { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/events/' + cur.id, 'DELETE');
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    dirty = false; cur = null;
    await load();
});

// ⚠️ Замок: два натискання «+ нова подія» заводили ДВІ порожні події
let ebNewBusy = false;
$('ebNew').addEventListener('click', async () => {
    if (ebNewBusy) return;
    ebNewBusy = true;
    $('ebNew').disabled = true;
    try {
        const r = await apiSend('/api/herd/events', 'POST',
            { name: 'Нова подія', category: 'other', effects: [] });
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        await load(r.id);
        $('ebName').focus(); $('ebName').select();
    } finally {
        ebNewBusy = false;
        $('ebNew').disabled = false;
    }
});

$('pkQuery').addEventListener('input', () => { pkQ = $('pkQuery').value; renderPicker(); });
$('pkDone').addEventListener('click', closePicker);
document.querySelectorAll('#evPicker [data-pclose]').forEach((el) =>
    el.addEventListener('click', closePicker));


document.addEventListener('herd-params-changed', () => { if ($('ebList')) load(); });
if ($('ebList')) load();

let scrollTimer = null;
window.addEventListener('scroll', () => {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(() => lsSet(LS_SCROLL, Math.round(window.scrollY)), 200);
}, { passive: true });

// якщо сторінку закривають раніше, ніж мине пауза автозбереження
window.addEventListener('beforeunload', () => { if (dirty) flushSave(); });
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden' && dirty) flushSave();
});
})();
