"""HTTPS для локальної мережі через ВЛАСНИЙ локальний CA.

Чому CA, а не «голий» самопідпис: iOS надійно вмикає service worker (офлайн)
лише для сертифікатів, підписаних ДОВІРЕНИМ корінням. Тому ми генеруємо
власний стабільний CA — його встановлюють і роблять довіреним на пристрої
ОДИН раз. Сервер-сертифікат (leaf) підписуємо цим CA. Leaf можна вільно
перевипускати (зміна IP/імені) — довіра не злітає, бо CA незмінний.

Файли у стан-папці:
  farm_ca.pem / farm_ca_key.pem   — корінь (CA), стабільний; CA встановлюють на пристрої
  farm_cert.pem                   — leaf + CA (повний ланцюг для сервера)
  farm_key.pem                    — приватний ключ leaf
"""
from __future__ import annotations

import datetime
import ipaddress
import socket
from datetime import timedelta
from pathlib import Path


def _all_local_ipv4() -> set:
    """Усі локальні IPv4-адреси цього ПК (усі мережеві адаптери).

    Навіщо: на Windows часто кілька адаптерів (Wi-Fi, Ethernet, інколи
    VirtualBox/WSL/VPN). Якщо в сертифікаті лише одна IP, а заходять за іншою —
    Chrome відхиляє сертифікат навіть із довіреним CA. Тому кладемо в сертифікат
    усі адреси, щоб він був валідним за будь-якою з них."""
    ips: set = set()
    # 1) Основна адреса (та, через яку є вихід у мережу).
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.3)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:  # noqa: BLE001
        pass
    # 2) Усі адреси, привʼязані до імені хоста (зазвичай покриває всі адаптери).
    try:
        host = socket.gethostname()
        for res in socket.getaddrinfo(host, None, socket.AF_INET):
            ips.add(res[4][0])
    except Exception:  # noqa: BLE001
        pass
    try:
        ips.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except Exception:  # noqa: BLE001
        pass
    # Прибираємо порожні, 0.0.0.0 та APIPA (169.254.x — несправжні адреси).
    return {ip for ip in ips if ip and ip != "0.0.0.0"
            and not ip.startswith("169.254.")}


def ensure_cert(state_dir: Path, lan_ip: str = "", hostnames=None) -> tuple[str, str]:
    """Повертає (certfile, keyfile) для HTTPS-сервера (leaf, підписаний CA).
    certfile містить повний ланцюг leaf+CA. Кидає виняток, якщо немає
    бібліотеки cryptography."""
    state_dir = Path(state_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    ca_cert_path = state_dir / "farm_ca.pem"
    ca_key_path = state_dir / "farm_ca_key.pem"
    leaf_cert_path = state_dir / "farm_cert.pem"
    leaf_key_path = state_dir / "farm_key.pem"
    meta_path = state_dir / "farm_cert_ip.txt"

    hostnames = [h for h in (hostnames or []) if h]
    # Імʼя цього ПК додаємо завжди (на випадок, якщо викликач не передав).
    try:
        hostnames.append(socket.gethostname().split(".")[0])
    except Exception:  # noqa: BLE001
        pass
    hostnames = [h for h in dict.fromkeys(h.strip().lower() for h in hostnames if h)]

    # Усі локальні IP + передана lan_ip.
    ips = _all_local_ipv4()
    if lan_ip:
        ips.add(lan_ip)

    ca_cert, ca_key = _ensure_ca(ca_cert_path, ca_key_path)

    # Підпис стану: IP + імена + відбиток CA. Якщо щось змінилось — перевипуск leaf.
    try:
        from cryptography.hazmat.primitives import hashes
        ca_fpr = ca_cert.fingerprint(hashes.SHA256()).hex()
    except Exception:  # noqa: BLE001
        ca_fpr = ""
    sig = ",".join(sorted(ips)) + "|" + ",".join(sorted(set(hostnames))) + "|" + ca_fpr

    prev = ""
    try:
        prev = meta_path.read_text(encoding="utf-8").strip()
    except Exception:  # noqa: BLE001
        prev = ""

    if leaf_cert_path.exists() and leaf_key_path.exists() \
            and not _expired(leaf_cert_path) and prev == sig:
        return str(leaf_cert_path), str(leaf_key_path)

    _make_leaf(leaf_cert_path, leaf_key_path, ca_cert, ca_key, ips, hostnames)
    try:
        meta_path.write_text(sig, encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    return str(leaf_cert_path), str(leaf_key_path)


def _expired(cert_path: Path) -> bool:
    try:
        from cryptography import x509
        cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
        return cert.not_valid_after_utc < datetime.datetime.now(datetime.timezone.utc)
    except Exception:  # noqa: BLE001
        return True


def _ensure_ca(ca_cert_path: Path, ca_key_path: Path):
    """Завантажити наявний CA або створити стабільний новий (раз)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    if ca_cert_path.exists() and ca_key_path.exists() and not _expired(ca_cert_path):
        try:
            ca_cert = x509.load_pem_x509_certificate(ca_cert_path.read_bytes())
            ca_key = serialization.load_pem_private_key(ca_key_path.read_bytes(), password=None)
            return ca_cert, ca_key
        except Exception:  # noqa: BLE001
            pass
    return _make_ca(ca_cert_path, ca_key_path)


def _make_ca(ca_cert_path: Path, ca_key_path: Path):
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "Oblik fermy Local CA"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Oblik fermy"),
    ])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=3650))   # 10 років — корінь стабільний
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=False, content_commitment=False, key_encipherment=False,
            data_encipherment=False, key_agreement=False, key_cert_sign=True,
            crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .sign(key, hashes.SHA256())
    )
    ca_key_path.write_bytes(key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()))
    ca_cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    return cert, key


def _make_leaf(leaf_cert_path: Path, leaf_key_path: Path, ca_cert, ca_key,
               ips, hostnames) -> None:
    from cryptography import x509
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Oblik fermy")])

    sans = [x509.DNSName("localhost"),
            x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
    # Усі локальні IP — щоб сертифікат був валідним за будь-якою адресою.
    for ip in sorted(set(ips or [])):
        if ip in ("127.0.0.1", ""):
            continue
        try:
            sans.append(x509.IPAddress(ipaddress.ip_address(ip)))
        except ValueError:
            pass
    seen = set()
    for h in (hostnames or []):
        for cand in (h, h + ".local"):
            cand = cand.strip().lower()
            if cand and cand != "localhost" and cand not in seen:
                seen.add(cand)
                try:
                    sans.append(x509.DNSName(cand))
                except Exception:  # noqa: BLE001
                    pass

    now = datetime.datetime.now(datetime.timezone.utc)
    leaf = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=397))    # iOS вимагає ≤398 днів для leaf
        .add_extension(x509.SubjectAlternativeName(sans), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(
            digital_signature=True, content_commitment=False, key_encipherment=True,
            data_encipherment=False, key_agreement=False, key_cert_sign=False,
            crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
        .sign(ca_key, hashes.SHA256())
    )

    leaf_key_path.write_bytes(key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()))
    # Повний ланцюг: leaf + CA (щоб сервер віддавав і проміжний корінь)
    chain = leaf.public_bytes(serialization.Encoding.PEM) \
        + ca_cert.public_bytes(serialization.Encoding.PEM)
    leaf_cert_path.write_bytes(chain)
