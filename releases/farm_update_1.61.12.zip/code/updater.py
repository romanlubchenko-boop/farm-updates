"""Безпечний апдейтер додатка.

Пакет оновлення — це zip-файл `farm_update_<версія>.zip`, у корені якого:
    update.json          — маніфест: {app_version, schema_version, notes, created}
    code/...             — новий код папки app/ (без data/, config/, .venv)

Джерело оновлення (update_source) — або шлях до папки/файлу .zip, або URL.

Безпека:
  • стейджинг (копія zip у локальну папку) робиться на живому сервері;
  • САМЕ ЗАСТОСУВАННЯ — на старті (start_server) до імпорту коду, щоб не
    замінювати зайняті файли;
  • перед заміною робиться резервна копія поточного коду (code_backups/);
  • новий код перевіряється py_compile; якщо не компілюється — автовідкат.
"""

from __future__ import annotations

import io
import os
import re
import sys
import json
import shutil
import zipfile
import tempfile
import py_compile
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

MANIFEST_NAME = "update.json"
UPDATE_GLOB = "farm_update_*.zip"
# Папки/файли, які НІКОЛИ не входять у пакет і не чіпаються при оновленні.
PRESERVE = {"data", "config", ".venv", "__pycache__", ".git", ".idea"}
# Файли, які мають скомпілюватись після оновлення (контроль цілісності).
VERIFY_FILES = ("web_app.py", "start_server.py", os.path.join("vet_pharmacy", "web_db.py"))


def _local_state_dir() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "FarmDB"


STATE_DIR = _local_state_dir()
STAGED_ZIP = STATE_DIR / "update_staged.zip"
STAGED_META = STATE_DIR / "update_staged.json"
CODE_BACKUP_DIR = STATE_DIR / "code_backups"


# ---------------------------------------------------------------- версії

def parse_version(v: Any) -> tuple:
    parts = []
    for x in str(v or "").strip().split("."):
        try:
            parts.append(int(x))
        except ValueError:
            parts.append(0)
    return tuple(parts) or (0,)


def is_newer(candidate: str, current: str) -> bool:
    return parse_version(candidate) > parse_version(current)


# ---------------------------------------------------------------- джерело

def _read_manifest_from_zip(zip_path: Path) -> Optional[dict]:
    try:
        with zipfile.ZipFile(zip_path) as z:
            with z.open(MANIFEST_NAME) as f:
                data = json.load(f)
        return data if isinstance(data, dict) else None
    except (KeyError, OSError, zipfile.BadZipFile, ValueError):
        return None


def _verify_package_signature(zip_path: Path, manifest: dict) -> str:
    """Перевірка автентичності пакета. Повертає '' якщо все гаразд, інакше
    текст помилки.

    Логіка (перехідний період): якщо пакет ПІДПИСАНИЙ — підпис мусить бути
    валідним, а вміст code/ — відповідати code_hash у підписаному маніфесті.
    Якщо підпису немає (старі пакети) — поки що пропускаємо (сумісність).
    Після оновлення всіх клієнтів підпис стане обовʼязковим (див. план)."""
    try:
        import update_signing
    except Exception:  # noqa: BLE001
        # Модуль перевірки недоступний — не блокуємо (старий код)
        return ""
    if not update_signing.has_signature(manifest):
        return ""   # перехідний період: непідписані пакети ще дозволені
    if not update_signing.verify_manifest_signature(manifest):
        return ("Підпис оновлення недійсний — пакет міг бути підмінений. "
                "Оновлення відхилено.")
    # Підпис валідний → звіряємо фактичний вміст code/ із підписаним code_hash
    try:
        pairs = []
        with zipfile.ZipFile(zip_path) as z:
            for name in z.namelist():
                if name.startswith("code/") and not name.endswith("/"):
                    pairs.append((name[len("code/"):], z.read(name)))
        actual = update_signing.code_hash_from_pairs(pairs)
    except (OSError, zipfile.BadZipFile) as exc:
        return f"Пакет не читається при перевірці підпису: {exc}"
    if actual != str(manifest.get("code_hash", "")):
        return ("Вміст оновлення не відповідає підпису — пакет пошкоджено або "
                "підмінено. Оновлення відхилено.")
    return ""


def _download_url(url: str, dest: Path) -> str:
    """Завантажити файл за URL у dest. Повертає '' при успіху або текст помилки.

    Як і для Telegram: на ПК антивірус/проксі часто підміняє TLS-сертифікат,
    і перевірка падає. Тому при помилці саме перевірки сертифіката пробуємо
    повторно без жорсткої перевірки."""
    import ssl

    # Деякі хости дають 403 на «не-браузерні» запити, тож представляємось браузером.
    # No-cache — щоб CDN (напр. raw.githubusercontent.com) не віддавав застарілий
    # latest.json після свіжої публікації нової версії.
    _headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/124.0 Safari/537.36"),
        "Accept": "*/*",
        "Cache-Control": "no-cache, no-store, max-age=0",
        "Pragma": "no-cache",
    }

    def _fetch(ctx) -> None:
        req = urllib.request.Request(url, headers=_headers)
        with urllib.request.urlopen(req, timeout=60, context=ctx) as resp, \
                open(dest, "wb") as f:
            shutil.copyfileobj(resp, f)

    # 1) Спроба зі звичайною перевіркою сертифіката.
    try:
        _fetch(ssl.create_default_context())
        return ""
    except urllib.error.HTTPError as exc:
        return f"HTTP {exc.code}: {exc.reason}"
    except Exception:  # noqa: BLE001
        pass  # будь-яка помилка → пробуємо без перевірки (антивірус/проксі/брак CA)

    # 2) Повтор без перевірки сертифіката (для локального ПК це прийнятно).
    try:
        _fetch(ssl._create_unverified_context())
        return ""
    except urllib.error.HTTPError as exc:
        return f"HTTP {exc.code}: {exc.reason}"
    except Exception as exc:  # noqa: BLE001
        return f"навіть без перевірки сертифіката: {exc}"


def resolve_source_zip(source: str, tmpdir: Path) -> tuple[Optional[Path], str]:
    """Повертає (шлях_до_zip, помилка). URL завантажується у tmpdir."""
    source = (source or "").strip()
    if not source:
        return None, "Джерело оновлення не задано."
    if source.lower().startswith(("http://", "https://")):
        dest = tmpdir / "update_dl.zip"
        err = _download_url(source, dest)
        if err:
            return None, f"Не вдалося завантажити оновлення з URL — {err}"
        return dest, ""
    p = Path(source).expanduser()
    if p.is_file() and p.suffix.lower() == ".zip":
        return p, ""
    if p.is_dir():
        zips = list(p.glob(UPDATE_GLOB))
        if not zips:
            return None, "У папці немає файлів оновлення (farm_update_*.zip)."

        def _ver_of(path: Path) -> tuple:
            # Беремо найбільшу ВЕРСІЮ, а не лексично найбільшу назву
            # (інакше 1.1.9 «більше» за 1.1.10). Резерв — mtime.
            m = re.match(r"farm_update_(.+)\.zip$", path.name)
            return (parse_version(m.group(1)) if m else (0,), path.stat().st_mtime)

        return max(zips, key=_ver_of), ""
    return None, "Джерело не знайдено (немає такої папки чи файлу)."


def _is_manifest_url(source: str) -> bool:
    """Чи є джерело посиланням на маніфест latest.json (а не на сам zip)."""
    s = (source or "").strip().lower()
    return (s.startswith(("http://", "https://"))
            and s.split("?", 1)[0].rstrip("/").endswith(".json"))


def _load_manifest_url(source: str, tmpdir: Path) -> tuple[Optional[dict], str]:
    """Завантажити й розпарсити latest.json. Повертає (dict, помилка)."""
    dest = tmpdir / "latest.json"
    # Кеш-бастер: унікальний параметр змушує CDN віддати свіжий файл, а не
    # закешовану стару версію (важливо при частих публікаціях).
    import time as _time
    sep = "&" if "?" in source else "?"
    busted = f"{source}{sep}cb={int(_time.time())}"
    err = _download_url(busted, dest)
    if err:
        return None, f"Не вдалося завантажити маніфест (latest.json) — {err}"
    try:
        data = json.loads(dest.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return None, f"Маніфест не читається (очікувався JSON): {exc}"
    if not str(data.get("app_version", "")).strip():
        return None, "У маніфесті немає поля app_version."
    if not str(data.get("url", "")).strip():
        return None, "У маніфесті немає поля url (посилання на пакет)."
    return data, ""


def check_update(source: str, current_app_version: str) -> dict:
    """Перевірити джерело: яка там версія і чи вона новіша за поточну.

    Підтримує два формати URL: пряме посилання на zip або на маніфест
    latest.json (тоді перевірка дешева — качається лише маленький JSON)."""
    # Легка перевірка через маніфест — без завантаження архіву
    if _is_manifest_url(source):
        with tempfile.TemporaryDirectory() as td:
            man, err = _load_manifest_url(source, Path(td))
            if err:
                return {"ok": False, "error": err}
            latest = str(man.get("app_version", ""))
            return {
                "ok": True,
                "available": is_newer(latest, current_app_version),
                "current": current_app_version,
                "latest": latest,
                "schema_version": man.get("schema_version"),
                "notes": man.get("notes", ""),
                "created": man.get("created", ""),
            }

    with tempfile.TemporaryDirectory() as td:
        zip_path, err = resolve_source_zip(source, Path(td))
        if err:
            return {"ok": False, "error": err}
        manifest = _read_manifest_from_zip(zip_path)
        if not manifest:
            return {"ok": False, "error": "У пакеті немає коректного update.json."}
        latest = str(manifest.get("app_version", ""))
        return {
            "ok": True,
            "available": is_newer(latest, current_app_version),
            "current": current_app_version,
            "latest": latest,
            "schema_version": manifest.get("schema_version"),
            "notes": manifest.get("notes", ""),
            "created": manifest.get("created", ""),
        }


def stage_update(source: str, current_app_version: str,
                 allow_same: bool = False) -> dict:
    """Скопіювати пакет у staged-зону. Застосується при наступному старті."""
    with tempfile.TemporaryDirectory() as td:
        tdp = Path(td)
        if _is_manifest_url(source):
            man, err = _load_manifest_url(source, tdp)
            if err:
                return {"ok": False, "error": err}
            zip_url = str(man.get("url", "")).strip()
            zip_path = tdp / "update_dl.zip"
            derr = _download_url(zip_url, zip_path)
            if derr:
                return {"ok": False,
                        "error": f"Не вдалося завантажити пакет за посиланням "
                                 f"з маніфесту — {derr}"}
        else:
            zip_path, err = resolve_source_zip(source, tdp)
            if err:
                return {"ok": False, "error": err}
        manifest = _read_manifest_from_zip(zip_path)
        if not manifest:
            return {"ok": False, "error": "У пакеті немає коректного update.json."}
        latest = str(manifest.get("app_version", ""))
        if not allow_same and not is_newer(latest, current_app_version):
            return {"ok": False,
                    "error": f"У джерелі версія {latest or '?'} не новіша за "
                             f"поточну {current_app_version}."}
        # перевірка автентичності (підпис) — до будь-яких дій із пакетом
        sig_err = _verify_package_signature(zip_path, manifest)
        if sig_err:
            return {"ok": False, "error": sig_err}
        # перевірка цілісності zip
        try:
            with zipfile.ZipFile(zip_path) as z:
                if z.testzip() is not None:
                    return {"ok": False, "error": "Пакет пошкоджено (zip)."}
                names = z.namelist()
            if not any(n.startswith("code/") and not n.endswith("/") for n in names):
                return {"ok": False, "error": "У пакеті немає коду (папки code/)."}
        except (OSError, zipfile.BadZipFile) as exc:
            return {"ok": False, "error": f"Пакет не читається: {exc}"}
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            STAGED_ZIP.write_bytes(Path(zip_path).read_bytes())
            STAGED_META.write_text(json.dumps({
                "app_version": latest,
                "schema_version": manifest.get("schema_version"),
                "notes": manifest.get("notes", ""),
                "staged_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "from": "url" if source.lower().startswith(("http://", "https://")) else "folder",
            }, ensure_ascii=False), encoding="utf-8")
        except OSError as exc:
            return {"ok": False, "error": f"Не вдалося підготувати оновлення: {exc}"}
        return {"ok": True, "app_version": latest, "notes": manifest.get("notes", "")}


def staged_info() -> Optional[dict]:
    """Інформація про підготовлене оновлення (якщо є), інакше None."""
    if not STAGED_ZIP.exists() or not STAGED_META.exists():
        return None
    try:
        return json.loads(STAGED_META.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"app_version": "?"}


def cancel_staged() -> None:
    for p in (STAGED_ZIP, STAGED_META):
        try:
            p.unlink()
        except OSError:
            pass


# ------------------------------------------------- застосування (на старті)

def _iter_code_files(app_dir: Path):
    for root, dirs, files in os.walk(app_dir):
        # ⚠️ Урок 2026-08-30: клієнтські налаштування з Windows-шляхами
        # («C:\Users\…») на Mac створювали в app/ теки з БЕКАПАМИ БД, і ті
        # потрапляли в опубліковані пакети (витік даних). Тому: жодних тек
        # зі слешем/двокрапкою в імені і жодних БД/бекапів у пакеті.
        dirs[:] = [d for d in dirs if d not in PRESERVE
                   and ":" not in d and "\\" not in d]
        for f in files:
            if f.endswith((".pyc", ".log", ".db", ".db-wal", ".db-shm",
                           ".sqlite", ".DS_Store")) \
                    or ".bak" in f or f == "launcher_debug.log":
                continue
            yield Path(root) / f


def _backup_current_code(app_dir: Path, label: str) -> Path:
    CODE_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    dest = CODE_BACKUP_DIR / f"code_before_{label}_{ts}.zip"
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in _iter_code_files(app_dir):
            z.write(fp, fp.relative_to(app_dir).as_posix())
    return dest


def _extract_new_code(zip_path: Path, app_dir: Path) -> None:
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            if not name.startswith("code/") or name.endswith("/"):
                continue
            rel = name[len("code/"):]
            # захист від виходу за межі папки
            target = (app_dir / rel).resolve()
            if not str(target).startswith(str(app_dir.resolve())):
                continue
            top = rel.split("/", 1)[0]
            if top in PRESERVE:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, open(target, "wb") as out:
                out.write(src.read())


def _verify_code(app_dir: Path) -> None:
    for rel in VERIFY_FILES:
        fp = app_dir / rel
        if fp.exists():
            py_compile.compile(str(fp), doraise=True)


def _restore_code(backup_zip: Path, app_dir: Path) -> None:
    with zipfile.ZipFile(backup_zip) as z:
        for name in z.namelist():
            if name.endswith("/"):
                continue
            target = (app_dir / name).resolve()
            if not str(target).startswith(str(app_dir.resolve())):
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, open(target, "wb") as out:
                out.write(src.read())


def _current_app_version(app_dir: Path) -> str:
    """Поточна версія коду (APP_VERSION у web_app.py), для звірки зі staged."""
    try:
        import re as _re
        txt = (app_dir / "web_app.py").read_text(encoding="utf-8")
        m = _re.search(r'^APP_VERSION\s*=\s*"([^"]+)"', txt, _re.M)
        return m.group(1) if m else ""
    except Exception:  # noqa: BLE001
        return ""


def apply_staged_update(app_dir: Path) -> dict:
    """Викликати на СТАРТІ до імпорту коду. Якщо є застейджене оновлення —
    робить бекап коду, застосовує, перевіряє; при помилці — відкочує."""
    if not STAGED_ZIP.exists():
        return {"applied": False}
    meta = staged_info() or {}
    ver = str(meta.get("app_version", "?"))

    # Запобіжник: не застосовувати пакет, версія якого НЕ новіша за поточну.
    # Це «залишок» уже застосованого оновлення — чистимо й не чіпаємо код,
    # щоб воно не «ставилось» повторно при кожному перезапуску.
    cur = _current_app_version(app_dir)
    if cur and ver != "?" and not is_newer(ver, cur):
        cancel_staged()
        return {"applied": False, "skipped": True, "app_version": ver}

    # Повторна перевірка підпису перед застосуванням (захист у глибину):
    # навіть якщо staged-zip хтось підмінив локально — без валідного підпису
    # код не застосується.
    staged_manifest = _read_manifest_from_zip(STAGED_ZIP)
    if staged_manifest is None:
        cancel_staged()
        return {"applied": False, "error": "Підготовлений пакет пошкоджено."}
    sig_err = _verify_package_signature(STAGED_ZIP, staged_manifest)
    if sig_err:
        cancel_staged()
        return {"applied": False, "error": sig_err}

    try:
        backup = _backup_current_code(app_dir, ver)
    except Exception as exc:  # noqa: BLE001
        cancel_staged()
        return {"applied": False, "error": f"Не вдалося зберегти копію коду: {exc}"}
    try:
        _extract_new_code(STAGED_ZIP, app_dir)
        _verify_code(app_dir)
    except Exception as exc:  # noqa: BLE001
        try:
            _restore_code(backup, app_dir)
        except Exception:  # noqa: BLE001
            pass
        cancel_staged()
        return {"applied": False, "error": str(exc), "rolled_back": True,
                "backup": str(backup)}
    cancel_staged()
    return {"applied": True, "app_version": ver, "backup": str(backup)}
