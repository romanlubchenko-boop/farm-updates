from __future__ import annotations

import json
from pathlib import Path


CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "ui_settings.json"


DEFAULT_UI_SETTINGS = {
    "window": {
        "title": "Ветаптека",
        "width": 1360,
        "height": 860,
        "min_width": 1120,
        "min_height": 720,
    },
    "fonts": {
        "family": "Avenir Next",
        "header_size": 28,
        "subheader_size": 11,
        "title_size": 18,
        "body_size": 12,
        "label_size": 10,
        "button_size": 12,
        "stat_size": 24,
        "entry_size": 14,
        "scan_entry_size": 20,
        "tree_size": 11,
        "tree_heading_size": 10,
    },
    "layout": {
        "header_pad_x": 24,
        "header_pad_y": 22,
        "body_padding": 18,
        "panel_padding": 14,
        "hero_panel_padding": 18,
        "stats_gap": 8,
        "section_gap": 10,
        "tab_padding": 10,
        "tree_row_height": 32,
        "scan_wraplength": 540,
        "hint_wraplength": 520,
    },
    "panels": {
        "dashboard_left_weight": 1,
        "dashboard_right_weight": 2,
        "scan_left_weight": 5,
        "scan_right_weight": 4,
        "products_list_weight": 3,
        "products_form_weight": 2,
    },
    "columns": {
        "low_stock": {
            "name": 240,
            "barcode": 150,
            "qty": 90,
            "min_stock": 90,
        },
        "recent_moves": {
            "created_at": 155,
            "name": 220,
            "move_type": 70,
            "qty": 70,
            "lot": 110,
            "note": 200,
        },
        "products": {
            "name": 260,
            "barcode": 145,
            "unit": 55,
            "qty": 90,
            "min_stock": 70,
            "supplier": 170,
        },
    },
}


def load_ui_settings() -> dict:
    if not CONFIG_PATH.exists():
        return DEFAULT_UI_SETTINGS
    with CONFIG_PATH.open("r", encoding="utf-8") as file:
        loaded = json.load(file)
    return _merge(DEFAULT_UI_SETTINGS, loaded)


def save_ui_settings(settings: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with CONFIG_PATH.open("w", encoding="utf-8") as file:
        json.dump(settings, file, ensure_ascii=False, indent=2)


def _merge(base: dict, override: dict) -> dict:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            merged[key] = _merge(base[key], value)
        else:
            merged[key] = value
    return merged
