from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

from vet_pharmacy.config import load_ui_settings, save_ui_settings
from vet_pharmacy.db import InventoryDB, Product


class VetPharmacyApp:
    def __init__(self) -> None:
        self.db = InventoryDB()
        self.ui = load_ui_settings()
        self.fonts = self.ui["fonts"]
        self.layout = self.ui["layout"]
        self.panel_weights = self.ui["panels"]
        self.column_sizes = self.ui["columns"]
        window = self.ui["window"]
        self.root = tk.Tk()
        self.root.title(window["title"])
        self.root.geometry(f'{window["width"]}x{window["height"]}')
        self.root.minsize(window["min_width"], window["min_height"])
        self.root.configure(bg="#ffffff")

        self.colors = {
            "bg": "#ffffff",
            "panel": "#f8fbff",
            "ink": "#16324f",
            "muted": "#6b87a3",
            "accent": "#1787d6",
            "accent_soft": "#dff2ff",
            "warn": "#ef6b73",
            "warn_soft": "#ffe7ea",
            "line": "#cfe3f5",
            "dark": "#0d5ea8",
        }
        self.font_family = self.fonts["family"]

        self.selected_product: Product | None = None

        self.status_var = tk.StringVar(value="Готово до сканування")
        self.search_barcode_var = tk.StringVar()
        self.scan_qty_var = tk.StringVar(value="1")
        self.receive_lot_var = tk.StringVar()
        self.receive_expiry_var = tk.StringVar()
        self.scan_note_var = tk.StringVar()

        self.product_name_var = tk.StringVar()
        self.product_barcode_var = tk.StringVar()
        self.product_unit_var = tk.StringVar(value="шт")
        self.product_min_stock_var = tk.StringVar(value="0")
        self.product_supplier_var = tk.StringVar()
        self.product_notes_var = tk.StringVar()
        self.settings_vars: dict[str, tk.StringVar] = {}

        self.total_items_var = tk.StringVar(value="0")
        self.total_stock_var = tk.StringVar(value="0")
        self.low_stock_count_var = tk.StringVar(value="0")
        self.scan_info_title_var = tk.StringVar(value="Скануйте штрихкод")
        self.scan_info_meta_var = tk.StringVar(value="Сканер MC-3303L працює як клавіатура: курсор у полі, сканування, Enter.")

        self._configure_styles()
        self._build_layout()
        self.refresh_all()

    def _configure_styles(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=self.colors["bg"], foreground=self.colors["ink"])
        style.configure("App.TFrame", background=self.colors["bg"])
        style.configure("Panel.TFrame", background=self.colors["panel"])
        style.configure(
            "Header.TLabel",
            background=self.colors["dark"],
            foreground="#fffdf8",
            font=(self.font_family, self.fonts["header_size"], "bold"),
        )
        style.configure(
            "SubHeader.TLabel",
            background=self.colors["dark"],
            foreground="#d8e9e2",
            font=(self.font_family, self.fonts["subheader_size"]),
        )
        style.configure(
            "Title.TLabel",
            background=self.colors["panel"],
            foreground=self.colors["ink"],
            font=(self.font_family, self.fonts["title_size"], "bold"),
        )
        style.configure(
            "Muted.TLabel",
            background=self.colors["panel"],
            foreground=self.colors["muted"],
            font=(self.font_family, self.fonts["subheader_size"]),
        )
        style.configure(
            "FormLabel.TLabel",
            background=self.colors["panel"],
            foreground=self.colors["muted"],
            font=(self.font_family, self.fonts["label_size"], "bold"),
        )
        style.configure(
            "StatValue.TLabel",
            background=self.colors["panel"],
            foreground=self.colors["ink"],
            font=(self.font_family, self.fonts["stat_size"], "bold"),
        )
        style.configure(
            "StatCaption.TLabel",
            background=self.colors["panel"],
            foreground=self.colors["muted"],
            font=(self.font_family, self.fonts["label_size"]),
        )
        style.configure(
            "Primary.TButton",
            background=self.colors["accent"],
            foreground="#ffffff",
            borderwidth=0,
            focusthickness=0,
            focuscolor=self.colors["accent"],
            font=(self.font_family, self.fonts["button_size"], "bold"),
            padding=(18, 12),
        )
        style.map("Primary.TButton", background=[("active", "#0f6fb2")])
        style.configure(
            "Danger.TButton",
            background=self.colors["warn"],
            foreground="#ffffff",
            borderwidth=0,
            focusthickness=0,
            focuscolor=self.colors["warn"],
            font=(self.font_family, self.fonts["button_size"], "bold"),
            padding=(18, 12),
        )
        style.map("Danger.TButton", background=[("active", "#d3525b")])
        style.configure(
            "Ghost.TButton",
            background=self.colors["panel"],
            foreground=self.colors["ink"],
            bordercolor=self.colors["line"],
            relief="solid",
            font=(self.font_family, self.fonts["subheader_size"], "bold"),
            padding=(16, 10),
        )
        style.map("Ghost.TButton", background=[("active", "#eef7ff")])
        style.configure(
            "App.TNotebook",
            background=self.colors["bg"],
            borderwidth=0,
            tabmargins=(0, 0, 0, 0),
        )
        style.configure(
            "App.TNotebook.Tab",
            font=(self.font_family, self.fonts["button_size"], "bold"),
            padding=(18, 10),
            background="#e9f4fd",
            foreground=self.colors["ink"],
            borderwidth=0,
        )
        style.map(
            "App.TNotebook.Tab",
            background=[("selected", self.colors["panel"])],
            foreground=[("selected", self.colors["accent"])],
        )
        style.configure(
            "App.Treeview",
            background="#fffdf9",
            fieldbackground="#fffdf9",
            foreground=self.colors["ink"],
            bordercolor=self.colors["line"],
            rowheight=self.layout["tree_row_height"],
            font=(self.font_family, self.fonts["tree_size"]),
        )
        style.configure(
            "App.Treeview.Heading",
            background="#eaf5ff",
            foreground=self.colors["ink"],
            font=(self.font_family, self.fonts["tree_heading_size"], "bold"),
            relief="flat",
        )
        style.map(
            "App.Treeview",
            background=[("selected", self.colors["accent_soft"])],
            foreground=[("selected", self.colors["ink"])],
        )

    def _build_layout(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        header = tk.Frame(
            self.root,
            bg=self.colors["dark"],
            padx=self.layout["header_pad_x"],
            pady=self.layout["header_pad_y"],
        )
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        ttk.Label(header, text="Ветаптека", style="Header.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            header,
            text="Швидкий облік медикаментів, партій і видачі зі сканера",
            style="SubHeader.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))

        header_right = tk.Frame(header, bg=self.colors["dark"])
        header_right.grid(row=0, column=1, rowspan=2, sticky="e")
        tk.Label(
            header_right,
            textvariable=self.status_var,
            bg="#2f7fc6",
            fg="#f7fcff",
            font=(self.font_family, self.fonts["subheader_size"], "bold"),
            padx=14,
            pady=10,
        ).pack()

        body = ttk.Frame(self.root, style="App.TFrame", padding=self.layout["body_padding"])
        body.grid(row=1, column=0, sticky="nsew")
        body.columnconfigure(0, weight=1)
        body.rowconfigure(1, weight=1)

        stats = ttk.Frame(body, style="App.TFrame")
        stats.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        for index in range(3):
            stats.columnconfigure(index, weight=1)

        self._create_stat_card(stats, 0, "Номенклатура", self.total_items_var, "Активні позиції")
        self._create_stat_card(stats, 1, "Залишок", self.total_stock_var, "Одиниць у системі")
        self._create_stat_card(stats, 2, "Ризик", self.low_stock_count_var, "Нижче мінімуму")

        notebook = ttk.Notebook(body, style="App.TNotebook")
        notebook.grid(row=1, column=0, sticky="nsew")

        self.dashboard_tab = ttk.Frame(notebook, style="App.TFrame", padding=self.layout["tab_padding"])
        self.scan_tab = ttk.Frame(notebook, style="App.TFrame", padding=self.layout["tab_padding"])
        self.products_tab = ttk.Frame(notebook, style="App.TFrame", padding=self.layout["tab_padding"])
        self.settings_tab = ttk.Frame(notebook, style="App.TFrame", padding=self.layout["tab_padding"])

        notebook.add(self.settings_tab, text="Настройки UI")
        notebook.add(self.dashboard_tab, text="Огляд")
        notebook.add(self.scan_tab, text="Сканер")
        notebook.add(self.products_tab, text="Товари")

        self._build_dashboard_tab()
        self._build_scan_tab()
        self._build_products_tab()
        self._build_settings_tab()

    def _build_dashboard_tab(self) -> None:
        self.dashboard_tab.columnconfigure(0, weight=1)
        self.dashboard_tab.rowconfigure(0, weight=1)

        split = self._create_splitter(self.dashboard_tab, orient="horizontal")
        split.grid(row=0, column=0, sticky="nsew")

        low_stock_frame = self._panel(split)
        low_stock_frame.columnconfigure(0, weight=1)
        low_stock_frame.rowconfigure(1, weight=1)
        ttk.Label(low_stock_frame, text="Критичні залишки", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            low_stock_frame,
            text="Тут товари, які вже на межі або нижче порогу.",
            style="Muted.TLabel",
        ).grid(row=0, column=1, sticky="e")

        self.low_stock_tree = ttk.Treeview(
            low_stock_frame,
            columns=("name", "barcode", "qty", "min_stock"),
            show="headings",
            style="App.Treeview",
            height=18,
        )
        for name, title, width in (
            ("name", "Товар", self.column_sizes["low_stock"]["name"]),
            ("barcode", "Штрихкод", self.column_sizes["low_stock"]["barcode"]),
            ("qty", "Залишок", self.column_sizes["low_stock"]["qty"]),
            ("min_stock", "Мінімум", self.column_sizes["low_stock"]["min_stock"]),
        ):
            self.low_stock_tree.heading(name, text=title)
            self.low_stock_tree.column(name, width=width, anchor="w")
        self.low_stock_tree.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(14, 0))

        recent_moves_frame = self._panel(split)
        recent_moves_frame.columnconfigure(0, weight=1)
        recent_moves_frame.rowconfigure(1, weight=1)
        ttk.Label(recent_moves_frame, text="Останні рухи", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            recent_moves_frame,
            text="Історія приходу і видачі по партіях.",
            style="Muted.TLabel",
        ).grid(row=0, column=1, sticky="e")

        self.recent_moves_tree = ttk.Treeview(
            recent_moves_frame,
            columns=("created_at", "name", "move_type", "qty", "lot", "note"),
            show="headings",
            style="App.Treeview",
            height=18,
        )
        for name, title, width in (
            ("created_at", "Дата", self.column_sizes["recent_moves"]["created_at"]),
            ("name", "Товар", self.column_sizes["recent_moves"]["name"]),
            ("move_type", "Тип", self.column_sizes["recent_moves"]["move_type"]),
            ("qty", "К-сть", self.column_sizes["recent_moves"]["qty"]),
            ("lot", "Партія", self.column_sizes["recent_moves"]["lot"]),
            ("note", "Коментар", self.column_sizes["recent_moves"]["note"]),
        ):
            self.recent_moves_tree.heading(name, text=title)
            self.recent_moves_tree.column(name, width=width, anchor="w")
        self.recent_moves_tree.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(14, 0))

        split.add(low_stock_frame, minsize=320, stretch="always")
        split.add(recent_moves_frame, minsize=420, stretch="always")

    def _build_scan_tab(self) -> None:
        self.scan_tab.columnconfigure(0, weight=1)
        self.scan_tab.rowconfigure(0, weight=1)

        vertical_split = self._create_splitter(self.scan_tab, orient="vertical")
        vertical_split.grid(row=0, column=0, sticky="nsew")

        hero = self._panel(vertical_split, pad=self.layout["hero_panel_padding"])
        hero.columnconfigure(1, weight=1)

        ttk.Label(hero, text="Робоча зона сканера", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            hero,
            text="Фокус у полі нижче, далі сканер вводить код і відразу знаходить позицію.",
            style="Muted.TLabel",
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 14))

        ttk.Label(hero, text="Штрихкод", style="FormLabel.TLabel").grid(row=2, column=0, sticky="w", padx=(0, 10))
        self.barcode_entry = ttk.Entry(hero, textvariable=self.search_barcode_var, font=(self.font_family, self.fonts["scan_entry_size"]))
        self.barcode_entry.grid(row=2, column=1, sticky="ew")
        self.barcode_entry.bind("<Return>", self.handle_scan_lookup)
        self.barcode_entry.focus_set()
        ttk.Button(hero, text="Знайти", style="Primary.TButton", command=self.handle_scan_lookup).grid(
            row=2, column=2, padx=(10, 0)
        )

        lower_split = self._create_splitter(vertical_split, orient="horizontal")

        left = self._panel(lower_split)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(3, weight=1)

        ttk.Label(left, textvariable=self.scan_info_title_var, style="Title.TLabel").grid(row=0, column=0, sticky="w")
        self.scan_info_meta_label = tk.Label(
            left,
            textvariable=self.scan_info_meta_var,
            bg=self.colors["panel"],
            fg=self.colors["muted"],
            justify="left",
            font=(self.font_family, self.fonts["body_size"]),
            wraplength=self.layout["scan_wraplength"],
        )
        self.scan_info_meta_label.grid(row=1, column=0, sticky="w", pady=(8, 18))

        info_band = tk.Frame(left, bg=self.colors["accent_soft"], padx=16, pady=14)
        info_band.grid(row=2, column=0, sticky="ew")
        tk.Label(
            info_band,
            text="Підказка",
            bg=self.colors["accent_soft"],
            fg=self.colors["accent"],
            font=(self.font_family, self.fonts["label_size"], "bold"),
        ).pack(anchor="w")
        tk.Label(
            info_band,
            text="Для нового приходу заповніть партію і термін. Для видачі достатньо кількості.",
            bg=self.colors["accent_soft"],
            fg=self.colors["ink"],
            font=(self.font_family, self.fonts["body_size"]),
            wraplength=self.layout["hint_wraplength"],
            justify="left",
        ).pack(anchor="w", pady=(6, 0))

        right = self._panel(lower_split)
        for column in range(2):
            right.columnconfigure(column, weight=1)
        right.rowconfigure(10, weight=1)

        fields = [
            ("Кількість", self.scan_qty_var),
            ("Партія", self.receive_lot_var),
            ("Термін придатності", self.receive_expiry_var),
            ("Коментар", self.scan_note_var),
        ]
        for row_index, (label, variable) in enumerate(fields):
            ttk.Label(right, text=label, style="FormLabel.TLabel").grid(row=row_index * 2, column=0, columnspan=2, sticky="w")
            ttk.Entry(right, textvariable=variable, font=(self.font_family, self.fonts["entry_size"])).grid(
                row=row_index * 2 + 1, column=0, columnspan=2, sticky="ew", pady=(4, 12)
            )

        ttk.Button(right, text="Оформити прихід", style="Primary.TButton", command=self.handle_receive).grid(
            row=8, column=0, sticky="ew", pady=(8, 0), padx=(0, 8)
        )
        ttk.Button(right, text="Оформити видачу", style="Danger.TButton", command=self.handle_dispense).grid(
            row=8, column=1, sticky="ew", pady=(8, 0)
        )
        ttk.Button(right, text="Очистити форму", style="Ghost.TButton", command=self.reset_scan_form).grid(
            row=9, column=0, columnspan=2, sticky="ew", pady=(10, 0)
        )
        lower_split.add(left, minsize=420, stretch="always")
        lower_split.add(right, minsize=360, stretch="always")
        vertical_split.add(hero, minsize=150, stretch="never")
        vertical_split.add(lower_split, minsize=420, stretch="always")

    def _build_products_tab(self) -> None:
        self.products_tab.columnconfigure(0, weight=1)
        self.products_tab.rowconfigure(0, weight=1)

        split = self._create_splitter(self.products_tab, orient="horizontal")
        split.grid(row=0, column=0, sticky="nsew")

        list_frame = self._panel(split)
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(1, weight=1)

        ttk.Label(list_frame, text="Номенклатура", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            list_frame,
            text="Вибір товару автоматично підставляє штрихкод у вкладку сканера.",
            style="Muted.TLabel",
        ).grid(row=0, column=1, sticky="e")

        self.products_tree = ttk.Treeview(
            list_frame,
            columns=("name", "barcode", "unit", "qty", "min_stock", "supplier"),
            show="headings",
            style="App.Treeview",
            height=20,
        )
        for name, title, width in (
            ("name", "Товар", self.column_sizes["products"]["name"]),
            ("barcode", "Штрихкод", self.column_sizes["products"]["barcode"]),
            ("unit", "Од.", self.column_sizes["products"]["unit"]),
            ("qty", "Залишок", self.column_sizes["products"]["qty"]),
            ("min_stock", "Мін.", self.column_sizes["products"]["min_stock"]),
            ("supplier", "Постачальник", self.column_sizes["products"]["supplier"]),
        ):
            self.products_tree.heading(name, text=title)
            self.products_tree.column(name, width=width, anchor="w")
        self.products_tree.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(14, 0))
        self.products_tree.bind("<<TreeviewSelect>>", self.handle_product_select)

        form_frame = self._panel(split)
        form_frame.columnconfigure(0, weight=1)

        ttk.Label(form_frame, text="Новий товар", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            form_frame,
            text="Додавайте позиції зі штрихкодом одразу під сканер.",
            style="Muted.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 14))

        fields = [
            ("Назва", self.product_name_var),
            ("Штрихкод", self.product_barcode_var),
            ("Одиниця", self.product_unit_var),
            ("Мінімальний залишок", self.product_min_stock_var),
            ("Постачальник", self.product_supplier_var),
            ("Нотатки", self.product_notes_var),
        ]
        for row_index, (label, variable) in enumerate(fields, start=2):
            ttk.Label(form_frame, text=label, style="FormLabel.TLabel").grid(row=(row_index - 2) * 2 + 2, column=0, sticky="w")
            ttk.Entry(form_frame, textvariable=variable, font=(self.font_family, self.fonts["entry_size"])).grid(
                row=(row_index - 2) * 2 + 3, column=0, sticky="ew", pady=(4, 12)
            )

        ttk.Button(form_frame, text="Додати товар", style="Primary.TButton", command=self.handle_add_product).grid(
            row=20, column=0, sticky="ew", pady=(8, 0)
        )
        split.add(list_frame, minsize=520, stretch="always")
        split.add(form_frame, minsize=360, stretch="always")

    def _build_settings_tab(self) -> None:
        self.settings_tab.columnconfigure(0, weight=1)
        self.settings_tab.rowconfigure(0, weight=1)

        split = self._create_splitter(self.settings_tab, orient="horizontal")
        split.grid(row=0, column=0, sticky="nsew")

        left = self._panel(split)
        left.columnconfigure(0, weight=1)

        ttk.Label(left, text="Настройки интерфейса", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            left,
            text="Изменения сохраняются в JSON и применяются после перезапуска окна.",
            style="Muted.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 14))

        settings_fields = [
            ("Название окна", "window.title"),
            ("Ширина окна", "window.width"),
            ("Высота окна", "window.height"),
            ("Мин. ширина", "window.min_width"),
            ("Мин. высота", "window.min_height"),
            ("Шрифт", "fonts.family"),
            ("Размер заголовка", "fonts.header_size"),
            ("Обычный текст", "fonts.body_size"),
            ("Поле сканера", "fonts.scan_entry_size"),
            ("Высота строк таблиц", "layout.tree_row_height"),
            ("Отступ панели", "layout.panel_padding"),
            ("Левая панель сканера", "panels.scan_left_weight"),
            ("Правая панель сканера", "panels.scan_right_weight"),
            ("Список товаров", "panels.products_list_weight"),
            ("Форма товаров", "panels.products_form_weight"),
        ]
        for row_index, (label, key) in enumerate(settings_fields, start=2):
            ttk.Label(left, text=label, style="FormLabel.TLabel").grid(row=(row_index - 2) * 2 + 2, column=0, sticky="w")
            entry = ttk.Entry(left, textvariable=self._setting_var(key), font=(self.font_family, self.fonts["entry_size"]))
            entry.grid(row=(row_index - 2) * 2 + 3, column=0, sticky="ew", pady=(4, 10))

        right = self._panel(split)
        right.columnconfigure(0, weight=1)

        ttk.Label(right, text="Ширина колонок", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(
            right,
            text="Подстройка таблиц для вашего экрана и формата работы.",
            style="Muted.TLabel",
        ).grid(row=1, column=0, sticky="w", pady=(4, 14))

        column_fields = [
            ("Товары: название", "columns.products.name"),
            ("Товары: штрихкод", "columns.products.barcode"),
            ("Товары: поставщик", "columns.products.supplier"),
            ("Движения: дата", "columns.recent_moves.created_at"),
            ("Движения: комментарий", "columns.recent_moves.note"),
            ("Остатки: название", "columns.low_stock.name"),
        ]
        for row_index, (label, key) in enumerate(column_fields, start=2):
            ttk.Label(right, text=label, style="FormLabel.TLabel").grid(row=(row_index - 2) * 2 + 2, column=0, sticky="w")
            entry = ttk.Entry(right, textvariable=self._setting_var(key), font=(self.font_family, self.fonts["entry_size"]))
            entry.grid(row=(row_index - 2) * 2 + 3, column=0, sticky="ew", pady=(4, 10))

        ttk.Button(right, text="Сохранить настройки", style="Primary.TButton", command=self.handle_save_settings).grid(
            row=20, column=0, sticky="ew", pady=(8, 0)
        )
        ttk.Button(right, text="Сбросить поля", style="Ghost.TButton", command=self.handle_reset_settings_form).grid(
            row=21, column=0, sticky="ew", pady=(10, 0)
        )
        split.add(left, minsize=460, stretch="always")
        split.add(right, minsize=320, stretch="always")

    def refresh_all(self) -> None:
        self.refresh_products()
        self.refresh_dashboard()
        self.refresh_stats()

    def refresh_stats(self) -> None:
        products = self.db.list_products()
        low_stock = self.db.low_stock_products()
        total_stock = sum(product.total_qty for product in products)
        self.total_items_var.set(str(len(products)))
        self.total_stock_var.set(self._fmt_qty(total_stock))
        self.low_stock_count_var.set(str(len(low_stock)))

    def refresh_products(self) -> None:
        for item in self.products_tree.get_children():
            self.products_tree.delete(item)
        for product in self.db.list_products():
            self.products_tree.insert(
                "",
                "end",
                iid=str(product.id),
                values=(
                    product.name,
                    product.barcode,
                    product.unit,
                    self._fmt_qty(product.total_qty),
                    self._fmt_qty(product.min_stock),
                    product.supplier,
                ),
            )

    def refresh_dashboard(self) -> None:
        for item in self.low_stock_tree.get_children():
            self.low_stock_tree.delete(item)
        low_products = self.db.low_stock_products()
        if low_products:
            for product in low_products:
                self.low_stock_tree.insert(
                    "",
                    "end",
                    values=(product.name, product.barcode, self._fmt_qty(product.total_qty), self._fmt_qty(product.min_stock)),
                )
        else:
            self.low_stock_tree.insert("", "end", values=("Все в нормі", "-", "-", "-"))

        for item in self.recent_moves_tree.get_children():
            self.recent_moves_tree.delete(item)
        for move in self.db.recent_moves():
            move_type = "Прихід" if move["move_type"] == "IN" else "Видача"
            self.recent_moves_tree.insert(
                "",
                "end",
                values=(
                    move["created_at"],
                    move["name"],
                    move_type,
                    self._fmt_qty(move["qty"]),
                    move["lot_number"],
                    move["note"],
                ),
            )

    def handle_scan_lookup(self, _event=None) -> None:
        barcode = self.search_barcode_var.get().strip()
        product = self.db.get_product_by_barcode(barcode)
        self.selected_product = product
        if not product:
            self.scan_info_title_var.set("Товар не знайдено")
            self.scan_info_meta_var.set("Цей штрихкод ще не заведений. Перейдіть у вкладку 'Товари' і створіть позицію.")
            self.status_var.set("Штрихкод не знайдено")
            return
        self.scan_info_title_var.set(product.name)
        self.scan_info_meta_var.set(
            f"Штрихкод: {product.barcode}\n"
            f"Залишок: {self._fmt_qty(product.total_qty)} {product.unit}\n"
            f"Мінімум: {self._fmt_qty(product.min_stock)} {product.unit}\n"
            f"Постачальник: {product.supplier or '-'}\n"
            f"Нотатка: {product.notes or '-'}"
        )
        self.status_var.set(f"Знайдено: {product.name}")

    def handle_receive(self) -> None:
        if not self._ensure_selected_product():
            return
        try:
            self.db.receive_stock(
                self.selected_product.barcode,
                self._read_qty(),
                self.receive_lot_var.get(),
                self.receive_expiry_var.get().strip() or None,
                self.scan_note_var.get(),
            )
        except ValueError as error:
            messagebox.showerror("Помилка", str(error))
            return
        self.status_var.set("Прихід проведено")
        self._post_move_refresh()

    def handle_dispense(self) -> None:
        if not self._ensure_selected_product():
            return
        try:
            self.db.dispense_stock(
                self.selected_product.barcode,
                self._read_qty(),
                self.scan_note_var.get(),
            )
        except ValueError as error:
            messagebox.showerror("Помилка", str(error))
            return
        self.status_var.set("Видачу проведено")
        self._post_move_refresh()

    def handle_add_product(self) -> None:
        try:
            self.db.add_product(
                self.product_name_var.get(),
                self.product_barcode_var.get(),
                self.product_unit_var.get(),
                float(self.product_min_stock_var.get().replace(",", ".")),
                self.product_supplier_var.get(),
                self.product_notes_var.get(),
            )
        except ValueError:
            messagebox.showerror("Помилка", "Перевірте числові поля.")
            return
        except Exception as error:
            messagebox.showerror("Помилка", str(error))
            return

        self.product_name_var.set("")
        self.product_barcode_var.set("")
        self.product_unit_var.set("шт")
        self.product_min_stock_var.set("0")
        self.product_supplier_var.set("")
        self.product_notes_var.set("")
        self.status_var.set("Товар додано")
        self.refresh_all()

    def handle_save_settings(self) -> None:
        try:
            updated = load_ui_settings()
            for key, variable in self.settings_vars.items():
                self._set_nested_value(updated, key, self._coerce_setting_value(key, variable.get()))
            save_ui_settings(updated)
        except ValueError as error:
            messagebox.showerror("Ошибка", str(error))
            return

        self.status_var.set("Настройки сохранены")
        messagebox.showinfo("Готово", "Настройки сохранены. Перезапустите приложение, чтобы все изменения применились.")

    def handle_reset_settings_form(self) -> None:
        self.settings_vars.clear()
        for widget in self.settings_tab.winfo_children():
            widget.destroy()
        self._build_settings_tab()
        self.status_var.set("Поля настроек обновлены")

    def handle_product_select(self, _event=None) -> None:
        selection = self.products_tree.selection()
        if not selection:
            return
        values = self.products_tree.item(selection[0], "values")
        self.search_barcode_var.set(values[1])
        self.handle_scan_lookup()

    def reset_scan_form(self) -> None:
        self.selected_product = None
        self.search_barcode_var.set("")
        self.scan_qty_var.set("1")
        self.receive_lot_var.set("")
        self.receive_expiry_var.set("")
        self.scan_note_var.set("")
        self.scan_info_title_var.set("Скануйте штрихкод")
        self.scan_info_meta_var.set("Сканер MC-3303L працює як клавіатура: курсор у полі, сканування, Enter.")
        self.status_var.set("Форму очищено")
        self.barcode_entry.focus_set()

    def _post_move_refresh(self) -> None:
        current_barcode = self.selected_product.barcode if self.selected_product else self.search_barcode_var.get().strip()
        self.refresh_all()
        self.search_barcode_var.set(current_barcode)
        self.handle_scan_lookup()
        self.barcode_entry.focus_set()

    def _ensure_selected_product(self) -> bool:
        if self.selected_product:
            return True
        self.handle_scan_lookup()
        if self.selected_product:
            return True
        messagebox.showwarning("Увага", "Спочатку знайдіть товар за штрихкодом.")
        return False

    def _create_stat_card(self, parent: ttk.Frame, column: int, title: str, value_var: tk.StringVar, subtitle: str) -> None:
        card = self._panel(parent, pad=16)
        card.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else self.layout["stats_gap"], 0))
        ttk.Label(card, text=title, style="StatCaption.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(card, textvariable=value_var, style="StatValue.TLabel").grid(row=1, column=0, sticky="w", pady=(6, 2))
        ttk.Label(card, text=subtitle, style="StatCaption.TLabel").grid(row=2, column=0, sticky="w")

    def _panel(self, parent, pad: int = 14):
        frame = ttk.Frame(parent, style="Panel.TFrame", padding=pad)
        return frame

    def _create_splitter(self, parent, orient: str):
        actual_orient = tk.HORIZONTAL if orient == "horizontal" else tk.VERTICAL
        return tk.PanedWindow(
            parent,
            orient=actual_orient,
            sashwidth=8,
            sashrelief="flat",
            bd=0,
            bg=self.colors["bg"],
            opaqueresize=True,
            showhandle=False,
        )

    def _setting_var(self, key: str) -> tk.StringVar:
        if key not in self.settings_vars:
            self.settings_vars[key] = tk.StringVar(value=str(self._get_nested_value(self.ui, key)))
        return self.settings_vars[key]

    def _get_nested_value(self, data: dict, key: str):
        value = data
        for part in key.split("."):
            value = value[part]
        return value

    def _set_nested_value(self, data: dict, key: str, value) -> None:
        parts = key.split(".")
        target = data
        for part in parts[:-1]:
            target = target[part]
        target[parts[-1]] = value

    def _coerce_setting_value(self, key: str, value: str):
        if key == "window.title" or key == "fonts.family":
            cleaned = value.strip()
            if not cleaned:
                raise ValueError("Текстовые настройки не должны быть пустыми.")
            return cleaned
        try:
            return int(value.strip())
        except ValueError as error:
            raise ValueError(f"Некорректное число для {key}.") from error

    def _read_qty(self) -> float:
        return float(self.scan_qty_var.get().replace(",", "."))

    @staticmethod
    def _fmt_qty(value: float) -> str:
        return f"{value:.2f}".rstrip("0").rstrip(".")

    def run(self) -> None:
        self.root.mainloop()
