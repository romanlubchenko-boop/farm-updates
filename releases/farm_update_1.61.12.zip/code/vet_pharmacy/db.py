from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable


DB_PATH = Path(__file__).resolve().parent.parent / "data" / "vet_pharmacy.db"


@dataclass(slots=True)
class Product:
    id: int
    name: str
    barcode: str
    unit: str
    min_stock: float
    supplier: str
    notes: str
    total_qty: float


class InventoryDB:
    def __init__(self, db_path: Path = DB_PATH) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self.seed_demo_data()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    barcode TEXT NOT NULL UNIQUE,
                    unit TEXT NOT NULL DEFAULT 'шт',
                    min_stock REAL NOT NULL DEFAULT 0,
                    supplier TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS stock_batches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    lot_number TEXT NOT NULL DEFAULT '',
                    expires_on TEXT,
                    qty REAL NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS stock_moves (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    batch_id INTEGER,
                    barcode TEXT NOT NULL,
                    move_type TEXT NOT NULL,
                    qty REAL NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id),
                    FOREIGN KEY(batch_id) REFERENCES stock_batches(id)
                );
                """
            )

    def seed_demo_data(self) -> None:
        with self._connect() as conn:
            product_count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
            if product_count:
                return

            now = self._now()
            demo_products = [
                ("Вакцина BioTest A", "4820000000011", "фл", 5, "BioTest", "Холодове зберігання"),
                ("Антибіотик VetCure 50", "4820000000028", "уп", 3, "VetCure", "Для стаціонару"),
                ("Шприц 5 мл", "4820000000035", "шт", 20, "MedSupply", "Розхідник"),
            ]
            conn.executemany(
                """
                INSERT INTO products (name, barcode, unit, min_stock, supplier, notes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                [(name, barcode, unit, min_stock, supplier, notes, now) for name, barcode, unit, min_stock, supplier, notes in demo_products],
            )

        self.receive_stock("4820000000011", 12, "LOT-VA-001", "2027-02-01", "Стартовий залишок")
        self.receive_stock("4820000000028", 7, "LOT-AB-001", "2026-11-15", "Стартовий залишок")
        self.receive_stock("4820000000035", 50, "LOT-SY-001", "2029-01-01", "Стартовий залишок")

    def list_products(self) -> list[Product]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT
                    p.id,
                    p.name,
                    p.barcode,
                    p.unit,
                    p.min_stock,
                    p.supplier,
                    p.notes,
                    COALESCE(SUM(b.qty), 0) AS total_qty
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id
                WHERE p.is_active = 1
                GROUP BY p.id
                ORDER BY p.name
                """
            ).fetchall()
        return [Product(**dict(row)) for row in rows]

    def get_product_by_barcode(self, barcode: str) -> Product | None:
        clean_barcode = barcode.strip()
        if not clean_barcode:
            return None

        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    p.id,
                    p.name,
                    p.barcode,
                    p.unit,
                    p.min_stock,
                    p.supplier,
                    p.notes,
                    COALESCE(SUM(b.qty), 0) AS total_qty
                FROM products p
                LEFT JOIN stock_batches b ON b.product_id = p.id
                WHERE p.barcode = ? AND p.is_active = 1
                GROUP BY p.id
                """,
                (clean_barcode,),
            ).fetchone()
        return Product(**dict(row)) if row else None

    def add_product(
        self,
        name: str,
        barcode: str,
        unit: str,
        min_stock: float,
        supplier: str,
        notes: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO products (name, barcode, unit, min_stock, supplier, notes, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (name.strip(), barcode.strip(), unit.strip() or "шт", min_stock, supplier.strip(), notes.strip(), self._now()),
            )

    def receive_stock(
        self,
        barcode: str,
        qty: float,
        lot_number: str,
        expires_on: str | None,
        note: str = "",
    ) -> None:
        product = self.get_product_by_barcode(barcode)
        if not product:
            raise ValueError("Товар зі штрихкодом не знайдено.")
        if qty <= 0:
            raise ValueError("Кількість повинна бути більшою за 0.")

        with self._connect() as conn:
            cursor = conn.execute(
                """
                INSERT INTO stock_batches (product_id, lot_number, expires_on, qty, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (product.id, lot_number.strip(), expires_on or None, qty, self._now()),
            )
            batch_id = cursor.lastrowid
            conn.execute(
                """
                INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, qty, note, created_at)
                VALUES (?, ?, ?, 'IN', ?, ?, ?)
                """,
                (product.id, batch_id, product.barcode, qty, note.strip(), self._now()),
            )

    def dispense_stock(self, barcode: str, qty: float, note: str = "") -> None:
        product = self.get_product_by_barcode(barcode)
        if not product:
            raise ValueError("Товар зі штрихкодом не знайдено.")
        if qty <= 0:
            raise ValueError("Кількість повинна бути більшою за 0.")
        if product.total_qty < qty:
            raise ValueError("Недостатньо залишку на складі.")

        remaining = qty
        with self._connect() as conn:
            batches = conn.execute(
                """
                SELECT id, qty
                FROM stock_batches
                WHERE product_id = ? AND qty > 0
                ORDER BY COALESCE(expires_on, '9999-12-31'), created_at, id
                """,
                (product.id,),
            ).fetchall()
            for batch in batches:
                if remaining <= 0:
                    break
                used = min(remaining, batch["qty"])
                conn.execute(
                    "UPDATE stock_batches SET qty = qty - ? WHERE id = ?",
                    (used, batch["id"]),
                )
                conn.execute(
                    """
                    INSERT INTO stock_moves (product_id, batch_id, barcode, move_type, qty, note, created_at)
                    VALUES (?, ?, ?, 'OUT', ?, ?, ?)
                    """,
                    (product.id, batch["id"], product.barcode, used, note.strip(), self._now()),
                )
                remaining -= used

    def low_stock_products(self) -> list[Product]:
        return [product for product in self.list_products() if product.total_qty <= product.min_stock]

    def recent_moves(self, limit: int = 20) -> Iterable[sqlite3.Row]:
        with self._connect() as conn:
            return conn.execute(
                """
                SELECT
                    m.created_at,
                    p.name,
                    m.barcode,
                    m.move_type,
                    m.qty,
                    m.note,
                    b.lot_number
                FROM stock_moves m
                JOIN products p ON p.id = m.product_id
                LEFT JOIN stock_batches b ON b.id = m.batch_id
                ORDER BY m.id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
