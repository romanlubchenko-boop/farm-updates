"""Лаунчер веб-сервера ветаптеки.

Що робить:
1. Перевіряє, чи встановлений Flask (якщо ні — пропонує встановити).
2. Знаходить вільний порт (за замовчуванням 5000, якщо зайнятий — 5001…).
3. Запускає Flask-сервер у поточному процесі.
4. Через 1 секунду автоматично відкриває браузер на головній сторінці.

Запуск:
    python3 start_server.py            # 127.0.0.1, авто-порт, відкрити браузер
    python3 start_server.py --host 0.0.0.0 --port 8080
    python3 start_server.py --no-browser
"""

from __future__ import annotations

import argparse
import atexit
import os
import signal
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path


HERE = Path(__file__).resolve().parent

# На Windows консоль/пайп часто у cp1251/cp866 — друк українських рядків і
# рамки Unicode валив би сервер (UnicodeEncodeError). Переводимо вивід у UTF-8
# з errors="replace", щоб жоден print ніколи не зупиняв запуск.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        pass


def _local_state_dir() -> Path:
    """Локальна папка стану (поза OneDrive) — та сама, де жива база."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local")
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "FarmDB"


# PID-файл тримаємо локально (а не в OneDrive), щоб запис був надійний.
PID_FILE = _local_state_dir() / "server.pid"
# Стара локація PID (у OneDrive) — щоб новий старт прибрав і інстанси,
# запущені до переходу на локальний PID-файл.
LEGACY_PID_FILE = HERE / "data" / "server.pid"


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        # На Windows os.kill(pid, 0) ненадійний (кидає WinError 6 / SystemError).
        # Перевіряємо через ctypes: відкриваємо процес і дивимось код виходу.
        try:
            import ctypes
            STILL_ACTIVE = 259
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            k32 = ctypes.windll.kernel32
            h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return bool(ok) and code.value == STILL_ACTIVE
        except Exception:        # noqa: BLE001 — будь-що → вважаємо мертвим
            return False
    try:
        os.kill(pid, 0)          # POSIX: сигнал 0 — лише перевірка існування
    except ProcessLookupError:
        return False
    except PermissionError:
        return True              # існує, але не наш — вважаємо живим
    except Exception:            # noqa: BLE001
        return False
    return True


def _kill_pid_from(pid_file: Path) -> None:
    """Гасить процес, записаний у вказаному PID-файлі (якщо живий і не наш)."""
    try:
        pid = int((pid_file.read_text(encoding="utf-8") or "0").strip())
    except (OSError, ValueError):
        return
    if pid == os.getpid() or not _pid_alive(pid):
        return
    print(f"ℹ  Зупиняю попередній сервер (PID {pid})…")
    sig_kill = getattr(signal, "SIGKILL", signal.SIGTERM)
    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):                 # до ~3 с на коректне завершення
            time.sleep(0.1)
            if not _pid_alive(pid):
                break
        else:
            os.kill(pid, sig_kill)          # не вийшов — примусово
    except Exception:                       # noqa: BLE001 — старт не має падати
        pass


def _stop_previous() -> None:
    """Гасить попередні інстанси сервера (якщо живі), щоб не плодити копії.
    Саме накопичення паралельних серверів давало «привидні» помилки старої
    версії коду після правок. Перевіряємо і новий (локальний), і старий
    (OneDrive) PID-файли."""
    _kill_pid_from(PID_FILE)
    if LEGACY_PID_FILE.resolve() != PID_FILE.resolve():
        _kill_pid_from(LEGACY_PID_FILE)


def _write_pid() -> None:
    """Запис PID-файлу, щоб «Зупинити сервер» / новий запуск знайшов процес."""
    try:
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass


def _remove_pid() -> None:
    try:
        PID_FILE.unlink()
    except OSError:
        pass


def ensure_dependencies() -> None:
    """Перевіряє, чи встановлені Flask + waitress + openpyxl.
    Якщо чогось бракує — пропонує встановити через pip із requirements.txt."""
    missing = []
    for name in ("flask", "waitress", "openpyxl", "cryptography", "segno"):
        try:
            __import__(name)
        except ImportError:
            missing.append(name)
    if not missing:
        return

    print(f"⚠  Не встановлено: {', '.join(missing)}")
    req = HERE / "requirements.txt"

    # Чи є інтерактивний термінал? Якщо ні (запуск значком/у фоні) — ставимо
    # автоматично, без запитань (інакше input() падає з EOFError).
    interactive = bool(getattr(sys.stdin, "isatty", lambda: False)())
    if interactive:
        answer = input("Встановити автоматично через pip? [Y/n] ").strip().lower()
        if answer not in ("", "y", "yes", "т", "так"):
            print("Завершую. Встановіть залежності і запустіть знову:")
            print(f"    {sys.executable} -m pip install -r requirements.txt")
            sys.exit(1)
    else:
        print("Встановлюю потрібні бібліотеки автоматично (одноразово)…")

    cmd = [sys.executable, "-m", "pip", "install", "-r", str(req)]
    print("→", " ".join(cmd))
    result = subprocess.run(cmd)
    if result.returncode != 0:
        # Повтор для «externally-managed» Python (Homebrew / PEP 668)
        print("ℹ  Повторюю з --break-system-packages…")
        result = subprocess.run(cmd + ["--break-system-packages"])
    if result.returncode != 0:
        print("✗  Не вдалося встановити залежності. Спробуйте вручну:")
        print(f"    {sys.executable} -m pip install -r {req}")
        sys.exit(1)


def get_lan_ip() -> str:
    """Повертає IP-адресу комп'ютера у локальній мережі (LAN).
    Класичний трюк: відкриваємо UDP-сокет «у напрямку інтернету»,
    реального трафіку не йде, але ОС вибирає інтерфейс і ми читаємо його IP.
    Якщо мережі немає — повертаємо порожній рядок."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return ""


def find_free_port(preferred: int, host: str = "127.0.0.1", max_tries: int = 20) -> int:
    """Шукає вільний порт починаючи з preferred.
    Використовує SO_REUSEADDR — щоб після Ctrl+C порт, що ще не вийшов
    з TIME_WAIT (~30-240 c у різних ОС), не лічився «зайнятим». На активний
    сервер SO_REUSEADDR не дозволяє binditись, тож безпечно."""
    for offset in range(max_tries):
        port = preferred + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"Не знайшов вільний порт у діапазоні {preferred}..{preferred + max_tries}")


def open_browser_later(url: str, delay: float = 1.0) -> None:
    def _open() -> None:
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception as exc:  # noqa: BLE001
            print(f"(не вдалося відкрити браузер: {exc})")

    threading.Thread(target=_open, daemon=True).start()


def _lan_ip() -> str:
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:  # noqa: BLE001
        return ""


def _write_https_status(msg: str) -> None:
    """Записати причину стану HTTPS у файл — щоб було видно, чому не піднявся."""
    try:
        (_local_state_dir() / "https_status.txt").write_text(
            time.strftime("%Y-%m-%d %H:%M:%S") + "  " + msg, encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass


def _reset_https_certs() -> None:
    """Прибрати лише LEAF-сертифікат (щоб перевипустити його), але НЕ CA.
    CA — корінь довіри: його вже встановлено на телефонах/планшетах, тож
    видаляти його НЕ можна (інакше на всіх пристроях зламається довіра і
    доведеться повторно ставити сертифікат). Тому чіпаємо тільки leaf."""
    d = _local_state_dir()
    for name in ("farm_cert.pem", "farm_key.pem", "farm_cert_ip.txt"):
        try:
            (d / name).unlink()
        except Exception:  # noqa: BLE001
            pass


def _start_https(app) -> None:
    """Підняти HTTPS-слухача у фоновому потоці (для камери телефона).
    Стійко: пошкоджений сертифікат — перевипускаємо; зайнятий порт —
    повторюємо/беремо наступний; причину збою пишемо у https_status.txt.
    Функція НІКОЛИ не кидає виняток (щоб не завалити старт HTTP-сервера)."""
    try:
        want_port = int(os.environ.get("FARM_HTTPS_PORT", "8443"))
        lan = _lan_ip()
        try:
            import ssl
            import tlscert
        except ModuleNotFoundError:
            print("[HTTPS] бібліотека cryptography ще не встановлена — "
                  "сканер на телефоні запрацює після перезапуску.", flush=True)
            _write_https_status("cryptography не встановлена — перезапустіть застосунок")
            return
        try:
            _host = socket.gethostname().split(".")[0]
        except Exception:  # noqa: BLE001
            _host = ""

        # 1) Сертифікат. Дві типові біди й самолікування кожної:
        #    (а) криптобібліотека зібрана під іншу архітектуру (arm64 vs x86_64)
        #        → бінарник не вантажиться; перевстановлюємо cryptography під
        #        поточний інтерпретатор (--force-reinstall) і пробуємо ще раз;
        #    (б) сам сертифікат пошкоджений → перевипускаємо його один раз.
        def _looks_like_crypto_arch(msg: str) -> bool:
            low = msg.lower()
            return ("incompatible architecture" in low or "_rust" in low
                    or "dlopen" in low or "mach-o" in low
                    or "no module named 'cryptography'" in low)

        def _reinstall_cryptography() -> bool:
            print("[HTTPS] перевстановлюю cryptography під поточну архітектуру…",
                  flush=True)
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--user",
                     "--force-reinstall", "--no-cache-dir", "--only-binary=:all:",
                     "--disable-pip-version-check", "-q", "cryptography"],
                    check=True, timeout=300)
                # скинути закешовані модулі, щоб підхопився новий бінарник
                for m in list(sys.modules):
                    if m.split(".")[0] == "cryptography":
                        sys.modules.pop(m, None)
                return True
            except Exception as exc:  # noqa: BLE001
                print(f"[HTTPS] перевстановлення не вдалося ({exc}).", flush=True)
                return False

        ctx = None
        healed = False
        for attempt in (1, 2, 3):
            try:
                cert, key = tlscert.ensure_cert(_local_state_dir(), lan,
                                                [_host] if _host else None)
                ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                ctx.load_cert_chain(cert, key)
                break
            except Exception as exc:  # noqa: BLE001
                msg = str(exc)
                if _looks_like_crypto_arch(msg) and not healed:
                    healed = True
                    print(f"[HTTPS] криптобібліотека несумісна ({msg[:100]}…).",
                          flush=True)
                    if _reinstall_cryptography():
                        continue
                    print("[HTTPS] не вдалося виправити криптобібліотеку. "
                          "HTTP працює.", flush=True)
                    _write_https_status(f"cryptography arch: {msg[:200]}")
                    return
                if attempt == 1 and not _looks_like_crypto_arch(msg):
                    print(f"[HTTPS] сертифікат не читається ({exc}) — перевипуск.",
                          flush=True)
                    _reset_https_certs()
                    continue
                print(f"[HTTPS] не вдалося створити сертифікат ({msg[:120]}). "
                      "HTTP працює.", flush=True)
                _write_https_status(f"сертифікат: {msg[:200]}")
                return

        # 2) Слухач. HTTPS МУСИТЬ бути саме на своєму порту (8443): телефон,
        #    QR і редіректи ведуть на фіксовану адресу https://IP:8443, тож
        #    «переїзд» на інший порт зламав би доступ. Після швидкого рестарту
        #    старий екземпляр ще кілька секунд тримає порт — тому терпляче
        #    чекаємо його звільнення (до ~12 с), і НЕ міняємо порт.
        from werkzeug.serving import make_server
        # werkzeug при зайнятому порту робить sys.exit(1) — тому спершу
        # перевіряємо порт власним тестовим bind (SO_REUSEADDR, як у werkzeug),
        # і викликаємо make_server лише коли порт вільний (+ ловимо SystemExit).
        def _port_free(p):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("0.0.0.0", p))
                return True
            except OSError:
                return False
            finally:
                s.close()

        srv = None
        for _try in range(24):            # ~12 c очікування звільнення порту
            if _port_free(want_port):
                try:
                    srv = make_server("0.0.0.0", want_port, app,
                                      threaded=True, ssl_context=ctx)
                    break
                except (OSError, SystemExit):  # зайняли між перевіркою і bind
                    srv = None
            time.sleep(0.5)
        if srv is None:
            print(f"[HTTPS] порт {want_port} досі зайнятий. HTTP-доступ працює; "
                  "HTTPS підніметься після наступного перезапуску.", flush=True)
            _write_https_status(f"порт {want_port} зайнятий")
            return
        threading.Thread(target=srv.serve_forever, daemon=True, name="https").start()
        _write_https_status("OK, порт " + str(want_port))
        if lan:
            print(f"[HTTPS] увімкнено, сканер на телефоні: "
                  f"https://{lan}:{want_port}/scan", flush=True)
        else:
            print(f"[HTTPS] увімкнено на порту {want_port}", flush=True)
        return
    except Exception as exc:  # noqa: BLE001 — HTTPS не має валити старт HTTP
        print(f"[HTTPS] поки не активний ({exc}). HTTP-доступ працює як завжди.", flush=True)
        _write_https_status(f"інше: {exc}")


def _reexec_arm64_if_rosetta() -> None:
    """На Apple Silicon під Rosetta (процес x86_64) перезапускаємось нативно
    arm64 — щоб завантажувалась установлена arm64-криптобібліотека (потрібна
    для HTTPS і камери телефона). Робимо один раз (guard через env-змінну),
    лише коли `arch` доступний. Якщо не під Rosetta — нічого не змінюємо."""
    if sys.platform != "darwin":
        return
    if os.environ.get("FARM_ARCH_REEXEC") == "1":
        return
    try:
        translated = subprocess.run(
            ["sysctl", "-n", "sysctl.proc_translated"],
            capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:  # noqa: BLE001
        translated = ""
    if translated != "1":            # не під Rosetta — залишаємось як є
        return
    arch = "/usr/bin/arch"
    if not os.path.exists(arch):
        return
    # БЕЗПЕКА: os.execv замінює процес, тож ЯКЩО arm64-зрізу немає — сервер би
    # загинув. Тому спершу тихо перевіряємо, що `arch -arm64 python` реально
    # стартує; лише за успіху робимо execv. Інакше лишаємось на x86_64 (HTTP ок).
    try:
        probe = subprocess.run(
            [arch, "-arm64", sys.executable, "-c", "pass"],
            capture_output=True, timeout=15)
        if probe.returncode != 0:
            print("[ARCH] arm64-зріз недоступний — лишаюсь на x86_64.", flush=True)
            return
    except Exception as exc:  # noqa: BLE001
        print(f"[ARCH] перевірка arm64 не вдалася ({exc}) — лишаюсь на x86_64.",
              flush=True)
        return
    os.environ["FARM_ARCH_REEXEC"] = "1"
    try:
        print("[ARCH] перезапуск нативно під arm64 (Apple Silicon)…", flush=True)
        os.execv(arch, [arch, "-arm64", sys.executable, *sys.argv])
    except Exception as exc:  # noqa: BLE001 — лишаємось на x86_64, HTTP працює
        print(f"[ARCH] не вдалося перезапустити під arm64 ({exc}).", flush=True)


def main() -> int:
    # Найперше: якщо ми під Rosetta — перезапуститись нативно arm64.
    _reexec_arm64_if_rosetta()

    parser = argparse.ArgumentParser(description="Запуск сервера ветаптеки")
    parser.add_argument("--host", default=None,
                        help="IP для прослуховування. Якщо не задано — береться "
                             "з перемикача «Режим сервера» (Налаштування).")
    parser.add_argument("--port", type=int, default=5050,
                        help="Бажаний порт (за замовч. 5050)")
    parser.add_argument("--no-browser", action="store_true",
                        help="Не відкривати браузер автоматично")
    parser.add_argument("--debug", action="store_true",
                        help="Режим debug (Flask reloader)")
    # parse_known_args — щоб зайві службові слова з .bat (напр. "gui")
    # не валили сервер; вони просто ігноруються.
    args, _ignored = parser.parse_known_args()

    # Працюємо у директорії скрипта, щоб шляхи до templates/static знайшлись
    os.chdir(HERE)
    sys.path.insert(0, str(HERE))

    # Хост: явний --host має пріоритет; інакше — з перемикача «Режим сервера».
    # Прапорець лежить у config/server_mode (1 = мережа / 0.0.0.0, інакше локально).
    host = args.host
    if not host:
        try:
            flag = (HERE / "config" / "server_mode").read_text(encoding="utf-8").strip()
        except Exception:  # noqa: BLE001
            flag = "0"
        host = "0.0.0.0" if flag == "1" else "127.0.0.1"

    ensure_dependencies()

    # Один інстанс: гасимо попередній сервер, щоб не плодити паралельні копії
    # (інакше старі процеси зі старим кодом/базою сиплять привидні помилки).
    _stop_previous()

    try:
        port = find_free_port(args.port, host)
    except RuntimeError as exc:
        print(f"✗  {exc}")
        return 1

    if port != args.port:
        print(f"ℹ  Порт {args.port} зайнятий, використовую {port}")

    # Фактичний HTTP-порт — у середовище, щоб застосунок міг показати
    # посилання за іменем ПК у футері (http://ІМ'ЯПК:порт).
    os.environ["FARM_HTTP_PORT"] = str(port)

    # Мережевий режим: вмикаємо HTTPS-only для не-локальних клієнтів — застосунок
    # перенаправлятиме http→https, а cookie сесії стане Secure. Власний ПК по
    # localhost лишається на http (зручно, без сертифіката).
    if host in ("0.0.0.0", "::"):
        os.environ["FARM_NETWORK_MODE"] = "1"
        os.environ.setdefault("FARM_HTTPS_PORT", "8443")

    # відкладене відкриття браузера ще ДО старту сервера
    visible_host = "127.0.0.1" if host in ("0.0.0.0", "::") else host
    url = f"http://{visible_host}:{port}/"

    # У мережному режимі підказуємо адресу для інших пристроїв.
    lan_url = ""
    phone_url = ""
    if host == "0.0.0.0":
        lan_ip = get_lan_ip()
        if lan_ip and lan_ip != "127.0.0.1":
            _hp = os.environ.get("FARM_HTTPS_PORT", "8443")
            # У мережі працюємо лише по HTTPS (http автоматично перенаправляє).
            lan_url = f"https://{lan_ip}:{_hp}/"
            phone_url = f"https://{lan_ip}:{_hp}/"

    print()
    print("┌─────────────────────────────────────────────────────────┐")
    print("│  Ветаптека — веб-сервер запущено                        │")
    print("├─────────────────────────────────────────────────────────┤")
    print(f"│  На цьому компʼютері:  {url:<33}│")
    if lan_url:
        print(f"│  З інших пристроїв:    {lan_url:<33}│")
        print(f"│  На телефоні (HTTPS):  {phone_url:<33}│")
        print("│                                                         │")
        print("│  Відкрийте адресу «З інших пристроїв» у браузері        │")
        print("│  на планшеті / другому ПК у тій самій Wi-Fi мережі.     │")
        print("│  Для камери й офлайн на телефоні — адреса «HTTPS»        │")
        print("│  (браузер один раз спитає підтвердити сайт — це норм).   │")
    elif host == "0.0.0.0":
        print("│  З інших пристроїв:    не вдалось визначити IP          │")
        print("│  Перевірте, що компʼютер підключений до мережі.         │")
    else:
        print("│  Доступ лише на цьому компʼютері (host=127.0.0.1).      │")
    print("│                                                         │")
    print("│  Зупинити: Ctrl+C                                       │")
    print("└─────────────────────────────────────────────────────────┘")
    print()

    if not args.no_browser:
        open_browser_later(url, delay=1.2)

    # PID-файл для коректної зупинки ззовні
    _write_pid()
    atexit.register(_remove_pid)

    # Застосувати підготовлене оновлення ДО імпорту коду — щоб не замінювати
    # зайняті файли. Робить копію поточного коду й відкат, якщо новий не валідний.
    try:
        import updater
        _up = updater.apply_staged_update(HERE)
        if _up.get("applied"):
            print(f"✓ Оновлення застосовано до версії {_up.get('app_version')}.")
        elif _up.get("error"):
            print("⚠ Оновлення не застосовано: " + str(_up["error"])
                  + (" (код відкочено до робочого стану)" if _up.get("rolled_back") else ""))
    except Exception as _exc:  # noqa: BLE001
        print(f"⚠ Помилка апдейтера (пропускаю): {_exc}")

    # Імпортуємо Flask-додаток вже після перевірки залежностей
    from web_app import app

    # У мережевому режимі піднімаємо ще й HTTPS — щоб камера телефона
    # працювала (getUserMedia вимагає захищеного контексту).
    if host in ("0.0.0.0", "::"):
        print("[HTTPS] запуск слухача…", flush=True)
        _start_https(app)

    try:
        if args.debug:
            # Debug-режим — рідний Flask-сервер з авто-перезавантаженням
            # (потрібно лише програмістам).
            app.run(host=host, port=port, debug=True, use_reloader=True)
        else:
            # Production-режим — waitress: багатопотоковий WSGI-сервер,
            # стабільний під одночасні запити, без лякливого «dev server»-попередження.
            import logging
            # Приглушуємо «Task queue depth» — це інформаційне повідомлення,
            # яке зʼявляється при короткочасних піках і нічого не зламано.
            logging.getLogger("waitress.queue").setLevel(logging.ERROR)
            from waitress import serve
            serve(app, host=host, port=port,
                  threads=8,           # вистачить на 5-10 одночасних касирів
                  ident="Vetpharm")
    except KeyboardInterrupt:
        print("\nЗупинено.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
