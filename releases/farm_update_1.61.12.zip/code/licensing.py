"""Ліцензія з цифровим підписом («печаткою»).

Перевірка офлайн і без залежностей: ліцензійний токен підписано ПРИВАТНИМ
ключем видавця, а програма перевіряє підпис вбудованим ПУБЛІЧНИМ ключем
(чистий Python: pow + sha256). Підробити токен без приватного ключа неможливо.

Формат токена:  FARM1.<payload_b64url>.<sig_b64url>
    payload — компактний JSON: {"company","issued","expires","lid","plan"}
    sig     — RSA-підпис SHA-256(_DOMAIN + payload_bytes)

Статуси: active | grace (GRACE_DAYS після expires) | expired | none | invalid.
"""

from __future__ import annotations

import os
import re
import sys
import json
import base64
import hashlib
import secrets
import subprocess
from pathlib import Path
from datetime import date, datetime, timedelta
from typing import Optional

# Публічний ключ видавця (RSA-2048). Приватний ключ — лише у власника.
_PUBLIC_N = int(
    "a3dac2fa622cf64bb68c69e780caa8fcdb229168c8a997f03be88999310c612f"
    "f34562ad4cbf8915867273777290da33251540ea58869361b00ac951198b2cff"
    "f43caa634d20c3711285fbe87bf77c32cf3e70b74d0ed003c30432626f7ed8c7"
    "eeede15bcd4038131fb23313034d6b3a988c11096c8085d387677db88ef437a7"
    "3fc1f65fc1b7a75cdf4050166e7c7f98d45f4bc989b0903cd9d5ada3aea70992"
    "d41e3a2f275f4c55277c9acbf2e4d3197c94a8851b59707e0ede286c482186f6"
    "ea574e3f9fe54bb1a5f116af8280c187cad3f54d8ef82a24d70a117141c7a185"
    "c09ee57122aab48a88f7c0f2e520653b41ca562dc8ba0193a05817e9c8d8bbb3",
    16,
)
_PUBLIC_E = 65537
_DOMAIN = b"FARMLIC1"
GRACE_DAYS = 15


# ===================================================================== привязка до ПК
# Код активації цього ПК = похідна від апаратного номера ПК + випадкової солі.
# Зашивається у ключ (поле "sn"); при перевірці локальний код має збігатися —
# інакше ключ не діє (режим лише-читання). Це привязує ліцензію до конкретного
# компʼютера: поширення .lic-файлу чи копіювання всієї папки на інший ПК не
# спрацює (на іншому залізі апаратний номер інший → інший код).

_code_cache: Optional[str] = None


def _run(cmd: list) -> str:
    try:
        out = subprocess.run(cmd, capture_output=True, timeout=5, text=True)
        return out.stdout or ""
    except Exception:  # noqa: BLE001
        return ""


def _hardware_id() -> str:
    """Стабільний апаратний ідентифікатор ПК (best-effort, лише stdlib)."""
    if sys.platform == "darwin":
        out = _run(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"])
        m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', out)
        if m:
            return m.group(1)
    elif os.name == "nt":
        try:
            import winreg  # type: ignore
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                r"SOFTWARE\Microsoft\Cryptography") as k:
                val, _ = winreg.QueryValueEx(k, "MachineGuid")
                if val:
                    return str(val)
        except Exception:  # noqa: BLE001
            pass
        out = _run(["wmic", "csproduct", "get", "uuid"])
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        if len(lines) >= 2:
            return lines[1]
    else:
        for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                v = Path(p).read_text().strip()
                if v:
                    return v
            except OSError:
                pass
    import platform
    return platform.node() or ""


def _salt_dir() -> Path:
    """Стабільна папка користувача ПОЗА папкою застосунку (щоб копіювання
    папки не переносило сіль)."""
    if sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support" / "OblikFermy"
    elif os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(Path.home()))) / "OblikFermy"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "oblik_fermy"
    try:
        base.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return base


def _get_or_create_salt() -> str:
    f = _salt_dir() / "activation_salt"
    try:
        v = f.read_text(encoding="utf-8").strip()
        if v:
            return v
    except OSError:
        pass
    salt = secrets.token_hex(16)
    try:
        f.write_text(salt, encoding="utf-8")
    except OSError:
        pass
    return salt


def activation_code() -> str:
    """Код активації цього ПК у форматі FARM-XXXX-XXXX-XXXX. Кешується."""
    global _code_cache
    if _code_cache:
        return _code_cache
    raw = (_hardware_id() + ":" + _get_or_create_salt()).encode("utf-8")
    digest = hashlib.sha256(raw).digest()
    b32 = base64.b32encode(digest).decode("ascii").rstrip("=").upper()
    body = b32[:12]
    code = "FARM-" + "-".join(body[i:i + 4] for i in range(0, 12, 4))
    _code_cache = code
    return code


def _b64u_decode(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _b64u_encode(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def _digest_int(payload_bytes: bytes) -> int:
    return int.from_bytes(hashlib.sha256(_DOMAIN + payload_bytes).digest(), "big")


def verify_token(token: str) -> Optional[dict]:
    """Повертає payload (dict), якщо підпис валідний, інакше None."""
    try:
        parts = (token or "").strip().split(".")
        if len(parts) != 3 or parts[0] != "FARM1":
            return None
        payload_bytes = _b64u_decode(parts[1])
        sig = int.from_bytes(_b64u_decode(parts[2]), "big")
        if pow(sig, _PUBLIC_E, _PUBLIC_N) != _digest_int(payload_bytes):
            return None
        data = json.loads(payload_bytes.decode("utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:  # noqa: BLE001
        return None


def status(token: str, today: Optional[date] = None) -> dict:
    """Статус ліцензії з токена. read_only=True означає режим лише-читання."""
    today = today or date.today()
    raw = (token or "").strip()
    data = verify_token(raw)
    if not data:
        return {"state": "none" if not raw else "invalid", "read_only": True,
                "company": "", "expires": "", "grace_days": GRACE_DAYS}
    company = str(data.get("company", ""))
    exp_s = str(data.get("expires", ""))
    try:
        exp = datetime.strptime(exp_s, "%Y-%m-%d").date()
    except ValueError:
        return {"state": "invalid", "read_only": True, "company": company,
                "expires": exp_s, "grace_days": GRACE_DAYS}
    # Дозволені гілки (entitlements). Відсутнє поле → None = без обмежень (усі).
    branches = data.get("branches")
    if branches is not None and not isinstance(branches, list):
        branches = None
    base = {"company": company, "expires": exp_s, "grace_days": GRACE_DAYS,
            "issued": str(data.get("issued", "")), "lid": str(data.get("lid", "")),
            "branches": branches}
    # Привязка до ПК: якщо у ключі є код активації (sn) — він мусить збігатися з
    # локальним. Старі ключі без sn проходять (сумісність). Якщо локальний код
    # не вдалося обчислити — НЕ блокуємо (fail-open, щоб не лишити без доступу).
    sn = str(data.get("sn", "")).strip()
    if sn:
        try:
            local = activation_code()
        except Exception:  # noqa: BLE001
            local = ""
        if local and sn != local:
            base.update(state="wrong_device", read_only=True)
            return base
    if today <= exp:
        base.update(state="active", read_only=False, days_left=(exp - today).days)
        return base
    grace_end = exp + timedelta(days=GRACE_DAYS)
    if today <= grace_end:
        base.update(state="grace", read_only=False, grace_left=(grace_end - today).days)
        return base
    base.update(state="expired", read_only=True)
    return base
