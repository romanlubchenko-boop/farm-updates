#!/usr/bin/env python3
"""Збирач ЧИСТОЇ клієнтської версії застосунку «Облік ферми».

Формує готовий до передачі клієнту пакет:
  • код програми (з updater'ом — клієнт зможе отримувати оновлення);
  • клієнтські лаунчери (Windows з авто-встановленням Python; macOS);
  • порожні реквізити (config/business.json);
  • інструкцію README.txt.

БЕЗ бази даних, користувачів, ліцензії й налаштувань — усе це
створюється/задається при першому запуску в клієнта:
  свіжа база з демо-даними → майстер створення адміністратора (/setup)
  → реквізити → активація ліцензії.

Запуск (із папки app/):
    python3 make_client.py            # пакет у ../dist/
    python3 make_client.py --out /шлях/до/теки
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import zipfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent      # .../FarmApp/app
ROOT = APP_DIR.parent                          # .../FarmApp

# Що НЕ потрапляє у клієнтський пакет (службове + dev-інструменти + локальні дані)
EXCLUDE_TOP = {
    "__pycache__", ".venv", ".git", ".idea",
    "config", "data",                  # локальні налаштування й база — не віддаємо
    "build_update.py", "make_client.py", "seed_demo_data.py",  # dev-інструменти
}

BLANK_BUSINESS = (
    "{\n"
    '  "name": "",\n'
    '  "entity": "",\n'
    '  "edrpou": "",\n'
    '  "address": "",\n'
    '  "phone": "",\n'
    '  "is_vat_payer": false,\n'
    '  "vat_rate": 20.0\n'
    "}\n"
)

# ─────────────────────────── Windows-лаунчер
# ВАЖЛИВО: .bat читається cmd у системній OEM-кодовій сторінці, тому ВЕСЬ файл
# тримаємо в ASCII (без кирилиці) і без дужок у тексті echo — інакше cmd ламає
# розбір рядків. Україномовний — лише сам застосунок у браузері.
WIN_BAT = r'''@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0app"

set "LOCALDB_DIR=%LOCALAPPDATA%\FarmDB"
set "VET_DB_PATH=%LOCALDB_DIR%\workcenter.db"
set "VET_JOURNAL_MODE=wal"
if not exist "%LOCALDB_DIR%" mkdir "%LOCALDB_DIR%"
echo Database: %VET_DB_PATH%
echo.

set "PY="
if exist ".venv\Scripts\python.exe" (
    .venv\Scripts\python.exe --version >nul 2>nul && set "PY=.venv\Scripts\python.exe"
)
if not defined PY ( python --version >nul 2>nul && set "PY=python" )
if not defined PY ( py -3 --version >nul 2>nul && set "PY=py -3" )
if not defined PY goto :install_python
goto :run

:install_python
echo.
echo Python not found. Downloading and installing for current user...
echo.
set "PYVER=3.12.8"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PYINST=%TEMP%\farm-python-%PYVER%.exe"
echo [1/3] Downloading Python %PYVER% ...
curl -L --fail -# -o "%PYINST%" "%PYURL%"
if errorlevel 1 (
    echo Could not download Python. Install manually:
    echo https://www.python.org/downloads/windows/
    pause
    exit /b 1
)
echo [2/3] Installing Python, please wait...
"%PYINST%" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1 SimpleInstall=1
set "INSTALL_RC=!errorlevel!"
del "%PYINST%" >nul 2>nul
if not "!INSTALL_RC!" == "0" (
    echo Python install failed code !INSTALL_RC!.
    echo Try manually: https://www.python.org/downloads/windows/
    pause
    exit /b 1
)
echo [3/3] Refreshing PATH...
for /f "skip=2 tokens=2,*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USERPATH=%%B"
if defined USERPATH set "PATH=%USERPATH%;%PATH%"
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
rem Direct path to the freshly installed Python (avoids needing a second run).
if not defined PY (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PY (
    echo Python installed. Please close this window and run run_server.bat again.
    pause
    exit /b 0
)

:run
echo Interpreter: %PY%
echo.
rem Default (double-click) opens the CONTROL PANEL window.
rem Argument "console" runs a plain server in this console (fallback).
if /I "%~1"=="console" goto :console

rem Make sure required libraries are present (one time, shows progress).
rem pystray + PIL are needed for the tray icon (Windows).
%PY% -c "import flask, openpyxl, waitress, cryptography, segno, pystray, PIL" >nul 2>nul
if errorlevel 1 (
    echo Installing required libraries, one time, please wait...
    %PY% -m pip install --disable-pip-version-check -q -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Could not install libraries. Check your internet connection.
        pause
        exit /b 1
    )
)

rem No GUI toolkit (Tkinter) - run the console server instead.
%PY% -c "import tkinter" >nul 2>nul
if errorlevel 1 (
    echo Graphical panel unavailable, starting server in this window...
    goto :console
)

rem Open the control panel window without a console (pythonw / pyw).
set "PYW="
if exist ".venv\Scripts\pythonw.exe" set "PYW=.venv\Scripts\pythonw.exe"
if not defined PYW ( where pythonw >nul 2>nul && set "PYW=pythonw" )
if not defined PYW ( where pyw >nul 2>nul && set "PYW=pyw" )
if not defined PYW (
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" set "PYW=%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
)
if defined PYW (
    start "" %PYW% launcher.py
    exit /b 0
)
rem No windowless Python found - open the panel with a console visible.
%PY% launcher.py
exit /b 0

:console
%PY% start_server.py
set "EC=%errorlevel%"
if "%EC%" == "0" exit /b 0
echo.
echo Server exited with error code %EC%.
pause >nul
exit /b %EC%
'''

# ─────────────────────────── macOS-лаунчер
MAC_CMD = r'''#!/bin/bash
# Облік ферми — запуск (macOS). Жива база локально; бекапи — в інтерфейсі.
cd "$(dirname "$0")/app"
export VET_DB_PATH="$HOME/Library/Application Support/FarmDB/workcenter.db"
export VET_JOURNAL_MODE=delete
mkdir -p "$HOME/Library/Application Support/FarmDB"
echo "Жива база: $VET_DB_PATH"
PY=python3
command -v "$PY" >/dev/null 2>&1 || PY=python
command -v "$PY" >/dev/null 2>&1 || {
  echo "Потрібен Python 3.10+: https://www.python.org/downloads/macos/"
  read -r -p "Натисніть Enter..."; exit 1;
}
# Перевірка/встановлення бібліотек без запитань
"$PY" -c "import flask, openpyxl, waitress, cryptography, segno" 2>/dev/null || {
  echo "Встановлюю потрібні бібліотеки (одноразово)..."
  "$PY" -m pip install -q -r requirements.txt || {
    echo "Не вдалось встановити бібліотеки. Перевірте інтернет."; read -r -p "Enter..."; exit 1; }
}
"$PY" start_server.py "$@"
'''

# ─────────────────────── значки-програми (запуск без термінала) ───────────
# macOS: .app-бандл із LSUIElement (без вікна термінала). Виконуваний скрипт
# стартує сервер у фоні; браузер відкриється сам.
# macOS .app: виконуваний скрипт стартує ВІКНО-ПУЛЬТ (launcher.py).
MAC_APP_RUN = r'''#!/bin/bash
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
export VET_DB_PATH="$HOME/Library/Application Support/FarmDB/workcenter.db"
export VET_JOURNAL_MODE=delete
export FARM_PORT=5050
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
mkdir -p "$HOME/Library/Application Support/FarmDB"
cd "$ROOT/app" || exit 1
PY=""
for c in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/local/bin/python3 python3 python; do
  command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }
done
[ -z "$PY" ] && {
  osascript -e 'display dialog "Потрібен Python 3. Встановіть із python.org" buttons {"OK"}'
  exit 1; }
exec "$PY" launcher.py
'''


def _mac_plist(name: str) -> str:
    return ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
            '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            '<plist version="1.0"><dict>\n'
            f'  <key>CFBundleName</key><string>{name}</string>\n'
            '  <key>CFBundleExecutable</key><string>run</string>\n'
            '  <key>CFBundleIdentifier</key><string>com.farmapp.launcher</string>\n'
            '  <key>CFBundlePackageType</key><string>APPL</string>\n'
            '  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>\n'
            '  <key>CFBundleShortVersionString</key><string>1.0</string>\n'
            '</dict></plist>\n')

# Windows: «Облік ферми.bat» — забезпечує Python і запускає вікно-пульт.
WIN_GUI_BAT = r'''@echo off
call "%~dp0run_server.bat" gui
'''


def _write_mac_app(parent, app_name: str, run_script: str) -> None:
    """Створити мінімальний .app-бандл."""
    appdir = parent / (app_name + ".app")
    macos = appdir / "Contents" / "MacOS"
    macos.mkdir(parents=True, exist_ok=True)
    (appdir / "Contents" / "Info.plist").write_text(_mac_plist(app_name), encoding="utf-8")
    run = macos / "run"
    run.write_text(run_script, encoding="utf-8")
    os.chmod(run, 0o755)


README_TXT = '''ОБЛІК ФЕРМИ — встановлення

ЗАПУСК (вікно-пульт)
  Windows: двічі клацніть "Облік ферми.bat"
  macOS:   двічі клацніть "Облік ферми.app"  (1-й раз: правою -> Відкрити)

  Відкриється невелике вікно-пульт із кнопками:
    Відкрити в браузері · Перезапустити · Зупинити
  У вікні видно стан: встановлення бібліотек / запускається / працює.
  Коли сервер готовий — браузер відкривається сам. Вікно можна згорнути.
  Зупинка сервера: кнопка "Зупинити" або закрийте вікно.

ЯКЩО ЩОСЬ НЕ ТАК (діагностика)
  Запустіть видимий запускач із журналом:
  Windows: run_server.bat     macOS: start_server_mac.command

Відкриється у браузері: http://127.0.0.1:5050  (на цьому ПК)
Мережевий доступ (з телефона/іншого ПК) вмикається у Налаштуваннях
розділ "Режим сервера" -> там же буде показана адреса.

ПЕРШИЙ ЗАПУСК (налаштування з нуля)
  1. Створіть адміністратора у вікні "Перший запуск".
  2. У базі вже є кілька демо-товарів для прикладу — їх можна видалити.
  3. Заповніть реквізити: Ліцензія -> Моя компанія.
  4. Активуйте ліцензію: Ліцензія -> Активувати (вставте отриманий ключ
     або файл license.lic).
  5. Бекапи: Сторінка "База даних" -> вкажіть папку (бажано в хмарі/OneDrive).

ОНОВЛЕННЯ
  Сторінка "База даних" -> "Версія та оновлення":
  вкажіть джерело (посилання чи папку) і натисніть "Перевірити".
  Перед оновленням автоматично робиться копія коду й бази.

Жива база зберігається локально:
  Windows: %LOCALAPPDATA%\\FarmDB\\workcenter.db
  macOS:   ~/Library/Application Support/FarmDB/workcenter.db
'''


def app_version() -> str:
    text = (APP_DIR / "web_app.py").read_text(encoding="utf-8")
    m = re.search(r'^APP_VERSION\s*=\s*"([^"]+)"', text, re.M)
    return m.group(1) if m else "0.0.0"


def copy_code(dst_app: Path) -> int:
    n = 0
    for item in sorted(APP_DIR.iterdir()):
        if item.name in EXCLUDE_TOP:
            continue
        dest = dst_app / item.name
        if item.name.endswith(".log"):
            continue
        if item.is_dir():
            shutil.copytree(item, dest,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.log"))
            n += sum(1 for _ in dest.rglob("*") if _.is_file())
        else:
            shutil.copy2(item, dest)
            n += 1
    return n


def main() -> None:
    ap = argparse.ArgumentParser(description="Збірка чистої клієнтської версії")
    ap.add_argument("--out", default=str(ROOT / "dist"),
                    help="тека для виходу (типово ../dist)")
    args = ap.parse_args()

    ver = app_version()
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    build = out / "FarmApp_client"
    if build.exists():
        shutil.rmtree(build)
    (build / "app").mkdir(parents=True)

    nfiles = copy_code(build / "app")

    # порожні реквізити
    (build / "app" / "config").mkdir(exist_ok=True)
    (build / "app" / "config" / "business.json").write_text(
        BLANK_BUSINESS, encoding="utf-8")

    # лаунчери + інструкція
    # Резервні запускачі через термінал (для першого запуску / діагностики)
    # .bat має бути ASCII + CRLF, інакше cmd ламає парсинг рядків.
    (build / "run_server.bat").write_text(
        WIN_BAT.replace("\n", "\r\n"), encoding="ascii")
    mac = build / "start_server_mac.command"
    mac.write_text(MAC_CMD, encoding="utf-8")
    os.chmod(mac, 0o755)
    (build / "README.txt").write_text(README_TXT, encoding="utf-8")

    # Значок-пульт (вікно керування сервером, без термінала)
    _write_mac_app(build, "Облік ферми", MAC_APP_RUN)               # macOS
    (build / "Облік ферми.bat").write_text(
        WIN_GUI_BAT.replace("\n", "\r\n"), encoding="ascii")  # Windows

    # PDF-інструкція (якщо згенерована поряд у dist/) — кладемо в пакет
    guide = out / "FarmApp_QuickStart.pdf"
    if guide.exists():
        shutil.copy2(guide, build / "Інструкція_швидкий_старт.pdf")

    # zip (назва без версії — завжди однакова). Зберігаємо прапорці виконання
    # (потрібні для .app/run і .command на macOS).
    zpath = out / "FarmApp_client.zip"
    if zpath.exists():
        zpath.unlink()
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(build.rglob("*")):
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            rel = str(p.relative_to(out))
            if p.is_dir():
                rel += "/"
            zi = zipfile.ZipInfo.from_file(p, rel)
            zi.compress_type = zipfile.ZIP_DEFLATED
            # зберегти права (виконуваний біт для скриптів/бандлів)
            zi.external_attr = (p.stat().st_mode & 0xFFFF) << 16
            if p.is_dir():
                z.writestr(zi, b"")
            else:
                z.writestr(zi, p.read_bytes())

    print(f"✓ Клієнтський пакет: {zpath}")
    print(f"  Версія: {ver} · файлів коду: {nfiles}")
    print("  Без бази, користувачів, ліцензії й налаштувань — "
          "усе задається при першому запуску в клієнта.")


if __name__ == "__main__":
    main()
