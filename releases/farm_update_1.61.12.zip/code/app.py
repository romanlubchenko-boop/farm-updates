from vet_pharmacy.ui import VetPharmacyApp


if __name__ == "__main__":
    VetPharmacyApp().run()
