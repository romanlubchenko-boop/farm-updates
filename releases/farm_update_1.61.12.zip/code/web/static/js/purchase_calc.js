/* ============================================================
   Спільний модуль розрахунків секції «Закупка».
   Використовується і формою приходу, і модалом редагування —
   щоб обидва поводилися абсолютно однаково.

   createPurchaseCalc(cfg) очікує у cfg посилання на DOM-елементи:
     section      — .form-section з атрибутом data-vat
     toggleButtons — NodeList кнопок .seg-btn (необов'язково)
     hint         — span-підказка у заголовку (необов'язково)
     lblPriceNoVat, lblSumNoVat — span-підписи полів (необов'язково)
     qty
     priceNoVat, priceVat, sumNoVat, sumVat
     vatSummary   — блок «Сума ПДВ» (необов'язково)
     markup, priceOut
     marginHint   — блок «Маржа» (необов'язково)
     storageKey   — ключ localStorage для режиму ПДВ (необов'язково)
     warnNoQty    — true: показувати toast, якщо вводять суму без к-сті
   ============================================================ */

function createPurchaseCalc(cfg) {
    const STANDARD_VAT = 20;
    const useToggle = !!(cfg.toggleButtons && cfg.toggleButtons.length);

    let vatMode = 'with';
    if (cfg.storageKey) {
        vatMode = localStorage.getItem(cfg.storageKey) || 'with';
    }
    let lastEditedField = null;   // 'p_novat' | 'p_vat' | 's_novat' | 's_vat'
    let lastEditedSale  = null;   // 'markup' | 'price'

    function round(n, d = 2) {
        const k = Math.pow(10, d);
        return Math.round((Number(n) + Number.EPSILON) * k) / k;
    }
    // Ставка ПДВ: у режимі «з ПДВ» береться з поля (напр. 20 або 7),
    // інакше 0. Якщо поле порожнє/некоректне — стандартні 20%.
    function activeVatRate() {
        if (vatMode !== 'with') return 0;
        if (cfg.vatRateInput) {
            const r = parseFloat(String(cfg.vatRateInput.value).replace(',', '.'));
            if (isFinite(r) && r >= 0) return r;
        }
        return STANDARD_VAT;
    }
    function vatCoef() { return 1 + activeVatRate() / 100; }

    function applyVatMode() {
        if (cfg.section) cfg.section.dataset.vat = vatMode;
        if (useToggle) {
            cfg.toggleButtons.forEach((b) =>
                b.classList.toggle('is-active', b.dataset.vatMode === vatMode));
        }
        if (cfg.hint) {
            cfg.hint.textContent = vatMode === 'without'
                ? 'без ПДВ — введіть ціну АБО суму'
                : 'введіть будь-яке з 4 значень — решта обчислиться';
        }
        if (cfg.lblPriceNoVat) {
            cfg.lblPriceNoVat.textContent =
                vatMode === 'without' ? 'Ціна, ₴' : 'Ціна без ПДВ, ₴';
        }
        if (cfg.lblSumNoVat) {
            cfg.lblSumNoVat.textContent =
                vatMode === 'without' ? 'Сума, ₴' : 'Сума без ПДВ, ₴';
        }
        if (vatMode === 'without') {
            cfg.priceVat.value = '';
            cfg.sumVat.value = '';
        }
        recalcPrices();
    }

    function recalcPrices() {
        const k = vatCoef();
        const qty = parseFloat(cfg.qty.value) || 0;

        const v_p_novat = parseFloat(cfg.priceNoVat.value) || 0;
        const v_p_vat   = parseFloat(cfg.priceVat.value)   || 0;
        const v_s_novat = parseFloat(cfg.sumNoVat.value)   || 0;
        const v_s_vat   = parseFloat(cfg.sumVat.value)     || 0;

        let canonical = null;  // ціна без ПДВ
        switch (lastEditedField) {
            case 'p_novat': canonical = v_p_novat; break;
            case 'p_vat':   canonical = v_p_vat / k; break;
            case 's_novat': canonical = qty > 0 ? v_s_novat / qty : null; break;
            case 's_vat':   canonical = qty > 0 ? v_s_vat / (k * qty) : null; break;
            default:
                if (v_p_novat)             canonical = v_p_novat;
                else if (v_p_vat)          canonical = v_p_vat / k;
                else if (v_s_novat && qty) canonical = v_s_novat / qty;
                else if (v_s_vat && qty)   canonical = v_s_vat / (k * qty);
        }

        if (canonical == null || !isFinite(canonical) || canonical <= 0) {
            if (qty > 0) {
                if (lastEditedField !== 's_novat')
                    cfg.sumNoVat.value = v_p_novat ? round(v_p_novat * qty, 4) : '';
                if (lastEditedField !== 's_vat')
                    cfg.sumVat.value = v_p_vat ? round(v_p_vat * qty, 4) : '';
            }
        } else {
            const newPNoVat = round(canonical, 4);
            const newPVat   = round(canonical * k, 4);
            const newSNoVat = qty > 0 ? round(canonical * qty, 4) : '';
            const newSVat   = qty > 0 ? round(canonical * k * qty, 4) : '';

            if (lastEditedField !== 'p_novat') cfg.priceNoVat.value = newPNoVat || '';
            if (lastEditedField !== 'p_vat')   cfg.priceVat.value   = newPVat   || '';
            if (lastEditedField !== 's_novat') cfg.sumNoVat.value   = newSNoVat;
            if (lastEditedField !== 's_vat')   cfg.sumVat.value     = newSVat;
        }

        if (cfg.vatSummary) {
            const vatAmount = round(
                (parseFloat(cfg.sumVat.value) || 0) - (parseFloat(cfg.sumNoVat.value) || 0), 4);
            const vatStr = vatAmount.toLocaleString('uk-UA', {
                minimumFractionDigits: 2, maximumFractionDigits: 4,
            });
            cfg.vatSummary.innerHTML = `Сума ПДВ: <strong>${vatStr} ₴</strong>`;
        }

        recalcSale();
    }

    function recalcSale() {
        // Секція продажу необов'язкова (некомерційний прихід — лише закупка з ПДВ)
        if (!cfg.priceOut && !cfg.markup) return;
        const priceIn = parseFloat(cfg.priceVat.value) || 0;  // продажна — від ціни з ПДВ
        const markup  = cfg.markup ? (parseFloat(cfg.markup.value) || 0) : 0;
        const sale    = cfg.priceOut ? (parseFloat(cfg.priceOut.value) || 0) : 0;

        if (lastEditedSale === 'markup' || (markup && !sale)) {
            if (priceIn) cfg.priceOut.value = (priceIn * (1 + markup / 100)).toFixed(2);
        } else if (lastEditedSale === 'price') {
            if (priceIn && sale) cfg.markup.value = round(((sale / priceIn) - 1) * 100, 2);
        } else {
            if (priceIn && markup && !sale) {
                cfg.priceOut.value = (priceIn * (1 + markup / 100)).toFixed(2);
            } else if (priceIn && sale && !markup) {
                cfg.markup.value = round(((sale / priceIn) - 1) * 100, 2);
            }
        }

        if (cfg.marginHint) {
            const finalSale = parseFloat(cfg.priceOut.value) || 0;
            const margin = round(finalSale - priceIn, 2);
            cfg.marginHint.textContent = margin.toLocaleString('uk-UA', {
                minimumFractionDigits: 2, maximumFractionDigits: 2,
            }) + ' ₴';
            cfg.marginHint.classList.toggle('negative', margin < 0);
        }
    }

    /* ---- події ---- */

    cfg.priceNoVat.addEventListener('input', () => { lastEditedField = 'p_novat'; recalcPrices(); });
    cfg.priceVat  .addEventListener('input', () => { lastEditedField = 'p_vat';   recalcPrices(); });
    cfg.sumNoVat  .addEventListener('input', () => {
        lastEditedField = 's_novat';
        if (cfg.warnNoQty && !(parseFloat(cfg.qty.value) > 0) && cfg.sumNoVat.value) {
            toast('Спочатку вкажіть кількість, щоб обчислити ціну', 'warn');
        }
        recalcPrices();
    });
    cfg.sumVat.addEventListener('input', () => {
        lastEditedField = 's_vat';
        if (cfg.warnNoQty && !(parseFloat(cfg.qty.value) > 0) && cfg.sumVat.value) {
            toast('Спочатку вкажіть кількість, щоб обчислити ціну', 'warn');
        }
        recalcPrices();
    });
    cfg.qty.addEventListener('input', recalcPrices);

    if (cfg.vatRateInput) {
        cfg.vatRateInput.addEventListener('input', recalcPrices);
    }

    if (cfg.markup) {
        cfg.markup.addEventListener('input',  () => { lastEditedSale = 'markup'; recalcSale(); });
    }
    if (cfg.priceOut) {
        cfg.priceOut.addEventListener('input', () => { lastEditedSale = 'price';  recalcSale(); });
        cfg.priceOut.addEventListener('blur', () => {
            const v = parseFloat(cfg.priceOut.value);
            cfg.priceOut.value = (v > 0) ? v.toFixed(2) : '';
        });
    }

    if (useToggle) {
        cfg.toggleButtons.forEach((btn) => {
            btn.addEventListener('click', () => {
                vatMode = btn.dataset.vatMode;
                if (cfg.storageKey) localStorage.setItem(cfg.storageKey, vatMode);
                applyVatMode();
            });
        });
    }

    /* ---- публічний інтерфейс ---- */

    return {
        recalcPrices,
        applyVatMode,
        getVatRate: activeVatRate,
        getVatMode: () => vatMode,
        setVatMode(mode) {
            vatMode = (mode === 'without') ? 'without' : 'with';
            if (cfg.storageKey) localStorage.setItem(cfg.storageKey, vatMode);
            applyVatMode();
        },
        resetEditState() { lastEditedField = null; lastEditedSale = null; },
    };
}
