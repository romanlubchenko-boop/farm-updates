/* ============ Генератор штрихкоду EAN-13 ============
   Малює коректний EAN-13 у вигляді SVG. Працює повністю офлайн,
   без зовнішніх бібліотек. Доступ через глобальний об'єкт Barcode. */

(function (global) {
    'use strict';

    // Кодування цифр: L (ліві непарні), G (ліві парні), R (праві).
    const L = ['0001101', '0011001', '0010011', '0111101', '0100011',
               '0110001', '0101111', '0111011', '0110111', '0001011'];
    const G = ['0100111', '0110011', '0011011', '0100001', '0011101',
               '0111001', '0000101', '0010001', '0001001', '0010111'];
    const R = ['1110010', '1100110', '1101100', '1000010', '1011100',
               '1001110', '1010000', '1000100', '1001000', '1110100'];
    // Парність лівої групи залежно від першої цифри коду.
    const PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG',
                    'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

    /** Контрольна (13-та) цифра за першими 12 цифрами коду. */
    function ean13CheckDigit(d12) {
        let s = 0;
        for (let i = 0; i < 12; i++) {
            const d = +d12[i];
            s += (i % 2 === 0) ? d : d * 3;
        }
        return (10 - (s % 10)) % 10;
    }

    /** Перевірка, чи рядок є коректним 13-значним кодом EAN-13. */
    function isValidEAN13(code) {
        if (!/^\d{13}$/.test(code)) return false;
        return ean13CheckDigit(code.slice(0, 12)) === +code[12];
    }

    /**
     * Повертає рядок SVG зі штрихкодом EAN-13.
     * @param {string} code  13 цифр
     * @param {object} [opts] { module, barHeight }
     */
    function ean13SVG(code, opts) {
        opts = opts || {};
        if (!isValidEAN13(code)) {
            throw new Error('Некоректний код EAN-13: ' + code);
        }
        const mod = opts.module || 3;        // ширина одного модуля, px
        const barH = opts.barHeight || 70;   // висота штриха, px
        const quiet = mod * 11;              // «тиха зона» з боків
        const fontH = 14;
        const guardExtra = 9;                // наскільки довші межові штрихи

        const first = code[0];
        const left = code.slice(1, 7);
        const right = code.slice(7, 13);
        const parity = PARITY[+first];

        // Збираємо послідовність модулів (0/1).
        let bits = '101';                    // ліва межа
        for (let i = 0; i < 6; i++) {
            const d = +left[i];
            bits += (parity[i] === 'L') ? L[d] : G[d];
        }
        bits += '01010';                     // центральна межа
        for (let i = 0; i < 6; i++) {
            bits += R[+right[i]];
        }
        bits += '101';                       // права межа

        const totalW = quiet * 2 + bits.length * mod;
        const totalH = barH + guardExtra + fontH + 6;

        // Модулі, що належать межам, — їх штрихи довші.
        const guard = new Set([0, 1, 2, 45, 46, 47, 48, 49, 92, 93, 94]);

        let rects = '';
        let x = quiet;
        for (let i = 0; i < bits.length; i++) {
            if (bits[i] === '1') {
                const h = guard.has(i) ? barH + guardExtra : barH;
                rects += '<rect x="' + x + '" y="0" width="' + mod +
                         '" height="' + h + '"/>';
            }
            x += mod;
        }

        // Підписи цифр під штрихкодом.
        const yText = barH + guardExtra + fontH;
        const digX = (startMod, idx) =>
            quiet + (startMod + idx * 7 + 3.5) * mod;   // центр цифри

        let texts = '<text x="' + (quiet - mod * 4) + '" y="' + yText +
                    '" text-anchor="middle">' + first + '</text>';
        for (let i = 0; i < 6; i++) {
            texts += '<text x="' + digX(3, i) + '" y="' + yText +
                     '" text-anchor="middle">' + left[i] + '</text>';
        }
        for (let i = 0; i < 6; i++) {
            texts += '<text x="' + digX(50, i) + '" y="' + yText +
                     '" text-anchor="middle">' + right[i] + '</text>';
        }

        return '<svg xmlns="http://www.w3.org/2000/svg" width="' + totalW +
               '" height="' + totalH + '" viewBox="0 0 ' + totalW + ' ' +
               totalH + '">' +
               '<rect x="0" y="0" width="' + totalW + '" height="' + totalH +
               '" fill="#ffffff"/>' +
               '<g fill="#000000">' + rects + '</g>' +
               '<g fill="#000000" font-family="monospace" font-size="' +
               fontH + '">' + texts + '</g></svg>';
    }

    global.Barcode = { ean13SVG: ean13SVG, ean13CheckDigit: ean13CheckDigit,
                       isValidEAN13: isValidEAN13 };
})(window);
