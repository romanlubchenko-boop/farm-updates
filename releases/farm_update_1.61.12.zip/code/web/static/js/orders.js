'use strict';
/* Сторінка «Схеми» — схеми лікування/профілактики по блоках і розрахунок
   замовлення. Норма (доза × поголів'я × період) → флакони/штуки через вміст
   упаковки товару. Гілка визначається API_BASE (аптека або /m). */

let products = [];   // {id, name, dose_unit, unit, pack_content}
let blocks   = [];   // {id, name}
let schemes  = [];
let herdGroups    = [];   // групи стада (для джерела поголів'я)
let herdMoveTypes = [];   // типи руху (для джерела поголів'я)

const schemesBody    = document.querySelector('#schemesTable tbody');
const needByBlock    = document.getElementById('needByBlock');
const orderBody      = document.querySelector('#orderTable tbody');
const orderCount     = document.getElementById('orderCount');
const orderSearch     = document.getElementById('orderSearch');
const toggleUnusedBtn = document.getElementById('toggleUnused');
let lastOrder = [];          // останній список «До замовлення» (усі товари)
let showUnusedOnly = false;  // фільтр «Не задіяні» (товари не в жодній схемі)
const schemeForm     = document.getElementById('schemeForm');
const schBlock       = document.getElementById('schBlock');
const schLinesBody   = document.querySelector('#schLines tbody');
const schemeModalTitle = document.getElementById('schemeModalTitle');
const schHcSource    = document.getElementById('schHcSource');
const schHcManualWrap = document.getElementById('schHcManualWrap');
const schHcRefWrap   = document.getElementById('schHcRefWrap');
const schHcRef       = document.getElementById('schHcRef');
const schHcRefLabel  = document.getElementById('schHcRefLabel');

// Перемикання полів джерела поголів'я: вручну / група стада / тип руху.
function updateHcSourceUI(selRef) {
    const src = schHcSource.value || 'manual';
    const isManual = src === 'manual';
    schHcManualWrap.hidden = !isManual;
    schHcRefWrap.hidden = isManual;
    if (isManual) return;
    const list = src === 'group' ? herdGroups : herdMoveTypes;
    schHcRefLabel.textContent = src === 'group' ? 'Група стада' : 'Тип руху';
    schHcRef.innerHTML = '<option value="">—</option>'
        + list.map((x) => `<option value="${x.id}">${escapeHtml(x.name)}</option>`).join('');
    if (selRef != null) schHcRef.value = String(selRef);
}

const PERIODS = [['once', 'разово (курс)'], ['day', 'щодня'], ['week', 'щотижня'], ['month', 'щомісяця']];
const UNITS = ['мл', 'г', 'табл', 'туб', 'шт', 'уп', 'фл', 'доза'];
const BASES = [['head', 'на голову'], ['time', 'на період']];
const MONTHS_FULL = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень',
    'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];

const planMonth   = document.getElementById('planMonth');
const planYear    = document.getElementById('planYear');
const orderCsvLink = document.getElementById('orderCsvLink');

// Заповнити селектори місяця/року плану. Дефолт — поточний; якщо збережено
// раніше (localStorage) — відновлюємо вибір (рік: поточний ±1 + збережений).
function initPlanSelectors() {
    const now = new Date();
    const curY = now.getFullYear();
    let selM = now.getMonth() + 1;
    let selY = curY;
    try {
        const sm = parseInt(localStorage.getItem('vetpharm:plan_month'), 10);
        const sy = parseInt(localStorage.getItem('vetpharm:plan_year'), 10);
        if (sm >= 1 && sm <= 12) selM = sm;
        if (sy >= 2000 && sy <= 2100) selY = sy;
    } catch (e) { /* ignore */ }
    planMonth.innerHTML = MONTHS_FULL.map((m, i) =>
        `<option value="${i + 1}" ${i + 1 === selM ? 'selected' : ''}>${m}</option>`).join('');
    const years = [curY - 1, curY, curY + 1];
    if (years.indexOf(selY) === -1) years.push(selY);
    years.sort((a, b) => a - b);
    planYear.innerHTML = years.map((yy) =>
        `<option value="${yy}" ${yy === selY ? 'selected' : ''}>${yy}</option>`).join('');
}

function savePlanSel() {
    try {
        localStorage.setItem('vetpharm:plan_month', planMonth.value);
        localStorage.setItem('vetpharm:plan_year', planYear.value);
    } catch (e) { /* ignore */ }
}

// Перерахувати на обраний місяць: і поголів'я у списку схем («Голів»), і
// потребу «До замовлення», і посилання CSV.
async function refreshForecast() {
    const qs = '?year=' + planYear.value + '&month=' + planMonth.value;
    if (orderCsvLink) orderCsvLink.href = (window.API_BASE || '') + '/api/export/order.csv' + qs;
    const rs = await apiGet('/api/schemes' + qs);
    if (rs.ok) { schemes = rs.items || []; renderSchemes(); }
    const rf = await apiGet('/api/scheme-forecast' + qs);
    if (rf.ok) renderForecast(rf);
}

function basisOptions(sel) {
    return BASES.map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${l}</option>`).join('');
}

function prodById(id) { return products.find((p) => String(p.id) === String(id)); }

function unitOptions(sel) {
    sel = sel || 'мл';
    let opts = UNITS.slice();
    if (sel && opts.indexOf(sel) === -1) opts = [sel].concat(opts);
    return opts.map((u) => `<option value="${escapeHtml(u)}" ${u === sel ? 'selected' : ''}>${escapeHtml(u)}</option>`).join('');
}

function productOptions(sel) {
    return ['<option value="">— медикамент —</option>'].concat(
        products.map((p) => `<option value="${p.id}" ${String(p.id) === String(sel) ? 'selected' : ''}>${escapeHtml(p.name)}</option>`)
    ).join('');
}
function periodOptions(sel) {
    return PERIODS.map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${l}</option>`).join('');
}

function addLineRow(line) {
    line = line || {};
    const tr = document.createElement('tr');
    const unit = line.dose_unit || (prodById(line.product_id) || {}).dose_unit || '';
    const times = (line.times_per != null && line.times_per !== '') ? line.times_per : 1;
    tr.innerHTML =
        `<td><select class="ln-prod">${productOptions(line.product_id)}</select></td>`
        + `<td><select class="ln-basis">${basisOptions(line.basis || 'head')}</select></td>`
        + `<td class="num"><input type="text" inputmode="decimal" class="ln-dose" value="${line.dose_per_head != null ? line.dose_per_head : ''}"></td>`
        + `<td><select class="ln-unit">${unitOptions(unit)}</select></td>`
        + `<td class="num"><input type="text" inputmode="numeric" class="ln-times" value="${times}"></td>`
        + `<td><select class="ln-period">${periodOptions(line.period || 'once')}</select></td>`
        + `<td class="num"><button type="button" class="btn btn-icon btn-icon-danger ln-del" title="Прибрати">×</button></td>`;
    schLinesBody.appendChild(tr);
    const prodSel = tr.querySelector('.ln-prod');
    prodSel.addEventListener('change', () => {
        const du = (prodById(prodSel.value) || {}).dose_unit;
        if (du) {
            const uSel = tr.querySelector('.ln-unit');
            if (UNITS.indexOf(du) === -1 && !uSel.querySelector(`option[value="${du}"]`)) {
                uSel.insertAdjacentHTML('afterbegin', `<option value="${escapeHtml(du)}">${escapeHtml(du)}</option>`);
            }
            uSel.value = du;
        }
    });
    tr.querySelector('.ln-del').addEventListener('click', () => tr.remove());
}

function renderSchemes() {
    if (!schemes.length) {
        schemesBody.innerHTML = '<tr><td colspan="6" class="empty">Схем ще немає</td></tr>';
        return;
    }
    schemesBody.innerHTML = schemes.map((s, i) =>
        `<tr draggable="true" data-id="${s.id}">
            <td class="seq-col"><span class="drag-handle" title="Перетягніть, щоб змінити порядок">⠿</span><span class="seq-num">${i + 1}</span></td>
            <td>${escapeHtml(s.name || '')}</td>
            <td class="text-mute">${escapeHtml(s.block_name || '—')}</td>
            <td class="num">${fmtNum(s.eff_headcount || 0)}${s.hc_ref_name ? ` <span class="text-mute">(${escapeHtml(s.hc_ref_name)})</span>` : ''}</td>
            <td class="num">${(s.lines || []).length}</td>
            <td class="num">
                <button class="btn btn-icon" data-edit="${s.id}" title="Редагувати">✎</button>
                <button class="btn btn-icon btn-icon-danger" data-del="${s.id}" title="Видалити">🗑</button>
            </td>
        </tr>`).join('');
}

// Перетягування рядків схем для зміни порядку. Слухачі — на tbody (делеговано),
// тож переживають перерендер. Під час dragover фізично пересуваємо рядок у DOM
// (живий прев'ю), на dragend перенумеровуємо та зберігаємо порядок на сервері.
function rowAfterPointer(y) {
    const rows = [...schemesBody.querySelectorAll('tr[data-id]:not(.dragging)')];
    let best = null, bestOff = -Infinity;
    rows.forEach((row) => {
        const box = row.getBoundingClientRect();
        const off = y - box.top - box.height / 2;
        if (off < 0 && off > bestOff) { bestOff = off; best = row; }
    });
    return best;
}

schemesBody.addEventListener('dragstart', (e) => {
    const tr = e.target.closest('tr[data-id]');
    if (!tr) return;
    tr.classList.add('dragging');
    if (e.dataTransfer) e.dataTransfer.effectAllowed = 'move';
});

schemesBody.addEventListener('dragover', (e) => {
    const dragging = schemesBody.querySelector('tr.dragging');
    if (!dragging) return;
    e.preventDefault();
    const after = rowAfterPointer(e.clientY);
    if (after == null) schemesBody.appendChild(dragging);
    else schemesBody.insertBefore(dragging, after);
});

schemesBody.addEventListener('dragend', async () => {
    const dragging = schemesBody.querySelector('tr.dragging');
    if (dragging) dragging.classList.remove('dragging');
    const order = [...schemesBody.querySelectorAll('tr[data-id]')].map((tr, i) => {
        const n = tr.querySelector('.seq-num');
        if (n) n.textContent = i + 1;
        return tr.dataset.id;
    });
    schemes.sort((a, b) => order.indexOf(String(a.id)) - order.indexOf(String(b.id)));
    const r = await apiSend('/api/schemes/reorder', 'POST', { order });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); loadAll(); }
});

function renderForecast(f) {
    const blocksArr = f.blocks || [];
    needByBlock.innerHTML = blocksArr.length ? blocksArr.map((b) =>
        `<div class="need-block">
            <div class="need-block-title">${escapeHtml(b.block)}</div>
            <table class="table table-compact"><tbody>
                ${b.rows.map((r) => `<tr><td>${escapeHtml(r.name)}</td><td class="num">${fmtNum(r.need)} ${escapeHtml(r.unit || '')}</td></tr>`).join('')}
            </tbody></table>
        </div>`).join('') : '<p class="empty">Поки порожньо</p>';

    lastOrder = f.order || [];
    renderOrderTable();
}

/* Рендер «До замовлення» з фільтрами (пошук, «не задіяні») і кольорами:
   зелений — у схемі й треба замовити; без кольору — у схемі, замовляти не треба;
   червоний — на складі, але не в жодній схемі (не задіяний). */
function renderOrderTable() {
    const q = ((orderSearch && orderSearch.value) || '').trim().toLowerCase();
    let rows = lastOrder;
    if (showUnusedOnly) rows = rows.filter((o) => !o.in_scheme);
    if (q) rows = rows.filter((o) =>
        ((o.name || '').toLowerCase().includes(q)) || ((o.barcode || '').toLowerCase().includes(q)));

    const toOrder = lastOrder.filter((o) => (o.order_qty || 0) > 0).length;
    const unused = lastOrder.filter((o) => !o.in_scheme).length;
    orderCount.textContent = lastOrder.length
        ? `позицій: ${lastOrder.length} · до замовлення: ${toOrder} · не задіяні: ${unused}` : '';

    if (!rows.length) {
        orderBody.innerHTML = `<tr><td colspan="4" class="empty">${lastOrder.length ? 'Нічого не знайдено' : 'Додайте товари або схеми'}</td></tr>`;
        return;
    }
    orderBody.innerHTML = rows.map((o) => {
        if (o.note === 'no_pack') {
            return `<tr>
                <td>${escapeHtml(o.name)}</td>
                <td class="text-warn" colspan="3">задайте вміст упаковки в картці товару</td>
            </tr>`;
        }
        let cls = '';
        if (!o.in_scheme) cls = 'row-urgent';          // на складі, не в схемі — червоний
        else if (o.order_qty > 0) cls = 'row-need';    // у схемі й треба замовити — зелений
        const need = (o.need == null) ? '<span class="text-mute">—</span>'
            : `${fmtNum(o.need)} ${escapeHtml(o.unit || '')}`;
        const ord = (o.order_qty == null) ? '<span class="text-mute">—</span>'
            : (o.order_qty > 0 ? `<strong>${fmtNum(o.order_qty)}</strong>` : '<span class="text-mute">0</span>');
        return `<tr class="${cls}">
            <td>${escapeHtml(o.name)}</td>
            <td class="num">${need}</td>
            <td class="num">${fmtNum(o.stock)}</td>
            <td class="num">${ord}</td>
        </tr>`;
    }).join('');
}

if (orderSearch) orderSearch.addEventListener('input', renderOrderTable);
if (toggleUnusedBtn) toggleUnusedBtn.addEventListener('click', () => {
    showUnusedOnly = !showUnusedOnly;
    toggleUnusedBtn.classList.toggle('is-active', showUnusedOnly);
    renderOrderTable();
});

async function loadAll() {
    const [rp, rb, rh] = await Promise.all([
        apiGet('/api/products'), apiGet('/api/blocks'), apiGet('/api/herd')]);
    products = (rp.ok && rp.items) || [];
    blocks   = (rb.ok && rb.items) || [];
    herdGroups    = (rh.ok && rh.groups) || [];
    herdMoveTypes = (rh.ok && rh.move_types) || [];
    schBlock.innerHTML = '<option value="">— блок —</option>'
        + blocks.map((b) => `<option value="${b.id}">${escapeHtml(b.name)}</option>`).join('');
    if (!planMonth.options.length) initPlanSelectors();
    await refreshForecast();   // вантажить схеми + прогноз на обраний місяць
}

function openScheme(s) {
    schemeForm.reset();
    schLinesBody.innerHTML = '';
    if (s) {
        schemeModalTitle.textContent = 'Редагування схеми';
        schemeForm.id.value = s.id;
        schemeForm.name.value = s.name || '';
        schBlock.value = s.block_id || '';
        schemeForm.headcount.value = s.headcount || '';
        schHcSource.value = s.hc_source || 'manual';
        updateHcSourceUI(s.hc_ref_id);
        (s.lines || []).forEach(addLineRow);
        if (!(s.lines || []).length) addLineRow();
    } else {
        schemeModalTitle.textContent = 'Нова схема';
        schemeForm.id.value = '';
        schHcSource.value = 'manual';
        updateHcSourceUI(null);
        addLineRow();
    }
    openModal('schemeModal');
    // Регульована ширина колонок таблиці медикаментів. Викликаємо після показу
    // модалу — інакше прихований елемент має нульову ширину й колонки злипаються.
    requestAnimationFrame(() => makeColumnsResizable('schLines', 'vetpharm:sch_colw'));
}

document.getElementById('addSchemeBtn').addEventListener('click', () => openScheme(null));
document.getElementById('addLineBtn').addEventListener('click', () => addLineRow());
schHcSource.addEventListener('change', () => updateHcSourceUI(null));
planMonth.addEventListener('change', () => { savePlanSel(); refreshForecast(); });
planYear.addEventListener('change', () => { savePlanSel(); refreshForecast(); });

schemesBody.addEventListener('click', async (e) => {
    const ed = e.target.closest('[data-edit]');
    const del = e.target.closest('[data-del]');
    if (ed) {
        const s = schemes.find((x) => String(x.id) === ed.dataset.edit);
        if (s) openScheme(s);
    } else if (del) {
        if (!await confirmAction('Видалити цю схему?')) return;
        const r = await apiSend('/api/schemes/' + del.dataset.del, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Схему видалено', 'success');
        loadAll();
    }
});

schemeForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const lines = [];
    schLinesBody.querySelectorAll('tr').forEach((tr) => {
        const pid = tr.querySelector('.ln-prod').value;
        if (!pid) return;
        lines.push({
            product_id: pid,
            basis: tr.querySelector('.ln-basis').value || 'head',
            dose_per_head: (tr.querySelector('.ln-dose').value || '').replace(',', '.'),
            dose_unit: tr.querySelector('.ln-unit').value || '',
            times_per: (tr.querySelector('.ln-times').value || '1').replace(',', '.'),
            period: tr.querySelector('.ln-period').value || 'day',
        });
    });
    const src = schHcSource.value || 'manual';
    const payload = {
        id: schemeForm.id.value || null,
        name: schemeForm.name.value,
        block_id: schBlock.value || null,
        headcount: (schemeForm.headcount.value || '').replace(',', '.'),
        hc_source: src,
        hc_ref_id: src === 'manual' ? null : (schHcRef.value || null),
        lines: lines,
    };
    const r = await apiSend('/api/schemes', 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Збережено', 'success');
    closeModal('schemeModal');
    loadAll();
});

document.addEventListener('DOMContentLoaded', loadAll);
