/* ============ «Потребує уваги» — офлайн-конфлікти (адмін) ============ */
(function () {
    'use strict';
    var body = document.getElementById('confBody');
    var cnt = document.getElementById('confCount');
    if (!body) return;

    var TYPE = { sale: 'Видача', receipt: 'Прихід', inventory: 'Інвентаризація' };
    function probText(c) {
        if (c.conflict === 'negative_stock') return 'Мінусовий залишок (видано більше, ніж було)';
        return c.conflict || (c.status === 'rejected' ? 'Відхилено сервером' : '');
    }
    function fmtDt(s) {
        if (!s) return '';
        var d = new Date(String(s).replace(' ', 'T'));
        if (isNaN(d)) return s;
        var p = function (n) { return (n < 10 ? '0' : '') + n; };
        return p(d.getDate()) + '.' + p(d.getMonth() + 1) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
    }

    async function load() {
        var r = await apiGet('/api/sync/conflicts');
        if (!r.ok) {
            body.innerHTML = '<tr><td colspan="6" class="empty">' + escapeHtml(r.error || 'Помилка') + '</td></tr>';
            return;
        }
        var items = r.items || [];
        cnt.textContent = items.length ? '· ' + items.length : '';
        if (!items.length) {
            body.innerHTML = '<tr><td colspan="6" class="empty">Немає операцій, що потребують уваги 👍</td></tr>';
            return;
        }
        body.innerHTML = items.map(function (c) {
            return '<tr>'
                + '<td>' + escapeHtml(fmtDt(c.applied_at)) + '</td>'
                + '<td>' + escapeHtml(TYPE[c.type] || c.type || '') + '</td>'
                + '<td>' + escapeHtml(c.sale_no || '—') + '</td>'
                + '<td>' + escapeHtml(c.username || '—') + '</td>'
                + '<td class="prob"><span class="conf-badge ' + escapeHtml(c.status) + '">'
                + (c.status === 'rejected' ? 'відхилено' : 'конфлікт') + '</span> ' + escapeHtml(probText(c)) + '</td>'
                + '<td><button class="btn btn-sm" data-resolve="' + escapeHtml(c.op_id) + '">Прийнято</button></td>'
                + '</tr>';
        }).join('');
    }

    body.addEventListener('click', async function (e) {
        var btn = e.target.closest('[data-resolve]');
        if (!btn) return;
        if (!await confirmAction('Позначити операцію як опрацьовану?')) return;
        var r = await apiSend('/api/sync/conflicts/' + encodeURIComponent(btn.dataset.resolve) + '/resolve', 'POST');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Позначено', 'success');
        load();
    });

    document.addEventListener('DOMContentLoaded', load);
})();
