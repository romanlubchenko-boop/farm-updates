/* ===== Звіти по складу: друк залишків на дату + звіт руху ===== */
/* ---------- друк залишків ---------- */

async function printStock() {
    const dateEl = document.getElementById('stockDate');
    const dateVal = (dateEl && dateEl.value) || new Date().toISOString().slice(0, 10);
    const r = await apiGet('/api/stock/as-of?date=' + encodeURIComponent(dateVal));
    const items = (r && r.items) || [];
    if (!items.length) { toast('На цю дату залишків немає', 'warn'); return; }
    const dParts = dateVal.split('-');
    const asOf = dParts.length === 3 ? `${dParts[2]}.${dParts[1]}.${dParts[0]}` : dateVal;
    const now = new Date().toLocaleString('uk-UA');
    let totalQty = 0, totalSum = 0;
    const rows = items.map((p, i) => {
        totalQty += Number(p.total_qty || 0);
        totalSum += Number(p.stock_value || 0);
        const low = p.total_qty <= p.min_stock;
        return `<tr>
            <td class="n">${i + 1}</td>
            <td>${escapeHtml(p.name)}</td>
            <td>${escapeHtml(p.code || '')}</td>
            <td class="c">${escapeHtml(p.unit || '')}</td>
            <td class="r${low ? ' low' : ''}">${fmtNum(p.total_qty)}</td>
            <td class="r">${fmtMoney(p.avg_price_in || 0)}</td>
            <td class="r">${fmtMoney(p.stock_value || 0)}</td>
        </tr>`;
    }).join('');

    const html = `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">
<title>Залишки на складі станом на ${asOf}</title>
<style>
  @page { margin: 12mm; }
  * { font-family: Arial, sans-serif; }
  body { margin: 0; color: #111; }
  h1 { font-size: 18px; margin: 0 0 2px; }
  .meta { font-size: 12px; color: #555; margin-bottom: 12px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #bbb; padding: 4px 6px; text-align: left; }
  th { background: #eef2f7; }
  td.n, td.c { text-align: center; }
  td.r { text-align: right; font-variant-numeric: tabular-nums; }
  td.low { color: #c0392b; font-weight: 700; }
  tfoot td { font-weight: 700; background: #f6f8fb; }
  .sign { margin-top: 26px; font-size: 12px; }
</style></head><body>
<h1>Залишки на складі станом на ${asOf}</h1>
<div class="meta">Сформовано: ${escapeHtml(now)} · Позицій: ${items.length}</div>
<table>
  <thead><tr>
    <th>№</th><th>Назва</th><th>Код</th><th>Од.</th>
    <th>Залишок</th><th>Ціна за од., ₴</th><th>Сума закуп., ₴</th>
  </tr></thead>
  <tbody>${rows}</tbody>
  <tfoot><tr>
    <td colspan="4" style="text-align:right;">Разом</td>
    <td class="r">${fmtNum(totalQty)}</td>
    <td></td>
    <td class="r">${fmtMoney(totalSum)}</td>
  </tr></tfoot>
</table>
<div class="sign">Відповідальний: ______________________&nbsp;&nbsp;&nbsp; Дата: ____________</div>
<script>window.onload=function(){window.print();};window.onafterprint=function(){window.close();};<\/script>
</body></html>`;

    const w = window.open('', '_blank', 'width=900,height=650');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(html);
    w.document.close();
}

const printStockBtn = document.getElementById('printStockBtn');
if (printStockBtn) printStockBtn.addEventListener('click', printStock);

/* ---------- звіт руху ветпрепаратів за період ---------- */

function ddmmyyyy(iso) {
    const p = (iso || '').split('-');
    return p.length === 3 ? `${p[2]}.${p[1]}.${p[0]}` : iso;
}

async function printMovement() {
    const fromEl = document.getElementById('moveFrom');
    const toEl = document.getElementById('moveTo');
    const today = new Date();
    const defFrom = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
    const defTo = today.toISOString().slice(0, 10);
    const from = (fromEl && fromEl.value) || defFrom;
    const to = (toEl && toEl.value) || defTo;
    const r = await apiGet(`/api/stock/movement?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
    const items = (r && r.items) || [];
    if (!items.length) { toast('За період руху немає', 'warn'); return; }

    let oQ = 0, oV = 0, iQ = 0, iV = 0, uQ = 0, uV = 0, cQ = 0, cV = 0;
    const rows = items.map((p, i) => {
        oQ += p.open_qty; oV += p.open_val; iQ += p.in_qty; iV += p.in_val;
        uQ += p.out_qty; uV += p.out_val; cQ += p.close_qty; cV += p.close_val;
        return `<tr>
            <td class="n">${i + 1}</td>
            <td>${escapeHtml(p.name)}</td>
            <td class="c">${escapeHtml(p.unit || '')}</td>
            <td class="r">${fmtNum(p.open_qty)}</td><td class="r">${fmtMoney(p.open_val)}</td>
            <td class="r">${fmtNum(p.in_qty)}</td><td class="r">${fmtMoney(p.in_val)}</td>
            <td class="r">${fmtNum(p.out_qty)}</td><td class="r">${fmtMoney(p.out_val)}</td>
            <td class="r b">${fmtNum(p.close_qty)}</td><td class="r b">${fmtMoney(p.close_val)}</td>
        </tr>`;
    }).join('');

    const itemPl = (window.ITEM_WORDS && window.ITEM_WORDS.gen_pl) || 'ветпрепаратів';
    const html = `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">
<title>Звіт руху ${itemPl} ${ddmmyyyy(from)}–${ddmmyyyy(to)}</title>
<style>
  @page { margin: 10mm; size: landscape; }
  * { font-family: Arial, sans-serif; }
  body { margin: 0; color: #111; }
  h1 { font-size: 16px; margin: 0 0 2px; }
  .meta { font-size: 11px; color: #555; margin-bottom: 10px; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; }
  th, td { border: 1px solid #bbb; padding: 3px 5px; }
  th { background: #eef2f7; text-align: center; }
  td.n, td.c { text-align: center; }
  td.r { text-align: right; font-variant-numeric: tabular-nums; }
  td.b { font-weight: 700; }
  tfoot td { font-weight: 700; background: #f6f8fb; }
  .sign { margin-top: 22px; font-size: 11px; }
</style></head><body>
<h1>Звіт руху ${itemPl}</h1>
<div class="meta">Період: ${ddmmyyyy(from)} – ${ddmmyyyy(to)} · Сформовано: ${escapeHtml(new Date().toLocaleString('uk-UA'))} · Позицій: ${items.length}</div>
<table>
  <thead>
    <tr>
      <th rowspan="2">№</th><th rowspan="2">Назва</th><th rowspan="2">Од.</th>
      <th colspan="2">Залишок на ${ddmmyyyy(from)}</th>
      <th colspan="2">Надходження</th>
      <th colspan="2">Видача + списання</th>
      <th colspan="2">Залишок на ${ddmmyyyy(to)}</th>
    </tr>
    <tr>
      <th>К-сть</th><th>Сума з ПДВ</th>
      <th>К-сть</th><th>Сума з ПДВ</th>
      <th>К-сть</th><th>Сума з ПДВ</th>
      <th>К-сть</th><th>Сума з ПДВ</th>
    </tr>
  </thead>
  <tbody>${rows}</tbody>
  <tfoot><tr>
    <td colspan="3" style="text-align:right;">Разом</td>
    <td class="r">${fmtNum(oQ)}</td><td class="r">${fmtMoney(oV)}</td>
    <td class="r">${fmtNum(iQ)}</td><td class="r">${fmtMoney(iV)}</td>
    <td class="r">${fmtNum(uQ)}</td><td class="r">${fmtMoney(uV)}</td>
    <td class="r">${fmtNum(cQ)}</td><td class="r">${fmtMoney(cV)}</td>
  </tr></tfoot>
</table>
<div class="sign">Відповідальний: ______________________&nbsp;&nbsp;&nbsp; Дата: ____________</div>
<script>window.onload=function(){window.print();};window.onafterprint=function(){window.close();};<\/script>
</body></html>`;

    const w = window.open('', '_blank', 'width=1100,height=700');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(html);
    w.document.close();
}

const printMovementBtn = document.getElementById('printMovementBtn');
if (printMovementBtn) printMovementBtn.addEventListener('click', printMovement);

/* ---------- звіт «Видача по блоках/отримувачах» за період ---------- */
async function printByBlock() {
    const fromEl = document.getElementById('blockFrom');
    const toEl = document.getElementById('blockTo');
    const today = new Date();
    const defFrom = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
    const defTo = today.toISOString().slice(0, 10);
    const from = (fromEl && fromEl.value) || defFrom;
    const to = (toEl && toEl.value) || defTo;
    const r = await apiGet(`/api/reports/issue-by-block?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
    const items = (r && r.items) || [];
    if (!items.length) { toast('За період видач немає', 'warn'); return; }

    // групуємо по блоку
    const blocks = [];
    const idx = {};
    let gQty = 0, gSum = 0;
    items.forEach((it) => {
        if (!(it.block in idx)) { idx[it.block] = blocks.length; blocks.push({ name: it.block, rows: [], qty: 0, sum: 0 }); }
        const g = blocks[idx[it.block]];
        g.rows.push(it); g.qty += Number(it.qty || 0); g.sum += Number(it.total || 0);
        gQty += Number(it.qty || 0); gSum += Number(it.total || 0);
    });

    const bodyRows = blocks.map((g) => {
        const rows = g.rows.map((it, i) => `<tr>
            <td class="n">${i + 1}</td>
            <td>${escapeHtml(it.product)}</td>
            <td class="c">${escapeHtml(it.unit || '')}</td>
            <td>${escapeHtml(it.recipient || '')}</td>
            <td>${it.move_type === 'WRITE_OFF' ? 'Списання' : 'Видача'}</td>
            <td class="r">${fmtNum(it.qty)}</td>
            <td class="r">${fmtMoney(it.total)}</td>
        </tr>`).join('');
        return `<tr class="grp"><td colspan="7">${BW('nom')}: ${escapeHtml(g.name)}</td></tr>${rows}
            <tr class="sub"><td colspan="5" class="r">Разом по ${BW('loc')} «${escapeHtml(g.name)}»</td>
            <td class="r">${fmtNum(g.qty)}</td><td class="r">${fmtMoney(g.sum)}</td></tr>`;
    }).join('');

    const itemPl = (window.ITEM_WORDS && window.ITEM_WORDS.gen_pl) || 'ветпрепаратів';
    const html = `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">
<title>Видача по ${BW('loc_pl')} ${ddmmyyyy(from)}–${ddmmyyyy(to)}</title>
<style>
  @page { margin: 12mm; }
  * { font-family: Arial, sans-serif; }
  body { margin: 0; color: #111; }
  h1 { font-size: 17px; margin: 0 0 2px; }
  .meta { font-size: 12px; color: #555; margin-bottom: 12px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #bbb; padding: 4px 6px; text-align: left; }
  th { background: #eef2f7; }
  td.n, td.c { text-align: center; }
  td.r { text-align: right; font-variant-numeric: tabular-nums; }
  tr.grp td { background: #e7eefc; font-weight: 700; }
  tr.sub td { background: #f6f8fb; font-weight: 700; }
  tfoot td { font-weight: 700; background: #eef2f7; }
  .sign { margin-top: 24px; font-size: 12px; }
</style></head><body>
<h1>Видача ${itemPl} по ${BW('loc_pl')}</h1>
<div class="meta">Період: ${ddmmyyyy(from)} – ${ddmmyyyy(to)} · Сформовано: ${escapeHtml(new Date().toLocaleString('uk-UA'))}</div>
<table>
  <thead><tr>
    <th>№</th><th>Назва</th><th>Од.</th><th>Кому</th><th>Тип</th>
    <th>К-сть</th><th>Сума, ₴</th>
  </tr></thead>
  <tbody>${bodyRows}</tbody>
  <tfoot><tr>
    <td colspan="5" class="r">Разом за період</td>
    <td class="r">${fmtNum(gQty)}</td><td class="r">${fmtMoney(gSum)}</td>
  </tr></tfoot>
</table>
<div class="sign">Відповідальний: ______________________&nbsp;&nbsp;&nbsp; Дата: ____________</div>
<script>window.onload=function(){window.print();};window.onafterprint=function(){window.close();};<\/script>
</body></html>`;

    const w = window.open('', '_blank', 'width=1000,height=700');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(html);
    w.document.close();
}

const printByBlockBtn = document.getElementById('printByBlockBtn');
if (printByBlockBtn) printByBlockBtn.addEventListener('click', printByBlock);

/* ---------- друк розходу кормів (по групах + категоріях + кормах) ---------- */
async function printFeedUsage() {
    const today = new Date();
    const defFrom = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
    const from = (document.getElementById('blockFrom') || {}).value || defFrom;
    const to = (document.getElementById('blockTo') || {}).value || today.toISOString().slice(0, 10);
    const qs = `?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;
    let tree, uc, ui;
    try {
        [tree, uc, ui] = await Promise.all([
            apiGet('/api/feed/feeding-tree' + qs),
            apiGet('/api/feed/usage-by-category' + qs),
            apiGet('/api/feed/usage-by-ingredient' + qs),
        ]);
    } catch (e) { toast('Не вдалося отримати дані', 'error'); return; }
    const secs = (tree && tree.sections) || [];
    const cats = (uc && uc.categories) || [];
    const ings = (ui && ui.ingredients) || [];
    if (!secs.length && !cats.length && !ings.length) { toast('За період даних немає', 'warn'); return; }

    const row = (name, kg, sum, cls) => `<tr class="${cls || ''}">
        <td>${escapeHtml(name)}</td><td class="r">${fmtNum(kg)}</td><td class="r">${fmtMoney(sum)}</td></tr>`;
    const aggIngs = (days) => {
        const m = {};
        (days || []).forEach((d) => (d.ingredients || []).forEach((it) => {
            const k = it.name || '';
            if (!m[k]) m[k] = { name: k, kg: 0, sum: 0 };
            m[k].kg += Number(it.kg || 0); m[k].sum += Number(it.sum || 0);
        }));
        return Object.values(m).sort((a, b) => b.kg - a.kg);
    };
    const sKg = (a) => a.reduce((s, x) => s + Number(x.kg || 0), 0);
    const sSum = (a) => a.reduce((s, x) => s + Number(x.sum || 0), 0);

    // По групах: Група → корми
    let gk = 0, gs = 0;
    const grp = secs.map((s) => {
        const feeds = aggIngs(s.days);
        gk += sKg(feeds); gs += sSum(feeds);
        return row(s.section, sKg(feeds), sSum(feeds), 'grp')
            + feeds.map((x) => row('   ' + x.name, x.kg, x.sum)).join('');
    }).join('') + row('Разом за період', gk, gs, 'sub');

    // По категоріях: Категорія → Підкатегорія → корми
    let ck = 0, cs = 0;
    const catRows = cats.map((c) => {
        let cck = 0, ccs = 0;
        const subHtml = (c.subs || []).map((s) => {
            const feeds = aggIngs(s.days);
            cck += sKg(feeds); ccs += sSum(feeds);
            return row('  ' + s.subgroup, sKg(feeds), sSum(feeds), 'sub')
                + feeds.map((x) => row('      ' + x.name, x.kg, x.sum)).join('');
        }).join('');
        ck += cck; cs += ccs;
        return row(c.category, cck, ccs, 'grp') + subHtml;
    }).join('') + row('Разом за період', ck, cs, 'sub');

    // По кормах: усього
    const ingRows = ings.map((g) => row(g.name, g.kg, g.sum)).join('')
        + row('Разом за період', sKg(ings), sSum(ings), 'sub');

    const tbl = (title, body) => `<h2>${title}</h2><table>
        <thead><tr><th>Назва</th><th class="r">Факт завантаження, кг</th><th class="r">Сума ₴ без ПДВ</th></tr></thead>
        <tbody>${body}</tbody></table>`;
    const html = `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">
<title>Розхід кормів ${ddmmyyyy(from)}–${ddmmyyyy(to)}</title>
<style>
  @page { margin: 12mm; }
  * { font-family: Arial, sans-serif; }
  body { margin: 0; color: #111; }
  h1 { font-size: 17px; margin: 0 0 2px; }
  h2 { font-size: 14px; margin: 16px 0 4px; }
  .meta { font-size: 12px; color: #555; margin-bottom: 6px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 6px; }
  th, td { border: 1px solid #bbb; padding: 4px 6px; text-align: left; }
  th { background: #eef2f7; }
  td.r, th.r { text-align: right; font-variant-numeric: tabular-nums; }
  tr.grp td { background: #e7eefc; font-weight: 700; }
  tr.sub td { background: #f6f8fb; font-weight: 700; }
</style></head><body>
<h1>Розхід кормів за період (факт завантаження зі складу)</h1>
<div class="meta">Період: ${ddmmyyyy(from)} – ${ddmmyyyy(to)} · Сформовано: ${escapeHtml(new Date().toLocaleString('uk-UA'))}</div>
${tbl('По групах', grp)}
${tbl('По категоріях', catRows)}
${tbl('По кормах', ingRows)}
<script>window.onload=function(){window.print();};window.onafterprint=function(){window.close();};<\/script>
</body></html>`;
    const w = window.open('', '_blank', 'width=1000,height=700');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(html); w.document.close();
}

const printFeedUsageBtn = document.getElementById('printFeedUsageBtn');
if (printFeedUsageBtn) printFeedUsageBtn.addEventListener('click', printFeedUsage);

/* ---------- завантаження звітів у Excel (за той самий період) ---------- */
function periodQS(fromId, toId) {
    const today = new Date();
    const defFrom = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
    const defTo = today.toISOString().slice(0, 10);
    const fromEl = document.getElementById(fromId);
    const toEl = document.getElementById(toId);
    const from = (fromEl && fromEl.value) || defFrom;
    const to = (toEl && toEl.value) || defTo;
    return '?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
}

const xlsMovementBtn = document.getElementById('xlsMovementBtn');
if (xlsMovementBtn) xlsMovementBtn.addEventListener('click', () => {
    window.location.href = (window.API_BASE || '') + '/api/export/movement.xlsx' + periodQS('moveFrom', 'moveTo');
});

const xlsByBlockBtn = document.getElementById('xlsByBlockBtn');
if (xlsByBlockBtn) xlsByBlockBtn.addEventListener('click', () => {
    window.location.href = (window.API_BASE || '') + '/api/export/issue-by-block.xlsx' + periodQS('blockFrom', 'blockTo');
});
