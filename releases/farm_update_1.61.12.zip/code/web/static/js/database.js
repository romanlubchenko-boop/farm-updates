/* ============ База даних: шаблони, імпорт, очищення ============ */

const importFile   = document.getElementById('importFile');
const importBtn    = document.getElementById('importBtn');
const importResult = document.getElementById('importResult');
const clearDbBtn   = document.getElementById('clearDbBtn');
const backupsList  = document.getElementById('backupsList');
const restoreFile  = document.getElementById('restoreFile');
const restoreBtn   = document.getElementById('restoreBtn');
const restoreResult = document.getElementById('restoreResult');

function fmtSize(b) {
    if (b == null) return '';
    if (b < 1024) return b + ' Б';
    if (b < 1024 * 1024) return (b / 1024).toFixed(0) + ' КБ';
    return (b / 1024 / 1024).toFixed(1) + ' МБ';
}

async function loadBackups() {
    const r = await apiGet('/api/database/backups');
    if (!r.ok || !r.items || !r.items.length) {
        backupsList.innerHTML = '<span class="empty">Ще немає автоматичних копій.</span>';
        return;
    }
    backupsList.innerHTML = r.items.map((b) =>
        '<div class="backup-item">' +
            '<a href="/api/database/backups/' + encodeURIComponent(b.name) +
            '">⤓ ' + escapeHtml(b.name) + '</a>' +
            '<span class="text-mute"> · ' + escapeHtml(b.modified) +
            ' · ' + fmtSize(b.size) + '</span>' +
        '</div>'
    ).join('');
}

restoreBtn.addEventListener('click', async () => {
    const file = restoreFile.files[0];
    if (!file) { toast('Виберіть файл резервної копії', 'warn'); return; }
    if (!await confirmAction('Замінити поточну базу даних на цей файл? Поточні дані буде втрачено (зберігається авто-копія перед відновленням).')) return;

    restoreBtn.disabled = true;
    restoreResult.hidden = true;
    const fd = new FormData();
    fd.append('file', file);
    let r;
    try {
        const resp = await fetch('/api/database/restore', { method: 'POST', body: fd });
        r = await resp.json();
    } catch (e) {
        r = { ok: false, error: 'Помилка зʼєднання із сервером' };
    }
    restoreBtn.disabled = false;

    if (!r.ok) {
        restoreResult.className = 'import-result err';
        restoreResult.textContent = r.error || 'Не вдалося відновити базу';
        restoreResult.hidden = false;
        toast(r.error || 'Помилка відновлення', 'error');
        return;
    }
    restoreResult.className = 'import-result ok';
    restoreResult.textContent = 'Базу даних успішно відновлено з резервної копії.';
    restoreResult.hidden = false;
    toast('Базу відновлено', 'success');
    restoreFile.value = '';
    loadBackups();
});

// при відкритті сторінки одразу показуємо список автоматичних копій
loadBackups();

/* ---------- версія та історія оновлень ---------- */

async function loadVersion() {
    const elApp = document.getElementById('verApp');
    if (!elApp) return;
    const r = await apiGet('/api/version');
    if (!r.ok) return;
    elApp.textContent = 'v' + (r.app_version || '—');
    const schTxt = 'схема БД ' + r.schema_version
        + (r.schema_version === r.schema_latest ? '' : ' → ' + r.schema_latest);
    const lastTxt = r.last_update ? ' · оновлено ' + r.last_update : '';
    const meta = document.getElementById('verMeta');
    if (meta) meta.textContent = schTxt + lastTxt;
    const box = document.getElementById('historyBox');
    const list = document.getElementById('historyList');
    if (r.history && r.history.length) {
        box.hidden = false;
        list.innerHTML = r.history.map((h) =>
            '<div class="backup-item"><span>' +
            (h.kind === 'schema' ? '🗄 Структура БД' : '⬆ Додаток') +
            ': ' + escapeHtml(h.from) + ' → ' + escapeHtml(h.to) +
            '</span><span class="text-mute"> · ' + escapeHtml(h.date) + '</span></div>'
        ).join('');
    } else {
        box.hidden = true;
    }
    // банер «підготовлено оновлення»
    const banner = document.getElementById('stagedBanner');
    if (banner) {
        if (r.staged && r.staged.app_version) {
            banner.hidden = false;
            banner.innerHTML = '✅ Оновлення до версії <strong>' + escapeHtml(r.staged.app_version) +
                '</strong> підготовлено. <strong>Перезапустіть сервер</strong>, щоб застосувати. ' +
                '<a href="#" id="cancelStagedLink">скасувати</a>';
            const cancel = document.getElementById('cancelStagedLink');
            cancel.addEventListener('click', async (e) => {
                e.preventDefault();
                await apiSend('/api/update/cancel', 'POST');
                toast('Підготовлене оновлення скасовано', 'success');
                loadVersion();
                if (window.refreshUpdateBadge) window.refreshUpdateBadge();
            });
        } else {
            banner.hidden = true;
        }
    }
}
loadVersion();

/* ---------- джерело та перевірка/застосування оновлень ---------- */

const updateSourceInput = document.getElementById('updateSourceInput');
const pickUpdateSrcBtn = document.getElementById('pickUpdateSrcBtn');
const checkUpdateBtn = document.getElementById('checkUpdateBtn');
const applyUpdateBtn = document.getElementById('applyUpdateBtn');
const updateStatus = document.getElementById('updateStatus');

async function loadUpdateSource() {
    if (!updateSourceInput) return;
    const r = await apiGet('/api/update/source');
    if (r.ok) updateSourceInput.value = r.local || '';
}

if (updateSourceInput) {
    loadUpdateSource();
    // зберігаємо джерело автоматично при втраті фокуса полем
    updateSourceInput.addEventListener('change', () => {
        apiSend('/api/update/source', 'POST', { source: updateSourceInput.value.trim() });
    });

    pickUpdateSrcBtn.addEventListener('click', async () => {
        pickUpdateSrcBtn.disabled = true;
        let r; try { r = await apiSend('/api/update/pick-source-folder', 'POST', {}); }
        catch (e) { r = { ok: false, error: 'Помилка зʼєднання' }; }
        pickUpdateSrcBtn.disabled = false;
        if (!r.ok) { toast(r.error || 'Не вдалося відкрити діалог', 'error'); return; }
        if (r.cancelled || !r.path) return;
        updateSourceInput.value = r.path;
        await apiSend('/api/update/source', 'POST', { source: r.path });
        toast('Джерело збережено', 'success');
    });

    checkUpdateBtn.addEventListener('click', async () => {
        // спершу зберігаємо те, що в полі
        await apiSend('/api/update/source', 'POST', { source: updateSourceInput.value.trim() });
        checkUpdateBtn.disabled = true;
        updateStatus.textContent = 'Перевіряю джерело…';
        applyUpdateBtn.hidden = true;
        const r = await apiSend('/api/update/check', 'POST', {});
        checkUpdateBtn.disabled = false;
        if (!r.ok) { updateStatus.textContent = '⚠ ' + (r.error || 'Помилка перевірки'); return; }
        if (r.available) {
            updateStatus.innerHTML = '🔔 Доступна версія <strong>' + escapeHtml(r.latest) +
                '</strong> (зараз ' + escapeHtml(r.current) + ').' +
                (r.notes ? ' ' + escapeHtml(r.notes) : '');
            applyUpdateBtn.hidden = false;
        } else {
            updateStatus.textContent = '✓ Встановлено найновішу версію (' + escapeHtml(r.current) + ').';
        }
    });

    applyUpdateBtn.addEventListener('click', async () => {
        if (!await confirmAction('Підготувати оновлення? Воно застосується при наступному перезапуску сервера (з копією коду й бази).')) return;
        applyUpdateBtn.disabled = true;
        updateStatus.textContent = 'Готую оновлення…';
        const r = await apiSend('/api/update/apply', 'POST', {});
        applyUpdateBtn.disabled = false;
        if (!r.ok) { updateStatus.textContent = '⚠ ' + (r.error || 'Помилка'); toast(r.error || 'Помилка', 'error'); return; }
        updateStatus.textContent = '';
        applyUpdateBtn.hidden = true;
        toast('Оновлення підготовлено — перезапустіть сервер', 'success');
        loadVersion();
        if (window.refreshUpdateBadge) window.refreshUpdateBadge();   // одразу прибрати показчик у меню
    });

    // оновлення вручну з файлу (напр. отриманого поштою)
    const updateFileInput = document.getElementById('updateFileInput');
    const uploadUpdateBtn = document.getElementById('uploadUpdateBtn');
    if (uploadUpdateBtn) {
        uploadUpdateBtn.addEventListener('click', async () => {
            const file = updateFileInput.files[0];
            if (!file) { toast('Виберіть файл farm_update_*.zip', 'warn'); return; }
            if (!await confirmAction('Підготувати оновлення з цього файлу? Воно застосується при перезапуску (з копією коду й бази).')) return;
            uploadUpdateBtn.disabled = true;
            updateStatus.textContent = 'Завантажую файл…';
            const fd = new FormData();
            fd.append('file', file);
            let r;
            try {
                const resp = await fetch('/api/update/upload', { method: 'POST', body: fd });
                r = await resp.json();
            } catch (e) { r = { ok: false, error: 'Помилка зʼєднання' }; }
            uploadUpdateBtn.disabled = false;
            if (!r.ok) { updateStatus.textContent = '⚠ ' + (r.error || 'Помилка'); toast(r.error || 'Помилка', 'error'); return; }
            updateFileInput.value = '';
            if (r.source) updateSourceInput.value = r.source;   // папку оновлень підставлено
            toast('Файл додано до папки оновлень', 'success');
            // далі — звичайний потік: перевірка покаже кнопку «Оновити»
            checkUpdateBtn.click();
            if (window.refreshUpdateBadge) window.refreshUpdateBadge();
        });
    }
}

/* ---------- папка для резервних копій ---------- */

const backupDirInput  = document.getElementById('backupDirInput');
const saveBackupDirBtn = document.getElementById('saveBackupDirBtn');
const resetBackupDirBtn = document.getElementById('resetBackupDirBtn');
const pickBackupDirBtn = document.getElementById('pickBackupDirBtn');
const backupDirHint   = document.getElementById('backupDirHint');

async function loadBackupDir() {
    if (!backupDirInput) return;
    const r = await apiGet('/api/database/backup-dir');
    if (!r.ok) return;
    backupDirInput.value = r.saved || '';
    backupDirInput.placeholder = r.default || '';
    if (r.locked) {
        backupDirInput.disabled = true;
        saveBackupDirBtn.disabled = true;
        resetBackupDirBtn.disabled = true;
        backupDirHint.textContent = 'Шлях задано змінною середовища VET_BACKUP_DIR — змінити тут не можна. Поточна: ' + r.path;
    } else {
        backupDirHint.textContent = 'Зараз копії зберігаються в: ' + r.path
            + (r.saved ? '' : '  (типова папка)');
    }
}

async function saveBackupDir(path) {
    saveBackupDirBtn.disabled = true;
    const r = await apiSend('/api/database/backup-dir', 'POST', { path });
    saveBackupDirBtn.disabled = false;
    if (!r.ok) { toast(r.error || 'Не вдалося зберегти шлях', 'error'); return; }
    toast('Папку для копій збережено', 'success');
    loadBackupDir();
    loadBackups();
}

if (saveBackupDirBtn) {
    saveBackupDirBtn.addEventListener('click', () => saveBackupDir(backupDirInput.value.trim()));
    resetBackupDirBtn.addEventListener('click', async () => {
        if (!await confirmAction('Повернути типову папку для копій?')) return;
        saveBackupDir('');
    });
    if (pickBackupDirBtn) {
        pickBackupDirBtn.addEventListener('click', async () => {
            pickBackupDirBtn.disabled = true;
            const old = pickBackupDirBtn.textContent;
            pickBackupDirBtn.textContent = 'Відкрито діалог…';
            let r;
            try { r = await apiSend('/api/database/pick-folder', 'POST', {}); }
            catch (e) { r = { ok: false, error: 'Помилка зʼєднання' }; }
            pickBackupDirBtn.disabled = false;
            pickBackupDirBtn.textContent = old;
            if (!r.ok) { toast(r.error || 'Не вдалося відкрити діалог', 'error'); return; }
            if (r.cancelled || !r.path) return;          // користувач закрив діалог
            backupDirInput.value = r.path;
            saveBackupDir(r.path);                         // одразу фіксуємо вибране
        });
    }
    loadBackupDir();
}

/* ---------- аналітика (Power BI) ---------- */

const analyticsEnabled = document.getElementById('analyticsEnabled');
const analyticsDirInput = document.getElementById('analyticsDirInput');
const pickAnalyticsBtn = document.getElementById('pickAnalyticsBtn');
const saveAnalyticsBtn = document.getElementById('saveAnalyticsBtn');
const exportNowBtn = document.getElementById('exportNowBtn');
const analyticsStatus = document.getElementById('analyticsStatus');
const analyticsFilesBox = document.getElementById('analyticsFilesBox');
const analyticsFiles = document.getElementById('analyticsFiles');

async function loadAnalytics() {
    if (!analyticsDirInput) return;
    const r = await apiGet('/api/analytics/info');
    if (!r.ok) return;
    analyticsDirInput.value = r.dir || '';
    analyticsEnabled.checked = !!r.enabled;
    if (r.locked) {
        analyticsDirInput.disabled = true; saveAnalyticsBtn.disabled = true; pickAnalyticsBtn.disabled = true;
    }
    const last = r.last_export ? 'Останній експорт: ' + r.last_export : 'Експорту ще не було';
    analyticsStatus.textContent = last + (r.enabled ? ' · авто кожні ' + r.interval_min + ' хв' : '');
    if (r.files && r.files.length) {
        analyticsFilesBox.hidden = false;
        analyticsFiles.innerHTML = r.files.map((f) =>
            '<div class="backup-item"><span>' + escapeHtml(f.name) +
            '</span><span class="text-mute"> · ' + fmtSize(f.size) + '</span></div>').join('');
    } else {
        analyticsFilesBox.hidden = true;
    }
}

async function saveAnalyticsDir(path) {
    const r = await apiSend('/api/analytics/dir', 'POST', { path });
    if (!r.ok) { toast(r.error || 'Не вдалося зберегти', 'error'); return; }
    toast('Папку аналітики збережено', 'success');
    loadAnalytics();
}

if (analyticsDirInput) {
    loadAnalytics();

    analyticsEnabled.addEventListener('change', async () => {
        const r = await apiSend('/api/analytics/toggle', 'POST', { enabled: analyticsEnabled.checked });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast(analyticsEnabled.checked ? 'Авто-експорт увімкнено' : 'Авто-експорт вимкнено', 'success');
        loadAnalytics();
    });

    saveAnalyticsBtn.addEventListener('click', () => saveAnalyticsDir(analyticsDirInput.value.trim()));

    pickAnalyticsBtn.addEventListener('click', async () => {
        pickAnalyticsBtn.disabled = true;
        let r; try { r = await apiSend('/api/analytics/pick-dir', 'POST', {}); }
        catch (e) { r = { ok: false, error: 'Помилка зʼєднання' }; }
        pickAnalyticsBtn.disabled = false;
        if (!r.ok) { toast(r.error || 'Не вдалося відкрити діалог', 'error'); return; }
        if (r.cancelled || !r.path) return;
        analyticsDirInput.value = r.path;
        saveAnalyticsDir(r.path);
    });

    exportNowBtn.addEventListener('click', async () => {
        exportNowBtn.disabled = true;
        analyticsStatus.textContent = 'Експортую…';
        const r = await apiSend('/api/analytics/export-now', 'POST', {});
        exportNowBtn.disabled = false;
        if (!r.ok) { analyticsStatus.textContent = '⚠ ' + (r.error || 'Помилка'); toast(r.error || 'Помилка', 'error'); return; }
        toast('Аналітику експортовано', 'success');
        loadAnalytics();
    });
}

/* ---------- імпорт файлу ---------- */

importBtn.addEventListener('click', async () => {
    const file = importFile.files[0];
    if (!file) { toast('Виберіть файл CSV', 'warn'); return; }

    importBtn.disabled = true;
    importResult.hidden = true;

    const fd = new FormData();
    fd.append('file', file);

    let r;
    try {
        const resp = await fetch('/api/import', { method: 'POST', body: fd });
        r = await resp.json();
    } catch (e) {
        r = { ok: false, error: 'Помилка зʼєднання із сервером' };
    }
    importBtn.disabled = false;

    if (!r.ok) {
        importResult.className = 'import-result err';
        importResult.textContent = r.error || 'Не вдалося імпортувати файл';
        importResult.hidden = false;
        toast(r.error || 'Помилка імпорту', 'error');
        return;
    }

    const summary = 'Товарів додано: ' + (r.products || 0) +
        '  ·  Партій залишків додано: ' + (r.batches || 0);

    let html = escapeHtml(summary);
    if (r.errors && r.errors.length) {
        html += '<div class="import-errors"><strong>Помилкові рядки (' +
            r.errors.length + '):</strong><ul>' +
            r.errors.map((e) => '<li>' + escapeHtml(e) + '</li>').join('') +
            '</ul></div>';
    }
    importResult.className = 'import-result ok';
    importResult.innerHTML = html;
    importResult.hidden = false;
    toast('Імпорт завершено', 'success');
    importFile.value = '';
});

/* ---------- очищення бази ---------- */

clearDbBtn.addEventListener('click', async () => {
    if (!await confirmAction('Ви впевнені що хочете очистити базу?')) return;
    clearDbBtn.disabled = true;
    const r = await apiSend('/api/database/clear', 'POST');
    clearDbBtn.disabled = false;
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Базу даних очищено', 'success');
    importResult.hidden = true;
});

/* ---------- згортання/розгортання панелей сторінки ---------- */
(function setupCollapsiblePanels() {
    document.querySelectorAll('.db-compact > .panel').forEach((panel, i) => {
        const head = panel.querySelector('.panel-head');
        if (!head || head.dataset.collapsible) return;
        head.dataset.collapsible = '1';
        head.classList.add('collapsible-head');
        const ch = document.createElement('span');
        ch.className = 'collapse-chevron';
        ch.textContent = '▾';
        head.appendChild(ch);
        const title = (head.textContent || '').trim().slice(0, 24) || ('p' + i);
        const key = 'dbpanel:' + title;
        if (localStorage.getItem(key) === '1') panel.classList.add('is-collapsed');
        head.addEventListener('click', () => {
            panel.classList.toggle('is-collapsed');
            localStorage.setItem(key, panel.classList.contains('is-collapsed') ? '1' : '0');
        });
    });
})();
