/* ============ Ліцензія: стан і активація ============ */

/* Згортання/розгортання панелей «Моя компанія» та «Активувати / продовжити» */
(function setupLicenseCollapse() {
    document.querySelectorAll('.ver-collapsible').forEach((panel, i) => {
        const head = panel.querySelector('.panel-head');
        if (!head || head.dataset.collapsible) return;
        head.dataset.collapsible = '1';
        head.classList.add('collapsible-head');
        const ch = document.createElement('span');
        ch.className = 'collapse-chevron';
        ch.textContent = '▾';
        head.appendChild(ch);
        const title = (head.textContent || '').trim().slice(0, 24) || ('lic' + i);
        const key = 'licpanel:' + title;
        if (localStorage.getItem(key) === '1') panel.classList.add('is-collapsed');
        head.addEventListener('click', () => {
            panel.classList.toggle('is-collapsed');
            localStorage.setItem(key, panel.classList.contains('is-collapsed') ? '1' : '0');
        });
    });
})();

const LIC_STATE = {
    active: 'Активна', grace: 'Пільговий період', expired: 'Прострочена',
    trial: 'Ознайомлення', none: 'Немає ліцензії', invalid: 'Недійсна',
    mismatch: 'Інша компанія', wrong_device: 'Інший ПК',
};

async function loadLic() {
    const r = await apiGet('/api/license');
    if (!r.ok) return;
    const COLOR = { active: '#1e9e5a', grace: '#b8860b', trial: '#2f5fb0' };
    const el = document.getElementById('licState');
    el.textContent = LIC_STATE[r.state] || r.state;
    el.style.color = COLOR[r.state] || (r.read_only ? 'var(--danger)' : 'var(--text)');

    const meta = document.getElementById('licMeta');
    let txt = '', days = null, color = '';
    if (r.state === 'active') { txt = 'діє до ' + r.expires; days = r.days_left; color = '#1e9e5a'; }
    else if (r.state === 'grace') { txt = 'прострочена ' + r.expires + ' · пільга'; days = r.grace_left; color = '#b8860b'; }
    else if (r.state === 'trial') { txt = 'ознайомлення'; days = r.trial_left; color = '#2f5fb0'; }
    else if (r.state === 'expired') txt = 'прострочена ' + r.expires;
    else if (r.state === 'mismatch') txt = 'ключ для «' + (r.company || '') + '»';
    else if (r.state === 'wrong_device') txt = 'ключ для іншого ПК';
    meta.innerHTML = escapeHtml(txt)
        + (days != null ? ' · <b style="color:' + color + '">залишилось ' + days + ' дн.</b>' : '');
    const BRANCH_LABELS = {
        pharmacy: 'Аптека', materials: 'Матеріали', herd: 'Управління стада',
        standard: 'Стандарт виробництва', plan: 'План-прогноз',
    };
    let brTxt = '';
    if (Array.isArray(r.branches) && r.branches.length) {
        brTxt = ' · Гілки: ' + r.branches.map(b => BRANCH_LABELS[b] || b).join(', ');
    } else if (r.company) {
        brTxt = ' · Гілки: усі';
    }
    document.getElementById('licCompany').textContent =
        r.company ? ('Ліцензовано: ' + r.company + brTxt)
                  : 'Ліцензію не активовано — режим лише для читання після ознайомлення.';
    if (r.state === 'wrong_device') {
        document.getElementById('licCompany').textContent =
            'Цей ключ виданий для іншого ПК — на цьому компʼютері він не діє. '
            + 'Надішліть власнику код активації цього ПК (нижче) для нового ключа.';
    }
    const cn = document.getElementById('companyName');
    const name = r.company || r.company_name || '';
    if (name) { cn.textContent = name; cn.classList.remove('empty'); }
    else { cn.textContent = 'Зʼявиться після активації ліцензії'; cn.classList.add('empty'); }

    // Код активації цього ПК
    const code = r.activation_code || '';
    const ac = document.getElementById('actCode');
    if (ac) ac.textContent = code || '—';
}
loadLic();

/* ----- Код активації: копіювати в буфер + показати QR (для зчитування телефоном) ----- */
async function copyActCode() {
    const code = (document.getElementById('actCode').textContent || '').trim();
    if (!code || code === '—') { toast('Код активації ще не готовий', 'warn'); return; }
    try { await navigator.clipboard.writeText(code); toast('Код скопійовано', 'success'); }
    catch (e) {
        // запасний варіант, якщо clipboard недоступний (несекюрний контекст)
        try {
            const ta = document.createElement('textarea');
            ta.value = code; ta.style.position = 'fixed'; ta.style.opacity = '0';
            document.body.appendChild(ta); ta.select();
            document.execCommand('copy'); ta.remove();
            toast('Код скопійовано', 'success');
        } catch (e2) { toast('Не вдалося скопіювати', 'error'); }
    }
}
const actCopyBtn = document.getElementById('actCopyBtn');
if (actCopyBtn) actCopyBtn.addEventListener('click', copyActCode);
const actCodeEl = document.getElementById('actCode');
if (actCodeEl) actCodeEl.addEventListener('click', copyActCode);
const actQrBtn = document.getElementById('actQrBtn');
if (actQrBtn) actQrBtn.addEventListener('click', () => {
    const code = (document.getElementById('actCode').textContent || '').trim();
    if (!code || code === '—') { toast('Код активації ще не готовий', 'warn'); return; }
    const img = document.getElementById('actQrImg');
    if (img && !img.src) img.src = '/license-code-qr.png';
    const m = document.getElementById('actQrModal'); if (m) m.hidden = false;
});
function closeActQr() { const m = document.getElementById('actQrModal'); if (m) m.hidden = true; }
document.addEventListener('click', (e) => { if (e.target.closest('[data-actqr-close]')) closeActQr(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeActQr(); });

/* ----- Реквізити для документів ----- */
const saveBizBtn = document.getElementById('saveBizBtn');
if (saveBizBtn) {
    saveBizBtn.addEventListener('click', async () => {
        const body = {
            name:    document.getElementById('bizName').value.trim(),
            entity:  document.getElementById('bizEntity').value.trim(),
            edrpou:  document.getElementById('bizEdrpou').value.trim(),
            phone:   document.getElementById('bizPhone').value.trim(),
            address: document.getElementById('bizAddress').value.trim(),
        };
        const msg = document.getElementById('bizStatusMsg');
        const r = await apiSend('/api/settings/business', 'POST', body);
        if (!r.ok) { msg.textContent = '⚠ ' + (r.error || 'Помилка'); toast(r.error || 'Помилка', 'error'); return; }
        msg.textContent = '✓ Збережено';
        toast('Реквізити збережено', 'success');
    });
}

const licKeyInput = document.getElementById('licKeyInput');
const licMsg = document.getElementById('licStatusMsg');

async function afterActivate(r) {
    if (!r.ok) { licMsg.textContent = '⚠ ' + (r.error || 'Помилка'); toast(r.error || 'Помилка', 'error'); return; }
    toast('Ліцензію активовано', 'success');
    loadLic();
    setTimeout(() => location.reload(), 700);   // оновити банер і режим у всій програмі
}

document.getElementById('activateLicBtn').addEventListener('click', async () => {
    const key = licKeyInput.value.trim();
    if (!key) { toast('Вставте ліцензійний ключ', 'warn'); return; }
    afterActivate(await apiSend('/api/license', 'POST', { key }));
    licKeyInput.value = '';
});

const licFileInput = document.getElementById('licFileInput');
const pickLicFileBtn = document.getElementById('pickLicFileBtn');
const licFileName = document.getElementById('licFileName');
const uploadLicBtn = document.getElementById('uploadLicBtn');

pickLicFileBtn.addEventListener('click', () => licFileInput.click());
licFileInput.addEventListener('change', () => {
    const f = licFileInput.files[0];
    if (f) {
        licFileName.textContent = f.name;
        licFileName.classList.add('has-file');
        uploadLicBtn.disabled = false;
    } else {
        licFileName.textContent = 'Файл не вибрано';
        licFileName.classList.remove('has-file');
        uploadLicBtn.disabled = true;
    }
});

uploadLicBtn.addEventListener('click', async () => {
    const f = licFileInput.files[0];
    if (!f) { toast('Виберіть файл license.lic', 'warn'); return; }
    const fd = new FormData();
    fd.append('file', f);
    let r;
    try { const resp = await fetch('/api/license/upload', { method: 'POST', body: fd }); r = await resp.json(); }
    catch (e) { r = { ok: false, error: 'Помилка зʼєднання' }; }
    afterActivate(r);
});
