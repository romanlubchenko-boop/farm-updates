/* Події: плитки категорій → подія → модал внесення (одинична/групова). */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let EVENTS = [], EVENTS_ALL = [], ANIMALS = [], GROUPS = [], CATS = {}, CHOICES = {}, FREQ = [];
// Вбудовані клички (за літерами) — використовуються, якщо в Налаштуваннях порожньо
const BUILTIN_CALF_NAMES = {
    F: ['Астра', 'Аза', 'Ася', 'Береза', 'Білка', 'Буря', 'Вишня', 'Веселка', 'Воля',
        'Галка', 'Гроза', 'Гілка', 'Доля', 'Діва', 'Долина', 'Ева', 'Європа', 'Жоржина',
        'Жар', 'Зірка', 'Зоря', 'Зима', 'Іва', 'Іскра', 'Калина', 'Квітка', 'Корона',
        'Лада', 'Ластівка', 'Лілія', 'Мрія', 'Марта', 'Малина', 'Ніжна', 'Нива', 'Ночка',
        'Оса', 'Осінь', 'Оксамитка', 'Пава', 'Пісня', 'Перлина', 'Роза', 'Рута', 'Ромашка',
        'Соня', 'Сніжка', 'Слава', 'Стріла', 'Тайга', 'Тінь', 'Умка', 'Фея', 'Фіалка',
        'Хвиля', 'Царівна', 'Чайка', 'Черешня', 'Шпилька', 'Щедра', 'Юла', 'Юнона',
        'Ягідка', 'Яблунька', 'Ясна'],
    M: ['Атлас', 'Азарт', 'Байкал', 'Буян', 'Богдан', 'Вихор', 'Вітер', 'Грім', 'Грізний',
        'Гай', 'Дунай', 'Дозор', 'Ефір', 'Жар', 'Зевс', 'Зорян', 'Ірбіс', 'Кедр', 'Космос',
        'Лідер', 'Лорд', 'Мороз', 'Магніт', 'Марс', 'Норд', 'Нептун', 'Орлан', 'Опал',
        'Партизан', 'Пірат', 'Рекс', 'Ратибор', 'Сокіл', 'Сармат', 'Смерч', 'Тайфун',
        'Титан', 'Ураган', 'Фрегат', 'Хан', 'Цезар', 'Чемпіон', 'Шторм', 'Юпітер', 'Ясон', 'Явір'],
};
let CALF_NAMES = { F: BUILTIN_CALF_NAMES.F.slice(), M: BUILTIN_CALF_NAMES.M.slice() };
let curEvent = null, curAttached = [];

async function load() {
    const [ev, an, cn] = await Promise.all([
        apiGet('/api/herd/events?active=1'),
        apiGet('/api/herd/animals'),
        apiGet('/api/herd/calf-names'),
    ]);
    // налаштовані списки мають пріоритет; інакше — вбудовані в код
    if (cn && cn.ok) {
        CALF_NAMES = {
            F: (cn.F && cn.F.length) ? cn.F : BUILTIN_CALF_NAMES.F.slice(),
            M: (cn.M && cn.M.length) ? cn.M : BUILTIN_CALF_NAMES.M.slice(),
        };
    }
    if (ev.ok) {
        EVENTS_ALL = (ev.events || []).filter((e) => e.is_active);
        // плитки: активні, з галочкою «на панель», і НЕ прив'язані до іншої події
        EVENTS = EVENTS_ALL.filter((e) =>
            (e.show_on_panel === undefined || e.show_on_panel) && !e.attach_to);
        CATS = ev.categories || {};
        FREQ = ev.frequent || [];
        (ev.params || []).forEach((p) => { CHOICES[p.key] = p.choices || []; });
    }
    if (an.ok) { ANIMALS = an.items || []; GROUPS = an.groups || []; }
    fillAnimals();
    fillGroups();
    renderTiles();
    initViewToggle();
    loadFeed();
}

/* ---------- плитки ---------- */
function effShort(e) {
    return (e.effects || []).map((x) => x.param_label).slice(0, 3).join(', ');
}
function renderTiles() {
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    let html = '';
    order.forEach((cat) => {
        const list = bySec[cat];
        if (!list || !list.length) return;
        html += `<div class="lg-cat c-${escapeHtml(cat)}">
            <button type="button" class="lg-cat-btn">
                <span>${escapeHtml(CATS[cat] || cat)}</span><span class="lg-caret">▾</span>
            </button>
            <div class="lg-drop"><div class="lg-tiles">${list.map((e) => `
                <button type="button" class="lg-tile" data-id="${e.id}">
                    <span class="t-name">${escapeHtml(e.name)}</span>
                    <span class="t-effs">${escapeHtml(effShort(e))}</span>
                </button>`).join('')}</div></div>
        </div>`;
    });
    $('lgTiles').innerHTML = html || '<p class="text-mute" style="padding:10px 16px;">Немає активних подій</p>';
    // закріплені ЧАСТІ (топ за 30 днів) — головні дії одним кліком, без дропдаунів
    const favBox = $('lgFav');
    if (favBox) {
        const favs = FREQ.map((id) => EVENTS.find((e) => e.id === id)).filter(Boolean);
        favBox.hidden = !favs.length;
        favBox.innerHTML = favs.length
            ? '<span class="lg-fav-lbl">Часті</span>' + favs.map((e) =>
                `<button type="button" class="lg-tile" data-id="${e.id}">
                    <span class="t-name">${escapeHtml(e.name)}</span></button>`).join('')
            : '';
        favBox.querySelectorAll('.lg-tile').forEach((b) => b.addEventListener('click', () => {
            const e2 = EVENTS.find((x) => String(x.id) === String(b.dataset.id));
            if (e2) openModal(e2);
        }));
    }
    // клік по категорії — розкрити/закрити список подій (інші закриваються)
    document.querySelectorAll('.lg-cat-btn').forEach((btn) => {
        btn.addEventListener('click', (ev) => {
            if ($('lgTiles').classList.contains('mode-flat')) return;  // у «Плитках» усе розкрито
            ev.stopPropagation();
            const cat = btn.closest('.lg-cat');
            const wasOpen = cat.classList.contains('is-open');
            document.querySelectorAll('.lg-cat.is-open').forEach((c) => c.classList.remove('is-open'));
            if (!wasOpen) cat.classList.add('is-open');
        });
    });
    // регульована ширина плиток категорій (тягнути правий край)
    if (window.makeFieldsResizable) makeFieldsResizable('lgTiles', 'vetpharm:lg_tiles', '.lg-cat');
}

// Перемикач вигляду: Список (дропдаун) / Плитки (усе розкрито)
function initViewToggle() {
    const wrap = $('lgTiles'), seg = $('lgViewToggle');
    if (!wrap || !seg) return;
    const apply = (mode) => {
        wrap.classList.toggle('mode-flat', mode === 'flat');
        wrap.classList.toggle('mode-drop', mode !== 'flat');
        seg.querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.view === mode));
        if (mode === 'flat') document.querySelectorAll('.lg-cat.is-open')
            .forEach((c) => c.classList.remove('is-open'));
        try { localStorage.setItem('lg_view_mode', mode); } catch (_) {}
    };
    seg.querySelectorAll('.seg-btn').forEach((b) =>
        b.addEventListener('click', () => apply(b.dataset.view)));
    let saved = 'drop';
    try { saved = localStorage.getItem('lg_view_mode') || 'drop'; } catch (_) {}
    apply(saved);
    document.addEventListener('click', (ev) => {
        if (!wrap.classList.contains('mode-flat') && !ev.target.closest('.lg-cat')) {
            document.querySelectorAll('.lg-cat.is-open').forEach((c) => c.classList.remove('is-open'));
        }
    });
}

/* ---------- довідники ---------- */
let acIdx = -1;   // активний рядок підказки
function fillAnimals() {
    const inp = $('lgAnimal'), box = $('lgAnimalSug');
    if (!inp || !box) return;
    const render = () => {
        const q = (inp.value || '').trim().toLowerCase();
        const list = ANIMALS.filter((a) => a.status !== 'archived').filter((a) => {
            if (!q) return true;
            return (a.tag || '').toLowerCase().includes(q)
                || (a.name || '').toLowerCase().includes(q);
        }).slice(0, 12);
        if (!list.length) { box.hidden = true; box.innerHTML = ''; acIdx = -1; return; }
        box.innerHTML = list.map((a) =>
            `<div class="lg-sug-item" data-tag="${escapeHtml(a.tag)}">
                <span class="s-tag">${escapeHtml(a.tag)}</span>` +
            (a.name ? `<span class="s-name">${escapeHtml(a.name)}</span>` : '') +
            (a.group_name ? `<span class="s-name">· ${escapeHtml(a.group_name)}</span>` : '') +
            `</div>`).join('');
        box.hidden = false;
        // перший варіант активний ОДРАЗУ — Enter бере його без стрілок
        acIdx = 0;
        box.querySelector('.lg-sug-item').classList.add('is-active');
        // точний збіг бирки — підставляємо сам, людина просто друкує номер
        if (q && list.length === 1 && (list[0].tag || '').toLowerCase() === q)
            choose(list[0].tag, false);            // без стрибка фокусу під час друку
    };
    const choose = (tag, advance = true) => {
        const a = ANIMALS.find((x) => x.tag === tag);
        inp.value = a ? (a.name ? `${a.tag} — ${a.name}` : a.tag) : tag;
        box.hidden = true; syncAnimalInfo();
        // явний вибір (Enter/Tab/клік) → наступне ПИТАННЯ по черзі (дата),
        // далі Enter веде по всіх полях до «Провести»
        if (advance) {
            const nxt = $('lgDate');
            if (nxt) { nxt.focus(); if (nxt.select) nxt.select(); }
        }
    };
    inp.addEventListener('input', render);
    inp.addEventListener('focus', render);
    inp.addEventListener('keydown', (e) => {
        const items = [...box.querySelectorAll('.lg-sug-item')];
        if (box.hidden || !items.length) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); acIdx = Math.min(acIdx + 1, items.length - 1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); acIdx = Math.max(acIdx - 1, 0); }
        else if (e.key === 'Enter' || (e.key === 'Tab' && !e.shiftKey)) {
            e.preventDefault(); e.stopPropagation();
            choose(items[Math.max(acIdx, 0)].dataset.tag); return; }
        else if (e.key === 'Escape') { box.hidden = true; return; }
        else return;
        items.forEach((it, i) => it.classList.toggle('is-active', i === acIdx));
        if (items[acIdx]) items[acIdx].scrollIntoView({ block: 'nearest' });
    });
    box.addEventListener('mousedown', (e) => {
        const it = e.target.closest('.lg-sug-item'); if (!it) return;
        e.preventDefault(); choose(it.dataset.tag);
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.lg-ac')) box.hidden = true;
    });
}
function fillGroups() {
    $('lgGroup').innerHTML = GROUPS.map((g, i) =>
        `<option value="${g.id}">${i + 1}. ${escapeHtml(g.name)}</option>`).join('');
}
function currentAnimal() {
    const v = ($('lgAnimal').value || '').trim();
    if (!v) return null;
    const tag = v.split(' — ')[0].trim();
    return ANIMALS.find((a) => a.tag === tag)
        || ANIMALS.find((a) => (a.name ? `${a.tag} — ${a.name}` : a.tag) === v) || null;
}
function groupAnimalIds() {
    const gid = String($('lgGroup').value || '');
    return ANIMALS.filter((a) => String(a.group_id) === gid && a.status === 'active').map((a) => a.id);
}
function syncAnimalInfo() {
    const a = currentAnimal();
    $('lgAnimalInfo').textContent = a
        ? `✔ ${a.name || a.tag}${a.group_name ? ' · ' + a.group_name : ''}`
        : (($('lgAnimal').value || '').trim() ? 'тварину не знайдено' : '');
}
function syncGroupInfo() {
    const n = groupAnimalIds().length;
    $('lgGroupInfo').textContent = `буде застосовано до ${n} тварин(и)`;
}
function isGroupMode() {
    const r = document.querySelector('input[name="lgMode"]:checked');
    return r && r.value === 'group';
}
function syncMode() {
    const grp = isGroupMode();
    $('lgSingleBox').hidden = grp;
    $('lgGroupBox').hidden = !grp;
    if (grp) syncGroupInfo();
    syncBirth();
}

/* ---------- динамічні поля ---------- */
function inputControl(eff, evId) {
    const ev = ` data-event-id="${evId}"`;
    const ch = CHOICES[eff.param_key] || [];
    if (ch.length) {
        // кодовий список — мітка вже містить код; текстовий — нумеруємо позиції,
        // тож набраний номер обирає пункт нативно (мітка починається з «N. »)
        const isCod = eff.param_dtype === 'cod' || eff.param_dtype === 'code';
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) => {
            const lbl = isCod ? c.label : `${i + 1}. ${c.label}`;
            return `<option value="${escapeHtml(c.value)}"${String(c.value) === String(eff.arg || '') ? ' selected' : ''}>${escapeHtml(lbl)}</option>`;
        }).join('');
        return `<select class="ref-select lg-in" data-key="${escapeHtml(eff.param_key)}" data-listtype="${isCod ? 'cod' : 'text'}"${ev}>${opts}</select>`;
    }
    const dt = eff.param_dtype;
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float') ? 'number' : 'text');
    const step = dt === 'float' ? ' step="0.01"' : '';
    return `<input type="${type}"${step} class="ref-select lg-in" data-key="${escapeHtml(eff.param_key)}"${ev} value="${escapeHtml(eff.arg || '')}" placeholder="значення">`;
}
function autoText(eff) {
    const ch = CHOICES[eff.param_key] || [];
    const lab = (v) => { const c = ch.find((x) => String(x.value) === String(v)); return c ? c.label : v; };
    if (eff.mode === 'const') return `${eff.param_label} = ${lab(eff.arg)}`;
    if (eff.mode === 'event_date') return `${eff.param_label} = дата події`;
    if (eff.mode === 'inc') return `${eff.param_label} += ${eff.arg}`;
    if (eff.mode === 'clear') return `${eff.param_label} — очистити`;
    if (eff.mode === 'when') {
        let d = {};
        try { if ((eff.arg || '').trim().startsWith('{')) d = JSON.parse(eff.arg); } catch (e) { /* ignore */ }
        const rules = Array.isArray(d.rules) ? d.rules : (d.if ? [d] : []);
        const dflt = d.default || (!d.if ? (d.val || '') : '');
        const parts = rules.filter((r) => r.if).map((r) => {
            const ic = CHOICES[r.if] || [];
            const il = (v) => { const c = ic.find((x) => String(x.value) === String(v)); return c ? c.label : v; };
            return `${r.if}=${il(r.eq)}→${lab(r.val)}`;
        });
        if (dflt) parts.push(`інакше→${lab(dflt)}`);
        return `${eff.param_label}: ${parts.join('; ')}`;
    }
    return '';
}
function renderInputs() {
    // питання батьківської події + усіх прив'язаних (Народження у вікні Отелу)
    const groups = [];
    if (curEvent) groups.push(curEvent);
    curAttached.forEach((a) => groups.push(a));
    let html = '';
    groups.forEach((ev) => {
        const isParent = curEvent && ev.id === curEvent.id;
        (ev.effects || []).forEach((eff) => {
            // поля вводу — лише для самої події; прив'язані (Народження)
            // збирають дані приплоду через блок «🐣 Приплід», а не тут
            if (eff.mode === 'input' && isParent) {
                html += `<label class="field"><span class="field-label">${escapeHtml(eff.param_label)}</span>${inputControl(eff, ev.id)}</label>`;
            }
        });
    });
    $('lgInputs').innerHTML = html;
    $('lgAuto').textContent = '';
}

/* ---------- приплід (Отел) ---------- */
// кличка теляти за літерою матері: перша вільна кличка потрібної статі
function genCalfName(sex) {
    const list = CALF_NAMES[(sex === 'M') ? 'M' : 'F'] || [];
    if (!list.length) return '';
    const dam = currentAnimal();
    let letter = '';
    for (const ch of ((dam && dam.name) || '')) { if (/[a-zа-яіїєґ]/i.test(ch)) { letter = ch.toUpperCase(); break; } }
    // зайняті: клички стада + уже проставлені в цьому приплоді
    const used = new Set();
    ANIMALS.forEach((a) => { if (a.name) used.add(a.name.trim()); });
    document.querySelectorAll('#lgCalves .cf-name').forEach((el) => {
        if ((el.value || '').trim()) used.add(el.value.trim());
    });
    const pick = (pool) => pool.find((n) => !used.has(n)) || '';
    const same = list.filter((n) => letter && n.slice(0, 1).toUpperCase() === letter);
    return pick(same) || pick(list);
}
function calfRow() {
    const div = document.createElement('div');
    div.className = 'lg-calf-row';
    div.innerHTML =
        `<select class="ref-select cf-alive" title="Живе чи мертвонароджене">
            <option value="1" selected>🐮 Живе</option><option value="0">✝ Мертвонар.</option></select>
         <input type="text" class="ref-select cf-uin" value="UA" placeholder="№ реєстр. (UA…) *">
         <input type="text" class="ref-select cf-tag" placeholder="№ ID (6 цифр)">
         <select class="ref-select cf-sex"><option value="" selected>— стать —</option><option value="F">1. Жіноча</option><option value="M">2. Чоловіча</option></select>
         <input type="text" class="ref-select cf-name" placeholder="кличка">
         <button type="button" class="lg-calf-del" title="Прибрати">✕</button>`;
    const uinEl = div.querySelector('.cf-uin'), tagEl = div.querySelector('.cf-tag');
    const sexEl = div.querySelector('.cf-sex'), nameEl = div.querySelector('.cf-name');
    // при виборі статі — підставити згенеровану кличку за літерою матері (у порожнє)
    sexEl.addEventListener('change', () => {
        if (!(nameEl.value || '').trim()) {
            const nm = genCalfName(sexEl.value);
            if (nm) nameEl.value = nm;
        }
    });
    // мертвонароджене → ховаємо номери й кличку, лишаємо тільки стать
    const aliveSel = div.querySelector('.cf-alive');
    const syncAlive = () => {
        const dead = aliveSel.value === '0';
        ['.cf-uin', '.cf-tag', '.cf-name'].forEach((s) => {
            div.querySelector(s).style.display = dead ? 'none' : '';
        });
    };
    aliveSel.addEventListener('change', syncAlive);
    syncAlive();
    // № реєстр. завжди починається з UA, далі лише цифри
    uinEl.addEventListener('input', (e) => {
        e.target.value = 'UA' + e.target.value.replace(/\D/g, '');
    });
    // Enter у № реєстр. → № ID = останні 6 цифр реєстраційного
    uinEl.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        const digits = uinEl.value.replace(/\D/g, '');
        if (digits) tagEl.value = digits.slice(-6);
    });
    div.querySelector('.lg-calf-del').addEventListener('click', () => div.remove());
    return div;
}
// подія, що реєструє приплід (батько або прив'язана, напр. Народження)
function birthEvent() {
    if (curEvent && curEvent.births) return curEvent;
    return curAttached.find((e) => e.births) || null;
}
function syncBirth() {
    const show = !!birthEvent() && !isGroupMode();
    $('lgBirth').hidden = !show;
    if (show && !$('lgCalves').children.length) $('lgCalves').appendChild(calfRow());
    if (!show) $('lgCalves').innerHTML = '';
}
function collectCalves() {
    const out = [];
    document.querySelectorAll('#lgCalves .lg-calf-row').forEach((r) => {
        const alive = r.querySelector('.cf-alive').value !== '0';
        const sex = r.querySelector('.cf-sex').value;
        if (!alive) {           // мертвонароджене — лише стать (для обліку)
            out.push({ alive: false, sex });
            return;
        }
        const tag = (r.querySelector('.cf-tag').value || '').trim();
        if (!tag) return;       // живе без номера — не рахуємо
        const uin = (r.querySelector('.cf-uin').value || '').replace(/\D/g, '');
        out.push({
            alive: true, tag, sex,
            name: (r.querySelector('.cf-name').value || '').trim(),
            uin: uin ? 'UA' + uin : '',
        });
    });
    return out;
}

/* ---------- модал ---------- */
function openModal(ev) {
    curEvent = ev;
    // прив'язані події (їх питання показуємо в цьому ж вікні), напр. Народження у Отелі
    curAttached = EVENTS_ALL.filter((e) => e.attach_to && e.attach_to === ev.key);
    $('lgmTitle').textContent = 'Подія: ' + ev.name;
    document.querySelector('input[name="lgMode"][value="single"]').checked = true;
    $('lgAnimal').value = ''; $('lgAnimalInfo').textContent = '';
    $('lgNote').value = '';
    $('lgCalves').innerHTML = '';
    $('lgDate').value = new Date().toISOString().slice(0, 10);
    renderInputs();
    syncMode();
    bindEnterNav();
    $('lgModal').hidden = false;
    initModalResize();
    // регульована ширина полів-ефектів у модалі (свій набір на кожну подію)
    const inp = $('lgInputs');
    if (inp) { inp.dataset.fieldsResizable = ''; }
    if (window.makeFieldsResizable) {
        makeFieldsResizable('lgInputs', 'vetpharm:lg_inp_' + (curEvent && curEvent.id || 0), '.field');
    }
    // фокус ПІСЛЯ повного показу вікна — інакше його зʼїдає рендер полів
    setTimeout(() => { const a = $('lgAnimal'); a.focus(); a.select(); }, 30);
}

// Регульована ширина модала «Провести подію» (тягнути правий край, з памʼяттю)
function initModalResize() {
    const card = document.querySelector('#lgModal .modal-card');
    if (!card || card.dataset.wResize === '1') return;
    card.dataset.wResize = '1';
    const KEY = 'vetpharm:lg_modalw';
    const saved = parseFloat(localStorage.getItem(KEY) || '0');
    if (saved > 0) card.style.width = saved + 'px';
    const grip = document.createElement('div');
    grip.className = 'lg-wgrip';
    grip.addEventListener('mousedown', (ev) => {
        ev.preventDefault();
        const sx = ev.clientX, sw = card.offsetWidth;
        const mv = (m) => { card.style.width = Math.max(440, Math.min(1200, sw + (m.clientX - sx))) + 'px'; };
        const up = () => {
            document.removeEventListener('mousemove', mv);
            document.removeEventListener('mouseup', up);
            localStorage.setItem(KEY, String(card.offsetWidth));
        };
        document.addEventListener('mousemove', mv);
        document.addEventListener('mouseup', up);
    });
    card.appendChild(grip);
}

// Enter → перехід на наступне поле; на останньому — провести
let lgEnterBound = false;
function bindEnterNav() {
    if (lgEnterBound) return; lgEnterBound = true;
    $('lgModal').addEventListener('keydown', (e) => {
        const smart = e.key === 'Enter' || (e.key === 'Tab' && !e.shiftKey);
        if (!smart || e.target.tagName === 'TEXTAREA') return;
        const seq = [...$('lgModal').querySelectorAll(
            '#lgAnimal, #lgGroup, #lgDate, #lgInputs .lg-in, ' +
            '#lgCalves input, #lgCalves select, #lgNote')]
            .filter((el) => el.offsetParent !== null && !el.disabled);
        const i = seq.indexOf(e.target);
        if (i === -1) return;
        e.preventDefault();
        // ЗАПОБІЖНИК: з поля тварини далі — лише з РОЗПІЗНАНОЮ твариною
        // (вибір першого варіанта робить обробник автокомпліту; якщо збігів
        // немає — стоїмо тут, а не тягнемо «12» у приплід)
        if (e.target.id === 'lgAnimal' && !currentAnimal()) {
            e.target.focus();
            return;
        }
        // переходимо тільки на НАСТУПНЕ ПОРОЖНЄ поле; заповнені пропускаємо.
        // № реєстр. з самим лише префіксом «UA» вважаємо порожнім.
        const isEmpty = (el) => {
            let v = (el.value || '').trim();
            if (el.classList.contains('cf-uin')) v = v.replace(/^UA$/i, '');
            return !v;
        };
        // необов'язкові поля (можна лишати порожніми): кличка, нотатка
        const optional = (el) => el.classList.contains('cf-name') || el.id === 'lgNote';
        // не переходити далі, поки поточне обов'язкове поле порожнє
        if (isEmpty(e.target) && !optional(e.target)) {
            e.target.focus();
            if (typeof e.target.select === 'function') e.target.select();
            return;
        }
        const nxt = seq[i + 1];
        if (nxt) {
            nxt.focus();
            if (typeof nxt.select === 'function') nxt.select();
        } else {
            submit();
        }
    });
}
function closeModal() { $('lgModal').hidden = true; }

// зібрати введені значення, згруповані за подією (data-event-id)
function inputsByEvent() {
    const map = {};
    document.querySelectorAll('#lgInputs .lg-in').forEach((el) => {
        const v = (el.value || '').trim();
        if (v === '') return;
        const eid = el.dataset.eventId || String(curEvent.id);
        (map[eid] = map[eid] || {})[el.dataset.key] = v;
    });
    return map;
}

async function submit() {
    if (!curEvent) return;
    const date = $('lgDate').value, note = $('lgNote').value.trim();

    if (isGroupMode()) {
        const ids = groupAnimalIds();
        if (!ids.length) { toast('У групі немає активних тварин', 'warn'); return; }
        if (!confirm(`Провести «${curEvent.name}» для ${ids.length} тварин(и)?`)) return;
        const byEv = inputsByEvent();
        const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: ids, event_id: curEvent.id, event_date: date,
            inputs: byEv[String(curEvent.id)] || {}, note,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast(`Проведено для ${r.applied} тварин(и)`, 'success');
        closeModal(); loadFeed(); return;
    }

    const a = currentAnimal();
    if (!a) { toast('Оберіть тварину', 'warn'); $('lgAnimal').focus(); return; }
    const byEv = inputsByEvent();
    const bEv = birthEvent();
    const calves = bEv ? collectCalves() : [];
    // стать теляти обов'язкова (за замовч. порожня — треба обрати)
    if (bEv && calves.some((c) => !c.sex)) {
        const row = [...document.querySelectorAll('#lgCalves .lg-calf-row')].find((r) => {
            const dead = r.querySelector('.cf-alive').value === '0';
            const hasTag = (r.querySelector('.cf-tag').value || '').trim();
            return (dead || hasTag) && !r.querySelector('.cf-sex').value;
        });
        toast('Оберіть стать теляти', 'warn');
        if (row) row.querySelector('.cf-sex').focus();
        return;
    }
    // одна подія в стрічці (Отел); приплід і правила прив'язаної події
    // (Народження) застосовуються в її межах на бекенді
    const base = {
        event_id: curEvent.id, event_date: date,
        inputs: byEv[String(curEvent.id)] || {}, note,
    };
    if (bEv) base.calves = calves;
    const r = await apiSend(`/api/herd/animals/${a.id}/apply-event`, 'POST', base);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    const changed = (r.changed || []).length;
    const born = (r.born || []).filter((b) => b.id).length;
    const still = r.stillborn || 0;
    toast(`Проведено: ${curEvent.name}${changed ? ' · оновлено ' + changed : ''}${born ? ' · приплід ' + born : ''}${still ? ' · мертвонар. ' + still : ''}`, 'success');
    closeModal();
    loadFeed();
}

/* ---------- стрічка ---------- */
async function loadFeed() {
    const q = ($('lgSearch').value || '').trim();
    const r = await apiGet('/api/herd/events-log?limit=100' + (q ? '&q=' + encodeURIComponent(q) : ''));
    const rows = r.ok ? (r.events || []) : [];
    $('lgCount').textContent = rows.length ? `· ${rows.length}` : '';
    $('lgBody').innerHTML = rows.length ? rows.map((e) => {
        const who = e.animal_name ? `${e.animal_tag} — ${e.animal_name}` : e.animal_tag;
        return `<tr data-id="${e.id}">
            <td>${escapeHtml((e.event_date || '').slice(0, 10))}</td>
            <td>${escapeHtml(who)}</td>
            <td><b>${escapeHtml(e.event_type || '')}</b></td>
            <td><span class="lg-badge">${escapeHtml(CATS[e.category] || e.category || '')}</span></td>
            <td class="text-mute">${escapeHtml(e.details || '')}</td>
            <td class="text-mute">${escapeHtml(e.user_name || '')}</td>
            <td class="lg-c">
                <button class="lg-edit-btn" data-edit="${e.id}" data-date="${escapeHtml((e.event_date || '').slice(0, 10))}"
                        data-note="${escapeHtml(e.details || '')}" title="Виправити">✎</button>
                <button class="lg-del-btn" data-del="${e.id}" title="Видалити">−</button></td>
        </tr>`;
    }).join('') : '<tr><td colspan="7" class="empty">Подій ще немає</td></tr>';
    // регульована ширина колонок «Останні події»
    if (window.makeColumnsResizable) makeColumnsResizable('lgTable', 'vetpharm:lg_evcols');
}
async function delEvent(id) {
    if (!confirm('Видалити запис події?')) return;
    const r = await apiSend('/api/herd/animals/events/' + id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    loadFeed();
}

/* ---------- події ---------- */
$('lgTiles').addEventListener('click', (e) => {
    const t = e.target.closest('.lg-tile'); if (!t) return;
    const ev = EVENTS.find((x) => String(x.id) === String(t.dataset.id));
    if (ev) openModal(ev);
});
document.querySelectorAll('input[name="lgMode"]').forEach((r) => r.addEventListener('change', syncMode));
$('lgAddCalf').addEventListener('click', () => $('lgCalves').appendChild(calfRow()));
$('lgAnimal').addEventListener('input', syncAnimalInfo);
$('lgGroup').addEventListener('change', syncGroupInfo);
$('lgSubmit').addEventListener('click', submit);
document.querySelectorAll('#lgModal [data-close]').forEach((el) => el.addEventListener('click', closeModal));
let searchT = null;
$('lgSearch').addEventListener('input', () => { clearTimeout(searchT); searchT = setTimeout(loadFeed, 250); });
$('lgBody').addEventListener('click', (e) => {
    const d = e.target.closest('[data-del]'); if (d) { delEvent(d.dataset.del); return; }
    const ed = e.target.closest('[data-edit]');
    if (ed) {
        $('leDate').value = ed.dataset.date || '';
        $('leNote').value = ed.dataset.note || '';
        $('lgEditModal').dataset.eventId = ed.dataset.edit;
        $('lgEditModal').hidden = false;
        $('leDate').focus();
    }
});
document.querySelectorAll('#lgEditModal [data-close-edit]').forEach((el) =>
    el.addEventListener('click', () => { $('lgEditModal').hidden = true; }));
$('leSave').addEventListener('click', async () => {
    const id = $('lgEditModal').dataset.eventId;
    if (!id) return;
    const r = await apiSend('/api/herd/animals/events/' + id, 'PATCH', {
        event_date: $('leDate').value, details: $('leNote').value,
    });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Виправлено' + (r.recalc ? ' · параметри перераховано' : ''), 'success');
    $('lgEditModal').hidden = true;
    loadFeed();
});
// Авто-розкриття будь-якого списку вікна при фокусі (де підтримується showPicker).
// Вибір за номером — нативний: мітки пронумеровані «1. …», тож набір цифри
// переходить на відповідну позицію; якщо такого номера немає — реакції немає.
$('lgModal').addEventListener('focusin', (e) => {
    const s = e.target.closest('select');
    if (s && typeof s.showPicker === 'function') {
        try { s.showPicker(); } catch (_) { /* потрібна взаємодія — ігноруємо */ }
    }
});

const LG_CODE_V = 'v156';   // видима версія коду сторінки (діагностика кешу)
if ($('lgTiles')) load().then(() => {
    // тихий напис версії в шапці — щоб було видно, який код реально працює
    const h = document.querySelector('.panel-head h2');
    if (h && !document.getElementById('lgCodeV')) {
        const b = document.createElement('span');
        b.id = 'lgCodeV';
        b.style.cssText = 'font-size:10px;color:var(--text-mute);font-weight:400;margin-left:8px';
        b.textContent = LG_CODE_V;
        h.appendChild(b);
    }
    // прийшли з картки тварини (/herd/log?animal=TAG) —預вибрати її
    const tag = new URLSearchParams(location.search).get('animal');
    if (tag) {
        const a = ANIMALS.find((x) => x.tag === tag);
        if (a) {
            $('lgAnimal').value = a.name ? `${a.tag} — ${a.name}` : a.tag;
            const single = document.querySelector('input[name="lgMode"][value="single"]');
            if (single) { single.checked = true; single.dispatchEvent(new Event('change')); }
            $('lgTiles').scrollIntoView({block: 'center'});
        }
    }
});
})();
