/* Перевикористовуваний сканер камерою.
   Виклик: openCameraScanner((code) => { ... }) — відкриває оверлей з камерою
   і викликає колбек на кожен зчитаний код (можна сканувати багато підряд).
   Рушій: вбудований BarcodeDetector (Android) → поліфіл (iPhone) → jsQR (QR). */
(function () {
    const FORMATS = ['qr_code', 'ean_13', 'ean_8', 'code_128', 'code_39',
                     'upc_a', 'upc_e', 'itf', 'codabar', 'data_matrix'];

    /* короткий звуковий сигнал (ok=false → нижчий тон «помилка») */
    let _ac = null;
    window.scanBeep = function (ok) {
        try {
            _ac = _ac || new (window.AudioContext || window.webkitAudioContext)();
            if (_ac.state === 'suspended') _ac.resume();
            const o = _ac.createOscillator(), g = _ac.createGain();
            o.type = 'square';
            o.frequency.value = (ok === false) ? 200 : 880;
            g.gain.value = 0.07;
            o.connect(g); g.connect(_ac.destination);
            const t = _ac.currentTime;
            o.start(t); o.stop(t + 0.10);
        } catch (e) { /* без звуку — не критично */ }
    };

    function loadScript(src) {
        return new Promise((res, rej) => {
            const s = document.createElement('script');
            s.src = src; s.onload = res; s.onerror = rej;
            document.head.appendChild(s);
        });
    }

    /* F2: перший раз — фокус на полі вводу; другий раз — відкрити камеру.
       Скидається при втраті фокуса або введенні, тож послідовність починається заново. */
    window.attachScanShortcut = function (inputEl, cameraBtn) {
        if (!inputEl) return;
        let armed = false;
        inputEl.addEventListener('blur', () => { armed = false; });
        inputEl.addEventListener('input', () => { armed = false; });
        document.addEventListener('keydown', (e) => {
            if (e.key !== 'F2') return;
            e.preventDefault();
            if (document.activeElement === inputEl && armed) {
                armed = false;
                if (cameraBtn) cameraBtn.click();
            } else {
                inputEl.focus();
                try { inputEl.select(); } catch (_) { /* ignore */ }
                armed = true;
            }
        });
    };

    window.openCameraScanner = function (onDetect, opts) {
        opts = opts || {};
        const ov = document.createElement('div');
        ov.className = 'camscan-overlay';
        ov.innerHTML =
            '<div class="camscan-top">' +
            '  <span class="camscan-title">Наведіть на QR / штрихкод</span>' +
            '  <button type="button" class="camscan-close">✕ Готово</button>' +
            '</div>' +
            '<div class="camscan-stage">' +
            '  <video class="camscan-video" playsinline muted></video>' +
            '  <div class="camscan-frame"><div class="camscan-laser"></div></div>' +
            '</div>' +
            '<div class="camscan-status"></div>';
        document.body.appendChild(ov);

        const video = ov.querySelector('.camscan-video');
        const statusEl = ov.querySelector('.camscan-status');
        const frameEl = ov.querySelector('.camscan-frame');
        let stream = null, scanning = false, detector = null;
        let useJsQR = false, canvas = null, cctx = null;
        let useZxing = false, zxReader = null;
        let lastCode = '', lastAt = 0;

        function setStatus(t) { statusEl.textContent = t || ''; }

        function close() {
            scanning = false;
            if (stream) { try { stream.getTracks().forEach((t) => t.stop()); } catch (e) {} }
            ov.remove();
        }
        ov.querySelector('.camscan-close').addEventListener('click', close);

        async function ensureDecoder() {
            // 1) Нативний BarcodeDetector (Android Chrome) — найшвидший.
            if ('BarcodeDetector' in window) {
                try { detector = new BarcodeDetector({ formats: FORMATS }); useJsQR = false; return true; }
                catch (e) {}
            }
            // 2) Вбудований ZXing — працює ОФЛАЙН (iPhone/Safari), без інтернету.
            if (window.ZXing && window.ZXing.BrowserMultiFormatReader) {
                try { zxReader = new window.ZXing.BrowserMultiFormatReader(); useZxing = true; return true; }
                catch (e) {}
            }
            // 3) Поліфіл BarcodeDetector з мережі (якщо є інтернет).
            try { await import('https://cdn.jsdelivr.net/npm/barcode-detector@2/dist/es/side-effects.min.js'); }
            catch (e) {}
            if ('BarcodeDetector' in window) {
                try { detector = new BarcodeDetector({ formats: FORMATS }); useJsQR = false; return true; }
                catch (e) {}
            }
            // 4) jsQR (лише QR) з мережі — останній резерв.
            if (typeof jsQR === 'undefined') {
                try { await loadScript('https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js'); }
                catch (e) { return false; }
            }
            if (typeof jsQR !== 'undefined') {
                useJsQR = true; canvas = document.createElement('canvas');
                cctx = canvas.getContext('2d', { willReadFrequently: true });
                return true;
            }
            return false;
        }

        function onScan(code) {
            const now = Date.now();
            if (code === lastCode && now - lastAt < 1500) return;
            lastCode = code; lastAt = now;
            if (navigator.vibrate) navigator.vibrate(60);
            frameEl.classList.add('flash');
            setTimeout(() => frameEl.classList.remove('flash'), 200);
            let p;
            try { p = onDetect(code); } catch (e) { /* ignore */ }   // звук — у колбеку
            if (opts.autoClose) {
                scanning = false;                                    // зупинити цикл
                Promise.resolve(p).catch(() => {}).then(() => setTimeout(close, 450));
            }
        }

        async function loop() {
            if (!scanning) return;
            try {
                if (useZxing) {
                    if (video.videoWidth) {
                        // покадрове декодування вбудованим ZXing (1D + QR), офлайн
                        var bb = zxReader.createBinaryBitmap(video);
                        var res = zxReader.decodeBitmap(bb);   // кине виняток, якщо не знайдено
                        if (res) onScan(res.getText());
                    }
                } else if (useJsQR) {
                    if (video.videoWidth) {
                        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
                        cctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                        const img = cctx.getImageData(0, 0, canvas.width, canvas.height);
                        const res = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
                        if (res && res.data) onScan(res.data);
                    }
                } else {
                    const codes = await detector.detect(video);
                    if (codes && codes.length) onScan(codes[0].rawValue);
                }
            } catch (e) {}
            if (scanning) setTimeout(loop, useZxing ? 220 : (useJsQR ? 200 : 280));
        }

        async function start() {
            setStatus('Готую сканер…');
            const ready = await ensureDecoder();
            if (!ready) { setStatus('Потрібен інтернет на телефоні (підвантажити сканер).'); return; }
            if (!window.isSecureContext || !navigator.mediaDevices ||
                    !navigator.mediaDevices.getUserMedia) {
                setStatus('Відкрийте сторінку за адресою https:// (не http) — інакше камеру блоковано.');
                return;
            }
            let s = null, err = null;
            const tries = [
                { video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } } },
                { video: { facingMode: { ideal: 'environment' } } },
                { video: true }
            ];
            for (const c of tries) {
                try { s = await navigator.mediaDevices.getUserMedia(c); break; } catch (e) { err = e; }
            }
            if (!s) {
                const n = (err && err.name) || '';
                setStatus(n === 'NotAllowedError'
                    ? 'Дозвольте камеру в налаштуваннях сайту.'
                    : 'Камеру не вдалося відкрити: ' + ((err && err.message) || n));
                return;
            }
            stream = s;
            try {
                const track = s.getVideoTracks()[0];
                if (track && track.applyConstraints)
                    await track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {});
            } catch (e) {}
            video.srcObject = stream;
            await video.play();
            setStatus('Скануйте товари один за одним. «Готово» — закрити.');
            scanning = true;
            loop();
        }

        start();
        return { close: close, setStatus: setStatus };
    };
})();
