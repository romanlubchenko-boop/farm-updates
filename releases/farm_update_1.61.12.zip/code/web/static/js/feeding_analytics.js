/* Аналітика годівлі по секціях: поголів'я (зі стада) × списання кормів (Profeed)
   → кг/гол/день, ₴/гол/день (без ПДВ), ₴ корму на 1 кг молока для дійних. */

const $ = (id) => document.getElementById(id);
const fmt = (n, d = 2) => (n == null ? '—'
    : Number(n).toLocaleString('uk-UA', { minimumFractionDigits: d, maximumFractionDigits: d }));
const kindLabel = (k) => (k === 'cow' ? 'Корови' : (k === 'young' ? 'Молодняк' : '—'));

async function loadAnalytics() {
    const from = $('faFrom').value || '';
    const to = $('faTo').value || '';
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    let r;
    try { r = await apiGet('/api/feed/analytics?' + qs.toString()); }
    catch (e) { r = { ok: false, error: 'Сервер не відповів (можливо, потрібен перезапуск)' }; }
    if (!r || !r.ok) {
        $('faBody').innerHTML = `<tr class="empty"><td colspan="10">${
            escapeHtml((r && r.error) || 'Помилка')}</td></tr>`;
        $('faCards').innerHTML = '';
        return;
    }
    renderCards(r);
    renderTable(r.sections || []);
}

function renderCards(r) {
    const cards = [];
    cards.push(card('Надій за період, кг', r.milk_kg == null ? '—' : fmt(r.milk_kg, 0)));
    cards.push(card('Корми дійних (без ПДВ), ₴', fmt(r.dairy_cost_no_vat, 2)));
    cards.push(card('₴ корму на 1 кг молока',
        r.uah_per_kg_milk == null ? '—' : fmt(r.uah_per_kg_milk, 2), true));
    $('faCards').innerHTML = cards.join('');
}

function card(cap, val, main) {
    return `<div class="fa-card ${main ? 'fa-main' : ''}">
        <div class="fa-cap">${cap}</div><div class="fa-val">${val}</div></div>`;
}

function renderTable(sections) {
    const body = $('faBody');
    if (!sections.length) {
        body.innerHTML = '<tr class="empty"><td colspan="10">За цей період годівлі немає</td></tr>';
        return;
    }
    let kg = 0, cost = 0, loss = 0;
    body.innerHTML = sections.map((s) => {
        kg += s.kg; cost += s.cost_no_vat; loss += (s.loss_kg || 0);
        const noHeads = !s.headcount;
        const lossCls = (s.loss_kg || 0) > 0 ? 'fa-loss-bad' : '';
        return `<tr>
            <td>${escapeHtml(s.block_name)}</td>
            <td class="${s.herd_kind === 'cow' ? 'fa-kind-cow' : ''}">${kindLabel(s.herd_kind)}</td>
            <td>${escapeHtml(s.subgroup || '—')}</td>
            <td class="num ${noHeads ? 'is-short' : ''}">${noHeads ? '—' : fmt(s.headcount, 0)}</td>
            <td class="num">${s.days}</td>
            <td class="num">${fmt(s.kg, 1)}</td>
            <td class="num">${fmt(s.kg_head_day, 2)}</td>
            <td class="num">${fmt(s.cost_no_vat, 2)}</td>
            <td class="num">${fmt(s.uah_head_day, 2)}</td>
            <td class="num ${lossCls}">${fmt(s.loss_kg, 1)}</td>
        </tr>`;
    }).join('') + `<tr><td colspan="5">Разом</td>
        <td class="num">${fmt(kg, 1)}</td><td class="num">—</td>
        <td class="num">${fmt(cost, 2)}</td><td class="num">—</td>
        <td class="num">${fmt(loss, 1)}</td></tr>`;
    makeColumnsResizable('faTable', 'farm:fa_cols_w');
}

/* Пресети періоду (як у надходженнях/виробництві) */
(() => {
    const presets = $('faPresets'), fromEl = $('faFrom'), toEl = $('faTo');
    const KEY = 'farm:fa_days';
    const iso = (d) => d.toISOString().slice(0, 10);
    const mark = (days) => presets.querySelectorAll('.btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));
    const apply = (days) => {
        toEl.value = iso(new Date());
        fromEl.value = days === 'all' ? '' : iso(new Date(Date.now() - (+days) * 864e5));
        mark(days);
    };
    presets.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-days]');
        if (!btn) return;
        apply(btn.dataset.days);
        try { localStorage.setItem(KEY, btn.dataset.days); } catch (err) { /* ignore */ }
        loadAnalytics();
    });
    [fromEl, toEl].forEach((el) => el.addEventListener('change', () => { mark(null); loadAnalytics(); }));
    apply(localStorage.getItem(KEY) || '30');   // дефолт — 30 днів
})();

/* Перемикач джерела поголів'я: авто з Profeed / вручну (секції) */
(() => {
    const sel = $('faSource');
    if (!sel) return;
    sel.addEventListener('change', async () => {
        await apiSend('/api/feed/headcount-source', 'POST', { source: sel.value });
        loadAnalytics();
    });
    apiGet('/api/feed/headcount-source').then((r) => {
        if (r && r.source) sel.value = r.source;
    });
})();

document.addEventListener('DOMContentLoaded', loadAnalytics);
