'use strict';
/* Управління стада — «Рух поголів'я»: типи руху (Запуск, Отел, Осіменіння,
   Вибуття…) × 12 місяців за рік. Секції стада редагуються в Налаштуваннях.
   Одне глобальне стадо (без прив'язки до гілки). */

const MONTHS = ['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер', 'Вер', 'Жов', 'Лис', 'Гру'];

let year = new Date().getFullYear();
const yearLabel = document.getElementById('herdYear');
const moveYearLabel = document.getElementById('moveYearLabel');

function toNum(v) {
    const n = parseFloat((v == null ? '' : String(v)).replace(',', '.'));
    return isFinite(n) && n > 0 ? n : 0;
}

function countsFromDict(dict, id) {
    const arr = [];
    for (let m = 1; m <= 12; m++) arr.push((dict || {})[id + '-' + m] || 0);
    return arr;
}

/* Помісячна сітка (типи руху × місяці) */
function makeGrid(cfg) {
    const headRow = document.getElementById(cfg.headId);
    const bodyEl = document.querySelector(cfg.bodySel);
    const totalsRow = document.getElementById(cfg.totalsId);
    let deleted = [];

    function buildHead() {
        headRow.innerHTML = `<th class="herd-group-col">${cfg.firstCol}</th>`
            + MONTHS.map((m) => `<th class="num">${m}</th>`).join('') + '<th></th>';
    }

    function addRow(row) {
        row = row || {};
        const counts = row.counts || [];
        const tr = document.createElement('tr');
        tr.dataset.id = row.id || '';
        tr.innerHTML =
            `<td class="herd-group-col"><input type="text" class="hd-name" value="${escapeHtml(row.name || '')}" placeholder="${cfg.placeholder}"></td>`
            + MONTHS.map((_, i) => {
                const v = toNum(counts[i]);
                return `<td class="num"><input type="text" inputmode="numeric" class="hd-month" value="${v > 0 ? v : ''}"></td>`;
            }).join('')
            + `<td class="num"><button type="button" class="btn btn-icon btn-icon-danger hd-del" title="Прибрати">🗑</button></td>`;
        bodyEl.appendChild(tr);
        return tr;
    }

    function showEmpty() {
        bodyEl.innerHTML = `<tr><td colspan="${MONTHS.length + 2}" class="empty">${cfg.emptyText}</td></tr>`;
        totalsRow.hidden = true;
    }

    function updateTotals() {
        const rows = [...bodyEl.querySelectorAll('tr')].filter((tr) => tr.querySelector('.hd-name'));
        if (!rows.length) { totalsRow.hidden = true; return; }
        const sums = new Array(12).fill(0);
        rows.forEach((tr) => {
            tr.querySelectorAll('.hd-month').forEach((inp, i) => { sums[i] += toNum(inp.value); });
        });
        totalsRow.hidden = false;
        totalsRow.innerHTML = '<td class="herd-group-col"><strong>Разом</strong></td>'
            + sums.map((s) => `<td class="num">${s ? fmtNum(s) : ''}</td>`).join('') + '<td></td>';
    }

    function gather() {
        const out = [];
        bodyEl.querySelectorAll('tr').forEach((tr) => {
            const nameInp = tr.querySelector('.hd-name');
            if (!nameInp) return;
            const name = (nameInp.value || '').trim();
            if (!name) return;
            const counts = [...tr.querySelectorAll('.hd-month')].map((i) => toNum(i.value));
            out.push({ id: tr.dataset.id ? Number(tr.dataset.id) : null, name, counts });
        });
        return out;
    }

    function renderRows(rows) {
        deleted = [];
        buildHead();
        bodyEl.innerHTML = '';
        rows.forEach(addRow);
        if (!rows.length) showEmpty(); else updateTotals();
    }

    async function save(silent) {
        const payload = { year: year, deleted: deleted };
        payload[cfg.payloadKey] = gather();
        const r = await apiSend(cfg.saveUrl, 'POST', payload);
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return false; }
        renderRows(cfg.rowsFrom(r));
        if (!silent) toast('Збережено', 'success');
        return true;
    }

    document.getElementById(cfg.addBtnId).addEventListener('click', () => {
        if (bodyEl.querySelector('td.empty')) bodyEl.innerHTML = '';
        const tr = addRow({});
        const inp = tr.querySelector('.hd-name');
        if (inp) inp.focus();
        updateTotals();
    });
    document.getElementById(cfg.saveBtnId).addEventListener('click', () => save(false));
    bodyEl.addEventListener('input', (e) => {
        if (e.target.classList.contains('hd-month')) updateTotals();
    });
    bodyEl.addEventListener('click', (e) => {
        const del = e.target.closest('.hd-del');
        if (!del) return;
        const tr = del.closest('tr');
        if (tr.dataset.id) deleted.push(Number(tr.dataset.id));
        tr.remove();
        if (!bodyEl.querySelector('tr')) showEmpty(); else updateTotals();
    });

    return {
        renderState: (s) => renderRows(cfg.rowsFrom(s)),
        save: save,
        hasRows: () => !!bodyEl.querySelector('.hd-name'),
    };
}

const moveGrid = makeGrid({
    headId: 'moveHead', bodySel: '#movesTable tbody', totalsId: 'moveTotals',
    addBtnId: 'addMoveTypeBtn', saveBtnId: 'saveMovesBtn',
    payloadKey: 'types', saveUrl: '/api/herd/moves/save',
    firstCol: 'Рух', placeholder: 'напр. Запуск, Отел',
    emptyText: 'Типів руху ще немає — натисніть «+ Тип»',
    rowsFrom: (s) => (s.move_types || []).map((t) => ({ id: t.id, name: t.name, counts: countsFromDict(s.move_counts, t.id) })),
});

async function loadYear(y) {
    const r = await apiGet('/api/herd?year=' + y);
    if (!r.ok) return;
    year = r.year;
    if (yearLabel) yearLabel.textContent = year;
    if (moveYearLabel) moveYearLabel.textContent = '— ' + year;
    moveGrid.renderState(r);
}

async function changeYear(delta) {
    if (moveGrid.hasRows() && !await moveGrid.save(true)) return;
    loadYear(year + delta);
}

const prevY = document.getElementById('herdPrevYear');
const nextY = document.getElementById('herdNextYear');
if (prevY) prevY.addEventListener('click', () => changeYear(-1));
if (nextY) nextY.addEventListener('click', () => changeYear(1));

document.addEventListener('DOMContentLoaded', () => loadYear(year));

/* ===== Поголів'я по днях (Excel 03_Herd_Structure) ===== */
(function herdDaily() {
    const tbl = document.getElementById('hdTable');
    if (!tbl) return;
    const headEl = document.getElementById('hdHead');
    const bodyEl = tbl.querySelector('tbody');
    const seg = document.getElementById('hdSeg');
    const nf = new Intl.NumberFormat('uk-UA');
    let period = 'month';

    function render(d) {
        const cols = d.cols || [], rows = d.rows || [];
        const span = cols.length + 2;
        headEl.innerHTML = '<th>Період</th><th>На дату</th>'
            + cols.map(c => `<th class="num">${c.label}</th>`).join('');
        if (d.error) {
            bodyEl.innerHTML = `<tr><td colspan="${span}" class="empty">${d.error}</td></tr>`;
            return;
        }
        if (!rows.length) {
            bodyEl.innerHTML = `<tr><td colspan="${span}" class="empty">Немає даних</td></tr>`;
            return;
        }
        bodyEl.innerHTML = rows.map(r => {
            const tds = cols.map(c => {
                const v = r.values[c.key];
                return `<td class="num">${v == null ? '—' : nf.format(v)}</td>`;
            }).join('');
            return `<tr><td>${r.period}</td><td class="text-mute">${r.day}</td>${tds}</tr>`;
        }).join('');
    }

    const todayEl = document.getElementById('hdToday');
    async function load() {
        const t = (todayEl && todayEl.checked) ? '&today=1' : '';
        const r = await apiGet('/api/herd/daily?period=' + period + t);
        if (r && r.ok !== false) render(r);
    }

    seg.addEventListener('click', e => {
        const a = e.target.closest('a[data-p]');
        if (!a) return;
        period = a.dataset.p;
        seg.querySelectorAll('a').forEach(x => x.classList.toggle('on', x === a));
        load();
    });
    if (todayEl) todayEl.addEventListener('change', load);
    load();
})();
