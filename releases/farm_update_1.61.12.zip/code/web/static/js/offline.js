/* ============ Офлайн-екран (Етапи 1–2) ============
   IndexedDB-знімок + перегляд (залишки/каталог/довідники) + ОФЛАЙН-ВИДАЧА
   з чергою операцій і синхронізацією на сервер. Не залежить від app.js. */
(function () {
    'use strict';

    var BRANCH = window.OFFLINE_BRANCH || 'pharmacy';
    var API = window.OFFLINE_API_BASE || '';
    // API-база гілки: '' = аптека, '/m' = матеріали. Потрібна, щоб перемикати
    // склад прямо на сторінці (без переходу) і синхронізувати кожну гілку окремо.
    function apiFor(branch) { return branch === 'materials' ? '/m' : ''; }
    var el = function (id) { return document.getElementById(id); };
    var esc = function (s) {
        // Екрануємо й лапки — значення часто вставляються в атрибути value="…",
        // data-…="…"; без цього назва/штрихкод із лапкою могли б зламати атрибут
        // і виконати чужий JS (XSS).
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    };
    var uuid = function () {
        return (self.crypto && crypto.randomUUID) ? crypto.randomUUID()
            : 'op-' + Date.now() + '-' + Math.random().toString(16).slice(2);
    };
    // Нормалізація числового вводу: кома й тире → крапка; лишаються лише цифри
    // й одна крапка. Так у полях к-сті/ціни/відсотка завжди десятковий формат 0.0.
    function normNum(s) {
        s = String(s == null ? '' : s).replace(/[,\-–—]/g, '.').replace(/[^0-9.]/g, '');
        var p = s.split('.');
        return p.length > 2 ? (p[0] + '.' + p.slice(1).join('')) : s;
    }
    // Нормалізувати поле «на льоту», зберігши позицію курсора в кінці
    function normField(elm) {
        var v = normNum(elm.value);
        if (v !== elm.value) { elm.value = v; try { elm.setSelectionRange(v.length, v.length); } catch (e) {} }
        return v;
    }
    // Крок кількості за одиницею: штучні — 1, вага/обʼєм — 0.1 (дробові)
    function unitStep(u) {
        u = (u || '').toLowerCase().trim();
        var ints = ['шт', 'уп', 'пак', 'доза', 'фл', 'амп', 'таб', 'капс', 'пач', 'компл', 'бл', 'набір'];
        if (ints.indexOf(u) !== -1) return 1;
        var frac = ['кг', 'г', 'гр', 'л', 'мл', 'м', 'см', 'кв.м', 'куб.м', 'літр', 'мілілітр'];
        if (frac.indexOf(u) !== -1) return 0.1;
        return 1; // невідомі — цілі
    }
    // Колесо-пікер кількості (барабан). Для дробових одиниць — два барабани:
    // ціла частина + десяті (.0–.9), крок 0.1. Для штучних — один барабан.
    var ROWH = 44, QMAX = 999;
    function openQtyPicker(unit, current, onPick) {
        var step = unitStep(unit), ov = el('qtyPicker'), wheels = el('qpWheels');
        el('qpTitle').textContent = 'Кількість' + (unit ? (' · ' + unit) : '');
        current = rnum(current);
        wheels.innerHTML = '';
        function buildWheel(max, sel) {
            var w = document.createElement('div'); w.className = 'qwheel';
            var rows = '<div class="qpad"></div>';
            for (var i = 0; i <= max; i++) rows += '<div class="qrow">' + i + '</div>';
            rows += '<div class="qpad"></div>';
            w.innerHTML = rows;
            wheels.appendChild(w);
            requestAnimationFrame(function () { w.scrollTop = Math.max(0, sel) * ROWH; });
            return w;
        }
        function selOf(w) { return Math.round(w.scrollTop / ROWH); }
        var wWhole, wDec;
        if (step === 1) {
            wWhole = buildWheel(QMAX, Math.round(current));
        } else {
            var whole = Math.floor(current), dec = Math.round((current - whole) * 10);
            if (dec > 9) { whole += 1; dec = 0; }
            wWhole = buildWheel(QMAX, whole);
            var dot = document.createElement('div'); dot.className = 'qdot'; dot.textContent = '.'; wheels.appendChild(dot);
            wDec = buildWheel(9, dec);
        }
        ov.style.display = 'flex';
        el('qpOk').onclick = function () {
            var val = (step === 1) ? selOf(wWhole) : (selOf(wWhole) + selOf(wDec) / 10);
            ov.style.display = 'none';
            onPick(String(Math.round(val * 10) / 10));
        };
        el('qpCancel').onclick = function () { ov.style.display = 'none'; };
    }

    var state = {
        snapshot: null, syncedAt: null, tab: 'stock', q: '',
        issue: null, cart: [], blockId: '', recipientId: '',
        receipt: null, invCart: [], pending: 0, newProd: null
    };

    function deviceId() {
        var k = 'farm_device_id';
        var v = localStorage.getItem(k);
        if (!v) { v = uuid(); localStorage.setItem(k, v); }
        return v;
    }

    /* --- чернетки/стан сторінки: переживають оновлення сторінки (навіть офлайн) ---
       Зберігаємо у localStorage активну вкладку, незбережену видачу/прихід,
       інвентаризацію та тексти пошуку. Так випадкове оновлення сторінки в офлайні
       не руйнує роботу — усе відновлюється. */
    function draftKey() { return 'farm_off_draft_' + BRANCH; }
    function saveDraft() {
        try {
            localStorage.setItem(draftKey(), JSON.stringify({
                tab: state.tab, issue: state.issue, receipt: state.receipt,
                invCart: state.invCart, saleQuery: saleQuery,
                recvSearch: recvSearch, invSearch: invSearch, newProd: state.newProd
            }));
        } catch (e) {}
    }
    function loadDraft() {
        try {
            var d = JSON.parse(localStorage.getItem(draftKey()) || 'null');
            if (!d) return;
            if (d.tab) state.tab = d.tab;
            state.issue = d.issue || null;
            state.receipt = d.receipt || null;
            state.invCart = d.invCart || [];
            state.newProd = d.newProd || null;
            saleQuery = d.saleQuery || '';
            recvSearch = d.recvSearch || '';
            invSearch = d.invSearch || '';
        } catch (e) {}
    }

    /* ---------------- IndexedDB ---------------- */
    function openDB() {
        return new Promise(function (resolve, reject) {
            var rq = indexedDB.open('farm_offline', 3);
            rq.onupgradeneeded = function () {
                var db = rq.result;
                if (!db.objectStoreNames.contains('snap')) {
                    db.createObjectStore('snap', { keyPath: 'branch' });
                }
                if (!db.objectStoreNames.contains('queue')) {
                    db.createObjectStore('queue', { keyPath: 'op_id' });
                }
                // історія проведених видач із ЦЬОГО телефона (номер — після синхр.)
                if (!db.objectStoreNames.contains('sales')) {
                    db.createObjectStore('sales', { keyPath: 'op_id' });
                }
            };
            rq.onsuccess = function () { resolve(rq.result); };
            rq.onerror = function () { reject(rq.error); };
        });
    }
    function tx(store, mode, fn) {
        return openDB().then(function (db) {
            return new Promise(function (resolve) {
                var t = db.transaction(store, mode);
                var s = t.objectStore(store);
                var out = fn(s);
                t.oncomplete = function () { resolve(out && out.result !== undefined ? out.result : out); };
                t.onerror = function () { resolve(null); };
            });
        }).catch(function () { return null; });
    }
    function snapGet(branch) {
        return tx('snap', 'readonly', function (s) { return s.get(branch); });
    }
    function snapPut(rec) {
        return tx('snap', 'readwrite', function (s) { s.put(rec); });
    }
    function queuePut(op) {
        return tx('queue', 'readwrite', function (s) { s.put(op); });
    }
    function queueDel(opId) {
        return tx('queue', 'readwrite', function (s) { s.delete(opId); });
    }
    function queueAll() {
        return openDB().then(function (db) {
            return new Promise(function (resolve) {
                var out = [];
                var t = db.transaction('queue', 'readonly');
                var rq = t.objectStore('queue').openCursor();
                rq.onsuccess = function () {
                    var c = rq.result;
                    if (c) { out.push(c.value); c.continue(); } else { resolve(out); }
                };
                rq.onerror = function () { resolve(out); };
            });
        }).catch(function () { return []; });
    }
    /* --- історія видач із цього телефона --- */
    function salePut(rec) { return tx('sales', 'readwrite', function (s) { s.put(rec); }); }
    function saleAll() {
        return openDB().then(function (db) {
            return new Promise(function (resolve) {
                var out = [];
                var t = db.transaction('sales', 'readonly');
                var rq = t.objectStore('sales').openCursor();
                rq.onsuccess = function () {
                    var c = rq.result;
                    if (c) { out.push(c.value); c.continue(); } else { resolve(out); }
                };
                rq.onerror = function () { resolve(out); };
            });
        }).catch(function () { return []; });
    }
    function saleUpdate(opId, saleNo, status, conflict) {
        return tx('sales', 'readwrite', function (s) {
            var g = s.get(opId);
            g.onsuccess = function () {
                var r = g.result; if (!r) return;
                if (saleNo) r.sale_no = saleNo;
                if (status) r.status = status;
                if (conflict) r.conflict = conflict;
                s.put(r);
            };
        });
    }
    function saleGet(opId) { return tx('sales', 'readonly', function (s) { return s.get(opId); }); }
    function saleDel(opId) { return tx('sales', 'readwrite', function (s) { s.delete(opId); }); }

    /* ---------------- стан мережі ---------------- */
    function refreshNet() {
        var n = el('offNet');
        n.className = 'off-net ' + (navigator.onLine ? 'online' : 'offline');
        n.title = navigator.onLine ? 'Онлайн' : 'Офлайн';
    }
    window.addEventListener('online', refreshNet);
    window.addEventListener('offline', refreshNet);

    function setSynced(t) { el('offSynced').textContent = t; }
    function setSyncedTime(iso) {
        if (!iso) { setSynced('Ще не завантажено'); return; }
        var d = new Date(iso), p = function (n) { return (n < 10 ? '0' : '') + n; };
        setSynced('Завантажено: ' + p(d.getDate()) + '.' + p(d.getMonth() + 1) + ' '
            + p(d.getHours()) + ':' + p(d.getMinutes()));
    }
    function updateBadge() {
        queueAll().then(function (ops) {
            state.pending = ops.length;
            var b = el('offBadge');
            if (state.pending > 0) {
                b.className = 'off-badge pending';
                b.textContent = state.pending + ' не синхронізовано';
            } else {
                b.className = 'off-badge';
                b.textContent = 'Все синхронізовано';
            }
        });
    }

    /* ---------------- завантаження знімка ---------------- */
    function downloadSnapshot() {
        var btn = el('offSync');   // кнопку «Завантажити» прибрано — може не бути
        if (!navigator.onLine) { setSynced('Немає мережі — підключіться до Wi-Fi'); return Promise.resolve(false); }
        var old = btn ? btn.textContent : '';
        if (btn) { btn.disabled = true; btn.textContent = '⏳ Завантаження…'; }
        else { setSynced('⏳ Завантаження складу…'); }
        return fetch(API + '/api/sync/device', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ device_id: deviceId(), name: 'Телефон ' + (navigator.platform || '') })
        }).catch(function () {})
        .then(function () {
            return fetch(API + '/api/sync/snapshot', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
        }).then(function (r) {
            if (r.status === 403) throw new Error('Немає дозволу на офлайн для цієї гілки.');
            if (!r.ok) throw new Error('Помилка завантаження (' + r.status + ')');
            return r.json();
        }).then(function (j) {
            if (!j || !j.ok || !j.snapshot) throw new Error((j && j.error) || 'Порожня відповідь');
            var now = new Date().toISOString();
            state.snapshot = j.snapshot; state.syncedAt = now;
            return snapPut({ branch: BRANCH, data: j.snapshot, synced_at: now });
        }).then(function () {
            setSyncedTime(state.syncedAt); render(); return true;
        }).catch(function (e) {
            // Збій мережі (fetch кидає TypeError «Load failed»/«Failed to fetch»):
            // це не помилка — просто немає звʼязку. Лишаємось на збереженому складі.
            var msg = (e && e.message) ? e.message : '';
            var netFail = (e instanceof TypeError) || /load failed|failed to fetch|networkerror|network ?request|timed? ?out/i.test(msg);
            if (netFail) {
                if (state.snapshot) { setSyncedTime(state.syncedAt); }
                else { setSynced('Немає мережі — підключіться до Wi-Fi'); }
            } else {
                setSynced('✗ ' + (msg || 'Помилка'));
            }
            return false;
        }).then(function (ok) {
            if (btn) { btn.disabled = false; btn.textContent = old; }
            return ok;
        });
    }

    /* ---------------- синхронізація черги ---------------- */
    function pushQueue() {
        var btn = el('offPush');
        if (!navigator.onLine) { toast('Немає мережі — підключіться до Wi-Fi'); return; }
        queueAll().then(function (ops) {
            // немає чого відправляти — просто оновлюємо склад із сервера
            if (!ops.length) { toast('Оновлюю склад…'); downloadSnapshot(); return; }
            // Групуємо операції за гілкою (стара черга без branch → поточна гілка)
            // і шлемо кожну на свій ендпоінт — так синхронізація однією кнопкою
            // коректно проводить і аптеку, і матеріали.
            var groups = {};
            ops.forEach(function (o) {
                var b = o.branch || BRANCH;
                (groups[b] = groups[b] || []).push(o);
            });
            btn.disabled = true; var old = btn.textContent; btn.textContent = '⏳ Синхронізація…';
            var totals = { applied: 0, conflicts: 0, rejected: 0 };
            var branches = Object.keys(groups);
            var chain = Promise.resolve();
            branches.forEach(function (b) {
                chain = chain.then(function () { return pushBranch(b, groups[b], totals); });
            });
            chain.then(function () {
                var msg = 'Проведено: ' + totals.applied;
                if (totals.conflicts) msg += ', конфліктів: ' + totals.conflicts;
                if (totals.rejected) msg += ', відхилено: ' + totals.rejected;
                toast(msg);
                updateBadge();
                return downloadSnapshot();   // оновлюємо залишки поточної гілки
            }).catch(function (e) {
                var msg = (e && e.message) ? e.message : '';
                var netFail = (e instanceof TypeError) || /load failed|failed to fetch|networkerror|network ?request|timed? ?out/i.test(msg);
                toast(netFail ? 'Немає звʼязку з сервером — спробуйте, коли буде мережа'
                              : ('✗ ' + (msg || 'Помилка')));
            }).then(function () {
                btn.disabled = false; btn.textContent = old;
            });
        });
    }
    // Відправити операції однієї гілки на її ендпоінт; прибрати проведені з черги.
    function pushBranch(branch, ops, totals) {
        // Сортуємо за часом створення: операція new_product має застосуватися
        // ДО приходу, що використовує цей штрихкод (черга в IndexedDB — за op_id,
        // тобто без порядку, тому впорядковуємо тут перед відправкою).
        var payload = ops.slice().sort(function (a, b) {
            return String(a.client_ts || '').localeCompare(String(b.client_ts || ''));
        }).map(function (o) {
            return { op_id: o.op_id, type: o.type, client_ts: o.client_ts, payload: o.payload };
        });
        return fetch(apiFor(branch) + '/api/sync/push', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ device_id: deviceId(), ops: payload })
        }).then(function (r) {
            if (r.status === 403) throw new Error('Немає дозволу на синхронізацію гілки.');
            if (!r.ok) throw new Error('Помилка синхронізації (' + r.status + ')');
            return r.json();
        }).then(function (j) {
            if (!j || !j.ok) throw new Error((j && j.error) || 'Помилка');
            totals.applied += (j.applied || 0);
            totals.conflicts += (j.conflicts || 0);
            totals.rejected += (j.rejected || 0);
            var dels = [];
            (j.results || []).forEach(function (res) {
                var ok = (res.status === 'applied' || res.status === 'conflict');
                if (ok || res.duplicate) dels.push(queueDel(res.op_id));
                if (ok) dels.push(saleDel(res.op_id));
                else dels.push(saleUpdate(res.op_id, res.sale_no, res.status, res.conflict));
            });
            return Promise.all(dels);
        });
    }

    /* ---------------- проста "тостер"-нотифікація ---------------- */
    function toast(text) {
        var t = document.createElement('div');
        t.textContent = text;
        t.style.cssText = 'position:fixed;left:50%;bottom:22px;transform:translateX(-50%);'
            + 'background:#1c2430;color:#fff;padding:10px 16px;border-radius:10px;'
            + 'font-size:14px;z-index:50;max-width:90%;box-shadow:0 6px 20px rgba(0,0,0,.25);';
        document.body.appendChild(t);
        setTimeout(function () { t.style.opacity = '0'; t.style.transition = 'opacity .4s'; }, 2600);
        setTimeout(function () { t.remove(); }, 3100);
    }

    /* ---------------- сканер штрихкодів ----------------
       Той самий сканер, що й на онлайн-Видачі (openCameraScanner з camera-scan.js):
       оверлей з лазером, статусом і безперервним скануванням. Офлайн працює завдяки
       вбудованому ZXing (Android — нативний BarcodeDetector). */
    function speak(text) {
        // Голосове підтвердження. Працює офлайн (системний голос). Якщо
        // українського голосу немає — браузер озвучить доступним, або змовчить.
        try {
            if (!('speechSynthesis' in window)) return;
            var u = new SpeechSynthesisUtterance(text);
            u.lang = 'uk-UA'; u.rate = 1;
            window.speechSynthesis.cancel();
            window.speechSynthesis.speak(u);
        } catch (e) {}
    }
    // Спільний сканер для Видачі й Приходу: один скан → сигнал → камера закривається.
    function runScanner(onProduct) {
        if (!window.openCameraScanner) { toast('Сканер недоступний — скористайтесь пошуком.'); return; }
        try { if (window.speechSynthesis) window.speechSynthesis.resume(); } catch (e) {}
        var scanner = window.openCameraScanner(function (code) {
            var p = prodByBarcode(code);
            if (p) {
                onProduct(p);
                if (scanner) scanner.setStatus('✓ Додано: ' + p.name);
                if (window.scanBeep) window.scanBeep(true);
                speak('Додано');
            } else {
                if (scanner) scanner.setStatus('✗ Не знайдено: ' + code);
                if (window.scanBeep) window.scanBeep(false);
                speak('Не знайдено');
            }
            var a = document.activeElement; if (a && a.blur) a.blur();   // не показувати клавіатуру
        }, { autoClose: true });
    }
    function startScanner() { runScanner(function (p) { addLine(p.barcode); }); }
    // Прихід: знайдено — додаємо в накладну; НЕ знайдено — одразу форма нового товару.
    function startReceiptScanner() {
        if (!window.openCameraScanner) { toast('Сканер недоступний — скористайтесь пошуком.'); return; }
        try { if (window.speechSynthesis) window.speechSynthesis.resume(); } catch (e) {}
        var scanner = window.openCameraScanner(function (code) {
            var p = prodByBarcode(code);
            if (p) {
                addRecv(code);
                if (scanner) scanner.setStatus('✓ Додано: ' + p.name);
                if (window.scanBeep) window.scanBeep(true); speak('Додано');
            } else {
                if (window.scanBeep) window.scanBeep(false); speak('Новий товар');
                openNewProduct(code, true);          // невідомий → створити товар
            }
            var a = document.activeElement; if (a && a.blur) a.blur();
        }, { autoClose: true });
    }

    /* ---------------- рендер ---------------- */
    function match(s) { return !state.q || String(s || '').toLowerCase().indexOf(state.q) !== -1; }
    function fmt(n) { n = Number(n || 0); return (Math.round(n * 1000) / 1000).toString().replace('.', ','); }
    function emptyRow() { return '<div class="off-empty">' + (state.q ? 'Нічого не знайдено' : 'Порожньо') + '</div>'; }

    var OWN_SEARCH = { sale: 1, receipt: 1, inventory: 1 };
    function render() {
        saveDraft();
        var box = el('offContent'), snap = state.snapshot, search = el('offSearch');
        // глобальне поле пошуку ховаємо на вкладках із власним пошуком
        search.style.display = OWN_SEARCH[state.tab] ? 'none' : '';
        if (!snap) {
            box.innerHTML = '<div class="off-empty">' + (navigator.onLine ? 'Завантаження складу…' : 'Немає мережі — підключіться до Wi-Fi, щоб завантажити склад.') + '</div>';
            return;
        }
        // Форма нового товару — поверх будь-якої вкладки
        if (state.newProd) { search.style.display = 'none'; box.innerHTML = renderNewProduct(); return; }
        if (state.tab === 'stock') box.innerHTML = renderStock(snap);
        else if (state.tab === 'sale') { box.innerHTML = renderSale(snap); loadSalesHistory(); }
        else if (state.tab === 'receipt') box.innerHTML = renderReceipt(snap);
        else if (state.tab === 'inventory') box.innerHTML = renderInventory(snap);
        else if (state.tab === 'catalog') box.innerHTML = renderCatalog(snap);
        else box.innerHTML = renderRefs(snap);
    }
    function renderStock(snap) {
        var items = (snap.products || []).filter(function (p) { return match(p.name) || match(p.barcode); });
        if (!items.length) return emptyRow();
        return items.map(function (p) {
            var low = Number(p.total_qty) <= Number(p.min_stock || 0);
            return '<div class="off-row"><div><div class="nm">' + esc(p.name) + '</div>'
                + '<div class="meta">' + esc(p.barcode || '') + '</div></div>'
                + '<div class="off-qty ' + (low ? 'low' : '') + '">' + fmt(p.total_qty)
                + ' <small>' + esc(p.unit || '') + '</small></div></div>';
        }).join('');
    }
    function renderCatalog(snap) {
        var head = '<button class="btn btn-primary sale-commit" id="catNewProd" style="margin-bottom:8px">+ Новий товар</button>';
        var items = (snap.catalog || []).filter(function (c) { return match(c.name) || match(c.barcode); });
        if (!items.length) return head + emptyRow();
        return head + items.map(function (c) {
            return '<div class="off-row"><div><div class="nm">' + esc(c.name) + '</div>'
                + '<div class="meta">' + esc(c.barcode || 'без штрихкоду') + '</div></div>'
                + '<div class="off-qty"><small>' + esc(c.unit || '') + '</small></div></div>';
        }).join('');
    }
    function renderRefs(snap) {
        function grp(title, arr) {
            arr = (arr || []).filter(function (x) { return match(x.name); });
            if (!arr.length) return '';
            return '<div class="off-sub">' + title + '</div>' + arr.map(function (x) {
                return '<div class="off-row"><div class="nm">' + esc(x.name) + '</div></div>';
            }).join('');
        }
        return (grp(BW('nom_pl'), snap.blocks) + grp('Отримувачі', snap.recipients)
            + grp('Постачальники', snap.suppliers)) || emptyRow();
    }

    /* ---- Видача ---- */
    var saleQuery = '';
    function prodByBarcode(bc) {
        return (state.snapshot.products || []).find(function (p) { return p.barcode === bc; });
    }
    function catByBarcode(bc) {
        return (state.snapshot.catalog || []).find(function (c) { return c.barcode === bc; });
    }

    /* ---- Новий (невідомий) товар: офлайн-форма ----
       Мінімум полів: назва (обовʼязково), штрихкод (обовʼязково), одиниця.
       Товар одразу зʼявляється в локальному знімку (можна одразу прийняти/видати),
       а в чергу йде операція new_product — сервер створить товар при синхронізації. */
    function openNewProduct(barcode, fromReceipt, name) {
        var pre = catByBarcode(barcode || '');
        state.newProd = {
            barcode: barcode || '',
            name: name || (pre ? pre.name : ''),
            unit: (pre && pre.unit) ? pre.unit : 'шт',
            fromReceipt: !!fromReceipt
        };
        render();
        setTimeout(function () { var n = el('npName'); if (n) { n.focus(); } }, 30);
    }
    function cancelNewProduct() { state.newProd = null; render(); }
    function renderNewProduct() {
        var np = state.newProd;
        return '<div class="off-sub">Новий товар</div>'
            + '<div class="sale-field"><label>Назва *</label>'
            +   '<input class="sale-search" id="npName" value="' + esc(np.name) + '" placeholder="Назва товару"></div>'
            + '<div class="sale-field"><label>Штрихкод *</label>'
            +   '<div class="sale-scanrow"><input class="sale-search" id="npBarcode" value="' + esc(np.barcode) + '" placeholder="Скануйте або введіть">'
            +     '<button class="scan-btn" id="npScan" type="button"><span class="ic">📷</span> Скан</button></div></div>'
            + '<div class="sale-field"><label>Одиниця</label>'
            +   '<input class="sale-search" id="npUnit" value="' + esc(np.unit) + '" placeholder="шт"></div>'
            + '<div class="issue-actions"><button class="btn btn-ghost" id="npCancel">Скасувати</button>'
            +   '<button class="btn btn-primary" id="npSave">Зберегти товар</button></div>';
    }
    function scanNewProductBarcode() {
        if (!window.openCameraScanner) { toast('Сканер недоступний — введіть штрихкод вручну.'); return; }
        var scanner = window.openCameraScanner(function (code) {
            if (state.newProd) state.newProd.barcode = code;
            if (scanner) scanner.setStatus('✓ ' + code);
            if (window.scanBeep) window.scanBeep(true);
            var a = document.activeElement; if (a && a.blur) a.blur();
            render();
        }, { autoClose: true });
    }
    function saveNewProduct() {
        var np = state.newProd; if (!np) return;
        var name = (np.name || '').trim();
        var barcode = (np.barcode || '').trim();
        var unit = (np.unit || 'шт').trim() || 'шт';
        if (!name) { toast('Вкажіть назву товару'); var n = el('npName'); if (n) n.focus(); return; }
        if (!barcode) { toast('Вкажіть штрихкод'); var b = el('npBarcode'); if (b) b.focus(); return; }
        var fromR = np.fromReceipt;
        // Уже є такий штрихкод — використовуємо наявний товар (без дублювання).
        if (prodByBarcode(barcode)) {
            state.newProd = null;
            if (fromR && state.receipt && state.receipt.stage === 'items') addRecv(barcode);
            else render();
            toast('Товар із таким штрихкодом уже є — взято наявний');
            return;
        }
        // 1) одразу у локальний знімок (доступний офлайн негайно)
        (state.snapshot.products = state.snapshot.products || []).push(
            { id: 'local-' + uuid(), name: name, barcode: barcode, unit: unit, total_qty: 0, min_stock: 0 });
        (state.snapshot.catalog = state.snapshot.catalog || []).push(
            { name: name, barcode: barcode, unit: unit });
        // 2) операція в чергу — сервер створить товар при синхронізації
        var op = { op_id: uuid(), type: 'new_product', client_ts: new Date().toISOString(),
            status: 'pending', branch: BRANCH, payload: { name: name, barcode: barcode, unit: unit } };
        queuePut(op)
            .then(function () { return snapPut({ branch: BRANCH, data: state.snapshot, synced_at: state.syncedAt }); })
            .then(function () {
                state.newProd = null;
                if (fromR && state.receipt && state.receipt.stage === 'items') addRecv(barcode);
                else render();
                updateBadge();
                toast('Новий товар додано' + (navigator.onLine ? ' — «Синхронізувати»' : ' (офлайн)'));
            });
    }
    function renderSale(snap) {
        var blocks = (snap.blocks || []), recs = (snap.recipients || []);
        function blkOpts(sel) {
            return '<option value="">— блок (куди) —</option>' + blocks.map(function (b) {
                return '<option value="' + b.id + '"' + (String(sel) === String(b.id) ? ' selected' : '') + '>' + esc(b.name) + '</option>';
            }).join('');
        }
        function recOpts(sel) {
            return '<option value="">— оберіть отримувача —</option>' + recs.map(function (r) {
                return '<option value="' + r.id + '"' + (String(sel) === String(r.id) ? ' selected' : '') + '>' + esc(r.name) + '</option>';
            }).join('');
        }
        var html = '', iss = state.issue;
        if (!iss) {
            html += '<button class="btn btn-primary sale-commit" id="issueNew">+ Нова видача</button>';
        } else {
            // 1) № видачі вже сформовано; 2) отримувач; 3) розпис медикаментів на блоки
            var q = saleQuery.toLowerCase(), results = '';
            if (q) {
                var found = (snap.products || []).filter(function (p) {
                    return (p.name || '').toLowerCase().indexOf(q) !== -1 || (p.barcode || '').toLowerCase().indexOf(q) !== -1;
                }).slice(0, 8);
                results = found.length ? found.map(function (p) {
                    return '<div class="sale-res" data-add="' + esc(p.barcode) + '"><span>' + esc(p.name) + '</span>'
                        + '<span class="meta">' + fmt(p.total_qty) + ' ' + esc(p.unit || '') + '</span></div>';
                }).join('') : '<div class="sale-cart-empty">Нічого не знайдено</div>';
            }
            var lines = iss.lines.length ? iss.lines.map(function (it, i) {
                // один рядок: медикамент · кількість · блок · видалити
                return '<div class="oline">'
                    + '<span class="nm" title="' + esc(it.name) + '">' + esc(it.name) + '</span>'
                    + '<button class="qtybtn sm" data-qpick="' + i + '">' + esc(String(rnum(it.qty)))
                    +   ' <span class="u">' + esc(it.unit || '') + '</span></button>'
                    + '<select class="blk" data-blk="' + i + '">' + blkOpts(it.blockId) + '</select>'
                    + '<button class="rm" data-del="' + i + '" title="Прибрати">×</button>'
                    + '</div>';
            }).join('') : '<div class="sale-cart-empty">Додайте медикаменти — скан 📷 або пошук.</div>';
            html += '<div class="issue-head"><div class="issue-no">Видача ' + esc(iss.no) + ' <span class="u">(чернетка)</span></div>'
                +   '<div class="sale-field" style="margin:6px 0 0"><label>Кому видано *</label><select id="issueRec">' + recOpts(iss.recipientId) + '</select></div></div>'
                + '<div class="sale-scanrow"><input class="sale-search" id="saleSearch" placeholder="Назва або штрихкод…" value="' + esc(saleQuery) + '">'
                +   '<button class="scan-btn" id="saleScan" type="button"><span class="ic">📷</span> Скан</button></div>'
                + '<div class="sale-results">' + results + '</div>'
                + '<div class="off-sub">Медикаменти на блоки<span class="cart-count">' + (iss.lines.length ? ' · ' + iss.lines.length : '') + '</span></div>' + lines
                + '<div class="issue-actions"><button class="btn btn-ghost" id="issueCancel">Скасувати</button>'
                +   '<button class="btn btn-primary" id="issueSave">Зберегти видачу</button></div>';
        }
        html += '<div class="off-sub">Видачі з цього телефона</div>'
            + '<div id="offSalesHist"><div class="sale-cart-empty">Завантаження…</div></div>';
        return html;
    }
    /* історія видач під кошиком (async — наповнюємо після рендеру) */
    function salesHistHtml(rows) {
        if (!rows.length) return '<div class="sale-cart-empty">Ще не було видач із цього телефона.</div>';
        rows.sort(function (a, b) { return (a.ts < b.ts) ? 1 : -1; });
        return rows.slice(0, 50).map(function (r) {
            var no, cls, editable = (r.status === 'pending' && !r.sale_no);
            if (r.sale_no) { no = '№ ' + r.sale_no; cls = 'ok'; }
            else if (r.status === 'rejected') { no = 'відхилено'; cls = 'bad'; }
            else { no = esc(r.no || 'чернетка') + ' · очікує'; cls = 'wait'; }
            var d = new Date(r.ts), p = function (n) { return (n < 10 ? '0' : '') + n; };
            var t = isNaN(d) ? '' : (p(d.getDate()) + '.' + p(d.getMonth() + 1) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()));
            return '<div class="shist">'
                + '<div class="shist-top"><span class="shist-no ' + cls + '">' + no + '</span>'
                +   '<span class="shist-t">' + t + '</span></div>'
                + '<div class="shist-m">' + esc(r.recipientName || '—') + ' · ' + (r.positions || 0) + ' поз.'
                +   (r.first ? (' · ' + esc(r.first)) : '') + '</div>'
                + (editable ? '<div class="shist-act">'
                    + '<button class="btn btn-sm" data-edit-issue="' + esc(r.op_id) + '">Редагувати</button>'
                    + '<button class="btn btn-sm btn-danger" data-del-issue="' + esc(r.op_id) + '">Видалити</button></div>' : '')
                + '</div>';
        }).join('');
    }
    function loadSalesHistory() {
        var box = el('offSalesHist'); if (!box) return;
        saleAll().then(function (rows) {
            rows = rows || [];
            // ретроспективне прибирання: видачі, що вже отримали № від сервера
            // (синхронізовані до оновлення з авто-очищенням), прибираємо — вони
            // вже на сервері. У списку лишаються тільки чернетки/очікують і відхилені.
            var keep = [];
            rows.forEach(function (r) { if (r.sale_no) saleDel(r.op_id); else keep.push(r); });
            var b = el('offSalesHist'); if (b) b.innerHTML = salesHistHtml(keep);
        });
    }

    function nameById(arr, id) {
        var x = (arr || []).find(function (o) { return String(o.id) === String(id); });
        return x ? x.name : '';
    }
    function nextIssueNo() {
        var n = 1;
        try { n = (parseInt(localStorage.getItem('farm_issue_seq') || '0', 10) || 0) + 1; localStorage.setItem('farm_issue_seq', String(n)); } catch (e) {}
        return 'Ч' + n;   // локальний номер-чернетка; реальний № прийде після синхронізації
    }
    function newIssue() {
        state.issue = { id: uuid(), no: nextIssueNo(), recipientId: '', lines: [], existing: false };
        saleQuery = ''; render();
    }
    function cancelIssue() { state.issue = null; saleQuery = ''; render(); }
    function addLine(bc) {
        if (!state.issue) state.issue = { id: uuid(), no: nextIssueNo(), recipientId: '', lines: [], existing: false };
        var p = prodByBarcode(bc); if (!p) return;
        var L = state.issue.lines;
        var line = L.find(function (x) { return x.barcode === bc; });
        if (line) line.qty = rnum(line.qty) + 1;
        else {
            var last = L[L.length - 1];
            L.push({ barcode: p.barcode, name: p.name, unit: p.unit, qty: 1, blockId: last ? last.blockId : '' });
        }
        saleQuery = ''; render();
    }
    function saveIssue() {
        var iss = state.issue; if (!iss) return;
        if (!iss.recipientId) { toast('Вкажіть отримувача (кому видано)'); return; }
        var lines = iss.lines.map(function (l) {
            return { barcode: l.barcode, name: l.name, unit: l.unit, qty: rnum(l.qty), blockId: l.blockId };
        }).filter(function (l) { return l.qty > 0; });
        if (!lines.length) { toast('Додайте медикаменти'); return; }
        var snap = state.snapshot, ts = new Date().toISOString();
        var items = lines.map(function (l) {
            return { barcode: l.barcode, qty: l.qty,
                block_id: l.blockId ? Number(l.blockId) : null,
                recipient_id: Number(iss.recipientId) };
        });
        var op = { op_id: iss.id, type: 'sale', client_ts: ts, status: 'pending',
            branch: BRANCH, payload: { items: items, move_type: 'OUT' } };
        var rec = { op_id: iss.id, ts: ts, no: iss.no, sale_no: '', status: 'pending',
            recipientId: iss.recipientId, recipientName: nameById(snap.recipients, iss.recipientId),
            positions: lines.length,
            first: lines[0].name + (lines.length > 1 ? (' +' + (lines.length - 1)) : ''),
            lines: lines.map(function (l) {
                return { barcode: l.barcode, name: l.name, unit: l.unit, qty: l.qty,
                    blockId: l.blockId, blockName: nameById(snap.blocks, l.blockId) };
            }) };
        queuePut(op).then(function () { return salePut(rec); }).then(function () {
            state.issue = null; updateBadge(); render();
            toast('Видачу ' + rec.no + ' збережено' + (navigator.onLine ? ' — «Синхронізувати»' : ' (офлайн)'));
        });
    }
    function editIssue(opId) {
        saleGet(opId).then(function (r) {
            if (!r) return;
            if (r.sale_no || r.status !== 'pending') { toast('Видачу вже синхронізовано — редагування недоступне'); return; }
            state.issue = { id: r.op_id, no: r.no, recipientId: r.recipientId || '',
                lines: (r.lines || []).map(function (l) {
                    return { barcode: l.barcode, name: l.name, unit: l.unit, qty: l.qty, blockId: l.blockId || '' };
                }), existing: true };
            saleQuery = ''; render();
        });
    }
    function deleteIssue(opId) {
        if (!window.confirm('Видалити цю видачу?')) return;
        queueDel(opId).then(function () { return saleDel(opId); }).then(function () {
            updateBadge(); render(); toast('Видачу видалено');
        });
    }

    /* ---- Прихід (крок за кроком: спершу шапка, потім товари) ----
       ПДВ — у кожному рядку своя ставка. Ціна й Сума перехресні (обидві без ПДВ):
       вводиш ціну → сума = к-сть×ціна; вводиш суму → ціна = сума/к-сть.
       ПДВ і «з ПДВ» рахуються й показуються під рядком та в «Разом». */
    var recvSearch = '';
    function rnum(v) { return parseFloat(String(v == null ? '' : v).replace(',', '.')) || 0; }
    function recvRound(n) { return Math.round((Number(n) + 1e-9) * 10000) / 10000; }
    function rmoney(n) { n = Math.round((Number(n) + 1e-9) * 100) / 100; return n.toLocaleString('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
    // Чотири перехресні поля рядка: pNo (ціна без ПДВ), pVat (ціна з ПДВ),
    // sNo (сума без ПДВ), sVat (сума з ПДВ). Канонічна величина — ціна без ПДВ;
    // за останнім введеним полем (lastEdited) обчислюємо її, далі — решту трьох.
    function recvCalc(it) {
        var q = rnum(it.qty), k = 1 + rnum(it.vat) / 100, e = it.lastEdited || 'pNo';
        if (k <= 0) k = 1;
        var pNo;
        if (e === 'pVat') pNo = rnum(it.pVat) / k;
        else if (e === 'sNo') pNo = q > 0 ? rnum(it.sNo) / q : 0;
        else if (e === 'sVat') pNo = q > 0 ? rnum(it.sVat) / (q * k) : 0;
        else pNo = rnum(it.pNo);
        pNo = recvRound(pNo);
        // десятковий роздільник — кома (як в онлайні); редаговане поле лишаємо як ввів користувач
        var cstr = function (n) { return String(n).replace('.', ','); };
        if (e !== 'pNo')  it.pNo  = pNo ? cstr(pNo) : '';
        if (e !== 'pVat') it.pVat = pNo ? cstr(recvRound(pNo * k)) : '';
        if (e !== 'sNo')  it.sNo  = (pNo && q > 0) ? cstr(recvRound(pNo * q)) : '';
        if (e !== 'sVat') it.sVat = (pNo && q > 0) ? cstr(recvRound(pNo * q * k)) : '';
    }
    // оновити 3 інші поля рядка в DOM (крім того, що зараз редагують)
    function recvFillRow(rowEl, it, except) {
        if (!rowEl) return;
        var map = { pNo: '[data-rpno]', pVat: '[data-rpvat]', sNo: '[data-rsno]', sVat: '[data-rsvat]' };
        Object.keys(map).forEach(function (key) {
            if (key === except) return;
            var inp = rowEl.querySelector(map[key]); if (inp) inp.value = it[key] || '';
        });
    }
    function recvTotalsHtml() {
        var tNo = 0, tVat = 0;
        (state.receipt ? state.receipt.items : []).forEach(function (it) {
            tNo += rnum(it.sNo); tVat += rnum(it.sVat) - rnum(it.sNo);
        });
        return 'Разом без ПДВ <b>' + rmoney(tNo) + '</b> · ПДВ <b>' + rmoney(tVat)
            + '</b> · з ПДВ <b>' + rmoney(tNo + tVat) + '</b>';
    }
    // оновити «Разом» без повного перемалювання (зберегти фокус)
    function recvLiveSums() {
        var t = el('offContent').querySelector('.rtotals'); if (t) t.innerHTML = recvTotalsHtml();
    }
    function newReceipt() {
        state.receipt = { stage: 'header', invoice: '', invoiceDate: '', receiptDate: '', supplier: '', items: [] };
        recvSearch = ''; render();
    }
    function cancelReceipt() { state.receipt = null; recvSearch = ''; render(); }
    function receiptNext() {
        var r = state.receipt; if (!r) return;
        if (!r.invoice.trim()) { toast('Вкажіть № накладної'); return; }
        if (!r.supplier.trim()) { toast('Вкажіть постачальника'); return; }
        r.stage = 'items'; render();
    }
    function receiptBack() { if (state.receipt) { state.receipt.stage = 'header'; render(); } }
    function renderReceipt(snap) {
        var suppliers = (snap.suppliers || []).map(function (s) { return '<option value="' + esc(s.name) + '">'; }).join('');
        var r = state.receipt;
        if (!r) {
            return '<button class="btn btn-primary sale-commit" id="recvNew">+ Нова накладна</button>'
                + '<div class="off-sub">Прихід</div>'
                + '<div class="sale-cart-empty">Створіть накладну: спершу № і постачальник, потім додавайте товари.</div>';
        }
        if (r.stage === 'header') {
            return '<div class="off-sub">Шапка накладної</div>'
                + '<div class="sale-field"><label>№ накладної *</label><input class="sale-search" id="recvInvoice" value="' + esc(r.invoice) + '" placeholder="напр. №123/2026"></div>'
                + '<div class="sale-field"><label>Дата накладної</label><input class="sale-search" id="recvInvoiceDate" type="date" value="' + esc(r.invoiceDate) + '"></div>'
                + '<div class="sale-field"><label>Дата приходу</label><input class="sale-search" id="recvDate" type="date" value="' + esc(r.receiptDate) + '"></div>'
                + '<div class="sale-field"><label>Постачальник *</label>'
                +   '<input class="sale-search" id="recvSupplier" list="offSuppliers" value="' + esc(r.supplier) + '" placeholder="Назва постачальника">'
                +   '<datalist id="offSuppliers">' + suppliers + '</datalist></div>'
                + '<div class="issue-actions"><button class="btn btn-ghost" id="recvCancel">Скасувати</button>'
                +   '<button class="btn btn-primary" id="recvNext">Далі</button></div>';
        }
        // stage === 'items'
        var q = recvSearch.toLowerCase(), results = '';
        if (q) {
            var found = (snap.products || []).filter(function (p) {
                return (p.name || '').toLowerCase().indexOf(q) !== -1 || (p.barcode || '').toLowerCase().indexOf(q) !== -1;
            }).slice(0, 8);
            results = found.length ? found.map(function (p) {
                return '<div class="sale-res" data-radd="' + esc(p.barcode) + '"><span>' + esc(p.name) + '</span>'
                    + '<span class="meta">' + fmt(p.total_qty) + ' ' + esc(p.unit || '') + '</span></div>';
            }).join('') : ('<div class="sale-cart-empty">Нічого не знайдено</div>'
                + '<button class="btn btn-primary" id="recvCreateNew" style="margin-top:6px">+ Створити новий товар</button>');
        }
        var lines = r.items.length ? r.items.map(function (it, i) {
            return '<div class="ocart">'
                + '<div class="ocart-h"><span class="ocart-nm">' + esc(it.name) + ' <span class="meta">' + esc(it.unit || '') + '</span></span>'
                +   '<button class="rm" data-rdel="' + i + '" title="Прибрати">×</button></div>'
                + '<div class="rline"><button class="qtybtn" data-rqpick="' + i + '">' + esc(String(rnum(it.qty)))
                +   ' <span class="u">' + esc(it.unit || '') + '</span> <span class="cv">▾</span></button>'
                +   '<label class="rvat-rate">ПДВ % <input inputmode="decimal" data-rvat="' + i + '" value="' + esc(String(it.vat)) + '"></label>'
                +   '<input type="date" class="rterm-in" data-rexp="' + i + '" value="' + esc(it.expires || '') + '" title="Термін придатності"></div>'
                + '<div class="rgrid">'
                +   '<label><span>Ціна без ПДВ</span><input inputmode="decimal" data-rpno="' + i + '" value="' + esc(String(it.pNo || '')) + '" placeholder="0,00"></label>'
                +   '<label><span>Ціна з ПДВ</span><input inputmode="decimal" data-rpvat="' + i + '" value="' + esc(String(it.pVat || '')) + '" placeholder="0,00"></label>'
                +   '<label><span>Сума без ПДВ</span><input inputmode="decimal" data-rsno="' + i + '" value="' + esc(String(it.sNo || '')) + '" placeholder="0,00"></label>'
                +   '<label><span>Сума з ПДВ</span><input inputmode="decimal" data-rsvat="' + i + '" value="' + esc(String(it.sVat || '')) + '" placeholder="0,00"></label>'
                + '</div>'
                + '</div>';
        }).join('') : '<div class="sale-cart-empty">Накладна порожня — відскануйте 📷 або знайдіть товар.</div>';
        var cnt = r.items.length ? ' · ' + r.items.length : '';
        var dt = r.invoiceDate ? (' від ' + r.invoiceDate) : '';
        return '<div class="issue-head"><div class="issue-no">Накладна ' + esc(r.invoice) + esc(dt) + '</div>'
            +   '<div class="shist-m">' + esc(r.supplier) + '</div>'
            +   '<button class="btn btn-sm" id="recvBack" style="margin-top:8px">← Змінити шапку</button></div>'
            + '<div class="sale-scanrow">'
            +   '<input class="sale-search" id="recvSearch" placeholder="Назва або штрихкод…" value="' + esc(recvSearch) + '">'
            +   '<button class="scan-btn" id="recvScan" type="button"><span class="ic">📷</span> Скан</button>'
            + '</div>'
            + '<div class="sale-results">' + results + '</div>'
            + '<div class="off-sub">Позиції накладної<span class="cart-count">' + cnt + '</span></div>' + lines
            + (r.items.length ? '<div class="rtotals">' + recvTotalsHtml() + '</div>' : '')
            + '<button class="btn btn-primary sale-commit" id="recvCommit"' + (r.items.length ? '' : ' disabled') + '>Зарахувати прихід</button>';
    }
    function addRecv(bc) {
        if (!state.receipt || state.receipt.stage !== 'items') return;
        var p = prodByBarcode(bc); if (!p) return;
        var ln = state.receipt.items.find(function (x) { return x.barcode === bc; });
        if (ln) { ln.qty = rnum(ln.qty) + 1; ln.lastEdited = 'pNo'; recvCalc(ln); }
        else state.receipt.items.push({ barcode: p.barcode, name: p.name, unit: p.unit, qty: 1, vat: '20', pNo: '', pVat: '', sNo: '', sVat: '', expires: '', lastEdited: 'pNo' });
        recvSearch = ''; render();
    }
    function commitReceipt() {
        var r = state.receipt; if (!r) return;
        if (!r.invoice.trim()) { toast('Вкажіть № накладної'); return; }
        if (!r.supplier.trim()) { toast('Вкажіть постачальника'); return; }
        var items = r.items.map(function (it) {
            var pNo = rnum(it.pNo), vat = rnum(it.vat);
            return { barcode: it.barcode, qty: rnum(it.qty),
                price_in_no_vat: pNo,
                price_in: it.pVat !== '' ? rnum(it.pVat) : recvRound(pNo * (1 + vat / 100)),
                vat_rate: vat,
                expires_on: it.expires || '' };
        }).filter(function (it) { return it.qty > 0; });
        if (!items.length) { toast('Додайте позиції з кількістю'); return; }
        var op = { op_id: uuid(), type: 'receipt', client_ts: new Date().toISOString(), status: 'pending',
            branch: BRANCH,
            payload: { header: { supplier_name: r.supplier, invoice_number: r.invoice,
                receipt_date: r.receiptDate, invoice_date: r.invoiceDate }, items: items } };
        items.forEach(function (it) { var p = prodByBarcode(it.barcode); if (p) p.total_qty = Number(p.total_qty) + it.qty; });
        queuePut(op).then(function () { return snapPut({ branch: BRANCH, data: state.snapshot, synced_at: state.syncedAt }); })
            .then(function () {
                state.receipt = null; recvSearch = '';
                updateBadge(); render(); toast('Прихід додано в чергу' + (navigator.onLine ? ' — «Синхронізувати»' : ' (офлайн)'));
            });
    }

    /* ---- Інвентаризація ---- */
    var invSearch = '';
    function renderInventory(snap) {
        var q = invSearch.toLowerCase(), results = '';
        if (q) {
            var found = (snap.products || []).filter(function (p) {
                return (p.name || '').toLowerCase().indexOf(q) !== -1 || (p.barcode || '').toLowerCase().indexOf(q) !== -1;
            }).slice(0, 8);
            results = found.length ? found.map(function (p) {
                return '<div class="sale-res" data-iadd="' + esc(p.barcode) + '"><span>' + esc(p.name) + '</span>'
                    + '<span class="meta">облік: ' + fmt(p.total_qty) + ' ' + esc(p.unit || '') + '</span></div>';
            }).join('') : '<div class="sale-cart-empty">Нічого не знайдено</div>';
        }
        var lines = state.invCart.length ? state.invCart.map(function (it, i) {
            return '<div class="sale-row"><span class="nm">' + esc(it.name) + '<div class="meta">облік: ' + fmt(it.book) + ' ' + esc(it.unit || '') + '</div></span>'
                + '<input class="q" inputmode="decimal" data-iq="' + i + '" value="' + esc(String(it.qty)) + '" placeholder="факт">'
                + '<button class="rm" data-idel="' + i + '">×</button></div>';
        }).join('') : '<div class="sale-cart-empty">Знайдіть товар і впишіть фактичну к-сть.</div>';
        return '<input class="sale-search" id="invSearch" placeholder="Знайти товар…" value="' + esc(invSearch) + '">'
            + '<div class="sale-results">' + results + '</div>'
            + '<div class="off-sub">Фактичні залишки</div>' + lines
            + '<button class="btn btn-primary sale-commit" id="invCommit"' + (state.invCart.length ? '' : ' disabled') + '>Провести інвентаризацію</button>';
    }
    function addInv(bc) {
        var p = prodByBarcode(bc); if (!p) return;
        if (state.invCart.find(function (x) { return x.barcode === bc; })) { invSearch = ''; render(); return; }
        state.invCart.push({ barcode: p.barcode, name: p.name, unit: p.unit, book: p.total_qty, qty: p.total_qty });
        invSearch = ''; render();
    }
    function commitInventory() {
        var counts = state.invCart.map(function (it) {
            return { barcode: it.barcode, qty: Number(String(it.qty).replace(',', '.')) };
        }).filter(function (it) { return !isNaN(it.qty); });
        if (!counts.length) { toast('Впишіть фактичні к-сті'); return; }
        var op = { op_id: uuid(), type: 'inventory', client_ts: new Date().toISOString(), status: 'pending',
            branch: BRANCH, payload: { counts: counts } };
        counts.forEach(function (c) { var p = prodByBarcode(c.barcode); if (p) p.total_qty = c.qty; });
        queuePut(op).then(function () { return snapPut({ branch: BRANCH, data: state.snapshot, synced_at: state.syncedAt }); })
            .then(function () {
                state.invCart = []; updateBadge(); render();
                toast('Інвентаризацію додано в чергу' + (navigator.onLine ? ' — «Синхронізувати»' : ' (офлайн)'));
            });
    }

    /* ---------------- події ---------------- */
    document.querySelectorAll('.off-tab').forEach(function (t) {
        t.addEventListener('click', function () {
            document.querySelectorAll('.off-tab').forEach(function (x) { x.classList.remove('is-active'); });
            t.classList.add('is-active'); state.tab = t.dataset.tab; render();
        });
    });
    el('offSearch').addEventListener('input', function () { state.q = this.value.trim().toLowerCase(); render(); });
    var syncBtn = el('offSync'); if (syncBtn) syncBtn.addEventListener('click', downloadSnapshot);
    el('offPush').addEventListener('click', pushQueue);

    // делеговані події всередині вмісту (Видача / Прихід / Інвентар)
    var content = el('offContent');
    content.addEventListener('click', function (e) {
        var t = e.target;
        if (t.closest('#issueNew')) { newIssue(); return; }
        if (t.closest('#issueCancel')) { cancelIssue(); return; }
        if (t.closest('#issueSave')) { saveIssue(); return; }
        var eis = t.closest('[data-edit-issue]'); if (eis) { editIssue(eis.dataset.editIssue); return; }
        var dis = t.closest('[data-del-issue]'); if (dis) { deleteIssue(dis.dataset.delIssue); return; }
        if (t.closest('#saleScan')) { startScanner(); return; }
        var qp = t.closest('[data-qpick]');
        if (qp && state.issue) { var qi = Number(qp.dataset.qpick); var ln = state.issue.lines[qi];
            if (ln) openQtyPicker(ln.unit, ln.qty, function (v) { ln.qty = v; render(); }); return; }
        var add = t.closest('[data-add]'); if (add) { addLine(add.dataset.add); return; }
        var del = t.closest('[data-del]'); if (del && state.issue) { state.issue.lines.splice(Number(del.dataset.del), 1); render(); return; }
        if (t.closest('#recvNew')) { newReceipt(); return; }
        if (t.closest('#recvCancel')) { cancelReceipt(); return; }
        if (t.closest('#recvNext')) { receiptNext(); return; }
        if (t.closest('#recvBack')) { receiptBack(); return; }
        if (t.closest('#recvScan')) { startReceiptScanner(); return; }
        var rqp = t.closest('[data-rqpick]');
        if (rqp && state.receipt) { var rqi = Number(rqp.dataset.rqpick); var rl = state.receipt.items[rqi];
            if (rl) openQtyPicker(rl.unit, rl.qty, function (v) { rl.qty = v; rl.lastEdited = 'pNo'; recvCalc(rl); render(); }); return; }
        var radd = t.closest('[data-radd]'); if (radd) { addRecv(radd.dataset.radd); return; }
        var rdel = t.closest('[data-rdel]'); if (rdel && state.receipt) { state.receipt.items.splice(Number(rdel.dataset.rdel), 1); render(); return; }
        if (t.closest('#recvCommit')) { commitReceipt(); return; }
        // новий товар
        if (t.closest('#recvCreateNew')) { openNewProduct('', true, recvSearch); return; }
        if (t.closest('#catNewProd')) { openNewProduct('', false); return; }
        if (t.closest('#npScan')) { scanNewProductBarcode(); return; }
        if (t.closest('#npCancel')) { cancelNewProduct(); return; }
        if (t.closest('#npSave')) { saveNewProduct(); return; }
        var iadd = t.closest('[data-iadd]'); if (iadd) { addInv(iadd.dataset.iadd); return; }
        var idel = t.closest('[data-idel]'); if (idel) { state.invCart.splice(Number(idel.dataset.idel), 1); render(); return; }
        if (t.id === 'invCommit') { commitInventory(); return; }
    });
    content.addEventListener('input', function (e) {
        var t = e.target;
        if (t.id === 'saleSearch') { saleQuery = t.value; renderTabOnly('sale', renderSale, 'saleSearch'); return; }
        if (t.id === 'recvSearch') { recvSearch = t.value; renderTabOnly('receipt', renderReceipt, 'recvSearch'); return; }
        if (t.id === 'invSearch') { invSearch = t.value; renderTabOnly('inventory', renderInventory, 'invSearch'); return; }
        if (t.id === 'recvSupplier') { if (state.receipt) state.receipt.supplier = t.value; return; }
        if (t.id === 'recvInvoice') { if (state.receipt) state.receipt.invoice = t.value; return; }
        if (t.id === 'recvDate') { if (state.receipt) state.receipt.receiptDate = t.value; return; }
        if (t.id === 'recvInvoiceDate') { if (state.receipt) state.receipt.invoiceDate = t.value; return; }
        if (t.id === 'npName' && state.newProd) { state.newProd.name = t.value; return; }
        if (t.id === 'npBarcode' && state.newProd) { state.newProd.barcode = t.value; return; }
        if (t.id === 'npUnit' && state.newProd) { state.newProd.unit = t.value; return; }
        var q = t.closest('[data-q]'); if (q) { var i = Number(q.dataset.q); if (state.cart[i]) state.cart[i].qty = normField(q); return; }
        var rvat = t.closest('[data-rvat]'); if (rvat && state.receipt) {
            var vi0 = Number(rvat.dataset.rvat), lv = state.receipt.items[vi0];
            if (lv) { var vd = normField(rvat).replace('.', ','); rvat.value = vd; lv.vat = vd; lv.lastEdited = 'pNo'; recvCalc(lv); recvFillRow(rvat.closest('.ocart'), lv, null); recvLiveSums(); }
            return;
        }
        // 4 перехресні поля: змінене лишаємо як є, решту 3 оновлюємо в DOM
        function recvField(sel, key) {
            var el0 = t.closest(sel); if (!el0 || !state.receipt) return false;
            var idx = Number(el0.dataset[key.attr]), it = state.receipt.items[idx];
            if (it) {
                // десятковий роздільник — кома: крапку, введену вручну, одразу міняємо на кому
                var disp = normField(el0).replace('.', ',');
                el0.value = disp; it[key.field] = disp;
                it.lastEdited = key.field; recvCalc(it); recvFillRow(el0.closest('.ocart'), it, key.field); recvLiveSums();
            }
            return true;
        }
        if (recvField('[data-rpno]',  { attr: 'rpno',  field: 'pNo'  })) return;
        if (recvField('[data-rpvat]', { attr: 'rpvat', field: 'pVat' })) return;
        if (recvField('[data-rsno]',  { attr: 'rsno',  field: 'sNo'  })) return;
        if (recvField('[data-rsvat]', { attr: 'rsvat', field: 'sVat' })) return;
        var rx = t.closest('[data-rexp]'); if (rx && state.receipt) { var rxi = Number(rx.dataset.rexp); if (state.receipt.items[rxi]) state.receipt.items[rxi].expires = rx.value; return; }
        var iq = t.closest('[data-iq]'); if (iq) { var ii = Number(iq.dataset.iq); if (state.invCart[ii]) state.invCart[ii].qty = normField(iq); return; }
    });
    content.addEventListener('change', function (e) {
        if (e.target.id === 'issueRec') { if (state.issue) state.issue.recipientId = e.target.value; return; }
        var b = e.target.closest('[data-blk]');
        if (b && state.issue) { var bi = Number(b.dataset.blk); if (state.issue.lines[bi]) state.issue.lines[bi].blockId = b.value; return; }
    });
    // перемалювати лише активну вкладку, зберігши фокус у полі пошуку
    function renderTabOnly(tab, fn, focusId) {
        if (state.tab !== tab || !state.snapshot) return;
        el('offContent').innerHTML = fn(state.snapshot);
        if (tab === 'sale') loadSalesHistory();
        var s = el(focusId); if (s) { s.focus(); s.setSelectionRange(s.value.length, s.value.length); }
    }

    /* ---------------- перемикання складів (КЛІЄНТСЬКЕ, без переходу) ----------------
       Обидва знімки вже в IndexedDB (фонове кешування), тож перемикач просто
       показує інший склад прямо на сторінці. Не залежить від мережі й від
       service worker — тому офлайн працює надійно і на iOS, і на Android. */
    function applyBranchUI() {
        el('offBranch').textContent = (BRANCH === 'materials' ? 'Матеріали' : 'Аптека');
        document.querySelectorAll('.off-switch-btn').forEach(function (b) {
            b.classList.toggle('on', b.dataset.branch === BRANCH);
        });
    }
    function loadBranchData() {
        document.querySelectorAll('.off-tab').forEach(function (x) {
            x.classList.toggle('is-active', x.dataset.tab === state.tab);
        });
        updateBadge();
        return snapGet(BRANCH).then(function (rec) {
            if (rec && rec.data) {
                state.snapshot = rec.data; state.syncedAt = rec.synced_at;
                setSyncedTime(rec.synced_at);
            } else { state.snapshot = null; state.syncedAt = null; }
            render();
            // авто-оновлення свіжого складу, якщо є мережа; офлайн лишається кеш
            if (navigator.onLine) downloadSnapshot();
            else if (!rec) setSynced('Немає мережі — підключіться до Wi-Fi');
        });
    }
    function switchBranch(newBranch) {
        if (!newBranch || newBranch === BRANCH) return;
        saveDraft();                              // зберегти чернетку поточної гілки
        BRANCH = newBranch; API = apiFor(newBranch);
        // скинути тимчасовий стан і відновити чернетку нової гілки
        state.snapshot = null; state.cart = []; state.issue = null;
        state.receipt = null; state.invCart = []; state.q = '';
        state.blockId = ''; state.recipientId = ''; state.tab = 'stock';
        saleQuery = ''; recvSearch = ''; invSearch = '';
        loadDraft();
        var s = el('offSearch'); if (s) s.value = '';
        applyBranchUI();
        loadBranchData();
    }
    document.querySelectorAll('.off-switch-btn').forEach(function (b) {
        b.addEventListener('click', function (e) { e.preventDefault(); switchBranch(b.dataset.branch); });
    });

    /* ---------------- старт ---------------- */
    refreshNet();
    // відновити вкладку/чернетки після (можливо випадкового) оновлення сторінки
    loadDraft();
    applyBranchUI();
    loadBranchData();
})();
