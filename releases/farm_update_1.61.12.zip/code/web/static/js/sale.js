/* ============ Видача / списання зі складу (некомерційна) ============
   Принцип як в офлайні: СПОЧАТКУ отримувач (прізвище) — один на всю видачу,
   ПОТІМ препарати; блок (куди) задається в КОЖНОМУ рядку списку. */

const saleSearch      = document.getElementById('saleSearch');
const saleSuggestions = document.getElementById('saleSuggestions');
const salePreview     = document.getElementById('salePreview');
const cartTable       = document.getElementById('cartTable');
const cartBody        = cartTable.querySelector('tbody');
const cartCount       = document.getElementById('cartCount');
const cartTitle       = document.getElementById('cartTitle');
const saleNote        = document.getElementById('saleNote');
const saleNoteLabel   = document.getElementById('saleNoteLabel');
const saleReason      = document.getElementById('saleReason');
const saleReasonField = document.getElementById('saleReasonField');
/* Підсумкова примітка списання: причина + вільний текст */
function writeoffNote() {
    const reason = (saleReason && saleReason.value || '').trim();
    const extra = (saleNote.value || '').trim();
    if (!reason) return extra;
    return extra ? `${reason} · ${extra}` : reason;
}
const clearCartBtn    = document.getElementById('clearCartBtn');
const processSaleBtn  = document.getElementById('processSaleBtn');
const recentBody      = document.querySelector('#recentSalesTable tbody');
const addBlockBtn     = document.getElementById('addBlockBtn');
const addRecipientBtn = document.getElementById('addRecipientBtn');
const issueRecipient  = document.getElementById('issueRecipient');   // один отримувач на всю видачу
const issueRecipField = document.getElementById('issueRecipField');
const issueKind       = document.getElementById('issueKind');        // група (корови/молодняк) — фільтр блоків
const issueKindField  = document.getElementById('issueKindField');
const issueSub        = document.getElementById('issueSub');          // підгрупа (2-й рівень) — фільтр блоків
const issueDate       = document.getElementById('issueDate');        // дата видачі/списання (можна заднім числом)
const issueDateLabel  = document.getElementById('issueDateLabel');

/* Мітка групи операції за herd_kind блоку */
function groupLabel(k) {
    return k === 'cow' ? 'Корови' : (k === 'young' ? 'Молодняк'
        : (k === 'pig' ? 'Свині' : ''));
}

/* Локальна дата (не UTC) у форматі YYYY-MM-DD */
function todayISO() {
    const d = new Date(), p = (n) => (n < 10 ? '0' : '') + n;
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

let mode = 'OUT';          // 'OUT' (видача) | 'WRITE_OFF' (списання)
let cart = [];             // [{id, name, barcode, unit, qty, stock, block_id, recipient_id}]
let currentProduct = null;
let blocksList = [];
let recipientsList = [];

const opLabel = {
    OUT: { text: 'Видача', cls: 'out' },
    WRITE_OFF: { text: 'Списання', cls: 'wo' },
    RETURN: { text: 'Повернення', cls: 'ret' },
};

function parseDec(v) {
    const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
    return isFinite(n) ? n : 0;
}

/* Скільки цього товару вже додано в активний список (видача/списання) —
   щоб у пошуку/прев'ю показувати ДОСТУПНИЙ залишок (склад − у списку). */
function cartQtyFor(barcode) {
    return cart.filter((l) => l.barcode === barcode)
        .reduce((s, l) => s + (parseDec(l.qty) || 0), 0);
}
window.stockReserved = (p) => cartQtyFor(p && p.barcode);

/* ---------- збереження списку між сторінками ---------- */

const CART_KEY = 'vetpharm:issue_cart';
let lastLocalChange = 0;

function persistCart() {
    lastLocalChange = Date.now();
    // тип операції, примітка та отримувач — локальні (для цього пристрою)
    try {
        localStorage.setItem(CART_KEY, JSON.stringify({
            mode, note: saleNote.value,
            recipient: issueRecipient ? issueRecipient.value : '',
            kind: issueKind ? issueKind.value : '',
            date: issueDate ? issueDate.value : '',
        }));
    } catch (_) { /* ignore */ }
    // сам список — у СПІЛЬНИЙ серверний кошик (видно на всіх пристроях)
    apiSend('/api/cart/save', 'POST', { cart }).catch(() => {});
}

function refreshCartStock() {
    cart.forEach((l) => {
        const p = productsIndex.find((x) => x.id === l.id);
        if (p) l.stock = p.total_qty;
    });
}

async function restoreCart() {
    try {
        const saved = JSON.parse(localStorage.getItem(CART_KEY) || 'null');
        if (saved) {
            if (saved.note) saleNote.value = saved.note;
            if (saved.mode) setMode(saved.mode);
            if (saved.recipient && issueRecipient) issueRecipient.value = saved.recipient;
            if (saved.kind && issueKind) issueKind.value = saved.kind;
            if (saved.date && issueDate) issueDate.value = saved.date;
        }
    } catch (_) { /* ignore */ }
    // дата за замовчуванням — сьогодні; не пускаємо в майбутнє
    if (issueDate) {
        issueDate.max = todayISO();
        if (!issueDate.value) issueDate.value = todayISO();
    }
    const r = await apiGet('/api/cart');
    cart = (r && r.ok && Array.isArray(r.cart)) ? r.cart : [];
    refreshCartStock();
    renderCart();
}

/* Скан у спільний кошик (сервер зливає атомарно) */
async function serverScan(barcode, qty) {
    const r = await apiSend('/api/cart/scan', 'POST', { barcode, qty: qty || 1 });
    if (r && r.ok) {
        cart = Array.isArray(r.cart) ? r.cart : cart;
        refreshCartStock();
        lastLocalChange = Date.now();
        renderCart();
    }
    return r;
}

/* ---------- режим: видача / списання ---------- */

function setMode(m) {
    mode = m;
    // ЛИШЕ кнопки перемикача операції (data-mode). Інакше знімається активність
    // з інших перемикачів сторінки (напр. «Видача / Таблиця» у гілці Годівля).
    document.querySelectorAll('.segmented .seg-btn[data-mode]').forEach((btn) => {
        btn.classList.toggle('is-active', btn.dataset.mode === m);
    });
    const issue = (m === 'OUT');
    cartTitle.textContent = issue ? 'До видачі' : 'До списання';
    processSaleBtn.textContent = issue ? 'Провести видачу' : 'Провести списання';
    saleNoteLabel.textContent = issue ? 'Примітка' : 'Примітка (додатково)';
    if (saleReasonField) saleReasonField.style.display = issue ? 'none' : '';
    // У режимі списання колонку «Блок» і поле отримувача приховуємо
    cartTable.classList.toggle('hide-issue', !issue);
    if (addBlockBtn) addBlockBtn.style.display = issue ? '' : 'none';
    if (issueRecipField) issueRecipField.style.display = issue ? '' : 'none';
    const nfField = document.getElementById('feedNotFeedField');
    if (nfField) nfField.style.display = issue ? '' : 'none';
    if (issueKindField) issueKindField.style.display = issue ? '' : 'none';
    if (issueDateLabel) issueDateLabel.textContent = issue ? 'Дата видачі' : 'Дата списання';
}

/* Блоки для обраної групи (корови/молодняк) і підгрупи. Група обов'язкова;
   підгрупа — необов'язкова (порожня = усі підгрупи цієї групи). */
function blocksForKind() {
    const k = issueKind ? issueKind.value : '';
    if (!k) return [];
    const sub = issueSub ? issueSub.value : '';
    return blocksList.filter((b) =>
        (b.herd_kind || '') === k && (!sub || (b.subgroup || '') === sub));
}

/* Наповнити список підгруп за блоками поточної групи. Зберігаємо вибір,
   якщо він ще валідний; інакше скидаємо на «усі підгрупи». */
function populateSubgroups() {
    if (!issueSub) return;
    const k = issueKind ? issueKind.value : '';
    const subs = [...new Set(blocksList
        .filter((b) => (b.herd_kind || '') === k)
        .map((b) => (b.subgroup || '').trim())
        .filter(Boolean))].sort((a, b) => a.localeCompare(b, 'uk'));
    const prev = issueSub.value;
    issueSub.innerHTML = '<option value="">усі підгрупи</option>'
        + subs.map((s) => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
    issueSub.value = subs.includes(prev) ? prev : '';
    // ховаємо поле, якщо підгруп немає взагалі
    const field = document.getElementById('issueSubField');
    if (field) field.style.display = subs.length ? '' : 'none';
}

document.querySelectorAll('.segmented .seg-btn[data-mode]').forEach((btn) => {
    btn.addEventListener('click', async () => {
        const m = btn.dataset.mode;
        if (m === mode) return;
        if (cart.length && !(await confirmAction('Список містить позиції. Очистити його для зміни типу операції?'))) {
            return;
        }
        cart = [];
        renderCart();
        setMode(m);
        persistCart();
    });
});

/* ---------- довідники: блоки та отримувачі ---------- */

async function loadBlocks() {
    const r = await apiGet('/api/blocks');
    blocksList = (r && r.items) || [];
    populateSubgroups();
}

async function loadRecipients() {
    const r = await apiGet('/api/recipients');
    recipientsList = (r && r.items) || [];
    renderRecipientSelect();
}

/* Наповнити верхній список отримувачів, зберігши поточний вибір */
function renderRecipientSelect() {
    if (!issueRecipient) return;
    const prev = issueRecipient.value;
    issueRecipient.innerHTML = optionsHtml(recipientsList, prev, '— без прізвища —');
}

function optionsHtml(list, selectedId, placeholder) {
    const sel = String(selectedId == null ? '' : selectedId);
    return `<option value="">${placeholder}</option>` + list.map((x) =>
        `<option value="${x.id}" ${String(x.id) === sel ? 'selected' : ''}>${escapeHtml(x.name)}</option>`
    ).join('');
}

if (addBlockBtn) addBlockBtn.addEventListener('click', async () => {
    const name = (window.prompt('Назва нового блоку:') || '').trim();
    if (!name) return;
    const r = await apiSend('/api/blocks', 'POST', { name });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    await loadBlocks();
    renderCart();
    toast(BW('nom') + ' додано', 'success');
});

addRecipientBtn.addEventListener('click', async () => {
    const name = (window.prompt('Прізвище отримувача:') || '').trim();
    if (!name) return;
    const r = await apiSend('/api/recipients', 'POST', { name });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    await loadRecipients();
    // одразу обрати щойно доданого
    const added = recipientsList.find((x) => x.name === name);
    if (added && issueRecipient) { issueRecipient.value = String(added.id); clearInvalid(issueRecipient); persistCart(); }
    if (saleSearch) saleSearch.focus();   // фокус назад у поле — щоб сканер працював
    toast('Отримувача додано', 'success');
});

/* ---------- пошук / сканування товару ---------- */

function renderPreview(product, notFoundCode) {
    if (!product) {
        salePreview.innerHTML =
            `<div class="preview-name text-warn">Товар «${escapeHtml(notFoundCode || '')}» не знайдено</div>`;
        return;
    }
    // Доступно = складський залишок − уже додане в список «До видачі/списання».
    const avail = (product.total_qty || 0) - cartQtyFor(product.barcode);
    const low = avail <= 0;
    salePreview.innerHTML = `
        <div>
            <div class="preview-name">${escapeHtml(product.name)}</div>
            <div class="preview-meta">${escapeHtml(product.barcode)} · ${escapeHtml(product.unit || '')}</div>
        </div>
        <div class="preview-stock ${low ? 'low' : ''}">
            <div class="preview-stock-value">${fmtNum(avail)}</div>
            <div class="preview-stock-label">залишок ${escapeHtml(product.unit || '')}</div>
        </div>
    `;
}

async function lookupProduct(barcode) {
    saleSuggestions.hidden = true;
    const r = await apiGet('/api/products/' + encodeURIComponent(barcode));
    if (!r.ok) {
        currentProduct = null;
        renderPreview(null, barcode);
        if (window.scanBeep) window.scanBeep(false);   // сигнал «не знайдено»
        toast('Товар не знайдено', 'error');
        return;
    }
    const product = r.product;
    if (window.scanBeep) window.scanBeep(true);          // сигнал «знайдено»
    if (product.total_qty <= 0) toast('Товару немає в наявності', 'warn');
    // Вибір/скан товару — ОДРАЗУ додаємо в список «До видачі» (к-сть 1),
    // очищаємо пошук і ставимо фокус на кількість доданого рядка.
    await cartAdd(product, 1);
    currentProduct = null;
    saleSearch.value = '';
    renderPreview(product);                              // показуємо, що додано
    saleSuggestions.hidden = true;
    focusCartQty(product.barcode);
}

createAutocomplete(saleSearch, saleSuggestions, (p) => {
    saleSearch.value = p.name;
    lookupProduct(p.barcode);
}, { showAllOnFocus: !!window.SALE_SHOW_ALL });
attachScannerHandler(saleSearch, lookupProduct);

/* ---------- додавання позиції ---------- */

function markInvalid(el)  { if (el) el.classList.add('input-error'); }
function clearInvalid(el) { if (el) el.classList.remove('input-error'); }

/* Додати товар у СПІЛЬНИЙ кошик (через сервер, накопичує однакові) */
function cartAdd(product, qty) {
    return serverScan(product.barcode, qty);
}

/* Автофокус на полі кількості доданого рядка (виділяємо вміст для заміни) */
function focusCartQty(barcode) {
    const idx = cart.findIndex((l) => l.barcode === barcode);
    if (idx < 0) return;
    const inp = cartBody.querySelector(`.cart-qty[data-idx="${idx}"]`);
    if (inp) { inp.focus(); try { inp.select(); } catch (_) { /* ignore */ } }
}

// Кнопки «+ Додати в список» більше немає — товар додається одразу при
// виборі/скані (див. lookupProduct вище).

/* ---------- сканування камерою телефона: скан → товар у список ---------- */
// F2 — перший раз фокус на полі пошуку, другий раз — камера.
if (window.attachScanShortcut) {
    attachScanShortcut(saleSearch, document.getElementById('cameraScanBtn'));
}
(function () {
    const camBtn = document.getElementById('cameraScanBtn');
    if (!camBtn || !window.openCameraScanner) return;
    camBtn.addEventListener('click', () => {
        const scanner = openCameraScanner(async (code) => {
            const r = await serverScan(code, 1);   // одразу у спільний кошик
            if (scanner) scanner.setStatus((r && r.ok)
                ? '✓ Додано: ' + r.added + '  ·  у списку: ' + cart.length
                : '✗ Не знайдено: ' + code);
            if (window.scanBeep) window.scanBeep(r && r.ok);
            const a = document.activeElement;      // не показувати клавіатуру поверх камери
            if (a && a.blur) a.blur();
        });
    });
})();

/* ---------- відображення списку ---------- */

function renderCart() {
    if (cart.length === 0) {
        cartBody.innerHTML = '<tr><td colspan="4" class="empty">Список порожній</td></tr>';
    } else {
        const baseBlocks = blocksForKind();
        cartBody.innerHTML = cart.map((l, i) => {
            const over = l.qty > l.stock + 1e-9;
            // показуємо блоки обраної групи; якщо рядок уже має блок іншої групи —
            // лишаємо його в списку, щоб вибір не зникав
            let rowBlocks = baseBlocks;
            if (l.block_id && !baseBlocks.some((b) => String(b.id) === String(l.block_id))) {
                rowBlocks = baseBlocks.concat(
                    blocksList.filter((b) => String(b.id) === String(l.block_id)));
            }
            return `
                <tr data-idx="${i}" class="${over ? 'cart-over' : ''}">
                    <td>${escapeHtml(l.name)}
                        <div class="cart-stock-note ${over ? 'over' : ''}">
                            ${escapeHtml(l.barcode)} · залишок ${fmtNum(l.stock)} ${escapeHtml(l.unit)}
                        </div>
                    </td>
                    <td class="issue-col">
                        <select class="cart-input cart-block" data-idx="${i}">
                            ${optionsHtml(rowBlocks, l.block_id, '— блок —')}
                        </select>
                    </td>
                    <td class="num">
                        <input class="cart-input cart-qty" inputmode="decimal"
                               data-idx="${i}" value="${l.qty}">
                    </td>
                    <td class="col-actions">
                        <button class="btn btn-icon btn-icon-danger" data-remove="${i}" title="Прибрати">🗑</button>
                    </td>
                </tr>
            `;
        }).join('');
    }
    updateCartFooter();
}

function updateCartFooter() {
    cartCount.textContent = fmtNum(cart.reduce((s, l) => s + l.qty, 0));
}

cartBody.addEventListener('input', (e) => {
    const inp = e.target.closest('.cart-qty');
    if (!inp) return;
    const idx = parseInt(inp.dataset.idx, 10);
    if (!cart[idx]) return;
    cart[idx].qty = parseDec(inp.value);
    const over = cart[idx].qty > cart[idx].stock + 1e-9;
    const row = inp.closest('tr');
    row.classList.toggle('cart-over', over);
    row.querySelector('.cart-stock-note').classList.toggle('over', over);
    updateCartFooter();
    persistCart();
});

cartBody.addEventListener('change', (e) => {
    const sel = e.target.closest('.cart-block');
    if (!sel) return;
    const idx = parseInt(sel.dataset.idx, 10);
    if (!cart[idx]) return;
    cart[idx].block_id = sel.value;
    clearInvalid(sel);
    persistCart();
});

/* зміна отримувача (прізвища) — один на всю видачу.
   ВАЖЛИВО: після вибору прізвища повертаємо фокус у поле пошуку — інакше
   USB/Bluetooth-сканер «друкує» у випадаючий список і не спрацьовує. */
if (issueRecipient) {
    issueRecipient.addEventListener('change', () => {
        clearInvalid(issueRecipient);
        persistCart();
        if (saleSearch) saleSearch.focus();
    });
}

/* зміна групи (корови/молодняк) — перемальовуємо кошик, щоб блоки
   відфільтрувались під обрану групу */
if (issueKind) {
    issueKind.addEventListener('change', () => {
        populateSubgroups();
        renderCart();
        persistCart();
        if (saleSearch) saleSearch.focus();
    });
}

/* зміна підгрупи — перефільтровуємо блоки в кошику */
if (issueSub) {
    issueSub.addEventListener('change', () => {
        renderCart();
        persistCart();
    });
}

/* зміна дати видачі/списання — запамʼятовуємо */
if (issueDate) {
    issueDate.addEventListener('change', persistCart);
}

cartBody.addEventListener('click', (e) => {
    const rm = e.target.closest('[data-remove]');
    if (rm) {
        cart.splice(parseInt(rm.dataset.remove, 10), 1);
        renderCart();
        persistCart();
    }
});

clearCartBtn.addEventListener('click', async () => {
    if (!cart.length) return;
    if (!await confirmAction('Очистити список?')) return;
    cart = [];
    renderCart();
    persistCart();
});

saleNote.addEventListener('input', persistCart);

/* ---------- проведення операції ---------- */

async function processSale() {
    if (cart.length === 0) { toast('Список порожній — додайте позиції', 'warn'); return; }
    const overLine = cart.find((l) => l.qty > l.stock + 1e-9);
    if (overLine) { toast(`Недостатньо «${overLine.name}» на складі`, 'error'); return; }
    const badLine = cart.find((l) => !(l.qty > 0));
    if (badLine) { toast(`Перевірте кількість: «${badLine.name}»`, 'warn'); return; }

    // У режимі видачі: отримувач необов'язковий (порожній = без прізвища/null),
    // а от група і блок у кожному рядку — обов'язкові
    const recipientId = issueRecipient ? issueRecipient.value : '';
    if (mode === 'WRITE_OFF' && saleReason && !saleReason.value) {
        toast('Оберіть причину списання', 'warn');
        markInvalid(saleReason); saleReason.focus();
        return;
    }
    if (mode === 'OUT') {
        if (!(issueKind && issueKind.value)) {
            toast('Оберіть групу (Корови / Молодняк / Свині)', 'warn');
            markInvalid(issueKind); if (issueKind) issueKind.focus();
            return;
        }
        const noBlockIdx = cart.findIndex((l) => !l.block_id);
        if (noBlockIdx >= 0) {
            toast(`Оберіть блок для «${cart[noBlockIdx].name}»`, 'warn');
            const sel = cartBody.querySelector(`.cart-block[data-idx="${noBlockIdx}"]`);
            markInvalid(sel); if (sel) sel.focus();
            return;
        }
    }

    // «Не корм» (напр. підстилка): видача корму, що НЕ рахується як спожитий
    // корм і не йде у ₴/л — лише у витрати складу. Лише для видачі (OUT).
    const nfEl = document.getElementById('feedNotFeed');
    const notFeed = (mode === 'OUT' && nfEl && nfEl.checked) ? 1 : 0;
    const payload = {
        move_type: mode,
        note: (mode === 'WRITE_OFF') ? writeoffNote() : saleNote.value,
        date: issueDate ? (issueDate.value || '') : '',
        items: cart.map((l) => ({
            barcode: l.barcode,
            qty: l.qty,
            block_id: (mode === 'OUT') ? l.block_id : '',
            recipient_id: (mode === 'OUT') ? recipientId : '',   // один отримувач на всю видачу
            not_feed: notFeed,
        })),
    };
    const r = await apiSend('/api/sale/bulk', 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }

    const lbl = opLabel[mode] ? opLabel[mode].text : 'Операція';
    toast(`${lbl} ${formatSaleNo(r.sale_no, mode)}: ${r.positions} поз.`, 'success');

    cart = [];
    saleNote.value = '';
    if (saleReason) saleReason.value = '';
    if (nfEl) nfEl.checked = false;
    currentProduct = null;
    if (issueDate) issueDate.value = todayISO();   // наступна операція — за сьогодні
    salePreview.innerHTML = '';        // прибрати застаріле прев'ю після видачі
    persistCart();
    renderCart();
    loadRecentSales();
    await loadProductsIndex();          // свіжі залишки у пошуку/прев'ю
    saleSearch.focus();
}

processSaleBtn.addEventListener('click', processSale);
saleNote.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); processSale(); }
});

/* ---------- останні операції з пошуком ---------- */

let lastSalesJson = '';
let salesSearchSaleNo = '';
let salesSearchQuery = '';

const salesSearchNoInput = document.getElementById('salesSearchNo');
const salesSearchQInput  = document.getElementById('salesSearchQ');
const salesCount         = document.getElementById('salesCount');
const salesFromEl        = document.getElementById('salesFrom');
const salesToEl          = document.getElementById('salesTo');

function salesISO(d) { return d.toISOString().slice(0, 10); }
function salesSetPeriod(days) {
    if (days === 'all') { salesFromEl.value = ''; salesToEl.value = ''; return; }
    const today = new Date();
    salesToEl.value = salesISO(today);
    const from = new Date();
    from.setDate(today.getDate() - Number(days));
    salesFromEl.value = salesISO(from);
}
function salesMarkPreset(days) {
    document.querySelectorAll('#salesPresets .btn').forEach(b =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));
}

function positionText(it) {
    let s = `${escapeHtml(it.name)} ×${fmtNum(it.qty)}`;
    const dest = [];
    if (it.block_name) dest.push(escapeHtml(it.block_name));
    if (it.recipient_name) dest.push(escapeHtml(it.recipient_name));
    if (dest.length) s += ` → ${dest.join(' / ')}`;
    return s;
}

async function loadRecentSales() {
    const hasFilter = !!(salesSearchSaleNo || salesSearchQuery);
    let url;
    if (hasFilter) {
        const params = new URLSearchParams();
        if (salesSearchSaleNo) params.set('sale_no', salesSearchSaleNo);
        if (salesSearchQuery)  params.set('q', salesSearchQuery);
        url = '/api/sales/search?' + params.toString();
    } else {
        const params = new URLSearchParams();
        if (salesFromEl && salesFromEl.value) params.set('from', salesFromEl.value);
        if (salesToEl && salesToEl.value) params.set('to', salesToEl.value);
        url = '/api/sales/recent' + (params.toString() ? '?' + params.toString() : '');
    }
    const r = await apiGet(url);
    if (!r.ok) return;
    const items = r.items || [];
    const j = url + '|' + JSON.stringify(items);
    if (j === lastSalesJson) return;
    lastSalesJson = j;
    salesCount.textContent = hasFilter ? ('Знайдено: ' + items.length) : '';
    if (items.length === 0) {
        recentBody.innerHTML = '<tr><td colspan="14" class="empty">' +
            (hasFilter ? 'Нічого не знайдено' : 'Поки що порожньо') + '</td></tr>';
    } else {
        recentBody.innerHTML = items.map((s) => {
            const lbl = opLabel[s.move_type] || { text: s.move_type, cls: '' };
            const its = (s.items && s.items.length) ? s.items : [{}];
            return its.map((it, idx) => {
                const first = idx === 0;
                const q = Number(it.qty) || 0;
                const sumV = Number(it.total) || 0;
                const sumNV = Number(it.total_no_vat) || 0;
                const priceV = q ? sumV / q : 0;
                const priceNV = q ? sumNV / q : 0;
                const head = first ? `
                    <td data-col="sale_no" rowspan="${its.length}"><strong>${escapeHtml(formatSaleNo(s.sale_no, s.move_type))}</strong></td>
                    <td data-col="created_at" rowspan="${its.length}" class="text-mute nowrap">${fmtDateTime(s.created_at)}</td>
                    <td data-col="move_type" rowspan="${its.length}"><span class="badge ${lbl.cls}">${lbl.text}</span></td>
                    <td data-col="group" rowspan="${its.length}" class="text-mute">${groupLabel(s.herd_kind)}</td>` : '';
                const tail = first ? `
                    <td data-col="user_login" rowspan="${its.length}" class="text-mute">${escapeHtml(s.user_login || '')}</td>
                    <td rowspan="${its.length}" class="col-actions">
                        <div class="row-actions">
                            <a class="btn btn-icon" href="${(window.API_BASE || '')}/sale/${encodeURIComponent(s.sale_no)}/invoice"
                               target="_blank" title="Друк накладної-вимоги">🖨</a>
                            ${s.can_edit ? `<button class="btn btn-icon" data-edit-sale="${escapeHtml(s.sale_no)}"
                                    title="Редагувати (блок / кому)">✎</button>
                            <button class="btn btn-icon btn-icon-danger" data-undo="${escapeHtml(s.sale_no)}"
                                    title="Відмінити операцію">↩</button>` : ''}
                        </div>
                    </td>` : '';
                return `
                    <tr>
                        ${head}
                        <td data-col="name">${escapeHtml(it.name || '')}</td>
                        <td data-col="block">${escapeHtml(it.block_name || '')}</td>
                        <td data-col="recipient">${escapeHtml(it.recipient_name || '')}</td>
                        <td data-col="qty" class="num">${fmtNum(it.qty)}</td>
                        <td data-col="price_no_vat" class="num">${fmtMoney(priceNV)}</td>
                        <td data-col="price_vat" class="num">${fmtMoney(priceV)}</td>
                        <td data-col="sum_no_vat" class="num">${fmtMoney(sumNV)}</td>
                        <td data-col="sum_vat" class="num">${fmtMoney(sumV)}</td>
                        ${tail}
                    </tr>
                `;
            }).join('');
        }).join('');
    }
    makeColumnsResizable('recentSalesTable', 'vetpharm:sales_cols_v2');
    applySaleCols();
}

/* ---------- вибір колонок «Останніх операцій» ---------- */

const SALE_COLS = [
    { key: 'sale_no',      label: '№' },
    { key: 'created_at',   label: 'Дата' },
    { key: 'move_type',    label: 'Тип' },
    { key: 'group',        label: 'Група' },
    { key: 'name',         label: (window.ITEM_WORDS && window.ITEM_WORDS.nom) || 'Препарат' },
    { key: 'block',        label: BW('nom') },
    { key: 'recipient',    label: 'Кому' },
    { key: 'qty',          label: 'К-сть' },
    { key: 'price_no_vat', label: 'Ціна без ПДВ' },
    { key: 'price_vat',    label: 'Ціна з ПДВ' },
    { key: 'sum_no_vat',   label: 'Сума без ПДВ' },
    { key: 'sum_vat',      label: 'Сума з ПДВ' },
    { key: 'user_login',   label: 'Користувач' },
];
const SALE_HIDDEN_KEY = 'vetpharm:sales_cols_hidden';
function getSaleHidden() {
    try { return new Set(JSON.parse(localStorage.getItem(SALE_HIDDEN_KEY) || '[]')); }
    catch (_) { return new Set(); }
}
function applySaleCols() {
    const hidden = getSaleHidden();
    const tbl = document.getElementById('recentSalesTable');
    if (!tbl) return;
    SALE_COLS.forEach((c) => {
        tbl.querySelectorAll(`[data-col="${c.key}"]`).forEach((el) => {
            el.style.display = hidden.has(c.key) ? 'none' : '';
        });
    });
}
(function initSaleColumnPicker() {
    const anchor = document.querySelector('#recentSalesTable')
        ?.closest('.panel')?.querySelector('.rcp-fields');
    if (!anchor) return;
    const hidden = getSaleHidden();
    const wrap = document.createElement('div');
    wrap.className = 'col-picker';
    wrap.innerHTML =
        '<button type="button" class="btn btn-ghost col-picker-btn" title="Колонки">⚙ Колонки</button>' +
        '<div class="col-picker-menu" hidden>' +
          '<div class="col-picker-title">Видимі колонки</div>' +
          SALE_COLS.map((c) =>
            `<label class="col-picker-item"><input type="checkbox" data-key="${c.key}" ${hidden.has(c.key) ? '' : 'checked'}><span>${c.label}</span></label>`
          ).join('') +
        '</div>';
    anchor.appendChild(wrap);
    const btn = wrap.querySelector('.col-picker-btn');
    const menu = wrap.querySelector('.col-picker-menu');
    function positionMenu() {
        menu.style.top = ''; menu.style.left = '';
        const r = btn.getBoundingClientRect();
        const mh = menu.offsetHeight, mw = menu.offsetWidth;
        const below = window.innerHeight - r.bottom, above = r.top;
        // якщо знизу замало місця, а зверху більше — відкриваємо вгору
        const top = (below < mh + 12 && above > below)
            ? Math.max(4, r.top - mh - 4) : (r.bottom + 4);
        let left = r.right - mw;
        if (left < 4) left = 4;
        if (left + mw > window.innerWidth - 4) left = window.innerWidth - mw - 4;
        menu.style.top = top + 'px';
        menu.style.left = left + 'px';
    }
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (menu.hidden) { menu.hidden = false; positionMenu(); } else { menu.hidden = true; }
    });
    window.addEventListener('resize', () => { if (!menu.hidden) positionMenu(); });
    window.addEventListener('scroll', () => { if (!menu.hidden) positionMenu(); }, { passive: true });
    document.addEventListener('click', (e) => { if (!wrap.contains(e.target)) menu.hidden = true; });
    menu.querySelectorAll('input[type="checkbox"]').forEach((inp) => {
        inp.addEventListener('change', () => {
            const h = getSaleHidden();
            if (inp.checked) h.delete(inp.dataset.key); else h.add(inp.dataset.key);
            localStorage.setItem(SALE_HIDDEN_KEY, JSON.stringify([...h]));
            applySaleCols();
        });
    });
})();

let salesSearchTimer = null;
function scheduleSalesSearch() {
    clearTimeout(salesSearchTimer);
    salesSearchTimer = setTimeout(() => {
        salesSearchSaleNo = (salesSearchNoInput?.value || '').trim();
        salesSearchQuery  = (salesSearchQInput?.value  || '').trim();
        lastSalesJson = '';
        loadRecentSales();
    }, 250);
}
if (salesSearchNoInput) salesSearchNoInput.addEventListener('input', scheduleSalesSearch);
if (salesSearchQInput)  salesSearchQInput.addEventListener('input', scheduleSalesSearch);

// Пресети періоду + ручні дати (як у «Дії користувачів»)
const salesPresetsEl = document.getElementById('salesPresets');
if (salesPresetsEl) {
    salesPresetsEl.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-days]');
        if (!btn) return;
        const d = btn.dataset.days;
        salesSetPeriod(d === 'all' ? 'all' : Number(d));
        salesMarkPreset(d);
        lastSalesJson = '';
        loadRecentSales();
    });
}
[salesFromEl, salesToEl].forEach((el) => el && el.addEventListener('change', () => {
    salesMarkPreset(null);
    lastSalesJson = '';
    loadRecentSales();
}));
// типове вікно — 45 днів
if (salesFromEl && salesToEl) { salesSetPeriod(45); salesMarkPreset(45); }

// авто-оновлення списку операцій — щоб бачити видачі з телефона / інших
// пристроїв без перезавантаження сторінки (lastSalesJson не перемальовує,
// якщо нічого не змінилось, тож без миготіння)
setInterval(() => {
    if (document.hidden) return;                          // вкладка неактивна
    const m = document.getElementById('editSaleModal');
    if (m && !m.hidden) return;                           // не заважати редагуванню
    loadRecentSales();
}, 15000);

recentBody.addEventListener('click', async (e) => {
    const editBtn = e.target.closest('[data-edit-sale]');
    if (editBtn) { openEditSale(editBtn.dataset.editSale); return; }
    const btn = e.target.closest('[data-undo]');
    if (!btn) return;
    const saleNo = btn.dataset.undo;
    if (!await confirmAction(`Відмінити операцію ${formatSaleNo(saleNo)}? Товар повернеться на склад.`)) return;
    const r = await apiSend('/api/sales/' + encodeURIComponent(saleNo), 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast(`Операцію ${formatSaleNo(saleNo)} відмінено`, 'success');
    loadRecentSales();
    loadProductsIndex();
});

/* ---------- редагування видачі за номером ---------- */

const editSaleModal   = document.getElementById('editSaleModal');
const editSaleNoEl    = document.getElementById('editSaleNo');
const editSaleInfo    = document.getElementById('editSaleInfo');
const editSaleTable   = document.getElementById('editSaleTable');
const editSaleBody    = document.querySelector('#editSaleTable tbody');
const editSaleNoteInp = document.getElementById('editSaleNoteInp');
const editSaleDateInp = document.getElementById('editSaleDateInp');
const editSaleDateLabel = document.getElementById('editSaleDateLabel');
const editSaleGroup = document.getElementById('editSaleGroup');           // група операції (корови/молодняк)
const editSaleGroupField = document.getElementById('editSaleGroupField');
let editSaleCurrent = null;   // {sale_no, positions:[...]}

/* Блоки для обраної в модалі групи (як на видачі) */
function editBlocksForGroup() {
    const k = editSaleGroup ? editSaleGroup.value : '';
    if (!k) return blocksList;
    return blocksList.filter((b) => (b.herd_kind || '') === k);
}
/* Перемалювати рядки позицій. strict=false (відкриття) — лишаємо поточний блок
   видимим навіть з іншої групи; strict=true (зміна групи) — лише блоки нової групи. */
function renderEditSaleRows(strict) {
    if (!editSaleCurrent || !editSaleBody) return;
    const base = editBlocksForGroup();
    editSaleBody.innerHTML = editSaleCurrent.positions.map((p, i) => {
        let rowBlocks = base;
        if (!strict && p.block_id && !base.some((b) => String(b.id) === String(p.block_id))) {
            rowBlocks = base.concat(blocksList.filter((b) => String(b.id) === String(p.block_id)));
        }
        return `
            <tr data-i="${i}">
                <td>${escapeHtml(p.name)}<div class="text-mute" style="font-size:11px;">${escapeHtml(p.barcode || '')}</div></td>
                <td class="num"><input type="number" class="es-qty" value="${p.qty}" min="0" step="any" style="width:80px;text-align:right;"></td>
                <td class="es-dest"><select class="es-block ref-select">${optionsHtml(rowBlocks, p.block_id, '— блок —')}</select></td>
                <td class="es-dest"><select class="es-recipient ref-select">${optionsHtml(recipientsList, p.recipient_id, '— не вказано —')}</select></td>
            </tr>`;
    }).join('');
}
/* Запамʼятати поточні вибори (блок/отримувач) перед перемальовуванням */
function snapshotEditRows() {
    if (!editSaleCurrent || !editSaleBody) return;
    editSaleBody.querySelectorAll('tr[data-i]').forEach((tr) => {
        const i = parseInt(tr.dataset.i, 10);
        const p = editSaleCurrent.positions[i];
        if (!p) return;
        const bs = tr.querySelector('.es-block'), rs = tr.querySelector('.es-recipient');
        if (bs) p.block_id = bs.value;
        if (rs) p.recipient_id = rs.value;
    });
}
if (editSaleGroup) {
    editSaleGroup.addEventListener('change', () => {
        snapshotEditRows();          // зберегти отримувачів
        renderEditSaleRows(true);    // блоки під нову групу; чужі — скидаються
    });
}

async function openEditSale(saleNo) {
    const r = await apiGet('/api/sales/' + encodeURIComponent(saleNo) + '/edit');
    if (!r.ok) { toast(r.error || 'Не вдалося завантажити операцію', 'error'); return; }
    const sale = r.sale;
    editSaleCurrent = sale;
    editSaleNoEl.textContent = formatSaleNo(sale.sale_no, sale.move_type);
    const lbl = opLabel[sale.move_type] ? opLabel[sale.move_type].text : sale.move_type;
    const isOut = sale.move_type === 'OUT';
    editSaleInfo.textContent = isOut
        ? 'Видача: можна змінити кількість, дату, блок, отримувача та примітку. Зміна кількості коригує залишок складу.'
        : 'Списання: можна змінити кількість, дату та примітку. Зміна кількості коригує залишок складу.';
    if (editSaleDateLabel) editSaleDateLabel.textContent = isOut ? 'Дата видачі' : 'Дата списання';
    if (editSaleDateInp) {
        editSaleDateInp.value = (sale.created_at || '').slice(0, 10);
        editSaleDateInp.max = todayISO();
    }
    editSaleTable.classList.toggle('hide-dest', !isOut);
    // Група операції (одна на всю операцію) = herd_kind першого блоку з cow/young.
    if (editSaleGroupField) editSaleGroupField.style.display = isOut ? '' : 'none';
    if (editSaleGroup) {
        let g = '';
        for (const p of sale.positions) {
            if (['cow', 'young', 'pig'].includes(p.herd_kind)) { g = p.herd_kind; break; }
        }
        editSaleGroup.value = g || 'cow';
    }
    renderEditSaleRows(false);
    editSaleNoteInp.value = sale.note || '';
    openModal('editSaleModal');
}

document.getElementById('saveEditSaleBtn').addEventListener('click', async () => {
    if (!editSaleCurrent) return;
    const positions = [];
    editSaleBody.querySelectorAll('tr[data-i]').forEach((tr) => {
        const i = parseInt(tr.dataset.i, 10);
        const p = editSaleCurrent.positions[i];
        const blockSel = tr.querySelector('.es-block');
        const recSel = tr.querySelector('.es-recipient');
        const qtyInp = tr.querySelector('.es-qty');
        positions.push({
            product_id: p.product_id,
            block_id: blockSel ? blockSel.value : '',
            recipient_id: recSel ? recSel.value : '',
            qty: qtyInp ? qtyInp.value : undefined,
        });
    });
    const r = await apiSend('/api/sales/' + encodeURIComponent(editSaleCurrent.sale_no) + '/edit',
        'POST', { positions, note: editSaleNoteInp.value,
                  date: editSaleDateInp ? editSaleDateInp.value : '' });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Зміни збережено', 'success');
    closeModal('editSaleModal');
    editSaleCurrent = null;
    lastSalesJson = '';
    loadRecentSales();
    loadProductsIndex();        // залишок міг змінитись (редагування кількості)
});

/* ---------- розсувний роздільник між панелями ---------- */

const SPLIT_KEY = 'vetpharm:sale_split';

function initSplitter() {
    const splitter = document.getElementById('saleSplitter');
    const layout = splitter && splitter.closest('.sale-layout');
    if (!splitter || !layout) return;

    const saved = parseFloat(localStorage.getItem(SPLIT_KEY));
    if (isFinite(saved) && saved >= 20 && saved <= 75) {
        layout.style.setProperty('--sale-left', saved + '%');
    }

    splitter.addEventListener('mousedown', (ev) => {
        ev.preventDefault();
        splitter.classList.add('dragging');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';

        const onMove = (m) => {
            const rect = layout.getBoundingClientRect();
            let pct = ((m.clientX - rect.left) / rect.width) * 100;
            pct = Math.max(20, Math.min(75, pct));
            layout.style.setProperty('--sale-left', pct + '%');
        };
        const onUp = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            splitter.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            const cur = layout.style.getPropertyValue('--sale-left');
            if (cur) localStorage.setItem(SPLIT_KEY, parseFloat(cur));
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    });

    // подвійний клік — скидання до типового співвідношення
    splitter.addEventListener('dblclick', () => {
        layout.style.removeProperty('--sale-left');
        localStorage.removeItem(SPLIT_KEY);
    });
}

/* ---------- авто-оновлення ---------- */

let salesPollTimer = null;
function startSalesPoll() {
    if (salesPollTimer) return;
    salesPollTimer = setInterval(loadRecentSales, 5000);
}
function stopSalesPoll() {
    if (salesPollTimer) { clearInterval(salesPollTimer); salesPollTimer = null; }
}
document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopSalesPoll();
    else { loadRecentSales(); startSalesPoll(); }
});

/* СПІЛЬНИЙ кошик: підтягувати скани з телефона / інших пристроїв */
setInterval(async () => {
    if (document.hidden) return;
    if (Date.now() - lastLocalChange < 3500) return;   // щойно міняли тут — не чіпаємо
    const m = document.getElementById('editSaleModal');
    if (m && !m.hidden) return;
    const r = await apiGet('/api/cart');
    if (!r || !r.ok || !Array.isArray(r.cart)) return;
    if (JSON.stringify(r.cart) !== JSON.stringify(cart)) {
        cart = r.cart;
        refreshCartStock();
        renderCart();
    }
}, 3000);

/* ---------- init ---------- */

document.addEventListener('DOMContentLoaded', async () => {
    setMode('OUT');
    await Promise.all([loadBlocks(), loadRecipients()]);
    renderCart();
    initSplitter();
    // дозволяємо тягнути ширину стовпців списку «До видачі»
    makeColumnsResizable('cartTable', 'vetpharm:cart_cols');
    loadRecentSales();
    startSalesPoll();
    loadProductsIndex().then(restoreCart);
    saleSearch.focus();
});

/* «Годівля з Profeed» прибрано: годівля списується автоматично на сторінці
   «Рух годівлі» (авто щодня + кнопка «Зафіксувати списання»). */
