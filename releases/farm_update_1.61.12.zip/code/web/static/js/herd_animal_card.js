/* Картка тварини: параметри плитками за секціями + історія подій. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
const AID = window.ANIMAL_ID;
let PARAMS = [], CATS = {};
let CONFIG = false;   // режим налаштування показу полів

// кольори секцій (як у Подіях); невідомі — з палітри по черзі
const SEC_COLOR = {
    'Основне': '#2f5fb0', 'Відтворення': '#8a4fd0', 'Родовід': '#0e9aa7',
    "Здоров'я": '#1aa86b', 'Продуктивність': '#d08700',
};
const SEC_PALETTE = ['#2f5fb0', '#8a4fd0', '#0e9aa7', '#1aa86b', '#d08700', '#c0392b', '#5b7083', '#c2185b'];
function hexRgba(hex, a) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
// приховані ключі параметрів (спільно для всіх тварин)
const HIDE_KEY = 'farm:herd:cardHidden';
let HIDDEN = new Set();
try { HIDDEN = new Set(JSON.parse(localStorage.getItem(HIDE_KEY) || '[]')); } catch (e) { /* ignore */ }
function saveHidden() { localStorage.setItem(HIDE_KEY, JSON.stringify([...HIDDEN])); }

// Код країни для ідентифікаційного номера (вушна бирка). За замовч. UA.
const UIN_COUNTRIES = [
    ['UA', 'Україна'], ['DE', 'Німеччина'], ['FR', 'Франція'], ['DK', 'Данія'],
    ['NL', 'Нідерланди'], ['PL', 'Польща'], ['CZ', 'Чехія'], ['HU', 'Угорщина'],
    ['AT', 'Австрія'], ['SK', 'Словаччина'], ['IE', 'Ірландія'], ['GB', 'Великобританія'],
    ['IT', 'Італія'], ['ES', 'Іспанія'], ['US', 'США'], ['CA', 'Канада'],
];

async function load() {
    const [a, p] = await Promise.all([
        apiGet('/api/herd/animals/' + AID),
        apiGet('/api/herd/animals/' + AID + '/params'),
    ]);
    if (a.ok) renderHeader(a);
    if (p.ok) { PARAMS = p.params || []; renderTiles(); }
}

/* ---------- шапка ---------- */
function renderHeader(a) {
    $('acName').textContent = `${a.tag}${a.name ? ' «' + a.name + '»' : ''}`;
    const chip = (k, v) => v ? `<span class="ac-chip">${k}: <b>${escapeHtml(String(v))}</b></span>` : '';
    $('acChips').innerHTML =
        chip('Статус', a.status_label) +
        chip('Секція', a.group_name) +
        chip('Стать', a.sex === 'M' ? 'Чоловіча' : 'Жіноча') +
        chip('Вік, міс', a.age_months == null ? '' : a.age_months) +
        chip('Народження', a.birth_date) +
        chip('Лактація', a.lactation_no || '');
    renderEvents(a.events || []);
}

function renderEvents(evs) {
    $('acEvCount').textContent = evs.length ? `· ${evs.length}` : '';
    $('acEvents').innerHTML = evs.length ? evs.map((e) => `
        <div class="ac-ev-row">
            <span class="ac-ev-date">${escapeHtml((e.event_date || '').slice(0, 10))}</span>
            <span class="ac-ev-type">${escapeHtml(e.event_type || '')}</span>
            <span class="ac-ev-body">${escapeHtml([e.ref_tag, e.details].filter(Boolean).join(' · '))}</span>
        </div>`).join('') : '<p class="text-mute" style="padding:8px 0;">Подій ще немає.</p>';
}

/* ---------- плитки параметрів ---------- */
function valText(p) {
    if (p.value === '' || p.value == null) return '';
    if (p.dtype === 'bool') return p.value === '1' || p.value === 1 ? 'Так' : 'Ні';
    if ((p.dtype === 'cod' || p.dtype === 'code') && p.value_label) return `${p.value} — ${p.value_label}`;
    return String(p.value);
}
function renderTiles() {
    const bySec = {}; const order = [];
    PARAMS.forEach((p) => {
        if (!bySec[p.section]) { bySec[p.section] = []; order.push(p.section); }
        bySec[p.section].push(p);
    });
    const hint = CONFIG
        ? '<p class="ac-cfg-hint">Режим налаштування: познач, які параметри показувати. Натисни «⚙ Поля» ще раз, щоб завершити.</p>'
        : '';
    const html = order.map((sec, i) => {
        const color = SEC_COLOR[sec] || SEC_PALETTE[i % SEC_PALETTE.length];
        const list = CONFIG ? bySec[sec] : bySec[sec].filter((p) => !HIDDEN.has(p.key));
        if (!list.length) return '';
        const rows = list.map((p) => {
            const hidden = HIDDEN.has(p.key);
            if (CONFIG) {
                return `<div class="ac-row cfg ${hidden ? 'hiddenp' : ''}" data-cfg="${escapeHtml(p.key)}">
                    <input type="checkbox" class="ac-vis" ${hidden ? '' : 'checked'}>
                    <span class="k">${escapeHtml(p.label)}</span>
                </div>`;
            }
            const txt = valText(p);
            const cls = p.computed ? 'auto' : (txt ? '' : 'empty');
            const unit = (txt && p.unit) ? `<span class="u">${escapeHtml(p.unit)}</span>` : '';
            const disp = txt ? escapeHtml(txt) + unit : (p.computed ? '—' : 'вписати');
            return `<div class="ac-row">
                <span class="k">${escapeHtml(p.label)}</span>
                <span class="v ${cls}" data-key="${escapeHtml(p.key)}">${disp}</span>
            </div>`;
        }).join('');
        return `<div class="ac-tile" style="--sec:${color};--sec-bg:${hexRgba(color, 0.10)}">
            <div class="ac-tile-head">${escapeHtml(sec)}</div>
            <div class="ac-tile-body">${rows}</div></div>`;
    }).join('');
    $('acParams').innerHTML = hint + html;
}

/* ---------- інлайн-редагування ---------- */
function editControl(p) {
    const opts = p.options || [];
    if (opts.length && (p.dtype === 'cod' || p.dtype === 'code')) {
        return `<select class="ac-edit"><option value="">—</option>${opts.map((o) =>
            `<option value="${escapeHtml(o.c)}"${String(o.c) === String(p.value) ? ' selected' : ''}>${escapeHtml(o.c)} — ${escapeHtml(o.l)}</option>`).join('')}</select>`;
    }
    if (opts.length) {   // list / group (масив рядків)
        return `<select class="ac-edit"><option value="">—</option>${opts.map((o) =>
            `<option value="${escapeHtml(o)}"${String(o) === String(p.value) ? ' selected' : ''}>${escapeHtml(o)}</option>`).join('')}</select>`;
    }
    if (p.dtype === 'bool') {
        return `<select class="ac-edit"><option value="">—</option>
            <option value="1"${p.value == 1 ? ' selected' : ''}>Так</option>
            <option value="0"${(p.value === '0' || p.value === 0) ? ' selected' : ''}>Ні</option></select>`;
    }
    const type = p.dtype === 'date' ? 'date' : ((p.dtype === 'int' || p.dtype === 'float') ? 'number' : 'text');
    const step = p.dtype === 'float' ? ' step="0.01"' : '';
    return `<input type="${type}"${step} class="ac-edit" value="${escapeHtml(p.value || '')}">`;
}
async function saveParam(cell, key, val) {
    const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key, value: val });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); cell.innerHTML = cell.dataset.orig; return; }
    toast('Збережено', 'success');
    load();
}
/* UIN — окреме вікно (країна + цифри) */
function openUin(p) {
    const m = String(p.value || '').match(/^([A-Za-z]*)(.*)$/);
    let cc = (m && m[1] ? m[1] : 'UA').toUpperCase();
    const digits = (m ? m[2] : '').replace(/\D/g, '');
    let list = UIN_COUNTRIES.slice();
    if (cc && !list.some((c) => c[0] === cc)) list.unshift([cc, cc]);
    $('uinCC').innerHTML = list.map((c) =>
        `<option value="${c[0]}"${c[0] === cc ? ' selected' : ''}>${c[0]} — ${escapeHtml(c[1])}</option>`).join('');
    $('uinNum').value = digits;
    updateUinPreview();
    $('uinModal').hidden = false;
    $('uinNum').focus();
}
function updateUinPreview() {
    const num = ($('uinNum').value || '').replace(/\D/g, '');
    $('uinPreview').textContent = ($('uinCC').value || 'UA') + (num || '…');
}
async function saveUin() {
    const val = ($('uinCC').value || 'UA') + ($('uinNum').value || '').replace(/\D/g, '');
    const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key: 'uin', value: val });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('uinModal').hidden = true;
    toast('Збережено', 'success');
    load();
}

function startEdit(cell) {
    const key = cell.dataset.key;
    const p = PARAMS.find((x) => x.key === key);
    if (!p || p.computed) return;
    if (key === 'uin') { openUin(p); return; }
    cell.dataset.orig = cell.innerHTML;
    cell.innerHTML = editControl(p);
    const ctl = cell.querySelector('.ac-edit');
    ctl.focus();
    let done = false;
    const save = async () => {
        if (done) return; done = true;
        const val = ctl.value;
        const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key, value: val });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); cell.innerHTML = cell.dataset.orig; return; }
        toast('Збережено', 'success');
        load();   // перечитати (обчислювані могли змінитись)
    };
    ctl.addEventListener('blur', save);
    ctl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); ctl.blur(); }
        else if (e.key === 'Escape') { done = true; cell.innerHTML = cell.dataset.orig; }
    });
    if (ctl.tagName === 'SELECT') ctl.addEventListener('change', save);
}

$('acParams').addEventListener('click', (e) => {
    if (CONFIG) {                       // режим налаштування — перемикаємо показ
        const row = e.target.closest('.ac-row.cfg'); if (!row) return;
        const key = row.dataset.cfg;
        if (HIDDEN.has(key)) HIDDEN.delete(key); else HIDDEN.add(key);
        saveHidden(); renderTiles();
        return;
    }
    const cell = e.target.closest('.v'); if (!cell || cell.classList.contains('auto')) return;
    if (cell.querySelector('.ac-edit')) return;
    startEdit(cell);
});
$('acCfgBtn').addEventListener('click', () => {
    CONFIG = !CONFIG;
    $('acCfgBtn').classList.toggle('btn-primary', CONFIG);
    renderTiles();
});

// модал UIN
$('uinNum').addEventListener('input', () => {
    $('uinNum').value = $('uinNum').value.replace(/\D/g, ''); updateUinPreview();
});
$('uinNum').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveUin(); } });
$('uinCC').addEventListener('change', updateUinPreview);
$('uinSave').addEventListener('click', saveUin);
document.querySelectorAll('[data-uin-close]').forEach((el) =>
    el.addEventListener('click', () => { $('uinModal').hidden = true; }));

if ($('acParams')) load();
})();
