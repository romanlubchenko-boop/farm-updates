/* ============ Журнал дій користувачів (audit trail) ============ */

const auTbody = document.querySelector('#auTable tbody');
const auCount = document.getElementById('auCount');
const auFromEl = document.getElementById('auFrom');
const auToEl = document.getElementById('auTo');
const auSearchEl = document.getElementById('auSearch');

function auFmtDate(s) {
    if (!s || s.length < 16) return s || '';
    return s.slice(8, 10) + '.' + s.slice(5, 7) + '.' + s.slice(0, 4) + ' ' + s.slice(11, 16);
}

function auQty(v) {
    if (v == null) return '';
    const n = Number(v);
    return Number.isFinite(n) ? n.toLocaleString('uk-UA') : v;
}

function auISO(d) { return d.toISOString().slice(0, 10); }

// Встановити період: days=0 → сьогодні, N → останні N днів, 'all' → без дат
function auSetPeriod(days) {
    if (days === 'all') {
        auFromEl.value = '';
        auToEl.value = '';
        return;
    }
    const today = new Date();
    auToEl.value = auISO(today);
    const from = new Date();
    from.setDate(today.getDate() - Number(days));
    auFromEl.value = auISO(from);
}

function auMarkPreset(days) {
    document.querySelectorAll('#auPresets .btn').forEach(b =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));
}

async function auLoadFilters() {
    const r = await apiGet('/api/audit/filters');
    if (!r.ok) return;
    const us = document.getElementById('auUser');
    (r.users || []).forEach(u => {
        const o = document.createElement('option');
        o.value = u.id; o.textContent = u.username;
        us.appendChild(o);
    });
    const bs = document.getElementById('auBranch');
    (r.branches || []).forEach(b => {
        const o = document.createElement('option');
        o.value = b.code; o.textContent = b.label;
        bs.appendChild(o);
    });
}

async function auLoad() {
    const q = new URLSearchParams({
        from: auFromEl.value,
        to: auToEl.value,
        user: document.getElementById('auUser').value,
        branch: document.getElementById('auBranch').value,
        type: document.getElementById('auType').value,
        q: auSearchEl.value.trim(),
    });
    auTbody.innerHTML = '<tr><td colspan="7" class="empty">Завантаження…</td></tr>';
    const r = await apiGet('/api/audit?' + q.toString());
    if (!r.ok) {
        auTbody.innerHTML = '<tr><td colspan="7" class="empty">Помилка завантаження</td></tr>';
        return;
    }
    const items = r.items || [];
    auCount.textContent = items.length
        ? (r.truncated ? ('показано ' + items.length + ' з ' + r.total)
                       : (r.total + ' записів'))
        : '';
    if (!items.length) {
        auTbody.innerHTML = '<tr><td colspan="7" class="empty">Немає записів за заданими умовами</td></tr>';
        return;
    }
    auTbody.innerHTML = items.map(it => `
        <tr>
            <td>${escapeHtml(auFmtDate(it.created_at))}</td>
            <td>${escapeHtml(it.user_login || '—')}</td>
            <td>${escapeHtml(it.branch || '')}</td>
            <td><span class="au-badge au-${it.op_type}">${escapeHtml(it.op_label)}</span></td>
            <td>${escapeHtml(it.product || '')}</td>
            <td class="num">${auQty(it.qty)}</td>
            <td class="au-detail">${escapeHtml(it.detail || '')}</td>
        </tr>`).join('');
}

document.getElementById('auApplyBtn').addEventListener('click', auLoad);
['auUser', 'auBranch', 'auType'].forEach(id =>
    document.getElementById(id).addEventListener('change', auLoad));

// Пресети періоду
document.getElementById('auPresets').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-days]');
    if (!btn) return;
    const d = btn.dataset.days;
    auSetPeriod(d === 'all' ? 'all' : Number(d));
    auMarkPreset(d);
    auLoad();
});

// Пошук із невеликою затримкою + ручне змінення дат знімає підсвітку пресета
let auSearchTimer = null;
auSearchEl.addEventListener('input', () => {
    clearTimeout(auSearchTimer);
    auSearchTimer = setTimeout(auLoad, 350);
});
[auFromEl, auToEl].forEach(el => el.addEventListener('change', () => {
    auMarkPreset(null);
    auLoad();
}));

// Старт: типове вікно 45 днів
(async () => {
    await auLoadFilters();
    auSetPeriod(45);
    auMarkPreset(45);
    auLoad();
})();
