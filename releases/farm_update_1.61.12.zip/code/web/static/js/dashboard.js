/* ===== Дашборд: KPI + «Найбільше видавали» з вибором колонок ===== */

function tsDate(s) {
    if (!s || s.length < 10) return '';
    return s.slice(8, 10) + '.' + s.slice(5, 7) + '.' + s.slice(0, 4);
}

// Опис колонок таблиці топ-видач. always:true — обовʼязкова (не вимикається).
const TS_COLUMNS = [
    { key: 'name',    label: 'Товар',         always: true,  render: r => escapeHtml(r.name) },
    { key: 'code',    label: 'Код',           cls: 'text-mute', render: r => escapeHtml(r.code || '') },
    { key: 'barcode', label: 'Штрихкод',      cls: 'text-mute', render: r => escapeHtml(r.barcode || '') },
    { key: 'unit',    label: 'Од.',           cls: 'text-mute', render: r => escapeHtml(r.unit || '') },
    { key: 'qty',     label: 'К-сть',         num: true, render: r => fmtNum(r.qty) },
    { key: 'revenue', label: 'Сума ₴',        num: true, render: r => fmtMoney(r.revenue) },
    { key: 'avg',     label: 'Сер. ціна ₴',   num: true, render: r => fmtMoney(r.qty ? r.revenue / r.qty : 0) },
    { key: 'ops',     label: 'Операцій',      num: true, render: r => fmtNum(r.ops || 0) },
    { key: 'last',    label: 'Остання видача', cls: 'text-mute', render: r => tsDate(r.last_date) },
];

const TS_DEFAULT = ['name', 'barcode', 'qty', 'revenue'];
const TS_STORE = 'dash:ts_cols';

function tsActive() {
    let set;
    try { set = JSON.parse(localStorage.getItem(TS_STORE)); } catch (e) { set = null; }
    if (!Array.isArray(set) || !set.length) set = TS_DEFAULT.slice();
    if (!set.includes('name')) set.unshift('name');
    return set;
}

function tsSave(keys) { localStorage.setItem(TS_STORE, JSON.stringify(keys)); }

let TS_DATA = [];

function renderTopSellers() {
    const active = tsActive();
    const cols = TS_COLUMNS.filter(c => active.includes(c.key));
    const head = document.getElementById('tsHead');
    head.innerHTML = cols.map(c => `<th${c.num ? ' class="num"' : ''}>${c.label}</th>`).join('');

    const body = document.querySelector('#topSellersTable tbody');
    if (!TS_DATA.length) {
        body.innerHTML = `<tr><td colspan="${cols.length}" class="empty">Видач за місяць ще не було</td></tr>`;
        return;
    }
    body.innerHTML = TS_DATA.map(r => '<tr>' + cols.map(c =>
        `<td${c.num ? ' class="num"' : (c.cls ? ` class="${c.cls}"` : '')}>${c.render(r)}</td>`
    ).join('') + '</tr>').join('');
}

function buildColsMenu() {
    const menu = document.getElementById('tsColsMenu');
    const active = tsActive();
    menu.innerHTML = TS_COLUMNS.map(c => {
        const checked = active.includes(c.key) ? 'checked' : '';
        const locked = c.always ? 'is-locked' : '';
        const dis = c.always ? 'disabled' : '';
        return `<label class="${locked}">
            <input type="checkbox" value="${c.key}" ${checked} ${dis}> ${c.label}
        </label>`;
    }).join('');

    menu.querySelectorAll('input:not([disabled])').forEach(inp => {
        inp.addEventListener('change', () => {
            // зберігаємо у порядку оголошення колонок
            const sel = TS_COLUMNS
                .filter(c => c.always ||
                    menu.querySelector(`input[value="${c.key}"]`).checked)
                .map(c => c.key);
            tsSave(sel);
            renderTopSellers();
        });
    });
}

(function setupColsButton() {
    const btn = document.getElementById('tsColsBtn');
    const menu = document.getElementById('tsColsMenu');
    if (!btn || !menu) return;
    buildColsMenu();
    function placeMenu() {
        const r = btn.getBoundingClientRect();
        menu.style.top = (r.bottom + 6) + 'px';
        menu.style.right = (window.innerWidth - r.right) + 'px';
        menu.style.left = 'auto';
    }
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (menu.hidden) { placeMenu(); menu.hidden = false; }
        else menu.hidden = true;
    });
    window.addEventListener('resize', () => { if (!menu.hidden) placeMenu(); });
    document.addEventListener('click', (e) => {
        if (!menu.hidden && !menu.contains(e.target) && e.target !== btn) menu.hidden = true;
    });
})();

async function loadDashboard() {
    const res = await apiGet('/api/dashboard');
    if (!res.ok) { toast('Не вдалося завантажити статистику', 'error'); return; }

    document.querySelectorAll('[data-stat]').forEach((el) => {
        const key = el.dataset.stat;
        if (key.includes('sum')) { el.textContent = fmtMoney(res[key]); return; }
        // Кількості на Огляді бувають шестизначні — групуємо розряди,
        // інакше «1988700» читається важко.
        const n = Number(res[key] || 0);
        el.textContent = n.toLocaleString('uk-UA', {
            minimumFractionDigits: 0,
            maximumFractionDigits: Number.isInteger(n) ? 0 : 2,
        });
    });

    TS_DATA = res.top_sellers || [];
    renderTopSellers();
}

document.addEventListener('DOMContentLoaded', loadDashboard);
