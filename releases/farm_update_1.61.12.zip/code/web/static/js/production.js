/* Виробництво комбікормів.
   Рецепт — лише підказка: кількості підставляються пропорційно фактичному
   випуску, але їх можна змінювати, додавати й прибирати компоненти.
   Собівартість рахується за середніми цінами залишків (орієнтовно); при
   проведенні сервер перерахує її за реальними партіями FIFO. */

let recipe = { lines: [], batch_kg: 0 };   // поточний рецепт
let allFeeds = [];                          // усі корми — для ручного додавання
let recipesCache = [];                      // рецепти — для редактора й зразків
let recEdit = { product_id: null, lines: [] };

/* Локальні скорочення. Імена навмисно з префіксом prod — глобальний простір
   спільний для всіх скриптів сторінки, а повторне оголошення const валить
   увесь файл ще до виконання (IS_ADMIN уже є в app.js). */
const $ = (id) => document.getElementById(id);
// Розбір числа з екрана: прибираємо пробіли-розділювачі розрядів (у т.ч.
// нерозривні, які вставляє toLocaleString) і приймаємо кому як десяткову.
const num = (v) => {
    const n = parseFloat(String(v).replace(/[\s\u00a0\u202f]/g, '').replace(',', '.'));
    return Number.isFinite(n) ? n : 0;
};
const fmt = (n, d = 2) => n.toLocaleString('uk-UA', { minimumFractionDigits: d, maximumFractionDigits: d });

/* apiGet кидає виняток, якщо сервер відповів не-JSON (напр. 404 HTML, коли
   застосунок ще не перезапущено після оновлення). Тоді таблиця мовчки
   залишалась на «Завантаження…». Тут ловимо це й показуємо причину. */
async function safeGet(url) {
    try {
        const r = await apiGet(url);
        return r && typeof r === 'object' ? r : { ok: false, error: 'Порожня відповідь' };
    } catch (e) {
        return { ok: false, error: 'Сервер не відповів на ' + url
                 + '. Найчастіше це означає, що застосунок треба перезапустити.' };
    }
}

function tableError(bodyId, cols, msg) {
    $(bodyId).innerHTML = `<tr class="empty"><td colspan="${cols}">`
        + `<span class="is-short">${escapeHtml(msg)}</span></td></tr>`;
}

/* ---------- чернетка замісу ----------
   Заміс набирають довго: подивитися залишки, зазирнути в прихід, порадитися.
   Тому незавершену форму тримаємо в браузері — повернувся на сторінку й
   продовжив із того ж місця, без жодних повідомлень. Форма просто така,
   якою її лишили. Очищується сама лише після проведення виробництва.
   Чернетка своя для кожної гілки складу. */
const DRAFT_KEY = 'farm:prod_draft:' + (window.API_BASE || '');

function saveDraft() {
    const comps = [];
    $('prodBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const inp = tr.querySelector('.c-qty');
        comps.push({ product_id: +tr.dataset.pid, qty: inp.value,
                     touched: inp.dataset.touched === '1' });
    });
    const draft = {
        product_id: $('prodProduct').value,
        qty_out: $('prodQty').value,
        prod_date: $('prodDate').value,
        note: $('prodNote').value,
        comps,
        saved_at: Date.now(),
    };
    // порожню форму не зберігаємо — інакше чернетка «липне» без потреби
    if (!draft.product_id && !draft.qty_out && !comps.length) { clearDraft(); return; }
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify(draft)); } catch (e) { /* ignore */ }
}

function clearDraft() {
    try { localStorage.removeItem(DRAFT_KEY); } catch (e) { /* ignore */ }
}

async function restoreDraft() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null'); } catch (e) { d = null; }
    if (!d || !d.product_id) return false;

    $('prodProduct').value = d.product_id;
    if (!$('prodProduct').value) { clearDraft(); return false; }  // КК уже видалено

    const rec = await safeGet('/api/feed/recipe/' + d.product_id);
    if (!rec.ok) return false;
    recipe = rec;
    $('prodDate').value = d.prod_date || $('prodDate').value;
    $('prodQty').value = d.qty_out ? fmtQty(num(d.qty_out)) : '';
    $('prodNote').value = d.note || '';
    render();

    // повертаємо саме ті кількості, які були на екрані
    const byId = {};
    for (const c of d.comps || []) byId[c.product_id] = c;
    $('prodBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const c = byId[tr.dataset.pid];
        if (!c) { tr.remove(); return; }
        const inp = tr.querySelector('.c-qty');
        inp.value = c.qty;
        inp.dataset.touched = c.touched ? '1' : '0';
    });
    totals();
    return true;
}

document.addEventListener('DOMContentLoaded', async () => {
    $('prodDate').value = new Date().toISOString().slice(0, 10);
    await Promise.all([loadCombifeeds(), loadFeeds(), loadLog(), loadRecipes()]);
    await restoreDraft();
    pfInit();
    // будь-яка зміна у формі оновлює чернетку
    ['prodProduct', 'prodQty', 'prodDate', 'prodNote'].forEach((id) => {
        $(id).addEventListener('change', saveDraft);
        $(id).addEventListener('input', saveDraft);
    });
    $('prodBody').addEventListener('input', saveDraft);
    $('prodBody').addEventListener('click', () => setTimeout(saveDraft, 0));
    $('addCompSel').addEventListener('change', () => setTimeout(saveDraft, 0));
    window.addEventListener('beforeunload', saveDraft);

    // Згортання складу замісу. Стан запамʼятовуємо — хто працює з готовими
    // рецептами, тримає склад згорнутим і бачить лише шапку документа.
    const COLLAPSE_KEY = 'farm:prod_collapsed';
    const applyCollapse = (on) => {
        $('docBody').hidden = on;
        $('docToggle').classList.toggle('is-collapsed', on);
        $('docToggle').title = on ? 'Показати склад замісу' : 'Сховати склад замісу';
    };
    applyCollapse(localStorage.getItem(COLLAPSE_KEY) === '1');
    // Ширини колонок можна тягнути мишкою; налаштування зберігається.
    // Поки склад згорнутий, таблиця прихована й виміряти її неможливо —
    // тому пробуємо ще раз щоразу після розгортання.
    makeColumnsResizable('prodTable', 'farm:prod_cols_w');
    // Поля шапки документа теж тягнуться по ширині
    makeFieldsResizable('docHead', 'farm:prod_head_w', '.doc-f');

    $('docToggle').addEventListener('click', () => {
        const on = !$('docBody').hidden;
        applyCollapse(on);
        if (!on) makeColumnsResizable('prodTable', 'farm:prod_cols_w');
        try { localStorage.setItem(COLLAPSE_KEY, on ? '1' : '0'); } catch (e) { /* ignore */ }
    });

    // Згортання ВСІЄЇ панелі «Новий заміс» (шапка документа + склад). Ставимо
    // після applyCollapse, щоб панельний стан був авторитетним. При розгортанні
    // склад відновлюється за власним станом (COLLAPSE_KEY).
    const PANEL_KEY = 'farm:prod_collapsed_panel';
    const pTog = $('prodPanelToggle');
    if (pTog) {
        const applyPanel = (on) => {
            $('docHead').hidden = on;
            $('docBody').hidden = on || (localStorage.getItem(COLLAPSE_KEY) === '1');
            pTog.classList.toggle('is-collapsed', on);
            pTog.title = on ? 'Розгорнути панель' : 'Згорнути панель';
        };
        applyPanel(localStorage.getItem(PANEL_KEY) === '1');
        pTog.addEventListener('click', () => {
            const on = !$('docHead').hidden;     // шапка видима → згортаємо
            applyPanel(on);
            if (!on) makeColumnsResizable('prodTable', 'farm:prod_cols_w');
            try { localStorage.setItem(PANEL_KEY, on ? '1' : '0'); } catch (e) { /* ignore */ }
        });
    }
});

async function loadCombifeeds() {
    const r = await safeGet('/api/feed/combifeeds');
    if (!r.ok) return;
    const sel = $('prodProduct');
    for (const it of r.items || []) {
        const o = document.createElement('option');
        o.value = it.id; o.textContent = it.name;
        sel.appendChild(o);
    }
}

async function loadFeeds() {
    const r = await safeGet('/api/products');
    if (r.ok) allFeeds = r.items || [];
}

$('prodProduct').addEventListener('change', async () => {
    const pid = $('prodProduct').value;
    if (!pid) { recipe = { lines: [], batch_kg: 0 }; render(); return; }
    const r = await apiGet('/api/feed/recipe/' + pid);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    recipe = r;
    if (!$('prodQty').value && recipe.batch_kg) $('prodQty').value = fmtQty(recipe.batch_kg);
    render();
});

/* Поле «Вироблено, кг» — звичайне число з групуванням розрядів (1 000)
   і комою як десятковим знаком. Стрілочки-лічильник тут зайві: кількість
   набирають з ваги, а не клацають по одиниці. Групування показуємо, коли
   поле не в фокусі; під час набору не заважаємо — лише чистимо зайве. */
function fmtQty(n) {
    if (!n) return '';
    return n.toLocaleString('uk-UA', { minimumFractionDigits: 0,
                                       maximumFractionDigits: 3 });
}

$('prodQty').addEventListener('input', (e) => {
    const el = e.target;
    const pos = el.selectionStart;
    const cleaned = el.value.replace(/[^\d\s\u00a0.,]/g, '');
    if (cleaned !== el.value) {
        el.value = cleaned;
        el.setSelectionRange(pos - 1, pos - 1);
    }
    render(true);
});

$('prodQty').addEventListener('focus', (e) => {
    // на час редагування прибираємо пробіли — так зручніше правити
    const v = num(e.target.value);
    e.target.value = v ? String(v).replace('.', ',') : '';
});

$('prodQty').addEventListener('blur', (e) => {
    e.target.value = fmtQty(num(e.target.value));
});

/* Перерахунок під фактичний випуск. keepManual — не затирати те,
   що користувач уже виправив руками. */
function render(keepManual) {
    const body = $('prodBody');
    const qty = num($('prodQty').value);
    const scale = recipe.batch_kg > 0 ? qty / recipe.batch_kg : 0;

    if (!recipe.lines.length) {
        body.innerHTML = '<tr class="empty"><td colspan="6">'
            + 'Оберіть комбікорм — компоненти підставляться з рецепта</td></tr>';
        totals(); return;
    }
    const manual = {};
    if (keepManual) {
        body.querySelectorAll('tr[data-pid]').forEach((tr) => {
            const inp = tr.querySelector('.c-qty');
            if (inp && inp.dataset.touched === '1') manual[tr.dataset.pid] = inp.value;
        });
    }
    body.innerHTML = recipe.lines.map((l) => {
        const need = manual[l.product_id] !== undefined
            ? num(manual[l.product_id]) : +(l.qty_kg * scale).toFixed(3);
        const short = need > (l.stock_qty || 0) + 1e-9;
        return `<tr data-pid="${l.product_id}" data-nv="${l.avg_price_no_vat || l.avg_price || 0}">
            <td>${escapeHtml(l.name)}</td>
            <td class="num ${short ? 'is-short' : ''}">${fmt(l.stock_qty || 0, 1)}</td>
            <td class="num">${fmt(l.avg_price || 0, 4)}</td>
            <td class="num"><input type="number" class="c-qty" min="0" step="any"
                 value="${need}" data-touched="${manual[l.product_id] !== undefined ? 1 : 0}"></td>
            <td class="num c-cost">${fmt(need * (l.avg_price || 0))}</td>
            <td class="prod-c-act"><button class="btn btn-icon c-del" title="Прибрати компонент">×</button></td>
        </tr>`;
    }).join('');
    totals();
    fillCompSelect();
}

function totals() {
    let q = 0, c = 0, cnv = 0;
    $('prodBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const need = num(tr.querySelector('.c-qty').value);
        const price = num(tr.children[2].textContent);
        q += need;
        c += need * price;
        cnv += need * (parseFloat(tr.dataset.nv) || price);
    });
    const out = num($('prodQty').value);
    $('sumQty').textContent = fmt(q, 1);
    $('sumCost').textContent = fmt(c);
    // Підсумки документа. Ціна за кг — без ПДВ: це собівартість,
    // яка далі йде в аналітику годівлі й у вартість молока.
    $('docSumVat').textContent = fmt(c);
    $('docSumNoVat').textContent = fmt(cnv);
    $('docPricePerKg').textContent = out > 0 ? fmt(cnv / out, 4) : '—';
}

$('prodBody').addEventListener('input', (e) => {
    const inp = e.target.closest('.c-qty');
    if (!inp) return;
    inp.dataset.touched = '1';
    const tr = inp.closest('tr');
    const price = num(tr.children[2].textContent);
    tr.querySelector('.c-cost').textContent = fmt(num(inp.value) * price);
    tr.children[1].classList.toggle('is-short',
        num(inp.value) > num(tr.children[1].textContent) + 1e-9);
    totals();
});

$('prodBody').addEventListener('click', (e) => {
    if (!e.target.closest('.c-del')) return;
    const tr = e.target.closest('tr');
    recipe.lines = recipe.lines.filter((l) => String(l.product_id) !== tr.dataset.pid);
    tr.remove();
    totals();
});

function fillCompSelect() {
    const sel = $('addCompSel');
    sel.innerHTML = '<option value="">+ додати компонент…</option>';
    for (const p of allFeeds) {
        if (recipe.lines.some((l) => l.product_id === p.id)) continue;
        const o = document.createElement('option');
        o.value = p.id; o.textContent = p.name;
        sel.appendChild(o);
    }
}

$('addCompSel').addEventListener('change', () => {
    const id = +$('addCompSel').value;
    $('addCompSel').value = '';
    const p = allFeeds.find((x) => x.id === id);
    if (!p) return;
    recipe.lines.push({ product_id: p.id, name: p.name, qty_kg: 0,
                        stock_qty: p.total_qty || 0, avg_price: p.avg_price_in || 0 });
    render(true);
});

$('produceBtn').addEventListener('click', async () => {
    const components = [];
    $('prodBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const q = num(tr.querySelector('.c-qty').value);
        if (q > 0) components.push({ product_id: +tr.dataset.pid, qty: q });
    });
    const payload = {
        product_id: +$('prodProduct').value,
        qty_out: num($('prodQty').value),
        components,
        prod_date: $('prodDate').value,
        note: $('prodNote').value,
    };
    if (!payload.product_id) { toast('Оберіть комбікорм', 'error'); return; }
    if (payload.qty_out <= 0) { toast('Вкажіть фактичний випуск', 'error'); return; }
    if (!components.length) { toast('Додайте компоненти', 'error'); return; }

    if (!await confirmAction(
        `Провести виробництво?\n\nКомпоненти буде списано зі складу, `
        + `а комбікорм оприбутковано в кількості ${payload.qty_out} кг.`)) return;

    $('produceBtn').disabled = true;
    const r = await apiSend('/api/feed/produce', 'POST', payload);
    $('produceBtn').disabled = false;
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast(`${r.doc_no}: ${r.product} ${fmt(r.qty_out, 0)} кг · `
        + `${fmt(r.price_per_kg, 4)} ₴/кг`, 'success');
    $('prodQty').value = ''; $('prodNote').value = '';
    $('prodProduct').value = ''; recipe = { lines: [], batch_kg: 0 };
    clearDraft();
    render(); loadLog(); loadRecipes();
});

let logItems = [];   // проведені документи

async function loadLog() {
    const r = await safeGet('/api/feed/productions');
    if (!r.ok) { tableError('prodLog', 11, r.error || 'Не вдалося завантажити журнал'); return; }
    $('prodDoc').textContent = r.next_doc ? 'Документ ' + r.next_doc : '';
    logItems = r.items || [];
    renderProdLog();
}

/* Зведений розхід кормів на виробництво комбікормів за той самий період,
   що й журнал (З/По). */
async function loadConsumption() {
    const body = $('feedConsumeBody');
    if (!body) return;
    const from = ($('prodFrom') || {}).value || '';
    const to = ($('prodTo') || {}).value || '';
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g,
        (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const m1 = (v) => (Number(v) || 0).toLocaleString('uk-UA', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
    const m2 = (v) => (Number(v) || 0).toLocaleString('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const m4 = (v) => (Number(v) || 0).toLocaleString('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
    const per = $('fcPeriod');
    if (per) per.textContent = (from || to) ? `(${from || '…'} — ${to || '…'})` : '';
    const qs = [];
    if (from) qs.push('from=' + from);
    if (to) qs.push('to=' + to);
    const r = await safeGet('/api/feed/production-consumption' + (qs.length ? '?' + qs.join('&') : ''));
    if (!r.ok) { body.innerHTML = `<tr class="empty"><td colspan="7">${esc(r.error || 'Помилка')}</td></tr>`; return; }
    const items = r.items || [];
    body.innerHTML = items.length ? items.map((x) => `<tr>
        <td>${esc(x.name)}</td><td>${esc(x.code || '')}</td>
        <td class="num">${m1(x.kg)}</td>
        <td class="num">${m2(x.cost_no_vat)}</td>
        <td class="num">${m4(x.per_kg_no_vat)}</td>
        <td class="num">${m2(x.cost)}</td>
        <td class="num">${m4(x.per_kg)}</td></tr>`).join('')
        : '<tr class="empty"><td colspan="7">За цей період кормів не витрачено</td></tr>';
    const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };
    set('fcKg', m1(r.total_kg));
    set('fcCostNv', m2(r.total_cost_no_vat));
    set('fcCost', m2(r.total_cost));
}

/* Один журнал на дві частини: зверху СІРІ заміси з Profeed, що очікують
   проведення (розкриваються для перегляду/коригування, кнопка «Провести»),
   нижче — вже проведені документи ВК-N. */
function renderProdLog() {
    const body = $('prodLog');
    // фільтри стосуються лише проведених; чернетки з Profeed завжди зверху
    const from = ($('prodFrom') || {}).value || '';
    const to = ($('prodTo') || {}).value || '';
    const q = (($('prodSearch') || {}).value || '').trim().toLowerCase();
    let shown = logItems.filter((p) => {
        const d = p.prod_date || '';
        if (from && d < from) return false;
        if (to && d > to) return false;
        if (q) {
            const hay = `${p.doc_no} ${p.product_name} ${p.src_key || ''}`.toLowerCase();
            if (!hay.includes(q)) return false;
        }
        return true;
    });
    if (!pfItems.length && !shown.length) {
        body.innerHTML = `<tr class="empty"><td colspan="11">${
            logItems.length ? 'За цими фільтрами виробництв немає' : 'Ще нічого не вироблено'}</td></tr>`;
        return;
    }
    body.innerHTML = pfItems.map(pfRow).join('') + shown.map(logRow).join('');
    makeColumnsResizable('prodLogTbl', 'farm:prodlog_cols_w');
}

/* Сірий рядок «чернетки» з Profeed */
function pfRow(it, i) {
    const warn = [];
    if (it.kk_missing) warn.push(`КК «${it.kk_code}» немає`);
    if (it.unknown_feeds.length) warn.push(`нові: ${it.unknown_feeds.join(', ')}`);
    return `
        <tr class="pf-row" data-i="${i}">
            <td class="rec-c-tog"><button class="btn btn-icon pf-tog" data-tog="${i}"
                    title="Переглянути / скоригувати">▸</button></td>
            <td><span class="pf-badge">чернетка</span></td>
            <td>${escapeHtml(it.date)}</td>
            <td><strong>${escapeHtml(it.kk_name)}</strong></td>
            <td>${escapeHtml(it.src_key)}</td>
            <td class="num pf-qty-cell">${fmt(it.qty_out, 1)}</td>
            <td class="num">—</td><td class="num">—</td>
            <td class="num">${warn.length ? '<span class="acc-warn">'+escapeHtml(warn.join('; '))+'</span>' : '—'}</td>
            <td>Profeed</td>
            <td class="pf-c-act"><button class="btn btn-primary btn-sm pf-do" data-do="${i}">Провести</button></td>
        </tr>
        <tr class="batch-detail pf-detail" data-detail="pf-${i}" hidden>
            <td colspan="11"><div class="batch-box">
                <div class="pf-edit-head">Профід: план проти факту — факт можна скоригувати</div>
                <table class="batch-table pf-edit-tbl">
                    <thead><tr><th>Компонент</th><th class="num">План, кг</th>
                        <th class="num">Факт, кг</th><th class="num">Відхилення</th><th>Стан</th></tr></thead>
                    <tbody>${it.lines.map((l, jx) => {
                        const d = l.dev_pct;
                        const dc = d === null ? '' : (Math.abs(d) <= 2 ? 'acc-ok' : (Math.abs(d) <= 5 ? 'acc-warn' : 'acc-bad'));
                        return `
                        <tr><td>${escapeHtml(l.name)}</td>
                            <td class="num">${fmt(l.plan, 1)}</td>
                            <td class="num"><input type="number" class="pf-comp" min="0" step="any"
                                 value="${l.qty}" data-i="${i}" data-j="${jx}"></td>
                            <td class="num pf-dev ${dc}" data-i="${i}" data-j="${jx}">${d === null ? '—'
                                : (d > 0 ? '+' : '') + fmt(d, 2) + ' %'}</td>
                            <td class="${l.unknown ? 'acc-warn' : ''}">${l.unknown ? 'немає на складі' : 'на складі'}</td></tr>`;
                    }).join('')}
                    </tbody>
                    <tfoot><tr><td>Разом</td><td class="num">${fmt(it.qty_plan, 1)}</td>
                        <td class="num pf-sum" data-i="${i}">${fmt(it.qty_out,1)}</td><td></td><td></td></tr></tfoot>
                </table>
            </div></td>
        </tr>`;
}

/* Рядок проведеного документа */
function logRow(p) {
    const a = p.accuracy_pct;
    const cls = a === null ? '' : (a >= 98 ? 'acc-ok' : (a >= 95 ? 'acc-warn' : 'acc-bad'));
    return `
        <tr>
            <td class="rec-c-tog">${(p.lines || []).length ? `
                <button class="btn btn-icon prod-tog" data-toggle="${p.id}" title="Склад партії">▸</button>` : ''}</td>
            <td>${escapeHtml(p.doc_no)}</td>
            <td>${escapeHtml(p.prod_date)}</td>
            <td>${escapeHtml(p.product_name)}</td>
            <td>${escapeHtml(p.src_key || '—')}</td>
            <td class="num">${fmt(p.qty_out, 1)}</td>
            <td class="num">${fmt(p.cost_total_no_vat ?? p.cost_total)}</td>
            <td class="num">${fmt(p.price_per_kg_no_vat ?? p.price_per_kg, 4)}</td>
            <td class="num ${cls}">${a === null ? '—' : fmt(a, 2) + ' %'}</td>
            <td>${p.source === 'profeed' ? 'Profeed' : 'вручну'}</td>
            <td class="prod-c-act prod-row-act">
                <button class="btn btn-icon p-print" data-print="${p.id}" title="Друк акта">🖨</button>${IS_ADMIN ? `
                <button class="btn btn-icon p-edit" data-edit="${p.id}" title="Редагувати">✎</button>
                <button class="btn btn-icon p-del" data-del="${p.id}" title="Скасувати">×</button>` : ''}
            </td>
        </tr>
        <tr class="batch-detail" data-detail="${p.id}" hidden>
            <td colspan="11"><div class="batch-box">
                <div class="batch-box-title">Склад партії: зразок проти факту</div>
                <table class="batch-table">
                    <thead><tr><th>Компонент</th><th class="num">за зразком, кг</th><th class="num">факт, кг</th>
                        <th class="num">відхилення</th><th class="num">ціна без ПДВ, ₴/кг</th><th class="num">вартість без ПДВ, ₴</th></tr></thead>
                    <tbody>${(p.lines || []).map((l) => {
                        const d = l.dev_pct;
                        const dc = d === null ? '' : (Math.abs(d) <= 2 ? 'acc-ok' : (Math.abs(d) <= 5 ? 'acc-warn' : 'acc-bad'));
                        const costNv = l.cost_no_vat ?? l.cost;
                        const priceNv = l.qty_fact ? costNv / l.qty_fact : 0;
                        return `<tr><td>${escapeHtml(l.name)}</td>
                            <td class="num">${fmt(l.qty_plan, 1)}</td>
                            <td class="num">${fmt(l.qty_fact, 1)}</td>
                            <td class="num ${dc}">${d === null ? '—' : (d > 0 ? '+' : '') + fmt(d, 2) + ' %'}</td>
                            <td class="num">${fmt(priceNv, 4)}</td>
                            <td class="num">${fmt(costNv)}</td></tr>`;
                    }).join('')}</tbody>
                </table>
            </div></td>
        </tr>`;
}

/* розкриття рядків журналу (pf-чернетки й проведені) — обробник нижче,
   у секції Profeed; окремий тут прибрано, щоб toggle не спрацьовував двічі */

/* ---------- довідник рецептів: список із розкриттям структури ---------- */

async function loadRecipes() {
    const r = await safeGet('/api/feed/recipes');
    const body = $('recipesBody');
    if (!r.ok) { tableError('recipesBody', 10, r.error || 'Не вдалося завантажити рецепти'); return; }
    recipesCache = r.items || [];
    if (!recipesCache.length) {
        body.innerHTML = '<tr class="empty"><td colspan="10">Рецептів ще немає</td></tr>';
        return;
    }
    makeColumnsResizable('recipesTable', 'farm:rec_cols_w');
    const lineNv = (l) => (l.qty_kg || 0) * (l.avg_price_no_vat || 0);
    const lineV = (l) => (l.qty_kg || 0) * (l.avg_price || 0);
    body.innerHTML = recipesCache.map((k) => {
        const sumNv = k.lines.reduce((a, l) => a + lineNv(l), 0);
        const sumV = k.lines.reduce((a, l) => a + lineV(l), 0);
        const perKgNv = k.batch_kg > 0 ? sumNv / k.batch_kg : 0;
        const perKgV = k.batch_kg > 0 ? sumV / k.batch_kg : 0;
        return `
        <tr class="rec-row" data-rec="${k.id}">
            <td class="rec-c-tog">
                <button class="btn btn-icon rec-tog" data-toggle="${k.id}"
                        title="Показати склад">▸</button>
            </td>
            <td><strong>${escapeHtml(k.name)}</strong></td>
            <td class="num">${fmt(k.batch_kg, 2)}</td>
            <td class="num">${k.lines.length}</td>
            <td class="num">${fmt(perKgNv, 4)}</td>
            <td class="num"><strong>${fmt(sumNv, 2)}</strong></td>
            <td class="num text-mute">${fmt(perKgV, 4)}</td>
            <td class="num text-mute">${fmt(sumV, 2)}</td>
            <td class="num">${fmt(k.stock_qty || 0, 1)}</td>
            <td class="prod-c-act">${IS_ADMIN ? `
                <button class="btn btn-icon rec-edit" data-edit="${k.id}"
                        title="Редагувати рецепт">✎</button>` : ''}</td>
        </tr>
        <tr class="batch-detail" data-detail="${k.id}" hidden>
            <td colspan="10">
                <div class="batch-box">
                    <div class="batch-box-title">Склад на заміс ${fmt(k.batch_kg, 2)} кг</div>
                    <table class="batch-table">
                        <thead>
                            <tr>
                                <th>Компонент</th>
                                <th class="num">кг на заміс</th>
                                <th class="num">частка, %</th>
                                <th class="num">₴/кг без ПДВ</th>
                                <th class="num">сума без ПДВ, ₴</th>
                                <th class="num">₴/кг з ПДВ</th>
                                <th class="num">сума з ПДВ, ₴</th>
                                <th class="num">на складі, кг</th>
                            </tr>
                        </thead>
                        <tbody>${k.lines.map((l) => `
                            <tr>
                                <td>${escapeHtml(l.name)}</td>
                                <td class="num">${fmt(l.qty_kg, 3)}</td>
                                <td class="num">${fmt(l.share_pct, 2)}</td>
                                <td class="num">${fmt(l.avg_price_no_vat || 0, 4)}</td>
                                <td class="num">${fmt(lineNv(l), 2)}</td>
                                <td class="num text-mute">${fmt(l.avg_price || 0, 4)}</td>
                                <td class="num text-mute">${fmt(lineV(l), 2)}</td>
                                <td class="num ${(l.stock_qty || 0) <= 0 ? 'is-short' : ''}">${fmt(l.stock_qty || 0, 1)}</td>
                            </tr>`).join('')}
                        </tbody>
                        <tfoot>
                            <tr>
                                <td><strong>Разом</strong></td>
                                <td class="num"><strong>${fmt(k.batch_kg, 3)}</strong></td>
                                <td class="num">100</td><td></td>
                                <td class="num"><strong>${fmt(sumNv, 2)}</strong></td>
                                <td></td>
                                <td class="num text-mute"><strong>${fmt(sumV, 2)}</strong></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </td>
        </tr>`;
    }).join('');
}

/* Згортання всієї панелі — ховає вміст, лишає шапку. Стан памʼятаємо. */
function makePanelCollapsible(toggleId, bodyEls, storageKey) {
    const tog = $(toggleId);
    const els = bodyEls.map((id) => $(id)).filter(Boolean);
    if (!tog || !els.length) return;
    const apply = (on) => {
        els.forEach((e) => { e.hidden = on; });
        tog.classList.toggle('is-collapsed', on);
        tog.title = on ? 'Розгорнути панель' : 'Згорнути панель';
    };
    apply(localStorage.getItem(storageKey) === '1');
    tog.addEventListener('click', () => {
        const on = !els[0].hidden;
        apply(on);
        try { localStorage.setItem(storageKey, on ? '1' : '0'); } catch (e) { /* ignore */ }
    });
}
makePanelCollapsible('recPanelToggle', ['recipesTable'], 'farm:recipes_collapsed');
// панель «Новий заміс» згортається у DOMContentLoaded (після applyCollapse складу),
// щоб панельний стан був авторитетним і не перебивався станом складу

/* Фільтр журналу виробництв: пресети періоду + ручні дати + пошук.
   Той самий вигляд, що й «Останні надходження». */
(() => {
    const presets = $('prodPresets'), fromEl = $('prodFrom'), toEl = $('prodTo'),
          search = $('prodSearch');
    if (!presets) return;
    const KEY = 'farm:prodlog_days';
    const iso = (d) => d.toISOString().slice(0, 10);

    const markPreset = (days) => presets.querySelectorAll('.btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.days === String(days)));

    const applyPreset = (days) => {
        toEl.value = iso(new Date());
        fromEl.value = days === 'all' ? ''
            : (days === '0' ? toEl.value
               : iso(new Date(Date.now() - (+days) * 864e5)));
        markPreset(days);
    };

    presets.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-days]');
        if (!btn) return;
        applyPreset(btn.dataset.days);
        try { localStorage.setItem(KEY, btn.dataset.days); } catch (err) { /* ignore */ }
        renderProdLog(); loadConsumption();
    });
    [fromEl, toEl].forEach((el) => el.addEventListener('change', () => {
        markPreset(null); renderProdLog(); loadConsumption();
    }));
    search.addEventListener('input', renderProdLog);

    applyPreset(localStorage.getItem(KEY) || '45');   // дефолт — 45 днів
    loadConsumption();
})();

$('recipesBody').addEventListener('click', (e) => {
    const btn = e.target.closest('.rec-tog');
    if (!btn) return;
    const row = $('recipesBody').querySelector(
        `tr.batch-detail[data-detail="${btn.dataset.toggle}"]`);
    if (!row) return;
    row.hidden = !row.hidden;
    btn.textContent = row.hidden ? '▸' : '▾';
    btn.title = row.hidden ? 'Показати склад' : 'Сховати склад';
});

/* ---------- редактор рецепта: новий комбікорм або зміна наявного ---------- */

function recTotals() {
    let sum = 0;
    $('recBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        sum += num(tr.querySelector('.r-qty').value);
    });
    $('recSumKg').textContent = fmt(sum, 3);
    $('recBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const q = num(tr.querySelector('.r-qty').value);
        tr.querySelector('.r-share').textContent = sum > 0 ? fmt(q / sum * 100, 2) : '—';
    });
}

function recRender() {
    const body = $('recBody');
    if (!recEdit.lines.length) {
        body.innerHTML = '<tr class="empty"><td colspan="4">Додайте компоненти</td></tr>';
        recTotals(); recFillAdd(); return;
    }
    body.innerHTML = recEdit.lines.map((l) => `
        <tr data-pid="${l.product_id}">
            <td>${escapeHtml(l.name)}</td>
            <td class="num"><input type="number" class="r-qty" min="0" step="any"
                 value="${l.qty_kg}"></td>
            <td class="num r-share">—</td>
            <td class="rec-c-del">
                <button class="btn btn-icon r-del" title="Прибрати">×</button>
            </td>
        </tr>`).join('');
    recTotals(); recFillAdd();
}

function recFillAdd() {
    const sel = $('recAddSel');
    sel.innerHTML = '<option value="">+ додати компонент…</option>';
    for (const p of allFeeds) {
        if (recEdit.lines.some((l) => l.product_id === p.id)) continue;
        if (recEdit.product_id === p.id) continue;      // сам себе не компонент
        const o = document.createElement('option');
        o.value = p.id; o.textContent = p.name;
        sel.appendChild(o);
    }
}

function recFillSamples() {
    const sel = $('recSample');
    sel.innerHTML = '<option value="">— порожній —</option>';
    for (const k of recipesCache) {
        const o = document.createElement('option');
        o.value = k.id; o.textContent = k.name;
        sel.appendChild(o);
    }
}

function openRecipeEditor(productId) {
    const k = productId ? recipesCache.find((x) => x.id === productId) : null;
    recEdit = {
        product_id: k ? k.id : null,
        lines: k ? k.lines.map((l) => ({ product_id: l.product_id, name: l.name,
                                         qty_kg: l.qty_kg })) : [],
    };
    $('recipeModalTitle').textContent = k ? 'Рецепт: ' + k.name : 'Новий комбікорм';
    $('recName').value = k ? k.name : '';
    $('recName').disabled = !!k;              // назву наявного КК тут не міняємо
    $('recNote').value = k ? (k.note || '') : '';
    $('recSample').value = '';
    $('recSample').closest('.field').hidden = !!k;   // зразок — лише для нового КК
    recFillSamples();
    recRender();
    openModal('recipeModal');
}

/* Зразок: підставляємо структуру іншого КК, назву лишаємо свою */
$('recSample').addEventListener('change', () => {
    const k = recipesCache.find((x) => x.id === +$('recSample').value);
    if (!k) return;
    recEdit.lines = k.lines.map((l) => ({ product_id: l.product_id, name: l.name,
                                          qty_kg: l.qty_kg }));
    recRender();
    toast(`Структуру взято з «${k.name}» — змініть за потреби`, 'success');
});

$('recAddSel').addEventListener('change', () => {
    const p = allFeeds.find((x) => x.id === +$('recAddSel').value);
    $('recAddSel').value = '';
    if (!p) return;
    recEdit.lines.push({ product_id: p.id, name: p.name, qty_kg: 0 });
    recRender();
});

$('recBody').addEventListener('input', (e) => {
    if (!e.target.closest('.r-qty')) return;
    const tr = e.target.closest('tr');
    const l = recEdit.lines.find((x) => String(x.product_id) === tr.dataset.pid);
    if (l) l.qty_kg = num(e.target.value);
    recTotals();
});

$('recBody').addEventListener('click', (e) => {
    if (!e.target.closest('.r-del')) return;
    const tr = e.target.closest('tr');
    recEdit.lines = recEdit.lines.filter((l) => String(l.product_id) !== tr.dataset.pid);
    recRender();
});

$('recSaveBtn').addEventListener('click', async () => {
    const lines = recEdit.lines
        .filter((l) => num(l.qty_kg) > 0)
        .map((l) => ({ product_id: l.product_id, qty_kg: num(l.qty_kg) }));
    if (!lines.length) { toast('Додайте компоненти з кількістю', 'error'); return; }
    const payload = { lines, note: $('recNote').value };
    if (recEdit.product_id) payload.product_id = recEdit.product_id;
    else payload.name = $('recName').value.trim();
    if (!payload.product_id && !payload.name) { toast('Вкажіть назву', 'error'); return; }

    $('recSaveBtn').disabled = true;
    const r = await apiSend('/api/feed/recipes', 'POST', payload);
    $('recSaveBtn').disabled = false;
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Рецепт збережено', 'success');
    closeModal('recipeModal');
    await Promise.all([loadRecipes(), loadFeeds()]);
    refreshCombifeedSelect();
});

/* Перезбираємо список КК у формі виробництва, зберігаючи вибір */
async function refreshCombifeedSelect() {
    const keep = $('prodProduct').value;
    $('prodProduct').innerHTML = '<option value="">— оберіть —</option>';
    await loadCombifeeds();
    $('prodProduct').value = keep;
}

if ($('newRecipeBtn')) {
    $('newRecipeBtn').addEventListener('click', () => openRecipeEditor(null));
}
$('recipesBody').addEventListener('click', (e) => {
    const btn = e.target.closest('.rec-edit');
    if (btn) openRecipeEditor(+btn.dataset.edit);
});

/* ---------- дії над партією: друк, редагування, скасування ---------- */

function printProduction(p) {
    const now = new Date().toLocaleString('uk-UA').slice(0, 16);
    const rows = (p.lines || []).map((l, i) => `
        <tr>
            <td class="c">${i + 1}</td>
            <td>${escapeHtml(l.name)}</td>
            <td class="r">${fmt(l.qty_plan, 1)}</td>
            <td class="r">${fmt(l.qty_fact, 1)}</td>
            <td class="r">${l.dev_pct === null ? '—'
                : (l.dev_pct > 0 ? '+' : '') + fmt(l.dev_pct, 2) + ' %'}</td>
            <td class="r">${fmt(l.price, 4)}</td>
            <td class="r">${fmt(l.cost)}</td>
        </tr>`).join('');
    const factSum = (p.lines || []).reduce((s, l) => s + l.qty_fact, 0);

    const html = `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8">
<title>Акт виробництва ${escapeHtml(p.doc_no)}</title>
<style>
  @page { margin: 12mm; }
  * { font-family: Arial, sans-serif; }
  body { margin: 0; color: #111; }
  h1 { font-size: 18px; margin: 0 0 2px; }
  .meta { font-size: 12px; color: #555; margin-bottom: 10px; }
  .head { font-size: 12px; margin-bottom: 12px; }
  .head div { margin-bottom: 3px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #bbb; padding: 4px 6px; text-align: left; }
  th { background: #eef2f7; }
  td.c { text-align: center; }
  td.r { text-align: right; font-variant-numeric: tabular-nums; }
  tfoot td { font-weight: 700; background: #f6f8fb; }
  .sign { margin-top: 26px; font-size: 12px; }
</style></head><body>
<h1>Акт виробництва комбікорму ${escapeHtml(p.doc_no)}</h1>
<div class="meta">Сформовано: ${escapeHtml(now)}</div>
<div class="head">
  <div><b>Комбікорм:</b> ${escapeHtml(p.product_name)} (${escapeHtml(p.product_code || '')})</div>
  <div><b>Дата виробництва:</b> ${escapeHtml(p.prod_date)}</div>
  <div><b>Фактично вироблено:</b> ${fmt(p.qty_out, 1)} кг</div>
  <div><b>Собівартість:</b> ${fmt(p.cost_total)} ₴ · ${fmt(p.price_per_kg, 4)} ₴/кг</div>
  <div><b>Точність виготовлення:</b> ${p.accuracy_pct === null ? '—' : fmt(p.accuracy_pct, 2) + ' %'}</div>
  <div><b>Джерело:</b> ${p.source === 'profeed' ? 'Profeed' : 'вручну'}${
      p.src_key ? ' · партія ' + escapeHtml(p.src_key) : ''}</div>
  ${p.note ? `<div><b>Примітка:</b> ${escapeHtml(p.note)}</div>` : ''}
</div>
<table>
  <thead><tr>
    <th>№</th><th>Компонент</th><th>За зразком, кг</th><th>Факт, кг</th>
    <th>Відхилення</th><th>Ціна, ₴/кг</th><th>Вартість, ₴</th>
  </tr></thead>
  <tbody>${rows}</tbody>
  <tfoot><tr>
    <td colspan="3" style="text-align:right;">Разом</td>
    <td class="r">${fmt(factSum, 1)}</td>
    <td colspan="2"></td>
    <td class="r">${fmt(p.cost_total)}</td>
  </tr></tfoot>
</table>
<div class="sign">Виробництво здійснив: ______________________&nbsp;&nbsp;&nbsp;
Перевірив: ______________________</div>
<script>window.onload=function(){window.print();};window.onafterprint=function(){window.close();};<\/script>
</body></html>`;

    const w = window.open('', '_blank', 'width=900,height=650');
    if (!w) { toast('Дозвольте спливаючі вікна для друку', 'warn'); return; }
    w.document.write(html);
    w.document.close();
}

/* Редагування = скасувати партію й підставити її у форму замісу.
   Так залишки й собівартість завжди лишаються узгодженими: змінені
   кількості проводяться заново, а не «підправляються» заднім числом. */
async function editProduction(id) {
    const doc = await safeGet('/api/feed/productions/' + id);
    if (!doc.ok) { toast(doc.error || 'Не вдалося відкрити документ', 'error'); return; }
    if (!await confirmAction(
        `Редагувати ${doc.doc_no}?\n\nПартію буде скасовано (компоненти повернуться `
        + `на склад), а її дані підставлено у форму замісу. Після правок `
        + `натисніть «Провести виробництво» — документ створиться заново.`)) return;

    const del = await apiSend('/api/feed/productions/' + id, 'DELETE');
    if (!del.ok) { toast(del.error || 'Помилка', 'error'); return; }

    $('prodDate').value = doc.prod_date;
    $('prodNote').value = doc.note || '';
    $('prodQty').value = fmtQty(doc.qty_out);
    $('prodProduct').value = doc.product_id;
    await loadFeeds();
    const rec = await safeGet('/api/feed/recipe/' + doc.product_id);
    const stock = {};
    for (const p of allFeeds) stock[p.id] = p;
    recipe = {
        batch_kg: rec.ok ? rec.batch_kg : 0,
        lines: doc.lines.map((l) => ({
            product_id: l.product_id, name: l.name, qty_kg: l.qty_plan,
            stock_qty: (stock[l.product_id] || {}).total_qty || 0,
            avg_price: (stock[l.product_id] || {}).avg_price_in || 0,
        })),
    };
    render();
    // підставляємо саме ФАКТ, а не перерахунок зі зразка
    $('prodBody').querySelectorAll('tr[data-pid]').forEach((tr) => {
        const l = doc.lines.find((x) => String(x.product_id) === tr.dataset.pid);
        if (!l) return;
        const inp = tr.querySelector('.c-qty');
        inp.value = l.qty_fact;
        inp.dataset.touched = '1';
        inp.dispatchEvent(new Event('input', { bubbles: true }));
    });
    loadLog(); loadRecipes();
    toast(`${doc.doc_no} скасовано — дані у формі, проведіть заново`, 'success');
    $('prodQty').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

$('prodLog').addEventListener('click', async (e) => {
    const pr = e.target.closest('.p-print');
    if (pr) {
        const doc = await safeGet('/api/feed/productions/' + pr.dataset.print);
        if (!doc.ok) { toast(doc.error || 'Помилка', 'error'); return; }
        printProduction(doc);
        return;
    }
    const ed = e.target.closest('.p-edit');
    if (ed) { editProduction(+ed.dataset.edit); return; }

    const del = e.target.closest('.p-del');
    if (del) {
        if (!await confirmAction(
            'Скасувати виробництво?\n\nКомпоненти повернуться на склад, '
            + 'а вироблений комбікорм буде знято із залишку.')) return;
        const r = await apiSend('/api/feed/productions/' + del.dataset.del, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Виробництво скасовано', 'success');
        loadLog(); loadRecipes(); loadFeeds();
    }
});

/* ---------- підтягування з Profeed у журнал ----------
   Заміси комбікормів підтягуються ПРИ ВІДКРИТТІ сторінки й показуються
   сірими рядками «чернетка» вгорі журналу «Останні виробництва». Рядок
   розкривають (▸), за потреби правлять кількості й кнопкою «Провести»
   фіксують виробництво. */
let pfItems = [];

async function pfInit() {
    if (!$('pfScanBtn')) return;                 // не адмін — керування прихованим
    const r = await safeGet('/api/feed/profeed/dir');
    if (r.ok && r.dir) { $('pfDir').value = r.dir; pfScan(); }
    // швидке оновлення з шапки + вікно теки Profeed
    $('pfRefreshBtn').addEventListener('click', pfScan);
    $('pfDirBtn').addEventListener('click', () => openModal('pfDirModal'));
    $('pfScanBtn').addEventListener('click', () => { pfScan(); closeModal('pfDirModal'); });
    $('pfDir').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { pfScan(); closeModal('pfDirModal'); }
    });
    // системний діалог вибору теки (сервер = цей ПК)
    $('pfPickBtn').addEventListener('click', async () => {
        $('pfPickBtn').disabled = true;
        const res = await apiSend('/api/feed/profeed/pick-dir', 'POST', {});
        $('pfPickBtn').disabled = false;
        if (!res.ok) { toast(res.error || 'Не вдалося', 'error'); return; }
        if (res.dir) { $('pfDir').value = res.dir; pfScan(); }
    });
}

async function pfScan() {
    const dir = ($('pfDir').value || '').trim();
    if (!dir) { $('pfStatus').textContent = 'вкажіть теку звітів'; return; }
    $('pfStatus').textContent = 'Сканую…';
    await apiSend('/api/feed/profeed/dir', 'POST', { dir });
    const r = await safeGet('/api/feed/profeed/scan?dir=' + encodeURIComponent(dir));
    if (!r.ok) { $('pfStatus').textContent = r.error || 'помилка'; return; }
    pfItems = r.items || [];
    $('pfStatus').textContent = pfItems.length ? `очікують: ${pfItems.length}` : 'усе проведено';
    renderProdLog();
}

/* обробники журналу: розкриття pf-рядка та проведеного, редагування к-сті,
   кнопка «Провести» */
$('prodLog').addEventListener('click', (e) => {
    const pft = e.target.closest('.pf-tog');
    if (pft) {
        const row = $('prodLog').querySelector(`tr.pf-detail[data-detail="pf-${pft.dataset.tog}"]`);
        if (row) { row.hidden = !row.hidden; pft.textContent = row.hidden ? '▸' : '▾'; }
        return;
    }
    const tog = e.target.closest('.prod-tog');
    if (tog) {
        const row = $('prodLog').querySelector(`tr.batch-detail[data-detail="${tog.dataset.toggle}"]`);
        if (row) { row.hidden = !row.hidden; tog.textContent = row.hidden ? '▸' : '▾'; }
    }
});

$('prodLog').addEventListener('input', (e) => {
    const inp = e.target.closest('.pf-comp');
    if (!inp) return;
    const i = +inp.dataset.i, j = +inp.dataset.j, it = pfItems[i], l = it.lines[j];
    l.qty = num(inp.value);
    // перерахунок відхилення відредагованого рядка
    l.dev_pct = l.plan ? +(((l.qty - l.plan) / l.plan) * 100).toFixed(2) : null;
    const dv = $('prodLog').querySelector(`.pf-dev[data-i="${i}"][data-j="${j}"]`);
    if (dv) {
        const d = l.dev_pct;
        dv.textContent = d === null ? '—' : (d > 0 ? '+' : '') + fmt(d, 2) + ' %';
        dv.classList.remove('acc-ok', 'acc-warn', 'acc-bad');
        if (d !== null) dv.classList.add(Math.abs(d) <= 2 ? 'acc-ok' : (Math.abs(d) <= 5 ? 'acc-warn' : 'acc-bad'));
    }
    const sum = it.lines.reduce((s, x) => s + num(x.qty), 0);
    it.qty_out = +sum.toFixed(3);
    const sc = $('prodLog').querySelector(`.pf-sum[data-i="${i}"]`);
    if (sc) sc.textContent = fmt(sum, 1);
    const qc = $('prodLog').querySelector(`tr.pf-row[data-i="${i}"] .pf-qty-cell`);
    if (qc) qc.textContent = fmt(sum, 1);
});

$('prodLog').addEventListener('click', async (e) => {
    const btn = e.target.closest('.pf-do');
    if (!btn) return;
    const it = pfItems[+btn.dataset.do];
    if (it.kk_missing) { toast(`Спершу заведіть комбікорм «${it.kk_code}»`, 'error'); return; }
    const bad = it.lines.find((l) => l.unknown);
    if (bad) { toast(`«${bad.name}» немає на складі`, 'error'); return; }
    const comps = it.lines.filter((l) => num(l.qty) > 0)
        .map((l) => ({ product_id: l.product_id, qty: num(l.qty) }));
    if (!comps.length) { toast('Немає компонентів', 'error'); return; }
    if (!await confirmAction(
        `Провести виробництво ${it.kk_name} (партія ${it.src_key})?\n\n`
        + `Компоненти буде списано, комбікорм оприбутковано ${fmt(it.qty_out, 1)} кг.`)) return;
    btn.disabled = true;
    const r = await apiSend('/api/feed/produce', 'POST', {
        product_id: it.kk_product_id, qty_out: it.qty_out, components: comps,
        prod_date: it.date, src_key: it.src_key, source: 'profeed',
        note: 'Імпорт Profeed · ' + it.kk_code,
    });
    btn.disabled = false;
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast(`${r.doc_no}: ${r.product} ${fmt(r.qty_out, 0)} кг · ${fmt(r.price_per_kg, 4)} ₴/кг`, 'success');
    await Promise.all([pfScan(), loadLog(), loadRecipes(), loadFeeds()]);
});
