const expiryBody = document.querySelector('#expiryTable tbody');
const daysSelect = document.getElementById('expiryDays');

async function loadExpiry() {
    const days = daysSelect.value || 60;
    const r = await apiGet('/api/expiring?days=' + days);
    if (!r.ok) { toast('Помилка', 'error'); return; }
    const items = r.items || [];
    if (items.length === 0) {
        expiryBody.innerHTML = `<tr><td colspan="7" class="empty">У горизонті ${days} днів усе добре</td></tr>`;
        return;
    }
    expiryBody.innerHTML = items.map((b) => {
        let status = '<span class="badge ok">Норма</span>';
        if (b.expired) status = '<span class="badge danger">Прострочено</span>';
        else if (b.days_left !== null && b.days_left <= 30) status = '<span class="badge warn">Скоро</span>';
        return `
            <tr>
                <td><strong>${escapeHtml(b.name)}</strong></td>
                <td class="text-mute">${escapeHtml(b.barcode)}</td>
                <td>${fmtDate(b.expires_on)}</td>
                <td class="num ${b.expired ? 'text-danger' : (b.days_left <= 30 ? 'text-warn' : '')}">${b.days_left ?? '—'}</td>
                <td class="num">${fmtNum(b.qty)} ${escapeHtml(b.unit || '')}</td>
                <td>${status}</td>
            </tr>
        `;
    }).join('');
}

daysSelect.addEventListener('change', loadExpiry);
document.addEventListener('DOMContentLoaded', () => {
    loadExpiry();
    setupColumnPicker({
        tableId: 'expiryTable',
        storageKey: 'vetpharm:expiry_cols_hidden',
        anchor: document.querySelector('#expiryTable')
                    .closest('.panel').querySelector('.head-actions'),
        columns: [
            { key: 'name',        label: 'Товар' },
            { key: 'barcode',     label: 'Штрихкод' },
            { key: 'expires_on',  label: 'Термін' },
            { key: 'days_left',   label: 'Днів до кінця' },
            { key: 'qty',         label: 'Залишок' },
            { key: 'status',      label: 'Статус' },
        ],
    });
});
