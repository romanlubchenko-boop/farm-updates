/* ============ Фонове кешування складів для офлайну ============
   Щоб офлайн був ЗАВЖДИ готовий — і по аптеці, і по матеріалах: поки користувач
   працює онлайн у звичайному застосунку, ми тихо тягнемо знімки складу всіх
   гілок, де в нього є офлайн-доступ, і кладемо їх в IndexedDB (той самий
   'farm_offline' / 'snap', що читає офлайн-сторінка). Тоді при втраті мережі
   можна перемикатися між складами офлайн — обидва вже на пристрої.

   Список гілок задається з шаблону: window.OFFLINE_CACHE_LIST = [{branch, api}].
   api визначає гілку для сервера: '' = аптека, '/m' = матеріали. */
(function () {
    'use strict';
    var LIST = window.OFFLINE_CACHE_LIST || [];
    if (!LIST.length || !('indexedDB' in window)) return;

    function uuid() {
        return (self.crypto && crypto.randomUUID) ? crypto.randomUUID()
            : 'op-' + Date.now() + '-' + Math.random().toString(16).slice(2);
    }
    function deviceId() {
        var k = 'farm_device_id', v = localStorage.getItem(k);
        if (!v) { v = uuid(); localStorage.setItem(k, v); }
        return v;
    }
    // Той самий upgrade, що в offline.js (версія 3, сховища snap/queue/sales).
    function openDB() {
        return new Promise(function (resolve, reject) {
            var rq = indexedDB.open('farm_offline', 3);
            rq.onupgradeneeded = function () {
                var db = rq.result;
                if (!db.objectStoreNames.contains('snap')) db.createObjectStore('snap', { keyPath: 'branch' });
                if (!db.objectStoreNames.contains('queue')) db.createObjectStore('queue', { keyPath: 'op_id' });
                if (!db.objectStoreNames.contains('sales')) db.createObjectStore('sales', { keyPath: 'op_id' });
            };
            rq.onsuccess = function () { resolve(rq.result); };
            rq.onerror = function () { reject(rq.error); };
        });
    }
    function snapPut(rec) {
        return openDB().then(function (db) {
            return new Promise(function (resolve) {
                var t = db.transaction('snap', 'readwrite');
                t.objectStore('snap').put(rec);
                t.oncomplete = function () { resolve(true); };
                t.onerror = function () { resolve(false); };
            });
        }).catch(function () { return false; });
    }

    // Закешувати знімок однієї гілки (branch) через її api-базу.
    function cacheOne(branch, api) {
        return fetch(api + '/api/sync/device', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ device_id: deviceId(), name: 'ПК ' + (navigator.platform || '') })
        }).catch(function () {})
        .then(function () {
            return fetch(api + '/api/sync/snapshot', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
        })
        .then(function (r) { if (!r || !r.ok) throw 0; return r.json(); })
        .then(function (j) {
            if (j && j.ok && j.snapshot) {
                return snapPut({ branch: branch, data: j.snapshot, synced_at: new Date().toISOString() });
            }
        })
        .catch(function () { /* мовчки — це фонова операція */ });
    }

    var busy = false;
    function cacheAll() {
        if (busy || !navigator.onLine) return;
        busy = true;
        var jobs = LIST.map(function (it) { return cacheOne(it.branch, it.api || ''); });
        Promise.all(jobs).then(function () { busy = false; }).catch(function () { busy = false; });
    }

    function kick() { setTimeout(cacheAll, 1500); }
    if (document.readyState === 'complete') kick();
    else window.addEventListener('load', kick);
    setInterval(cacheAll, 5 * 60 * 1000);
    window.addEventListener('online', cacheAll);
})();
