"""Зібрати пакет оновлення з поточного коду.

Запуск (з папки app/):
    python3 build_update.py --notes "Що нового" --out /шлях/куди/покласти

Результат: farm_update_<версія>.zip із маніфестом update.json та папкою code/
(увесь код app/, окрім data/, config/, .venv). Цей файл кладеш у папку-джерело
(USB / OneDrive / мережа) або викладаєш за URL — і програма зможе оновитись.
"""

from __future__ import annotations

import re
import json
import zipfile
import argparse
from datetime import datetime
from pathlib import Path

from updater import PRESERVE, MANIFEST_NAME, _iter_code_files
import update_signing

HERE = Path(__file__).resolve().parent  # папка app/


def _read_const(path: Path, name: str, default: str = "") -> str:
    try:
        txt = path.read_text(encoding="utf-8")
    except OSError:
        return default
    m = re.search(rf'^{name}\s*=\s*["\']?([0-9.]+)["\']?', txt, re.M)
    return m.group(1) if m else default


def main() -> int:
    ap = argparse.ArgumentParser(description="Зібрати пакет оновлення")
    ap.add_argument("--notes", default="", help="Опис змін (показується перед оновленням)")
    ap.add_argument("--out", default=str(HERE.parent / "releases"),
                    help="Куди покласти пакет (за замовч. ../releases)")
    args = ap.parse_args()

    app_version = _read_const(HERE / "web_app.py", "APP_VERSION")
    schema_version = _read_const(HERE / "vet_pharmacy" / "web_db.py", "SCHEMA_VERSION", "1")
    if not app_version:
        print("✗ Не знайшов APP_VERSION у web_app.py")
        return 1

    out_dir = Path(args.out).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / f"farm_update_{app_version}.zip"

    # Збираємо файли коду в памʼять, щоб порахувати стабільний code_hash
    # (хеш усього вмісту code/) — його підписуємо й перевіряємо на клієнті.
    files = []  # (relpath_posix, bytes)
    for fp in _iter_code_files(HERE):
        rel = fp.relative_to(HERE).as_posix()
        files.append((rel, fp.read_bytes()))

    manifest = {
        "app_version": app_version,
        "schema_version": int(schema_version or 1),
        "notes": args.notes,
        "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "code_hash": update_signing.code_hash_from_pairs(files),
    }

    # Підписуємо маніфест приватним ключем (якщо доступний). Без підпису пакет
    # теж збереться (для сумісності), але клієнти з перевіркою його відхилять.
    sig = update_signing.sign_manifest(manifest)
    if sig:
        manifest["sig_alg"] = update_signing.SIG_ALG
        manifest["signature"] = sig

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(MANIFEST_NAME, json.dumps(manifest, ensure_ascii=False, indent=2))
        for rel, data in files:
            z.writestr("code/" + rel, data)

    print(f"✓ Пакет оновлення: {zip_path}")
    print(f"  Версія додатка: {app_version} · схема БД: {schema_version} · файлів: {len(files)}")
    print(f"  Виключено з пакета: {', '.join(sorted(PRESERVE))}")
    print(f"  Підпис: {'є (ed25519)' if sig else '✗ НЕМАЄ (ключ не знайдено)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
