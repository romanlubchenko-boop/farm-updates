"""Виробництво молока — читання даних із Excel за посиланням + агрегація по періодах.

Модуль НЕ зберігає даних: щоразу читає актуальний Excel-файл (openpyxl, read_only)
за налаштованим шляхом і мапінгом колонок. Далі групує рядки по періоду
(день/тиждень/місяць/квартал/рік) і рахує показники за правилами згортання:

  • sum    — Σ(col)                     надій_л/кг, продаж_кг
  • ratio  — Σ(num_col) / Σ(den_col)    жир% = Σкг_жиру/Σкг_молока (обернений
                                        перерахунок через кілограми), ціна = Σсума/Σкг
  • psum   — Σ(num_col × den_col)       сума_грн = Σ(ціна × кг)

Мапінг задається користувачем через інтерфейс і зберігається у налаштуваннях
застосунку (JSON). Тут — лише читання й математика.
"""
from __future__ import annotations

import datetime
from pathlib import Path


# ------------------------------------------------------------------- утиліти
def _num(v) -> float:
    """Число з клітинки; порожнє/текст → 0."""
    if v is None or v == "":
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        # інколи десяткові з комою
        try:
            return float(str(v).replace("\xa0", "").replace(" ", "").replace(",", "."))
        except ValueError:
            return 0.0


def _parse_date(v):
    if v is None or v == "":
        return None
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    return None


_MON = ["", "січ", "лют", "бер", "кві", "тра", "чер",
        "лип", "сер", "вер", "жов", "лис", "гру"]


def bucket(d: datetime.date, period: str):
    """(ключ, підпис, сортувальний_ключ) для дати в межах періоду."""
    if isinstance(d, datetime.datetime):
        d = d.date()
    if period == "week":
        iso = d.isocalendar()
        mon = d - datetime.timedelta(days=d.weekday())
        sun = mon + datetime.timedelta(days=6)
        return (f"{iso[0]}-W{iso[1]:02d}",
                f"{mon.strftime('%d.%m')}–{sun.strftime('%d.%m.%Y')}",
                mon.toordinal())
    if period == "month":
        return (f"{d.year}-{d.month:02d}", f"{_MON[d.month]} {d.year}",
                d.year * 100 + d.month)
    if period == "quarter":
        q = (d.month - 1) // 3 + 1
        return (f"{d.year}-Q{q}", f"{q} кв. {d.year}", d.year * 10 + q)
    if period == "year":
        return (str(d.year), str(d.year), d.year)
    if period == "all":
        return ("all", "Разом", 0)
    # day (за замовчуванням)
    return (d.isoformat(), d.strftime("%d.%m.%Y"), d.toordinal())


# ----------------------------------------------------------- читання Excel
def _materialize(path) -> str:
    """Скопіювати файл у тимчасову теку РЕАЛЬНИМ читанням байтів і повернути копію.

    Навіщо саме побайтове читання (критично для macOS + OneDrive):
      • `shutil.copy2` на macOS може зробити APFS-КЛОН файлу без фактичного
        читання — а для «хмарного заповнювача» OneDrive (Files On-Demand) це
        клонує ПОРОЖНІЙ плейсхолдер → копія виходить порожня/стара. Тому копіюємо
        через open('rb')+read: реальне читання ФОРСУЄ довантаження актуального
        вмісту з OneDrive.
      • дає стабільний ЗНІМОК на момент читання (навіть якщо Excel саме зберігає);
      • оригінал відкритий лише на короткий час читання.
    """
    import shutil, tempfile, os
    src = Path(path).expanduser()
    fd, tmp = tempfile.mkstemp(suffix=".xlsx", prefix="farm_milk_")
    os.close(fd)
    try:
        with open(src, "rb") as f, open(tmp, "wb") as g:
            shutil.copyfileobj(f, g)     # реальні read() → хідрує placeholder OneDrive
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:  # noqa: BLE001
            pass
        raise
    if os.path.getsize(tmp) == 0:
        try:
            os.unlink(tmp)
        except Exception:  # noqa: BLE001
            pass
        raise OSError("Файл порожній або не довантажився з OneDrive "
                      "(перевірте, що він «Завжди на цьому пристрої»).")
    return tmp


def _open(path):
    import openpyxl, os
    tmp = _materialize(path)
    try:
        wb = openpyxl.load_workbook(tmp, data_only=True, read_only=True)
        wb._farm_tmp = tmp
        return wb
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:  # noqa: BLE001
            pass
        raise


def _close(wb):
    import os
    try:
        wb.close()
    except Exception:  # noqa: BLE001
        pass
    tmp = getattr(wb, "_farm_tmp", None)
    if tmp:
        try:
            os.unlink(tmp)
        except Exception:  # noqa: BLE001
            pass


def file_mtime(path):
    """datetime останньої зміни файлу-джерела (для показу свіжості)."""
    try:
        return datetime.datetime.fromtimestamp(Path(path).expanduser().stat().st_mtime)
    except Exception:  # noqa: BLE001
        return None


def list_sheets(path) -> list:
    wb = _open(path)
    try:
        return list(wb.sheetnames)
    finally:
        _close(wb)


def list_columns(path, sheet, header_row: int) -> list:
    """Назви стовпців із рядка-шапки (1-based)."""
    wb = _open(path)
    try:
        ws = wb[sheet]
        for row in ws.iter_rows(min_row=int(header_row), max_row=int(header_row),
                                values_only=True):
            return [(str(c).strip() if c is not None else "") for c in row]
        return []
    finally:
        _close(wb)


def distinct_values(path, sheet, header_row: int, col: str, limit: int = 500) -> list:
    """Унікальні значення одного стовпця (для підказки у фільтрах)."""
    wb = _open(path)
    try:
        ws = wb[sheet]
        idx = None
        header_seen = False
        seen, out = set(), []
        for row in ws.iter_rows(min_row=int(header_row), values_only=True):
            if not header_seen:
                for j, c in enumerate(row):
                    if (str(c).strip() if c is not None else "") == col:
                        idx = j
                        break
                header_seen = True
                if idx is None:
                    return []
                continue
            v = row[idx] if idx < len(row) else None
            s = "" if v is None else str(v).strip()
            if s and s not in seen:
                seen.add(s)
                out.append(s)
                if len(out) >= limit:
                    break
        return out
    finally:
        _close(wb)


def read_rows(path, sheet, header_row: int, date_col: str, cols) -> list:
    """Читає рядки: {'date': date, <col>: value, ...}. Рядки без дати пропускає."""
    wb = _open(path)
    try:
        ws = wb[sheet]
        idx = {}
        header_seen = False
        out = []
        for row in ws.iter_rows(min_row=int(header_row), values_only=True):
            if not header_seen:
                for j, c in enumerate(row):
                    name = str(c).strip() if c is not None else ""
                    if name and name not in idx:
                        idx[name] = j
                header_seen = True
                continue

            def get(name):
                j = idx.get(name)
                return row[j] if (j is not None and j < len(row)) else None

            d = _parse_date(get(date_col))
            if not d:
                continue
            rec = {"date": d}
            for c in cols:
                if c:
                    rec[c] = get(c)
            out.append(rec)
        return out
    finally:
        _close(wb)


# ----------------------------------------------------------------- агрегація
def _as_list(spec):
    """Референс колонки: рядок або список рядків → список назв (без порожніх)."""
    if spec is None:
        return []
    if isinstance(spec, (list, tuple)):
        return [str(x) for x in spec if x]
    return [str(spec)] if spec else []


def _rowsum(r, spec) -> float:
    """Сума значень усіх колонок spec у рядку r (spec — назва або список назв)."""
    return sum(_num(r.get(c)) for c in _as_list(spec))


def cols_used(metrics, extra=()) -> list:
    """Усі колонки Excel, які треба прочитати для набору показників.
    Кожен референс може бути назвою або списком назв (що сумуються)."""
    s = set(_as_list(list(extra)))
    for m in metrics:
        for k in ("col", "cols", "num_col", "num_cols", "den_col", "den_cols"):
            for c in _as_list(m.get(k)):
                s.add(c)
    return [c for c in s if c]


def aggregate(rows, metrics, period, buyer_col=None, buyer_filter=None) -> list:
    """Групує рядки по періоду й рахує показники. Повертає список бакетів:
    [{'key','label','sort','metrics':{key:value,...}}], відсортований у часі."""
    if buyer_col and buyer_filter not in (None, "", "__all__"):
        rows = [r for r in rows if str(r.get(buyer_col, "")).strip() == str(buyer_filter)]

    buckets = {}
    for r in rows:
        d = r.get("date")
        if not d:
            continue
        key, label, sort = bucket(d, period)
        b = buckets.get(key)
        if b is None:
            b = buckets[key] = {"label": label, "sort": sort, "acc": {},
                                "photo": "", "source": "", "by": "", "at": ""}
        if r.get("photo"):
            b["photo"] = r["photo"]      # фото лічильника (для дня — фото цього дня)
        if r.get("source"):
            b["source"] = r["source"]    # джерело (manual/Excel) — для кнопки видалення
        if r.get("entered_by"):
            b["by"] = r["entered_by"]    # хто вніс (Telegram-учасник)
        if r.get("at"):
            b["at"] = r["at"]            # коли внесли (дата й час)
        acc = b["acc"]
        for m in metrics:
            a = acc.get(m["key"])
            if a is None:
                a = acc[m["key"]] = {"sum": 0.0, "num": 0.0, "den": 0.0}
            kind = m.get("agg", "sum")
            if kind == "sum":
                a["sum"] += _rowsum(r, m.get("cols") or m.get("col"))
            elif kind == "ratio":
                a["num"] += _rowsum(r, m.get("num_cols") or m.get("num_col"))
                a["den"] += _rowsum(r, m.get("den_cols") or m.get("den_col"))
            elif kind == "psum":
                a["sum"] += _rowsum(r, m.get("num_col")) * _rowsum(r, m.get("den_col"))

    out = []
    for key, b in buckets.items():
        vals = {}
        for m in metrics:
            a = b["acc"].get(m["key"], {"sum": 0.0, "num": 0.0, "den": 0.0})
            kind = m.get("agg", "sum")
            if kind == "ratio":
                vals[m["key"]] = (a["num"] / a["den"]) if a["den"] else 0.0
            else:  # sum, psum
                vals[m["key"]] = a["sum"]
        out.append({"key": key, "label": b["label"], "sort": b["sort"],
                    "metrics": vals, "photo": b.get("photo", ""),
                    "source": b.get("source", ""), "by": b.get("by", ""),
                    "at": b.get("at", "")})
    out.sort(key=lambda x: x["sort"])
    return out


def build_price_schedule(rows, date_col, price_col):
    """Графік цін: відсортований список (дата, ціна) з аркуша цін."""
    sched = [(r["date"], _num(r.get(price_col))) for r in rows if r.get("date")]
    sched.sort(key=lambda x: x[0])
    return sched


def effective_price(sched, d):
    """Ціна, що ДІЄ на дату d: остання ціна, чия дата ≤ d (перенесення вперед).
    Дати вже нормалізовані у datetime.date (read_rows). До першої ціни — 0."""
    if isinstance(d, datetime.datetime):
        d = d.date()
    price = 0.0
    for dt, val in sched:
        if dt <= d:
            price = val
        else:
            break
    return price


def buyers(rows, buyer_col) -> list:
    """Унікальні значення покупця (для фільтра)."""
    if not buyer_col:
        return []
    seen = []
    s = set()
    for r in rows:
        v = str(r.get(buyer_col, "")).strip()
        if v and v not in s:
            s.add(v)
            seen.append(v)
    return sorted(seen)
