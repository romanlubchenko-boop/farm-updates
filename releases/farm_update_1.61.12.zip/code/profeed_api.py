"""Інтеграція з Profeed API — автоматичне завантаження звіту роздач.

Профід віддає звіт як base64-вміст .xlsx у полі data.report:

    POST /api/auth/jwt/create/   {email, password}          → data.token
    POST /api/auth/jwt/verify/   {token}                    → 200 якщо дійсний
    POST /api/auth/jwt/refresh/  {token}                    → новий data.token
    GET  /api/report/inout/make/?farm=&planned_on_after=
         &planned_on_before=&report=&language=uk            → data.name + data.report

Модуль навмисно НЕ знає про базу: токен передається зовні й повертається назад,
щоб застосунок сам вирішив, де його зберігати. Використовуємо лише стандартну
бібліотеку (urllib) — жодних нових залежностей.
"""
from __future__ import annotations

import base64
import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Optional

API_BASE = "https://api-mix.profeed.systems"
TIMEOUT = 60

# Перевірка сертифіката: на macOS «голий» Python часто не має кореневих
# сертифікатів (CERTIFICATE_VERIFY_FAILED), тому пробуємо кілька джерел CA:
# certifi (якщо встановлено) → системні бандли ОС → типовий контекст.
INSECURE = False        # аварійний режим: без перевірки (вмикається з налаштувань)


def _ca_candidates() -> list:
    out: list = []
    try:
        import certifi
        out.append(certifi.where())
    except Exception:  # noqa: BLE001
        pass
    for p in ("/etc/ssl/cert.pem",                      # macOS
              "/opt/homebrew/etc/openssl@3/cert.pem",
              "/usr/local/etc/openssl@3/cert.pem",
              "/etc/ssl/certs/ca-certificates.crt",     # Linux
              "/etc/pki/tls/certs/ca-bundle.crt"):
        if Path(p).exists():
            out.append(p)
    return out


def _contexts() -> list:
    """Контексти SSL у порядку спроб."""
    if INSECURE:
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode = ssl.CERT_NONE
        return [c]
    ctxs = [ssl.create_default_context()]
    for ca in _ca_candidates():
        try:
            ctxs.append(ssl.create_default_context(cafile=ca))
        except Exception:  # noqa: BLE001
            pass
    return ctxs


class ProfeedError(Exception):
    """Помилка звернення до Profeed (мережа / авторизація / відповідь)."""


# Підказки для помилок валідації параметрів (Profeed віддає лише коди).
_FIELD_HINT = {
    "report": ("невідома назва звіту. Потрібен ТЕХНІЧНИЙ код латиницею "
               "(напр. pleshkani_report), а не назва українською"),
    "farm": "невірний номер ферми (farm) — потрібен числовий ID",
    "planned_on_after": "невірна дата «з»",
    "planned_on_before": "невірна дата «по»",
    "language": "невідома мова (має бути uk / en)",
}


def _explain_400(txt: str) -> str:
    """Зробити з відповіді 400 зрозуміле повідомлення."""
    try:
        data = json.loads(txt or "{}")
    except Exception:  # noqa: BLE001
        data = {}
    parts = []
    if isinstance(data, dict):
        for field, hint in _FIELD_HINT.items():
            if field in data:
                parts.append(f"«{field}» — {hint}")
        for field in data:
            if field not in _FIELD_HINT and field != "detail":
                parts.append(f"«{field}» — Profeed не прийняв значення")
    if parts:
        return "Profeed відхилив параметри: " + "; ".join(parts) + "."
    return f"Profeed відповів 400. {txt}"


def _request(method: str, path: str, payload: Optional[dict] = None,
             token: str = "", timeout: int = TIMEOUT) -> dict[str, Any]:
    url = path if path.startswith("http") else API_BASE + path
    data = None
    headers = {"accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = "JWT " + token
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    body = None
    last_ssl: Optional[Exception] = None
    try:
        for ctx in _contexts():          # по черзі, доки сертифікат не пройде
            try:
                with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                    body = resp.read().decode("utf-8", "replace")
                break
            except ssl.SSLCertVerificationError as exc:
                last_ssl = exc
                continue
            except urllib.error.URLError as exc:
                if isinstance(getattr(exc, "reason", None), ssl.SSLCertVerificationError):
                    last_ssl = exc.reason
                    continue
                raise
        if body is None:
            raise ProfeedError(
                "Не вдалося перевірити сертифікат сервера Profeed "
                f"({last_ssl}). Встановіть кореневі сертифікати "
                "(кнопка «Оновити бібліотеки» в Налаштуваннях або пакет certifi) "
                "чи увімкніть «без перевірки сертифіката».")
    except urllib.error.HTTPError as exc:
        txt = ""
        try:
            txt = exc.read().decode("utf-8", "replace")[:300]
        except Exception:  # noqa: BLE001
            pass
        if exc.code in (401, 403):
            raise ProfeedError("Немає доступу (перевірте email/пароль або токен).") from exc
        if exc.code == 400:
            raise ProfeedError(_explain_400(txt)) from exc
        raise ProfeedError(f"Profeed відповів {exc.code}. {txt}") from exc
    except urllib.error.URLError as exc:
        raise ProfeedError(f"Немає зв'язку з Profeed: {exc.reason}") from exc
    except ProfeedError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise ProfeedError(f"Помилка запиту: {exc}") from exc
    try:
        return json.loads(body or "{}")
    except Exception as exc:  # noqa: BLE001
        raise ProfeedError("Profeed повернув не JSON.") from exc


def login(email: str, password: str) -> str:
    """Отримати JWT за логіном і паролем."""
    email = (email or "").strip()
    if not email or not password:
        raise ProfeedError("Вкажіть email і пароль Profeed.")
    r = _request("POST", "/api/auth/jwt/create/",
                 {"email": email, "password": password})
    tok = ((r or {}).get("data") or {}).get("token") or ""
    if not tok:
        raise ProfeedError("Profeed не повернув токен.")
    return tok


def verify(token: str) -> bool:
    """Чи дійсний токен (без винятку)."""
    if not (token or "").strip():
        return False
    try:
        _request("POST", "/api/auth/jwt/verify/", {"token": token}, token=token)
        return True
    except ProfeedError:
        return False


def refresh(token: str) -> str:
    """Продовжити токен; порожньо, якщо не вдалося."""
    try:
        r = _request("POST", "/api/auth/jwt/refresh/", {"token": token}, token=token)
        return ((r or {}).get("data") or {}).get("token") or ""
    except ProfeedError:
        return ""


def ensure_token(email: str, password: str, token: str = "") -> str:
    """Дійсний токен: наявний → продовжений → новий за логіном/паролем."""
    if verify(token):
        new = refresh(token)
        return new or token
    return login(email, password)


def make_report(token: str, farm, report: str, date_from: str, date_to: str,
                language: str = "uk") -> tuple[str, bytes]:
    """Сформувати й забрати звіт. Повертає (назва файлу, вміст .xlsx)."""
    q = urllib.parse.urlencode({
        "farm": str(farm or "").strip(),
        "planned_on_after": (date_from or "")[:10],
        "planned_on_before": (date_to or date_from or "")[:10],
        "report": (report or "").strip(),
        "language": (language or "uk").strip() or "uk",
    })
    r = _request("GET", "/api/report/inout/make/?" + q, token=token)
    data = (r or {}).get("data") or {}
    name = (data.get("name") or "").strip()
    b64 = data.get("report") or ""
    if not b64:
        raise ProfeedError("Profeed не повернув файл звіту (порожній report).")
    try:
        raw = base64.b64decode(b64, validate=False)
    except Exception as exc:  # noqa: BLE001
        raise ProfeedError("Не вдалося розкодувати файл звіту.") from exc
    if not raw.startswith(b"PK"):
        raise ProfeedError("Отриманий файл не схожий на .xlsx.")
    if not name:
        name = f"profeed_{(date_from or '')[:10]}_{(date_to or date_from or '')[:10]}.xlsx"
    if not name.lower().endswith(".xlsx"):
        name += ".xlsx"
    return name, raw


def build_name(pattern: str, day: str, fallback: str) -> str:
    """Ім'я файлу за шаблоном користувача.

    Порожньо → назва від Profeed. У шаблоні можна писати {date} — підставиться
    дата; якщо {date} немає, дата додається в кінець: feedreport →
    feedreport_2026-08-16.xlsx."""
    pat = (pattern or "").strip()
    if not pat:
        return fallback
    day = (day or "")[:10]
    if pat.lower().endswith(".xlsx"):      # розширення допишемо самі
        pat = pat[:-5].strip() or pat
    name = pat.replace("{date}", day) if "{date}" in pat else f"{pat}_{day}"
    for ch in '/\\:*?"<>|':               # безпечне ім'я файлу
        name = name.replace(ch, "-")
    name = name.strip() or fallback
    if not name.lower().endswith(".xlsx"):
        name += ".xlsx"
    return name


def download(cfg: dict, date_from: str, date_to: str,
             target_dir: str) -> dict[str, Any]:
    """Завантажити звіт у теку звітів Profeed.

    cfg: {email, password, farm, report, language, token}
    Повертає {file, name, size, token, replaced} — файл ЗАВЖДИ перезаписується
    свіжою версією (звіт за поточний день доповнюється протягом доби);
    token може бути новим (застосунок збереже його, щоб не логінитись щоразу).
    """
    folder = Path((target_dir or "").strip()).expanduser()
    if not str(folder):
        raise ProfeedError("Не вказано теку звітів Profeed.")
    folder.mkdir(parents=True, exist_ok=True)

    token = ensure_token(cfg.get("email", ""), cfg.get("password", ""),
                         cfg.get("token", ""))
    name, raw = make_report(token, cfg.get("farm", ""), cfg.get("report", ""),
                            date_from, date_to, cfg.get("language", "uk"))
    name = build_name(cfg.get("fname", ""), date_from, name)
    path = folder / name
    existed = path.exists()
    path.write_bytes(raw)                 # завжди перезаписуємо свіжою версією
    return {"file": str(path), "name": name, "size": len(raw),
            "token": token, "replaced": existed}
