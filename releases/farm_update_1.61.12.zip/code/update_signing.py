"""Підпис і перевірка пакетів оновлення (Ed25519).

Навіщо: щоб у застосунок не можна було підсунути чужий код через підміну
джерела оновлень чи MITM. Кожен пакет підписується ПРИВАТНИМ ключем (лежить
лише на ПК розробника, у проєкт НЕ потрапляє). Клієнт перевіряє підпис
ВБУДОВАНИМ публічним ключем — без доступу до приватного підробити пакет не можна.

Схема:
  • update.json у пакеті містить code_hash — стабільний хеш усіх файлів code/.
  • update.json також містить signature — підпис канонічного маніфесту
    (усі поля, КРІМ signature) приватним ключем.
  • Клієнт: перевіряє підпис маніфесту публічним ключем, далі звіряє code_hash
    із фактичним вмістом code/. Якщо щось не збігається — пакет відхиляється.

Приватний ключ НЕ зберігається тут. build_update.py читає його з файлу
(env FARM_UPDATE_KEY або signing_keys/farm_update_ed25519.pem поруч із проєктом).
"""

from __future__ import annotations

import os
import json
import base64
import hashlib
from pathlib import Path
from typing import Optional

# Вбудований ПУБЛІЧНИЙ ключ (Ed25519, raw 32 байти, base64). Безпечно бути в коді.
UPDATE_PUBLIC_KEY_B64 = "ScuMU3mJHDTM5po8TpUyR2pqTnYiYnFJT3XQIdFReB4="
SIG_ALG = "ed25519"


def canonical_manifest_bytes(manifest: dict) -> bytes:
    """Канонічні байти маніфесту для підпису/перевірки (без поля signature).
    Однаково рахуються і при збірці, і на клієнті."""
    m = {k: v for k, v in manifest.items() if k not in ("signature", "sig_alg")}
    return json.dumps(m, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False).encode("utf-8")


def code_hash_from_pairs(pairs) -> str:
    """pairs: ітерабельний (relpath_posix, file_bytes). Повертає стабільний хеш."""
    items = []
    for rel, data in pairs:
        items.append(rel + ":" + hashlib.sha256(data).hexdigest())
    items.sort()
    joined = "\n".join(items).encode("utf-8")
    return hashlib.sha256(joined).hexdigest()


# ----------------------------------------------------------- перевірка (клієнт)

def verify_manifest_signature(manifest: dict) -> bool:
    """True, якщо підпис маніфесту валідний за вбудованим публічним ключем."""
    sig_b64 = str(manifest.get("signature", "")).strip()
    if not sig_b64:
        return False
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PublicKey,
        )
        pub = Ed25519PublicKey.from_public_bytes(
            base64.b64decode(UPDATE_PUBLIC_KEY_B64))
        pub.verify(base64.b64decode(sig_b64), canonical_manifest_bytes(manifest))
        return True
    except Exception:  # noqa: BLE001
        return False


def has_signature(manifest: dict) -> bool:
    return bool(str((manifest or {}).get("signature", "")).strip())


# ----------------------------------------------------------- підпис (розробник)

def _default_private_key_path() -> Path:
    env = os.environ.get("FARM_UPDATE_KEY")
    if env:
        return Path(env).expanduser()
    # signing_keys/ поруч із коренем проєкту (…/farmProject/.. → codeProject)
    here = Path(__file__).resolve()
    # here = …/FarmApp/app/update_signing.py → проєкт = …/farmProject
    project_root = here.parent.parent.parent          # …/codeProject/farmProject → .. = codeProject
    return project_root.parent / "signing_keys" / "farm_update_ed25519.pem"


def sign_manifest(manifest: dict,
                  private_key_path: Optional[Path] = None) -> Optional[str]:
    """Підписати маніфест приватним ключем. Повертає base64-підпис або None,
    якщо ключа немає / помилка (тоді збірка лишиться без підпису)."""
    kp = Path(private_key_path) if private_key_path else _default_private_key_path()
    if not kp.exists():
        return None
    try:
        from cryptography.hazmat.primitives import serialization
        priv = serialization.load_pem_private_key(kp.read_bytes(), password=None)
        sig = priv.sign(canonical_manifest_bytes(manifest))
        return base64.b64encode(sig).decode("ascii")
    except Exception:  # noqa: BLE001
        return None
