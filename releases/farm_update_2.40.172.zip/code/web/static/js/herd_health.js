/* ЗДОРОВ’Я СТАДА — ВАКЦИНАЦІЯ (Роман 2026-10-01: «окремий блок вакцинація тварин — прописувати схему вакцинації й
   впроваджувати в списки» → обрав: строк кроку — від віку чи від події; проведено — подія й тварина зникає зі списку;
   аптеку поки не списуємо).
   📌 Схема: кого — СТАНДАРТНИЙ рядок формули під пошуком тварини, як скрізь (Роман 2026-10-01: «строкова форма стандартна,
      як і скрізь»): клік по схемі — її FILTER(…) у рядку, Enter — записати; кроки: препарат, доза, від чого рахувати —
      ПАРАМЕТР-ДАТА (будь-який: народження, отелу, очікуваний отел, запуск…) або попередній крок; вікно днів від дати
      (від’ємні — до неї). Схема активна / неактивна (неактивна в «До вакцинації» і в vacc не рахується).
   📌 Хто кому вже зроблено — подія «Вакцинація» з полем __vstep «схема:крок» (сервер: /api/herd/vacc → done).
   📌 Кому час — рахуємо тут, на живих тваринах: «зараз» (у вікні), «прострочено» (до 30 днів по вікну), «скоро» (до 14
      днів до вікна). «Провести» — груповий запис події тим, кого відмічено. */
'use strict';
(function () {
const $ = (id) => document.getElementById(id);
if (!$('hhDue')) return;

// від чого рахувати: параметри-дати (найуживаніші — першими) і «попередній крок»
const BASE_FIRST = ['birth_date', 'last_calving', 'expected_calving', 'last_dryoff'];
function dateParams() {
    const ds = PARAMS.filter((p) => p.dtype === 'date');
    const rank = (p) => { const i = BASE_FIRST.indexOf(p.key); return i < 0 ? 99 : i; };
    return ds.sort((a, b) => rank(a) - rank(b) || String(a.label).localeCompare(String(b.label), 'uk'));
}
const baseLabel = (k) => ((PARAMS.find((p) => p.key === k) || {}).label || k);

let PARAMS = [], SCHEMES = [], EVENT = null, ANIMALS = [];
let SEL = '';                                         // схема, чия умова «Кого» — у рядку формули вгорі
const OPEN = new Set();                              // розгорнуті кроки (до першого рендера — усі, де є «зараз»)
let FIRST = true;

const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const parseD = (s) => {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const dm = (d) => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
const dmy = (d) => `${dm(d)}.${d.getFullYear()}`;
const sk = (sc, st) => `${sc.id}:${st.id}`;

/* ---------- хто кому час ---------- */
/* рахунок — спільний із мовою списків (herd_vacc.js): одна схема — одні числа скрізь */
const V = window.herdVacc;
const whoQ = (sc) => V.whoQ(sc);
const needKeys = () => V.deps();
const stateOf = (a, sc, st, t0) => V.stateOf(a, sc, st, t0);
function computeDue() {
    const t0 = today();
    const out = [];
    SCHEMES.forEach((sc) => {
        if (!sc.steps.some((st) => !st.off)) return;
        const q = whoQ(sc);
        if (q.error) return;
        const who = ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters));
        sc.steps.forEach((st) => {
            if (st.off) return;                       // неактивний крок — не рахується
            const rows = [];
            who.forEach((a) => { const s = stateOf(a, sc, st, t0); if (s) rows.push(Object.assign({ a }, s)); });
            if (!rows.length) return;
            const rank = { late: 0, now: 1, soon: 2 };
            rows.sort((p, r) => rank[p.st] - rank[r.st] || String(p.a.tag).localeCompare(String(r.a.tag), 'uk', { numeric: true }));
            out.push({ sc, st, rows });
        });
    });
    return out;
}

/* ---------- «До вакцинації» ---------- */
const xLabel = (st, x) => (st.base === 'step' ? `${x} дн. після кроку`
    : st.base === 'birth_date' ? `${x} дн. життя`
        : x < 0 ? `за ${-x} дн. до «${baseLabel(st.base)}»` : `${x} дн. від «${baseLabel(st.base)}»`);
const stLabel = (r) => (r.st === 'now' ? 'зараз' : r.st === 'late' ? `прострочено на ${r.n} дн.` : `через ${r.n} дн.`);
function renderDue() {
    V.setSchemes(SCHEMES);                         // правки схеми — одразу в спільному рахунку
    const box = $('hhDue');
    if (!SCHEMES.length) {
        $('hhSum').textContent = '';
        box.innerHTML = '<div class="hh-empty">Схем вакцинації ще немає — додайте нижче «+ схема».</div>';
        return;
    }
    if (SCHEMES.every((sc) => sc.steps.every((st) => st.off))) {
        $('hhSum').textContent = 'усі кроки неактивні';
        box.innerHTML = '<div class="hh-empty">Усі кроки неактивні — увімкніть потрібні нижче.</div>';
        return;
    }
    const list = computeDue();
    let now = 0, late = 0, soon = 0;
    list.forEach((g) => g.rows.forEach((r) => { if (r.st === 'now') now++; else if (r.st === 'late') late++; else soon++; }));
    $('hhSum').innerHTML = list.length
        ? `зараз <b>${now}</b>` + (late ? ` · прострочено <b>${late}</b>` : '') + (soon ? ` · скоро ${soon}` : '')
        : 'нікому — усе зроблено';
    if (!list.length) { box.innerHTML = '<div class="hh-empty">Зараз нікого: кому за схемами час — уже вакциновані.</div>'; return; }
    if (FIRST) { list.forEach((g) => { if (g.rows.some((r) => r.st !== 'soon')) OPEN.add(sk(g.sc, g.st)); }); FIRST = false; }
    box.innerHTML = list.map((g) => {
        const key = sk(g.sc, g.st);
        const c = (s) => g.rows.filter((r) => r.st === s).length;
        const open = OPEN.has(key);
        // за замовчуванням — лише «зараз»: прострочених могли колоти без запису, їх відмічають свідомо
        const pick = g.rows.filter((r) => r.st === 'now').length;
        const pills = [['late', c('late'), 'прострочено'], ['now', c('now'), 'зараз'], ['soon', c('soon'), 'скоро']]
            .filter((p) => p[1]).map((p) => `<span class="hh-pill ${p[0]}" title="${p[2]}">${p[1]} ${p[2]}</span>`).join('');
        const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
        return `<div class="hh-step" data-k="${escapeHtml(key)}">
            <div class="hh-sh" data-tog="${escapeHtml(key)}">
                <span class="hh-chev">${open ? '▾' : '▸'}</span>
                <span class="nm">${escapeHtml(g.st.name)}</span>
                ${drug ? `<span class="dr">${escapeHtml(drug)}</span>` : ''}
                <span class="sc">${escapeHtml(g.sc.name)}</span>
                <span class="cnt">${pills}</span>
                <button type="button" class="btn btn-primary btn-sm" data-go="${escapeHtml(key)}"${pick ? '' : ' disabled'}>Провести · <span data-n>${pick}</span></button>
            </div>
            ${open ? `<table class="hh-tbl"><thead><tr><th class="ck"><input type="checkbox" data-all${pick ? ' checked' : ''}></th>
                <th>Номер</th><th class="hide-sm">Кличка</th><th>Строк</th><th class="hide-sm">Вікно</th><th>Стан</th></tr></thead><tbody>
                ${g.rows.map((r) => `<tr><td class="ck"><input type="checkbox" data-id="${r.a.id}"${r.st === 'now' ? ' checked' : ''}></td>
                    <td><a href="/herd/animals/${r.a.id}">${escapeHtml(r.a.tag || '')}</a></td>
                    <td class="hide-sm">${escapeHtml(r.a.name || '')}</td>
                    <td>${escapeHtml(xLabel(g.st, r.x))}</td>
                    <td class="hide-sm">${dm(r.w1)}–${dmy(r.w2)}</td>
                    <td><span class="hh-st ${r.st}">${stLabel(r)}</span></td></tr>`).join('')}
                </tbody></table>` : ''}
        </div>`;
    }).join('');
    box._list = list;
}
function picked(card, g) {
    const boxes = card.querySelectorAll('input[data-id]');
    if (!boxes.length) return g.rows.filter((r) => r.st === 'now').map((r) => r.a.id);   // згорнуто — лише «зараз»
    return [...boxes].filter((b) => b.checked).map((b) => +b.dataset.id);
}
function paintN(card, g) {
    const n = picked(card, g).length;
    const btn = card.querySelector('[data-go]');
    btn.querySelector('[data-n]').textContent = n;
    btn.disabled = !n;
}
$('hhDue').addEventListener('click', async (e) => {
    const box = $('hhDue');
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = (box._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (!g) return;
    const go = e.target.closest('[data-go]');
    if (go) { e.stopPropagation(); conduct(g, picked(card, g)); return; }
    if (e.target.closest('input, a')) return;
    if (e.target.closest('[data-tog]')) {
        if (OPEN.has(card.dataset.k)) OPEN.delete(card.dataset.k); else OPEN.add(card.dataset.k);
        renderDue();
    }
});
$('hhDue').addEventListener('change', (e) => {
    const card = e.target.closest('.hh-step');
    if (!card) return;
    const g = ($('hhDue')._list || []).find((x) => sk(x.sc, x.st) === card.dataset.k);
    if (e.target.matches('[data-all]')) card.querySelectorAll('input[data-id]').forEach((b) => { b.checked = e.target.checked; });
    if (g) paintN(card, g);
});

let BUSY = false;
async function conduct(g, ids) {
    if (BUSY || !ids.length) return;
    if (!EVENT) { toast('Немає події «Вакцинація» — заведіть її в Конструкторі', 'error'); return; }
    const date = $('hhDate').value || iso(today());
    const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
    const ok = await confirmAction(`Внести «${EVENT.name}»${drug ? ` (${drug})` : ''} — крок «${g.st.name}» — ${ids.length} `
        + `${ids.length === 1 ? 'тварині' : 'тваринам'} за ${dmy(parseD(date))}?`, { ok: 'Провести', okClass: 'btn-primary' });
    if (!ok) return;
    BUSY = true;
    try {
        const inputs = { __vstep: sk(g.sc, g.st) };
        if (EVENT.drug_key) inputs[EVENT.drug_key] = g.st.drug || g.st.name;
        const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: ids, event_id: EVENT.id, event_date: date, inputs,
            note: [g.st.name, g.st.dose].filter(Boolean).join(' · '),
        });
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося провести', 'error'); return; }
        const bad = (r.failed || []).length, dup = (r.dupes || []).length;
        toast(`Проведено: ${r.applied || 0}` + (bad ? ` · не вдалося ${bad}: ${(r.failed || []).slice(0, 3).map((x) => `${x.tag} — ${x.error}`).join('; ')}` : '')
            + (dup ? ` · ${dup} уже мали цю подію щойно` : ''), bad ? 'error' : 'success');
        await loadDone();
        renderDue();
        renderHist();
    } finally { BUSY = false; }
}

/* ---------- «Проведені вакцинації»: одне проведення (день · крок чи препарат) — рядок; 15 останніх ---------- */
const HIST_OPEN = new Set();
function renderHist() {
    const byId = new Map(ANIMALS.map((a) => [a.id, a]));
    const groups = new Map();
    V.done().forEach((ev) => {
        const a = byId.get(ev.a);
        if (!a) return;
        const so = V.stepOf(a, ev);
        const key = `${ev.d}|${so ? sk(so.sc, so.st) : 'g:' + (ev.g || '')}`;
        if (!groups.has(key)) groups.set(key, { d: ev.d, so, g: ev.g, rows: [] });
        groups.get(key).rows.push(a);
    });
    const list = [...groups.values()].sort((x, y) => (x.d < y.d ? 1 : x.d > y.d ? -1 : 0));
    const total = list.reduce((t, g) => t + g.rows.length, 0);
    $('hhHistSum').textContent = list.length ? `${total} гол. · ${list.length} ${(list.length % 10 >= 1 && list.length % 10 <= 4 && !(list.length % 100 >= 11 && list.length % 100 <= 14)) ? 'проведення' : 'проведень'}` : '';
    if (!list.length) { $('hhHist').innerHTML = '<div class="hh-empty">Ще нічого не проведено.</div>'; return; }
    const shown = list.slice(0, 15);
    $('hhHist').innerHTML = `<table><thead><tr><th>Дата</th><th>Крок</th><th>Препарат</th><th class="hide-sm">Схема</th><th class="num">Голів</th></tr></thead><tbody>`
        + shown.map((g) => {
            const key = `${g.d}|${g.so ? sk(g.so.sc, g.so.st) : g.g}`;
            const open = HIST_OPEN.has(key);
            const drug = g.so ? [g.so.st.drug, g.so.st.dose].filter(Boolean).join(' · ') : (g.g || '');
            const tags = g.rows.slice().sort((x, y) => String(x.tag).localeCompare(String(y.tag), 'uk', { numeric: true }));
            return `<tr class="hh-hr" data-h="${escapeHtml(key)}"><td>${dmy(parseD(g.d))}</td>
                <td>${g.so ? `<b>${escapeHtml(g.so.st.name)}</b>` : '<span class="mute">поза схемою</span>'}</td>
                <td>${escapeHtml(drug)}</td><td class="hide-sm mute">${g.so ? escapeHtml(g.so.sc.name) : ''}</td>
                <td class="num">${g.rows.length} ${open ? '▾' : '▸'}</td></tr>`
                + (open ? `<tr><td colspan="5" class="tags">${tags.map((a) => `<a href="/herd/animals/${a.id}" title="${escapeHtml(a.name || '')}">${escapeHtml(a.tag || '')}</a>`).join('')}</td></tr>` : '');
        }).join('') + '</tbody></table>'
        + (list.length > 15 ? `<div class="hh-empty">Показано 15 останніх із ${list.length}.</div>` : '');
}
$('hhHist').addEventListener('click', (e) => {
    const tr = e.target.closest('tr.hh-hr');
    if (!tr) return;
    if (HIST_OPEN.has(tr.dataset.h)) HIST_OPEN.delete(tr.dataset.h); else HIST_OPEN.add(tr.dataset.h);
    renderHist();
});

/* ---------- схеми ---------- */
const sel = (opts, v, cls) => `<select class="hh-in ${cls}">${opts.map(([k, l]) => `<option value="${escapeHtml(k)}"${k === v ? ' selected' : ''}>${escapeHtml(l)}</option>`).join('')}</select>`;
function whoNote(sc) {
    if (!String(sc.who || '').trim()) return '<span class="ok">кого: усе стадо</span>';
    const q = whoQ(sc);
    if (q.error) return `<span class="msg">⚠ ${escapeHtml(q.error)}</span>`;
    const n = ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters)).length;
    return `<span class="ok">кого: ${n} гол.</span>`;
}
function stepRow(sc, st, i) {
    const prevs = sc.steps.slice(0, i).map((x) => [x.id, x.name || '—']);
    const bases = (prevs.length ? [['step', 'після кроку']] : []).concat(dateParams().map((p) => [p.key, p.label]));
    if (st.base !== 'step' && !bases.some((b) => b[0] === st.base)) bases.push([st.base, st.base]);   // параметр прибрали
    return `<tr data-st="${escapeHtml(st.id)}"${st.off ? ' class="is-off"' : ''}>
        <td><input class="hh-in w-sn" data-f="name" value="${escapeHtml(st.name || '')}" placeholder="Хіпра 1" maxlength="40"></td>
        <td><input class="hh-in w-drug" data-f="drug" value="${escapeHtml(st.drug || '')}" placeholder="Хіпрабовіс 4" maxlength="60"></td>
        <td><input class="hh-in w-dose" data-f="dose" value="${escapeHtml(st.dose || '')}" placeholder="3 мл" maxlength="20"></td>
        <td class="hh-base">${sel(bases, st.base, 'w-base" data-f="base')}${st.base === 'step' ? sel(prevs, st.prev, 'w-prev" data-f="prev') : ''}</td>
        <td title="Дні від дати; від’ємні — до неї (з -60 по -45 — за 60–45 днів до дати)"><span class="sep">з</span><input class="hh-in w-d" data-f="from" inputmode="numeric" value="${st.from}"><span class="sep">по</span><input class="hh-in w-d" data-f="to" inputmode="numeric" value="${st.to}"><span class="sep">день</span></td>
        <td><button type="button" class="hh-act${st.off ? '' : ' is-on'}" data-act title="Неактивний крок у «До вакцинації» і в vacc не рахується">${st.off ? 'неактивний' : 'активний'}</button></td>
        <td><button type="button" class="hh-x" data-delst title="Прибрати крок">✕</button></td></tr>`;
}
function renderSchemes() {
    const box = $('hhSchemes');
    if (!SCHEMES.length) { box.innerHTML = '<div class="hh-empty">Натисніть «+ схема»: назва, кого вакцинуємо, і кроки — препарат, доза, коли.</div>'; return; }
    if (!SCHEMES.some((x) => x.id === SEL)) SEL = SCHEMES[0].id;
    box.innerHTML = SCHEMES.map((sc) => `<div class="hh-sch${sc.id === SEL ? ' is-sel' : ''}" data-sc="${escapeHtml(sc.id)}">
        <div class="hh-sch-head">
            <input class="hh-in w-name" data-sf="name" value="${escapeHtml(sc.name || '')}" placeholder="Назва схеми" maxlength="60">
            <span class="hh-wn" data-whonote title="Кого вакцинуємо — умова у рядку формули вгорі (клацніть схему)">${whoNote(sc)}</span>
            <button type="button" class="hh-link" data-addst>+ крок</button>
            <button type="button" class="hh-x" data-delsc title="Видалити схему">✕</button>
        </div>
        <table class="hh-steps"><thead><tr><th>Крок</th><th>Препарат</th><th>Доза</th><th>Від чого рахувати</th><th>Коли</th><th></th><th></th></tr></thead>
            <tbody>${sc.steps.map((st, i) => stepRow(sc, st, i)).join('')}</tbody></table>
    </div>`).join('');
}
const scOf = (el) => SCHEMES.find((x) => x.id === el.closest('[data-sc]').dataset.sc);

let SAVE_T = 0, SAVE_SEQ = 0;
function saveSoon() { clearTimeout(SAVE_T); $('hhSaved').textContent = 'зберігаю…'; $('hhSaved').classList.remove('is-bad'); SAVE_T = setTimeout(save, 500); }
async function save() {
    const my = ++SAVE_SEQ;
    const bad = SCHEMES.find((sc) => whoQ(sc).error);   // бита умова «Кого» — не пишемо, доки не виправлять
    if (bad) {
        $('hhSaved').textContent = `⚠ «${bad.name}»: виправте умову «Кого» — не збережено`;
        $('hhSaved').classList.add('is-bad');
        return;
    }
    const r = await apiSend('/api/herd/vacc/schemes', 'POST', { schemes: SCHEMES }).catch(() => null);
    if (my !== SAVE_SEQ) return;
    if (!r || r.ok === false) {
        $('hhSaved').textContent = '⚠ ' + ((r && r.error) || 'не збереглося');
        $('hhSaved').classList.add('is-bad');
        return;
    }
    // сервер дає id новим — беремо їх, решту лишаємо як є (фокус у полі не губимо)
    (r.schemes || []).forEach((s2, i) => {
        const s1 = SCHEMES[i];
        if (!s1) return;
        if (s1.id !== s2.id) {
            const el = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"]`);
            if (SEL === s1.id) SEL = s2.id;
            s1.id = s2.id;
            if (el) el.dataset.sc = s2.id;
        }
        (s2.steps || []).forEach((t2, j) => { if (s1.steps[j] && s1.steps[j].id !== t2.id) s1.steps[j].id = t2.id; });
    });
    $('hhSaved').textContent = 'збережено';
    setTimeout(() => { if (my === SAVE_SEQ && !$('hhSaved').classList.contains('is-bad')) $('hhSaved').textContent = ''; }, 1500);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderDue();
    renderHist();                                  // назви кроків у журналі — свіжі
}
let NID = 0;
const nid = (p) => p + Date.now().toString(36) + (++NID);
$('hhAddScheme').addEventListener('click', () => {
    let name = 'Нова схема', i = 1;
    while (SCHEMES.some((s) => s.name === name)) name = `Нова схема ${++i}`;
    const sc = { id: nid('v'), name, who: '', off: 0, steps: [{ id: nid('k'), name: 'Крок 1', drug: '', dose: '', base: 'birth_date', prev: '', from: 0, to: 7 }] };
    SCHEMES.push(sc);
    SEL = sc.id;
    renderSchemes();
    fxRender();
    saveSoon();
    const els = document.querySelectorAll('#hhSchemes .w-name');
    const el = els[els.length - 1];
    if (el) { el.focus(); el.select(); }
});
$('hhSchemes').addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('[data-addst]')) {
        const sc = scOf(t);
        const last = sc.steps[sc.steps.length - 1];
        sc.steps.push({ id: nid('k'), name: `Крок ${sc.steps.length + 1}`, drug: last ? last.drug : '', dose: last ? last.dose : '',
            base: last ? 'step' : 'birth_date', prev: last ? last.id : '', from: last ? 21 : 0, to: last ? 28 : 7 });
        renderSchemes();
        saveSoon();
        return;
    }
    if (t.closest('[data-delst]')) {
        const sc = scOf(t);
        const id = t.closest('[data-st]').dataset.st;
        if (sc.steps.some((x) => x.base === 'step' && x.prev === id)) { toast('Від цього кроку рахується інший — спершу змініть той', 'error'); return; }
        sc.steps = sc.steps.filter((x) => x.id !== id);
        renderSchemes();
        saveSoon();
        return;
    }
    if (t.closest('[data-delsc]')) {
        const sc = scOf(t);
        if (!await confirmAction(`Видалити схему «${sc.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Видалити' })) return;
        SCHEMES = SCHEMES.filter((x) => x !== sc);
        renderSchemes();
        fxRender();
        saveSoon();
        return;
    }
    if (t.closest('[data-act]')) {
        const sc = scOf(t);
        const st = sc.steps.find((x) => x.id === t.closest('[data-st]').dataset.st);
        st.off = st.off ? 0 : 1;
        renderSchemes();
        saveSoon();
        return;
    }
});
/* клік чи фокус у схемі — її «Кого» в рядку формули вгорі */
function pickScheme(el) {
    const box = el && el.closest('[data-sc]');
    if (!box || box.dataset.sc === SEL) return;
    SEL = box.dataset.sc;
    $('hhSchemes').querySelectorAll('.hh-sch').forEach((x) => x.classList.toggle('is-sel', x.dataset.sc === SEL));
    fxRender();
}
$('hhSchemes').addEventListener('mousedown', (e) => pickScheme(e.target));
$('hhSchemes').addEventListener('focusin', (e) => pickScheme(e.target));
$('hhSchemes').addEventListener('change', (e) => {
    const t = e.target;
    const sc = scOf(t);
    if (!sc) return;
    if (t.dataset.sf) {
        sc[t.dataset.sf] = t.value.trim();
        saveSoon();
        return;
    }
    const tr = t.closest('[data-st]');
    if (!tr || !t.dataset.f) return;
    const st = sc.steps.find((x) => x.id === tr.dataset.st);
    const f = t.dataset.f;
    if (f === 'from' || f === 'to') {
        const n = parseInt(t.value, 10);
        if (!Number.isFinite(n)) { t.classList.add('is-bad'); return; }
        t.classList.remove('is-bad');
        st[f] = n;
    } else st[f] = t.value.trim();
    if (f === 'base') {
        if (st.base === 'step' && !st.prev) st.prev = (sc.steps[sc.steps.indexOf(st) - 1] || {}).id || '';
        renderSchemes();
    }
    if (f === 'name') renderSchemes();
    saveSoon();
});
$('hhSchemes').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches('input.hh-in')) { e.preventDefault(); e.target.blur(); }
});

/* ---------- рядок формули вгорі: «Кого» вибраної схеми ---------- */
let FX = null;
const FX_PH = 'FILTER(lact=0 rc<9) — кого вакцинує схема; Enter — записати';
const selSc = () => SCHEMES.find((x) => x.id === SEL) || null;
function fxMsg(t, bad) { $('hhFxMsg').textContent = t || ''; $('hhFxMsg').classList.toggle('bad', !!bad); }
function fxRender() {
    if (!FX) {
        FX = herdFxEdit($('hhFx'), {
            params: () => PARAMS,
            groups: () => [...new Set(ANIMALS.map((a) => a.group_name).filter(Boolean))],
            acts: ['FILTER'],
            placeholder: FX_PH,
            onEnter: () => fxApply(),
            onInput: () => { $('hhFx').classList.remove('is-bad'); fxMsg(''); },
        });
        FX.input.addEventListener('blur', () => { const sc = selSc(); if (sc && FX.get().trim() !== V.whoText(sc.who)) fxApply(); });
    }
    const sc = selSc();
    FX.input.disabled = !sc;
    FX.input.placeholder = sc ? FX_PH : 'Додайте схему — тут буде, кого вона вакцинує';
    FX.set(sc ? V.whoText(sc.who) : '');
    $('hhFx').classList.remove('is-bad');
    fxMsg(sc ? `Кого вакцинує «${sc.name}»` : '');
}
async function fxApply() {
    const sc = selSc();
    if (!sc) return;
    const text = window.herdQuery.canon(FX.get());
    let who = '';
    if (text) {
        if (!/^FILTER\s*\(/i.test(text) && /\(/.test(text)) { $('hhFx').classList.add('is-bad'); fxMsg('Кого — лише FILTER(…): BODY і VIEW тут не потрібні', true); return; }
        const f = /^FILTER\s*\(/i.test(text) ? text : `FILTER(${text})`;
        const q = window.herdQuery.parse(f, PARAMS);
        if (q.error) { $('hhFx').classList.add('is-bad'); fxMsg(q.error, true); return; }
        if ((q.keys || []).includes('vacc')) { $('hhFx').classList.add('is-bad'); fxMsg('Кого не може залежати від vacc', true); return; }
        if (q.cols.length || q.groups.length || q.sorts.length || (q.extra || []).length) {
            $('hhFx').classList.add('is-bad'); fxMsg('Кого — лише FILTER(…) з умовами', true); return;
        }
        who = f.replace(/^FILTER\s*\(/i, '').replace(/\)\s*$/, '').trim();
    }
    if (who === String(sc.who || '').trim()) { FX.set(V.whoText(who)); return; }
    sc.who = who;
    FX.set(V.whoText(who));
    V.setSchemes(SCHEMES);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    const note = document.querySelector(`[data-sc="${CSS.escape(sc.id)}"] [data-whonote]`);
    if (note) note.innerHTML = whoNote(sc);
    fxMsg(`Кого вакцинує «${sc.name}» — записано`);
    saveSoon();
}
/* рядок формули тримається вгорі під час прокрутки — як у «Роботі зі стадом» і Календарі */
(function () {
    const bar = $('hhFxTop');
    const topbar = document.querySelector('.topbar');
    if (!bar) return;
    let TOP = null, IO = null;
    const barTop = () => (topbar && getComputedStyle(topbar).position === 'sticky' ? topbar.offsetHeight : 0);
    function place() {
        const t = barTop();
        if (t === TOP) return;
        TOP = t;
        bar.style.top = (t - 1) + 'px';
        if (!window.IntersectionObserver) return;
        if (IO) IO.disconnect();
        IO = new IntersectionObserver(([en]) => { bar.classList.toggle('is-stuck', en.intersectionRatio < 1); },
            { threshold: [1], rootMargin: `${-t}px 0px 0px 0px` });
        IO.observe(bar);
    }
    place();
    window.addEventListener('resize', place);
    if (window.ResizeObserver && topbar) new ResizeObserver(place).observe(topbar);
}());

/* ---------- дані ---------- */
let LOADED = new Set();
async function loadAnimals() {
    const keys = needKeys().filter((k) => PARAMS.some((p) => p.key === k));
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(','))).catch(() => null);
    if (!r || !r.ok) { toast('Стадо не прочиталось — оновіть сторінку', 'error'); return; }
    ANIMALS = r.items || [];
    LOADED = new Set(needKeys());
}
async function loadDone() {
    const r = await V.load();
    if (!r) return false;
    EVENT = r.event || null;
    return r;
}
async function boot() {
    $('hhDate').value = iso(today());
    const [ev, v] = await Promise.all([apiGet('/api/herd/events?lite=1').catch(() => null), loadDone()]);
    if (!ev || !ev.ok || !v) { $('hhSum').textContent = 'Не вдалося завантажити'; return; }
    PARAMS = ev.params || [];
    V.use({ params: () => PARAMS });
    window.HERD_CONSTS = ev.consts || [];
    SCHEMES = V.normSchemes((v.schemes || []).map((s) => Object.assign({ steps: [] }, JSON.parse(JSON.stringify(s)))));
    V.setSchemes(SCHEMES);
    await loadAnimals();
    renderSchemes();
    fxRender();
    renderDue();
    renderHist();
}
boot();
})();
