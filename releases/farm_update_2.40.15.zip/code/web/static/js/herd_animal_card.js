/* Картка тварини: параметри плитками за секціями + історія подій. */
'use strict';

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
/* Дата по-людськи: 2024-08-23 → 23.08.2024 (Роман 2026-09-21 «переведи
   всю картку на формат дат»). Лише ПОКАЗ: у полях вводу, порівняннях і
   запитах до сервера дата лишається технічною (YYYY-MM-DD), інакше
   <input type="date"> перестане її приймати, а сортування посиплеться. */
/* Сьогодні за МІСЦЕВИМ часом. toISOString() віддає UTC, тож увечері за
   Києвом підставляв учорашнє число (той самий капкан, що колись зсував
   межі періодів в історії). */
function todayISO() {
    const d = new Date();
    const p = (x) => String(x).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function dmy(v) {
    const s = String(v == null ? '' : v).slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s.split('-').reverse().join('.') : s;
}

function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}
(function () {

const $ = (id) => document.getElementById(id);
let AID = window.ANIMAL_ID;

/* ── Швидке перемикання тварин ────────────────────────────────────────
   Роман 2026-09-16: «коли перемикаєш між тваринами, є мить оновлення, яка
   сповільнює роботу». Причина була не в обчисленнях (запити йдуть за
   десятки мілісекунд), а в самому перезавантаженні сторінки: браузер
   щоразу заново тягнув розмітку, стилі й шість скриптів, гасив екран і
   перемальовував усе — меню, шапку, підвал. Тепер сусідня тварина
   підмінює ЛИШЕ вміст картки, а дані сусідів підвозяться заздалегідь,
   тож перехід лягає в кадр. */
const CARD_CACHE = new Map();       // id → {a, p}; тримаємо останні 12
const CACHE_MAX = 12;

function cachePut(id, v) {
    CARD_CACHE.set(String(id), v);
    while (CARD_CACHE.size > CACHE_MAX) CARD_CACHE.delete(CARD_CACHE.keys().next().value);
}

async function fetchAnimal(id) {
    const hit = CARD_CACHE.get(String(id));
    if (hit) return hit;
    const [a, p] = await Promise.all([
        apiGet('/api/herd/animals/' + id),
        apiGet('/api/herd/animals/' + id + '/params'),
    ]);
    const v = { a, p };
    if (a && a.ok) cachePut(id, v);
    return v;
}
let PARAMS = [], CATS = {};
let PED = null;   // родовід: {sire, ancestors:[…], offspring:[…]}
let PED_TREE;     // дерево з племкниги предків: undefined — ще не питали
let ANIMAL = null;   // остання прочитана тварина — для перемалювання шапки
let CONFIG = false;   // режим налаштування показу полів

// кольори секцій (як у Подіях); невідомі — з палітри по черзі
const SEC_COLOR = {
    'Основне': '#2f5fb0', 'Відтворення': '#8a4fd0', 'Родовід': '#0e9aa7',
    "Здоров'я": '#1aa86b', 'Продуктивність': '#d08700',
};
const SEC_PALETTE = ['#2f5fb0', '#8a4fd0', '#0e9aa7', '#1aa86b', '#d08700', '#c0392b', '#5b7083', '#c2185b'];
function hexRgba(hex, a) {
    const h = hex.replace('#', '');
    const n = parseInt(h.length === 3 ? h.replace(/(.)/g, '$1$1') : h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
/* ── Налаштування показу — ОКРЕМЕ для биків, телиць і корів ───────────
   Роман 2026-09-16: «треба зробити налаштування окремо для (Бики-Телиці-
   Корови)». Різні тварини живуть різними числами: корові важать лактація
   й дні доїння, телиці — вік і осіменіння, бику ні те, ні те. Групу
   застосунок визначає сам (стать + чи були отели), перемикати нічого не
   треба: відкрив корову — бачиш налаштування корів.
   Ті самі три групи вже вживаються для показників біля подій. */
const GRPS = ['cow', 'heifer', 'bull'];
const GRP_NAME = { cow: 'корів', heifer: 'телиць', bull: 'биків' };
const animalGrp = (a) => (a && a.sex === 'M' ? 'bull'
    : ((a && +a.lactation_no > 0) ? 'cow' : 'heifer'));
let GRP = 'cow';                // група відкритої зараз тварини

/* Старий формат (спільний список на всіх) переносимо в усі три групи —
   інакше налаштоване раніше зникло б на очах. */
function byGroup(raw, fallback) {
    const out = {};
    let old = null;
    try { old = raw ? JSON.parse(raw) : null; } catch (e) { old = null; }
    GRPS.forEach((g) => {
        if (old && Array.isArray(old)) out[g] = old.slice();          // старий спільний
        else if (old && Array.isArray(old[g])) out[g] = old[g].slice();
        else out[g] = fallback(g);
    });
    return out;
}

// приховані ключі параметрів
const HIDE_KEY = 'farm:herd:cardHidden';
let HID_ALL = byGroup(localStorage.getItem(HIDE_KEY), () => []);
let HIDDEN = new Set();
function saveHidden() {
    HID_ALL[GRP] = [...HIDDEN];
    try { localStorage.setItem(HIDE_KEY, JSON.stringify(HID_ALL)); } catch (e) { /* ignore */ }
}

// Код країни для ідентифікаційного номера (вушна бирка). За замовч. UA.
const UIN_COUNTRIES = [
    ['UA', 'Україна'], ['DE', 'Німеччина'], ['FR', 'Франція'], ['DK', 'Данія'],
    ['NL', 'Нідерланди'], ['PL', 'Польща'], ['CZ', 'Чехія'], ['HU', 'Угорщина'],
    ['AT', 'Австрія'], ['SK', 'Словаччина'], ['IE', 'Ірландія'], ['GB', 'Великобританія'],
    ['IT', 'Італія'], ['ES', 'Іспанія'], ['US', 'США'], ['CA', 'Канада'],
];

/* Після будь-якої зміни даних читаємо ЗАНОВО: інакше картка показала б
   те, що лежить у кеші швидкого перемикання, і правка «не застосувалась» би
   на очах у людини. */
async function reload() {
    CARD_CACHE.delete(String(AID));
    return load();
}

async function load() {
    const want = AID;
    const { a, p } = await fetchAnimal(AID);
    if (want !== AID) return;          // поки чекали, встигли клацнути далі
    // параметри СПЕРШУ: з них беруться назви показників біля подій,
    // інакше історія малюється запасними підписами
    if (p.ok) { PARAMS = p.params || []; PARAMS_NOW = PARAMS; AT = ''; AT_LACT = null; }
    if (a.ok) {
        PHIST = a.param_hist || {}; SEX = a.sex || 'F';
        CUR_LACT = Number(a.lactation_no) || 0;
        PED = { self: a, sire: a.sire, dam: a.dam || null,
                ancestors: a.ancestors || [],
                offspring: a.offspring || [],
                insem: a.insem || null, pregInsem: a.preg_insem || null };
        renderHeader(a);
        // смужка гілки має показувати ТУ САМУ тварину, хоч куди ми зайшли:
        // стрілкою, пошуком, з родоводу чи кнопкою «назад» у браузері
        if (window.herdNav) window.herdNav.setCurrent({ id: AID, tag: a.tag, name: a.name });
    }
    if (p.ok) renderTiles();
}

/* ---------- шапка ----------
   Роман 2026-09-16: «кнопкою треба вибирати відображення основних даних по
   тварині». Смужка чіпів під іменем — не жорсткий набір: у режимі «⚙ Поля»
   до неї можна додати БУДЬ-ЯКИЙ параметр картки (репрокод, вагу, УІН) і
   прибрати зайве. Вибір спільний для всіх тварин — як і приховані поля. */
const CHIP_KEY = 'farm:herd:cardChips';
// вбудовані — те, що є в самій тварині, а не в параметрах
// Ключ, людська назва, звідки брати значення і ЯКИЙ параметр цей чіп
// заміняє: більшість із них є і серед параметрів, але тут значення
// зрозуміліше («04 · Група-3» замість коду, «В стаді» замість «active»),
// тож параметр-двійник у перелік не потрапляє.
const BUILTIN_CHIPS = [
    ['status', 'Статус', (a) => a.status_label, 'status'],
    // без порядкового номера секції (Роман 2026-09-16): у роботі секцію
    // називають словом, а «07 ·» лише додає шуму
    ['group', 'Група', (a) => a.group_name, 'group'],
    ['sex', 'Стать', (a) => herdOpt('sex', a.sex, a.sex === 'M' ? 'Чоловіча' : 'Жіноча'), 'sex'],
    ['age_m', 'Вік, міс', (a) => (a.age_months == null ? '' : a.age_months), 'age_months'],
    ['birth', 'Дата народження', (a) => dmy(a.birth_date), 'birth_date'],
    ['lact', '№ лактації', (a) => (a.lactation_no == null ? '' : a.lactation_no), 'lactation'],
];
/* Різні за замовчуванням, бо різне важить: корові — лактація і дні доїння,
   телиці — коли народилась і що з осіменінням, бику — вік. Усе це людина
   переставляє під себе; параметра, якого в господарстві немає, чіп просто
   не покаже. */
const CHIPS_DEFAULT = {
    // ⚠️ «Дата народження» потрібна і КОРОВІ (Роман 2026-09-21, дивлячись на
    // завезених із СТОВ «Промінь»: «немає дати народження»). Доти вона стояла
    // лише в телиці й бика, а після першого отелу тварина стає «коровою» —
    // і дата зникала з шапки, хоч у плитках лишалась.
    cow: ['status', 'group', 'age_m', 'birth', 'lact', 'dim', 'repro_code'],
    heifer: ['status', 'group', 'age_m', 'birth', 'repro_code'],
    bull: ['status', 'group', 'age_m', 'birth'],
};
let CHIPS_ALL = byGroup(localStorage.getItem(CHIP_KEY), (g) => CHIPS_DEFAULT[g].slice());
/* Разова доливка для тих, хто шапку вже налаштовував: інакше нова
   «Дата народження» дісталась би лише новим людям, а в того, хто колись
   відкривав «⚙ Поля», лишився б старий набір без неї.
   ⚠️ Доливаємо в УСІ ТРИ групи, а не лише коровам: до поділу на бики-
   телиці-корови набір був СПІЛЬНИЙ, і byGroup() роздає той старий список
   однаково всім трьом — тож у кого шапка налаштована здавна, дати немає
   і в телиці (Роман 2026-09-21: «22025 Сонатка — в неї немає дати
   народження», а вона телиця). Мітку ставимо один раз — прибрав дату
   свідомо, вона більше не повернеться. */
try {
    if (!localStorage.getItem('farm:herd:cardChips:birth2')) {
        let changed = false;
        GRPS.forEach((g) => {
            const set = CHIPS_ALL[g];
            if (!Array.isArray(set) || set.indexOf('birth') >= 0) return;
            const at = set.indexOf('age_m');
            set.splice(at < 0 ? set.length : at + 1, 0, 'birth');
            changed = true;
        });
        if (changed) localStorage.setItem(CHIP_KEY, JSON.stringify(CHIPS_ALL));
        localStorage.setItem('farm:herd:cardChips:birth2', '1');
    }
} catch (e) { /* приватне вікно — просто лишаємо як є */ }
let CHIPS = CHIPS_DEFAULT.cow.slice();
function saveChips() {
    CHIPS_ALL[GRP] = CHIPS.slice();
    try { localStorage.setItem(CHIP_KEY, JSON.stringify(CHIPS_ALL)); } catch (e) { /* ignore */ }
}

/* Перемкнути налаштування на групу відкритої тварини. Кличеться перед
   кожним малюванням шапки, тож перехід стрілкою з телиці на корову
   одразу міняє й смужку, і склад секцій. */
function useGroup(a) {
    GRP = animalGrp(a);
    HIDDEN = new Set(HID_ALL[GRP] || []);
    CHIPS = (CHIPS_ALL[GRP] || CHIPS_DEFAULT[GRP] || []).slice();
}

/* Усе, що МОЖНА поставити в шапку: вбудоване + параметри картки.
   Параметр, схований у плитках, у цей перелік однаково входить — шапка й
   плитки налаштовуються окремо (у шапці тримають найголовніше). */
/* Свої назви показників (Роман 2026-09-16: «хочу довільно змінювати назву,
   або ставити по дефолту як називається параметр насправді»). Порожньо —
   береться назва з Конструктора параметрів, тож перейменування там доходить
   у картку саме. Назви спільні для всіх груп: параметр один і той самий. */
const CHIP_NAME_KEY = 'farm:herd:cardChipNames';
let CHIP_NAMES = {};
try { CHIP_NAMES = JSON.parse(localStorage.getItem(CHIP_NAME_KEY) || '{}') || {}; } catch (e) { CHIP_NAMES = {}; }
function saveChipNames() {
    try { localStorage.setItem(CHIP_NAME_KEY, JSON.stringify(CHIP_NAMES)); } catch (e) { /* ignore */ }
}

/* Назва показника: своя → справжня назва параметра → запасна.
   ⚠️ Саме параметр, а не вигадане слово: підпис «Секція» над значенням
   параметра «Група» збивав з пантелику. */
function chipLabel(key, fallback) {
    const own = (CHIP_NAMES[key] || '').trim();
    if (own) return own;
    const b = BUILTIN_CHIPS.find(([k]) => k === key);
    const alias = b ? (b[3] || '') : '';
    const p = PARAMS.find((x) => x.key === (alias || key));
    return (p && p.label) || fallback || key;
}

function chipChoices(a) {
    /* ⚠️ Значення теж беремо з ПАРАМЕТРА, а не з зашитого тексту: інакше
       «Стать: Жіноча» лишалась би «Жіночою», навіть коли в Конструкторі
       опцію перейменували на «Теличку» (Роман 2026-09-16: «не з параметру
       тягнеться назва»). Власна функція лишається запасною — для того, чого
       серед параметрів немає (дата народження). */
    const out = BUILTIN_CHIPS.map(([key, label, get, alias]) => {
        const p = PARAMS.find((x) => x.key === (alias || key));
        const v = p ? valText(p) : '';
        return { key, label: chipLabel(key, label), value: v === '' ? get(a) : v };
    });
    // ⚠️ назва — тільки label: short у параметрах технічний («age», «gndr»,
    // «BCS»), і в шапці це виглядало б як код, а не як дані про тварину
    const taken = new Set(BUILTIN_CHIPS.flatMap(([k, , , alias]) => [k, alias]).filter(Boolean));
    PARAMS.forEach((p) => {
        if (taken.has(p.key)) return;
        out.push({ key: p.key, label: chipLabel(p.key, p.label), value: valText(p) });
    });
    return out;
}

function renderHeader(a) {
    ANIMAL = a;
    useGroup(a);
    $('acName').textContent = `${a.tag}${a.name ? ' «' + a.name + '»' : ''}`;
    const all = chipChoices(a);
    const byKey = {};
    all.forEach((c) => { byKey[c.key] = c; });
    if (CONFIG) {
        // у режимі налаштування показуємо ВСЕ, навіть порожнє: інакше поле
        // без значення неможливо було б наперед поставити в шапку
        // без цього підпису незрозуміло, чому в наступної тварини набір інший
        const head = `<span class="ac-chip-grp">Показ для ${GRP_NAME[GRP]}</span>`;
        $('acChips').innerHTML = head + all.map((c) => {
            const on = CHIPS.includes(c.key);
            const v = c.value === '' || c.value == null ? '—' : String(c.value);
            return `<span class="ac-chip cfg${on ? ' on' : ''}" data-chip="${escapeHtml(c.key)}">
                <input type="checkbox" ${on ? 'checked' : ''} tabindex="-1">
                <span class="ac-chip-lbl">${escapeHtml(c.label)}</span>: <b>${escapeHtml(v)}</b>
                <button type="button" class="ac-chip-ren" data-ren="${escapeHtml(c.key)}"
                        title="Змінити назву показника">✎</button></span>`;
        }).join('');
    } else {
        $('acChips').innerHTML = CHIPS.map((k) => {
            const c = byKey[k];
            if (!c || c.value === '' || c.value == null) return '';
            return `<span class="ac-chip" draggable="true" data-chip="${escapeHtml(c.key)}"
                title="Перетягніть, щоб поміняти показники місцями"
                ><i>${escapeHtml(c.label)}</i><b>${escapeHtml(String(c.value))}</b></span>`;
        }).join('');
    }
    renderEvents(a.events || []);
}


/* ═══ ПОРЯДОК ПОКАЗНИКІВ — ПЕРЕТЯГУВАННЯМ ═══
   Роман 2026-09-25: «треба зробити так, щоб можна було місцями міняти
   основні показники». Тягнемо просто в шапці: що бачиш, те й переставляєш
   (у режимі «⚙ Поля» перетягування вимкнене — там вибирають, ЩО показувати).
   ⚠️ Зберігати «те, що на екрані» НЕ МОЖНА: показники з порожнім значенням у
   шапку не потрапляють, і простий перепис списку з екрана ТИХО ВИКИНУВ БИ їх
   із налаштування. Тому новий порядок зшивається зі старим: невидимий
   показник лишається за тим самим сусідом, за яким і стояв. */
function chipsMerge(oldList, visNew) {
    const vis = new Set(visNew);
    const hidden = oldList.filter((k) => !vis.has(k));
    if (!hidden.length) return visNew.slice();
    const prevOf = new Map();                       // за ким стояв невидимий
    oldList.forEach((k, i) => {
        if (!vis.has(k)) prevOf.set(k, i > 0 ? oldList[i - 1] : null);
    });
    const out = [];
    const put = (h) => { if (!out.includes(h)) out.push(h); };
    hidden.forEach((h) => { if (prevOf.get(h) === null) put(h); });   // ті, що були першими
    visNew.forEach((k) => {
        put(k);
        hidden.forEach((h) => { if (prevOf.get(h) === k) put(h); });
    });
    hidden.forEach(put);                            // чий сусід зник зовсім
    return out;
}

(function () {
    const box = $('acChips');
    if (!box) return;
    let dragging = null;
    box.addEventListener('dragstart', (e) => {
        const c = e.target.closest('.ac-chip[data-chip]');
        if (!c || CONFIG) return;
        dragging = c;
        c.classList.add('is-drag');
        box.classList.add('is-sorting');
        try {
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', c.dataset.chip);
        } catch (_) { /* ignore */ }
    });
    box.addEventListener('dragover', (e) => {
        if (!dragging) return;
        e.preventDefault();
        const over = e.target.closest('.ac-chip[data-chip]');
        if (!over || over === dragging) return;
        const r = over.getBoundingClientRect();
        const after = (e.clientX - r.left) > r.width / 2;
        box.insertBefore(dragging, after ? over.nextSibling : over);
    });
    box.addEventListener('drop', (e) => { if (dragging) e.preventDefault(); });
    box.addEventListener('dragend', () => {
        if (!dragging) return;
        dragging.classList.remove('is-drag');
        box.classList.remove('is-sorting');
        dragging = null;
        const seen = Array.prototype.map.call(
            box.querySelectorAll('.ac-chip[data-chip]'), (x) => x.dataset.chip);
        CHIPS = chipsMerge(CHIPS, seen);
        saveChips();
    });
}());

// перемикання чіпа в режимі налаштування
$('acChips').addEventListener('click', (e) => {
    if (!CONFIG) return;
    const ren = e.target.closest('[data-ren]');
    if (ren) { e.stopPropagation(); renameChip(ren.dataset.ren); return; }
    const el = e.target.closest('[data-chip]');
    if (!el) return;
    const k = el.dataset.chip;
    const i = CHIPS.indexOf(k);
    if (i >= 0) CHIPS.splice(i, 1); else CHIPS.push(k);
    saveChips();
    if (ANIMAL) renderHeader(ANIMAL);
});

/* Перейменування просто в чіпі: підпис стає полем. Порожньо — повертається
   назва з Конструктора параметрів (тобто «як параметр зветься насправді»). */
function renameChip(key) {
    const chip = $('acChips').querySelector(`[data-chip="${CSS.escape(key)}"]`);
    const lbl = chip && chip.querySelector('.ac-chip-lbl');
    if (!lbl || lbl.querySelector('input')) return;
    const was = lbl.textContent;
    lbl.innerHTML = '<input class="ac-chip-inp" type="text">';
    const inp = lbl.querySelector('input');
    inp.value = (CHIP_NAMES[key] || '').trim() || was;
    inp.placeholder = chipLabel(key, was);
    inp.focus(); inp.select();
    let done = false;
    const finish = (save) => {
        if (done) return; done = true;
        if (save) {
            const v = inp.value.trim();
            if (v && v !== chipLabel(key, was)) CHIP_NAMES[key] = v;
            else delete CHIP_NAMES[key];      // порожньо або як було — назва параметра
            saveChipNames();
        }
        if (ANIMAL) renderHeader(ANIMAL);
    };
    inp.addEventListener('keydown', (ev) => {
        ev.stopPropagation();
        if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
        else if (ev.key === 'Escape') { finish(false); }
    });
    inp.addEventListener('blur', () => finish(true));
    inp.addEventListener('click', (ev) => ev.stopPropagation());
}

/* Історія ділиться на лактації: лактація N починається її отелом і триває
   до наступного. Події до першого отелу — період телиці. За замовчуванням
   показуємо останню лактацію (слово Романа). */
let EVENTS = [], LACTS = [], LACT_SEL = null, CAT_SEL = 'all';
/* Обрана лактація — і параметри станом на її кінець (Роман 2026-09-19:
   «при перемиканні між лактаціями дані по відтворенню, основні параметри,
   здоровʼя, продуктивність — по тій лактації»). AT — дата стану ('' — сьогодні),
   PARAMS_NOW — поточні параметри, до яких повертаємось. */
let AT = '', AT_LACT = null, PARAMS_NOW = null, atSeq = 0;
function lactEnd(n) {
    if (n === 'all' || n === null) return '';
    const l = LACTS.find((x) => x.n === n);
    if (!l || l === LACTS[LACTS.length - 1] || !l.to || l.to >= '9999') return '';   // поточна
    const d = new Date(l.to + 'T00:00:00');
    d.setDate(d.getDate() - 1);                  // останній день перед наступним отелом
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
async function applyLactParams() {
    const at = lactEnd(LACT_SEL);
    const my = ++atSeq;
    if (!at) {
        AT = ''; AT_LACT = null;
        if (PARAMS_NOW) PARAMS = PARAMS_NOW;
        renderTiles();
        return;
    }
    const r = await apiGet(`/api/herd/animals/${AID}/params?at=${at}`);
    if (my !== atSeq) return;                    // встигли обрати іншу
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося прочитати стан на дату', 'error'); return; }
    AT = at; AT_LACT = LACT_SEL;
    PARAMS = r.params || [];
    renderTiles();
}
let PHIST = {};                 // історія значень параметрів: {ключ: [{d,v}]}
const CAT_NAMES = window.EVENT_CATS || {};
// Які показники показувати біля події. Набір спільний для всіх тварин і
// може бути СВІЙ для кожного типу події: {_all: […], calving: […], …}.
const DET_KEY = 'farm:herd:evDetails';
// Ключі набору: «cow:_all», «heifer:insem» тощо. Телицею вважаємо період
// до першого отелу (лактація 0) — там свої показники, у корів свої.
let DETS = { 'cow:_all': ['lact', 'dim'], 'heifer:_all': ['age_m'],
             'bull:_all': ['age_m'] };
let SEX = 'F';                  // стать тварини — бичків не ділимо на лактації
let CUR_LACT = 0;               // № лактації тварини зараз — від нього нумеруються лактації
let DET_EV = '_all';            // яку подію налаштовуємо у відкритому меню
let DET_GRP = '';               // яку групу налаштовуємо (порожньо — за твариною)
try {
    const raw = localStorage.getItem(DET_KEY);
    if (raw) {
        const v = JSON.parse(raw);
        if (Array.isArray(v)) DETS = { 'cow:_all': v, 'heifer:_all': v.slice() };
        else if (v && typeof v === 'object') {
            DETS = v;
            if (v._all && !v['cow:_all']) {          // старий спільний набір
                DETS['cow:_all'] = v._all;
                DETS['heifer:_all'] = v._all.slice();
            }
        }
    }
} catch (e) { /* ignore */ }
['cow', 'heifer', 'bull'].forEach((g) => {
    if (!DETS[`${g}:_all`]) DETS[`${g}:_all`] = [];
});
// група тварини на момент події: бичок · телиця (до отелу) · корова
const grpOf = (e) => (SEX === 'M' ? 'bull'
    : ((e && e.at && +e.at.lact > 0) ? 'cow' : 'heifer'));
function detFor(grp, evKey) {
    const own = DETS[`${grp}:${evKey}`];
    if (Array.isArray(own)) return own;
    return DETS[`${grp}:_all`] || [];
}
function detSave() {
    try { localStorage.setItem(DET_KEY, JSON.stringify(DETS)); } catch (e) { /* ignore */ }
}
// вбудовані показники «на момент події»
// Показники «на момент події». `p` — параметр стада, звідки беруться назви:
// перейменували в Конструкторі — змінилось і тут (слово Романа: «саме DIM
// немає такої назви ніде»). Підписи нижче — запасні, якщо параметра немає.
const AT_FIELDS = [
    { k: 'lact', p: 'lactation', label: '№ лактації', short: 'лакт.' },
    { k: 'dim', p: 'dim', label: 'Днів лактації (DIM)', short: 'DIM' },
    { k: 'dpreg', p: 'days_preg', label: 'Днів тільності', short: 'тільн.' },
    { k: 'age_m', p: 'age_months', label: 'Вік, міс', short: 'вік' },
    { k: '_note', label: 'Ремарка (нотатка події)', short: '' },
];
// назва показника: коротка — для рядка історії, повна — для меню й підказки
function atShort(f) {
    const p = f.p && PARAMS.find((x) => x.key === f.p);
    return (p && (p.short || p.label)) || f.short;
}
function atLabel(f) {
    const p = f.p && PARAMS.find((x) => x.key === f.p);
    return (p && p.label) || f.label;
}

function buildLacts(evs) {
    const calv = evs.filter((e) => e.def_key === 'calving')
        .map((e) => (e.event_date || '').slice(0, 10)).filter(Boolean).sort();
    // номер — справжній № лактації: у тварини, заведеної дорослою, ранні
    // отели не записані, і перший записаний — це вже не 1-ша лактація
    const off = Math.max(0, (CUR_LACT || calv.length) - calv.length);
    LACTS = calv.map((from, i) => ({ n: off + i + 1, from, to: calv[i + 1] || '9999-12-31' }));
    // до першого записаного отелу: телиця, а якщо ранні отели не записані — «раніше»
    if (calv.length && evs.some((e) => (e.event_date || '').slice(0, 10) < calv[0]))
        LACTS.unshift({ n: off, from: '', to: calv[0], pre: true });
    // за замовчуванням — остання лактація
    const last = LACTS.length ? LACTS[LACTS.length - 1].n : null;
    if (LACT_SEL === null || !LACTS.some((l) => l.n === LACT_SEL)) LACT_SEL = last;
}

function evsOfLact(n) {
    if (n === 'all' || n === null) return EVENTS;
    const l = LACTS.find((x) => x.n === n);
    if (!l) return EVENTS;
    return EVENTS.filter((e) => {
        const d = (e.event_date || '').slice(0, 10);
        return d && d >= (l.from || '') && (l.n === 0 ? d < l.to : d < l.to);
    });
}
const catOf = (e) => e.category || 'other';

// значення параметра, чинне НА ДАТУ події (останній запис до неї включно)
function paramAt(key, day) {
    const lst = PHIST[key] || [];
    let v = '';
    for (const r of lst) { if (r.d <= day) v = r.v; else break; }
    return v;
}

// підпис показників біля події
function atBadges(e) {
    const keys = detFor(grpOf(e), e.def_key || '');
    if (!keys.length) return '';
    const day = (e.event_date || '').slice(0, 10);
    const at = e.at || {};
    const out = [];
    keys.forEach((k) => {
        if (k === '_note') {                       // ремарка — окремо
            const n = (e.note || '').trim();
            if (n) out.push(`<span class="ac-ev-note">${escapeHtml(n)}</span>`);
            return;
        }
        // у рядку — КОРОТКА назва, повна спливає підказкою (слово Романа)
        const badge = (shortNm, fullNm, v) => {
            const tip = (fullNm && fullNm !== shortNm)
                ? ` class="ev-hint" data-tip="${escapeHtml(fullNm)}"` : '';
            return `<span><span${tip}>${escapeHtml(shortNm)}</span>`
                + ` <b>${escapeHtml(String(v))}</b></span>`;
        };
        const f = AT_FIELDS.find((x) => x.k === k);
        if (f) {
            const v = at[k];
            if (v !== undefined && v !== null && v !== '')
                out.push(badge(atShort(f), atLabel(f), v));
            return;
        }
        const p = PARAMS.find((x) => x.key === k);
        const v = paramAt(k, day);
        // код довідника / списку — назвою («3» → «Петренко Сергій»)
        const opt = k !== 'repro_code' && p && Array.isArray(p.options) && p.options.find((o) => String(o.c) === String(v));
        const shown = (opt && opt.l) || (p && p.dtype === 'date' ? dmy(v) : v);
        if (v) out.push(badge((p && (p.short || p.label)) || k, p && p.label, shown));
    });
    return out.length ? `<span class="ac-ev-at">${out.join('')}</span>` : '';
}

// Параметри в меню ⚙ — за секціями картки (Основне, Відтворення…) і за
// абеткою всередині: плаский список на тридцять рядків не читається.
function paramGroupsHtml(keys, item) {
    if (!keys.length) return '';
    const order = [];
    const bySec = {};
    PARAMS.forEach((p) => {                       // порядок секцій — як у картці
        if (!keys.includes(p.key)) return;
        const sec = p.section || 'Інше';
        if (!bySec[sec]) { bySec[sec] = []; order.push(sec); }
        bySec[sec].push(p);
    });
    const known = new Set(PARAMS.map((p) => p.key));
    const rest = keys.filter((k) => !known.has(k));
    if (rest.length) { bySec['Інше'] = bySec['Інше'] || []; if (!order.includes('Інше')) order.push('Інше'); }
    let html = '';
    order.forEach((sec) => {
        const list = (bySec[sec] || []).slice()
            .sort((a, b) => (a.label || '').localeCompare(b.label || '', 'uk'));
        if (!list.length && sec !== 'Інше') return;
        html += `<div class="h" style="margin-top:6px">${escapeHtml(sec)}</div>`
            + list.map((p) => item(p.key, p.label || p.key)).join('');
        if (sec === 'Інше') html += rest.map((k) => item(k, k)).join('');
    });
    return html;
}

/* меню «⚙ Деталі»: показники окремо для телиці й корови, окремо для події */
function renderDetMenu() {
    const box = $('acDetMenu');
    if (!box) return;
    // типи подій цієї тварини у вибраній групі (телиця / корова)
    const types = [];
    EVENTS.forEach((e) => {
        if (grpOf(e) !== DET_GRP) return;
        const k = e.def_key || '';
        if (k && !types.some((t) => t.k === k)) types.push({ k, name: e.event_type || k });
    });
    types.sort((a, b) => a.name.localeCompare(b.name, 'uk'));
    if (DET_EV !== '_all' && !types.some((t) => t.k === DET_EV)) DET_EV = '_all';
    const own = DET_EV !== '_all' && Array.isArray(DETS[`${DET_GRP}:${DET_EV}`]);
    const cur = detFor(DET_GRP, DET_EV === '_all' ? '__none__' : DET_EV);
    const item = (k, label) =>
        `<label class="ac-det-item"><input type="checkbox" data-k="${escapeHtml(k)}"`
        + `${cur.includes(k) ? ' checked' : ''}> ${escapeHtml(label)}</label>`;
    // ті самі величини вже стоять у «На момент події» — не двоїмо
    const atKeys = new Set(AT_FIELDS.map((f) => f.p).filter(Boolean));
    // усі параметри, які вносяться (не формули), — навіть якщо в цієї тварини
    // ще не записані: набір діє й на інших («Технік» при осіменінні)
    const withHist = [...new Set(Object.keys(PHIST).filter((k) => (PHIST[k] || []).length)
        .concat(PARAMS.filter((x) => !x.computed).map((x) => x.key)))]
        .filter((k) => !atKeys.has(k));
    if (!DET_GRP) DET_GRP = grpOf(EVENTS[0] || {});
    const GRPS = [['heifer', 'телиця'], ['cow', 'корова'], ['bull', 'бичок']];
    box.innerHTML = '<div class="ac-det-grp">'
        + GRPS.map(([g, nm]) => `<button type="button" data-g="${g}"`
            + `${DET_GRP === g ? ' class="on"' : ''}>${nm}</button>`).join('')
        + '</div>'
        + '<div class="ac-det-top">'
        + '<select id="acDetEv">'
        + `<option value="_all"${DET_EV === '_all' ? ' selected' : ''}>усі події</option>`
        + types.map((t) => `<option value="${escapeHtml(t.k)}"`
            + `${t.k === DET_EV ? ' selected' : ''}>${escapeHtml(t.name)}`
            + `${Array.isArray(DETS[`${DET_GRP}:${t.k}`]) ? ' •' : ''}</option>`).join('')
        + '</select>'
        + (own ? '<button type="button" class="hp-link" id="acDetReset">як у всіх</button>' : '')
        + '</div>'
        + (DET_EV !== '_all' && !own
            ? '<div class="ac-det-note">зараз як у всіх — познач щось, щоб задати своє</div>'
            : (types.length ? ''
                : '<div class="ac-det-note">у цієї тварини таких подій немає — '
                  + 'набір діятиме на інших</div>'))
        + '<div class="h">На момент події</div>'
        + AT_FIELDS.map((f) => item(f.k, atLabel(f))).join('')
        + paramGroupsHtml(withHist, item);
    box.querySelectorAll('.ac-det-grp button').forEach((b) => b.addEventListener('click', () => {
        DET_GRP = b.dataset.g; DET_EV = '_all'; renderDetMenu();
    }));
    $('acDetEv').addEventListener('change', () => { DET_EV = $('acDetEv').value; renderDetMenu(); });
    const rst = $('acDetReset');
    if (rst) rst.addEventListener('click', () => {
        delete DETS[`${DET_GRP}:${DET_EV}`]; detSave(); renderDetMenu(); renderEvents();
    });
    box.querySelectorAll('input[data-k]').forEach((c) => c.addEventListener('change', () => {
        const k = c.dataset.k;
        const key = DET_EV === '_all' ? `${DET_GRP}:_all` : `${DET_GRP}:${DET_EV}`;
        const base = (DETS[key] || cur).slice();
        DETS[key] = c.checked ? base.concat([k]) : base.filter((x) => x !== k);
        detSave(); renderDetMenu(); renderEvents();
    }));
}

/* «усі 22 події», а не «всі 22 подій» — число керує формою слова. */
function evWord(n) {
    const t = Math.abs(n) % 100, o = t % 10;
    if (t > 10 && t < 20) return 'усі ' + n + ' подій';
    if (o === 1) return 'усю ' + n + ' подію';
    if (o >= 2 && o <= 4) return 'усі ' + n + ' події';
    return 'усі ' + n + ' подій';
}

function renderEvents(evs) {
    if (evs) { EVENTS = evs; buildLacts(evs); }
    const inLact = evsOfLact(LACT_SEL);
    // читаємо як літопис: найстаріші зліва вгорі, далі вниз і в праву колонку.
    // ⚠️ В ОДИН ДЕНЬ порядок не за номером запису, а за змістом: народження —
    // завжди перше, вибуття — завжди останнє (Роман 2026-09-21: «народження
    // саме перше»). Інакше зважування новонародженого, внесене раніше за саму
    // подію народження, ставало над нею, ніби тварину зважили до того, як
    // вона народилась.
    const dayRank = (e) => (e.def_key === 'birth' ? 0 : (e.def_key === 'cull' ? 2 : 1));
    const list = (CAT_SEL === 'all' ? inLact : inLact.filter((e) => catOf(e) === CAT_SEL))
        .slice().sort((a, b) => {
            const da = (a.event_date || ''), db2 = (b.event_date || '');
            if (da !== db2) return da < db2 ? -1 : 1;
            const ra = dayRank(a), rb = dayRank(b);
            return ra === rb ? (a.id || 0) - (b.id || 0) : ra - rb;
        });
    const chip = (n, label, title) =>
        `<button type="button" class="ac-lact${n === LACT_SEL ? ' on' : ''}"
                 data-l="${n}" title="${escapeHtml(title)}">${escapeHtml(label)}</button>`;
    let bar = '';
    if (LACTS.length > 1) {
        bar = '<div class="ac-lact-bar">' + LACTS.map((l) => (l.pre
            ? chip(l.n, l.n === 0 ? herdOpt('repro_code', '0', 'телиця') : 'раніше',
                l.n === 0 ? herdLabel('lactation', '№ лактації') + ' 0'
                    : `до ${dmy(l.to)}: лактація ${l.n} і раніше — ранні отели не записані`)
            : chip(l.n, 'лакт. ' + l.n, `з ${dmy(l.from)}`))).join('')
            + chip('all', 'усі', 'уся історія') + '</div>';
    }
    // фільтр за категоріями — лише ті, що є в обраному періоді
    const cnt = {};
    inLact.forEach((e) => { const c = catOf(e); cnt[c] = (cnt[c] || 0) + 1; });
    const cats = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a]);
    if (cats.length > 1) {
        const cchip = (c, label, n) =>
            `<button type="button" class="ac-cat ev-c-${escapeHtml(c)}${c === CAT_SEL ? ' on' : ''}"
                     data-c="${escapeHtml(c)}">${escapeHtml(label)}`
            + (n ? `<span class="ac-cat-n">${n}</span>` : '') + '</button>';
        bar += '<div class="ac-cat-bar">'
            + cchip('all', 'усі події', inLact.length)
            + cats.map((c) => cchip(c, CAT_NAMES[c] || c, cnt[c])).join('') + '</div>';
    } else if (CAT_SEL !== 'all') {
        CAT_SEL = 'all';
    }
    /* Лічильник має пояснювати САМ СЕБЕ. «7 з 17» викликало питання
       (Роман 2026-09-16: «чому пише так?») — з нього не видно, що список
       звужено фільтром: картка відкривається на останній лактації, а не на
       всій історії. Тепер поруч написано, ЩО саме показано. */
    const el = $('acEvCount');
    const why = [];
    if (LACTS.length > 1 && LACT_SEL !== 'all') {
        why.push(LACT_SEL === 0 ? herdOpt('repro_code', '0', 'телиця').toLowerCase()
            : herdLabel('lactation', '№ лактації') + ' ' + LACT_SEL);
    }
    if (CAT_SEL !== 'all') why.push((CAT_NAMES[CAT_SEL] || CAT_SEL).toLowerCase());
    if (!EVENTS.length) {
        el.textContent = '';
        el.title = '';
    } else if (list.length !== EVENTS.length) {
        el.textContent = `· ${list.length} із ${EVENTS.length}`
            + (why.length ? ' · ' + why.join(' · ') : '');
        el.title = 'Показано не всю історію. Щоб побачити '
            + evWord(EVENTS.length) + ', натисніть «усі».';
    } else {
        el.textContent = '· ' + EVENTS.length;
        el.title = 'Уся історія тварини';
    }

    const row = (e) => `
        <div class="ac-ev-row" data-ev="${e.id}">
            <span class="ac-ev-date">${escapeHtml(dmy(e.event_date))}</span>
            <span class="ac-ev-type ev-c-${escapeHtml(e.category || 'other')}">${escapeHtml(e.event_type || '')}</span>
            <span class="ac-ev-body">${(e.ref_tag ? escapeHtml(e.ref_tag) + ' · ' : '')}`
            + `${e.details_html || escapeHtml(e.details || '')}${atBadges(e)}</span>
            <button type="button" class="ac-ev-edit" title="Виправити подію — дату й усі її поля">✎</button>
            <button type="button" class="ac-ev-del" title="Видалити подію">✕</button>
        </div>`;
    // Скільки днів минуло від попередньої події (список іде від новіших
    // до старіших, тож рахуємо різницю з рядком вище).
    const dnum = (e) => {
        const d = (e.event_date || '').slice(0, 10);
        return d ? Math.floor(new Date(d + 'T00:00:00').getTime() / 86400000) : null;
    };
    const gap = (prev, cur) => {
        const a = dnum(prev), b = dnum(cur);
        if (a === null || b === null) return '';
        const n = b - a;                          // список іде від старіших
        if (n <= 0) return '';                    // той самий день
        return `<div class="ac-ev-gap"><span>${n}</span></div>`;
    };
    const chunk = (arr) => arr.map((e, i) =>
        (i ? gap(arr[i - 1], e) : '') + row(e)).join('');
    // Дві колонки, як дві сторінки на аркуші: перша половина ліворуч,
    // друга праворуч — довга історія не тягнеться вниз екрана.
    let rows;
    if (!list.length) {
        rows = '<p class="text-mute" style="padding:8px 0;">За цей період подій немає.</p>';
    } else {
        const half = Math.ceil(list.length / 2);
        const left = list.slice(0, half), right = list.slice(half);
        // розрив на переході колонок лишаємо ВНИЗУ лівої — ланцюг днів
        // дочитується там, де обривається список
        const bridge = right.length ? gap(left[left.length - 1], right[0]) : '';
        rows = '<div class="ac-ev-cols">'
            + `<div class="ac-ev-col">${chunk(left)}${bridge}</div>`
            + `<div class="ac-ev-col">${chunk(right)}</div>`
            + '</div>';
    }
    // фільтри живуть у шапці панелі, під нею — самі записи
    $('acEvFilters').innerHTML = bar;
    $('acEvents').innerHTML = rows;
    $('acEvents').querySelectorAll('.ac-ev-del').forEach((b) =>
        b.addEventListener('click', () => delEvent(b.closest('.ac-ev-row'))));
    $('acEvents').querySelectorAll('.ac-ev-edit').forEach((b) =>
        b.addEventListener('click', () => editEvent(b.closest('.ac-ev-row'))));
    $('acEvFilters').querySelectorAll('.ac-lact').forEach((b) => b.addEventListener('click', () => {
        LACT_SEL = b.dataset.l === 'all' ? 'all' : +b.dataset.l;
        renderEvents();
        applyLactParams();      // параметри й крива — по обраній лактації
    }));
    $('acEvFilters').querySelectorAll('.ac-cat').forEach((b) => b.addEventListener('click', () => {
        CAT_SEL = b.dataset.c;
        renderEvents();
    }));
}

/* ---------- плитки параметрів ---------- */
/* Довгий номер очима не прочитати суцільним рядком: 296297008766 проти
   296 297 008 766 (Роман 2026-09-16 про транспондер). Ділимо по три цифри
   з кінця — і лише ЦІЛІ номери від девʼяти цифр, щоб вага чи вік лишались
   як були. Пробіл нерозривний: номер не має переноситись посередині. */
const NBSP = '\u00a0';
function groupDigits(v) {
    const t = String(v);
    if (!/^\d{9,}$/.test(t)) return t;
    return t.replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
}

/* У числове поле мають потрапляти лише цифри (для дробових — ще кома).
   Курсор при цьому не стрибає: рахуємо, скільки зайвих знаків прибрали
   ліворуч від нього. */
function numOnly(el, allowDot) {
    el.addEventListener('input', () => {
        const pos = el.selectionStart;
        const before = el.value;
        const ok = allowDot ? /[^\d.,]/g : /[^\d]/g;
        const after = before.replace(ok, '');
        if (after === before) return;
        const cut = before.slice(0, pos).replace(ok, '').length;
        el.value = after;
        el.setSelectionRange(cut, cut);
    });
}

function valText(p) {
    if (p.value === '' || p.value == null) return '';
    if (p.dtype === 'date') return dmy(p.value);
    if (p.dtype === 'bool') return p.value === '1' || p.value === 1 ? 'Так' : 'Ні';
    if (p.dtype === 'int') return groupDigits(p.value);
    const numv = numText(p.value, p.dtype);
    if (numv !== null) return numv;
    if (p.key === 'repro_code') return String(p.value);   // код цілим числом, назва — у «Репродуктивний статус»
    // довідник читається назвою: «S-21 — Соболь», а не голим кодом
    if (['cod', 'code', 'ref'].includes(p.dtype) && p.value_label) {
        // ⚠️ але СЛУЖБОВИЙ код показувати нема сенсу: «5 — Тільна» і
        // «E-44 — Ерік» людина впізнає за кодом, а «active — В стаді» — це
        // внутрішнє слово програми (Роман 2026-09-16 спитав, що воно таке).
        // Ознака: код без жодної цифри й самою латиницею.
        if (/^[A-Za-z_]+$/.test(String(p.value))) return p.value_label;
        return `${p.value} — ${p.value_label}`;
    }
    return String(p.value);
}
/* Згорнуті плитки (Роман 2026-09-16: «таблицю параметрів скривати
   розкривати»). Ключ — заголовок плитки, стан спільний для всіх тварин:
   згорнув «Родовід» — він згорнутий і в наступної. */
const FOLD_KEY = 'farm:herd:cardFolded';
let FOLDED = new Set();
try { FOLDED = new Set(JSON.parse(localStorage.getItem(FOLD_KEY) || '[]')); } catch (e) { /* ignore */ }
function saveFolded() {
    try { localStorage.setItem(FOLD_KEY, JSON.stringify([...FOLDED])); } catch (e) { /* ignore */ }
}

// вибрана сторінка (секція) картки — спільна для всіх тварин
const TAB_KEY = 'farm:herd:cardTab';
let TAB = '';
try { TAB = localStorage.getItem(TAB_KEY) || ''; } catch (e) { /* ignore */ }

function renderTiles() {
    const bySec = {}; const order = [];
    PARAMS.forEach((p) => {
        if (!bySec[p.section]) { bySec[p.section] = []; order.push(p.section); }
        bySec[p.section].push(p);
    });
    if (!order.length) { $('acParams').innerHTML = ''; return; }
    if (!order.includes(TAB)) TAB = order[0];
    const colorOf = (sec) => SEC_COLOR[sec] || SEC_PALETTE[order.indexOf(sec) % SEC_PALETTE.length];

    // перемикач сторінок картки
    const tabs = `<div class="ac-tabs">` + order.map((sec) => {
        const c = colorOf(sec);
        return `<button type="button" class="ac-tab${sec === TAB ? ' on' : ''}"
            style="--sec:${c};--sec-bg:${hexRgba(c, 0.12)}" data-tab="${escapeHtml(sec)}">
            ${escapeHtml(sec)}</button>`;
    }).join('') + '</div>';

    const atBar = (AT && !CONFIG)
        ? `<div class="ac-at">Стан на кінець ${AT_LACT === 0 ? 'періоду до першого отелу'
            : AT_LACT + '-ї лактації'} · <b>${dmy(AT)}</b> — день перед наступним отелом
            <button type="button" class="hp-link" id="acAtNow">показати сьогоднішній</button></div>`
        : '';
    const hint = CONFIG
        ? `<p class="ac-cfg-hint">Режим налаштування — <b>для ${GRP_NAME[GRP]}</b>: у смужці вгорі познач, що показувати про тварину, нижче — які параметри тримати в секціях. Олівцем ✎ на показнику міняється його назва (порожньо — повернеться назва з Конструктора). Бики, телиці й корови налаштовуються окремо. Натисни «⚙ Поля» ще раз, щоб завершити.</p>`
        : '';
    const sec = TAB;
    const color = colorOf(sec);
    // на «Родоводі» Мати й Батько вже показує саме дерево — не дублюємо рядками
    const inTree = (sec === 'Родовід' && !CONFIG)
        ? new Set(['dam_tag', 'sire_code']) : new Set();
    const list = CONFIG ? bySec[sec]
        : bySec[sec].filter((p) => !HIDDEN.has(p.key) && !inTree.has(p.key));
    const rows = list.map((p) => {
        const hidden = HIDDEN.has(p.key);
        if (CONFIG) {
            return `<div class="ac-row cfg ${hidden ? 'hiddenp' : ''}" data-cfg="${escapeHtml(p.key)}">
                <input type="checkbox" class="ac-vis" ${hidden ? '' : 'checked'}>
                <span class="k">${escapeHtml(p.label)}</span>
            </div>`;
        }
        const txt = valText(p);
        const cls = p.computed ? 'auto' : (txt ? '' : 'empty');
        // одиниця вимірювання стосується чисел; у коду й довідника її немає
        const hasUnit = txt && p.unit && !['cod', 'code', 'ref', 'bool', 'date']
            .includes(p.dtype);
        const unit = hasUnit ? ` <span class="u">${escapeHtml(p.unit)}</span>` : '';
        // у минулій лактації вписувати нічого — порожнє там просто «—»
        const disp = txt ? escapeHtml(txt) + unit : ((p.computed || AT) ? '—' : 'вписати');
        // коли параметр показує не останній запис — видно, коли його внесли
        const at = (p.hist_at && txt) ? `<span class="u">${escapeHtml(dmy(p.hist_at))}</span>` : '';
        return `<div class="ac-row">
            <span class="k">${escapeHtml(p.label)}${at}</span>
            <span class="v ${cls}" data-key="${escapeHtml(p.key)}">${disp}</span>
        </div>`;
    }).join('');
    const tile = (!rows && inTree.size) ? ''      // лишились самі Мати/Батько
        : `<div class="ac-tile ac-tile-page" style="--sec:${color};--sec-bg:${hexRgba(color, 0.10)}">
        <div class="ac-tile-head" role="button" tabindex="0"><span class="ac-fold-chev">▾</span>${escapeHtml(sec)}</div>
        <div class="ac-tile-body ac-grid">${rows || '<div class="ac-row"><span class="k">поля цієї секції приховано</span></div>'}</div></div>`;
    // на сторінці «Родовід» — саме дерево, а не два текстові поля
    const ped = (sec === 'Родовід' && !CONFIG) ? pedigreeHtml(color) : '';
    // на сторінці «Продуктивність» — крива лактації
    const milk = (sec === 'Продуктивність' && !CONFIG)
        ? `<div class="ac-tile ac-tile-page ac-milk" style="--sec:${color};--sec-bg:${hexRgba(color, 0.10)}">
             <div class="ac-tile-head" role="button" tabindex="0"><span class="ac-fold-chev">▾</span>Крива лактації</div>
             <div class="ac-milk-body"><canvas id="acMilkCv" height="240"></canvas>
             <p class="text-mute" id="acMilkNote" hidden></p></div></div>`
        : '';
    // крива лактації стоїть НАД параметрами продуктивності (слово Романа)
    $('acParams').innerHTML = tabs + atBar + hint + ped + milk + tile;
    if ($('acAtNow')) $('acAtNow').addEventListener('click', () => {
        LACT_SEL = LACTS.length ? LACTS[LACTS.length - 1].n : null;
        renderEvents();
        applyLactParams();
    });
    $('acParams').querySelectorAll('.ac-tab').forEach((b) => b.addEventListener('click', () => {
        TAB = b.dataset.tab;
        try { localStorage.setItem(TAB_KEY, TAB); } catch (e) { /* ignore */ }
        renderTiles();
    }));
    applyFolds();
    if (milk) drawMilkCurve();
    if (ped) loadPedTree();
    $('acParams').querySelectorAll('[data-go]').forEach((el) =>
        el.addEventListener('click', () => goAnimal(el.dataset.go)));
}

// Видалення події з історії — ЗАВЖДИ з перепитом: подія веде параметри
// тварини, тож після видалення стан перераховується з решти ланцюга.
let evDeleting = false;
async function delEvent(row) {
    if (evDeleting) return;          // два перепити на одну кнопку «Видалити»
    evDeleting = true;
    try { await delEventRun(row); } finally { evDeleting = false; }
}

async function delEventRun(row) {
    if (!row) return;
    const id = Number(row.dataset.ev || 0);
    const e = EVENTS.find((x) => Number(x.id) === id);
    if (!id || !e) return;
    const d = (e.event_date || '').slice(0, 10);
    const kids = (PED && PED.offspring || []).filter(
        (o) => Number(o.birth_event_id || 0) === id);
    let msg = `Видалити подію «${e.event_type || ''}» від ${dmy(d)}?`;
    if (e.details) msg += `\n${e.details}`;
    if (kids.length) {
        msg += `\n\nЦією подією заведено тварин: ${kids.length}`
            + ` (${kids.map((o) => o.tag).join(', ')}). Вони лишаться в реєстрі,`
            + ' але втратять звʼязок із отелом.';
    }
    msg += '\n\nПараметри тварини перерахуються з решти подій.';
    if (!await confirmAction(msg, { ok: 'Видалити' })) return;
    const r = await apiSend('/api/herd/animals/events/' + id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Подію видалено', 'success');
    await reload();
}

/* ПРАВКА ПОДІЇ — повна: дата, нотатка й УСІ поля, які подія питає
   (Роман 2026-09-24: «можу змінити тільки дату… а треба, щоб усе, що
   підвʼязано до події, я мав змогу змінити»). Поля малює спільний
   herd_fields.js — ті самі, що при внесенні, з тими самими межами,
   умовами й звʼязаними грошима.
   ⚠️ Службові ключі, які дописала програма (__calves_list — приплід отелу,
   __cond_off — умовна дія не спрацювала), тут НЕ показуються й НЕ
   редагуються; їх зберігає сервер при злитті. Інакше правка дати в отелі
   стерла б єдиний слід про народжених телят. */
let EV_EDIT = 0, EV_EDIT_WAS = {}, eveSaving = false;

async function editEvent(row) {
    if (!row) return;
    const id = Number(row.dataset.ev || 0);
    const e = EVENTS.find((x) => Number(x.id) === id);
    if (!id || !e) return;
    EV_EDIT = id;
    $('eveWhat').textContent = `${e.event_type || 'Подія'} · зараз ${dmy((e.event_date || '').slice(0, 10))}`;
    $('eveDate').value = (e.event_date || '').slice(0, 10);
    $('eveNote').value = e.note || '';
    const box = $('eveFields');
    box.innerHTML = '';
    $('eveNoAsk').hidden = true;
    $('eveKeep').hidden = true;
    // подія з групового внесення: правимо РІВНО цю тварину, решта пакета ціла
    $('eveBatch').hidden = !e.batch_id;
    if (e.batch_id) {
        $('eveBatch').textContent = `Це запис із групового внесення №${e.batch_id}`
            + ' — виправиться лише ця тварина.';
    }
    $('evEditModal').hidden = false;
    setTimeout(() => $('eveDate').focus(), 30);

    if (!(await evEnsureDefs())) return;
    if (EV_EDIT !== id) return;                 // за цей час відкрили іншу подію
    const def = EVALL.find((d) => Number(d.id) === Number(e.event_def_id))
        || EVALL.find((d) => (d.key || '') === (e.def_key || ''));
    let was = {};
    try { was = JSON.parse(e.inputs_json || '{}') || {}; } catch (er) { was = {}; }
    // службові ключі (__…) людина не редагує — показуємо лише справжні поля
    EV_EDIT_WAS = {};
    Object.keys(was).forEach((k) => { if (!k.startsWith('__')) EV_EDIT_WAS[k] = was[k]; });
    if (!def) {
        $('eveNoAsk').hidden = false;
        $('eveNoAsk').textContent = 'Означення цієї події не знайдено — можна змінити дату й нотатку.';
        return;
    }
    const n = window.herdFields.render(box, def, { values: EV_EDIT_WAS,
        showVals: SHOWVALS_OF(), eventId: def.id, useDefaults: false });
    window.herdFields.bind(box);
    $('eveNoAsk').hidden = !!n;
    if (!n) $('eveNoAsk').textContent = 'Ця подія нічого не питає.';
    const hidden = Object.keys(was).filter((k) => k.startsWith('__')).length;
    if (hidden) {
        $('eveKeep').hidden = false;
        $('eveKeep').textContent = 'Приплід і службові позначки цієї події зберігаються без змін.';
    }
}

/* значення параметрів тварини — для полів-довідок (mode='show') */
function SHOWVALS_OF() {
    const out = {};
    (PARAMS || []).forEach((p) => { out[p.key] = p.value_label || p.value || ''; });
    return out;
}

async function saveEventEdit() {
    if (!EV_EDIT || eveSaving) return;
    const d = $('eveDate').value;
    if (!d) { $('eveDate').focus(); return; }
    const box = $('eveFields');
    const hf = window.herdFields;
    // обовʼязкове, що БУЛО заповнене, не можна лишити порожнім; давню подію,
    // де поля й доти не було, правка не блокує
    const miss = hf ? hf.missingRequired(box, { was: EV_EDIT_WAS }) : [];
    if (miss.length) {
        toast('Заповніть: ' + miss.map((m) => m.label).join(', '), 'error');
        miss[0].el.focus();
        return;
    }
    const bad = hf ? hf.outOfBounds(box) : [];
    if (bad.length) { toast(bad[0].msg, 'error'); bad[0].el.focus(); return; }
    eveSaving = true;
    try {
        const body = { event_date: d, note: $('eveNote').value };
        if (hf && box.children.length) body.inputs = hf.collect(box);
        const r = await apiSend('/api/herd/animals/events/' + EV_EDIT, 'PATCH', body);
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        $('evEditModal').hidden = true;
        EV_EDIT = 0;
        toast('Виправлено · параметри перераховано', 'success');
        await reload();
    } finally { eveSaving = false; }
}

if ($('eveSave')) {
    $('eveSave').addEventListener('click', saveEventEdit);
    $('eveDate').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveEventEdit(); });
    $('eveNote').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveEventEdit(); });
    document.querySelectorAll('#evEditModal [data-eve-close]').forEach((x) =>
        x.addEventListener('click', () => { $('evEditModal').hidden = true; EV_EDIT = 0; }));
}

/* ---------- родовід ---------- */
// Батько на фермі — бик із довідника плідників, власних предків у нього
// немає. Тож дерево — це ЛІНІЯ МАТЕРІ вглиб, і біля кожного покоління свій
// бик; під нею — нащадки. Так воно й читається зоотехніком.
// перший рівень — назва параметра «мати» з конструктора, глибші — покоління
const PED_LEVEL = [herdLabel('dam_tag', 'мати'), 'бабуся', 'прабабуся', 'прапрабабуся', 'пращурка'];

/* Лінія походження бика — з довідника плідників (колонка «Примітка»).
   Порожньо в бика природного парування — тоді й не показуємо. */
function sireLine(b) {
    const l = (b && b.line ? String(b.line) : '').trim();
    return l ? ` <span class="pd-line">лінія ${escapeHtml(l)}</span>` : '';
}

function animalChip(a, extra) {
    if (!a) return '<span class="pd-none">не вказано</span>';
    const nm = a.name ? ' «' + escapeHtml(a.name) + '»' : '';
    const go = a.id && !a.is_ref ? ` data-go="${a.id}"` : '';
    const cls = 'pd-a' + (a.is_ref ? ' is-bull' : '') + (go ? ' is-link' : '');
    return `<span class="${cls}"${go}><b>${escapeHtml(a.tag || '—')}</b>${nm}`
        + (extra ? `<span class="pd-sub">${extra}</span>` : '') + '</span>';
}

function insemRow(title, ins) {
    if (!ins) return '';
    const parts = (ins.fields || []).map((f) =>
        `<span class="pd-sub">${escapeHtml(f.label)}: <b>${escapeHtml(f.value)}</b></span>`);
    return `<div class="pd-row pd-insem"><span class="pd-lvl">${escapeHtml(title)}</span>
        <span class="pd-a"><b>${escapeHtml(dmy(ins.date))}</b>${parts.join('')}</span></div>`;
}

/* Мати, якої немає в реєстрі. Номер її ми знаємо (з імпорту чи з картки),
   тож показуємо саме номер, а не мовчазне «матері немає»: у завезених із
   іншого господарства мати лишилась там, але в родоводі їй місце є. */
function damOutsideRow() {
    const d = PED && PED.dam;
    const lvl = escapeHtml(herdLabel('dam_tag', 'мати'));
    if (!d || !d.tag) {
        // ⚠️ теж pd-dup: без нього рядок «мати — не вказано» лишався видимим
        // НАД деревом, у якому мати стоїть (її знає племкнига, а картка ні) —
        // виходило, що картка сама собі суперечить (Роман 2026-09-22).
        // Коли дерева немає, рядок видно як і раніше; коли є, але матері в
        // ньому справді бракує, у схемі на її місці стоїть пунктирна плитка.
        return `<div class="pd-row pd-dup"><span class="pd-lvl">${lvl}</span>`
            + '<span class="pd-none">не вказано</span></div>';
    }
    return `<div class="pd-row pd-dup"><span class="pd-lvl">${lvl}</span>`
        + animalChip(d, outsideNote(d)) + '</div>';
}

/* Підпис тварини, якої немає в реєстрі: UA-номер, якщо знаємо, і чесна
   позначка, чому на неї не можна перейти. */
function outsideNote(a) {
    return [a && a.uin ? escapeHtml(a.uin) : '', 'немає в реєстрі']
        .filter(Boolean).join(' · ');
}

/* ДЕРЕВО РОДОВОДУ з племкниги предків. Гілки ростуть праворуч: у кожного
   вузла — своя клітинка, а поруч стовпчиком мати й батько. Так само читають
   племінне свідоцтво. Порожня гілка малюється пунктиром, щоб було видно, де
   саме обривається лінія. */
function pedNode(n, lvl, max, path) {
    if (lvl > max) return '';
    // ПІДПИС — ланцюжком, як у племінних документах: М, Б, ММ, БМ, БММ…
    // Просто «мати»/«батько» на кожній клітинці не казало нічого: у колонці
    // «Діди» їх чотири, і незрозуміло, чиї саме (Роман 2026-09-22).
    const cap = path
        ? `<span class="pt-role" title="${escapeHtml(pedWho(path))}">${pedCode(path)}</span>` : '';
    if (!n) return `<div class="pt-node l${lvl}"><div class="pt-cell is-none"><b>${cap}—</b></div></div>`;
    const go = n.animal_id ? ` data-go="${n.animal_id}"` : '';
    const num = escapeHtml(n.tag || n.uin || '—');
    const nm = n.name ? `<span class="pt-nm">${escapeHtml(n.name)}</span>` : '';
    // ВИСОТУ ДЕРЕВА ЗАДАЄ ОСТАННЄ ПОКОЛІННЯ: його клітинок 16, і кожен
    // зайвий рядок у них розсуває матір і батька на сотні пікселів. Тому
    // прапрадіди — В ОДИН РЯДОК (код, номер, кличка), решта — як було.
    if (lvl === max) {
        const tip1 = escapeHtml([n.name, n.uin, n.line && ('лінія ' + n.line)]
            .filter(Boolean).join(' · '));
        const ln1 = pedLineHtml(n);
        return `<div class="pt-node l${lvl}"><div class="pt-cell is-tight sx-${n.sex === 'M' ? 'm' : 'f'}`
            + `${go ? ' is-link' : ''}" data-line="${escapeHtml(n.line || '')}"${go} title="${tip1}">`
            + `<span class="pt-t1"><b>${cap}${num}</b>${nm}</span>${ln1}</div></div>`;
    }
    // ЛІНІЯ видима до прадідів включно — вона коротка й важлива; а от
    // реєстраційний номер у далеких поколіннях лише додає рядок, тож
    // лишається в підказці (Роман 2026-09-22: «не скрізь лінія вказана»)
    const full = lvl <= 2;
    const ln = pedLineHtml(n);
    const uin = (full && n.uin && n.tag) ? `<span class="pt-uin">${escapeHtml(n.uin)}</span>` : '';
    const kids = lvl < max
        ? '<div class="pt-kids">'
          + pedKids(n).map((b) => pedNode(n[b.k], lvl + 1, max, path + b.c)).join('')
          + '</div>'
        : '';
    const self = lvl === 0 ? ' is-self' : '';
    const tip = full ? '' : ` title="${escapeHtml([n.uin, n.line && ('лінія ' + n.line)]
        .filter(Boolean).join(' · '))}"`;
    return `<div class="pt-node l${lvl}"><div class="pt-cell sx-${n.sex === 'M' ? 'm' : 'f'}`
        + `${self}${go ? ' is-link' : ''}" data-line="${escapeHtml(n.line || '')}"${go}${tip}><b>${cap}${num}</b>${nm}${uin}${ln}</div>${kids}</div>`;
}

/* Смужка поколінь над деревом — щоб було видно, докуди «діди», а докуди
   «прадіди». Ширина колонок та сама, що й у клітинок. */
const PED_COLS = ['Тварина', 'Батьки', 'Діди', 'Прадіди', 'Прапрадіди'];
function pedHeadHtml() {
    return '<div class="pt-head">'
        + PED_COLS.map((t) => `<span>${t}</span>`).join('') + '</div>';
}

/* Як читати родовід — схемою чи таблицею. Вибір памʼятається. */
const PED_VIEW_KEY = 'farm:herd:pedView';
let PED_VIEW = 'tree';
try { PED_VIEW = localStorage.getItem(PED_VIEW_KEY) || 'tree'; } catch (e) { /* ignore */ }

/* КОД ПРЕДКА — так, як пишуть у племінних документах: ПЕРША літера каже,
   хто це сам, а далі — чий він. «БМ» — батько матері, «МБ» — мати батька,
   «БММ» — батько матері матері.
   ⚠️ Усередині дерево ходить ланцюжком ВІД тварини (мати→батько = «МБ»),
   тож для показу ланцюжок РОЗГОРТАЄТЬСЯ. Раніше показували сам ланцюжок,
   і під матірʼю стояло «МБ», що читається як «мати батька» — навпаки
   (Роман 2026-09-22: «схематично неправильно вказано ММ, МБ»). */
function pedCode(path) {
    return String(path || '').split('').reverse().join('');
}

/* ЛІНІЯ ПОХОДЖЕННЯ в клітинці. Якщо її не знає ні сам предок, ні жоден його
   батько в книзі — кажемо про це ПРЯМО. Порожнє місце там, де в сусідніх
   плитках стоїть «лінія …», читалося як збій показу, а не як «невідомо»
   (Роман 2026-09-22: «передивися лінію прадіди»). Таке буває у старих
   корів, яким у книзі не записали батька. */
function pedLineHtml(n) {
    const l = (n && n.line) ? String(n.line).trim() : '';
    return l ? `<span class="pt-ln">лінія ${escapeHtml(l)}</span>`
             : '<span class="pt-ln is-unk">лінія невідома</span>';
}

/* Порядок гілок: першою йде та, що одної статі з самою твариною. У корови
   зверху мати, під батьком — його батько. Так лінія походження (вона
   батьківська) читається суцільно згори вниз, не перестрибуючи. */
function pedKids(n) {
    const dam = { k: 'dam', c: 'М' }, sire = { k: 'sire', c: 'Б' };
    return (n && n.sex === 'M') ? [sire, dam] : [dam, sire];
}

/* Хто це в родоводі: «М» → мати, ланцюжок «МБ» → батько матері, «МББ» →
   батько батька матері. Читається з кінця ланцюжка, як і кажуть уголос.
   На вхід іде ВНУТРІШНІЙ ланцюжок, не показаний код. */
function pedWho(path) {
    const one = { 'М': 'мати', 'Б': 'батько' };
    const of = { 'М': 'матері', 'Б': 'батька' };
    const p = String(path || '');
    if (!p) return '';
    const head = one[p[p.length - 1]] || '';
    const rest = p.slice(0, -1).split('').reverse().map((c) => of[c] || '').filter(Boolean);
    return [head, ...rest].join(' ');
}
const PED_GEN = ['I', 'II', 'III', 'IV', 'V', 'VI'];

/* Таблицею: той самий родовід рядками — зручно читати підряд, порівнювати
   й копіювати. Порядок рядків ТОЧНО як у схемі згори вниз. */
function pedTableHtml(root) {
    const rows = [];
    (function walk(n, path) {
        if (!n) return;
        if (path) rows.push({ path, n });
        pedKids(n).forEach((b) => walk(n[b.k], path + b.c));
    })(root, '');
    // обхід іде вже в тому порядку, у якому клітинки стоять у схемі, тож
    // лишається розкласти за поколіннями; сортування в JS стійке, отже
    // всередині покоління порядок обходу зберігається
    rows.sort((a, b) => a.path.length - b.path.length);
    // покоління відбиваємо рядком-роздільником — інакше 30 рядків читаються
    // суцільною стіною (Роман 2026-09-22: «в таблиці виділити покоління»)
    let gen = 0;
    const body = rows.map(({ path, n }) => {
        const go = n.animal_id ? ` data-go="${n.animal_id}"` : '';
        let head = '';
        if (path.length !== gen) {
            gen = path.length;
            head = `<tr class="pt-gen"><td colspan="6">${PED_GEN[gen - 1] || gen} покоління`
                + ` · ${escapeHtml((PED_COLS[gen] || '').toLowerCase())}</td></tr>`;
        }
        return head + `<tr class="sx-${n.sex === 'M' ? 'm' : 'f'}" data-line="${escapeHtml(n.line || '')}">
            <td class="c"><b class="pt-code" title="${escapeHtml(pedWho(path))}">${pedCode(path)}</b></td>
            <td>${escapeHtml(pedWho(path))}</td>
            <td class="pt-t-num${go ? ' is-link' : ''}"${go}><b>${escapeHtml(n.tag || '—')}</b></td>
            <td>${escapeHtml(n.name || '')}</td>
            <td class="u">${escapeHtml(n.uin || '')}</td>
            <td>${n.line ? escapeHtml(n.line)
                : '<span class="pt-unk">невідома</span>'}</td></tr>`;
    }).join('');
    return `<table class="pt-tbl"><thead><tr>
            <th class="c">Код</th><th>Хто</th><th>Номер</th>
            <th>Кличка</th><th>Реєстраційний номер</th><th>Лінія</th>
        </tr></thead><tbody>${body}</tbody></table>`;
}

/* Які лінії є в ЦЬОМУ родоводі — для перемикача над деревом. */
function pedTreeLines(root) {
    const out = new Map();
    (function w(n) {
        if (!n) return;
        const l = String(n.line || '').trim();
        if (l) out.set(l, (out.get(l) || 0) + 1);
        w(n.dam); w(n.sire);
    })(root);
    return [...out.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'uk'));
}
let PED_LINE = '';      // обрана лінія: '' = усі

async function loadPedTree() {
    if (PED_TREE !== undefined) { paintPedTree(); return; }
    const r = await apiGet('/api/herd/animals/' + AID + '/pedigree').catch(() => null);
    PED_TREE = (r && r.ok) ? (r.tree || null) : null;
    paintPedTree();
}
function paintPedTree() {
    const box = document.getElementById('acPedTree');
    if (!box) return;
    if (!PED_TREE || (!PED_TREE.dam && !PED_TREE.sire)) { box.hidden = true; return; }
    box.hidden = false;
    // дерево вже містить матір і батька — текстові рядки над ним були б
    // тим самим удруге (правило Романа: одне число — одне місце)
    const body = box.closest('.pd-body');
    if (body) body.classList.add('has-tree');
    const seg = (v, t) => `<button type="button" class="seg-btn${PED_VIEW === v ? ' is-active' : ''}"
        data-pv="${v}">${t}</button>`;
    box.innerHTML = PED_VIEW === 'table'
        ? pedTableHtml(PED_TREE)
        : `<div class="pt"><div class="pt-root">${pedHeadHtml()}`
          + `${pedNode(PED_TREE, 0, 4, '')}</div></div>`;
    const slot = document.getElementById('acPedView');
    if (slot) {
        // перемикач ліній: показує, ЯКОЮ лінією йде родовід — обрана
        // лишається на видноті, решта приглушується (Роман 2026-09-22)
        const lines = pedTreeLines(PED_TREE);
        if (!lines.some(([l]) => l === PED_LINE)) PED_LINE = '';
        const lsel = lines.length > 1
            ? `<select class="pt-linesel" title="Показати лінію">`
              + `<option value="">усі лінії</option>`
              + lines.map(([l, n]) => `<option value="${escapeHtml(l)}"`
                  + `${l === PED_LINE ? ' selected' : ''}>${escapeHtml(l)} · ${n}</option>`).join('')
              + '</select>'
            : '';
        slot.innerHTML = lsel
            + `<span class="segmented pt-view">${seg('tree', 'Схема')}${seg('table', 'Таблиця')}</span>`;
        slot.querySelectorAll('[data-pv]').forEach((b) => b.addEventListener('click', (e) => {
            e.stopPropagation();
            PED_VIEW = b.dataset.pv;
            try { localStorage.setItem(PED_VIEW_KEY, PED_VIEW); } catch (err) { /* ignore */ }
            paintPedTree();
        }));
        const ls = slot.querySelector('.pt-linesel');
        if (ls) {
            ls.addEventListener('click', (e) => e.stopPropagation());
            ls.addEventListener('change', (e) => {
                e.stopPropagation();
                PED_LINE = ls.value;
                applyPedLine();
            });
        }
    }
    applyPedLine();
    fitPedTree();
    watchPedFit();
    box.querySelectorAll('[data-go]').forEach((el) =>
        el.addEventListener('click', () => goAnimal(el.dataset.go)));
}

/* Приглушити все, що не належить обраній лінії. Порожній вибір — усе
   як є. Працює і в схемі, і в таблиці. */
function applyPedLine() {
    const box = document.getElementById('acPedTree');
    if (!box) return;
    box.querySelectorAll('.pt-cell, .pt-tbl tbody tr').forEach((el) => {
        const l = el.dataset ? (el.dataset.line || '') : '';
        el.classList.toggle('is-dim', !!PED_LINE && l !== PED_LINE);
    });
}

/* ДЕРЕВО МАЄ ВМІЩАТИСЯ. На вікні 1280 колонки не влазили аж на 213 px, і
   частина плиток ховалась за внутрішньою прокруткою (Роман: «не
   поміщаються всі плитки»). Тому, коли місця бракує, схема переходить у
   щільний вигляд: колонки вужчі, а в останньому поколінні кличка й лінія
   стають окремими рядками. Росте вниз — а сторінка й так гортається. */
function fitPedTree() {
    // елементи шукаємо ЩОРАЗУ наново: після перемальовування дерева старі
    // посилання ведуть у відчеплений вузол, і підбір щільності мовчки
    // переставав працювати
    const pt = document.querySelector('#acPedTree .pt');
    const root = pt && pt.querySelector('.pt-root');
    if (!root) return;
    pt.classList.remove('is-narrow', 'is-tiny');
    if (root.scrollWidth <= pt.clientWidth + 1) return;
    pt.classList.add('is-narrow');
    if (root.scrollWidth <= pt.clientWidth + 1) return;
    pt.classList.add('is-tiny');
}

/* Стежимо за шириною ОДИН раз на сторінку: і за вікном, і за самою
   карткою (добір тварин можна згорнути — місця стає більше). */
function watchPedFit() {
    if (window.__ptFitOn) return;
    window.__ptFitOn = true;
    let t = null;
    const kick = () => { clearTimeout(t); t = setTimeout(fitPedTree, 120); };
    window.addEventListener('resize', kick);
    if (window.ResizeObserver) {
        const host = document.querySelector('.ac-main') || document.body;
        new ResizeObserver(kick).observe(host);
    }
}

function pedigreeHtml(color) {
    if (!PED) return '';
    const line = PED.ancestors || [];
    const off = PED.offspring || [];
    const sireRow = `<div class="pd-row pd-self pd-dup">
        <span class="pd-lvl">${escapeHtml(herdLabel('sire_code', 'батько'))}</span>${animalChip(PED.sire, sireLine(PED.sire))}</div>`
        // саме осіменіння, що дало цю тварину: бик, технік, спосіб — усе,
        // що записали в тій події (ідея Романа)
        + insemRow(herdEvent('insem', 'Осіменіння'), PED.insem)
        + insemRow(herdOpt('preg_result', '5', 'Тільна'), PED.pregInsem);
    const rows = line.map((m, i) => (m.outside
        // поза реєстром: про неї знаємо лише номер, кличку й UA — бика й дат немає
        ? `<div class="pd-row pd-dup">
        <span class="pd-lvl">${PED_LEVEL[i] || 'предок'}</span>
        ${animalChip(m, outsideNote(m))}</div>`
        : `<div class="pd-row pd-dup">
        <span class="pd-lvl">${PED_LEVEL[i] || 'предок'}</span>
        ${animalChip(m, [dmy(m.birth_date), m.status_label].filter(Boolean).join(' · '))}
        <span class="pd-bull">${escapeHtml(herdLabel('sire_code', 'бик'))}: ${m.sire
            ? escapeHtml(m.sire.name || m.sire.tag) + sireLine(m.sire) : '—'}</span></div>`)).join('');
    const kids = off.map((o) => `<div class="pd-row pd-kid">
        <span class="pd-lvl">${escapeHtml(dmy(o.birth_date))}</span>
        ${animalChip(o, `<span class="sx-${o.sex === 'M' ? 'm' : 'f'}">`
            + (o.sex === 'M' ? '♂' : '♀') + '</span>'
            + (o.status_label ? ' · ' + escapeHtml(o.status_label) : ''))}
        <span class="pd-bull">${o.via === 'sire' ? 'через: ' + escapeHtml(herdLabel('sire_code', 'батько')) : escapeHtml(herdLabel('sire_code', 'бик')) + ': '
            + (o.sire ? escapeHtml(o.sire.name || o.sire.tag) + sireLine(o.sire) : '—')}</span></div>`).join('');
    return `<div class="ac-tile ac-tile-page ac-ped"
                 style="--sec:${color};--sec-bg:${hexRgba(color, 0.10)}">
        <div class="ac-tile-head" role="button" tabindex="0" data-fold="Родовід">
            <span class="ac-fold-chev">▾</span>Родовід
            <span class="pt-view-slot" id="acPedView"></span></div>
        <div class="pd-body">
            ${sireRow}
            ${rows || damOutsideRow()}
            <div class="pt-box" id="acPedTree" hidden></div>
            <div class="pd-sep">Нащадки${off.length ? ' · ' + off.length : ''}</div>
            ${kids || '<div class="pd-row"><span class="pd-none">нащадків немає</span></div>'}
        </div></div>`;
}

/* ---------- крива лактації ---------- */
let MILK = null;   // {points:[{d,kg}], calvings:[dates]}
async function drawMilkCurve() {
    if (!MILK) {
        const r = await apiGet('/api/herd/animals/' + AID + '/milk-curve').catch(() => null);
        MILK = (r && r.ok) ? r : { points: [], calvings: [] };
    }
    const cv = $('acMilkCv'), note = $('acMilkNote');
    if (!cv) return;
    const pts = MILK.points || [];
    if (!pts.length) {
        cv.hidden = true;
        note.hidden = false;
        note.textContent = `Подій «${herdEvent('milk_test', 'Контрольний надій')}» ще немає — крива зʼявиться після першої.`;
        return;
    }
    const box = cv.parentElement.getBoundingClientRect();
    const W = Math.max(320, Math.floor(box.width) - 4);
    const H = 240;
    // чітко на Retina: полотно в пікселях екрана, малюємо в CSS-пікселях
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    cv.style.width = W + 'px'; cv.style.height = H + 'px';
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const css = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
    const cAxis = css('--text-soft') || css('--text-mute') || '#5b6470';
    const cLine = '#d08700';
    const day = (s2) => Math.floor(new Date(s2 + 'T00:00:00').getTime() / 86400000);

    // Вісь X — дні лактації (DIM): 0–360 за замовчуванням, довша лактація
    // розтягує вісь. Точка відліку — останній отел; заміри до нього належать
    // попередній лактації і малюються сірим (DIM від попереднього отелу).
    // ЖОДЕН замір не губиться: точки діляться на лактації за отелами;
    // заміри до першого відомого отелу — окрема група з умовним нулем.
    const calvs = [...new Set(MILK.calvings || [])].map(day).sort((a, b) => a - b);
    const groups = new Map();            // ключ = день отелу (або 'before')
    pts.forEach((p) => {
        const t = day(p.d);
        let c0 = null;
        for (const c of calvs) { if (c <= t) c0 = c; else break; }
        const key = c0 === null ? 'before' : c0;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push({ t, kg: p.kg });
    });
    const series = [];
    for (const [key, arr] of groups) {
        const zero = key === 'before'
            ? Math.min(...arr.map((p) => p.t)) - 15   // початок лактації невідомий
            : key;
        series.push({ zero, key, pts: arr.map((p) => ({ dim: p.t - zero, kg: p.kg })) });
    }
    series.sort((a, b) => a.zero - b.zero);
    // обрана у фільтрі історії лактація стає головною лінією
    let mainIdx = series.length - 1;
    if (typeof LACT_SEL === 'number' && LACT_SEL > 0) {
        const l = LACTS.find((x) => x.n === LACT_SEL);
        if (l) {
            const want = day(l.from);
            const i = series.findIndex((g) => g.key !== 'before' && g.key === want);
            if (i >= 0) mainIdx = i;
        }
    }
    const cur = series.length ? series[mainIdx].pts : [];
    if (!cur.length) {
        cv.hidden = true; note.hidden = false;
        note.textContent = 'Контрольних надоїв ще немає.';
        return;
    }
    const xMax = Math.max(360, ...series.flatMap((g) => g.pts).map((p) => p.dim));
    const kgs2 = series.flatMap((g) => g.pts).map((p) => p.kg);
    const yMax = Math.max(...kgs2) * 1.15, yMin = 0;
    const padL = 34, padR = 12, padT = 14, padB = 26;
    const X = (dim) => padL + dim / xMax * (W - padL - padR);
    const Y = (v) => padT + (1 - (v - yMin) / (yMax - yMin)) * (H - padT - padB);
    ctx.clearRect(0, 0, W, H);
    // сітка Y
    ctx.strokeStyle = hexRgba('#8a8f98', 0.30); ctx.fillStyle = cAxis;
    ctx.font = '500 11.5px system-ui'; ctx.textAlign = 'right'; ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
        const v = yMin + (yMax - yMin) / 4 * i, y = Y(v);
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
        ctx.fillText(String(Math.round(v)), padL - 6, y + 4);
    }
    // сітка X: кожні 30 днів, підпис кожні 60
    ctx.textAlign = 'center';
    for (let d2 = 0; d2 <= xMax; d2 += 30) {
        const x = X(d2);
        ctx.strokeStyle = hexRgba('#8a8f98', d2 % 60 ? 0.10 : 0.22);
        ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, H - padB); ctx.stroke();
        if (d2 % 60 === 0) ctx.fillText(String(d2), x, H - 8);
    }
    ctx.fillText('днів лактації', W - 46, H - 8 - 12);
    const drawSeries = (arr, color, dots) => {
        if (!arr.length) return;
        arr = arr.slice().sort((a, b) => a.dim - b.dim);
        ctx.strokeStyle = color; ctx.lineWidth = dots ? 2.5 : 1.5;
        ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.beginPath();
        arr.forEach((p, i) => {
            const x = X(p.dim), y = Y(p.kg);
            i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        });
        ctx.stroke();
        if (!dots) return;
        arr.forEach((p) => {
            const x = X(p.dim), y = Y(p.kg);
            ctx.fillStyle = color;
            ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill();
            ctx.lineWidth = 1.5; ctx.strokeStyle = '#fff'; ctx.stroke();
            ctx.font = '600 12px system-ui';
            ctx.fillStyle = '#5c3b00';
            ctx.fillText(String(p.kg), x, y - 9);
        });
    };
    series.forEach((g, i) => {                    // решта лактацій — тлом
        if (i !== mainIdx) drawSeries(g.pts, hexRgba('#8a8f98', 0.75), false);
    });
    drawSeries(cur, cLine, true);                  // обрана
    ctx.textAlign = 'left'; ctx.fillStyle = cAxis; ctx.font = '500 11.5px system-ui';
    if (series.length > 1) {
        const n = (typeof LACT_SEL === 'number' && LACT_SEL > 0) ? LACT_SEL : series.length;
        ctx.fillText(`кольором — лактація ${n}, сірим — решта`, padL + 4, padT + 2);
    }
}

/* ---------- інлайн-редагування ---------- */
function editControl(p) {
    // вимкнені позиції довідника (o.off) у виборі не пропонуємо, але ту, що
    // вже стоїть у тварини, лишаємо — інакше значення мовчки затерлося б
    const opts = (p.options || []).filter((o) =>
        !(o && o.off) || String(o.c) === String(p.value));
    if (opts.length && ['cod', 'code', 'ref'].includes(p.dtype)) {
        return `<select class="ac-edit"><option value="">—</option>${opts.map((o) =>
            `<option value="${escapeHtml(o.c)}"${String(o.c) === String(p.value) ? ' selected' : ''}>${escapeHtml(o.c)} — ${escapeHtml(o.l)}</option>`).join('')}</select>`;
    }
    if (opts.length) {   // list / group (масив рядків)
        return `<select class="ac-edit"><option value="">—</option>${opts.map((o) =>
            `<option value="${escapeHtml(o)}"${String(o) === String(p.value) ? ' selected' : ''}>${escapeHtml(o)}</option>`).join('')}</select>`;
    }
    if (p.dtype === 'bool') {
        return `<select class="ac-edit"><option value="">—</option>
            <option value="1"${p.value == 1 ? ' selected' : ''}>Так</option>
            <option value="0"${(p.value === '0' || p.value === 0) ? ' selected' : ''}>Ні</option></select>`;
    }
    // ⚠️ НЕ type="number": браузер малює в полі перемикач ▲▼, який у картці
    // тільки заважає (Роман 2026-09-16: «не треба ставити перемикач вверх
    // вниз»). Цифрову клавіатуру на телефоні дає inputmode, а зайві символи
    // відсікає санітизація нижче.
    const num = p.dtype === 'int' || p.dtype === 'float';
    const type = p.dtype === 'date' ? 'date' : 'text';
    const mode = num ? ` inputmode="${p.dtype === 'int' ? 'numeric' : 'decimal'}"` : '';
    const cls = 'ac-edit' + (num ? ' ac-num' : '');
    return `<input type="${type}"${mode} class="${cls}"${window.multiAttrs(p.dtype, p.vmin, p.vmax)}`
        + ` value="${escapeHtml(p.value || '')}">`;
}
async function saveParam(cell, key, val) {
    const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key, value: val });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); cell.innerHTML = cell.dataset.orig; return; }
    toast('Збережено', 'success');
    reload();
}
/* UIN — окреме вікно (країна + цифри) */
function openUin(p) {
    const m = String(p.value || '').match(/^([A-Za-z]*)(.*)$/);
    let cc = (m && m[1] ? m[1] : 'UA').toUpperCase();
    const digits = (m ? m[2] : '').replace(/\D/g, '');
    let list = UIN_COUNTRIES.slice();
    if (cc && !list.some((c) => c[0] === cc)) list.unshift([cc, cc]);
    $('uinCC').innerHTML = list.map((c) =>
        `<option value="${c[0]}"${c[0] === cc ? ' selected' : ''}>${c[0]} — ${escapeHtml(c[1])}</option>`).join('');
    $('uinNum').value = digits;
    updateUinPreview();
    $('uinModal').hidden = false;
    $('uinNum').focus();
}
function updateUinPreview() {
    const num = ($('uinNum').value || '').replace(/\D/g, '');
    $('uinPreview').textContent = ($('uinCC').value || 'UA') + (num || '…');
}
async function saveUin() {
    const val = ($('uinCC').value || 'UA') + ($('uinNum').value || '').replace(/\D/g, '');
    const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key: 'uin', value: val });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('uinModal').hidden = true;
    toast('Збережено', 'success');
    reload();
}

function startEdit(cell) {
    const key = cell.dataset.key;
    const p = PARAMS.find((x) => x.key === key);
    if (!p || p.computed) return;
    if (AT) {                                   // минула лактація — лише перегляд
        toast('Це стан на кінець лактації — змінювати можна поточні дані', 'warn');
        return;
    }
    if (key === 'uin') { openUin(p); return; }
    cell.dataset.orig = cell.innerHTML;
    cell.innerHTML = editControl(p);
    const ctl = cell.querySelector('.ac-edit');
    if (ctl.classList.contains('ac-num')) numOnly(ctl, p.dtype === 'float');
    ctl.focus();
    let done = false;
    const save = async () => {
        if (done) return; done = true;
        // пробіли з поділу номера (і вставленого з буфера) у базу не йдуть
        const val = ctl.classList.contains('ac-num')
            ? ctl.value.replace(/[\s\u00a0]/g, '') : ctl.value;
        const r = await apiSend('/api/herd/animals/' + AID + '/params', 'POST', { key, value: val });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); cell.innerHTML = cell.dataset.orig; return; }
        toast('Збережено', 'success');
        reload();   // перечитати (обчислювані могли змінитись)
    };
    ctl.addEventListener('blur', save);
    ctl.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); ctl.blur(); }
        else if (e.key === 'Escape') { done = true; cell.innerHTML = cell.dataset.orig; }
    });
    if (ctl.tagName === 'SELECT') ctl.addEventListener('change', save);
}

/* обчислене значення: наведіть мишу — видно, як воно рахується, кольоровим
   рядком формули (Роман 2026-09-19: «підсвітку кольорами в картку тварини») */
let fxTipT = null;
function fxTipHide() { clearTimeout(fxTipT); const t = $('acFxTip'); if (t) t.hidden = true; }
$('acParams').addEventListener('mouseover', (e) => {
    const v = e.target.closest('.v.auto[data-key]');
    if (!v) return;
    if (v.contains(e.relatedTarget)) return;
    const p = PARAMS.find((x) => x.key === v.dataset.key);
    const fx = (p && p.fx) || {};
    if (!fx.line && !fx.note) return;
    clearTimeout(fxTipT);
    fxTipT = setTimeout(() => {
        let tip = $('acFxTip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'acFxTip';
            tip.className = 'fx-tip';
            document.body.appendChild(tip);
        }
        const body = fx.line && window.herdFxHl
            ? `<code class="fxc">${window.herdFxHl(fx.line, { params: PARAMS })}</code>`
            : `<span class="fx-tip-note">${escapeHtml(fx.note || fx.line || '')}</span>`;
        tip.innerHTML = `<div class="fx-tip-h">Як рахується «${escapeHtml(p.label)}»</div>${body}`;
        tip.hidden = false;
        const r = v.getBoundingClientRect();
        const w = tip.offsetWidth, h = tip.offsetHeight;
        tip.style.left = `${Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8)))}px`;
        tip.style.top = `${Math.round(r.bottom + 6 + h > window.innerHeight ? r.top - h - 6 : r.bottom + 6)}px`;
    }, 0);          // підказки — миттєво (Роман 2026-09-24)
});
$('acParams').addEventListener('mouseout', (e) => {
    const v = e.target.closest('.v.auto[data-key]');
    if (v && !v.contains(e.relatedTarget)) fxTipHide();
});
window.addEventListener('scroll', fxTipHide, true);

$('acParams').addEventListener('click', (e) => {
    if (CONFIG) {                       // режим налаштування — перемикаємо показ
        const row = e.target.closest('.ac-row.cfg'); if (!row) return;
        const key = row.dataset.cfg;
        if (HIDDEN.has(key)) HIDDEN.delete(key); else HIDDEN.add(key);
        saveHidden(); renderTiles();
        return;
    }
    const cell = e.target.closest('.v'); if (!cell || cell.classList.contains('auto')) return;
    if (cell.querySelector('.ac-edit')) return;
    startEdit(cell);
});
if ($('acDetBtn')) $('acDetBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    const m = $('acDetMenu');
    if (m.hidden) {
        // відкриваємо на групі самої тварини — її і налаштовують найчастіше
        if (!DET_GRP) DET_GRP = grpOf(EVENTS[0] || {});
        renderDetMenu();
    }
    m.hidden = !m.hidden;
});
document.addEventListener('click', (e) => {
    const m = $('acDetMenu');
    if (m && !m.hidden && !e.target.closest('#acDetMenu') && !e.target.closest('#acDetBtn'))
        m.hidden = true;
});
$('acCfgBtn').addEventListener('click', () => {
    CONFIG = !CONFIG;
    $('acCfgBtn').classList.toggle('btn-primary', CONFIG);
    if (ANIMAL) renderHeader(ANIMAL);     // шапка налаштовується так само
    renderTiles();
});

// модал UIN
$('uinNum').addEventListener('input', () => {
    $('uinNum').value = $('uinNum').value.replace(/\D/g, ''); updateUinPreview();
});
$('uinNum').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveUin(); } });
$('uinCC').addEventListener('change', updateUinPreview);
$('uinSave').addEventListener('click', saveUin);
document.querySelectorAll('[data-uin-close]').forEach((el) =>
    el.addEventListener('click', () => { $('uinModal').hidden = true; }));


/* ---------- провести подію просто з картки ---------- */
// Два кроки: спершу ПЕРЕЛІК подій за категоріями (щоб було видно, що
// взагалі можна внести), потім форма обраної. Кнопка вгорі — просто
// «Провести подію», без переходу на окрему сторінку.
let EVDEFS = [], EVALL = [], EVPARAMS = {}, EVCATS = {}, EVCUR = null, EVM_BIRTH = null;
// закріплений бик — кого ПЛАНОВО ставити цій тварині (на кожну голову)
let PLAN_SIRE = { sire: '', label: '', param: '' };

function evmClose() { $('evModal').hidden = true; }

/* означення подій потрібні двом місцям: «⚡ Провести подію» і ✎ правка в
   історії. Вантажимо раз і спільно — інакше ✎ працював би лише після того,
   як хоч раз відкривали «Провести подію». */
async function evEnsureDefs() {
    if (EVDEFS.length) return true;
    const r = await apiGet('/api/herd/events?active=1').catch(() => null);
    if (!r || !r.ok) { toast('Не вдалося прочитати перелік подій', 'error'); return false; }
    // у переліку — лише самостійні події; прикріплені («Народження»)
    // потрібні, щоб знайти ту, що реєструє приплід
    EVALL = r.events || [];
    EVDEFS = EVALL.filter((e) => !(e.attach_to || '').trim());
    (r.params || []).forEach((p) => { EVPARAMS[p.key] = p; });
    EVCATS = r.categories || {};
    if (window.herdFields) window.herdFields.init({ params: r.params || [] });
    return true;
}

async function evmOpen() {
    if (!(await evEnsureDefs())) return;
    apiGet('/api/herd/animals/' + AID + '/plan-sire')
        .then((r) => { if (r && r.ok) PLAN_SIRE = r; })
        .catch(() => {});
    $('evModal').hidden = false;
    evmList();
}

// крок 1 — структура подій
function evmList() {
    EVCUR = null;
    $('evmTitle').textContent = 'Провести подію';
    $('evmForm').hidden = true;
    $('evmSave').hidden = true;
    const pick = $('evmPick');
    pick.hidden = false;
    // розмітка та класи — як у конструкторі подій (.eb-list): категорія
    // окремим рядком на всю ширину, події таблетками
    const byCat = {};
    EVDEFS.forEach((e) => { (byCat[e.category || 'other'] ||= []).push(e); });
    const order = Object.keys(EVCATS).concat(
        Object.keys(byCat).filter((c) => !EVCATS[c]));
    pick.innerHTML = order.filter((c) => (byCat[c] || []).length).map((c) =>
        `<div class="eb-cat">${escapeHtml(EVCATS[c] || c)}</div>`
        + byCat[c].map((e) => `<button type="button" class="eb-ev" data-id="${e.id}">`
            + `${escapeHtml(e.name)}</button>`).join('')).join('');
    pick.querySelectorAll('.eb-ev').forEach((b) =>
        b.addEventListener('click', () => evmForm(Number(b.dataset.id))));
}

// крок 2 — форма обраної події
function evmForm(id) {
    EVCUR = EVDEFS.find((e) => Number(e.id) === id) || null;
    if (!EVCUR) return;
    $('evmPick').hidden = true;
    $('evmForm').hidden = false;
    $('evmSave').hidden = false;
    $('evmTitle').textContent = 'Провести подію';
    $('evmEvName').textContent = EVCUR.name || '';
    $('evmDate').value = todayISO();
    $('evmNote').value = '';
    const asks = (EVCUR.effects || []).filter((e) => e.mode === 'input'
        && (!('enabled' in e) || e.enabled));
    $('evmFields').innerHTML = asks.map((e) => {
        const p = EVPARAMS[e.param_key] || {};
        const unit = p.unit ? `, ${p.unit}` : '';
        return `<label class="evm-f"><span>${escapeHtml(p.label || e.param_key)}`
            + `${escapeHtml(unit)}${e.required ? ' *' : ''}</span>${evmControl(e)}</label>`;
    }).join('') || '<p class="text-mute" style="margin:0;font-size:13px">Ця подія нічого не питає.</p>';
    // бик за замовчуванням — закріплений за твариною; видно, що саме план
    const bull = $('evmFields').querySelector('[data-k="last_bull"]');
    if (bull && PLAN_SIRE.sire) {
        bull.value = PLAN_SIRE.sire;
        const lab = bull.closest('.evm-f');
        if (lab && !lab.querySelector('.evm-plan')) {
            const n = document.createElement('span');
            n.className = 'evm-plan';
            n.textContent = 'закріплено: ' + (PLAN_SIRE.label || PLAN_SIRE.sire);
            lab.appendChild(n);
        }
    }
    EVM_BIRTH = EVALL.find((e) => (e.attach_to || '') === EVCUR.key && e.births)
        || (EVCUR.births ? EVCUR : null);
    $('evmCalves').hidden = !EVM_BIRTH;
    $('evmCalfRows').innerHTML = '';
    if (EVM_BIRTH) evmAddCalf();
    // подія не вноситься з поточного стану — видно одразу, а не після спроби
    const rc = (PARAMS.find((x) => x.key === 'repro_code') || {});
    const allow = String(EVCUR.allow_rc || '').split(',').map((x) => x.trim()).filter(Boolean);
    const bad = allow.length && rc.value !== undefined && rc.value !== ''
        && !allow.includes(String(rc.value));
    $('evmDeny').hidden = !bad;
    if (bad) {
        $('evmDeny').textContent = `Стан «${rc.value_label || rc.value}» — `
            + 'цю подію в ньому не вносять.';
    }
}

// контрол поля: список — випадайка, дата — календар, число — число
function evmControl(eff) {
    const p = EVPARAMS[eff.param_key] || {};
    const ch = p.choices || [];
    const k = escapeHtml(eff.param_key);
    if (ch.length) {
        return `<select data-k="${k}"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}">${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    const dt = p.dtype || 'text';
    const numf = ['int', 'float', 'number'].includes(dt);
    const type = dt === 'date' ? 'date' : 'text';
    const step = numf ? ` inputmode="${dt === 'int' ? 'numeric' : 'decimal'}"` : '';
    return `<input type="${type}"${step} data-k="${k}"${window.multiAttrs(dt, p.vmin, p.vmax)}>`;
}

function evmAddCalf() {
    const extra = ((EVM_BIRTH && EVM_BIRTH.effects) || []).filter((e) =>
        e.mode === 'input' && (!('enabled' in e) || e.enabled)
        && !['sex', 'name', 'tag', 'uin'].includes(e.param_key));
    const div = document.createElement('div');
    div.className = 'evm-calf';
    div.innerHTML =
        '<select class="c-alive"><option value="1">🐮 Живе</option>'
        + '<option value="0">✝ Мертвонар.</option></select>'
        + `<input type="text" class="c-uin" value="UA" placeholder="${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))}">`
        + `<input type="text" class="c-tag" placeholder="${escapeHtml(herdLabel('tag', 'Номер тварини'))}">`
        + `<select class="c-sex"><option value="">— ${escapeHtml(herdLabel('sex', 'Стать').toLowerCase())} —</option>`
        + (herdOptions('sex').length ? herdOptions('sex') : [{ c: 'F', l: 'Жіноча' }, { c: 'M', l: 'Чоловіча' }])
            .map((o) => `<option value="${escapeHtml(o.c)}">${escapeHtml(o.l)}</option>`).join('')
        + '</select>'
        + `<input type="text" class="c-name" placeholder="${escapeHtml(herdLabel('name', 'Кличка'))}">`
        + extra.map((e) => {
            const p = EVPARAMS[e.param_key] || {};
            const ph = (p.label || e.param_key) + (p.unit ? ', ' + p.unit : '');
            // підписів у рядку немає: ввід — підказкою, випадайка — першою позицією
            return evmControl(e).replace('<select ', '<select class="c-ex" ')
                .replace('<input ', `<input class="c-ex" placeholder="${escapeHtml(ph)}" `)
                .replace('<option value="">—</option>',
                         `<option value="">— ${escapeHtml(p.label || '')} —</option>`);
        }).join('')
        + '<button type="button" class="c-del" title="Прибрати">✕</button>';
    div.querySelector('.c-del').addEventListener('click', () => div.remove());
    const cTag = div.querySelector('.c-tag');
    const cUin = div.querySelector('.c-uin');
    let uinTimer = null;
    cUin.addEventListener('input', (e) => {
        e.target.value = 'UA' + e.target.value.replace(/\D/g, '');
        if (!cTag || cTag.dataset.manual) return;   // бирка йде за довгим номером
        const t = tailOfUin(e.target.value);
        if (t) cTag.value = t;
        clearTimeout(uinTimer);
        uinTimer = setTimeout(() => freeCalfTag(cUin, cTag), 350);
    });
    if (cTag) cTag.addEventListener('input', () => { cTag.dataset.manual = '1'; });
    $('evmCalfRows').appendChild(div);
    suggestCalfUin(div.querySelector('.c-uin'), div.querySelector('.c-tag'));
}

/* Номер приплоду: основний — довгий UA, бирка з нього похідна (Роман
   2026-09-16). Правило нумерації задається в реєстрі тварин. */
let CALF_NUM = { prefix: '', width: 0 };

function tailOfUin(v) {
    const raw = String(v || '').replace(/\s/g, '').toUpperCase();
    const pref = (CALF_NUM.prefix || '').toUpperCase();
    if (pref && raw.startsWith(pref)) {
        const t = raw.slice(pref.length);
        return /^\d+$/.test(t) ? t : '';
    }
    const digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    return digits.slice(-(CALF_NUM.width || 6));
}

/* Коротка бирка може бути зайнята — тоді беремо на цифру довший хвіст
   того самого номера (Роман 2026-09-16). */
async function freeCalfTag(uinEl, tagEl) {
    const uin = (uinEl.value || '').trim();
    if (!/\d/.test(uin) || tagEl.dataset.manual) return;
    const busy = [...document.querySelectorAll('#evmCalfRows .c-tag')]
        .filter((x) => x !== tagEl).map((x) => (x.value || '').trim()).filter(Boolean);
    try {
        const r = await apiGet('/api/herd/tag-for-uin?uin=' + encodeURIComponent(uin)
            + (busy.length ? '&skip=' + encodeURIComponent(busy.join(',')) : ''));
        if (!r || !r.ok || !r.tag || tagEl.dataset.manual) return;
        tagEl.value = r.tag;
        tagEl.classList.toggle('tag-grown', !!r.grown);
        tagEl.title = r.grown ? 'Коротший номер уже зайнятий — узято на цифру довший' : '';
    } catch (e) { /* ignore */ }
}

async function suggestCalfUin(el, tagEl) {
    if (!el || (el.value || '').replace(/\D/g, '')) return;
    const busy = [...document.querySelectorAll('#evmCalfRows .c-uin')]
        .map((x) => (x.value || '').trim()).filter((v) => /\d/.test(v));
    try {
        const r = await apiGet('/api/herd/next-uin'
            + (busy.length ? '?skip=' + encodeURIComponent(busy.join(',')) : ''));
        if (r && r.ok) {
            CALF_NUM = { prefix: (r.uin || '').slice(0, (r.uin || '').length - (r.tag || '').length),
                         width: (r.tag || '').length };
        }
        if (r && r.ok && r.uin && !(el.value || '').replace(/\D/g, '')) {
            el.value = r.uin;
            el.title = r.mode === 'max'
                ? 'Наступний за найбільшим у цій серії — можна змінити'
                : 'За лічильником нумерації приплоду — можна змінити';
            if (tagEl && !(tagEl.value || '').trim() && r.tag) tagEl.value = r.tag;
        }
    } catch (e) { /* немає звʼязку — лишиться «UA» */ }
}

/* ⚠️ ЗАМОК ПЕРШИМ РЯДКОМ. Між натисканням «Провести подію» і самим записом
   стоїть підтвердження бика (await confirmAction), а сам запит іде секунду-дві
   (параметри перераховуються). Без замка друге натискання проводить подію
   ВДРУГЕ — та сама вада, через яку 23.09.2026 у груповому вводі три
   осіменіння лягли по два рази. Кнопку ще й гасимо, щоб людина бачила, що
   запис уже йде. */
let evmSaving = false;
async function evmSave() {
    if (evmSaving) return;
    evmSaving = true;
    const btn = $('evmSave');
    const was = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Проводжу…'; }
    try {
        await evmSaveRun();
    } finally {
        evmSaving = false;
        if (btn) { btn.disabled = false; btn.textContent = was; }
    }
}

async function evmSaveRun() {
    if (!EVCUR) return;
    const inputs = {};
    $('evmFields').querySelectorAll('[data-k]').forEach((el) => {
        const v = (el.value || '').trim();
        if (v) inputs[el.dataset.k] = v;
    });
    const miss = (EVCUR.effects || []).find((e) => e.mode === 'input' && e.required
        && (!('enabled' in e) || e.enabled) && !inputs[e.param_key]);
    if (miss) {
        const p = EVPARAMS[miss.param_key] || {};
        toast(`Заповніть «${p.label || miss.param_key}»`, 'warn');
        return;
    }
    const calves = [];
    let calfErr = '';
    $('evmCalfRows').querySelectorAll('.evm-calf').forEach((r) => {
        const alive = r.querySelector('.c-alive').value !== '0';
        const sex = r.querySelector('.c-sex').value;
        const tag = (r.querySelector('.c-tag').value || '').trim();
        const uin = (r.querySelector('.c-uin').value || '').replace(/\D/g, '');
        const name = (r.querySelector('.c-name').value || '').trim();
        const params = {};
        r.querySelectorAll('.c-ex').forEach((el) => {
            const v = (el.value || '').trim();
            if (v && el.dataset.k) params[el.dataset.k] = v;
        });
        if (!(sex || tag || name || uin || Object.keys(params).length)) return;
        if (!sex) { calfErr = `Оберіть «${herdLabel('sex', 'Стать')}»`; return; }
        if (alive && !tag) { calfErr = `Вкажіть «${herdLabel('tag', 'Номер тварини')}»`; return; }
        calves.push({ alive, sex, tag, name, params,
                      uin: (alive && uin) ? 'UA' + uin : '' });
    });
    if (calfErr) { toast(calfErr, 'warn'); return; }
    // обрали не закріпленого бика — питаємо один раз, але не забороняємо
    if (PLAN_SIRE.sire && inputs.last_bull && inputs.last_bull !== PLAN_SIRE.sire) {
        const ch = (EVPARAMS.last_bull && EVPARAMS.last_bull.choices || [])
            .find((c) => String(c.value) === String(inputs.last_bull));
        const okGo = await confirmAction(
            `Закріплено ${PLAN_SIRE.label || PLAN_SIRE.sire}, обрано `
            + `${(ch && ch.label) || inputs.last_bull}. Провести?`,
            { ok: 'Провести', okClass: 'btn-primary' });
        if (!okGo) return;
    }
    const r = await apiSend('/api/herd/animals/' + AID + '/apply-event', 'POST', {
        event_id: EVCUR.id, event_date: $('evmDate').value,
        inputs, calves, note: ($('evmNote').value || '').trim(),
    });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast((r.kept_labels || []).length
        ? `Подію проведено заднім числом; поточне не змінено (є пізніша подія): ${r.kept_labels.join(', ')}`
        : 'Подію проведено', 'success');
    evmClose();
    await reload();
}

// кнопка й вікно
if ($('acEvBtn')) {
    $('acEvBtn').addEventListener('click', evmOpen);
    $('evmBack').addEventListener('click', evmList);
    $('evmAddCalf').addEventListener('click', evmAddCalf);
    $('evmSave').addEventListener('click', evmSave);
    document.querySelectorAll('[data-ev-close]').forEach((el) =>
        el.addEventListener('click', evmClose));
}

/* Згортання плиток: заголовок працює як кнопка (миша й клавіатура). */
function applyFolds() {
    $('acParams').querySelectorAll('.ac-tile').forEach((tile) => {
        const head = tile.querySelector('.ac-tile-head');
        if (!head) return;
        const key = head.dataset.fold
            || head.textContent.replace('▾', '').replace('▸', '').trim();
        const off = FOLDED.has(key);
        tile.classList.toggle('is-folded', off);
        const chev = head.querySelector('.ac-fold-chev');
        if (chev) chev.textContent = off ? '▸' : '▾';
        head.setAttribute('aria-expanded', off ? 'false' : 'true');
        head.title = off ? 'Показати' : 'Згорнути';
        const toggle = () => {
            if (FOLDED.has(key)) FOLDED.delete(key); else FOLDED.add(key);
            saveFolded();
            applyFolds();
            // крива малюється по видимій ширині — після розгортання перемалювати
            if (!FOLDED.has(key) && tile.classList.contains('ac-milk')) drawMilkCurve();
        };
        head.onclick = (e) => {
            // керування в шапці — не привід згортати (правило з farm-design)
            if (e.target.closest('button, a, select, input, .segmented')) return;
            toggle();
        };
        head.onkeydown = (e) => {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
        };
    });
}

/* Перехід на іншу тварину БЕЗ перезавантаження сторінки. */
async function goAnimal(id, push = true) {
    id = parseInt(id, 10);
    if (!id || id === AID) return;
    AID = id;
    // усе, що стосувалось попередньої тварини, скидаємо — інакше в новій
    // картці лишилась би чужа крива чи чужий закріплений бик
    MILK = null;
    PLAN_SIRE = { sire: '', label: '', param: '' };
    PED = null; PED_TREE = undefined; PHIST = {}; EVENTS = []; LACTS = []; LACT_SEL = null; CAT_SEL = 'all';
    AT = ''; AT_LACT = null; PARAMS_NOW = null; atSeq += 1;
    CONFIG = false;
    evmClose();
    if (push) {
        try { history.pushState({ aid: id }, '', '/herd/animals/' + id); } catch (e) { /* ignore */ }
    }
    // ⚠️ саме load(), а не reload(): reload() чистить кеш ТІЄЇ тварини, на
    // яку переходимо, тобто зводив нанівець усе передзавантаження сусідів
    await load();
    window.scrollTo({ top: 0 });
    // підсвічення в бічній панелі йде за карткою, хоч звідки її змінили:
    // стрілками у смужці, пошуком, родоводом чи кнопкою «назад»
    if (window.herdSide) window.herdSide.sync();
    prefetchNeighbours();
}
window.herdCardGo = goAnimal;

/* Сусідів по списку підвозимо тихо у фоні: наступне натискання стрілки
   тоді не чекає мережі взагалі. */
function prefetchNeighbours(retry = true) {
    // смужка гілки підключається в кінці сторінки, тож на першому кроці її
    // може ще не бути — тоді пробуємо ще раз, коли сторінка дозавантажилась
    if (!(window.herdNav && window.herdNav.neighbours)) {
        if (retry) setTimeout(() => prefetchNeighbours(false), 500);
        return;
    }
    const near = window.herdNav.neighbours(AID);
    near.forEach((id) => {
        if (id && !CARD_CACHE.has(String(id))) {
            fetchAnimal(id).catch(() => {});
        }
    });
}

// «Назад» у браузері має повертати до попередньої тварини, а не з модуля
window.addEventListener('popstate', (e) => {
    const m = location.pathname.match(/^\/herd\/animals\/(\d+)/);
    if (m) goAnimal(parseInt(m[1], 10), false);
});

if ($('acParams')) load().then(prefetchNeighbours);
})();

/* ============ Права панель добору ============
   Роман 2026-09-16: «панель зправа, яку можна скривати розкривати; в цій
   панелі будуть відображатись і налаштовуватись фільтри, по яким можна
   буде перемикати номера тварин і продивлятись їх».

   Фільтри тут — ТІ САМІ, що в реєстрі (ключ herd:filters), тож добір,
   зроблений на картці, одразу діє і на стрілках «◄ ►» у смужці, і в
   реєстрі. Список під фільтрами — те, чим зараз гортаєш: видно, де ти в
   ньому, і можна стрибнути на будь-яку тварину, не шукаючи. */
(function () {
    const layout = document.getElementById('acLayout');
    if (!layout) return;
    const $$ = (id) => document.getElementById(id);
    const FLT_KEY = 'herd:filters';
    const OPEN_KEY = 'farm:herd:sideOpen';

    const jget = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (e) { return d; } };
    const jset = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } };

    let items = [];
    let timer = null;

    function open(v) {
        layout.classList.toggle('is-closed', !v);
        $$('acSideToggle').textContent = v ? '›' : '‹';
        $$('acSideToggle').title = v ? 'Сховати добір' : 'Показати добір';
        jset(OPEN_KEY, !!v);
    }

    /* ФІЛЬТРИ ДОБОРУ НАЛАШТОВУЮТЬСЯ (Роман 2026-09-22). Перелік доступних
       приходить із сервера й збирається з живих даних, а людина галочками
       лишає ті, якими справді користується. Ключі «c_»/«p_» — поле тварини
       або значення параметра. */
    const SHOW_KEY = 'herd:sideShow';
    const DEF_SHOW = ['group_id', 'status', 'sex', 'line'];
    let DEFS = [];
    let SHOW = jget(SHOW_KEY, null) || DEF_SHOW.slice();

    const fid = (k) => 'acf_' + k.replace(/[^\w]/g, '_');
    const fval = (k) => { const el = $$(fid(k)); return el ? el.value : ''; };

    function filters() {
        const out = { q: $$('acfQ').value.trim() };
        SHOW.forEach((k) => { const v = fval(k); if (v) out[k] = v; });
        const g = $$(fid('group_id')); const st = $$(fid('status'));
        out.group_name = (g && g.value) ? g.selectedOptions[0].textContent : '';
        out.status_name = (st && st.value) ? st.selectedOptions[0].textContent : '';
        return out;
    }

    function query(f) {
        const p = new URLSearchParams();
        Object.keys(f).forEach((k) => {
            if (k.endsWith('_name') || !f[k]) return;
            p.set(k, f[k]);
        });
        return p.toString();
    }

    function curId() {
        const m = location.pathname.match(/^\/herd\/animals\/(\d+)/);
        return m ? parseInt(m[1], 10) : 0;
    }

    function renderList() {
        const box = $$('acSideList');
        const cur = curId();
        $$('acSideCount').textContent = items.length ? items.length + ' гол.' : '';
        if (!items.length) {
            box.innerHTML = '<div class="ac-side-empty">За цим добором тварин немає.</div>';
            return;
        }
        box.innerHTML = items.map((a) => `
            <div class="ac-side-row${a.id === cur ? ' is-cur' : ''}" data-go="${a.id}">
                <span class="t">${escapeHtml(a.tag || '')}</span>
                <span class="n">${escapeHtml(a.name || '')}</span>
            </div>`).join('');
        // ⚠️ НЕ scrollIntoView: він тягне ВСЮ сторінку (картка від'їжджала
        // на тисячі пікселів угору). Крутимо лише сам список.
        const row = box.querySelector('.is-cur');
        if (row) {
            // ⚠️ рахуємо по ЕКРАННИХ координатах, а не по offsetTop: панель
            // позиціонована (sticky), тож offsetTop міряється від неї, і
            // список зупинявся повз потрібний рядок на висоту фільтрів
            const rb = row.getBoundingClientRect(), bb = box.getBoundingClientRect();
            box.scrollTop += (rb.top - bb.top) - (bb.height - rb.height) / 2;
        }
    }

    async function load(saveToo) {
        const f = filters();
        if (saveToo) jset(FLT_KEY, f);
        try {
            const r = await fetch('/api/herd/animals/nav?' + query(f),
                                  { headers: { Accept: 'application/json' } });
            const d = await r.json();
            items = (d && d.items) || [];
        } catch (e) { items = []; }
        renderList();
        // смужка гілки гортає той самий добір — хай перечитає
        if (window.herdNav && window.herdNav.cacheList) window.herdNav.cacheList(items);
    }

    /* Перелік доступних фільтрів — із сервера; малюємо лише обрані. */
    function renderFilters() {
        const box = $$('acfDyn');
        if (!box) return;
        const saved = jget(FLT_KEY, {}) || {};
        box.innerHTML = SHOW.map((k) => {
            const d = DEFS.find((x) => x.key === k);
            if (!d) return '';
            const opts = ['<option value="">усі</option>'].concat(
                (d.options || []).map((o) =>
                    `<option value="${escapeHtml(o.v)}">${escapeHtml(o.l)}</option>`)).join('');
            return `<label class="ac-f"><span>${escapeHtml(d.label)}</span>`
                + `<select id="${fid(k)}">${opts}</select></label>`;
        }).join('');
        SHOW.forEach((k) => {
            const el = $$(fid(k));
            if (!el) return;
            if (saved[k]) el.value = saved[k];
            el.addEventListener('change', () => load(true));
        });
    }

    function renderCfg() {
        const box = $$('acfCfgBox');
        if (!box) return;
        box.innerHTML = DEFS.map((d) => `<label><input type="checkbox" data-fk="${escapeHtml(d.key)}"`
            + `${SHOW.includes(d.key) ? ' checked' : ''}>${escapeHtml(d.label)}</label>`).join('');
        box.querySelectorAll('[data-fk]').forEach((c) => c.addEventListener('change', () => {
            const k = c.dataset.fk;
            SHOW = c.checked ? [...SHOW, k] : SHOW.filter((x) => x !== k);
            // порядок — як у переліку доступних, щоб не стрибав
            SHOW = DEFS.map((d) => d.key).filter((x) => SHOW.includes(x));
            jset(SHOW_KEY, SHOW);
            renderFilters();
            load(true);
        }));
    }

    async function fillSelects() {
        try {
            const r = await fetch('/api/herd/animals/nav?refs=1', { headers: { Accept: 'application/json' } });
            const d = await r.json();
            DEFS = d.filters || [];
        } catch (e) { DEFS = []; }
        SHOW = SHOW.filter((k) => DEFS.some((d) => d.key === k));
        if (!SHOW.length) SHOW = DEF_SHOW.filter((k) => DEFS.some((d) => d.key === k));
        renderFilters();
        renderCfg();
        const f = jget(FLT_KEY, {}) || {};
        if (f.q) $$('acfQ').value = f.q;
        load(false);
    }

    $$('acfCfgBtn').addEventListener('click', () => {
        const b = $$('acfCfgBox');
        b.hidden = !b.hidden;
    });

    $$('acSideToggle').addEventListener('click', () => open(layout.classList.contains('is-closed')));
    $$('acfQ').addEventListener('input', () => {
        clearTimeout(timer); timer = setTimeout(() => load(true), 250);
    });
    $$('acfReset').addEventListener('click', () => {
        $$('acfQ').value = '';
        SHOW.forEach((k) => { const el = $$(fid(k)); if (el) el.value = ''; });
        load(true);
    });
    $$('acSideList').addEventListener('click', (e) => {
        const row = e.target.closest('[data-go]');
        if (!row) return;
        const id = parseInt(row.dataset.go, 10);
        const a = items.find((x) => x.id === id);
        if (a && window.herdNav) window.herdNav.setCurrent(a);
        if (window.herdCardGo) { window.herdCardGo(id); renderList(); }
        else location.href = '/herd/animals/' + id;
    });

    // картка кличе це після кожної зміни тварини
    /* ⚠️ Панель і смужка ділять одні фільтри. Якщо панель просто
       перевантажиться своїми селектами, вона перепише спільний список —
       і перемикач «Живі/Вибулі/Усі» показуватиме старі числа. Тому
       спершу приймаємо спільний вибір у свої поля. */
    function pullFilters() {
        const f = jget(FLT_KEY, {}) || {};
        if ($$('acfQ').value !== (f.q || '')) $$('acfQ').value = f.q || '';
        SHOW.forEach((k) => { const el = $$(fid(k)); if (el) el.value = f[k] || ''; });
    }

    window.herdSide = {
        sync: renderList,
        reload: () => { pullFilters(); return load(false); },
    };

    open(jget(OPEN_KEY, true) !== false);
    fillSelects();
})();
