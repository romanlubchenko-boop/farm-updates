/* Налаштування подій стада: коло відтворення, самоперевірка, список подій
   і конструктор у три кроки — Доступ · Поля · Перегляд (макет «Події ВРХ»).
   Повний редактор ефектів (автоматика + правила «Якщо») живе в «Розширено». */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const $ = (id) => document.getElementById(id);
let EVENTS = [], PARAMS = [], CATS = {}, MODES = {}, USERS = [];
let cur = null;          // подія, відкрита в конструкторі
let WORK = [];           // робоча копія її полів/дій
let ACCESS = [];         // id людей, яким дозволено вносити подію
let step = 1, openRow = '', dirty = false, dragCode = '';
let pkQ = '', pkCat = 'Усі';

const ARG_MODES = new Set(['const', 'inc']);   // авто-режими зі звичайним полем значення
const TYPES = { date: 'дата', text: 'текст', int: 'ціле', float: 'число', number: 'число',
    bool: 'так / ні', list: 'список', cod: 'код', ref_animal: 'тварина' };

async function load() {
    const r = await apiGet('/api/herd/events');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    EVENTS = r.events || [];
    PARAMS = (r.params || []).filter((p) => !(p.formula || '').trim())   // обчислювані не міняємо
        .sort((a, b) => (a.label || '').localeCompare(b.label || '', 'uk'));
    CATS = r.categories || {};
    MODES = r.modes || {};
    USERS = r.users || [];
    fillParamDatalist();
    if (cur) {           // конструктор відкритий — підхопити свіжі дані події
        const fresh = EVENTS.find((e) => e.id === cur.id);
        if (fresh) cur = fresh; else closeBuilder(false);
    }
    renderList();
    renderCycle();
    if (cur) renderBuilder();
}

function paramByKey(k) { return PARAMS.find((p) => p.key === k); }
function paramByLabel(lbl) {
    const s = (lbl || '').trim();
    return PARAMS.find((p) => (p.label || '') === s);
}
function typeLabel(p) { return (p && TYPES[p.dtype]) || (p && p.dtype) || ''; }
function codeLabel(paramKey, val) {
    const p = paramByKey(paramKey);
    const ch = (p && p.choices) || [];
    const c = ch.find((x) => String(x.value) === String(val));
    return c ? c.label : (val || '—');
}
function fillParamDatalist() {
    const dl = $('eeParamDL'); if (!dl) return;
    dl.innerHTML = PARAMS.map((p) =>
        `<option value="${escapeHtml(p.label)}"></option>`).join('');
}
const isInput = (e) => e.mode === 'input';
const isOn = (e) => !('enabled' in e) || !!e.enabled;

/* ═══════════ КОЛО ВІДТВОРЕННЯ ═══════════ */
function cycleRoles() {
    const roles = { set: {}, branch: null };
    EVENTS.filter((e) => e.is_active).forEach((e) => {
        (e.effects || []).forEach((f) => {
            if (f.param_key !== 'repro_code') return;
            if (f.mode === 'const' && ['2', '4', '6', '9'].includes(String(f.arg).trim())) {
                if (!roles.set[String(f.arg).trim()]) roles.set[String(f.arg).trim()] = e;
            } else if (f.mode === 'when') {
                const s = parseWhenSpec(f.arg);
                const vals = s.rules.map((r) => String(r.val));
                if (vals.includes('5') && vals.includes('3')) roles.branch = e;
            }
        });
    });
    return roles;
}

function renderCycle() {
    const svg = $('evCycle'); if (!svg) return;
    const R = cycleRoles();
    const N = {
        '0': { x: 70,  y: 55,  t: 'Телиця',     c: '0' },
        '4': { x: 250, y: 140, t: 'Осіменена',  c: '4' },
        '3': { x: 250, y: 265, t: 'Ялова',      c: '3' },
        '5': { x: 470, y: 140, t: 'Тільна',     c: '5' },
        '6': { x: 660, y: 140, t: 'Сухостій',   c: '6' },
        '2': { x: 660, y: 265, t: 'Новотільна', c: '2' },
    };
    const ev4 = R.set['4'], ev6 = R.set['6'], ev2 = R.set['2'], br = R.branch;
    // [з, до, подія, підпис-додаток, зсув підпису, зсув точок кріплення по x]
    const edges = [
        ['0', '4', ev4, '', [-14, -16], 0],
        ['4', '5', br, 'тільна', [0, -14], 0],
        ['4', '3', br, 'ялова', [78, 3], -26],
        ['3', '4', ev4, 'повтор', [-64, 3], 0],
        ['5', '6', ev6, '', [0, -14], 0],
        ['6', '2', ev2, '', [14, 3], 0],
        ['2', '4', ev4, 'через 60 дн', [0, 16], 26],
    ];
    const W = 118, H = 44;
    const defs = `<defs><marker id="cycArr" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#9fb4cf"/></marker>
        <marker id="cycArrBad" markerWidth="9" markerHeight="9" refX="8" refY="4.5"
        orient="auto"><path d="M0,0 L9,4.5 L0,9 z" fill="#e5484d"/></marker></defs>`;
    const port = (n, side) => {
        const p = N[n];
        if (side === 'l') return [p.x - W / 2, p.y];
        if (side === 'r') return [p.x + W / 2, p.y];
        if (side === 't') return [p.x, p.y - H / 2];
        return [p.x, p.y + H / 2];
    };
    let g = '', labels = '';
    edges.forEach(([a, b, ev, extra, lo, dx]) => {
        const A = N[a], B = N[b];
        let p1, p2, path, mid;
        const shift = (pt) => [pt[0] + (dx || 0), pt[1]];
        if (a === '2' && b === '4') {          // довга дуга низом
            p1 = port(a, 'b'); p2 = shift(port(b, 'b'));
            path = `M${p1[0]},${p1[1]} C ${p1[0]},324 ${p2[0]},324 ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, 314];
        } else if (a === '3' && b === '4') {   // повтор: дужка ліворуч
            p1 = port(a, 'l'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} C ${p1[0] - 70},${p1[1]} ${p2[0] - 70},${p2[1]} ${p2[0]},${p2[1]}`;
            mid = [p1[0] - 56, (p1[1] + p2[1]) / 2];
        } else if (A.y === B.y) {
            p1 = port(a, 'r'); p2 = port(b, 'l');
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, p1[1]];
        } else if (A.x === B.x) {
            p1 = shift(port(a, 'b')); p2 = shift(port(b, 't'));
            path = `M${p1[0]},${p1[1]} L${p2[0]},${p2[1]}`;
            mid = [p1[0], (p1[1] + p2[1]) / 2];
        } else {                               // діагональ (телиця → осіменена)
            p1 = port(a, 'b'); p2 = port(b, 't');
            path = `M${p1[0]},${p1[1]} C ${p1[0]},${p1[1] + 40} ${p2[0]},${p2[1] - 40} ${p2[0]},${p2[1]}`;
            mid = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2];
        }
        const ok = !!ev;
        g += `<path class="cyc-edge${ok ? '' : ' bad'}" d="${path}"
                marker-end="url(#${ok ? 'cycArr' : 'cycArrBad'})"></path>`;
        const name = ok ? ev.name : 'немає події!';
        const lbl = extra ? `${name} · ${extra}` : name;
        labels += `<text class="cyc-lbl${ok ? '' : ' bad'}" x="${mid[0] + lo[0]}" y="${mid[1] + lo[1]}"
                text-anchor="middle" ${ok ? `data-ev="${ev.id}"` : ''}>${escapeHtml(lbl)}</text>`;
    });
    let nodes = '';
    Object.values(N).forEach((n) => {
        nodes += `<g class="cyc-node">
            <rect x="${n.x - W / 2}" y="${n.y - H / 2}" width="${W}" height="${H}" rx="10"></rect>
            <text x="${n.x}" y="${n.y + 1}" text-anchor="middle">${escapeHtml(n.t)}</text>
            <text class="cyc-code" x="${n.x}" y="${n.y + 15}" text-anchor="middle">код ${n.c}</text>
        </g>`;
    });
    svg.innerHTML = defs + g + nodes + labels;
    svg.querySelectorAll('.cyc-lbl[data-ev]').forEach((t) => t.addEventListener('click', () => {
        const ev = EVENTS.find((x) => String(x.id) === t.dataset.ev);
        if (ev) openBuilder(ev);
    }));
}

/* ═══════════ СПИСОК ПОДІЙ ═══════════ */
/* людське речення для автоматичної дії (для картки і кроку «Перегляд») */
function sentence(e) {
    const p = paramByKey(e.param_key);
    if (!p) return null;
    const lbl = p.label;
    if (e.param_key === 'group' && e.mode === 'const') {
        return `переводить у секцію <b>${escapeHtml(e.arg || '—')}</b>`;
    }
    if (e.mode === 'event_date') return `записує дату події → <b>${escapeHtml(lbl)}</b>`;
    if (e.mode === 'const') return `ставить <b>${escapeHtml(lbl)}</b> = ${escapeHtml(codeLabel(e.param_key, e.arg))}`;
    if (e.mode === 'inc') return `<b>${escapeHtml(lbl)}</b> ${+e.arg >= 0 ? '+' : ''}${escapeHtml(e.arg)}`;
    if (e.mode === 'clear') return `очищає <b>${escapeHtml(lbl)}</b>`;
    if (e.mode === 'when') {
        const s = parseWhenSpec(e.arg);
        const parts = s.rules.filter((r) => r.if).map((r) => {
            const a = codeLabel(r.if, r.eq), b = codeLabel(e.param_key, r.val);
            return a === b ? a : `${a} → ${b}`;
        });
        if (s.default) parts.push(`інакше → ${codeLabel(e.param_key, s.default)}`);
        return `<b>${escapeHtml(lbl)}</b> — за відповіддю: ${escapeHtml(parts.join(' · '))}`;
    }
    return null;
}

function renderList() {
    $('evCount').textContent = EVENTS.length ? `· ${EVENTS.length}` : '';
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    let html = '';
    order.forEach((cat) => {
        const list = bySec[cat];
        if (!list || !list.length) return;
        html += `<div class="evx-cat">${escapeHtml(CATS[cat] || cat)}</div>`;
        list.forEach((e) => {
            const effs = e.effects || [];
            const sents = effs.filter((f) => !isInput(f) && isOn(f)).map(sentence).filter(Boolean);
            const asks = effs.filter((f) => isInput(f) && isOn(f)).length;
            const acc = (e.access_list || []).length;
            html += `<div class="evx-card${e.is_active ? '' : ' off'}" data-id="${e.id}">
                <div class="hd"><b>${escapeHtml(e.name)}</b>
                    ${e.is_active ? '' : '<span class="ev-badge">вимкнена</span>'}
                    <span class="ev-badge ${e.is_standard ? 'std' : 'cus'}">${e.is_standard ? 'системна' : 'створена'}</span></div>
                ${sents.length ? `<div class="sent">${sents.join('<br>')}</div>` : ''}
                <div class="opts">
                    ${asks ? `<span class="opt ask">питає: ${asks}</span>` : ''}
                    ${acc ? `<span class="opt who">доступ: ${acc}</span>` : ''}
                    ${e.attach_to ? `<span class="opt">у вікні «${escapeHtml((EVENTS.find((x) => x.key === e.attach_to) || {}).name || e.attach_to)}»</span>` : ''}
                </div>
            </div>`;
        });
    });
    $('evList').innerHTML = html || '<div class="empty" style="padding:14px">Немає подій</div>';
    $('evList').querySelectorAll('.evx-card').forEach((c) => c.addEventListener('click', () => {
        const ev = EVENTS.find((x) => String(x.id) === c.dataset.id);
        if (ev) openBuilder(ev);
    }));
}

/* ═══════════ КОНСТРУКТОР ═══════════ */
function openBuilder(ev) {
    cur = ev;
    WORK = (ev.effects || []).map((e) => ({
        param_key: e.param_key, mode: e.mode, arg: e.arg || '',
        required: e.required ? 1 : 0,
        quick: ('quick' in e && !e.quick) ? 0 : 1,
        enabled: ('enabled' in e && !e.enabled) ? 0 : 1,
    }));
    ACCESS = (ev.access_list || []).slice();
    step = 1; openRow = ''; dirty = false;
    $('evList').hidden = true;
    $('evNew').hidden = true;
    $('evBuilder').hidden = false;
    renderBuilder();
}

async function closeBuilder(saveFirst) {
    if (saveFirst && dirty) { await save(true); }
    cur = null; WORK = []; ACCESS = [];
    $('evBuilder').hidden = true;
    $('evList').hidden = false;
    $('evNew').hidden = false;
    renderList();
    renderCycle();
}

function renderBuilder() {
    if (!cur) return;
    $('ebName').value = cur.name || '';
    $('ebCat').innerHTML = Object.entries(CATS).map(([k, v]) =>
        `<option value="${k}"${cur.category === k ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
    $('ebActive').checked = !!cur.is_active;
    $('ebPanel').checked = cur.show_on_panel === undefined ? true : !!cur.show_on_panel;
    $('ebAttach').innerHTML = '<option value="">— окрема подія —</option>' +
        EVENTS.filter((x) => x.id !== cur.id).map((x) =>
            `<option value="${escapeHtml(x.key)}"${x.key === (cur.attach_to || '') ? ' selected' : ''}>у вікні «${escapeHtml(x.name)}»</option>`).join('');
    $('ebDel').style.display = (!cur.is_standard || window.canManage('herd')) ? '' : 'none';
    setStep(step);
}

function setStep(n) {
    step = n;
    document.querySelectorAll('#ebSteps .eb-step').forEach((b) =>
        b.classList.toggle('is-active', +b.dataset.step === n));
    $('ebS1').hidden = n !== 1;
    $('ebS2').hidden = n !== 2;
    $('ebS3').hidden = n !== 3;
    $('ebNote').textContent = { 1: 'Крок 1 з 3 — хто може вносити подію',
        2: 'Крок 2 з 3 — поля, що зʼявляться у формі',
        3: 'Крок 3 з 3 — перевірка перед збереженням' }[n];
    $('ebNext').textContent = n === 3 ? 'Зберегти' : 'Далі';
    $('ebPrev').textContent = n === 1 ? 'До списку' : 'Назад';
    if (n === 1) renderUsers();
    if (n === 2) renderFields();
    if (n === 3) renderReview();
}

/* --- крок 1: доступ --- */
function renderUsers() {
    const box = $('ebUsers');
    if (!USERS.length) { box.innerHTML = '<div class="eb-empty">Користувачів немає</div>'; return; }
    box.innerHTML = USERS.map((u) => `<div class="eb-user${ACCESS.includes(u.id) ? ' on' : ''}" data-uid="${u.id}">
        <span class="ini">${escapeHtml(u.ini)}</span>
        <span><span class="nm">${escapeHtml(u.name)}</span><br><span class="rl">${escapeHtml(u.role)}</span></span>
    </div>`).join('');
    box.querySelectorAll('.eb-user').forEach((el) => el.addEventListener('click', () => {
        const id = +el.dataset.uid;
        ACCESS = ACCESS.includes(id) ? ACCESS.filter((x) => x !== id) : ACCESS.concat([id]);
        dirty = true; renderUsers();
    }));
    $('ebAllUsers').textContent = ACCESS.length === USERS.length ? 'Зняти всіх' : 'Обрати всіх';
}

/* --- крок 2: поля --- */
function renderFields() {
    const rows = WORK.filter(isInput);
    const box = $('ebFields');
    if (!rows.length) {
        box.innerHTML = '<tr><td colspan="7" class="eb-empty">Подія нічого не питає в оператора — '
            + 'додайте параметр, якщо потрібна форма</td></tr>';
    } else {
        box.innerHTML = rows.map((e) => {
            const p = paramByKey(e.param_key);
            const name = p ? p.label : e.param_key;
            const unit = (p && p.unit) ? ', ' + p.unit : '';
            const det = openRow === e.param_key ? `<tr class="eb-det" data-det="${escapeHtml(e.param_key)}"><td></td>
                <td colspan="6"><div class="row">
                    <span class="k">Значення за замовчуванням</span>
                    <input type="text" class="eb-def" value="${escapeHtml(e.arg || '')}"
                           placeholder="порожньо — оператор вводить сам">
                    <span class="k">${escapeHtml((p && p.desc) || 'параметр із довідника «Параметри тварин»')}</span>
                </div></td></tr>` : '';
            return `<tr data-code="${escapeHtml(e.param_key)}" draggable="true"
                        class="${isOn(e) ? '' : 'is-off'}">
                <td class="eb-drag" title="Перетягніть, щоб змінити порядок">⠿</td>
                <td><span class="nm">${escapeHtml(name + unit)}</span>
                    <span class="sub">${escapeHtml(e.param_key)}${p && p.section ? ' · ' + escapeHtml(p.section) : ''}</span></td>
                <td><span class="eb-type">${escapeHtml(typeLabel(p))}</span></td>
                <td class="c"><input type="checkbox" class="eb-req"${e.required ? ' checked' : ''}></td>
                <td><button type="button" class="eb-place${e.quick ? ' quick' : ''}">${e.quick ? 'Швидкий блок' : 'Розширені'}</button></td>
                <td class="c"><input type="checkbox" class="eb-on"${isOn(e) ? ' checked' : ''}></td>
                <td class="c"><button type="button" class="eb-x" title="Прибрати з події">✕</button></td>
            </tr>${det}`;
        }).join('');
    }
    const autos = WORK.filter((e) => !isInput(e)).length;
    $('ebAutoNote').innerHTML = autos
        ? `Подія також робить <b>${autos}</b> ${autos === 1 ? 'автоматичну дію' : 'автоматичних дій'} `
          + '(ставить код, дату, лічильник) — вони на кроці «Перегляд», редагуються в «Розширено».'
        : 'Автоматичних дій у події немає — додати їх можна в «Розширено».';
    bindFieldRows();
}

function bindFieldRows() {
    const box = $('ebFields');
    const find = (code) => WORK.find((x) => x.param_key === code && isInput(x));
    box.querySelectorAll('tr[data-code]').forEach((tr) => {
        const code = tr.dataset.code;
        const e = find(code);
        if (!e) return;
        tr.querySelector('.eb-req').addEventListener('change', (ev) => {
            e.required = ev.target.checked ? 1 : 0; dirty = true;
        });
        tr.querySelector('.eb-on').addEventListener('change', (ev) => {
            e.enabled = ev.target.checked ? 1 : 0; dirty = true; renderFields();
        });
        tr.querySelector('.eb-place').addEventListener('click', () => {
            e.quick = e.quick ? 0 : 1; dirty = true; renderFields();
        });
        tr.querySelector('.eb-x').addEventListener('click', () => {
            WORK = WORK.filter((x) => x !== e); dirty = true; renderFields();
        });
        tr.querySelector('.nm').addEventListener('click', () => {
            openRow = openRow === code ? '' : code; renderFields();
        });
        tr.addEventListener('dragstart', () => { dragCode = code; });
        tr.addEventListener('dragover', (ev) => { ev.preventDefault(); tr.classList.add('drag-over'); });
        tr.addEventListener('dragleave', () => tr.classList.remove('drag-over'));
        tr.addEventListener('drop', (ev) => {
            ev.preventDefault(); tr.classList.remove('drag-over');
            if (!dragCode || dragCode === code) return;
            const from = WORK.findIndex((x) => x.param_key === dragCode && isInput(x));
            const to = WORK.findIndex((x) => x.param_key === code && isInput(x));
            if (from < 0 || to < 0) return;
            WORK.splice(to, 0, WORK.splice(from, 1)[0]);
            dragCode = ''; dirty = true; renderFields();
        });
    });
    box.querySelectorAll('.eb-det').forEach((tr) => {
        const e = find(tr.dataset.det); if (!e) return;
        const inp = tr.querySelector('.eb-def');
        inp.addEventListener('input', () => { e.arg = inp.value; dirty = true; });
    });
}

/* --- крок 3: перегляд --- */
function renderReview() {
    const autos = WORK.filter((e) => !isInput(e) && isOn(e));
    const asks = WORK.filter((e) => isInput(e) && isOn(e));
    const req = asks.filter((e) => e.required);
    const defs = asks.filter((e) => (e.arg || '').trim());
    const none = (t) => `<div class="none">${t}</div>`;

    $('ebChanges').innerHTML = autos.length
        ? autos.map((e) => { const s = sentence(e); return s ? `<div class="li">→ ${s}</div>` : ''; }).join('')
        : none('Подія нічого не змінює сама');

    $('ebRequired').innerHTML = req.length
        ? req.map((e) => {
            const p = paramByKey(e.param_key);
            const hint = p && (p.choices || []).length ? 'вибір зі списку' : ((p && p.desc) || 'вводить оператор');
            return `<div class="li"><span><b>${escapeHtml(p ? p.label : e.param_key)}</b><br>
                <span style="font-size:12px;color:var(--text-mute)">${escapeHtml(hint)}</span></span></div>`;
        }).join('')
        : none('Обовʼязкових полів немає');

    $('ebDefaults').innerHTML = defs.length
        ? defs.map((e) => {
            const p = paramByKey(e.param_key);
            return `<div class="li"><span>${escapeHtml(p ? p.label : e.param_key)}</span>
                <span class="v">${escapeHtml(codeLabel(e.param_key, e.arg))}</span></div>`;
        }).join('')
        : none('Значень за замовчуванням немає');
}

/* --- збереження --- */
async function save(quiet) {
    if (!cur) return false;
    const payload = {
        name: $('ebName').value.trim() || cur.name,
        category: $('ebCat').value,
        is_active: $('ebActive').checked,
        show_on_panel: $('ebPanel').checked,
        attach_to: $('ebAttach').value || '',
        access: ACCESS,
        effects: WORK.map((e) => ({ param_key: e.param_key, mode: e.mode, arg: e.arg || '',
            required: e.required ? 1 : 0, quick: e.quick ? 1 : 0, enabled: e.enabled ? 1 : 0 })),
    };
    const r = await apiSend('/api/herd/events/' + cur.id, 'POST', payload);
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return false; }
    dirty = false;
    if (!quiet) toast('Збережено', 'success');
    await load();
    return true;
}

/* ═══════════ ВИБІР ПАРАМЕТРА ═══════════ */
function openPicker() {
    pkQ = ''; pkCat = 'Усі';
    $('pkQuery').value = '';
    $('evPicker').hidden = false;
    renderPicker();
    setTimeout(() => $('pkQuery').focus(), 60);
}
function renderPicker() {
    const cats = ['Усі'].concat([...new Set(PARAMS.map((p) => p.section).filter(Boolean))]);
    $('pkCats').innerHTML = cats.map((c) =>
        `<button type="button" class="pk-cat${pkCat === c ? ' on' : ''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
    $('pkCats').querySelectorAll('.pk-cat').forEach((b) => b.addEventListener('click', () => {
        pkCat = b.dataset.cat; renderPicker();
    }));
    const q = pkQ.toLowerCase();
    const list = PARAMS.filter((p) => (pkCat === 'Усі' || p.section === pkCat)
        && (!q || (p.label + ' ' + p.key).toLowerCase().includes(q)));
    const inEvent = (code) => WORK.some((x) => x.param_key === code && isInput(x));
    $('pkList').innerHTML = list.length ? list.map((p) => `<div class="pk-row${inEvent(p.key) ? ' on' : ''}" data-code="${escapeHtml(p.key)}">
        <input type="checkbox" ${inEvent(p.key) ? 'checked' : ''}>
        <span><span class="nm">${escapeHtml(p.label)}${p.unit ? ', ' + escapeHtml(p.unit) : ''}</span><br>
            <span class="sub">${escapeHtml(p.key)}${p.section ? ' · ' + escapeHtml(p.section) : ''}${p.desc ? ' · ' + escapeHtml(p.desc) : ''}</span></span>
        <span class="eb-type">${escapeHtml(typeLabel(p))}</span></div>`).join('')
        : '<div class="eb-empty">Нічого не знайдено за цим запитом</div>';
    $('pkList').querySelectorAll('.pk-row').forEach((row) => row.addEventListener('click', () => {
        const code = row.dataset.code;
        if (inEvent(code)) WORK = WORK.filter((x) => !(x.param_key === code && isInput(x)));
        else WORK.push({ param_key: code, mode: 'input', arg: '', required: 0, quick: 1, enabled: 1 });
        dirty = true; renderPicker();
    }));
    const n = WORK.filter(isInput).length;
    $('pkNote').textContent = `У події «${cur ? cur.name : ''}»: ${n} ${n === 1 ? 'поле' : 'полів'}`;
}
function closePicker() { $('evPicker').hidden = true; renderFields(); }

/* ═══════════ РОЗШИРЕНО: повний редактор дій ═══════════ */
function autoModeOptions(sel) {
    return Object.entries(MODES).filter(([k]) => k !== 'input').map(([k, v]) =>
        `<option value="${k}"${k === sel ? ' selected' : ''}>${escapeHtml(v)}</option>`).join('');
}
function argControlHtml(param, val) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        const opts = '<option value="">—</option>' + ch.map((c) =>
            `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('');
        return `<select class="ref-select ee-arg">${opts}</select>`;
    }
    return `<input type="text" class="ref-select ee-arg" placeholder="значення" value="${escapeHtml(val || '')}">`;
}
function paramSelectHtml(sel, cls) {
    return `<select class="ref-select ${cls}"><option value="">— параметр —</option>`
        + PARAMS.map((p) => `<option value="${escapeHtml(p.key)}"${p.key === sel ? ' selected' : ''}>${escapeHtml(p.label)}</option>`).join('')
        + '</select>';
}
function valControlHtml(param, val, cls) {
    const ch = (param && param.choices) || [];
    if (ch.length) {
        return `<select class="ref-select ${cls}"><option value="">—</option>`
            + ch.map((c) => `<option value="${escapeHtml(c.value)}"${String(c.value) === String(val || '') ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')
            + '</select>';
    }
    return `<input type="text" class="ref-select ${cls}" value="${escapeHtml(val || '')}" placeholder="значення" style="width:88px">`;
}
function parseWhenSpec(arg) {
    let d = {};
    try { if (arg && arg.trim().startsWith('{')) d = JSON.parse(arg); } catch (e) { d = {}; }
    if (d && Array.isArray(d.rules)) {
        return {
            rules: d.rules.map((r) => ({ if: r.if || '', eq: r.eq || '', val: r.val || '' })),
            default: d.default || '',
        };
    }
    if (d && (d.if || d.eq || d.val)) {
        if (!d.if) return { rules: [], default: d.val || '' };
        return { rules: [{ if: d.if, eq: d.eq || '', val: d.val || '' }], default: '' };
    }
    return { rules: [], default: '' };
}
function whenRuleLineHtml(targetParam, r) {
    const ifParam = paramByKey(r.if);
    return `<div class="ee-when-line" data-role="rule">`
        + `<span class="ee-op">якщо</span> ${paramSelectHtml(r.if, 'ee-if')} `
        + `<span class="ee-op">=</span> ${valControlHtml(ifParam, r.eq, 'ee-ifval')} `
        + `<span class="ee-op">→</span> ${valControlHtml(targetParam, r.val, 'ee-val')}`
        + `<button type="button" class="ee-line-del" title="Прибрати умову">✕</button></div>`;
}
function whenDefaultLineHtml(targetParam, val) {
    return `<div class="ee-when-line ee-when-def" data-role="default">`
        + `<span class="ee-op">інакше</span> <span class="ee-op">→</span> `
        + `${valControlHtml(targetParam, val, 'ee-val')}</div>`;
}
function whenBlockHtml(targetParam, arg) {
    const spec = parseWhenSpec(arg);
    const rules = spec.rules.length ? spec.rules : [{ if: '', eq: '', val: '' }];
    const lines = rules.map((r) => whenRuleLineHtml(targetParam, r)).join('')
        + whenDefaultLineHtml(targetParam, spec.default);
    return `<div class="ee-when"><div class="ee-when-lines">${lines}</div>`
        + `<button type="button" class="ee-when-add">+ ще «якщо»</button></div>`;
}
function readWhenBlock(scope) {
    const rules = [];
    scope.querySelectorAll('.ee-when-line[data-role="rule"]').forEach((l) => {
        rules.push({
            if: (l.querySelector('.ee-if') || {}).value || '',
            eq: (l.querySelector('.ee-ifval') || {}).value || '',
            val: (l.querySelector('.ee-val') || {}).value || '',
        });
    });
    const dl = scope.querySelector('.ee-when-line[data-role="default"] .ee-val');
    return { rules, default: dl ? dl.value : '' };
}
function argHtmlFor(param, mode, ask, val) {
    if (!ask && mode === 'when') return whenBlockHtml(param, val);
    return argControlHtml(param, val);
}
function effRow(e) {
    e = e || { param_key: '', mode: 'const', arg: '' };
    const ask = e.mode === 'input';
    const autoMode = ask ? 'const' : (e.mode || 'const');
    const div = document.createElement('div');
    div.className = 'ev-eff-row';
    const curParam = paramByKey(e.param_key);
    div.innerHTML =
        `<input type="text" class="ref-select ee-param" list="eeParamDL" placeholder="пошук параметра…"
             value="${escapeHtml(curParam ? curParam.label : '')}" autocomplete="off">
         <label class="ee-ask" title="Питати значення в оператора під час події">
             <input type="checkbox" class="ee-ask-cb" ${ask ? 'checked' : ''}> Питати</label>
         <select class="ref-select ee-mode">${autoModeOptions(autoMode)}</select>
         <span class="ee-arg-wrap"></span>
         <button type="button" class="ev-eff-del" title="Прибрати">✕</button>`;
    const askCb = div.querySelector('.ee-ask-cb');
    const modeSel = div.querySelector('.ee-mode');
    const paramSel = div.querySelector('.ee-param');
    const argWrap = div.querySelector('.ee-arg-wrap');
    const isWhenMode = () => !askCb.checked && modeSel.value === 'when';
    const sync = () => {
        const asking = askCb.checked;
        modeSel.disabled = asking;
        const argInp = div.querySelector('.ee-arg');
        if (argInp) {
            const showArg = asking || ARG_MODES.has(modeSel.value);
            argInp.style.visibility = showArg ? '' : 'hidden';
            if (argInp.tagName === 'INPUT') argInp.placeholder = asking ? 'за замовч. (необовʼязково)' : 'значення';
        }
    };
    const renderArg = (val) => {
        const tgt = paramByLabel(paramSel.value) || curParam;
        div.classList.toggle('has-when', isWhenMode());
        argWrap.innerHTML = argHtmlFor(tgt, askCb.checked ? 'input' : modeSel.value, askCb.checked, val);
        sync();
    };
    const keepWhen = () => renderArg(isWhenMode() ? JSON.stringify(readWhenBlock(argWrap)) : '');
    paramSel.addEventListener('change', keepWhen);
    paramSel.addEventListener('input', keepWhen);
    askCb.addEventListener('change', () => renderArg(''));
    modeSel.addEventListener('change', () => renderArg(''));
    argWrap.addEventListener('click', (ev) => {
        if (ev.target.closest('.ee-when-add')) {
            const s = readWhenBlock(argWrap); s.rules.push({ if: '', eq: '', val: '' });
            renderArg(JSON.stringify(s));
        } else if (ev.target.closest('.ee-line-del')) {
            const line = ev.target.closest('.ee-when-line');
            const idx = [...argWrap.querySelectorAll('.ee-when-line[data-role="rule"]')].indexOf(line);
            const s = readWhenBlock(argWrap); s.rules.splice(idx, 1);
            renderArg(JSON.stringify(s));
        }
    });
    argWrap.addEventListener('change', (ev) => {
        if (ev.target.classList.contains('ee-if')) renderArg(JSON.stringify(readWhenBlock(argWrap)));
    });
    div.querySelector('.ev-eff-del').addEventListener('click', () => div.remove());
    renderArg(e.arg);
    return div;
}
function collectEffects() {
    const out = [];
    document.querySelectorAll('#eeEffects .ev-eff-row').forEach((r) => {
        const p = paramByLabel(r.querySelector('.ee-param').value);
        const pk = p ? p.key : '';
        if (!pk) return;
        const asking = r.querySelector('.ee-ask-cb').checked;
        const mode = asking ? 'input' : r.querySelector('.ee-mode').value;
        let arg = '';
        if (mode === 'when') {
            const s = readWhenBlock(r.querySelector('.ee-arg-wrap'));
            const rules = s.rules.filter((x) => x.if);
            if (!rules.length && !s.default) return;
            arg = JSON.stringify({ rules, default: s.default });
        } else if (asking || ARG_MODES.has(mode)) {
            const el = r.querySelector('.ee-arg');
            arg = el ? el.value.trim() : '';
        }
        // ознаки поля (обовʼязкове / швидкий блок / увімкнено) переносимо зі старого запису
        const prev = WORK.find((x) => x.param_key === pk && x.mode === mode) || {};
        out.push({ param_key: pk, mode, arg,
            required: prev.required ? 1 : 0,
            quick: ('quick' in prev && !prev.quick) ? 0 : 1,
            enabled: ('enabled' in prev && !prev.enabled) ? 0 : 1 });
    });
    return out;
}
function openAdvanced() {
    $('eeTitle').textContent = 'Розширено: ' + (cur ? cur.name : '');
    const box = $('eeEffects'); box.innerHTML = '';
    WORK.forEach((e) => box.appendChild(effRow(e)));
    if (!WORK.length) box.appendChild(effRow(null));
    $('evEditModal').hidden = false;
}

/* ═══════════ САМОПЕРЕВІРКА ═══════════ */
$('evSelftestBtn').addEventListener('click', async () => {
    const out = $('evSelftestOut');
    out.hidden = false;
    out.innerHTML = '<div class="text-mute">Проганяю тестову тварину по колу…</div>';
    const r = await apiSend('/api/herd/repro-selftest', 'POST', {});
    if (!r || !r.ok) { out.innerHTML = `<div class="evx-verdict bad">Помилка: ${escapeHtml((r && r.error) || '')}</div>`; return; }
    const ok = r.checks.every((c) => c.ok);
    out.innerHTML = `<div class="evx-verdict ${ok ? 'ok' : 'bad'}">${ok
        ? '✅ Алгоритм виконується, коло замкнене' : '⚠ Знайдено проблеми — дивіться червоні рядки'}</div>`
        + r.checks.map((c) => `<div class="row ${c.ok ? 'ok' : 'bad'}">
            <span class="m">${c.ok ? '✓' : '✗'}</span>
            <span>${escapeHtml(c.label)}</span>
            ${c.note ? `<span class="note">· ${escapeHtml(c.note)}</span>` : ''}
        </div>`).join('');
});

/* ═══════════ ПОДІЇ ІНТЕРФЕЙСУ ═══════════ */
document.querySelectorAll('#ebSteps .eb-step').forEach((b) =>
    b.addEventListener('click', () => setStep(+b.dataset.step)));
$('ebPrev').addEventListener('click', () => {
    if (step === 1) closeBuilder(true); else setStep(step - 1);
});
$('ebNext').addEventListener('click', async () => {
    if (step < 3) { setStep(step + 1); return; }
    if (await save(false)) closeBuilder(false);
});
$('ebBack').addEventListener('click', () => closeBuilder(true));
$('ebAllUsers').addEventListener('click', () => {
    ACCESS = ACCESS.length === USERS.length ? [] : USERS.map((u) => u.id);
    dirty = true; renderUsers();
});
$('ebAddParam').addEventListener('click', openPicker);
$('ebAdv').addEventListener('click', openAdvanced);
['ebName', 'ebCat', 'ebActive', 'ebPanel', 'ebAttach'].forEach((id) =>
    $(id).addEventListener('change', () => { dirty = true; }));
$('ebName').addEventListener('input', () => { dirty = true; });

$('ebDel').addEventListener('click', async () => {
    if (!cur) return;
    if (cur.is_standard && !window.canManage('herd')) { toast('Системну подію видаляє лише адмін', 'warn'); return; }
    if (!confirm(`Видалити подію «${cur.name}»?`)) return;
    const r = await apiSend('/api/herd/events/' + cur.id, 'DELETE');
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    dirty = false;
    await closeBuilder(false);
    await load();
});

$('evNew').addEventListener('click', async () => {
    const r = await apiSend('/api/herd/events', 'POST',
        { name: 'Нова подія', category: 'other', effects: [] });
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    await load();
    const ev = EVENTS.find((e) => e.id === r.id);
    if (ev) { openBuilder(ev); $('ebName').focus(); $('ebName').select(); }
});

$('pkQuery').addEventListener('input', () => { pkQ = $('pkQuery').value; renderPicker(); });
$('pkDone').addEventListener('click', closePicker);
document.querySelectorAll('#evPicker [data-pclose]').forEach((el) =>
    el.addEventListener('click', closePicker));

$('eeAddEff').addEventListener('click', () => $('eeEffects').appendChild(effRow(null)));
$('eeSaveBtn').addEventListener('click', () => {
    WORK = collectEffects();
    dirty = true;
    $('evEditModal').hidden = true;
    setStep(step);
});
document.querySelectorAll('#evEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('evEditModal').hidden = true; }));

document.addEventListener('herd-params-changed', () => { if ($('evList')) load(); });
if ($('evList')) load();
})();
