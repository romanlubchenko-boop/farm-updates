/* Груповий ввід події: таблиця тварин ліворуч, форма події праворуч.
   Поля беруться з конструктора події (швидкий блок, обовʼязкові, вимкнені
   пропускаються). Проведення — тим самим /api/herd/apply-event-bulk. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let EVENTS = [], ANIMALS = [], GROUPS = [], CHOICES = {};
let sel = new Set(), gFilter = '', query = '';

const todayISO = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

async function load() {
    const [ev, an] = await Promise.all([
        apiGet('/api/herd/events?active=1'),
        apiGet('/api/herd/animals'),
    ]);
    if (!ev || !ev.ok) { toast((ev && ev.error) || 'Помилка', 'error'); return; }
    EVENTS = (ev.events || []).filter((e) => e.show_on_panel === undefined || e.show_on_panel);
    CHOICES = {};
    (ev.params || []).forEach((p) => { CHOICES[p.key] = p.choices || []; });
    ANIMALS = ((an && an.ok) ? (an.animals || an.items || []) : [])
        .filter((a) => a.status === 'active');
    // секції — з самих тварин: показуємо лише ті, де хтось є
    const seen = new Map();
    ANIMALS.forEach((a) => { if (a.group_name) seen.set(String(a.group_id), a.group_name); });
    GROUPS = [...seen.entries()].map(([id, name]) => ({ id, name }))
        .sort((x, y) => x.name.localeCompare(y.name, 'uk'));

    $('hgEvent').innerHTML = EVENTS.map((e) =>
        `<option value="${e.id}">${escapeHtml(e.name)}</option>`).join('')
        || '<option value="">подій немає</option>';
    $('hgGroup').innerHTML = '<option value="">Усі секції</option>'
        + GROUPS.map((g) => `<option value="${escapeHtml(g.id)}">${escapeHtml(g.name)}</option>`).join('');
    $('hgDate').value = todayISO();
    renderViews();
    renderTable();
    renderFields();
}

function renderViews() {
    $('hgViews').innerHTML = GROUPS.slice(0, 4).map((g) =>
        `<button type="button" class="hg-view${gFilter === String(g.id) ? ' on' : ''}"
             data-g="${escapeHtml(g.id)}">${escapeHtml(g.name)}</button>`).join('');
    $('hgViews').querySelectorAll('.hg-view').forEach((b) => b.addEventListener('click', () => {
        gFilter = gFilter === b.dataset.g ? '' : b.dataset.g;
        $('hgGroup').value = gFilter;
        renderViews(); renderTable();
    }));
}

function filtered() {
    const q = query.trim().toLowerCase();
    return ANIMALS.filter((a) => (!gFilter || String(a.group_id) === gFilter)
        && (!q || (`${a.tag} ${a.name || ''}`).toLowerCase().includes(q)));
}

function renderTable() {
    const list = filtered();
    $('hgCount').textContent = list.length ? `· ${list.length}` : '';
    $('hgBody').innerHTML = list.length ? list.map((a) => `<tr data-id="${a.id}"${sel.has(a.id) ? ' class="on"' : ''}>
        <td class="c"><input type="checkbox" ${sel.has(a.id) ? 'checked' : ''}></td>
        <td class="tag">${escapeHtml(a.tag)}</td>
        <td>${escapeHtml(a.name || '')}</td>
        <td>${escapeHtml(a.group_name || '')}</td>
        <td class="num">${a.lactation_no || ''}</td>
        <td>${escapeHtml(a.status_label || '')}</td></tr>`).join('')
        : '<tr><td colspan="6" class="hg-empty">Тварин за цим фільтром немає</td></tr>';
    $('hgBody').querySelectorAll('tr[data-id]').forEach((tr) => tr.addEventListener('click', (e) => {
        const id = +tr.dataset.id;
        if (sel.has(id)) sel.delete(id); else sel.add(id);
        if (e.target.tagName !== 'INPUT') {
            const cb = tr.querySelector('input'); if (cb) cb.checked = sel.has(id);
        }
        tr.classList.toggle('on', sel.has(id));
        syncSel();
    }));
    const all = list.length && list.every((a) => sel.has(a.id));
    $('hgAll').checked = !!all;
    syncSel();
}

function curEvent() {
    const id = +$('hgEvent').value;
    return EVENTS.find((e) => e.id === id) || null;
}

function inputControl(eff) {
    const ch = CHOICES[eff.param_key] || [];
    if (ch.length) {
        const isCod = eff.param_dtype === 'cod' || eff.param_dtype === 'code';
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) =>
            `<option value="${escapeHtml(c.value)}"${String(c.value) === String(eff.arg || '') ? ' selected' : ''}>`
            + `${escapeHtml(isCod ? c.label : `${i + 1}. ${c.label}`)}</option>`).join('');
        return `<select class="hg-in hg-input" data-key="${escapeHtml(eff.param_key)}"`
            + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}">${opts}</select>`;
    }
    const dt = eff.param_dtype;
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float') ? 'number' : 'text');
    const step = dt === 'float' ? ' step="0.01"' : '';
    return `<input type="${type}"${step} class="hg-in hg-input" data-key="${escapeHtml(eff.param_key)}"`
        + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}"`
        + ` value="${escapeHtml(eff.arg || '')}" placeholder="значення">`;
}

function renderFields() {
    const ev = curEvent();
    const effs = ev ? (ev.effects || []).filter((e) => e.mode === 'input'
        && (!('enabled' in e) || e.enabled)) : [];
    $('hgInputs').innerHTML = effs.map((eff) => `<label class="hg-f">
        <span class="hg-lbl">${escapeHtml(eff.param_label)}${eff.required ? '<span class="hg-req"> *</span>' : ''}</span>
        ${inputControl(eff)}</label>`).join('');
    $('hgReqNote').textContent = effs.some((e) => e.required) ? 'Поля із * — обовʼязкові' : '';
    $('hgAuto').textContent = (ev && ev.births)
        ? 'Приплід у груповому режимі не вноситься — для отелів відкривайте подію на сторінці «Події».'
        : '';
    syncSel();
}

function syncSel() {
    const n = sel.size;
    $('hgSel').textContent = n
        ? `Подію буде записано для ${n} тварин(и). Індивідуальні значення (№ теляти, вага) у груповому режимі недоступні.`
        : 'Оберіть тварин у таблиці зліва.';
    $('hgSubmit').disabled = !n;
    $('hgSubmit').textContent = n ? `Зберегти для ${n} тварин(и)` : 'Зберегти';
}

async function submit() {
    const ev = curEvent();
    if (!ev) { toast('Оберіть подію', 'warn'); return; }
    if (!sel.size) { toast('Оберіть тварин', 'warn'); return; }
    const inputs = {};
    let miss = null;
    document.querySelectorAll('#hgInputs .hg-input').forEach((el) => {
        const v = String(el.value || '').trim();
        if (v) inputs[el.dataset.key] = v;
        else if (el.dataset.req === '1' && !miss) miss = el;
    });
    if (miss) {
        toast('Заповніть обовʼязкове поле: ' + (miss.dataset.label || miss.dataset.key), 'warn');
        miss.focus(); return;
    }
    $('hgSubmit').disabled = true;
    const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
        animal_ids: [...sel], event_id: ev.id,
        event_date: $('hgDate').value || todayISO(),
        inputs, note: ($('hgNote').value || '').trim(),
    });
    $('hgSubmit').disabled = false;
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    toast(`«${ev.name}» записано для ${r.applied || sel.size} тварин(и)`, 'success');
    sel = new Set();
    $('hgNote').value = '';
    renderTable();
}

$('hgGroup').addEventListener('change', () => {
    gFilter = $('hgGroup').value; renderViews(); renderTable();
});
$('hgQuery').addEventListener('input', () => { query = $('hgQuery').value; renderTable(); });
$('hgAll').addEventListener('change', () => {
    const list = filtered();
    const all = list.every((a) => sel.has(a.id));
    list.forEach((a) => { if (all) sel.delete(a.id); else sel.add(a.id); });
    renderTable();
});
$('hgEvent').addEventListener('change', renderFields);
$('hgSubmit').addEventListener('click', submit);

load();
})();
