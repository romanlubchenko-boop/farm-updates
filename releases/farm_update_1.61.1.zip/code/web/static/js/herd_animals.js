/* Реєстр тварин (поголівний облік) — Фаза 1. */
'use strict';

const EVENT_TYPES = [
    { t: 'Осіменіння', c: 'repro' },
    { t: 'Перевірка тільності', c: 'repro' },
    { t: 'Тільна', c: 'repro' },
    { t: 'Ялова', c: 'repro' },
    { t: 'Запуск (сухостій)', c: 'repro' },
    { t: 'Отел', c: 'repro' },
    { t: 'Аборт', c: 'repro' },
    { t: 'Лікування', c: 'health' },
    { t: 'Вакцинація', c: 'health' },
    { t: 'Ветогляд', c: 'health' },
    { t: 'Одужання', c: 'health' },
    { t: 'Переведення', c: 'move' },
    { t: 'Зважування', c: 'prod' },
    { t: 'Контрольний надій', c: 'prod' },
    { t: 'Інше', c: 'other' },
];
const CAT_OF = Object.fromEntries(EVENT_TYPES.map((e) => [e.t, e.c]));
const SEX_LABEL = { F: 'Жіноча', M: 'Чоловіча' };

let ALL_GROUPS = [];
let STATUSES = {};
let currentAnimal = null;

const $ = (id) => document.getElementById(id);
const bind = (id, ev, fn) => { const el = $(id); if (el) el.addEventListener(ev, fn); };
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------- список ---------- */
async function loadList() {
    const params = new URLSearchParams();
    const q = $('animSearch').value.trim();
    if (q) params.set('q', q);
    if ($('animStatus').value) params.set('status', $('animStatus').value);
    if ($('animSex').value) params.set('sex', $('animSex').value);
    if ($('animGroup').value) params.set('group_id', $('animGroup').value);
    const r = await apiGet('/api/herd/animals?' + params.toString());
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    STATUSES = r.statuses || {};
    ALL_GROUPS = r.groups || [];
    fillFilters();
    renderStats(r.stats || {});
    renderTable(r.items || []);
}

function fillFilters() {
    const st = $('animStatus');
    if (st.options.length <= 1) {
        Object.entries(STATUSES).forEach(([k, v]) => {
            const o = document.createElement('option'); o.value = k; o.textContent = v;
            st.appendChild(o);
        });
    }
    const g = $('animGroup');
    if (g.options.length <= 1) {
        ALL_GROUPS.forEach((gr) => {
            const o = document.createElement('option'); o.value = gr.id; o.textContent = gr.name;
            g.appendChild(o);
        });
    }
}

function renderStats(s) {
    $('animStats').innerHTML =
        `<div class="anim-stat"><b>${s.active || 0}</b><span>В стаді</span></div>` +
        `<div class="anim-stat"><b>${s.cows || 0}</b><span>Корів/телиць</span></div>`;
}

function renderTable(items) {
    $('animCount').textContent = items.length ? `· ${items.length}` : '';
    const tb = $('animBody');
    if (!items.length) {
        tb.innerHTML = '<tr><td colspan="8" class="empty">Немає тварин. Додайте або імпортуйте.</td></tr>';
        return;
    }
    tb.innerHTML = items.map((a) => `
        <tr data-id="${a.id}">
            <td><b>${escapeHtml(a.tag)}</b></td>
            <td>${escapeHtml(a.name || '')}</td>
            <td>${SEX_LABEL[a.sex] || ''}</td>
            <td class="num">${a.age_months == null ? '' : a.age_months}</td>
            <td>${escapeHtml(a.breed || '')}</td>
            <td>${escapeHtml(a.group_name || '')}</td>
            <td class="num">${a.lactation_no || ''}</td>
            <td><span class="anim-badge ${a.status}">${escapeHtml(a.status_label || '')}</span></td>
        </tr>`).join('');
    tb.querySelectorAll('tr[data-id]').forEach((tr) =>
        tr.addEventListener('click', () => { location.href = '/herd/animals/' + tr.dataset.id; }));
}

/* ---------- модал додати/редагувати ---------- */
function groupOptions(sel) {
    return '<option value="">—</option>' + ALL_GROUPS.map((g) =>
        `<option value="${g.id}"${String(g.id) === String(sel || '') ? ' selected' : ''}>${escapeHtml(g.name)}</option>`).join('');
}

function openEdit(a) {
    const isNew = !a;
    $('animEditTitle').textContent = isNew ? 'Нова тварина' : 'Редагувати тварину';
    $('afTag').value = a ? a.tag : '';
    $('afName').value = a ? (a.name || '') : '';
    $('afSex').value = a ? a.sex : 'F';
    $('afBirth').value = a ? (a.birth_date || '') : '';
    $('afBreed').value = a ? (a.breed || '') : '';
    $('afGroup').innerHTML = groupOptions(a ? a.group_id : '');
    $('afDam').value = a ? (a.dam_tag || '') : '';
    $('afSire').value = a ? (a.sire_code || '') : '';
    $('afLact').value = a ? (a.lactation_no || 0) : 0;
    $('afSource').value = a ? (a.source || 'born') : 'born';
    $('afEntry').value = a ? (a.entry_date || '') : todayISO();
    $('afNotes').value = a ? (a.notes || '') : '';
    $('afSaveBtn').dataset.id = a ? a.id : '';
    show('animEditModal');
    $('afTag').focus();
}

async function saveAnimal() {
    const id = $('afSaveBtn').dataset.id;
    const payload = {
        tag: $('afTag').value, name: $('afName').value, sex: $('afSex').value,
        birth_date: $('afBirth').value, breed: $('afBreed').value,
        group_id: $('afGroup').value, dam_tag: $('afDam').value,
        sire_code: $('afSire').value, lactation_no: $('afLact').value,
        source: $('afSource').value, entry_date: $('afEntry').value,
        notes: $('afNotes').value,
    };
    const url = id ? '/api/herd/animals/' + id : '/api/herd/animals';
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Збережено', 'success');
    hide('animEditModal');
    await loadList();
    if (id) openCard(parseInt(id, 10));
}

/* ---------- картка ---------- */
async function openCard(id) {
    const r = await apiGet('/api/herd/animals/' + id);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    currentAnimal = r;
    $('acTitle').textContent = `Картка · ${r.tag}${r.name ? ' «' + r.name + '»' : ''}`;
    const kv = (k, v) => v ? `<div><div class="k">${k}</div><div class="v">${escapeHtml(String(v))}</div></div>` : '';
    $('acHeader').innerHTML =
        kv('Статус', r.status_label) + kv('Стать', r.sex === 'M' ? 'Чоловіча' : 'Жіноча') +
        kv('Вік, міс', r.age_months == null ? '' : r.age_months) +
        kv('Дата народж.', r.birth_date) + kv('Порода', r.breed) +
        kv('Секція', r.group_name) + kv('Лактація', r.lactation_no || '') +
        kv('Надходження', r.entry_date) + (r.notes ? kv('Нотатки', r.notes) : '');
    // родовід
    let ped = '';
    ped += `<div>Мама: ${r.dam ? escapeHtml(r.dam.tag) + (r.dam.name ? ' «' + escapeHtml(r.dam.name) + '»' : '') : (r.dam_tag ? escapeHtml(r.dam_tag) + ' (немає в базі)' : '—')}</div>`;
    ped += `<div>Батько/бик: ${r.sire_code ? escapeHtml(r.sire_code) : '—'}</div>`;
    if (r.offspring && r.offspring.length) {
        ped += `<div>Нащадки (${r.offspring.length}): ` +
            r.offspring.map((o) => escapeHtml(o.tag)).join(', ') + '</div>';
    }
    $('acPedigree').innerHTML = ped;
    renderTimeline(r.events || []);
    $('aeDate').value = todayISO();
    show('animCardModal');
}

function renderTimeline(events) {
    const tl = $('acTimeline');
    if (!events.length) {
        tl.innerHTML = '<div class="anim-tl-row"><span class="anim-tl-body">Подій ще немає.</span></div>';
        return;
    }
    tl.innerHTML = events.map((e) => `
        <div class="anim-tl-row anim-tl-cat-${e.category || 'other'}">
            <span class="anim-tl-date">${escapeHtml((e.event_date || '').slice(0, 10))}</span>
            <span class="anim-tl-type">${escapeHtml(e.event_type)}</span>
            <span class="anim-tl-body">${escapeHtml([e.ref_tag, e.details].filter(Boolean).join(' · '))}</span>
            <button class="anim-tl-del" data-ev="${e.id}" title="Видалити">🗑</button>
        </div>`).join('');
    tl.querySelectorAll('.anim-tl-del').forEach((b) =>
        b.addEventListener('click', async () => {
            const rr = await apiSend('/api/herd/animals/events/' + b.dataset.ev, 'DELETE');
            if (rr.ok) openCard(currentAnimal.id);
        }));
}

function fillEventTypes() {
    $('aeType').innerHTML = EVENT_TYPES.map((e) =>
        `<option value="${e.t}">${e.t}</option>`).join('');
}

async function addEvent() {
    if (!currentAnimal) return;
    const type = $('aeType').value;
    const payload = {
        event_type: type, category: CAT_OF[type] || 'other',
        event_date: $('aeDate').value || todayISO(),
        ref_tag: $('aeRef').value, details: $('aeDetails').value,
    };
    const r = await apiSend('/api/herd/animals/' + currentAnimal.id + '/events', 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('aeRef').value = ''; $('aeDetails').value = '';
    openCard(currentAnimal.id);
}

async function changeStatus() {
    if (!currentAnimal) return;
    const opts = Object.entries(STATUSES).map(([k, v]) => `${k} — ${v}`).join('\n');
    const val = window.prompt('Новий статус (введіть код):\n' + opts, currentAnimal.status);
    if (!val) return;
    const status = val.trim().split(/\s|—/)[0];
    let exit_date = '', exit_reason = '';
    if (status !== 'active') {
        exit_date = window.prompt('Дата вибуття (РРРР-ММ-ДД):', todayISO()) || '';
        exit_reason = window.prompt('Причина:', '') || '';
    }
    const r = await apiSend('/api/herd/animals/' + currentAnimal.id + '/status', 'POST',
        { status, exit_date, exit_reason });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Статус змінено', 'success');
    hide('animCardModal');
    loadList();
}

/* ---------- імпорт ---------- */
async function doImport(file) {
    const st = $('animImportStatus');
    st.textContent = 'Завантаження…';
    const fd = new FormData(); fd.append('file', file);
    try {
        const r = await fetch('/api/herd/animals/import', { method: 'POST', body: fd });
        const j = await r.json();
        if (!j.ok) { st.textContent = 'Помилка: ' + (j.error || 'невідома'); return; }
        st.textContent = `Готово: додано ${j.added}, оновлено ${j.updated}` +
            (j.skipped ? `, пропущено ${j.skipped}` : '') +
            (j.errors && j.errors.length ? ` · помилок ${j.errors.length}` : '');
        loadList();
    } catch (e) { st.textContent = 'Сервер не відповів'; }
}

/* ---------- модал helpers ---------- */
function show(id) { const m = $(id); if (m) m.hidden = false; }
function hide(id) { const m = $(id); if (m) m.hidden = true; }
document.querySelectorAll('[data-close]').forEach((el) =>
    el.addEventListener('click', () => { el.closest('.modal').hidden = true; }));

/* ---------- init ---------- */
let searchTimer = null;
bind('animSearch', 'input', () => {
    clearTimeout(searchTimer); searchTimer = setTimeout(loadList, 250);
});
['animStatus', 'animSex', 'animGroup'].forEach((id) => bind(id, 'change', loadList));
bind('animAddBtn', 'click', () => openEdit(null));
bind('afSaveBtn', 'click', saveAnimal);
bind('acEditBtn', 'click', () => { hide('animCardModal'); openEdit(currentAnimal); });
bind('acStatusBtn', 'click', changeStatus);
bind('aeAddBtn', 'click', addEvent);
bind('animImportBtn', 'click', () => $('animImportFile').click());
bind('animImportFile', 'change', (e) => {
    if (e.target.files && e.target.files[0]) doImport(e.target.files[0]);
    e.target.value = '';
});

fillEventTypes();
loadList();
