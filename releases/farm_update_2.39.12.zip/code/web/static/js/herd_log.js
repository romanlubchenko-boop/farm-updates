/* Нова подія: подія обирається у шапці, форма — на сторінці, історія — праворуч. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let EVENTS = [], EVENTS_ALL = [], ANIMALS = [], CATS = {}, CHOICES = {}, UNITS = {}, FREQ = [];
const PARAMS = {};       // ключ → означення параметра (формула, тип, коротка назва)
const FXNAME = {};       // назва у формулі (short/label/key) → ключ параметра
const BOUNDS = {};      // межі числових параметрів: {ключ: {min,max,step}}
// Вбудовані клички (за літерами) — використовуються, якщо в Налаштуваннях порожньо
const BUILTIN_CALF_NAMES = {
    F: ['Астра', 'Аза', 'Ася', 'Береза', 'Білка', 'Буря', 'Вишня', 'Веселка', 'Воля',
        'Галка', 'Гроза', 'Гілка', 'Доля', 'Діва', 'Долина', 'Ева', 'Європа', 'Жоржина',
        'Жар', 'Зірка', 'Зоря', 'Зима', 'Іва', 'Іскра', 'Калина', 'Квітка', 'Корона',
        'Лада', 'Ластівка', 'Лілія', 'Мрія', 'Марта', 'Малина', 'Ніжна', 'Нива', 'Ночка',
        'Оса', 'Осінь', 'Оксамитка', 'Пава', 'Пісня', 'Перлина', 'Роза', 'Рута', 'Ромашка',
        'Соня', 'Сніжка', 'Слава', 'Стріла', 'Тайга', 'Тінь', 'Умка', 'Фея', 'Фіалка',
        'Хвиля', 'Царівна', 'Чайка', 'Черешня', 'Шпилька', 'Щедра', 'Юла', 'Юнона',
        'Ягідка', 'Яблунька', 'Ясна'],
    M: ['Атлас', 'Азарт', 'Байкал', 'Буян', 'Богдан', 'Вихор', 'Вітер', 'Грім', 'Грізний',
        'Гай', 'Дунай', 'Дозор', 'Ефір', 'Жар', 'Зевс', 'Зорян', 'Ірбіс', 'Кедр', 'Космос',
        'Лідер', 'Лорд', 'Мороз', 'Магніт', 'Марс', 'Норд', 'Нептун', 'Орлан', 'Опал',
        'Партизан', 'Пірат', 'Рекс', 'Ратибор', 'Сокіл', 'Сармат', 'Смерч', 'Тайфун',
        'Титан', 'Ураган', 'Фрегат', 'Хан', 'Цезар', 'Чемпіон', 'Шторм', 'Юпітер', 'Ясон', 'Явір'],
};
let CALF_NAMES = { F: BUILTIN_CALF_NAMES.F.slice(), M: BUILTIN_CALF_NAMES.M.slice() };
let curEvent = null, curAttached = [];
const LS_EVENT = 'herd:last_event';
/* Стать у рядку теляти — варіанти й назва з конструктора, з нумерацією
   («1. Жіноча»), як у решті випадайок форми. */
function calfSexOptions(numbered) {
    const opts = herdOptions('sex').length ? herdOptions('sex')
        : [{ c: 'F', l: 'Жіноча' }, { c: 'M', l: 'Чоловіча' }];
    return `<option value="" selected>— ${escapeHtml(herdLabel('sex', 'Стать').toLowerCase())} —</option>`
        + opts.map((o, i) => `<option value="${escapeHtml(o.c)}">${numbered ? (i + 1) + '. ' : ''}${escapeHtml(o.l)}</option>`).join('');
}

async function load() {
    const [ev, an, cn] = await Promise.all([
        apiGet('/api/herd/events?active=1'),
        apiGet('/api/herd/animals'),
        apiGet('/api/herd/calf-names'),
    ]);
    // налаштовані списки мають пріоритет; інакше — вбудовані в код
    if (cn && cn.ok) {
        CALF_NAMES = {
            F: (cn.F && cn.F.length) ? cn.F : BUILTIN_CALF_NAMES.F.slice(),
            M: (cn.M && cn.M.length) ? cn.M : BUILTIN_CALF_NAMES.M.slice(),
        };
    }
    if (ev.ok) {
        EVENTS_ALL = (ev.events || []).filter((e) => e.is_active);
        // у випадайку: активні, з галочкою «на панель», і НЕ прив'язані до іншої події
        EVENTS = EVENTS_ALL.filter((e) =>
            (e.show_on_panel === undefined || e.show_on_panel) && !e.attach_to);
        CATS = ev.categories || {};
        FREQ = ev.frequent || [];
        (ev.params || []).forEach((p) => {
            PARAMS[p.key] = p;
            // за якими іменами формула може послатись на цей параметр
            [p.short, p.label, p.key].forEach((n) => {
                const k = String(n || '').trim().toLowerCase();
                if (k && !FXNAME[k]) FXNAME[k] = p.key;
            });
            CHOICES[p.key] = p.choices || [];
            if (p.unit) UNITS[p.key] = p.unit;
            if (p.vmin || p.vmax || p.vstep)
                BOUNDS[p.key] = { min: p.vmin || '', max: p.vmax || '', step: p.vstep || '' };
        });
    }
    if (an.ok) ANIMALS = an.items || [];
    $('lgDate').value = new Date().toISOString().slice(0, 10);
    fillAnimals();
    fillEventSelect();
    bindEnterNav();
    loadFeed();
    // прийшли з картки тварини (/herd/log?animal=TAG) — підставити її
    const tag = new URLSearchParams(location.search).get('animal');
    if (tag) {
        const a = ANIMALS.find((x) => x.tag === tag);
        if (a) {
            $('lgAnimal').value = a.name ? `${a.tag} — ${a.name}` : a.tag;
            syncAnimalInfo();
        }
    }
}

/* ---------- вибір події ---------- */
function fillEventSelect() {
    const sel = $('lgEvent');
    const bySec = {};
    EVENTS.forEach((e) => { (bySec[e.category] = bySec[e.category] || []).push(e); });
    const order = Object.keys(CATS).concat(Object.keys(bySec).filter((c) => !CATS[c]));
    let html = '';
    // часті події — окремою групою вгорі, щоб головні дії були під рукою
    const favs = FREQ.map((id) => EVENTS.find((e) => e.id === id)).filter(Boolean);
    if (favs.length) {
        html += `<optgroup label="Часті">` + favs.map((e) =>
            `<option value="${e.id}">${escapeHtml(e.name)}</option>`).join('') + '</optgroup>';
    }
    order.forEach((cat) => {
        const list = bySec[cat];
        if (!list || !list.length) return;
        html += `<optgroup label="${escapeHtml(CATS[cat] || cat)}">` + list.map((e) =>
            `<option value="${e.id}">${escapeHtml(e.name)}</option>`).join('') + '</optgroup>';
    });
    sel.innerHTML = html || '<option value="">— немає активних подій —</option>';
    let want = new URLSearchParams(location.search).get('event') || '';
    if (!want) { try { want = localStorage.getItem(LS_EVENT) || ''; } catch (_) { /* ignore */ } }
    if (want && sel.querySelector(`option[value="${want}"]`)) sel.value = want;
    selectEvent(sel.value);
}

function selectEvent(id) {
    curEvent = EVENTS.find((e) => String(e.id) === String(id)) || null;
    // прив'язані події (їх питання показуємо тут же), напр. Народження у Отелі
    curAttached = curEvent
        ? EVENTS_ALL.filter((e) => e.attach_to && e.attach_to === curEvent.key) : [];
    try { if (curEvent) localStorage.setItem(LS_EVENT, String(curEvent.id)); } catch (_) { /* ignore */ }
    $('lgAccess').textContent = curEvent ? (CATS[curEvent.category] || curEvent.category || '') : '';
    $('lgCalves').innerHTML = '';
    renderInputs();
    syncBirth();
}

/* ---------- довідники ---------- */
let acIdx = -1;   // активний рядок підказки
function fillAnimals() {
    const inp = $('lgAnimal'), box = $('lgAnimalSug');
    if (!inp || !box) return;
    const render = () => {
        const q = (inp.value || '').trim().toLowerCase();
        const list = ANIMALS.filter((a) => a.status !== 'archived').filter((a) => {
            if (!q) return true;
            return (a.tag || '').toLowerCase().includes(q)
                || (a.name || '').toLowerCase().includes(q);
        }).slice(0, 12);
        if (!list.length) { box.hidden = true; box.innerHTML = ''; acIdx = -1; return; }
        box.innerHTML = list.map((a) =>
            `<div class="lg-sug-item" data-tag="${escapeHtml(a.tag)}">
                <span class="s-tag">${escapeHtml(a.tag)}</span>` +
            (a.name ? `<span class="s-name">${escapeHtml(a.name)}</span>` : '') +
            (a.group_name ? `<span class="s-name">· ${escapeHtml(a.group_name)}</span>` : '') +
            `</div>`).join('');
        box.hidden = false;
        // перший варіант активний ОДРАЗУ — Enter бере його без стрілок
        acIdx = 0;
        box.querySelector('.lg-sug-item').classList.add('is-active');
        // точний збіг бирки — підставляємо сам, людина просто друкує номер
        if (q && list.length === 1 && (list[0].tag || '').toLowerCase() === q)
            choose(list[0].tag, false);            // без стрибка фокусу під час друку
    };
    const choose = (tag, advance = true) => {
        const a = ANIMALS.find((x) => x.tag === tag);
        inp.value = a ? (a.name ? `${a.tag} — ${a.name}` : a.tag) : tag;
        box.hidden = true; syncAnimalInfo();
        // явний вибір (Enter/Tab/клік) → перше поле форми
        if (advance) {
            const nxt = document.querySelector('#lgInputs .lg-in') || $('lgNote');
            if (nxt) { nxt.focus(); if (nxt.select) nxt.select(); }
        }
    };
    inp.addEventListener('input', render);
    inp.addEventListener('focus', render);
    inp.addEventListener('keydown', (e) => {
        const items = [...box.querySelectorAll('.lg-sug-item')];
        if (box.hidden || !items.length) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); acIdx = Math.min(acIdx + 1, items.length - 1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); acIdx = Math.max(acIdx - 1, 0); }
        else if (e.key === 'Enter' || (e.key === 'Tab' && !e.shiftKey)) {
            e.preventDefault(); e.stopPropagation();
            choose(items[Math.max(acIdx, 0)].dataset.tag); return; }
        else if (e.key === 'Escape') { box.hidden = true; return; }
        else return;
        items.forEach((it, i) => it.classList.toggle('is-active', i === acIdx));
        if (items[acIdx]) items[acIdx].scrollIntoView({ block: 'nearest' });
    });
    box.addEventListener('mousedown', (e) => {
        const it = e.target.closest('.lg-sug-item'); if (!it) return;
        e.preventDefault(); choose(it.dataset.tag);
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.hp-ac')) box.hidden = true;
    });
}
function currentAnimal() {
    const v = ($('lgAnimal').value || '').trim();
    if (!v) return null;
    const tag = v.split(' — ')[0].trim();
    return ANIMALS.find((a) => a.tag === tag)
        || ANIMALS.find((a) => (a.name ? `${a.tag} — ${a.name}` : a.tag) === v) || null;
}
function syncAnimalInfo() {
    const a = currentAnimal();
    const deny = stateDeny(a);
    const el = $('lgAnimalInfo');
    el.textContent = deny
        || (a ? '' : (($('lgAnimal').value || '').trim() ? 'тварину не знайдено' : ''));
    el.classList.toggle('lg-deny', !!deny);
    renderAnimalCard();
}

/* Захист від помилок: подія дозволена не з кожного стану (тільну не
   осіменяють, нетільну не розтелюють). Правило задається в конструкторі
   події («Захист від помилок»), тут — лише людське пояснення. */
function stateDeny(a) {
    if (!a || !curEvent) return '';
    const allow = String(curEvent.allow_rc || '').split(',')
        .map((x) => x.trim()).filter(Boolean);
    const rc = String(a.repro_code || '').trim();
    if (!allow.length || !rc || allow.includes(rc)) return '';
    const lbl = (v) => {
        const hit = (CHOICES.repro_code || []).find((c) => String(c.value) === String(v));
        return hit ? hit.label : v;
    };
    return `⚠ ${a.tag}${a.name ? ' (' + a.name + ')' : ''}: стан «${lbl(rc)}» — `
        + `«${curEvent.name}» не вноситься. Дозволено: `
        + allow.map(lbl).join(', ') + '.';
}

/* ---------- динамічні поля ---------- */
/* Поле-довідка (дія «Показати»): значення параметра тварини, змінювати не
   можна. Так у формі видно обчислюване — каренцію, днів тільності, суму за
   формулою (Роман 2026-09-20: «якщо не можна відобразити автоматичні
   параметри, то треба поставити, щоб він був видимий»). */
let SHOWVALS = {};              // ключ → значення для обраної тварини
function showControl(eff) {
    const v = SHOWVALS[eff.param_key];
    return `<input type="text" class="hp-in lg-show" readonly tabindex="-1"`
        + ` data-key="${escapeHtml(eff.param_key)}"`
        + ` value="${escapeHtml(v === undefined || v === null ? '' : String(v))}"`
        + ` placeholder="—">`;
}
/* ГРОШОВИЙ БЛОК — як у приході: вводять БУДЬ-ЯКЕ поле, решта рахується
   (Роман 2026-09-20 «щоб усе перераховувалося, як у приході»). Ролі задаються
   в параметрі (Конструктор → Параметри → «Роль у грошах»), тож це працює в
   будь-якій події, а не лише у вибутті.
   Правила ті самі, що в pryhid.js: ціна з ПДВ = ціна без ПДВ × k; сума = к-сть
   × ціна; введена сума дає ціну = сума ÷ к-сть; ціни з точністю 4 знаки. */
const MONEY_ROLES = ['qty', 'price_nv', 'sum_nv', 'vat', 'price_v', 'sum_v'];
const r4 = (x) => Math.round(x * 10000) / 10000;
const r2 = (x) => Math.round(x * 100) / 100;
function moneyFields() {
    const out = {};
    (curEvent ? (curEvent.effects || []) : []).forEach((e) => {
        const p = PARAMS[e.param_key];
        const role = p && (p.money_role || '').trim();
        if (!role || !MONEY_ROLES.includes(role)) return;
        const el = document.querySelector(`#lgInputs [data-key="${CSS.escape(e.param_key)}"]`);
        if (el) out[role] = el;
    });
    return out;
}
function mVal(el) {
    if (!el) return null;
    const v = parseFloat(String(el.value || '').trim().replace(',', '.'));
    return isFinite(v) ? v : null;
}
function mPut(el, v, dec) {
    if (!el || el === document.activeElement) return;   // те, що набирають, не чіпаємо
    el.value = (v === null || !isFinite(v)) ? '' : String(Number(v.toFixed(dec)));
}
function recalcMoney(changedRole) {
    const f = moneyFields();
    if (!f.price_nv && !f.price_v && !f.sum_nv && !f.sum_v) return;   // події без грошей
    const qty = mVal(f.qty);
    const vat = mVal(f.vat);
    const k = 1 + (vat === null ? 0 : vat) / 100;
    let pnv = mVal(f.price_nv), pv = mVal(f.price_v);
    // 1) що ввели — те й головне; з нього виводимо ціну без ПДВ
    if (changedRole === 'sum_nv') {
        const s = mVal(f.sum_nv);
        pnv = (s !== null && qty) ? r4(s / qty) : pnv;
    } else if (changedRole === 'sum_v') {
        const s = mVal(f.sum_v);
        pv = (s !== null && qty) ? r4(s / qty) : pv;
        pnv = (pv !== null && k) ? r4(pv / k) : pnv;
    } else if (changedRole === 'price_v') {
        pnv = (pv !== null && k) ? r4(pv / k) : pnv;
    }
    // 2) решта — похідні
    if (pnv !== null) pv = r4(pnv * k);
    else if (pv !== null) pnv = r4(pv / k);
    mPut(f.price_nv, pnv, 4);
    mPut(f.price_v, pv, 4);
    mPut(f.sum_nv, (qty !== null && pnv !== null) ? r2(qty * pnv) : null, 2);
    mPut(f.sum_v, (qty !== null && pv !== null) ? r2(qty * pv) : null, 2);
}
function moneyRoleOf(key) {
    const p = PARAMS[key];
    const r = p && (p.money_role || '').trim();
    return MONEY_ROLES.includes(r) ? r : '';
}

/* Формула поля-довідки рахується З ТОГО, ЩО ВЖЕ У ФОРМІ: ввели вагу й ціну —
   одразу видно суму. Чого у формі немає, береться з картки тварини; формули,
   що читають історію (COUNT, VAL, TOTAL…), лишаються серверними. */
function fxResolve(name) {
    const key = FXNAME[String(name || '').trim().toLowerCase()] || name;
    const el = document.querySelector(`#lgInputs .lg-in[data-key="${CSS.escape(key)}"]`);
    // поле Є у формі — правда рівно те, що в ньому: стерли вагу, зникла й сума
    // (інакше підтягнулося б торішнє зважування з картки й сума брехала б)
    if (el) return el.value;
    const sv = SHOWVALS[key];
    return (sv === undefined || sv === null) ? '' : sv;
}
function recalcShow() {
    document.querySelectorAll('#lgInputs .lg-show').forEach((el) => {
        const p = PARAMS[el.dataset.key];
        const fml = p && (p.formula || '').trim();
        if (!fml) return;
        const r = window.herdFxCalc ? window.herdFxCalc(fml, fxResolve) : { ok: false };
        if (r.ok) {
            el.value = (r.value === null || r.value === undefined) ? '' : String(r.value);
        } else if (!r.server) {
            el.value = '';           // формулу не розібрати — краще порожньо, ніж неправда
        }
        // r.server — значення від сервера (у полі вже стоїть), не чіпаємо
    });
}
async function loadShowVals(animalId) {
    SHOWVALS = {};
    const need = (curEvent ? (curEvent.effects || []) : []).some((e) => e.mode === 'show');
    if (!need || !animalId) return;
    const r = await apiGet('/api/herd/animals/' + animalId + '/params').catch(() => null);
    (((r && r.ok) ? r.params : []) || []).forEach((p) => {
        SHOWVALS[p.key] = p.value_label || p.value || '';
    });
}
function inputControl(eff, evId) {
    const ev = ` data-event-id="${evId}"`;
    const ch = CHOICES[eff.param_key] || [];
    if (ch.length) {
        // кодовий список — мітка вже містить код; текстовий — нумеруємо позиції,
        // тож набраний номер обирає пункт нативно (мітка починається з «N. »)
        const isCod = eff.param_dtype === 'cod' || eff.param_dtype === 'code';
        // числову градацію (3.25, 3.50…) не нумеруємо — номер лише плутав би
        const isNum = ['int', 'float', 'number'].includes(eff.param_dtype);
        const isRef = eff.param_dtype === 'ref';   // довідник: «1 — Коля»
        const opts = '<option value="">— (за замовч.)</option>' + ch.map((c, i) => {
            // довідник — порядковий номер через тире («1 — Коля»): код
            // позиції людині нічого не каже, а номер дає вибір із клавіатури.
            // ⚠️ Якщо код УПІЗНАВАНИЙ, він лишається в мітці («M-101 — Мажор»)
            // — тоді номер не додаємо, бо вийшло б «1 — M-101 — Мажор».
            const lbl = (isRef && !c.label.includes(' — ')) ? `${i + 1} — ${c.label}`
                : ((isCod || isNum || isRef) ? c.label : `${i + 1}. ${c.label}`);
            return `<option value="${escapeHtml(c.value)}"${String(c.value) === String(eff.arg || '') ? ' selected' : ''}>${escapeHtml(lbl)}</option>`;
        }).join('');
        return `<select class="hp-in lg-in" data-key="${escapeHtml(eff.param_key)}" data-listtype="${isCod ? 'cod' : 'text'}"`
            + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}"${ev}>${opts}</select>`;
    }
    const dt = eff.param_dtype;
    const type = dt === 'date' ? 'date' : ((dt === 'int' || dt === 'float') ? 'number' : 'text');
    // межі з налаштувань параметра; крок за замовчуванням — 0,01 для дробових
    const b = BOUNDS[eff.param_key] || {};
    let step = dt === 'float' ? ' step="0.01"' : '';
    if (type === 'number') {
        if (b.step) step = ` step="${escapeHtml(b.step)}"`;
        if (b.min) step += ` min="${escapeHtml(b.min)}"`;
        if (b.max) step += ` max="${escapeHtml(b.max)}"`;
    }
    return `<input type="${type}"${step} class="hp-in lg-in" data-key="${escapeHtml(eff.param_key)}"`
        + ` data-req="${eff.required ? 1 : 0}" data-label="${escapeHtml(eff.param_label || '')}"${ev}`
        + (dt === 'multi' ? window.multiAttrs(dt, b.min, b.max)
            // текстове поле з лімітом («до» в параметрі) — далі за нього
            // просто не набереться, а не відмова вже після «Зберегти»
            : ((dt === 'text' && b.max) ? ` maxlength="${escapeHtml(b.max)}" placeholder="до ${escapeHtml(b.max)} символів"`
                : ' placeholder="значення"'))
        + ` value="${escapeHtml(eff.arg || '')}">`;
}
function renderInputs() {
    // питання самої події; прив'язані (Народження) збирають дані приплоду
    // через блок «🐣 Приплід», а не тут. Поля діляться на швидкий блок
    // і «розширені» — так, як налаштовано в конструкторі події.
    const effs = (curEvent ? (curEvent.effects || []) : [])
        .filter((e) => (e.mode === 'input' || e.mode === 'show')
            && (!('enabled' in e) || e.enabled));
    // ширина за типом: число й дата вузькі, список середній, текст ширший —
    // так форма не розсипається, поки ширину не задали вручну
    const widthClass = (eff) => {
        if ((CHOICES[eff.param_key] || []).length) return ' w-md';
        const dt = eff.param_dtype;
        if (dt === 'date') return ' w-sm';
        if (dt === 'int' || dt === 'float' || dt === 'number') return ' w-xs';
        return ' w-lg';
    };
    // колір картки: назва з палітри (fc-green) або свій #rrggbb інлайном
    const colorOf = (eff) => {
        const c = String((PARAMS[eff.param_key] || {}).color || '').trim();
        if (!c) return { cls: '', style: '' };
        if (/^#[0-9a-f]{6}$/i.test(c))
            return { cls: ' fc-own', style: ` style="--fc:${c}"` };
        return { cls: ' fc-' + c, style: '' };
    };
    const cell = (eff) => { const col = colorOf(eff); return `<label class="hp-fl${widthClass(eff)}${col.cls}" data-field="${escapeHtml(eff.param_key)}"${col.style}><span>`
        + `${escapeHtml(eff.param_label)}`
        + `${UNITS[eff.param_key] ? ', ' + escapeHtml(UNITS[eff.param_key]) : ''}`
        + `${eff.required ? '<span class="hp-req"> *</span>' : ''}`
        + `</span>${eff.mode === 'show' ? showControl(eff) : inputControl(eff, curEvent.id)}</label>`; };
    // поділу на «швидкі/приховані» більше немає: що вносить оператор — те у формі
    $('lgInputs').innerHTML = effs.map(cell).join('');
    applyPlanSire();          // підставити закріпленого бика в «Бик»
    const req = effs.filter((e) => e.required).length;
    $('lgReqNote').textContent = req ? 'Поля із * — обовʼязкові' : '';
    $('lgAuto').textContent = '';
    applyFieldConds();        // поля з умовою («покупець» — лише для продажу)
    recalcMoney('');          // звʼязані гроші (ціна ↔ сума ↔ ПДВ)
    recalcShow();             // поля-довідки за формулами
}

/* Поле з умовою показується, лише коли умова справджується: у «Вибутті»
   покупець і сума питаються для продажу, а не для загибелі (Роман 2026-09-20).
   Значення умови беремо з ЦІЄЇ Ж форми — людина щойно обрала «Продано». */
// зміна будь-якого поля форми може відкрити або сховати інше
document.addEventListener('change', (ev) => {
    if (ev.target.closest && ev.target.closest('#lgInputs')) applyFieldConds();
});
// поки оператор вводить — формули перераховуються на очах
document.addEventListener('input', (ev) => {
    const t = ev.target;
    if (!t || !t.closest || !t.closest('#lgInputs')) return;
    const role = moneyRoleOf(t.dataset.key);
    if (role) recalcMoney(role);
    recalcShow();
});
document.addEventListener('change', (ev) => {
    if (ev.target.closest && ev.target.closest('#lgInputs')) recalcShow();
});
function condOf(eff) {
    try {
        const c = JSON.parse(eff.cond || '{}');
        return (c && c.if) ? { if: c.if, op: c.op || 'eq', eq: c.eq == null ? '' : String(c.eq) } : null;
    } catch (e) { return null; }
}
function condHolds(c) {
    const el = document.querySelector(`#lgInputs .lg-in[data-key="${CSS.escape(c.if)}"]`);
    const raw = el ? String(el.value || '').trim() : '';
    if (!raw) return false;
    if (c.op === 'eq') return raw.toLowerCase() === c.eq.toLowerCase();
    if (c.op === 'ne') return raw.toLowerCase() !== c.eq.toLowerCase();
    const x = parseFloat(raw.replace(',', '.')), y = parseFloat(String(c.eq).replace(',', '.'));
    if (!isFinite(x) || !isFinite(y)) return false;
    return { gt: x > y, ge: x >= y, lt: x < y, le: x <= y }[c.op] || false;
}
function applyFieldConds() {
    const effs = (curEvent ? (curEvent.effects || []) : [])
        .filter((e) => e.mode === 'input' || e.mode === 'show');
    effs.forEach((eff) => {
        const c = condOf(eff);
        if (!c) return;
        const lab = document.querySelector(`#lgInputs .hp-fl[data-field="${CSS.escape(eff.param_key)}"]`);
        if (!lab) return;
        const on = condHolds(c);
        lab.hidden = !on;
        const el = lab.querySelector('.lg-in, .lg-show');
        if (el) {
            // приховане поле не вимагається; значення НЕ стираємо — інакше
            // зникав би і підставлений за замовчуванням ПДВ, а записати його
            // все одно не дасть та сама умова на сервері
            el.dataset.req = (on && eff.required) ? '1' : '0';
        }
    });
}

/* обовʼязкові поля, які лишились порожніми */
function missingRequired() {
    const out = [];
    document.querySelectorAll('#lgInputs .lg-in').forEach((el) => {
        if (el.dataset.req === '1' && !String(el.value || '').trim())
            out.push({ el, label: el.dataset.label || el.dataset.key });
    });
    return out;
}

/* значення поза заданими межами (від / до) — і у формі, і в рядку приплоду */
function outOfBounds() {
    const out = [];
    document.querySelectorAll('#lgInputs .lg-in, #lgCalves .cf-x .lg-in').forEach((el) => {
        const b = BOUNDS[el.dataset.key];
        const raw = String(el.value || '').trim();
        if (!b || !raw) return;
        const v = parseFloat(raw.replace(',', '.'));
        if (!isFinite(v)) return;
        const lo = b.min === '' ? null : parseFloat(b.min);
        const hi = b.max === '' ? null : parseFloat(b.max);
        const name = el.dataset.label || el.dataset.key;
        if (lo !== null && v < lo) out.push({ el, msg: `${name}: не менше ${b.min}` });
        else if (hi !== null && v > hi) out.push({ el, msg: `${name}: не більше ${b.max}` });
    });
    return out;
}

/* картка тварини + її історія */
async function renderAnimalCard() {
    const box = $('lgAnimalCard'), hist = $('lgHistBody');
    const a = currentAnimal();
    if (!a) {
        box.hidden = true;
        hist.innerHTML = '<div class="hp-empty">Оберіть тварину — покажемо її останні події</div>';
        return;
    }
    const meta = [];
    // підписи — назви параметрів із конструктора
    if (a.group_name) meta.push(`<span>${escapeHtml(herdLabel('group', 'Група'))} <b>${escapeHtml(a.group_name)}</b></span>`);
    if (a.lactation_no) meta.push(`<span>${escapeHtml(herdLabel('lactation', '№ лактації'))} <b>${a.lactation_no}</b></span>`);
    if (a.status_label) meta.push(`<span><b>${escapeHtml(a.status_label)}</b></span>`);
    // ⚠️ номер і кличку НЕ повторюємо: вони вже стоять у самому полі
    // «Тварина» («1001 — Ожина»). Картка каже лише те, чого в полі немає,
    // і стоїть ПОРУЧ із полем, а не смугою під ним (Роман 2026-09-20).
    box.innerHTML = meta.length ? `<span class="meta">${meta.join('')}</span>` : '';
    box.hidden = !meta.length;
    loadDamSire(a.id);
    loadPlanSire(a.id);
    // поля-довідки («Показати») наповнюються значеннями цієї тварини
    loadShowVals(a.id).then(() => {
        document.querySelectorAll('#lgInputs .lg-show').forEach((el) => {
            const v = SHOWVALS[el.dataset.key];
            el.value = (v === undefined || v === null) ? '' : String(v);
        });
        recalcShow();        // те, що можна порахувати з форми, — рахуємо
    });
    const r = await apiGet('/api/herd/animals/' + a.id).catch(() => null);
    // картка тварини віддається в корені відповіді (події — ключ events)
    const src = (r && r.ok) ? (r.events || (r.animal && r.animal.events) || []) : [];
    const evs = src.slice(0, 12);
    hist.innerHTML = evs.length ? evs.map((e) => {
        const d = (e.event_date || '').slice(0, 10);
        const dmy = d ? d.slice(8, 10) + '.' + d.slice(5, 7) + '.' + d.slice(0, 4) : '';
        return `<div class="row"><span class="d">${dmy}</span><span>`
            + `<span class="n ev-c-${escapeHtml(e.category || 'other')}">${escapeHtml(e.event_type || '')}</span>`
            + `<span class="dt">${escapeHtml(e.details || '')}</span></span></div>`;
    }).join('') : '<div class="hp-empty">Подій за цією твариною ще немає</div>';
}

/* ---------- приплід (Отел) ---------- */
// Батько приплоду — бик останнього осіменіння матері. Підставляємо ВИДИМО,
// щоб оператор бачив, що зафіксується, і міг перебити (пересадка ембріона,
// куплена тільна). Доти він проставлявся мовчки вже після збереження.
let DAM_SIRE = '';
// закріплений бик — кого ПЛАНОВО ставити цій тварині
let PLAN_SIRE = { sire: '', label: '' };
async function loadPlanSire(animalId) {
    PLAN_SIRE = { sire: '', label: '' };
    if (!animalId) return;
    const r = await apiGet('/api/herd/animals/' + animalId + '/plan-sire').catch(() => null);
    if (r && r.ok) PLAN_SIRE = r;
    applyPlanSire(true);       // обрали ІНШУ тварину — підпис і бик свіжі
}
// підставляємо в поле «Бик» події осіменіння і підписуємо, що це план
function applyPlanSire(force) {
    const el = document.querySelector('select[data-key="last_bull"], input[data-key="last_bull"]');
    if (!el) return;
    if (PLAN_SIRE.sire && (force || !(el.value || '').trim())) el.value = PLAN_SIRE.sire;
    const cell = el.closest('.hp-fl') || el.parentElement;
    if (!cell) return;
    let n = cell.querySelector('.lg-plan');
    if (!PLAN_SIRE.sire) { if (n) n.remove(); return; }
    if (!n) {
        n = document.createElement('span');
        n.className = 'lg-plan';
        cell.appendChild(n);
    }
    n.textContent = 'закріплено: ' + (PLAN_SIRE.label || PLAN_SIRE.sire);
}
async function loadDamSire(animalId) {
    DAM_SIRE = '';
    if (!animalId) return;
    // питаємо саме за ДАТУ події: після отелу корову осіменяють знову, і
    // «останній бик» у картці вже не той, що дав цей приплід
    const day = ($('lgDate').value || '').slice(0, 10);
    const r = await apiGet('/api/herd/animals/' + animalId + '/sire-of-calf'
        + (day ? '?on=' + encodeURIComponent(day) : '')).catch(() => null);
    DAM_SIRE = (r && r.ok && String(r.sire || '').trim()) || '';
    document.querySelectorAll('#lgCalves .lg-calf').forEach(applyDamSire);
}
function applyDamSire(row) {
    if (!DAM_SIRE) return;
    // саме КОНТРОЛ, а не комірка: data-key стоїть і на обгортці .cf-x
    const el = row.querySelector('select[data-key="sire_code"], input[data-key="sire_code"]');
    if (el && !(el.value || '').trim()) el.value = DAM_SIRE;
}

/* Номер приплоду (Роман 2026-09-16: «номер він іде похідний, а довгий
   номер UA він є основний»). Тож рахуємо ІДЕНТИФІКАЦІЙНИЙ номер, а бирку
   виводимо з нього — це його хвіст без префікса господарства. Правило
   (свій лічильник чи найбільший у базі) задається в реєстрі тварин. */
let CALF_NUM = { prefix: '', width: 0 };     // форма номера приплоду

/* Хвіст реєстраційного номера — те, що стає биркою. Довжину й префікс
   бере з налаштувань нумерації; без них — останні 6 цифр, як було. */
function tailOfUin(v) {
    const raw = String(v || '').replace(/\s/g, '').toUpperCase();
    const pref = (CALF_NUM.prefix || '').toUpperCase();
    if (pref && raw.startsWith(pref)) {
        const t = raw.slice(pref.length);
        return /^\d+$/.test(t) ? t : '';
    }
    const digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    const w = CALF_NUM.width || 6;
    return digits.slice(-w);
}

/* Бирка має бути вільна. Хвіст короткий, тож у стаді може вже бути тварина
   з таким номером (серії закінчуються однаково) — тоді беремо на цифру
   довший хвіст того самого номера (Роман 2026-09-16: «якщо шість знаків
   збігаються, то автоматом ставляться сім»). */
async function freeTagFor(uinEl, tagEl) {
    const uin = (uinEl.value || '').trim();
    if (!/\d/.test(uin) || tagEl.dataset.manual) return;
    const busy = [...document.querySelectorAll('#lgCalves .cf-tag')]
        .filter((x) => x !== tagEl).map((x) => (x.value || '').trim()).filter(Boolean);
    try {
        const r = await apiGet('/api/herd/tag-for-uin?uin=' + encodeURIComponent(uin)
            + (busy.length ? '&skip=' + encodeURIComponent(busy.join(',')) : ''));
        if (!r || !r.ok || !r.tag || tagEl.dataset.manual) return;
        tagEl.value = r.tag;
        tagEl.classList.toggle('tag-grown', !!r.grown);
        tagEl.title = r.grown
            ? 'Коротший номер уже зайнятий — узято на цифру довший'
            : '';
    } catch (e) { /* без звʼязку лишається як є */ }
}

/* Оператор вписав бирку сам — просто кажемо, якщо вона вже зайнята. */
async function checkTagBusy(tagEl) {
    const v = (tagEl.value || '').trim();
    tagEl.classList.remove('tag-busy');
    tagEl.title = '';
    if (!v) return;
    try {
        const r = await apiGet('/api/herd/search?q=' + encodeURIComponent(v) + '&limit=5');
        const hit = ((r && r.items) || []).some((a) => String(a.tag) === v);
        tagEl.classList.toggle('tag-busy', hit);
        if (hit) tagEl.title = 'Таку бирку вже має інша тварина';
    } catch (e) { /* ignore */ }
}

async function suggestUin(el, tagEl) {
    if (!el || (el.value || '').replace(/\D/g, '')) return;
    const busy = [...document.querySelectorAll('#lgCalves .cf-uin')]
        .map((x) => (x.value || '').trim()).filter((v) => /\d/.test(v));
    try {
        const r = await apiGet('/api/herd/next-uin'
            + (busy.length ? '?skip=' + encodeURIComponent(busy.join(',')) : ''));
        if (r && r.ok) {
            CALF_NUM = { prefix: (r.uin || '').slice(0, (r.uin || '').length - (r.tag || '').length),
                         width: (r.tag || '').length };
        }
        if (r && r.ok && r.uin && !(el.value || '').replace(/\D/g, '')) {
            el.value = r.uin;
            el.title = r.mode === 'max'
                ? 'Наступний за найбільшим у цій серії — можна змінити'
                : 'За лічильником нумерації приплоду — можна змінити';
            if (tagEl && !(tagEl.value || '').trim() && r.tag) tagEl.value = r.tag;
        }
    } catch (e) { /* немає звʼязку — лишиться «UA» */ }
}

// кличка теляти за літерою матері: перша вільна кличка потрібної статі
function genCalfName(sex) {
    const list = CALF_NAMES[(sex === 'M') ? 'M' : 'F'] || [];
    if (!list.length) return '';
    const dam = currentAnimal();
    let letter = '';
    for (const ch of ((dam && dam.name) || '')) { if (/[a-zа-яіїєґ]/i.test(ch)) { letter = ch.toUpperCase(); break; } }
    // зайняті: клички стада + уже проставлені в цьому приплоді
    const used = new Set();
    ANIMALS.forEach((a) => { if (a.name && (!a.status || a.status === 'active')) used.add(a.name.trim()); });
    document.querySelectorAll('#lgCalves .cf-name').forEach((el) => {
        if ((el.value || '').trim()) used.add(el.value.trim());
    });
    used.add(((dam && dam.name) || '').trim());
    // лише на літеру матері; усі зайняті — та сама з номером («Мальва-2»)
    const same = list.filter((n) => letter && n.slice(0, 1).toUpperCase() === letter);
    const low = new Set([...used].map((u) => u.toLowerCase()));
    const free = same.find((n) => !low.has(n.toLowerCase()));
    if (free || !same.length) return free || '';
    for (let i = 2; i < 1000; i++) {
        const v = same.map((n) => `${n}-${i}`).find((x) => !low.has(x.toLowerCase()));
        if (v) return v;
    }
    return '';
}
// Поля теляти, які налаштовані в події «Народження» (крок «Поля»).
// Стать, номери й кличка — базові, вони потрібні, щоб завести тварину.
const CALF_BASE = new Set(['sex', 'name', 'tag', 'uin']);
function calfExtraFields() {
    const b = birthEvent();
    if (!b) return [];
    return (b.effects || []).filter((e) =>
        e.mode === 'input' && (!('enabled' in e) || e.enabled) && !CALF_BASE.has(e.param_key));
}

function calfRow() {
    const div = document.createElement('div');
    div.className = 'lg-calf';
    div.innerHTML =
        // вбудовані пʼять полів теж у комірках .cf-x — щоб їхню ширину
        // можна було задати в макеті конструктора (службові ключі __…)
        `<span class="cf-x" data-field="__alive"><select class="hp-in cf-alive" title="Живе чи мертвонароджене">
            <option value="1" selected>🐮 Живе</option><option value="0">✝ Мертвонар.</option></select></span>
         <span class="cf-x" data-field="__uin"><input type="text" class="hp-in cf-uin" value="UA" placeholder="${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))} *"></span>
         <span class="cf-x" data-field="__tag"><input type="text" class="hp-in cf-tag" placeholder="${escapeHtml(herdLabel('tag', 'Номер тварини'))}" title="Підставляється з реєстраційного номера; можна виправити"></span>
         <span class="cf-x" data-field="__sex"><select class="hp-in cf-sex">${calfSexOptions(true)}</select></span>
         <span class="cf-x" data-field="__name"><input type="text" class="hp-in cf-name" placeholder="${escapeHtml(herdLabel('name', 'Кличка'))}"></span>`
        + calfExtraFields().map((e) => {
            const lbl = e.param_label + (UNITS[e.param_key] ? ', ' + UNITS[e.param_key] : '');
            // У рядку теляти підписів немає — назва поля мусить бути В
            // САМОМУ полі: для вводу це placeholder, для випадайки —
            // перша позиція («— Батько —»), як у вбудованої статі.
            const ctl = inputControl(e, 0)
                .replace('placeholder="значення"', `placeholder="${escapeHtml(lbl)}"`)
                .replace('<option value="">— (за замовч.)</option>',
                         `<option value="">— ${escapeHtml(e.param_label || '')} —</option>`);
            return `<span class="cf-x" data-key="${escapeHtml(e.param_key)}"
                        data-field="${escapeHtml(e.param_key)}"
                        title="${escapeHtml(lbl)}">${ctl}</span>`;
          }).join('')
        + `<button type="button" class="lg-calf-del" title="Прибрати">✕</button>`;
    const uinEl = div.querySelector('.cf-uin'), tagEl = div.querySelector('.cf-tag');
    suggestUin(uinEl, tagEl);
    const sexEl = div.querySelector('.cf-sex'), nameEl = div.querySelector('.cf-name');
    // при виборі статі — підставити згенеровану кличку за літерою матері (у порожнє)
    sexEl.addEventListener('change', () => {
        if (!(nameEl.value || '').trim()) {
            const nm = genCalfName(sexEl.value);
            if (nm) nameEl.value = nm;
        }
    });
    // Мертвонароджене теж реєструється твариною (рішення Романа), тож
    // бирка й кличка лишаються — просто необовʼязкові; державний номер
    // мертвому не присвоюють, його й ховаємо.
    const aliveSel = div.querySelector('.cf-alive');
    const syncAlive = () => {
        const dead = aliveSel.value === '0';
        div.querySelector('.cf-uin').style.display = dead ? 'none' : '';
        const tagWord = herdLabel('tag', 'Номер тварини');
        tagEl.placeholder = dead ? tagWord + ' (не обовʼязково)' : tagWord;
        div.classList.toggle('is-dead', dead);
    };
    aliveSel.addEventListener('change', syncAlive);
    syncAlive();
    // № реєстр. завжди починається з UA, далі лише цифри
    let uinTimer = null;
    uinEl.addEventListener('input', (e) => {
        e.target.value = 'UA' + e.target.value.replace(/\D/g, '');
        // бирка — ХВІСТ реєстраційного номера: основний саме довгий номер,
        // тож № ID іде за ним сам, поки його не виправили руками
        if (tagEl.dataset.manual) return;
        const t = tailOfUin(e.target.value);
        if (t) tagEl.value = t;
        // і звіряємо з реєстром: якщо такий хвіст уже зайнятий — беремо довший
        clearTimeout(uinTimer);
        uinTimer = setTimeout(() => freeTagFor(uinEl, tagEl), 350);
    });
    tagEl.addEventListener('input', () => {
        tagEl.dataset.manual = '1';
        checkTagBusy(tagEl);
    });
    div.querySelector('.lg-calf-del').addEventListener('click', () => div.remove());
    applyDamSire(div);
    return div;
}
// подія, що реєструє приплід (сама або прив'язана, напр. Народження)
function birthEvent() {
    if (curEvent && curEvent.births) return curEvent;
    return curAttached.find((e) => e.births) || null;
}
function syncBirth() {
    const show = !!birthEvent();
    $('lgBirth').hidden = !show;
    if (show && !$('lgCalves').children.length) $('lgCalves').appendChild(calfRow());
    if (!show) $('lgCalves').innerHTML = '';
}
function collectCalves() {
    const out = [];
    document.querySelectorAll('#lgCalves .lg-calf').forEach((r) => {
        const alive = r.querySelector('.cf-alive').value !== '0';
        const sex = r.querySelector('.cf-sex').value;
        if (!alive) {
            // мертвонароджене реєструється твариною: бирка й кличка не
            // обовʼязкові (бирки йому часто не дають), решта — як у живого
            const p0 = {};
            r.querySelectorAll('.cf-x .lg-in').forEach((el) => {
                if (!el.dataset.key) return;
                const v = (el.value || '').trim();
                if (v) p0[el.dataset.key] = v;
            });
            out.push({ alive: false, sex,
                       tag: (r.querySelector('.cf-tag').value || '').trim(),
                       name: (r.querySelector('.cf-name').value || '').trim(),
                       params: p0 });
            return;
        }
        const tag = (r.querySelector('.cf-tag').value || '').trim();
        if (!tag) return;       // живе без номера — не рахуємо
        const uin = (r.querySelector('.cf-uin').value || '').replace(/\D/g, '');
        const params = {};
        r.querySelectorAll('.cf-x .lg-in').forEach((el) => {
            if (!el.dataset.key) return;          // вбудовані поля — не параметри
            const v = (el.value || '').trim();
            if (v) params[el.dataset.key] = v;
        });
        out.push({
            alive: true, tag, sex,
            name: (r.querySelector('.cf-name').value || '').trim(),
            uin: uin ? 'UA' + uin : '',
            params,
        });
    });
    return out;
}

/* ---------- Enter веде по полях, на останньому — зберігає ---------- */
function bindEnterNav() {
    document.querySelector('.lg-layout').addEventListener('keydown', (e) => {
        const smart = e.key === 'Enter' || (e.key === 'Tab' && !e.shiftKey);
        if (!smart || e.target.tagName === 'TEXTAREA') return;
        const seq = [...document.querySelectorAll(
            '#lgAnimal, #lgInputs .lg-in, #lgCalves input, #lgCalves select, #lgNote')]
            .filter((el) => el.offsetParent !== null && !el.disabled);
        const i = seq.indexOf(e.target);
        if (i === -1) return;
        e.preventDefault();
        // ЗАПОБІЖНИК: з поля тварини далі — лише з РОЗПІЗНАНОЮ твариною
        // (вибір першого варіанта робить обробник автокомпліту; якщо збігів
        // немає — стоїмо тут, а не тягнемо «12» у приплід)
        if (e.target.id === 'lgAnimal' && !currentAnimal()) { e.target.focus(); return; }
        // переходимо тільки на НАСТУПНЕ ПОРОЖНЄ поле; заповнені пропускаємо.
        // № реєстр. з самим лише префіксом «UA» вважаємо порожнім.
        const isEmpty = (el) => {
            let v = (el.value || '').trim();
            if (el.classList.contains('cf-uin')) v = v.replace(/^UA$/i, '');
            return !v;
        };
        // необов'язкові поля (можна лишати порожніми): кличка, нотатка
        const optional = (el) => el.classList.contains('cf-name') || el.id === 'lgNote'
            || el.dataset.req === '0';
        // не переходити далі, поки поточне обов'язкове поле порожнє
        if (isEmpty(e.target) && !optional(e.target)) {
            e.target.focus();
            if (typeof e.target.select === 'function') e.target.select();
            return;
        }
        const nxt = seq[i + 1];
        if (nxt) {
            nxt.focus();
            if (typeof nxt.select === 'function') nxt.select();
        } else {
            submit();
        }
    });
}

// зібрати введені значення, згруповані за подією (data-event-id)
function inputsByEvent() {
    const map = {};
    document.querySelectorAll('#lgInputs .lg-in').forEach((el) => {
        const v = (el.value || '').trim();
        if (v === '') return;
        const eid = el.dataset.eventId || String(curEvent.id);
        (map[eid] = map[eid] || {})[el.dataset.key] = v;
    });
    return map;
}

async function submit() {
    if (!curEvent) { toast('Оберіть подію', 'warn'); $('lgEvent').focus(); return; }
    const a = currentAnimal();
    if (!a) { toast('Оберіть тварину', 'warn'); $('lgAnimal').focus(); return; }
    const deny = stateDeny(a);
    if (deny) { toast(deny, 'error'); $('lgAnimal').focus(); return; }
    const miss = missingRequired();
    if (miss.length) {
        toast('Заповніть обовʼязкові поля: ' + miss.map((m) => m.label).join(', '), 'warn');
        miss[0].el.focus();
        return;
    }
    const bad = outOfBounds();
    if (bad.length) {
        toast(bad[0].msg, 'warn');
        bad[0].el.focus();
        return;
    }
    const date = $('lgDate').value, note = $('lgNote').value.trim();
    const byEv = inputsByEvent();
    const bEv = birthEvent();
    const calves = bEv ? collectCalves() : [];
    // живе теля без № ID доти мовчки ЗНИКАЛО: рядок заповнений, а тварина
    // не створювалась і ніхто про це не дізнавався
    if (bEv) {
        const noTag = [...document.querySelectorAll('#lgCalves .lg-calf')].find((r) => {
            if (r.querySelector('.cf-alive').value === '0') return false;
            if ((r.querySelector('.cf-tag').value || '').trim()) return false;
            const filled = (r.querySelector('.cf-sex').value || '').trim()
                || (r.querySelector('.cf-name').value || '').trim()
                || (r.querySelector('.cf-uin').value || '').replace(/\D/g, '')
                || [...r.querySelectorAll('.cf-x .lg-in')].some((el) => (el.value || '').trim());
            return !!filled;
        });
        if (noTag) {
            toast('Вкажіть № ID теляти — без нього тварина не заведеться', 'warn');
            noTag.querySelector('.cf-tag').focus();
            return;
        }
    }
    // стать теляти обов'язкова (за замовч. порожня — треба обрати)
    if (bEv && calves.some((c) => !c.sex)) {
        const row = [...document.querySelectorAll('#lgCalves .lg-calf')].find((r) => {
            const dead = r.querySelector('.cf-alive').value === '0';
            const hasTag = (r.querySelector('.cf-tag').value || '').trim();
            return (dead || hasTag) && !r.querySelector('.cf-sex').value;
        });
        toast(`Оберіть «${herdLabel('sex', 'Стать')}»`, 'warn');
        if (row) row.querySelector('.cf-sex').focus();
        return;
    }
    // обрали не закріпленого бика — питаємо один раз, але не забороняємо
    const bullVal = ((byEv[String(curEvent.id)] || {}).last_bull || '').trim();
    if (PLAN_SIRE.sire && bullVal && bullVal !== PLAN_SIRE.sire) {
        const ch = (CHOICES.last_bull || []).find((c) => String(c.value) === bullVal);
        const okGo = await confirmAction(
            `Закріплено ${PLAN_SIRE.label || PLAN_SIRE.sire}, обрано `
            + `${(ch && ch.label) || bullVal}. Провести?`,
            { ok: 'Провести', okClass: 'btn-primary' });
        if (!okGo) return;
    }
    // одна подія в стрічці (Отел); приплід і правила прив'язаної події
    // (Народження) застосовуються в її межах на бекенді
    const base = {
        event_id: curEvent.id, event_date: date,
        inputs: byEv[String(curEvent.id)] || {}, note,
    };
    if (bEv) base.calves = calves;
    const r = await apiSend(`/api/herd/animals/${a.id}/apply-event`, 'POST', base);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    const changed = (r.changed || []).length;
    const born = (r.born || []).filter((b) => b.id).length;
    const still = r.stillborn || 0;
    // заднім числом: поточні значення, які вже змінила пізніша подія, лишились
    const kept = (r.kept_labels || []).length
        ? ' · поточне не змінено (є пізніша подія): ' + r.kept_labels.join(', ') : '';
    toast(`Проведено: ${curEvent.name}${changed ? ' · оновлено ' + changed : ''}${born ? ' · приплід ' + born : ''}${still ? ' · мертвонар. ' + still : ''}${kept}`, 'success');
    // наступна тварина — форма чиста, подія й дата лишаються
    $('lgAnimal').value = ''; $('lgNote').value = '';
    $('lgCalves').innerHTML = '';
    renderInputs(); syncBirth(); syncAnimalInfo();
    $('lgAnimal').focus();
    loadFeed();
}

/* ---------- стрічка ---------- */
let FEED = [], FEED_CAT = 'all';

// фільтр стрічки за категоріями подій — ті самі кольори, що й у назвах
function renderCatBar() {
    const box = $('lgCatBar');
    if (!box) return;
    const cnt = {};
    FEED.forEach((e) => { const c = e.category || 'other'; cnt[c] = (cnt[c] || 0) + 1; });
    const cats = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a]);
    if (cats.length < 2) { box.innerHTML = ''; FEED_CAT = 'all'; return; }
    const chip = (c, label, n) =>
        `<button type="button" class="lg-cat ev-c-${escapeHtml(c)}${c === FEED_CAT ? ' on' : ''}"
                 data-c="${escapeHtml(c)}">${escapeHtml(label)}`
        + `<span class="lg-cat-n">${n}</span></button>`;
    box.innerHTML = chip('all', 'усі події', FEED.length)
        + cats.map((c) => chip(c, (CATS[c] || c), cnt[c])).join('');
    box.querySelectorAll('.lg-cat').forEach((b) => b.addEventListener('click', () => {
        FEED_CAT = b.dataset.c; renderFeed();
    }));
}

function renderFeed() {
    const rows = FEED_CAT === 'all'
        ? FEED : FEED.filter((e) => (e.category || 'other') === FEED_CAT);
    $('lgCount').textContent = FEED.length
        ? `· ${rows.length}${rows.length !== FEED.length ? ' з ' + FEED.length : ''}` : '';
    renderCatBar();
    $('lgBody').innerHTML = rows.length ? rows.map((e) => {
        const d = (e.event_date || '').slice(0, 10);
        // коли внесено: «17.09 09:42» — дата події й момент запису бувають різні
        const cr = String(e.created_at || '');
        const created = cr.length >= 16 ? `${cr.slice(8, 10)}.${cr.slice(5, 7)} ${cr.slice(11, 16)}` : cr;
        return `<tr data-id="${e.id}">
            <td>${escapeHtml(d)}</td>
            <td><b class="ev-c-${escapeHtml(e.category || 'other')}">${escapeHtml(e.event_type || '')}</b></td>
            <td><a class="lg-animal" href="/herd/animals/${e.animal_id}"
                   title="Відкрити картку тварини">${escapeHtml(e.animal_tag || '')}</a></td>
            <td>${escapeHtml(e.animal_name || '')}</td>
            <td class="text-mute">${escapeHtml(e.group_name || '')}</td>
            <td class="text-mute">${e.details_html || escapeHtml(e.details || '')}</td>
            <td class="text-mute">${escapeHtml(e.note || '')}</td>
            <td class="text-mute">${escapeHtml(e.user_name || '')}</td>
            <td class="text-mute">${escapeHtml(created)}</td>
            <td class="c">
                <button class="lg-del" data-edit="${e.id}" data-date="${escapeHtml(d)}"
                        data-note="${escapeHtml(e.note || '')}" title="Виправити">✎</button>
                <button class="lg-del" data-del="${e.id}" title="Видалити">✕</button></td>
        </tr>`;
    }).join('') : '<tr><td colspan="10" class="hp-empty">Подій ще немає</td></tr>';
}

/* Які колонки стрічки показувати — вирішує сама людина (Роман 2026-09-17).
   Спільний механізм застосунку «⚙ Колонки»; вибір памʼятається в браузері.
   Нові колонки (Група, Внесено) за замовчуванням сховані — вигляд не
   змінюється, доки їх не ввімкнуть. */
(function feedColumns() {
    const KEY = 'herd:log_feed_hidden';
    try {
        if (localStorage.getItem(KEY) === null) {
            localStorage.setItem(KEY, JSON.stringify(['group', 'created']));
        }
    } catch (_) { /* приватний режим — усі колонки видимі */ }
    setupColumnPicker({
        tableId: 'lgTable',
        storageKey: KEY,
        anchor: $('lgCols'),
        columns: [
            { key: 'date', label: 'Дата' },
            { key: 'event', label: 'Подія' },
            { key: 'tag', label: herdLabel('tag', 'Номер тварини') },
            { key: 'name', label: herdLabel('name', 'Кличка') },
            { key: 'group', label: herdLabel('group', 'Група') },
            { key: 'details', label: 'Деталі' },
            { key: 'note', label: 'Нотатка' },
            { key: 'user', label: 'Хто вніс' },
            { key: 'created', label: 'Внесено (дата й час)' },
        ],
    });
})();

async function loadFeed() {
    const q = ($('lgSearch').value || '').trim();
    const r = await apiGet('/api/herd/events-log?limit=100' + (q ? '&q=' + encodeURIComponent(q) : ''));
    FEED = r.ok ? (r.events || []) : [];
    renderFeed();
}
async function delEvent(id) {
    if (!(await confirmAction('Видалити запис події?', { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/animals/events/' + id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    loadFeed();
}

/* ---------- прив'язка ---------- */
$('lgEvent').addEventListener('change', (e) => selectEvent(e.target.value));
$('lgAddCalf').addEventListener('click', () => $('lgCalves').appendChild(calfRow()));
$('lgAnimal').addEventListener('input', syncAnimalInfo);
$('lgSubmit').addEventListener('click', submit);
$('lgSubmit2').addEventListener('click', submit);
let searchT = null;
$('lgSearch').addEventListener('input', () => { clearTimeout(searchT); searchT = setTimeout(loadFeed, 250); });
$('lgBody').addEventListener('click', (e) => {
    const d = e.target.closest('[data-del]'); if (d) { delEvent(d.dataset.del); return; }
    const ed = e.target.closest('[data-edit]');
    if (ed) {
        $('leDate').value = ed.dataset.date || '';
        $('leNote').value = ed.dataset.note || '';
        $('lgEditModal').dataset.eventId = ed.dataset.edit;
        $('lgEditModal').hidden = false;
        $('leDate').focus();
    }
});
document.querySelectorAll('#lgEditModal [data-close-edit]').forEach((el) =>
    el.addEventListener('click', () => { $('lgEditModal').hidden = true; }));
$('leSave').addEventListener('click', async () => {
    const id = $('lgEditModal').dataset.eventId;
    if (!id) return;
    const r = await apiSend('/api/herd/animals/events/' + id, 'PATCH', {
        event_date: $('leDate').value, note: $('leNote').value,
    });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Виправлено' + ((r.recalc || r.reapplied) ? ' · параметри перераховано' : ''), 'success');
    $('lgEditModal').hidden = true;
    loadFeed();
});
// Авто-розкриття списків при фокусі (де підтримується showPicker).
// Вибір за номером — нативний: мітки пронумеровані «1. …».
document.querySelector('.lg-layout').addEventListener('focusin', (e) => {
    const s = e.target.closest('select');
    if (s && typeof s.showPicker === 'function') {
        try { s.showPicker(); } catch (_) { /* потрібна взаємодія — ігноруємо */ }
    }
});

if ($('lgEvent')) load();
})();
