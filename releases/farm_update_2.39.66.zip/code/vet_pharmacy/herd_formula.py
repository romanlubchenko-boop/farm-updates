"""Рядок формул параметрів стада (Роман 2026-09-19: «в конструкторі
параметрів зробимо строкою формул»).

Обчислюваний параметр пишеться одним рядком, як в Excel:

    =DAYS(TODAY(), last_calving)
    =IF(lact > 0, DAYS(TODAY(), last_insem), "")
    =COUNT(calving, lactation)
    =ADDDAYS(last_insem, 275)

Посилання на параметр — коротка назва, ключ або [Назва з пробілами].
Дата мінус дата — днів; дата ± число — дата. Порожнє значення робить
порожнім і результат, якщо його не перехопити IF/ISEMPTY/COALESCE.

Без eval: власний розбір і обчислення, лише дозволені функції.
"""
from __future__ import annotations

import re
from datetime import date, timedelta
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP, ROUND_UP

# назва функції → (мін. аргументів, макс. аргументів, опис для підказки)
FUNCS = {
    "TODAY": (0, 0, "сьогоднішня дата"),
    "DAYS": (2, 2, "днів між датами: DAYS(пізніша, рання)"),
    "MONTHS": (2, 2, "повних місяців між датами: MONTHS(пізніша, рання)"),
    "ADDDAYS": (2, 2, "дата + днів: ADDDAYS(дата, 275)"),
    "IF": (2, 3, "умова: IF(умова, так, інакше)"),
    "AND": (1, 9, "усі умови виконано"),
    "OR": (1, 9, "хоч одна умова"),
    "NOT": (1, 1, "заперечення"),
    "IN": (2, 20, "значення серед переліку: IN(rc, 5, 6)"),
    "ISEMPTY": (1, 1, "значення немає"),
    "COALESCE": (1, 9, "перше непорожнє: COALESCE(a, b)"),
    "MIN": (1, 9, "найменше"),
    "MAX": (1, 9, "найбільше"),
    "ROUND": (1, 2, "округлення за правилами: ROUND(2.45, 1) = 2.5"),
    "ROUNDUP": (1, 2, "округлення вгору (від нуля): ROUNDUP(2.41, 1) = 2.5"),
    "ROUNDDOWN": (1, 2, "округлення вниз (до нуля): ROUNDDOWN(2.49, 1) = 2.4"),
    "ABS": (1, 1, "модуль"),
    "INT": (1, 1, "ціла частина"),
    "COUNT": (1, 3, "скільки разів була подія: COUNT(insem, lactation) — у поточній "
              "лактації. Замість події можна взяти параметр: COUNT(fdat) — скільки "
              "разів записано дату отелу"),
    "LAST": (1, 3, "дата останньої події: LAST(insem) або LAST(insem, lactation)"),
    "FIRST": (1, 3, "дата першої події: FIRST(insem, lactation) — перше осіменіння в лактації"),
    "VAL": (1, 3, "запис параметра за позицією: VAL(вага, 1) — перший (при народженні), "
                  "VAL(вага, -1) — останній, VAL(вага, -2) — передостанній; третім — період"),
    "VALDATE": (1, 3, "дата цього запису: VALDATE(вага, -1) — коли зважували востаннє"),
    "AVGVAL": (1, 2, "середнє записів параметра: AVGVAL([milk/lkd], lactation) — середній контрольний надій у лактації"),
    "TOTAL": (1, 2, "сума за період методом контрольних доїнь: TOTAL([milk/lkd], lactation) — надій за лактацію, "
                    "від отелу до запуску або сьогодні"),
    "LABEL": (1, 1, "назва коду зі списку: LABEL(rc)"),
    "POS": (1, 1, "яким за рахунком значення йде у своєму списку: POS(group)"),
    "WITHDRAWAL": (1, 1, "каренція до: WITHDRAWAL(milk) — молоко, WITHDRAWAL(meat) — мʼясо; "
                          "дата лікування + днів каренції препарату (порожньо, коли минула)"),
    "MILKING": (0, 1, "дійна секція: 1 — тварина в дійній секції, 0 — ні; MILKING(group)"),
    "GESTATION": (0, 0, "строк тільності, днів — з налаштувань календаря"),
}
EVENT_FUNCS = {"COUNT", "LAST", "FIRST"}
HIST_FUNCS = {"VAL", "VALDATE"}
AGG_FUNCS = {"AVGVAL", "TOTAL"}      # історія параметра: (параметр, період)
WD_KINDS = {"milk": "milk", "молоко": "milk", "meat": "meat", "мʼясо": "meat", "м'ясо": "meat"}      # історія параметра: (параметр, позиція, період)
# період для COUNT/LAST/FIRST (другий аргумент): слово або число/дата
SCOPES = {"life": "за все життя", "lactation": "поточна лактація (з останнього отелу)",
          "prevlactation": "попередня лактація"}


class FormulaError(ValueError):
    pass


# ── розбір ────────────────────────────────────────────────────────────────
_TOKEN = re.compile(r"""
    (?P<ws>\s+)
  | (?P<num>\d+(?:\.\d+)?)
  | (?P<str>"[^"]*"|'[^']*')
  | (?P<ref>\[[^\]]+\])
  | (?P<name>[^\W\d][\w]*)
  | (?P<op><=|>=|<>|!=|[-+*/^(),;=<>])
""", re.X | re.U)


def _tokens(src: str) -> list:
    s = str(src or "").strip()
    if s.startswith("="):
        s = s[1:]
    out, i = [], 0
    while i < len(s):
        m = _TOKEN.match(s, i)
        if not m:
            raise FormulaError(f"не зрозуміло «{s[i:i + 12]}»")
        i = m.end()
        kind = m.lastgroup
        if kind == "ws":
            continue
        v = m.group(kind)
        if kind == "num":
            out.append(("num", float(v)))
        elif kind == "str":
            out.append(("str", v[1:-1]))
        elif kind == "ref":
            out.append(("ref", v[1:-1].strip()))
        elif kind == "name":
            out.append(("name", v))
        else:
            out.append(("op", "<>" if v == "!=" else v))
    return out


_BINOPS = {"+", "-", "*", "/", "^", "=", "<>", "!=", "<", ">", "<=", ">="}


def pretty(src: str) -> str:
    """Охайний запис формули: знаки впритул (rc<6), пробіл після коми й
    навколо and/or, без пробілів у дужках; назви функцій великими, and/or — малими. Текст у лапках і
    [назви з пробілами] не чіпаємо. Не вдалося розібрати — повертаємо як було."""
    raw = str(src or "").strip()
    s = raw[1:] if raw.startswith("=") else raw
    toks, i = [], 0
    while i < len(s):
        m = _TOKEN.match(s, i)
        if not m:
            return raw
        i = m.end()
        if m.lastgroup != "ws":
            toks.append((m.lastgroup, m.group(m.lastgroup)))
    out = ""

    def gap():                        # один пробіл, не після «(» і не подвійний
        nonlocal out
        if out and not out.endswith((" ", "(")):
            out += " "
    prev = None                       # попередній токен (kind, text)
    for j, (kind, v) in enumerate(toks):
        nxt = toks[j + 1] if j + 1 < len(toks) else None
        # and/or після умови — слово між умовами (навіть якщо далі «(»)
        after_operand = prev is not None and not prev[2] and (
            prev[0] in ("num", "str", "ref", "name") or prev[:2] == ("op", ")"))
        word = kind == "name" and v.lower() in ("and", "or") and after_operand
        if kind == "name" and nxt and nxt == ("op", "(") and not word:
            v = v.upper()             # функція
        elif word:
            v = v.lower()
        if kind == "op" and v in (",", ";"):
            out = out.rstrip(" ") + ", "
        elif kind == "op" and v == "(":
            if prev and prev[2]:
                gap()                 # після and/or — пробіл; функція — впритул
            out += "("
        elif kind == "op" and v == ")":
            out = out.rstrip(" ") + ")"
        elif kind == "op" and v in ("-", "+") and (
                prev is None or (prev[0] == "op" and prev[1] != ")") or prev[2]):
            if prev is not None and prev[2]:
                gap()                 # після and/or — пробіл
            out += v                  # унарний: -1, x>-3
        elif kind == "op" and v in _BINOPS:
            # знаки — впритул, як у «Роботі зі стадом»: rc<6, a+b (Роман 2026-09-19)
            out = out.rstrip(" ") + ("<>" if v == "!=" else v)
        elif word:
            gap()
            out += v + " "
        else:
            if prev is not None and prev[0] != "op" and not out.endswith((" ", "(")):
                out += " "            # два слова поспіль — як були
            out += v
        prev = (kind, v, word)
    out = out.strip()
    return ("=" if raw.startswith("=") else "") + out


def parse(src: str):
    """Текст → дерево. Помилка — FormulaError з поясненням українською."""
    tk = _tokens(src)
    if not tk:
        raise FormulaError("формула порожня")
    pos = [0]

    def peek():
        return tk[pos[0]] if pos[0] < len(tk) else None

    def eat(op):
        t = peek()
        if t and t[0] == "op" and t[1] == op:
            pos[0] += 1
            return True
        return False

    def word(w):
        """and / or між умовами: IF(lact > 0 and rc = 5, …) — те саме, що AND(…)."""
        t = peek()
        if t and t[0] == "name" and t[1].lower() == w:
            nxt = tk[pos[0] + 1] if pos[0] + 1 < len(tk) else None
            if not nxt or nxt[0] == "op" and nxt[1] in (")", ",", ";"):
                raise FormulaError(f"після «{t[1]}» бракує умови")
            pos[0] += 1
            return True
        return False

    def expr():
        left = conj()
        items = [left]
        while word("or"):
            items.append(conj())
        return left if len(items) == 1 else ("fn", "OR", items)

    def conj():
        left = cmp()
        items = [left]
        while word("and"):
            items.append(cmp())
        return left if len(items) == 1 else ("fn", "AND", items)

    def cmp():
        left = add()
        t = peek()
        if t and t[0] == "op" and t[1] in ("=", "<>", "<", ">", "<=", ">="):
            pos[0] += 1
            return ("cmp", t[1], left, add())
        return left

    def add():
        left = mul()
        while True:
            if eat("+"):
                left = ("bin", "+", left, mul())
            elif eat("-"):
                left = ("bin", "-", left, mul())
            else:
                return left

    def mul():
        left = unary()
        while True:
            if eat("*"):
                left = ("bin", "*", left, unary())
            elif eat("/"):
                left = ("bin", "/", left, unary())
            elif eat("^"):
                left = ("bin", "^", left, unary())
            else:
                return left

    def unary():
        if eat("-"):
            return ("neg", unary())
        if eat("+"):
            return unary()
        return atom()

    def atom():
        t = peek()
        if not t:
            raise FormulaError("формула обірвалась — чогось бракує в кінці")
        pos[0] += 1
        if t[0] == "num":
            return ("num", t[1])
        if t[0] == "str":
            return ("str", t[1])
        if t[0] == "ref":
            return ("ref", t[1])
        if t[0] == "name":
            name = t[1]
            if eat("("):
                fn = name.upper()
                if fn not in FUNCS:
                    raise FormulaError(f"невідома функція {name}")
                args = []
                if not eat(")"):
                    while True:
                        args.append(expr())
                        if eat(",") or eat(";"):
                            continue
                        if eat(")"):
                            break
                        raise FormulaError(f"у {fn}(…) не закрито дужку")
                lo, hi, _ = FUNCS[fn]
                if not lo <= len(args) <= hi:
                    need = str(lo) if lo == hi else f"{lo}–{hi}"
                    raise FormulaError(f"{fn} потребує {need} аргум., а дано {len(args)}")
                return ("fn", fn, args)
            if name.upper() in ("TRUE", "FALSE"):
                return ("num", 1.0 if name.upper() == "TRUE" else 0.0)
            return ("ref", name)
        if t[0] == "op" and t[1] == "(":
            node = expr()
            if not eat(")"):
                raise FormulaError("не закрито «)»")
            return node
        raise FormulaError(f"несподіване «{t[1]}»")

    root = expr()
    if pos[0] < len(tk):
        raise FormulaError(f"зайве «{tk[pos[0]][1]}» — можливо, бракує коми чи дужки")
    return root


def refs(node, out=None, in_event=False) -> list:
    """Усі посилання на параметри (без назв подій у COUNT/LAST/FIRST)."""
    out = [] if out is None else out
    kind = node[0]
    if kind == "ref" and not in_event:
        out.append(node[1])
    elif kind == "fn":
        for i, a in enumerate(node[2]):
            ev = node[1] in EVENT_FUNCS
            if ev and i == 0:
                continue                         # назва події — не параметр
            if ev and i == 1 and a[0] == "ref" and a[1].lower() in SCOPES:
                continue                         # life / lactation / prevlactation
            if node[1] in HIST_FUNCS and i == 2 and a[0] == "ref" and a[1].lower() in SCOPES:
                continue
            if node[1] in AGG_FUNCS and i == 1 and a[0] == "ref" and a[1].lower() in SCOPES:
                continue
            if node[1] == "WITHDRAWAL" and a[0] in ("ref", "str") and a[1].lower() in WD_KINDS:
                continue                         # milk / meat — не параметр
            refs(a, out)
    elif kind in ("bin", "cmp"):
        refs(node[2], out)
        refs(node[3], out)
    elif kind == "neg":
        refs(node[1], out)
    return out


def event_args(node, out=None) -> list:
    """Назви подій у COUNT/LAST/FIRST і область COUNT (life|lactation)."""
    out = [] if out is None else out
    if node[0] == "fn":
        if node[1] in EVENT_FUNCS and node[2]:
            a = node[2][0]
            if a[0] in ("ref", "str"):
                out.append(a[1])
            # другий аргумент — період: life / lactation / prevlactation, число
            # (№ лактації) або дата "РРРР-ММ-ДД"; параметр теж можна (перевіряє refs)
        for a in node[2]:
            event_args(a, out)
    elif node[0] in ("bin", "cmp"):
        event_args(node[2], out)
        event_args(node[3], out)
    elif node[0] == "neg":
        event_args(node[1], out)
    return out


# ── обчислення ────────────────────────────────────────────────────────────
def _as_date(v):
    if isinstance(v, date):
        return v
    if isinstance(v, str) and re.match(r"^\d{4}-\d{2}-\d{2}", v):
        try:
            return date.fromisoformat(v[:10])
        except ValueError:
            return None
    return None


def _as_num(v):
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        s = v.strip().replace(",", ".")
        if re.match(r"^-?\d+(\.\d+)?$", s):
            return float(s)
    return None


def _empty(v) -> bool:
    return v is None or (isinstance(v, str) and v.strip() in ("", "—"))


def _truthy(v) -> bool:
    if _empty(v):
        return False
    n = _as_num(v)
    return bool(n) if n is not None else True


class Ctx:
    """Що формулі відомо про тварину.
    ref(name) → значення параметра (рядок/число/дата) або None;
    events → [(ключ події, 'YYYY-MM-DD')]; event_key(name) → ключ або None;
    label(name, code) → назва коду; today → date; last_calving → дата."""

    def __init__(self, ref, events=None, event_key=None, label=None,
                 today: date | None = None, last_calving=None, pos=None, gestation=280,
                 lactation=None, hist=None, milking=None, withdrawal=None):
        self.ref = ref
        self.hist = hist or (lambda n: [])
        self.milking = milking or (lambda sec: 0.0)   # секція → 1/0 («Дійна»)
        self.withdrawal = withdrawal or (lambda kind: None)   # milk/meat → дата       # імʼя параметра → [{d, v}] за датою
        self.events = events or []
        self.event_key = event_key or (lambda n: n)
        self.label = label or (lambda n, c: None)
        self.today = today or date.today()
        self.last_calving = last_calving
        self.pos = pos or (lambda n, v: None)
        self.gestation = gestation
        self.lactation = lactation


def run(node, ctx: Ctx):
    k = node[0]
    if k == "num":
        return node[1]
    if k == "str":
        return node[1]
    if k == "ref":
        v = ctx.ref(node[1])
        return None if _empty(v) else v
    if k == "neg":
        n = _as_num(run(node[1], ctx))
        return None if n is None else -n
    if k == "bin":
        a, b = run(node[2], ctx), run(node[3], ctx)
        if _empty(a) or _empty(b):
            return None
        op = node[1]
        da, db = _as_date(a), _as_date(b)
        if op == "-" and da and db:
            return float((da - db).days)
        if op in ("+", "-") and da and _as_num(b) is not None:
            n = _as_num(b)
            return da + timedelta(days=int(n) * (1 if op == "+" else -1))
        if op == "+" and db and _as_num(a) is not None:
            return db + timedelta(days=int(_as_num(a)))
        na, nb = _as_num(a), _as_num(b)
        if na is None or nb is None:
            if op == "+":                        # текст + текст — склеїти
                return f"{a}{b}"
            return None
        if op == "+":
            return na + nb
        if op == "-":
            return na - nb
        if op == "*":
            return na * nb
        if op == "/":
            return None if nb == 0 else na / nb
        if op == "^":
            return na ** nb
    if k == "cmp":
        a, b = run(node[2], ctx), run(node[3], ctx)
        op = node[1]
        if _empty(a) or _empty(b):
            return (1.0 if op == "<>" and not (_empty(a) and _empty(b)) else 0.0) \
                if op in ("=", "<>") else 0.0
        da, db = _as_date(a), _as_date(b)
        na, nb = _as_num(a), _as_num(b)
        if da and db:
            x, y = da, db
        elif na is not None and nb is not None:
            x, y = na, nb
        else:
            x, y = str(a).strip().lower(), str(b).strip().lower()
        r = {"=": x == y, "<>": x != y, "<": x < y, ">": x > y,
             "<=": x <= y, ">=": x >= y}[op]
        return 1.0 if r else 0.0
    if k == "fn":
        return _fn(node[1], node[2], ctx)
    return None


def _event_name(arg) -> str:
    return arg[1] if arg[0] in ("ref", "str") else ""


def _window(scope_args, ctx: Ctx):
    """Період для COUNT/LAST/FIRST: (з дати, до дати — не включно), None — період
    невідомий (лактації з таким номером в історії не записано).
      без аргументу / life — усе життя;
      lactation — від останнього отелу; prevlactation — попередня лактація;
      число N — лактація № N (0 — до першого отелу);
      дата — з неї до сьогодні; дві дати — з першої до другої (не включно)."""
    if not scope_args:
        return ("", "")
    a = scope_args[0]
    word = a[1].lower() if a[0] in ("ref", "str") and a[1].lower() in SCOPES else ""
    today = ctx.today.isoformat()
    calvs = sorted(d[:10] for (ek, d) in ctx.events if ek == "calving" and d and d[:10] <= today)
    lc = _as_date(ctx.last_calving)
    if lc and (not calvs or lc.isoformat() > calvs[-1]):
        calvs.append(lc.isoformat())             # отел записаний параметром, без події
    n_lact = _as_num(ctx.lactation)
    n_lact = int(n_lact) if n_lact is not None else len(calvs)
    offset = max(0, n_lact - len(calvs))          # ранні отели, яких немає в історії

    def lact(k):
        if k < 0 or k > n_lact:
            return None
        if k == 0:
            return ("", calvs[0] if calvs else "") if offset == 0 else None
        i = k - offset - 1                        # індекс отелу, з якого почалась лактація k
        if i < 0 or i >= len(calvs):
            return None
        return (calvs[i], calvs[i + 1] if i + 1 < len(calvs) else "")

    if word == "life":
        return ("", "")
    if word == "lactation":
        return (calvs[-1] if calvs else "", "")
    if word == "prevlactation":
        return lact(n_lact - 1)
    v = run(a, ctx)
    d = _as_date(v)
    if d:
        hi = _as_date(run(scope_args[1], ctx)) if len(scope_args) > 1 else None
        return (d.isoformat(), hi.isoformat() if hi else "")
    n = _as_num(v)
    if n is None:
        return None
    return lact(int(n))


def _fn(fn, args, ctx: Ctx):
    if fn == "IF":                              # гілки — лише потрібна
        c = run(args[0], ctx)
        if _truthy(c):
            return run(args[1], ctx)
        return run(args[2], ctx) if len(args) > 2 else None
    if fn in EVENT_FUNCS:
        _nm = _event_name(args[0])
        key = ctx.event_key(_nm)
        win = _window(args[1:], ctx)
        if win is None:                          # такої лактації в історії немає
            return None
        lo, hi = win
        today = ctx.today.isoformat()
        if not key:
            # не подія — рахуємо ЗАПИСИ ПАРАМЕТРА: COUNT(fdat) = скільки разів
            # записано дату отелу. Потрібне, коли отелом стає не лише «Отел»:
            # пізній аборт теж ставить дату отелу (Роман 2026-09-20).
            recs = [r for r in (ctx.hist(_nm) or []) if not r.get("nodate")]
            ds = sorted((r.get("d") or "")[:10] for r in recs
                        if (r.get("d") or "")[:10] <= today)
            # порожня історія — це «жодного разу», тобто 0 (телиця без отелів
            # має показувати 0 лактацій, а не порожньо). Неіснуючу назву
            # відсікає перевірка формули при збереженні.
        else:
            ds = sorted(d[:10] for (ek, d) in ctx.events if ek == key and d and d[:10] <= today)
        ds = [d for d in ds if (not lo or d >= lo) and (not hi or d < hi)]
        if fn == "COUNT":
            return float(len(ds))
        if not ds:
            return None
        return _as_date(ds[-1] if fn == "LAST" else ds[0])
    if fn in HIST_FUNCS:
        return _hist_fn(fn, args, ctx)
    if fn in AGG_FUNCS:
        return _agg_fn(fn, args, ctx)
    if fn == "POS":
        a = args[0]
        name = a[1] if a[0] == "ref" else ""
        v = run(a, ctx)
        if _empty(v):
            return None
        return ctx.pos(name, v)
    if fn == "WITHDRAWAL":
        a = args[0]
        kind = WD_KINDS.get(str(a[1]).lower()) if a[0] in ("ref", "str") else None
        if not kind:
            raise FormulaError("WITHDRAWAL(milk) або WITHDRAWAL(meat)")
        return ctx.withdrawal(kind)
    if fn == "MILKING":                          # без аргументу — секція тварини
        sec = run(args[0], ctx) if args else ctx.ref("group")
        return 0.0 if _empty(sec) else ctx.milking(sec)
    if fn == "GESTATION":
        return float(ctx.gestation)
    if fn == "LABEL":
        a = args[0]
        name = a[1] if a[0] == "ref" else ""
        code = run(a, ctx)
        if _empty(code):
            return None
        lab = ctx.label(name, code)
        return lab if lab not in (None, "") else code
    vals = [run(a, ctx) for a in args]
    if fn == "TODAY":
        return ctx.today
    if fn in ("DAYS", "MONTHS"):
        a, b = _as_date(vals[0]), _as_date(vals[1])
        if not a or not b:
            return None
        if fn == "DAYS":
            return float((a - b).days)
        n = (a.year - b.year) * 12 + (a.month - b.month) - (1 if a.day < b.day else 0)
        return float(n)
    if fn == "ADDDAYS":
        d, n = _as_date(vals[0]), _as_num(vals[1])
        if not d or n is None:
            return None
        return d + timedelta(days=int(n))
    if fn == "AND":
        return 1.0 if all(_truthy(v) for v in vals) else 0.0
    if fn == "OR":
        return 1.0 if any(_truthy(v) for v in vals) else 0.0
    if fn == "NOT":
        return 0.0 if _truthy(vals[0]) else 1.0
    if fn == "ISEMPTY":
        return 1.0 if _empty(vals[0]) else 0.0
    if fn == "COALESCE":
        return next((v for v in vals if not _empty(v)), None)
    if fn == "IN":
        x = vals[0]
        if _empty(x):
            return 0.0
        nx = _as_num(x)
        for v in vals[1:]:
            nv = _as_num(v)
            if (nx is not None and nv is not None and nx == nv) or \
                    str(x).strip().lower() == str(v).strip().lower():
                return 1.0
        return 0.0
    if fn in ("MIN", "MAX"):
        ds = [_as_date(v) for v in vals if not _empty(v)]
        if ds and all(ds):
            return min(ds) if fn == "MIN" else max(ds)
        ns = [_as_num(v) for v in vals if _as_num(v) is not None]
        if not ns:
            return None
        return min(ns) if fn == "MIN" else max(ns)
    n = _as_num(vals[0])
    if n is None:
        return None
    if fn in ("ROUND", "ROUNDUP", "ROUNDDOWN"):
        # як в Excel: ROUND — половина від нуля (2.5 → 3, не «банківське» 2),
        # ROUNDUP — завжди від нуля, ROUNDDOWN — завжди до нуля
        nd = int(_as_num(vals[1]) or 0) if len(vals) > 1 else 0
        d = Decimal(str(n))
        q = Decimal(1).scaleb(-nd)
        mode = {"ROUND": ROUND_HALF_UP, "ROUNDUP": ROUND_UP, "ROUNDDOWN": ROUND_DOWN}[fn]
        return float(d.quantize(q, rounding=mode))
    if fn == "ABS":
        return abs(n)
    if fn == "INT":
        return float(int(n))
    return None


def _hist_fn(fn, args, ctx: Ctx):
    """VAL / VALDATE: запис параметра за позицією в його історії.
    1 — перший, 2 — другий…; −1 — останній, −2 — передостанній; 0 = −1.
    Третім аргументом — період, як у COUNT (lactation, prevlactation, № лактації, дати)."""
    a = args[0]
    name = a[1] if a[0] in ("ref", "str") else ""
    n = _as_num(run(args[1], ctx)) if len(args) > 1 else -1
    if n is None:
        return None
    n = int(n) or -1
    today = ctx.today.isoformat()
    recs = [r for r in (ctx.hist(name) or []) if (r.get("d") or "")[:10] <= today]
    if len(args) > 2:
        win = _window(args[2:], ctx)
        if win is None:
            return None
        lo, hi = win
        recs = [r for r in recs if (not lo or r["d"][:10] >= lo) and (not hi or r["d"][:10] < hi)]
    if n > 0:        # від початку — лише записи подій: внесене вручну без дати
        recs = [r for r in recs if not r.get("nodate")]   # не «вага при народженні»
    i = len(recs) + n if n < 0 else n - 1
    if i < 0 or i >= len(recs):
        return None
    r = recs[i]
    if fn == "VALDATE":
        return _as_date(r.get("d")) if not r.get("nodate") else None
    v = r.get("v")
    nv = _as_num(v)
    return nv if nv is not None else (_as_date(v) or v)


def _agg_fn(fn, args, ctx: Ctx):
    """AVGVAL / TOTAL над записами параметра в періоді (як у COUNT: без —
    усе життя; lactation, prevlactation, № лактації, дата[, дата]).

    TOTAL — надій за період за методом контрольних доїнь (ICAR): від початку
    періоду (отел) до першого контролю — за першим значенням, між контролями —
    середнє двох сусідніх, від останнього контролю — до кінця періоду. Кінець —
    запуск у цьому періоді (подія «Запуск»), якщо він після останнього
    контролю, інакше межа періоду або сьогодні."""
    a = args[0]
    name = a[1] if a[0] in ("ref", "str") else ""
    today = ctx.today.isoformat()
    win = _window(args[1:], ctx) if len(args) > 1 else ("", "")
    if win is None:
        return None
    lo, hi = win
    recs = []
    for r in (ctx.hist(name) or []):
        if r.get("nodate"):
            continue                              # внесене вручну без дати — не контроль
        d = (r.get("d") or "")[:10]
        n = _as_num(r.get("v"))
        if not d or n is None or d > today or (lo and d < lo) or (hi and d >= hi):
            continue
        recs.append((d, n))
    if not recs:
        return None
    recs.sort()
    if fn == "AVGVAL":
        return sum(n for _, n in recs) / len(recs)
    if not lo:
        # надій рахується від отелу (лактація) або від заданої дати; без початку
        # — ні: «за все життя» захопило б сухостій, а до першого отелу
        # (lactation 0 у телиці) молока не буває взагалі
        return None
    start = _as_date(lo)
    end = min(_as_date(hi), ctx.today) if hi else ctx.today
    dry_key = ctx.event_key("dryoff")
    if dry_key:
        drys = sorted(d[:10] for (ek, d) in ctx.events
                      if ek == dry_key and d and recs[-1][0] < d[:10] <= today
                      and (not hi or d[:10] < hi))
        if drys:
            end = _as_date(drys[0])               # після запуску молока немає
    total = recs[0][1] * max(0, (_as_date(recs[0][0]) - start).days)
    for (d1, v1), (d2, v2) in zip(recs, recs[1:]):
        total += (v1 + v2) / 2.0 * max(0, (_as_date(d2) - _as_date(d1)).days)
    total += recs[-1][1] * max(0, (end - _as_date(recs[-1][0])).days)
    return round(total, 1)


def to_value(v):
    """Результат → те, що зберігається/показується: дата ISO, ціле без «.0»."""
    if v is None:
        return None
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            return None
        return int(v) if v == int(v) else round(v, 4)
    return v
