/* Реєстр тварин (поголівний облік) — Фаза 1. */
'use strict';

/* Типи подій живуть у ДОВІДНИКУ (herd_event_defs) — проведення через
   Журнал (/herd/log): одна система, ефекти застосовуються завжди. */

let ALL_GROUPS = [];
let STATUSES = {};

const $ = (id) => document.getElementById(id);
const bind = (id, ev, fn) => { const el = $(id); if (el) el.addEventListener(ev, fn); };
const todayISO = () => new Date().toISOString().slice(0, 10);

/* ---------- фільтри ----------
   Вибір фільтрів памʼятається між сторінками (Роман 2026-09-15): перемикач
   тварин у шапці гілки гортає САМЕ цю вибірку, тож він має знати, що обрано,
   навіть коли людина пішла з реєстру на календар чи рух поголівʼя. */
const FLT_KEY = 'herd:filters';

function selText(id) {
    const el = $(id);
    const o = el && el.options[el.selectedIndex];
    return (o && o.value) ? o.textContent.trim() : '';
}

function curFilters() {
    return {
        q: $('animSearch').value.trim(),
        status: $('animStatus').value,
        sex: $('animSex').value,
        group_id: $('animGroup').value,
        // назви — щоб перемикач у шапці підписував вибірку словами
        // («Нетелі»), а не кодом: на інших сторінках цих списків немає
        group_name: selText('animGroup'),
        status_name: selText('animStatus'),
    };
}

function saveFilters(f) {
    try { localStorage.setItem(FLT_KEY, JSON.stringify(f)); } catch (e) { /* ignore */ }
}

function restoreFilters() {
    let f = null;
    try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
    if (!f) return;
    if (f.q) $('animSearch').value = f.q;
    // статус і секцію ставимо ПІСЛЯ того, як наповняться списки (fillFilters)
    pendingFilters = f;
}

let pendingFilters = null;

/* ---------- колонки ----------
   Роман 2026-09-17: «таке саме налаштування колонок у реєстрі тварин», як у
   груповому вводі. Бирка є завжди; решта — параметри з КОНСТРУКТОРА (назви
   теж звідти: «усі параметри повинні йти із списку, із конструктора»).
   Частину з них реєстр уже має в самій тварині — такі клітинки малюємо з
   неї, без запиту значень. Набір свій у кожного й лежить на сервері. */
const DEFAULT_COLS = ['name', 'sex', 'age_months', 'breed', 'group', 'lactation', 'status'];
let COLS = null;
let PARAMS = [];
let LAST_ITEMS = [];
// колонки, що беруться з самої тварини (без запиту параметрів)
const CORE_COLS = {
    name: { label: 'Кличка', cell: (a) => escapeHtml(a.name || '') },
    sex: { label: 'Стать', cell: (a) => escapeHtml(a.sex ? herdOpt('sex', a.sex) : '') },
    age_months: { label: 'Вік, міс', num: true, cell: (a) => (a.age_months == null ? '' : a.age_months) },
    breed: { label: 'Порода', cell: (a) => escapeHtml(a.breed || '') },
    group: { label: 'Секція', cell: (a) => escapeHtml(a.group_name || '') },
    // 0 — це телиці, нетелі й бики: показуємо нуль, а не порожнечу
    lactation: { label: 'Лакт.', num: true,
        cell: (a) => (a.lactation_no == null ? '' : a.lactation_no) },
    status: { label: 'Статус',
        cell: (a) => `<span class="anim-badge ${a.status}">${escapeHtml(a.status_label || '')}</span>` },
};
const paramOf = (k) => PARAMS.find((p) => p.key === k) || null;

function colLabel(k) {
    const p = paramOf(k);                  // назва — як у конструкторі
    if (p) return p.label;
    return CORE_COLS[k] ? CORE_COLS[k].label : k;
}

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}

function paramCell(a, k) {
    const raw = (a.p || {})[k];
    if (raw === null || raw === undefined || raw === '') return '';
    const num = numText(raw, (paramOf(k) || {}).dtype);
    if (num !== null) return escapeHtml(num);
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = k === 'repro_code' ? '' : (a.pl || {})[k];
    if (lbl) return escapeHtml(lbl);
    const p = paramOf(k);
    if (p && p.dtype === 'date' && /^\d{4}-\d{2}-\d{2}/.test(String(raw))) {
        const [y, m, d] = String(raw).slice(0, 10).split('-');
        return `${d}.${m}.${y}`;
    }
    // довгі номери (транспондер) — по три цифри, як у картці тварини
    if (/^\d{9,}$/.test(String(raw))) return String(raw).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
    return escapeHtml(String(raw));
}

/* ---------- вкладка «Робота зі стадом» ----------
   Рядок-формула своєю мовою (herd_query.js): ФІЛЬТР(…) ПОКАЗАТИ(…)
   ГРУПУВАТИ(…) СОРТУВАТИ(…). Нічого не зберігається — це разова вибірка. */
const AW_KEY = 'herd:work_formula';
/* ⚠️ «=» ПЕРЕД ФОРМУЛОЮ (Роман 2026-09-22: «не прибрав символ = перед
   формулою всередині»). Знак рівності стоїть ОКРЕМИМ значком ліворуч від
   поля — а в самому полі він дублювався, бо зберігається разом із формулою
   («=BODY(…)»). Тепер у полі його не показуємо, а в сховищі й у збережених
   списках лишаємо, щоб старі списки й посилання далі читались. */
const awNoEq = (t) => String(t === null || t === undefined ? '' : t).replace(/^\s*=\s*/, '');
const awWithEq = (t) => { const v = awNoEq(t).trim(); return v ? '=' + v : ''; };
/* прочитані тварини лежать у памʼяті: поки формула не просить НОВИХ
   параметрів, наступний запуск миттєвий — без звернення до сервера */
let WORK_CACHE = null;
const CACHE_TTL = 120000;
/* Остання вибірка «Роботи зі стадом» живе в памʼяті браузера між заходами:
   таблиця малюється одразу, а свіжі дані підтягуються слідом
   (Роман 2026-09-19: «моментальна робота»). */
const WORK_STORE = 'herd:work_cache';
function workCacheSave() {
    try {
        localStorage.setItem(WORK_STORE, JSON.stringify({
            keys: [...WORK_CACHE.keys], items: WORK_CACHE.items, at: WORK_CACHE.at,
            groups: ALL_GROUPS }));
    } catch (e) { /* місця немає — обійдемось памʼяттю сторінки */ }
}
function workCacheLoad() {
    try {
        const c = JSON.parse(localStorage.getItem(WORK_STORE) || 'null');
        if (c && Array.isArray(c.items) && c.items.length) {
            // з іншого заходу — могли змінитись, тож завжди перечитуємо слідом
            if (!ALL_GROUPS.length && Array.isArray(c.groups)) ALL_GROUPS = c.groups;
            return { keys: new Set(c.keys || []), items: c.items, at: c.at || 0, stored: true };
        }
    } catch (e) { /* ignore */ }
    return null;
}
let TAB = 'reg';
let Q = null;                        // розібрана формула
let ALL_ITEMS = [];
const qOn = () => TAB === 'work' && !!(Q && (Q.cols.length || Q.filters.length
    || Q.sorts.length || Q.groups.length));
const effCols = () => (qOn() && Q.cols.length ? Q.cols : COLS);
const stripTags = (h) => String(h === null || h === undefined ? '' : h)
    .replace(/<[^>]*>/g, '').trim();          // «0» лишається нулем, не порожнечею

let colsSaveT = null;
function saveCols() {
    clearTimeout(colsSaveT);
    colsSaveT = setTimeout(() => {
        apiSend('/api/herd/ui-columns', 'POST', { scope: 'registry', columns: COLS })
            .then((r) => { if (!r || !r.ok) toast('Колонки не збережено', 'error'); });
    }, 500);
}

async function loadColumns() {
    const [c, ev] = await Promise.all([
        apiGet('/api/herd/ui-columns?scope=registry'),
        apiGet('/api/herd/events?active=1'),        // перелік параметрів — там же
    ]);
    PARAMS = (ev && ev.ok) ? (ev.params || []) : [];
    const saved = c && c.ok ? c.columns : null;
    // лише те, що є в конструкторі
    COLS = (saved || DEFAULT_COLS).filter((k) => paramOf(k));
}

/* ---------- список ---------- */
async function loadList() {
    const f = curFilters();
    const params = new URLSearchParams();
    // у «Роботі зі стадом» добір задає формула, а не панель фільтрів
    if (TAB !== 'work') Object.keys(f).forEach((k) => { if (f[k]) params.set(k, f[k]); });
    saveFilters(f);
    if (COLS === null) await loadColumns();
    // значення параметрів: колонки + усе, що згадала формула
    const need = [...new Set([...effCols(), ...((qOn() && Q.keys) || [])])]
        .filter((k) => qOn() || !CORE_COLS[k]);
    if (need.length) params.set('params', need.join(','));
    // у «Роботі зі стадом» беремо лише потрібні поля — відповідь удвічі легша
    if (TAB === 'work') params.set('lean', '1');
    const r = await apiGet('/api/herd/animals?' + params.toString());
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    STATUSES = r.statuses || {};
    ALL_GROUPS = r.groups || [];
    fillFilters();
    if (pendingFilters) {                   // списки готові — ставимо збережене
        const f0 = pendingFilters;
        pendingFilters = null;
        if (f0.status) $('animStatus').value = f0.status;
        if (f0.sex) $('animSex').value = f0.sex;
        if (f0.group_id) $('animGroup').value = f0.group_id;
        if (f0.status || f0.sex || f0.group_id) { loadList(); return; }
    }
    renderStats(r.stats || {});
    ALL_ITEMS = r.items || [];
    if (TAB === 'work') {                          // запамʼятовуємо, що вже прочитано
        WORK_CACHE = { keys: new Set(need), items: ALL_ITEMS, at: Date.now() };
        workCacheSave();
    }
    renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
    // перемикач у шапці гортає цю саму вибірку — віддаємо йому свіжий
    // порядок замість того, щоб він питав сервер удруге
    if (window.herdNav) window.herdNav.cacheList(r.items || []);
}

function fillFilters() {
    const st = $('animStatus');
    if (st.options.length <= 1) {
        // «вибулі» — не окремий статус, а всі, крім тих, що в стаді; те саме
        // значення розуміють перемикач у смужці й панель добору
        const gone = document.createElement('option');
        gone.value = 'gone'; gone.textContent = 'Вибулі';
        st.appendChild(gone);
        Object.entries(STATUSES).forEach(([k, v]) => {
            const o = document.createElement('option'); o.value = k; o.textContent = v;
            st.appendChild(o);
        });
    }
    const g = $('animGroup');
    if (g.options.length <= 1) {
        ALL_GROUPS.forEach((gr) => {
            const o = document.createElement('option'); o.value = gr.id; o.textContent = gr.name;
            g.appendChild(o);
        });
    }
}

function renderStats(s) {
    $('animStats').innerHTML =
        `<div class="anim-stat"><b>${s.active || 0}</b><span>${escapeHtml(herdOpt('status', 'active', 'В стаді'))}</span></div>` +
        `<div class="anim-stat"><b>${s.cows || 0}</b><span>${escapeHtml(herdOpt('sex', 'F', 'Корів/телиць'))}</span></div>`;
}

/* порядок секцій — ПОВНИЙ список Конструктора (у варіантах параметра лише
   секції з чинним періодом, тож секція без періоду випадала з порядку) */
function sortParamsFor() {
    if (!ALL_GROUPS.length) return PARAMS;
    return PARAMS.map((p) => (p.key === 'group'
        ? Object.assign({}, p, { choices: ALL_GROUPS.map((g) => ({ value: g.name, label: g.name })) })
        : p));
}

/* добір і порядок — за формулою */
function applyQ(items) {
    if (!qOn()) return items;
    let out = items.filter((a) => window.herdQuery.passes(a, Q.filters));
    // порядок груп — за Конструктором; «sort <параметр групи> desc» перевертає групи
    const dirOf = (k) => ((Q.sorts.find((sx) => sx.key === k) || {}).dir || 'asc');
    const order = Q.groups.map((k) => ({ key: k, dir: dirOf(k) }))
        .concat(Q.sorts.filter((sx) => !Q.groups.includes(sx.key)));
    if (order.length) out = window.herdQuery.sortRows(out, order, sortParamsFor());
    return out;
}

const TAG_KEYS = ['tag', 'id'];
/* у «Роботі зі стадом» шапка коротка — тими самими словами, що й у формулі */
function headLabel(k) {
    const p = paramOf(k);
    return qOn() ? (p ? awShort(p) : k) : colLabel(k);
}
const tagInCols = () => effCols().some((k) => TAG_KEYS.includes(k));

function renderHead() {
    const html = (qOn() && Q.rownum ? '<th class="num">№</th>' : '')
        + (tagInCols() ? '' : `<th>${escapeHtml(qOn()
            ? (paramOf('tag') ? awShort(paramOf('tag')) : 'id')
            : herdLabel('tag', 'Номер тварини'))}</th>`)
        + effCols().map((k) => {
        const p = paramOf(k);
        const num = (CORE_COLS[k] && CORE_COLS[k].num) || (!CORE_COLS[k] && p && ['int', 'float'].includes(p.dtype));
        const p2 = paramOf(k);
        return `<th${num ? ' class="num"' : ''}`
            + `${qOn() && p2 ? ` title="${escapeHtml(p2.label)}"` : ''}>`
            + `${escapeHtml(headLabel(k))}</th>`;
    }).join('');
    $('animHead').innerHTML = html;
}

let ROW_NO = 0;
function rowHtml(a) {
    ROW_NO += 1;
    const cells = [];
    if (qOn() && Q.rownum) cells.push(`<td class="num">${ROW_NO}</td>`);
    if (!tagInCols()) cells.push(`<td><b>${escapeHtml(a.tag)}</b></td>`);
    effCols().forEach((k) => {
        if (CORE_COLS[k]) {
            cells.push(`<td${CORE_COLS[k].num ? ' class="num"' : ''}>${CORE_COLS[k].cell(a)}</td>`);
            return;
        }
        const p = paramOf(k);
        const num = p && ['int', 'float'].includes(p.dtype);
        cells.push(`<td${num ? ' class="num"' : ''}>${paramCell(a, k)}</td>`);
    });
    return `<tr data-id="${a.id}">${cells.join('')}</tr>`;
}

/* ---------- увесь добір → «Груповий ввід» (Роман 2026-09-22) ----------
   Спершу тут були галочки в рядках, але Роман: «прибери галочки, просто
   зроби посилання на груповий ввід і збережи фільтрацію». Тож туди їде
   ВЕСЬ добір — САМОЮ ФОРМУЛОЮ (?f=…), тож там список живий і рахується
   на місці, а не приїжджає замороженим переліком номерів. */

function awGoUpd() {
    const b = $('awEvent');
    if (!b) return;
    const n = (qOn() && Q.cols.length) ? LAST_ITEMS.length : 0;
    b.hidden = !n;
    b.textContent = `Груповий ввід · ${n}`;
    b.title = 'Внести подію для всіх тварин цього списку';
}

/* підсумки: кількість і середнє/сума по числових параметрах */
const numFmt = (v, dec) => (Math.round(v * 10 ** dec) / 10 ** dec)
    .toLocaleString('uk-UA', { minimumFractionDigits: dec, maximumFractionDigits: dec });

function aggText(rows) {
    const aggs = (qOn() && Q.aggs) || [];
    // «N гол.» показуємо, поки не попросили cnt окремо
    const out = aggs.some((a) => a.fn === 'cnt') ? [] : [`<b>${rows.length}</b> гол.`];
    aggs.forEach((a) => {
        if (a.fn === 'cnt') {                     // кількість: усіх або із заповненим параметром
            const n = a.key
                ? rows.filter((x) => {
                    const v = (x.p || {})[a.key];
                    return !(v === null || v === undefined || v === '');
                }).length
                : rows.length;
            const p0 = a.key ? paramOf(a.key) : null;
            out.push(`cnt${p0 ? ' ' + escapeHtml(p0.short || p0.key) : ''} <b>${n}</b>`);
            return;
        }
        const nums = rows.map((x) => {
            const raw = (x.p || {})[a.key];
            const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
            return Number.isFinite(n) ? n : null;
        }).filter((n) => n !== null);
        if (!nums.length) return;
        const p = paramOf(a.key);
        const nm = p ? (p.short || p.key) : a.key;
        const v = a.fn === 'sum' ? nums.reduce((t, n) => t + n, 0)
            : a.fn === 'min' ? Math.min(...nums)
            : a.fn === 'max' ? Math.max(...nums)
            : nums.reduce((t, n) => t + n, 0) / nums.length;
        // назви агрегацій — ті самі слова, що й у формулі
        const dec = ['sum', 'min', 'max'].includes(a.fn) ? 0 : 1;
        out.push(`${a.fn} ${escapeHtml(nm)} <b>${numFmt(v, dec)}</b>`);
    });
    return out.join(' · ');
}

/* одне число агрегації */
function aggValue(a, rows) {
    if (a.fn === 'cnt') {
        return a.key
            ? rows.filter((x) => {
                const v = (x.p || {})[a.key];
                return !(v === null || v === undefined || v === '');
            }).length
            : rows.length;
    }
    const nums = rows.map((x) => {
        const raw = (x.p || {})[a.key];
        const n = parseFloat(String(raw === undefined || raw === null ? '' : raw).replace(',', '.'));
        return Number.isFinite(n) ? n : null;
    }).filter((n) => n !== null);
    if (!nums.length) return null;
    if (a.fn === 'sum') return nums.reduce((t, n) => t + n, 0);
    if (a.fn === 'min') return Math.min(...nums);
    if (a.fn === 'max') return Math.max(...nums);
    return nums.reduce((t, n) => t + n, 0) / nums.length;
}

/* підсумковий рядок таблиці: числа стоять У СВОЇХ колонках, без підписів
   (Роман 2026-09-18: «вигрупування напроти стовпця — чіткіше») */
function sumRowHtml(rows, title, cls) {
    const aggs = (qOn() && Q.aggs) || [];
    const cols = effCols();
    const byCol = new Map();
    const rest = [];
    aggs.forEach((a) => {
        const v = aggValue(a, rows);
        if (v === null) return;
        const dec = a.fn === 'avg' ? 1 : 0;
        const txt = numFmt(v, dec);
        if (a.key && cols.includes(a.key)) {           // кілька агрегацій на колонку — поруч
            const cur = byCol.get(a.key) || { fns: [], txts: [] };
            cur.fns.push(a.fn); cur.txts.push(txt);
            byCol.set(a.key, cur);
        } else if (a.fn === 'cnt' && !a.key) rest.push(txt);   // просто кількість, без підпису
        else rest.push(`${a.fn}${a.key ? ' ' + escapeHtml(colShort(a.key)) : ''} ${txt}`);
    });
    const head = escapeHtml(title) + (aggs.some((a) => a.fn === 'cnt' && !a.key)
        ? '' : ` · ${rows.length}`)
        + (rest.length ? ` · ${rest.join(' · ')}` : '');
    // назва групи займає колонки ДО першої з числом — інакше вона розсуває «id»
    const lead = (qOn() && Q.rownum ? 1 : 0) + (tagInCols() ? 0 : 1);
    let firstNum = cols.findIndex((k) => byCol.has(k));
    if (firstNum < 0) firstNum = cols.length;
    const titleSpan = lead + firstNum - (qOn() && Q.rownum ? 1 : 0);
    let html = `<tr class="${cls}">`;
    if (qOn() && Q.rownum) html += '<td></td>';
    html += `<td colspan="${Math.max(1, titleSpan)}">${head}</td>`;
    cols.slice(tagInCols() ? firstNum : firstNum).forEach((k, i) => {
        if (i + firstNum < firstNum) return;
        const hit = byCol.get(k);
        html += `<td${isNumCol(k) ? ' class="num"' : ''}`
            + `${hit ? ` title="${hit.fns.join(' · ')}"` : ''}>`
            + `${hit ? `<b>${hit.txts.join(' · ')}</b>` : ''}</td>`;
    });
    return html + '</tr>';
}

const colShort = (k) => { const p = paramOf(k); return p ? (p.short || p.key) : k; };
const isNumCol = (k) => {
    if (CORE_COLS[k] && CORE_COLS[k].num) return true;
    const p = paramOf(k);
    return !!p && ['int', 'float', 'number'].includes(p.dtype);
};

function aggRow(rows, cls) {
    if (!qOn() || (!Q.aggs.length && !Q.groups.length)) return '';
    const span = effCols().length + (tagInCols() ? 0 : 1) + (Q.rownum ? 1 : 0);
    return `<tr class="anim-sum ${cls || ''}"><td colspan="${span}">${aggText(rows)}</td></tr>`;
}

/* групи формули — рядком-шапкою, як у календарі */
function groupedHtml(items, lvl) {
    const gs = (qOn() && Q.groups) || [];
    if (lvl >= gs.length) return items.map(rowHtml).join('');
    const k = gs[lvl];
    let by = new Map();
    items.forEach((a) => {
        const _t = stripTags(CORE_COLS[k] ? CORE_COLS[k].cell(a) : paramCell(a, k));
        const t = _t === '' || _t == null ? '— не вказано' : _t;   // «0» — теж значення
        if (!by.has(t)) by.set(t, []);
        by.get(t).push(a);
    });
    // порядок самих груп: якщо в sort стоїть параметр, однаковий у межах групи
    // (напр. «№ секції» при групуванні за секцією) — групи шикуються за ним
    const gsort = ((qOn() && Q.sorts) || []).find((sx) => {
        if (sx.key === k) return true;
        return [...by.values()].every((part) => {
            const v0 = (part[0].p || {})[sx.key];
            return part.every((a) => (a.p || {})[sx.key] === v0);
        });
    });
    if (gsort) {
        const rows = [...by.entries()].map(([t, part]) => ({ t, part, a: part[0] }));
        const sorted = window.herdQuery.sortRows(rows.map((x) => x.a),
            [{ key: gsort.key, dir: gsort.dir }], sortParamsFor());
        const pos = new Map(sorted.map((a, idx) => [a, idx]));
        rows.sort((x, y) => pos.get(x.a) - pos.get(y.a));
        by = new Map(rows.map((x) => [x.t, x.part]));
    }
    const span = effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0);
    const pre = gs.length > 1 ? `${escapeHtml(headLabel(k))}: ` : '';
    // шапка групи: назва + числа агрегацій у своїх колонках
    // рівень групи — у класі (l0, l1…): друк повторює на новому аркуші й батьківську шапку
    const gcls = `anim-grp l${Math.min(lvl, 2)}`;
    return [...by.entries()].map(([t, part]) =>
        (qOn() && Q.aggs.length
            ? sumRowHtml(part, pre + t, gcls)
            : `<tr class="${gcls}"><td colspan="${span}">${pre}${escapeHtml(t)} · ${part.length}</td></tr>`)
        + groupedHtml(part, lvl + 1)).join('');
}

function renderTable(items, total) {
    LAST_ITEMS = items;
    // у «Роботі зі стадом» таблиця по ширині вмісту, а не на все вікно
    const tbl = document.querySelector('.anim-table');
    tbl.classList.toggle('auto-w', qOn());
    delete tbl.dataset.colsResizable;              // шапка перемальовується
    delete tbl.dataset.colsFixed;
    tbl.classList.remove('is-sized');
    tbl.style.tableLayout = '';
    tbl.style.width = '';
    renderHead();
    const all = total === undefined ? items.length : total;
    $('animCount').textContent = items.length
        ? `· ${items.length}${qOn() && all !== items.length ? ` із ${all}` : ''}` : '';
    const tb = $('animBody');
    if (!items.length) {
        tb.innerHTML = `<tr><td colspan="${effCols().length + (tagInCols() ? 0 : 1) + (qOn() && Q.rownum ? 1 : 0)}" class="empty">${qOn()
            ? 'За цією формулою нікого' : 'Немає тварин. Додайте або імпортуйте.'}</td></tr>`;
        return;
    }
    ROW_NO = 0;
    tb.innerHTML = groupedHtml(items, 0)
        + (qOn() && Q.aggs.length ? sumRowHtml(items, 'Разом', 'anim-sum all')
            : (qOn() && Q.groups.length ? aggRow(items, 'all') : ''));
    // ширину колонок можна тягнути за межу заголовка; памʼятається в браузері
    // У «Роботі зі стадом» ширину не чіпаємо руками: колонка сама стає
    // за найширшим вмістом (Роман 2026-09-18). Ручний ресайз — лише в реєстрі.
    if (!qOn()) requestAnimationFrame(() => makeColumnsResizable('animTable', 'herd:reg_colw'));
    awKeepWidth();
    awGoUpd();
    tb.querySelectorAll('tr[data-id]').forEach((tr) => {
        tr.addEventListener('click', () => {
            const a = items.find((x) => String(x.id) === String(tr.dataset.id));
            if (a && window.herdNav) window.herdNav.setCurrent(a);
            location.href = '/herd/animals/' + tr.dataset.id;
        });
    });
}

/* ⚠️ ТАБЛИЦЯ НЕ ВУЖЧАЄ ВІД ОНОВЛЕННЯ (Роман 2026-09-22). Один і той самий
   список малюється ДВІЧІ — спершу з памʼяті, а за мить із сервера, — і колонки
   щоразу міряються наново за вмістом, тож ширина сіпалась на очах. Тепер для
   відкритої формули памʼятаємо найбільшу заміряну ширину кожної колонки і
   ставимо її НИЖНЬОЮ межею: довший текст колонку ще розсуне, коротший —
   уже ні. Нова формула — міряємо з чистого аркуша. */
let WKEEP_SIG = '', WKEEP = [];
function awKeepWidth() {
    const tbl = $('animTable');
    if (!tbl || !tbl.tHead || !qOn()) { WKEEP_SIG = ''; WKEEP = []; return; }
    const ths = [...tbl.tHead.rows[0].cells];
    const sig = ($('awInput').value || '').trim();
    if (sig !== WKEEP_SIG) { WKEEP_SIG = sig; WKEEP = []; }
    ths.forEach((th) => { th.style.minWidth = ''; });        // міряємо вільно
    const now = ths.map((th) => Math.round(th.getBoundingClientRect().width));
    WKEEP = ths.map((th, i) => Math.max(WKEEP[i] || 0, now[i] || 0));
    ths.forEach((th, i) => { if (WKEEP[i]) th.style.minWidth = WKEEP[i] + 'px'; });
}

/* ---------- модал додати/редагувати ---------- */
function groupOptions(sel) {
    return '<option value="">—</option>' + ALL_GROUPS.map((g) =>
        `<option value="${g.id}"${String(g.id) === String(sel || '') ? ' selected' : ''}>${escapeHtml(g.name)}</option>`).join('');
}

function openEdit(a) {
    const isNew = !a;
    $('animEditTitle').textContent = isNew ? 'Нова тварина' : 'Редагувати тварину';
    $('afTag').value = a ? a.tag : '';
    $('afName').value = a ? (a.name || '') : '';
    $('afSex').value = a ? a.sex : 'F';
    $('afBirth').value = a ? (a.birth_date || '') : '';
    $('afBreed').value = a ? (a.breed || '') : '';
    $('afGroup').innerHTML = groupOptions(a ? a.group_id : '');
    $('afDam').value = a ? (a.dam_tag || '') : '';
    $('afSire').value = a ? (a.sire_code || '') : '';
    $('afLact').value = a ? (a.lactation_no || 0) : 0;
    $('afSource').value = a ? (a.source || 'born') : 'born';
    $('afEntry').value = a ? (a.entry_date || '') : todayISO();
    $('afNotes').value = a ? (a.notes || '') : '';
    $('afSaveBtn').dataset.id = a ? a.id : '';
    show('animEditModal');
    $('afTag').focus();
}

async function saveAnimal() {
    const id = $('afSaveBtn').dataset.id;
    const payload = {
        tag: $('afTag').value, name: $('afName').value, sex: $('afSex').value,
        birth_date: $('afBirth').value, breed: $('afBreed').value,
        group_id: $('afGroup').value, dam_tag: $('afDam').value,
        sire_code: $('afSire').value, lactation_no: $('afLact').value,
        source: $('afSource').value, entry_date: $('afEntry').value,
        notes: $('afNotes').value,
    };
    const url = id ? '/api/herd/animals/' + id : '/api/herd/animals';
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Збережено', 'success');
    hide('animEditModal');
    // одна картка тварини на всю гілку: після збереження — одразу в неї
    // (окреме спрощене вікно картки прибрано, Роман 2026-09-17)
    const newId = id || (r && r.id);
    if (newId) { location.href = '/herd/animals/' + newId; return; }
    await loadList();
}

/* ---------- імпорт ---------- */
async function doImport(file) {
    const st = $('animImportStatus');
    st.textContent = 'Завантаження…';
    const fd = new FormData(); fd.append('file', file);
    try {
        const r = await fetch('/api/herd/animals/import', { method: 'POST', body: fd });
        const j = await r.json();
        if (!j.ok) { st.textContent = 'Помилка: ' + (j.error || 'невідома'); return; }
        // Кажемо не лише «скільки», а й ЩО саме зайшло: коли у файлі були
        // колонки параметрів (транспондер, UIN), людина має бачити, що їх
        // розпізнано — інакше незрозуміло, чи спрацювало
        const pc = (j.param_columns || []);
        st.textContent = `Готово: додано ${j.added}, оновлено ${j.updated}` +
            (j.skipped ? `, пропущено ${j.skipped}` : '') +
            (j.missing ? `, не знайдено в реєстрі ${j.missing}` : '') +
            (pc.length ? ` · ${pc.join(', ')}: заповнено ${j.params_set || 0}` : '') +
            (j.errors && j.errors.length ? ` · помилок ${j.errors.length}` : '');
        loadList();
    } catch (e) { st.textContent = 'Сервер не відповів'; }
}

/* ---------- модал helpers ---------- */
function show(id) { const m = $(id); if (m) m.hidden = false; }
function hide(id) { const m = $(id); if (m) m.hidden = true; }
document.querySelectorAll('[data-close]').forEach((el) =>
    el.addEventListener('click', () => { el.closest('.modal').hidden = true; }));

/* ---------- init ---------- */
let searchTimer = null;
bind('animSearch', 'input', () => {
    clearTimeout(searchTimer); searchTimer = setTimeout(loadList, 250);
});
['animStatus', 'animSex', 'animGroup'].forEach((id) => bind(id, 'change', loadList));
bind('animAddBtn', 'click', () => openEdit(null));
bind('afSaveBtn', 'click', saveAnimal);
bind('animImportBtn', 'click', () => $('animImportFile').click());
bind('animImportFile', 'change', (e) => {
    if (e.target.files && e.target.files[0]) doImport(e.target.files[0]);
    e.target.value = '';
});

/* ---------- збережені списки (вкладка «Списки») ----------
   Формула з назвою, категорією і коментарем; лежать на сервері — одні на
   ферму, як списки календаря. Відкритий список лишається «приєднаним», тож
   виправлену формулу можна перезберегти однією кнопкою. */
let WLISTS = [], WCATS = [], WCUR = null;

async function wlLoad() {
    const r = await apiGet('/api/herd/work-lists').catch(() => null);
    WLISTS = (r && r.ok) ? (r.lists || []) : [];
    WCATS = (r && r.ok) ? (r.categories || []) : [];
    const sel = $('wlCat');
    if (sel && sel.options.length <= 1) {
        WCATS.forEach((c) => sel.insertAdjacentHTML('beforeend',
            `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`));
    }
    const save = $('awSaveCat');
    if (save && !save.options.length) {
        save.innerHTML = '<option value="">Без категорії</option>'
            + WCATS.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    }
    wlRender();
}

async function wlSave() {
    const r = await apiSend('/api/herd/work-lists', 'POST', { lists: WLISTS });
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося зберегти', 'error'); return false; }
    WLISTS = r.lists || [];
    wlRender();
    return true;
}

function wlRender() {
    const box = $('wlBody');
    if (!box) return;
    const q = ($('wlSearch') ? $('wlSearch').value : '').trim().toLowerCase();
    const cat = $('wlCat') ? $('wlCat').value : '';
    const rows = WLISTS.filter((L) => (!cat || L.category === cat)
        && (!q || `${L.name} ${L.note || ''} ${L.formula}`.toLowerCase().includes(q)));
    const tbl = $('wlTbl');
    if (!rows.length) {
        if (tbl) tbl.classList.add('is-empty');
        box.innerHTML = `<tr><td colspan="3" class="wl-empty">${WLISTS.length
            ? 'За цим добором нічого немає.'
            : 'Збережених списків ще немає. Наберіть формулу у «Роботі зі стадом» і збережіть її значком 💾.'}</td></tr>`;
        return;
    }
    if (tbl) tbl.classList.remove('is-empty');
    // теми йдуть у порядку Конструктора, «Без категорії» — останньою
    const secs = [];
    (WCATS.length ? WCATS : [...new Set(rows.map((L) => L.category))].filter(Boolean))
        .forEach((c) => {
            const got = rows.filter((L) => L.category === c);
            if (got.length) secs.push([c, got]);
        });
    const rest = rows.filter((L) => !L.category);
    if (rest.length) secs.push(['Без категорії', rest]);

    const rowHtml = (L) => `<tr class="wl-row" data-id="${escapeHtml(L.id)}">
        <td class="wl-cname"><span class="wl-name" data-act="open" title="Відкрити">${escapeHtml(L.name)}</span></td>
        <td>
            <code class="wl-f">${awHlHtml(L.formula)}</code>
            <button type="button" class="wl-fcopy" data-act="fcopy"
                    title="Скопіювати формулу" aria-label="Скопіювати формулу"><svg
                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
                    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect
                    x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0
                    1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
            ${L.note ? `<div class="wl-note">${escapeHtml(L.note)}</div>` : ''}
        </td>
        <td class="wl-acts">
            <button type="button" data-act="copy"
                    title="Зробити копію — щоб правити, не чіпаючи цей список">⧉</button>
            <button type="button" data-act="rename" title="Перейменувати">✎</button>
            <button type="button" data-act="del" title="Видалити">✕</button>
        </td>
    </tr>`;
    box.innerHTML = secs.map(([c, got]) => `<tr class="wl-sec"><td colspan="3">
        ${escapeHtml(c)}<span class="wl-n">${got.length}</span></td></tr>`
        + got.map(rowHtml).join('')).join('');
}

/* який список зараз відкрито у «Роботі зі стадом» */
function wlSetCur(L) {
    // відкрили інший список — коробка ⚙ більше не про нього
    if (CFG_FOR && (!L || String(L.id) !== CFG_FOR.id)) awCfgClose();
    WCUR = L || null;
    if (WCUR) OV_CUR = null;
    awCurShow();
    railRender();                       // у рейці підсвічується відкритий список
}

/* ---------- рейка збережених списків збоку від таблиці ----------
   Кількість голів рахується ТУТ, у браузері, тією самою мовою добору, що й
   сама формула — оператор бачить, куди йти, ще до кліку. Якщо для якогось
   списку бракує значень параметра, один раз дочитуємо їх усі разом. */
let RAIL_N = {}, RAIL_ITEMS = null, RAIL_KEYS = null;

/* рейку можна згорнути — тоді таблиці дістається вся ширина
   (Роман 2026-09-22: «щоб цю частину можна скривати, розкривати») */
const RAIL_CLOSED_KEY = 'herd:rail_closed';
let RAIL_CLOSED = false;
try { RAIL_CLOSED = localStorage.getItem(RAIL_CLOSED_KEY) === '1'; } catch (e) { /* ignore */ }

let RAIL_Q = '';

/* каркас рейки будуємо ОДИН раз: інакше перемальовка на кожну літеру
   забирала б фокус із поля пошуку */
function railShell(box) {
    if (box.dataset.shell === '1') return;
    box.dataset.shell = '1';
    box.innerHTML = '<button type="button" class="awr-head" id="awRailHead"></button>'
        + '<input type="search" id="awRailQ" class="awr-q" autocomplete="off"'
        + ' placeholder="пошук списку">'
        + '<div id="awRailList"></div>';
    $('awRailQ').addEventListener('input', () => {
        RAIL_Q = $('awRailQ').value.trim().toLowerCase();
        railList();
    });
}

function railRender() {
    const box = $('awRail');
    if (!box) return;
    box.hidden = TAB !== 'work';
    if (box.hidden) return;
    railShell(box);
    box.classList.toggle('is-closed', RAIL_CLOSED);
    const head = $('awRailHead');
    head.title = RAIL_CLOSED ? 'Показати списки' : 'Згорнути списки';
    head.innerHTML = `<span class="awr-chev">${RAIL_CLOSED ? '▸' : '▾'}</span>Списки`;
    $('awRailQ').hidden = RAIL_CLOSED || WLISTS.length < 2;
    $('awRailList').hidden = RAIL_CLOSED;
    if (!RAIL_CLOSED) railList();
}

function railList() {
    const wrap = $('awRailList');
    if (!wrap) return;
    if (!WLISTS.length) {
        wrap.innerHTML = '<p class="awr-cat">Збережених списків ще немає</p>';
        return;
    }
    const by = new Map();
    WLISTS.forEach((L) => {
        const c = (L.category || '').trim() || 'Інше';
        if (!by.has(c)) by.set(c, []);
        by.get(c).push(L);
    });
    // нумерація СВОЯ в кожній категорії (Роман 2026-09-22): «Інше 1, 2»,
    // «Відтворення 1» — щоб список можна було назвати номером уголос.
    // Рахуємо ДО пошуку, щоб номер не стрибав, коли частину відсіяно.
    const no = new Map();
    by.forEach((ls) => ls.forEach((L, i) => no.set(String(L.id), i + 1)));
    const hit = (L) => !RAIL_Q
        || `${L.name} ${L.category || ''} ${L.note || ''}`.toLowerCase().includes(RAIL_Q);
    const html = [...by.entries()].map(([c, ls]) => {
        const seen = ls.filter(hit);
        if (!seen.length) return '';
        return `<p class="awr-cat">${escapeHtml(c)}</p>` + seen.map((L) => {
            const n = RAIL_N[L.id];
            // свій колір списку (шестерня «Вигляд»): лише чистий hex у style=
            const hex = (c) => (/^#[0-9a-f]{6}$/i.test(c || '') ? c : '');
            // кладемо ЗМІННІ, а не готові кольори: інакше темна тема не мала б
            // чим їх перебити (у панелей «Огляду» так і зроблено)
            const st = [hex(L.color) && `--awr-ink:${hex(L.color)}`,
                hex(L.color) && '--awr-dim:.75',   // номер і кількість — трохи тихіше
                hex(L.edge) && `--awr-edge:${hex(L.edge)}`,
                hex(ovBgOf(L.bg || '')) && `--awr-bg:${hex(ovBgOf(L.bg || ''))}`]
                .filter(Boolean).join(';');
            return `<button type="button" class="awr-i${WCUR && String(WCUR.id) === String(L.id) ? ' on' : ''}"`
                + (st ? ` style="${st}"` : '')
                + ` data-wl="${escapeHtml(L.id)}" title="${escapeHtml(L.note || L.name)}">`
                + `<i class="awr-no">${no.get(String(L.id))}</i>`
                + `<span>${escapeHtml(L.name)}</span>`
                + `<b>${n === undefined ? '' : n}</b></button>`;
        }).join('');
    }).join('');
    wrap.innerHTML = html || '<p class="awr-cat">Нічого не знайшли</p>';
}

async function railCounts() {
    if (!WLISTS.length || !PARAMS.length) return;
    const qs = WLISTS.map((L) => {
        const q = window.herdQuery.parse(String(L.formula || '').replace(/^\s*=/, ''), PARAMS);
        return (q && !q.error) ? { id: L.id, q } : null;
    }).filter(Boolean);
    if (!qs.length) return;
    // «ядрові» параметри (лактація, статус) теж просимо ЗНАЧЕННЯМИ: добір
    // читає їх із p, а не з полів картки — без цього лічильник давав 0
    const need = [...new Set(qs.flatMap((x) => x.q.keys || []))];
    let items = null;
    if (WORK_CACHE && need.every((k) => WORK_CACHE.keys.has(k))) items = WORK_CACHE.items;
    else if (RAIL_KEYS && need.every((k) => RAIL_KEYS.has(k))) items = RAIL_ITEMS;
    if (!items) {
        const qp = 'lean=1' + (need.length ? '&params=' + encodeURIComponent(need.join(',')) : '');
        const r = await apiGet('/api/herd/animals?' + qp).catch(() => null);
        if (!r || !r.ok) return;                       // не порахували — просто без числа
        RAIL_ITEMS = r.items || [];
        RAIL_KEYS = new Set(need);
        items = RAIL_ITEMS;
    }
    qs.forEach((x) => {
        RAIL_N[x.id] = items.filter((a) => window.herdQuery.passes(a, x.q.filters)).length;
    });
    railRender();
}

document.addEventListener('click', (e) => {
    if (e.target.closest('#awRailHead')) {
        RAIL_CLOSED = !RAIL_CLOSED;
        try { localStorage.setItem(RAIL_CLOSED_KEY, RAIL_CLOSED ? '1' : '0'); } catch (er) { /* ignore */ }
        railRender();
        return;
    }
    const b = e.target.closest('#awRail .awr-i');
    if (!b) return;
    const L = WLISTS.find((x) => String(x.id) === String(b.dataset.wl));
    if (L) wlOpen(L);
});

/* смужка під рядком: що саме зараз відкрито — список чи панель «Огляду» */
function awCurShow() {
    const box = $('awCurName');
    if (!box) return;
    const cur = WCUR || OV_CUR;
    // смужку НЕ ховаємо: її висота зарезервована в .aw-status, інакше поява
    // назви списку зсувала б рейку й таблицю вниз (Роман 2026-09-22)
    box.innerHTML = cur
        ? (WCUR ? 'Список ' : 'Панель ') + `<b>${escapeHtml(cur.name)}</b>`
        : '';
}

function wlOpen(L) {
    $('awInput').value = awNoEq(L.formula);
    try { localStorage.setItem(AW_KEY, L.formula); } catch (e) { /* ignore */ }
    wlSetCur(L);
    setTab('work');
    awPaint();
}

/* ---------- вкладки: Огляд / Робота зі стадом / Списки ---------- */
/* ═══════════ ІСТОРІЯ: що робили на фермі ═══════════
   Роман 2026-09-23: «в історії фіксувати гарно, наглядно послідовні рухи.
   Там буде дата. І що робили — наприклад, внесли 10 тварин браку. І щоб
   можна було навести на панельку і висвітилась інформація. Щоб було
   візуальне ділення на дати: що сьогодні, що вчора, що позавчора».

   📌 Вісь стрічки — КОЛИ ВНЕСЛИ (created_at), а не коли подія сталась:
   питання «що сьогодні робили» саме про роботу. Якщо дата події інша,
   кажемо про це прямо в картці («за 14.09»), щоб не збрехати. */
let HS = [], HS_DEPTH = 30;

const hsDmy = (d) => (d && d.length >= 10
    ? `${d.slice(8, 10)}.${d.slice(5, 7)}.${d.slice(0, 4)}` : (d || ''));

/* «Сьогодні · Вчора · Позавчора», далі — датою з днем тижня. */
const HS_WDAY = ['неділя', 'понеділок', 'вівторок', 'середа', 'четвер',
    'пʼятниця', 'субота'];
function hsDayLabel(iso) {
    const t = new Date(); t.setHours(0, 0, 0, 0);
    const d = new Date(iso + 'T00:00:00');
    const days = Math.round((t - d) / 86400000);
    if (days === 0) return { name: 'Сьогодні', sub: hsDmy(iso) };
    if (days === 1) return { name: 'Вчора', sub: hsDmy(iso) };
    if (days === 2) return { name: 'Позавчора', sub: hsDmy(iso) };
    return { name: hsDmy(iso), sub: HS_WDAY[d.getDay()] || '' };
}

/* Події → дні → дії. Дія = групове внесення (спільний batch_id) або одна
   подія. Усередині дня новіші зверху. */
function hsGroup(rows) {
    const by = new Map();
    rows.forEach((e) => {
        const cr = String(e.created_at || '');
        const day = cr.slice(0, 10);
        if (!day) return;
        // ключ дії: номер пакета, а для давньої історії — той самий відбиток,
        // що й у журналі подій (подія + дата + автор + секунда внесення)
        const k = e.batch_id
            ? 'b|' + e.batch_id
            : [e.event_def_id || e.event_type || '', (e.event_date || '').slice(0, 10),
                e.user_id || '', cr.slice(0, 19)].join('|');
        if (!by.has(day)) by.set(day, new Map());
        const acts = by.get(day);
        if (!acts.has(k)) acts.set(k, []);
        acts.get(k).push(e);
    });
    const out = [];
    [...by.keys()].sort().reverse().forEach((day) => {
        const acts = [...by.get(day).values()]
            .sort((a, b) => String(b[0].created_at || '')
                .localeCompare(String(a[0].created_at || '')));
        out.push({ day, label: hsDayLabel(day), acts });
    });
    return out;
}

/* Зведення однієї дії — те, що видно на картці. */
function hsAct(list) {
    const e = list[0];
    const same = (f) => (list.every((x) => (x[f] || '') === (e[f] || '')) ? (e[f] || '') : '');
    const tags = list.map((x) => x.animal_tag).filter(Boolean)
        .sort((a, b) => String(a).localeCompare(String(b), 'uk', { numeric: true }));
    const cr = String(e.created_at || '');
    return {
        n: list.length,
        many: list.length > 1,
        time: cr.length >= 16 ? cr.slice(11, 16) : '',
        name: e.event_type || '',
        cat: e.category || 'other',
        user: e.user_name || '',
        // дата САМОЇ події — показуємо, лише якщо вона не збігається з днем внесення
        evDay: (e.event_date || '').slice(0, 10) !== cr.slice(0, 10)
            ? (e.event_date || '').slice(0, 10) : '',
        group: same('group_name'),
        // деталі пакета — СПІЛЬНІ частини, а не лише повний збіг: в осіменінні
        // плідник і спосіб однакові, а «номер ос.» у кожної свій, і вимога
        // збігу цілого рядка лишала б стрічку без найголовнішого
        details: (() => {
            const parts = (x) => String(x.details || '').split(' · ').filter(Boolean);
            return parts(e).filter((q) => list.every((x) => parts(x).includes(q)))
                .join(' · ');
        })(),
        note: same('note'),
        tags,
        // секції з кількостями: «Група-4 — 6 гол. · Мастит — 4 гол.»
        groups: (() => {
            const m = new Map();
            list.forEach((x) => {
                const g = x.group_name || '—';
                m.set(g, (m.get(g) || 0) + 1);
            });
            return [...m.entries()];
        })(),
        day: cr.slice(0, 10),
        ids: list.map((x) => x.id).join(','),
        bid: String(e.batch_id || ''),
    };
}

/* Українська кількість: 1 подія · 2 події · 5 подій. */
function hsPl(n, one, few, many) {
    const a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b === 1) return one;
    if (b >= 2 && b <= 4) return few;
    return many;
}

/* ── малювання стрічки ──
   Рядок = ОДНЕ внесення (групове або одна подія), а не одна тварина: Роман
   просив бачити «внесли 10 тварин браку», а не десять однакових рядків.
   Це СІТКА, не таблиця: колонки задані раз на контейнері, тож розкриті
   пакети й роздільники днів не воюють із colspan (урок 2.39.49). */
let HS_ACTS = [];

function hsDet(a, e) {
    const out = [];
    // дата події ≠ день внесення — кажемо прямо, інакше стрічка бреше
    if (a.evDay) out.push(`<span class="hx-back">за ${hsDmy(a.evDay).slice(0, 5)}</span>`);
    if (a.many) {
        const show = a.tags.slice(0, 5).map((t) => escapeHtml(t)).join(' · ');
        out.push(show + (a.tags.length > 5
            ? ` <i>і ще ${a.tags.length - 5}</i>` : ''));
    } else if (e.animal_name) {
        out.push(escapeHtml(e.animal_name));
    }
    const d = String(a.details || '').trim();
    if (d) out.push((out.length ? '— ' : '') + escapeHtml(d));
    else if (a.note) out.push((out.length ? '— ' : '') + escapeHtml(a.note));
    return out.join(' ');
}

function hsRow(a, e, i, alt) {
    const cat = escapeHtml(a.cat || 'other');
    const num = a.many
        ? `<b>${a.n}</b> ${hsPl(a.n, 'голова', 'голови', 'голів')}`
        : escapeHtml(e.animal_tag || '');
    return `<div class="hx-row ev-c-${cat}${a.many ? ' is-batch' : ''}${alt ? ' is-alt' : ''}"`
        + ` data-i="${i}" tabindex="0"${a.many ? ' role="button" aria-expanded="false"' : ''}>`
        + `<span class="hx-time">${escapeHtml(a.time)}</span>`
        + '<span class="hx-cat" aria-hidden="true"></span>'
        + `<span class="hx-ev" title="${escapeHtml(a.name)}">${escapeHtml(a.name)}</span>`
        + `<span class="hx-n">${num}</span>`
        + `<span class="hx-det">${hsDet(a, e)}</span>`
        + `<span class="hx-who">${escapeHtml(a.user)}</span>`
        + `<span class="hx-more" aria-hidden="true">${a.many ? '▸' : ''}</span></div>`;
}

/* Скільки внесень показуємо за день одразу. Звичайний день на фермі — це
   кілька внесень; сотні бувають лише в дні перенесення історії (дзеркало
   ОРСЕКу 21–22.09), і тоді вони затопили б стрічку. Решта — за кнопкою,
   з чесним числом. */
const HS_DAY_MAX = 40;
const HS_SHOWN = new Set();

function hsRender() {
    const box = $('hsFeed');
    if (!box) return;
    const days = hsGroup(HS);
    HS_ACTS = [];
    if (!days.length) {
        box.innerHTML = '<div class="hp-empty">За цей час нічого не вносили</div>';
        if ($('hsCount')) $('hsCount').textContent = '';
        return;
    }
    let nAct = 0, nEv = 0;
    const html = days.map((d) => {
        const de = d.acts.reduce((s, l) => s + l.length, 0);
        const all = HS_SHOWN.has(d.day) || d.acts.length <= HS_DAY_MAX;
        const acts = all ? d.acts : d.acts.slice(0, HS_DAY_MAX);
        const rows = acts.map((list, k) => {
            const a = hsAct(list);
            const i = HS_ACTS.push({ a, list }) - 1;
            return hsRow(a, list[0], i, k % 2 === 1);
        }).join('');
        nAct += d.acts.length; nEv += de;
        const sum = `${d.acts.length} ${hsPl(d.acts.length, 'внесення', 'внесення', 'внесень')}`
            + ` · ${de} ${hsPl(de, 'подія', 'події', 'подій')}`;
        const rest = d.acts.length - acts.length;
        const more = rest > 0
            ? `<button type="button" class="hx-all" data-day="${escapeHtml(d.day)}">`
                + `Показати решту — ще ${rest} ${hsPl(rest, 'внесення', 'внесення', 'внесень')}</button>`
            : '';
        return `<div class="hx-day"><b>${escapeHtml(d.label.name)}</b>`
            + `<span>${escapeHtml(d.label.sub)}</span>`
            + `<span class="sum">${sum}</span></div>${rows}${more}`;
    }).join('');
    box.innerHTML = html;
    if ($('hsCount')) {
        // межу читання називаємо вголос, інакше «за три місяці» тихо показувало б
        // не всі дні, а людина думала б, що їх і не було
        const cut = HS.length >= 1000 ? ' · показано останні 1000 подій' : '';
        $('hsCount').textContent = `${nAct} ${hsPl(nAct, 'внесення', 'внесення', 'внесень')}`
            + ` · ${nEv} ${hsPl(nEv, 'подія', 'події', 'подій')}`
            + ` · ${days.length} ${hsPl(days.length, 'день', 'дні', 'днів')}${cut}`;
    }
}

/* Розкритий пакет — тварини підсписком ЗЛІВА, без вирівнювання по колонках
   стрічки: у них інший зміст (той самий висновок, що в журналі 2.39.53). */
function hsKids(rec) {
    const L = [...rec.list].sort((x, y) => String(x.animal_tag || '')
        .localeCompare(String(y.animal_tag || ''), 'uk', { numeric: true }));
    const items = L.map((e, n) => {
        const html = e.details_html || '';
        let d;
        if (html.includes('<')) d = html;
        else {
            // жирність через одну — як у журналі подій
            d = String(e.details || '').split(' · ').filter((x) => x !== '')
                .map((x, k) => (k % 2 ? escapeHtml(x) : `<b>${escapeHtml(x)}</b>`))
                .join(' · ');
        }
        if (!d && e.note) d = escapeHtml(e.note);
        return `<div class="hx-kid${n % 2 ? ' is-alt' : ''}">`
            + `<span class="k-n">${n + 1}</span>`
            + `<a class="k-tag" href="/herd/animals/${e.animal_id}">${escapeHtml(e.animal_tag || '')}</a>`
            + `<span class="k-nm">${escapeHtml(e.animal_name || '')}</span>`
            + `<span class="k-d">${d}</span></div>`;
    }).join('');
    return `<div class="hx-kids">${items}</div>`;
}

function hsToggle(row) {
    // розкрили пакет — підказка більше не потрібна: вона стоїть під рядком і
    // накрила б щойно відкритий перелік. HX_ROW лишаємо, щоб вона не
    // вискочила знову від руху миші в межах того самого рядка.
    const pop = $('hxPop');
    if (pop) pop.classList.remove('on');
    const nx = row.nextElementSibling;
    if (nx && nx.classList.contains('hx-kids')) {
        nx.remove();
        row.classList.remove('is-open');
        row.setAttribute('aria-expanded', 'false');
        return;
    }
    const rec = HS_ACTS[+row.dataset.i];
    if (!rec) return;
    row.insertAdjacentHTML('afterend', hsKids(rec));
    row.classList.add('is-open');
    row.setAttribute('aria-expanded', 'true');
}

/* ── підказка при наведенні ──
   Одна коробка на сторінку, ПОЗА панеллю (`.panel{overflow:hidden}` зрізала б
   вкладену) і `position:fixed` — тим самим шляхом, що й підказки формули.
   Показуємо те, чого немає в рядку: ДВІ дати (їх і плутають), секції з
   кількостями, деталі, нотатку й перелік бирок. */
let HX_ROW = null;

function hxHtml(rec) {
    const a = rec.a, e = rec.list[0];
    const row = (t, v) => (v ? `<dt>${t}</dt><dd>${v}</dd>` : '');
    const head = a.many
        ? `групове · ${a.n} ${hsPl(a.n, 'голова', 'голови', 'голів')}`
            + (a.bid ? ` · внесення №${escapeHtml(a.bid)}` : '')
        : 'одинична подія';
    const secs = a.groups.map(([g, n]) => escapeHtml(g)
        + (a.many ? ` — ${n} ${hsPl(n, 'голова', 'голови', 'голів')}` : '')).join(' · ');
    const tags = rec.list.length > 1
        ? [...rec.list].sort((x, y) => String(x.animal_tag || '')
            .localeCompare(String(y.animal_tag || ''), 'uk', { numeric: true }))
            .slice(0, 24)
            .map((x) => `<span>${escapeHtml(x.animal_tag || '')}`
                + `${x.animal_name ? ' ' + escapeHtml(x.animal_name) : ''}</span>`).join('')
        : '';
    const more = rec.list.length > 24
        ? `<span class="more">і ще ${rec.list.length - 24}</span>` : '';
    return `<div class="hx-pop-h"><b class="ev-c-${escapeHtml(a.cat || 'other')}">`
        + `${escapeHtml(a.name)}</b><span>${head}</span></div><dl>`
        + row('Подія відбулась', escapeHtml(hsDmy((e.event_date || '').slice(0, 10))))
        + row('Внесено', `${escapeHtml(hsDmy(a.day))}${a.time ? ', ' + escapeHtml(a.time) : ''}`
            + (a.user ? ' · ' + escapeHtml(a.user) : ''))
        + row(a.many ? 'Секції' : 'Секція', secs)
        + row('Деталі', escapeHtml(a.details || ''))
        + row('Нотатка', escapeHtml(a.note || ''))
        + '</dl>'
        + (tags ? `<div class="hx-tags">${tags}${more}</div>` : '')
        + (a.many ? '<p class="hx-go">Клік — розкрити перелік тварин</p>' : '');
}

function hxPlace(pop, row, ev) {
    const pad = 12, r = row.getBoundingClientRect();
    const w = pop.offsetWidth, h = pop.offsetHeight;
    let x = (ev && ev.clientX) ? ev.clientX + 16 : r.left + 48;
    let y = r.bottom + 6;
    if (x + w + pad > window.innerWidth) x = Math.max(pad, window.innerWidth - w - pad);
    if (y + h + pad > window.innerHeight) y = Math.max(pad, r.top - h - 6);
    pop.style.left = `${Math.round(x)}px`;
    pop.style.top = `${Math.round(y)}px`;
}

function hxShow(row, ev) {
    const pop = $('hxPop');
    if (!pop || HX_ROW === row) return;
    const rec = HS_ACTS[+row.dataset.i];
    if (!rec) return;
    HX_ROW = row;
    pop.innerHTML = hxHtml(rec);
    pop.hidden = false;
    // міряємо ОДИН раз на вході в рядок, не на кожен рух миші — інакше
    // на кількох сотнях рядків сторінка гальмує
    hxPlace(pop, row, ev);
    pop.classList.add('on');
}

function hxHide() {
    HX_ROW = null;
    const pop = $('hxPop');
    if (pop) pop.classList.remove('on');
}

async function hsLoad() {
    const box = $('hsFeed');
    if (!box) return;
    const to = new Date(); const from = new Date(to.getTime() - HS_DEPTH * 86400000);
    const iso = (d) => d.toISOString().slice(0, 10);
    box.innerHTML = '<div class="hp-empty">Читаю історію…</div>';
    const r = await apiGet(`/api/herd/events-log?limit=1000&order=created&cfrom=${iso(from)}&cto=${iso(to)}`);
    HS = (r && r.ok && r.events) ? r.events : [];
    hsRender();
}

function setTab(t) {
    TAB = ['work', 'lists', 'hist'].includes(t) ? t : 'reg';
    document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.tab === TAB));
    $('animWork').hidden = TAB !== 'work';
    $('animLists').hidden = TAB !== 'lists';
    $('animHist').hidden = TAB !== 'hist';
    $('animOver').hidden = TAB !== 'reg';       // «Огляд» — самі панелі-показники
    $('animFilters').hidden = true;             // добір живе у формулі, не в панелі фільтрів
    $('animStats').hidden = true;
    // таблиця тварин — лише у «Роботі зі стадом»
    $('animTableWrap').hidden = TAB !== 'work';
    // рядок формули переїхав усередину .aw-split (поруч із рейкою), тож
    // ховати треба й саму обгортку — інакше на «Огляді» лишався б рядок
    const sp = $('awSplit');
    if (sp) sp.hidden = TAB !== 'work';
    if (TAB !== 'work') awCfgClose();       // пішли з вкладки — коробка не висить
    // лічильник не ЗНИКАЄ, а ховається: місце лишається за ним, інакше
    // вкладки їдуть убік при кожній зміні вкладки (Роман 2026-09-22)
    $('animCount').classList.toggle('is-off', TAB !== 'work');
    // «⚙ Колонки» — про реєстр; у «Роботі зі стадом» колонки задає сама
    // формула (BODY), тож кнопка там нічого не робила й лише займала місце
    const cols = $('animCols');
    // кнопка не зникає, а гасне: інакше сусідні «Імпорт» і «№ Нумерація»
    // стрибали на 112 px при кожній зміні вкладки (Роман 2026-09-22)
    if (cols) cols.classList.toggle('is-off', TAB !== 'reg');
    railRender();
    try { sessionStorage.setItem('herd:anim_tab', TAB); } catch (e) { /* ignore */ }
    if (TAB === 'work') {
        runFormula();
        // списки могли бути ще не прочитані — рейка без них порожня
        (WLISTS.length ? Promise.resolve() : wlLoad()).then(() => {
            railRender();
            railCounts();
        });
    } else if (TAB === 'lists') wlLoad();
    else if (TAB === 'hist') hsLoad();
    else { Q = null; ovLoad(); }
}

/* ---------- «Огляд»: налаштовані панелі-показники ----------
   Панель — назва + формула добору (та сама мова, що в «Роботі зі стадом»).
   Роман 2026-09-18: «прибрати реєстр і зробити налаштовані панелі». */
let OV = [], OV_ITEMS = [], OV_EDIT = null, OV_CUR = null, SAVE_WHERE = 'list';
let OV_COLOR = '', OV_BG = '', OV_EDGE = '', OV_LAST = {};
/* Палітри (Роман 2026-09-19: «для шрифту, фону — палітри»): 15 тонів × 5
   кроків світлоти + сірі. Для шрифту й канта — насичені, для фону — світлі. */
const OV_HUES = [0, 15, 30, 45, 60, 90, 130, 160, 185, 205, 225, 255, 285, 315, 340];
function hslHex(h, s, l) {
    s /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return '#' + [f(0), f(8), f(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}
const OV_PAL_INK = [].concat(
    ...[28, 38, 48, 58, 68].map((l) => OV_HUES.map((h) => hslHex(h, 70, l))),
    [10, 25, 40, 55, 70, 80].map((l) => hslHex(215, 12, l)));
const OV_PAL_BG = [].concat(
    ...[97, 93, 89, 84, 78].map((l) => OV_HUES.map((h) => hslHex(h, 70, l))),
    [98, 95, 92, 88, 84, 80].map((l) => hslHex(215, 14, l)));
// ранні коди фону: основні кольори показувались блідим тоном — лишаємо їх блідими
const OV_BG_OLD = { '#2f5fb0': '#e3ebf7', '#1aa86b': '#e1f4ea', '#7c3aed': '#ece3fc',
    '#b45309': '#f6e8dc', '#0e7490': '#dcedf1', '#e5484d': '#fbe2e3', '#5b7083': '#e6e9ed',
    '#f5f8fd': '#f5f8fd', '#f4fbf7': '#f4fbf7', '#f8f6fd': '#f8f6fd', '#fdf9f3': '#fdf9f3',
    '#f2f9fb': '#f2f9fb', '#fdecec': '#fdecec', '#f7f8fa': '#f7f8fa' };
const ovBgOf = (c) => OV_BG_OLD[c] || c;
const ovTint = (c) => (c ? ovBgOf(c) : '');

const OV_CACHE = 'herd:ov_cache';

async function ovLoad() {
    // торішні числа з памʼяті браузера — щоб панелі були видні одразу,
    // а не спалахували порожнечею, поки читаються дані (Роман 2026-09-18)
    if (!OV.length) {
        try {
            const c = JSON.parse(localStorage.getItem(OV_CACHE) || 'null');
            if (c && Array.isArray(c.tiles) && c.tiles.length) {
                OV = c.tiles;
                OV_LAST = c.counts || {};
                ovRender();
            }
        } catch (e) { /* ignore */ }
    }
    const r = await apiGet('/api/herd/overview-tiles');
    OV = (r && r.tiles) || [];
    ovRender();                                  // спершу назви, числа — після читання
    if (COLS === null) await loadColumns();
    const keys = new Set();
    OV.forEach((t) => {
        (splitRatio(t.formula) || [t.formula]).forEach((f) => {
            const q = window.herdQuery.parse(f, PARAMS);
            if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
        });
    });
    const p = new URLSearchParams();
    if (keys.size) p.set('params', [...keys].join(','));
    p.set('lean', '1');
    p.set('status', 'active');            // панелі рахують тих, хто в стаді
    const a = await apiGet('/api/herd/animals?' + p.toString());
    OV_ITEMS = (a && a.items) || [];
    if (a && a.groups) ALL_GROUPS = a.groups;
    ovRender();
    try {                                        // запамʼятовуємо на наступний вхід
        const counts = {};
        OV.forEach((t) => {
            const n = ovCount(t);
            if (n && typeof n === 'object') counts[t.id] = n;
        });
        OV_LAST = counts;
        localStorage.setItem(OV_CACHE, JSON.stringify({ tiles: OV, counts }));
    } catch (e) { /* ignore */ }
}

/* Число панелі: кількість тих, хто пройшов FILTER, або — якщо у формулі є
   VIEW(avg|sum|min|max <параметр>) — середнє/сума/мін/макс серед них
   (Роман 2026-09-19: «якісні показники» — середній надій, середні дні лактації…).
   Повертає число, {txt} для показника або рядок із помилкою формули. */
/* «A / B» — частка (Роман 2026-09-19): дві формули через «/» поза дужками,
   напр. FILTER(lact>0 rc>=5) / FILTER(lact>0) — частка тільних серед фуражних.
   Повертає [чисельник, знаменник] або null. «/» у назвах (milk/lkd) — у дужках. */
function splitRatio(text) {
    const src = String(text || '').replace(/^\s*=/, '');
    let depth = 0;
    for (let i = 0; i < src.length; i++) {
        const c = src[i];
        if (c === '(') depth += 1;
        else if (c === ')') depth -= 1;
        else if (c === '/' && depth === 0) {
            const a = src.slice(0, i).trim(), b = src.slice(i + 1).trim();
            return a && b ? ['=' + a, '=' + b] : null;
        }
    }
    return null;
}
/* значення однієї формули: кількість відібраних або avg/sum/min/max */
function metricOf(q, items) {
    const rows = items.filter((a) => window.herdQuery.passes(a, q.filters));
    const ag = (q.aggs || []).find((x) => x.fn !== 'cnt' || x.key);
    if (!ag) return { v: rows.length, auto: 0, cnt: true };
    const v = aggValue(ag, rows);
    return { v, auto: ag.fn === 'avg' || (v !== null && !Number.isInteger(v)) ? 1 : 0, cnt: false };
}
/* частка двох формул: кількість / кількість — у відсотках, інакше — просте ділення */
function ratioOf(qa, qb, items) {
    const a = metricOf(qa, items), b = metricOf(qb, items);
    const pct = a.cnt && b.cnt;
    const v = (a.v === null || !b.v) ? null : (a.v / b.v) * (pct ? 100 : 1);
    return { v, auto: pct ? 1 : 2, pct, a: a.v, b: b.v };
}

function ovCount(t) {
    if (!OV_ITEMS.length) return null;
    const rp = splitRatio(t.formula);
    if (rp) {
        const qa = window.herdQuery.parse(rp[0], PARAMS);
        const qb = window.herdQuery.parse(rp[1], PARAMS);
        if (qa.error || qb.error) return qa.error || qb.error;
        return ratioOf(qa, qb, OV_ITEMS);
    }
    const q = window.herdQuery.parse(t.formula, PARAMS);
    if (q.error) return q.error;
    const m = metricOf(q, OV_ITEMS);
    return { v: m.v, auto: m.auto };
}
/* показ числа панелі за її форматом: знаків після коми («як є» — ціле для
   кількості, 0,0 для середнього) і пробіл між тисячами (Роман 2026-09-19) */
function ovShow(n, t) {
    if (typeof n === 'number') n = { v: n, auto: 0 };      // старий запис у памʼяті
    if (!n || typeof n !== 'object') return n;
    if (n.v === null || n.v === undefined) return '—';
    const dec = (t && t.dec !== undefined && t.dec !== '') ? Number(t.dec) : n.auto;
    return Number(n.v).toLocaleString('uk-UA', { minimumFractionDigits: dec,
        maximumFractionDigits: dec, useGrouping: !(t && t.sep === false) }) + (n.pct ? ' %' : '');
}

function ovRender() {
    const box = $('ovGrid');
    if (!box) return;
    if (!OV.length) {
        box.innerHTML = '<div class="ov-hint">Панелей ще немає — натисніть «+ Панель».</div>';
        return;
    }
    const tileHtml = (t) => {
        let n = ovCount(t);
        if (n === null && OV_LAST[t.id] !== undefined) n = OV_LAST[t.id];   // поки читаємо
        const bad = typeof n === 'string';
        n = ovShow(n, t);
        // чорний шрифт у темній темі стає світлим (інакше не видно)
        const ink = (c) => (c === '#101418' ? 'var(--ov-ink)' : escapeHtml(c));
        const st = (t.color ? `--sp:${ink(t.color)};` : '')
            + (t.edge ? `--edge:${ink(t.edge)};` : '')
            + (t.bg ? `--spbg:${ovTint(escapeHtml(t.bg))};` : '');
        const c = st ? ` style="${st}"` : '';
        return `<div class="ov-tile" draggable="true" data-id="${escapeHtml(t.id)}"
                data-sec="${escapeHtml(t.section || '')}"${c}
                data-fx="${escapeHtml(t.formula)}">
            <b>${bad ? '—' : (n === null ? '…' : n)}</b>
            <span>${escapeHtml(t.name)}</span>
            <span class="ov-acts">
                <button type="button" data-act="edit" title="Змінити">✎</button>
                <button type="button" data-act="del" title="Прибрати">✕</button>
            </span>
        </div>`;
    };
    // розділи — смугами, у порядку першої появи; без розділу йдуть першими
    const secs = [];
    OV.forEach((t) => {
        const k = (t.section || '').trim();
        let g = secs.find((x) => x.k === k);
        if (!g) { g = { k, list: [] }; secs.push(g); }
        g.list.push(t);
    });
    box.innerHTML = secs.map((g) =>
        (g.k ? `<div class="ov-sec">${escapeHtml(g.k)}</div>` : '')
        + g.list.map(tileHtml).join('')).join('');
    // розділи, які вже є — у підказку поля
    const dl = $('ovSections');
    if (dl) dl.innerHTML = [...new Set(OV.map((t) => (t.section || '').trim()).filter(Boolean))]
        .map((k) => `<option value="${escapeHtml(k)}">`).join('');
}

function ovPaintColors() {
    const cur = { color: OV_COLOR, edge: OV_EDGE, bg: OV_BG };
    document.querySelectorAll('.ov-sw').forEach((b) => {
        const v = cur[b.dataset.for];
        const dflt = b.dataset.for === 'color' ? 'var(--text)'
            : (b.dataset.for === 'edge' ? 'var(--primary)' : 'var(--surface)');
        b.style.background = v ? (b.dataset.for === 'bg' ? ovBgOf(v) : v) : dflt;
    });
}

/* спливна палітра біля зразка */
let OV_PAL_FOR = '';
function ovPalOpen(btn) {
    const box = $('ovPal');
    if (!box) return;
    if (box.parentElement !== document.body) document.body.appendChild(box);
    OV_PAL_FOR = btn.dataset.for;
    const list = OV_PAL_FOR === 'bg' ? OV_PAL_BG : OV_PAL_INK;
    const cur = { color: OV_COLOR, edge: OV_EDGE, bg: ovBgOf(OV_BG) }[OV_PAL_FOR] || '';
    const none = { color: 'звичайний', edge: 'колір гілки', bg: 'без фону' }[OV_PAL_FOR];
    box.innerHTML = `<div class="ov-pal-top">
            <button type="button" class="ov-pal-none" data-pc="">${none}</button>
            <label>свій колір <input type="color" id="ovPalCustom"
                value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#808080'}"></label>
        </div>
        <div class="ov-pal-grid">${list.map((c) =>
            `<button type="button" data-pc="${c}" style="background:${c}"
                ${c.toLowerCase() === cur.toLowerCase() ? 'class="on"' : ''}></button>`).join('')}</div>`;
    box.hidden = false;
    const r = btn.getBoundingClientRect();
    const w = box.offsetWidth, h = box.offsetHeight;
    box.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - w - 8))}px`;
    box.style.top = `${(r.bottom + 6 + h < window.innerHeight) ? r.bottom + 6 : Math.max(8, r.top - h - 6)}px`;
}
function ovPalSet(c) {
    if (OV_PAL_FOR === 'color') OV_COLOR = c;
    else if (OV_PAL_FOR === 'edge') OV_EDGE = c;
    else if (OV_PAL_FOR === 'bg') OV_BG = c;
    ovPaintColors();
}

async function ovSave() {
    const r = await apiSend('/api/herd/overview-tiles', 'POST', { tiles: OV });
    if (!r || r.ok === false) { toast((r && r.error) || 'Не збереглося', 'error'); return false; }
    OV = r.tiles || OV;
    await ovLoad();          // нова панель могла спитати параметр, якого ще не читали
    return true;
}

function awHelpHtml() {
    return '<h4>Як писати</h4>'
        + '<p>Рядок складається з трьох частин — як налаштування списку в календарі: '
        + '<b>BODY</b> (тіло — які параметри показати), <b>FILTER</b> (фільтрація — кого брати), '
        + '<b>VIEW</b> (відображення — як показати). Усередині дужок пишемо через пробіл, '
        + 'параметри — короткими назвами.</p>'
        + '<p><code>=BODY(name group dslh)</code> — колонки таблиці. Без BODY таблиці немає: '
        + 'видно лише, скільки знайдено, і показники з VIEW (avg, sum…).</p>'
        + '<p><code>FILTER(dslh&gt;=35 rc=4)</code> — добір. Умови: '
        + '<code>=</code> <code>&lt;&gt;</code> <code>&gt;</code> <code>&gt;=</code> '
        + '<code>&lt;</code> <code>&lt;=</code>, ще <code>dslh between 28 35</code>, '
        + '<code>name contains Рай</code>, <code>name empty</code> (порожньо), '
        + '<code>name notempty</code> (є значення), '
        + '<code>group=Група-1 or Група-2</code>.</p>'
        + '<p><code>VIEW(no groupby group sort dslh desc avg dslh)</code> — '
        + '<code>no</code> колонка № з/п, <code>groupby &lt;параметр&gt;</code> групи, '
        + '<code>sort &lt;параметр&gt; desc</code> порядок (а <code>groupby group desc</code> '
        + 'перевертає самі групи), '
        + '<code>cnt</code> кількість (сама по собі — голів, з назвою параметра — '
        + 'скільки тварин мають це значення), <code>avg</code> середнє, <code>sum</code> сума, '
        + '<code>min</code> найменше, <code>max</code> найбільше. '
        + 'Числа стають у своїх колонках — у рядку групи й у рядку «Разом»; '
        + 'на одну колонку можна поставити кілька агрегацій, вони стануть поруч. '
        + 'Ширину колонки тягніть за межу заголовка — вона памʼятається. '
        + '«🖨 Друк» — попередній перегляд на A4, як у календарі: аркуш, колонки, '
        + 'шрифт і його розмір.</p>'
        + '<p>Підказка вискакує сама: стрілки <b>↑↓</b> — вибрати, <b>Tab</b> — підтвердити, '
        + '<b>Esc</b> — закрити. <b>Enter</b> — прочитати список за формулою (окремої кнопки немає).</p>'
        + '<p>Після Enter рядок сам набуває акуратного вигляду: дії великими літерами, '
        + 'параметри — короткими назвами, зайві пробіли й коми прибираються.</p>'
        + '<p>Частини пишуться в один рядок одна за одною; будь-яку можна пропустити. '
        + 'Українські слова (ТІЛО, ФІЛЬТРАЦІЯ, ВІДОБРАЖЕННЯ, групувати, сортувати, спад, між, '
        + 'містить, порожньо, або) теж працюють — після Enter рядок переписується англійською.</p>';
}

function awWordsHtml() {
    const bySec = {};
    PARAMS.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    return '<h4>Параметри з конструктора</h4>'
        + Object.keys(bySec).map((sec) => `<div class="aw-sec"><h4>${escapeHtml(sec)}</h4>`
            + '<div class="aw-words">'
            + bySec[sec].map((p) => `<button type="button" data-w="${escapeHtml(awShort(p))}"`
                + ` title="${escapeHtml(p.label)}">${escapeHtml(awShort(p))}</button>`).join('')
            + '</div></div>').join('');
}

/* коротка назва параметра — нею й пишемо у формулі */
function awShort(p) { return (p.short || p.key || '').trim() || p.label; }

/* кольорова підсвітка формули — herdQuery.highlight (herd_query.js) */

/* розфарбований HTML формули — той самий вигляд у рядку й у «Списках» */
function awHlHtml(txt) {
    return window.herdQuery.highlight(txt, PARAMS);   // спільна з Календарем
}

function awPaint() {
    const hl = $('awHl');
    if (!hl) return;
    const txt = $('awInput').value;
    hl.innerHTML = awHlHtml(txt);
    hl.scrollLeft = $('awInput').scrollLeft;
    if ($('awClear')) $('awClear').hidden = !txt;
}

/* ── підказки під час набору ──────────────────────────────────────────
   Роман 2026-09-18: «немає підказок при вводі». Підказуємо дію, слово
   всередині ВІДОБРАЖЕННЯ і короткі назви параметрів після «[». */
const AW_ACTS = [
    { w: 'BODY', t: 'тіло — які параметри показати' },
    { w: 'FILTER', t: 'фільтрація — кого брати' },
    { w: 'VIEW', t: 'відображення — групи й порядок' },
];
const AW_DISP = [
    { w: 'groupby', t: 'групувати — групи в таблиці' },
    { w: 'sort', t: 'сортувати — порядок рядків' },
    { w: 'no', t: 'нумерація — колонка № з/п' },
    { w: 'cnt', t: 'кількість — усіх або з даними в параметрі' },
    { w: 'avg', t: 'середнє по числовому параметру' },
    { w: 'sum', t: 'сума по числовому параметру' },
    { w: 'min', t: 'найменше значення' },
    { w: 'max', t: 'найбільше значення' },
    { w: 'desc', t: 'спад — від більшого до меншого' },
];
const AW_COND = [
    { w: '=', t: 'дорівнює' }, { w: '>', t: 'більше' }, { w: '<', t: 'менше' },
    { w: '>=', t: 'більше або дорівнює' }, { w: '<=', t: 'менше або дорівнює' },
    { w: '<>', t: 'не дорівнює' }, { w: 'between', t: 'між: between 200 260' },
    { w: 'contains', t: 'містить частину тексту' }, { w: 'empty', t: 'порожньо — значення немає' },
    { w: 'notempty', t: 'не порожньо — значення є' }, { w: 'or', t: 'або — кілька значень' },
];
let AW_SUG = [], AW_POS = 0, AW_FROM = 0, AW_NAV = false;

/* яка дія відкрита в місці курсора */
function awContext(txt) {
    let open = null, depth = 0;
    const re = /([\p{L}]+)\s*\(|\)/gu;
    let m;
    while ((m = re.exec(txt))) {
        if (m[0] === ')') { depth = Math.max(0, depth - 1); if (!depth) open = null; }
        else { depth += 1; open = (m[1] || '').toLowerCase(); }
    }
    return depth ? open : null;
}

function awParamItems(word, close, only) {
    const w = (word || '').toLowerCase();
    const starts = (x) => String(x || '').toLowerCase().startsWith(w);
    return PARAMS.filter((p) => (!only || only(p)) && (!w || starts(awShort(p)) || starts(p.key)
        || (p.label || '').toLowerCase().includes(w)))
        .sort((a, b) => (Number(!starts(awShort(a))) - Number(!starts(awShort(b))))
            || (awShort(a).length - awShort(b).length))
        .map((p) => ({ ins: awShort(p) + (close ? '] ' : ' '), w: awShort(p), t: p.label, k: 'p' }));
}

/* значення параметра для умови: коди з назвами, секції, стать */
function awValueItems(p, word) {
    const w = (word || '').toLowerCase();
    let list = [];
    if (p.key === 'group') list = ALL_GROUPS.map((g) => ({ v: g.name, l: '' }));
    else list = (p.choices || []).map((c) => ({ v: String(c.value), l: String(c.label || '') }));
    return list.filter((x) => !w || x.v.toLowerCase().startsWith(w) || x.l.toLowerCase().includes(w))
        // значення з пробілом — у квадратних дужках, інакше формула розірветься
        .map((x) => ({ ins: (/\s/.test(x.v) ? `[${x.v}]` : x.v) + ' ', w: x.v,
            t: x.l && x.l !== x.v ? x.l : '', k: 'v' }));
}

const AW_NUM = (p) => ['int', 'float', 'number'].includes(p.dtype);
const AW_TOK = '([\\p{L}\\d_./№]+|\\[[^\\]]+\\])';

function awSuggest() {
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    const left = el.value.slice(0, at);
    const inBr = left.lastIndexOf('[') > left.lastIndexOf(']');
    const findP = (tok) => window.herdQuery.findParam(tok, PARAMS);
    let items = [];
    if (inBr) {                                   // назва параметра в дужках
        AW_FROM = left.lastIndexOf('[') + 1;
        items = awParamItems(left.slice(AW_FROM), true);
    } else {
        const m = left.match(/[\p{L}\d_./№]*$/u);
        const word = m ? m[0] : '';
        AW_FROM = at - word.length;
        const ctx = awContext(left);
        const lw = word.toLowerCase();
        if (!ctx) {                               // поза дужками — дія
            items = AW_ACTS.filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                .map((x) => ({ ins: x.w + '(', w: x.w + '(', t: x.t, k: 'a' }));
        } else if (['view', 'відображення', 'вигляд'].includes(ctx)) {
            const agg = left.match(new RegExp('\\b(avg|sum|min|max|середнє|сума|мін|макс)\\s+' + '([\\p{L}\\d_./]*)$', 'iu'));
            const grp = left.match(/\b(groupby|sort|cnt|count|групувати|сортувати)\s+([\p{L}\d_./]*)$/iu);
            if (agg) items = awParamItems(word, false, AW_NUM);           // лише числові
            else if (grp) items = awParamItems(word, false);
            else {
                const sortDone = left.match(/\bsort\s+\S+\s+([\p{L}]*)$/iu);
                const dirs = sortDone ? [{ w: 'desc', t: 'спад — від більшого до меншого' },
                    { w: 'asc', t: 'зростання' }] : [];
                items = dirs.concat(AW_DISP).filter((x) => !lw || x.w.toLowerCase().startsWith(lw))
                    .map((x) => ({ ins: x.w + ' ', w: x.w, t: x.t, k: 'w' }))
                    .concat(lw ? awParamItems(word, false) : []);
            }
        } else if (['filter', 'фільтрація', 'фільтр', 'де'].includes(ctx)) {
            // значення: «rc=», «group=Група-1 or »
            const vm = left.match(new RegExp(AW_TOK + '\\s*(=|<>|!=|>=|<=|>|<)\\s*'
                + '((?:[^\\s()]+\\s+(?:or|або)\\s+)*)([^\\s()]*)$', 'u'));
            // умова: одразу після назви параметра
            const cm = left.match(new RegExp(AW_TOK + '\\s+([\\p{L}]*)$', 'u'));
            const vp = vm ? findP(vm[1]) : null;
            if (vp) {
                AW_FROM = at - vm[4].length;
                items = awValueItems(vp, vm[4]);
            } else if (cm && findP(cm[1]) && !/^(between|між|contains|містить)$/i.test(cm[1])) {
                const cw = cm[2].toLowerCase();
                items = AW_COND.filter((x) => !cw || x.w.toLowerCase().startsWith(cw))
                    .map((x) => ({ ins: x.w + (/^[<>=]/.test(x.w) ? '' : ' '), w: x.w, t: x.t, k: 'w' }));
                if (cw) items = items.concat(awParamItems(cm[2], false));
            } else if (/[<>=]$/.test(left.trimEnd())) {
                items = [];
            } else {
                items = awParamItems(word, false);
            }
        } else {
            items = awParamItems(word, false);
        }
    }
    AW_SUG = items.slice(0, 40);
    AW_POS = 0;
    AW_NAV = false;
    awDrawSug();
}

/* підказка — під курсором, поверх сторінки (панель має transform) */
function awPlaceSug() {
    const box = $('awSug'), el = $('awInput');
    if (!box || !el || box.hidden) return;
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    const cv = awPlaceSug.cv || (awPlaceSug.cv = document.createElement('canvas'));
    const g = cv.getContext('2d');
    g.font = `${cs.fontSize} ${cs.fontFamily}`;
    // рядок може переноситись: рахуємо лише останній візуальний рядок до курсора
    const x0 = r.left + parseFloat(cs.paddingLeft)
        + g.measureText(el.value.slice(0, AW_FROM)).width - el.scrollLeft;
    const w = box.offsetWidth;
    box.style.left = `${Math.round(Math.max(8, Math.min(x0, r.right - 40, window.innerWidth - w - 8)))}px`;
    box.style.width = '';
    const below = window.innerHeight - r.bottom - 10;
    const above = r.top - 10;
    const up = below < 140 && above > below;     // унизу тісно — відкриваємо вгору
    box.style.maxHeight = `${Math.min(320, Math.max(120, up ? above : below))}px`;
    box.style.top = up ? '' : `${Math.round(r.bottom + 4)}px`;
    box.style.bottom = up ? `${Math.round(window.innerHeight - r.top + 4)}px` : '';
}

/* опис у підказці: приклад після «:» — тими самими кольорами, що в рядку */
function awHintHtml(t) {
    const m = String(t || '').match(/^(.*?:\s)([A-Za-z=(\[].*)$/);
    return m ? escapeHtml(m[1]) + `<i class="aw-ex">${awHlHtml(m[2])}</i>` : escapeHtml(t || '');
}

function awDrawSug() {
    const box = $('awSug');
    if (!AW_SUG.length) { box.hidden = true; return; }
    box.innerHTML = AW_SUG.map((x, i) =>
        `<div data-i="${i}"${i === AW_POS ? ' class="on"' : ''}><b class="${x.k || ''}">${escapeHtml(x.w)}</b>`
        + `<span>${awHintHtml(x.t)}</span></div>`).join('')
        + '<div class="foot">↑↓ вибрати · Tab — вставити · Enter — прочитати список · Esc — закрити</div>';
    box.hidden = false;
    awPlaceSug();
}

function awTake(i) {
    const x = AW_SUG[i];
    if (!x) return;
    const el = $('awInput');
    const at = el.selectionStart === null ? el.value.length : el.selectionStart;
    el.value = el.value.slice(0, AW_FROM) + x.ins + el.value.slice(at);
    const pos = AW_FROM + x.ins.length;
    el.focus();
    el.selectionStart = el.selectionEnd = pos;
    $('awSug').hidden = true;
    AW_SUG = [];
    awPaint();
    awSuggest();
}

function awInsert(word) {
    const t = $('awInput');
    const at = t.selectionStart === null ? t.value.length : t.selectionStart;
    const before = t.value.slice(0, at), after = t.value.slice(at);
    t.value = before + '[' + word + ']' + after;
    t.focus();
    t.selectionStart = t.selectionEnd = (before + '[' + word + ']').length;
}

function runFormula() {
    const text = $('awInput').value.trim();
    try { localStorage.setItem(AW_KEY, text); } catch (e) { /* ignore */ }
    const msg = $('awMsg');
    // порожній рядок — стада не показуємо (Роман 2026-09-18)
    if (!text) {
        Q = null;
        msg.textContent = 'Наберіть формулу і натисніть Enter.';
        msg.classList.remove('bad');
        $('animTableWrap').hidden = true;
        $('animCount').classList.add('is-off');   // ховаємо НАПИС, місце лишаємо
        return;
    }
    // частка «A / B»: у таблиці — тварини чисельника, над нею — сама частка
    const rp = splitRatio(text);
    let qb = null;
    const q = window.herdQuery.parse(rp ? rp[0] : text, PARAMS);
    if (rp && !q.error) {
        qb = window.herdQuery.parse(rp[1], PARAMS);
        if (qb.error) { msg.textContent = 'після «/»: ' + qb.error; msg.classList.add('bad'); return; }
        q.keys = [...new Set([...q.keys, ...qb.keys])];
    }
    if (q.error) { msg.textContent = q.error; msg.classList.add('bad'); return; }
    Q = q;
    // без BODY — стандартного списку не показуємо, лише підсумок (Роман 2026-09-19)
    const noBody = !q.cols.length;
    $('animTableWrap').hidden = noBody;
    $('animCount').classList.remove('is-off');
    // акуратний вигляд: дії великими, без зайвих пробілів, короткі назви
    const tidy = qb ? '' : window.herdQuery.format(q, PARAMS);
    // страховка: упорядкований рядок має означати рівно те саме, інакше лишаємо як є
    const same = (x, y) => JSON.stringify([x.cols, x.filters, x.sorts, x.groups, x.aggs, x.rownum])
        === JSON.stringify([y.cols, y.filters, y.sorts, y.groups, y.aggs, y.rownum]);
    // акуратний вигляд рядка: у ПОЛІ — без «=» (він стоїть значком ліворуч),
    // у сховищі — з ним, як зберігаються списки
    if (tidy && awNoEq(tidy) !== text && same(q, window.herdQuery.parse(tidy, PARAMS))) {
        $('awInput').value = awNoEq(tidy);
        try { localStorage.setItem(AW_KEY, tidy); } catch (e) { /* ignore */ }
        awPaint();
    }
    msg.classList.remove('bad');
    const need = [...new Set([...(q.cols.length ? q.cols : COLS || []), ...q.keys])];
    if (!WORK_CACHE) WORK_CACHE = workCacheLoad();
    const have = WORK_CACHE && need.every((k) => WORK_CACHE.keys.has(k));
    const fresh = have && !WORK_CACHE.stored && (Date.now() - WORK_CACHE.at) < CACHE_TTL;
    const done = () => {
        // те саме число вже стоїть у шапці («Стадо · 191 із 614»), тож окремий
        // рядок під формулою лишаємо тільки там, де таблиці немає
        msg.textContent = LAST_ITEMS.length ? '' : `Нікого із ${ALL_ITEMS.length}`;
        if (noBody && !qb) {
            const extra = (q.aggs || []).map((ag) => {
                const v = aggValue(ag, LAST_ITEMS);
                if (v === null) return '';
                const p0 = ag.key ? paramOf(ag.key) : null;
                return `${ag.fn}${p0 ? ' ' + escapeHtml(p0.short || p0.key) : ''} `
                    + `<b>${numFmt(v, ag.fn === 'avg' || !Number.isInteger(v) ? 1 : 0)}</b>`;
            }).filter(Boolean);
            msg.innerHTML = `Знайдено <b>${LAST_ITEMS.length}</b> із ${ALL_ITEMS.length}`
                + (extra.length ? ' · ' + extra.join(' · ') : '')
                + ' <span class="aw-dim">· таблиця — з BODY(…)</span>';
        }
        if (qb) {
            // як на панелі «Огляду»: рахуються тварини в стаді
            const r = ratioOf(q, qb, ALL_ITEMS.filter((a) => a.status === 'active'));
            const f = (v, d) => (v === null ? '—' : numFmt(v, d));
            msg.textContent = r.v === null ? 'Частка: знаменник порожній'
                : (r.pct ? `Частка ${f(r.v, 1)} % — ${f(r.a, 0)} із ${f(r.b, 0)} (у стаді)`
                    : `Відношення ${f(r.v, 2)} = ${f(r.a, 1)} / ${f(r.b, 1)} (у стаді)`);
        }
    };
    if (have) {                                    // усе вже прочитано — рахуємо на місці
        ALL_ITEMS = WORK_CACHE.items;
        renderTable(applyQ(ALL_ITEMS), ALL_ITEMS.length);
        done();
        if (!fresh) loadList().then(done);         // застаріле — оновлюємо слідом, тихо
        return;
    }
    msg.textContent = 'Читаю…';
    loadList().then(done);
}

/* таблиця так, як вона на екрані: шапка, групи з числами, «Разом» */
function awTableData() {
    const head = (qOn() && Q.rownum ? ['№'] : [])
        .concat(tagInCols() ? [] : [headLabel('tag')])
        .concat(effCols().map(headLabel));
    const rows = [];
    document.querySelectorAll('#animBody tr').forEach((tr) => {
        const kind = tr.classList.contains('anim-grp') ? 'group'
            : (tr.classList.contains('anim-sum') ? 'total' : 'row');
        const cells = [];
        [...tr.cells].forEach((td) => {
            const span = td.colSpan || 1;
            // саме текст: innerHTML лишав «&nbsp;» у розрядах числа
            cells.push((td.textContent || '').replace(/\u00a0/g, ' ').trim());
            for (let i = 1; i < span; i++) cells.push('');
        });
        rows.push({ kind, cells });
    });
    return { head, rows, title: 'Робота зі стадом', formula: $('awInput').value.trim() };
}

async function awXlsx() {
    const btn = $('awXlsx');
    btn.disabled = true;
    try {
        const r = await fetch('/api/herd/export-xlsx', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(awTableData()),
        });
        if (!r.ok) { toast('Не вдалося зібрати файл', 'error'); return; }
        const blob = await r.blob();
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'stado.xlsx';
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    } catch (e) {
        toast('Сервер не відповів', 'error');
    } finally { btn.disabled = false; }
}

/* друк на A4 — як у календарі: спільний модуль herd_print.js */
const AW_PRINT_KEY = 'herd:work_print';
let AW_PRINT = { orient: 'p', twocol: false, font: { family: '', size: 11, bold: false, italic: false } };
try { AW_PRINT = Object.assign(AW_PRINT, JSON.parse(localStorage.getItem(AW_PRINT_KEY) || '{}')); } catch (e) { /* ignore */ }

/* таблиця для друку: та сама шапка й рядки, але БЕЗ екранних ширин —
   клас «fit» каже модулю друку порахувати стовпці за вмістом під ширину
   аркуша (herd_print.js → fitTables). Доти сюди йшли ширини з екрана, а екран
   удвічі ширший за аркуш, тож останні стовпці просто зрізало. */
function awPrintHtml() {
    const src = document.getElementById('animTable');
    const ths = [...src.tHead.rows[0].cells];
    const head = '<tr>' + ths.map((th) => `<th${th.classList.contains('num') ? ' class="num"' : ''}>`
        + `${escapeHtml(th.textContent.trim())}</th>`).join('') + '</tr>';
    const rows = [...src.tBodies[0].rows].map((tr) => {
        const lv = (tr.className.match(/\bl(\d)\b/) || [])[1] || '0';
        const cls = tr.classList.contains('anim-grp') ? ` class="sec l${lv}"`
            : (tr.classList.contains('anim-sum') ? ' class="tot"' : '');
        return `<tr${cls}>` + [...tr.cells].map((td) => `<td${td.classList.contains('num') ? ' class="num"' : ''}`
            + `${td.colSpan > 1 ? ` colspan="${td.colSpan}"` : ''}>${escapeHtml(td.textContent.trim())}</td>`).join('')
            + '</tr>';
    }).join('');
    return `<table class="fit"><thead>${head}</thead><tbody>${rows}</tbody></table>`;
}

function awPrint() {
    if (!LAST_ITEMS.length) { toast('Немає що друкувати', 'error'); return; }
    const today = new Date();
    const dmy = `${String(today.getDate()).padStart(2, '0')}.${String(today.getMonth() + 1).padStart(2, '0')}.${today.getFullYear()}`;
    // на папері має стояти НАЗВА СПИСКУ (Роман 2026-09-22). Але лише доти,
    // доки в рядку САМЕ його формула: після ручної правки список уже не той,
    // і стара назва на аркуші збрехала б — тоді пишемо загальний заголовок.
    const cur = WCUR || OV_CUR;
    // рядок міг бути «причесаний» автоматично (herdQuery.format), тож
    // порівнюємо ЗМІСТ добору, а не текст — інакше назва зникала б після
    // першого ж Enter
    const sig = (t) => {
        try {
            const rp = splitRatio(awNoEq(t).trim());
            const q = window.herdQuery.parse(rp ? rp[0] : awNoEq(t).trim(), PARAMS);
            if (q.error) return null;
            const one = (x) => [x.cols, x.filters, x.sorts, x.groups, x.aggs, x.rownum];
            if (!rp) return JSON.stringify(one(q));
            const q2 = window.herdQuery.parse(rp[1], PARAMS);
            return q2.error ? null : JSON.stringify([one(q), one(q2)]);
        } catch (e) { return null; }
    };
    const mine = cur ? sig($('awInput').value) : null;
    const same = !!mine && mine === sig(cur.formula || '');
    window.herdPrint.open({
        state: AW_PRINT,
        twocolToggle: true,
        content: () => ({
            title: same ? cur.name : 'Робота зі стадом',
            sub: `${LAST_ITEMS.length} із ${ALL_ITEMS.length} · ${dmy}`,
            body: awPrintHtml(),                       // формулу на папір не виносимо
        }),
        onChange: () => {
            try { localStorage.setItem(AW_PRINT_KEY, JSON.stringify(AW_PRINT)); } catch (e) { /* ignore */ }
        },
    });
}

function awCsv() {
    // те саме, що в Excel: короткі назви колонок, групи й «Разом»
    const d = awTableData();
    const num = (v) => String(v === null || v === undefined ? '' : v)
        .replace(/(\d)[\s\u00a0]+(?=\d)/g, '$1');            // 2 349 → 2349
    const esc = (v) => (/[;"\n]/.test(num(v)) ? '"' + num(v).replace(/"/g, '""') + '"' : num(v));
    const lines = [d.head.map(esc).join(';')]
        .concat(d.rows.map((r) => (r.cells || []).map(esc).join(';')));
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'stado.csv';
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 2000);
}

document.querySelectorAll('.anim-tabs .hp-tab').forEach((b) =>
    b.addEventListener('click', () => setTab(b.dataset.tab)));

/* ── стрічка історії: наведення, розкриття, глибина ── */
(function hsBind() {
    const feed = $('hsFeed');
    if (!feed) return;
    // наведення слухаємо ДЕЛЕГОВАНО: mouseenter не спливає, а рядків сотні
    feed.addEventListener('mouseover', (e) => {
        const row = e.target.closest('.hx-row');
        if (row) hxShow(row, e); else hxHide();
    });
    feed.addEventListener('mouseleave', hxHide);
    // з клавіатури — та сама коробка
    feed.addEventListener('focusin', (e) => {
        const row = e.target.closest('.hx-row');
        if (row) hxShow(row, null);
    });
    feed.addEventListener('focusout', hxHide);
    feed.addEventListener('click', (e) => {
        if (e.target.closest('.k-tag')) return;     // посилання на картку
        const all = e.target.closest('.hx-all');
        if (all) { HS_SHOWN.add(all.dataset.day); hxHide(); hsRender(); return; }
        const row = e.target.closest('.hx-row.is-batch');
        if (row) hsToggle(row);
    });
    feed.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        const row = e.target.closest('.hx-row.is-batch');
        if (!row) return;
        e.preventDefault();
        hsToggle(row);
    });
    // сторінка поїхала — підказка не має висіти на порожньому місці
    window.addEventListener('scroll', hxHide, true);
    const dep = $('hsDepth');
    if (dep) {
        dep.addEventListener('change', () => {
            HS_DEPTH = parseInt(dep.value, 10) || 30;
            try { localStorage.setItem('herd:hist_depth', String(HS_DEPTH)); } catch (er) { /* ignore */ }
            hsLoad();
        });
        try {
            const saved = localStorage.getItem('herd:hist_depth');
            if (saved && [...dep.options].some((o) => o.value === saved)) {
                dep.value = saved;
                HS_DEPTH = parseInt(saved, 10) || 30;
            }
        } catch (er) { /* ignore */ }
    }
}());

/* збереження набраної формули під назвою */
function awSaveWhere(w) {
    SAVE_WHERE = w === 'tile' ? 'tile' : 'list';
    document.querySelectorAll('#awSaveWhere .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.w === SAVE_WHERE));
    const tile = SAVE_WHERE === 'tile';
    $('awSaveCat').hidden = tile;               // список має категорію й коментар,
    $('awSaveNote').hidden = tile;              // панель — розділ
    $('ovSection').hidden = !tile;
    // кольори й формат числа переїхали під шестерню (Роман 2026-09-22)
    $('awSaveName').placeholder = tile ? 'Назва панелі' : 'Назва списку';
}

/* 💾 — ЗБЕРЕГТИ. Відкритий список чи панель оновлюємо МОВЧКИ (Роман
   2026-09-22: «кнопка Зберегти повинна зберігати наявний список відкритий,
   без ніяких питань»); вікно з питаннями лишилось для НОВОГО — «чи це
   список, чи панель, яка категорія». Щоб зробити ОКРЕМИЙ список із наявного,
   беруть ⧉ «копію» у «Списках» і правлять її: «+» чистить і рядок теж. */
async function awSaveClick() {
    const f = awWithEq($('awInput').value);
    if (!f) { toast('Спершу наберіть формулу', 'error'); return; }
    if (WCUR) {
        const L = WLISTS.find((x) => String(x.id) === String(WCUR.id));
        if (L) {
            L.formula = f;
            if (await wlSave()) {
                wlSetCur(WLISTS.find((x) => String(x.id) === String(L.id)) || null);
                toast(`Список «${L.name}» збережено`, 'success');
            }
            return;
        }
    }
    if (OV_CUR) {
        const t = OV.find((x) => String(x.id) === String(OV_CUR.id));
        if (t) {
            t.formula = f;
            if (await ovSave()) {
                OV_CUR = OV.find((x) => String(x.id) === String(t.id)) || t;
                awCurShow();
                toast(`Панель «${t.name}» збережено`, 'success');
            }
            return;
        }
    }
    awSaveOpen();                       // нічого не відкрито — питаємо, що це
}

function awSaveOpen() {
    const f = $('awInput').value.trim();
    if (!f) { toast('Спершу наберіть формулу', 'error'); return; }
    if (!WCATS.length) wlLoad();
    $('awCfgBox').hidden = true;
    $('awSaveBox').hidden = false;
    awSaveWhere('list');
    $('awSaveName').value = '';
    $('ovSection').value = '';          // чужий розділ не підставляємо
    $('awSaveCat').value = '';
    $('awSaveNote').value = '';
    $('awSaveName').focus();
}

/* ⚙ ВИГЛЯД — кольори того, що ВІДКРИТО. Список це чи панель, застосунок
   знає сам; у списку немає числа, тож формат числа там не показуємо. */
/* ⚙ тримається за ТОЙ запис, для якого її відкрили: доки коробка стоїть,
   людина може клацнути інший список у рейці чи панель на «Огляді», і запис
   «те, що відкрито зараз» уже інший — кольори лягли б не туди. */
let CFG_FOR = null;

function awCfgClose() {
    if ($('awCfgBox')) $('awCfgBox').hidden = true;
    if ($('ovPal')) $('ovPal').hidden = true;
    CFG_FOR = null;
}

/* перелік категорій у шестерні збирається щоразу: категорію могли додати в
   Конструкторі вже після завантаження сторінки. Свою, якої немає в переліку,
   теж лишаємо — інакше вона мовчки злетіла б при збереженні. */
function awCfgCats(cur) {
    const sel = $('awCfgCat');
    if (!sel) return;
    const cats = [...WCATS];
    if (cur && cur.category && !cats.includes(cur.category)) cats.push(cur.category);
    sel.innerHTML = '<option value="">Без категорії</option>'
        + cats.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    sel.value = (cur && cur.category) || '';
}

function awCfgOpen() {
    const cur = WCUR || OV_CUR;
    if (!cur) {
        toast('Спершу відкрийте список або збережіть формулу', 'error');
        return;
    }
    const tile = !WCUR && !!OV_CUR;
    CFG_FOR = { kind: tile ? 'tile' : 'list', id: String(cur.id), name: cur.name };
    $('awSaveBox').hidden = true;
    $('awCfgBox').hidden = false;
    $('awCfgTitle').textContent = tile ? 'Панель' : 'Список';
    $('awCfgName').value = cur.name || '';
    // список має категорію й коментар, панель — розділ «Огляду»
    if (!WCATS.length) wlLoad().then(() => { if (!$('awCfgBox').hidden) awCfgCats(WCUR); });
    awCfgCats(tile ? null : cur);
    $('awCfgCat').hidden = tile;
    $('awCfgNote').hidden = tile;
    $('awCfgNote').value = tile ? '' : (cur.note || '');
    $('awCfgSection').hidden = !tile;
    $('awCfgSection').value = tile ? (cur.section || '') : '';
    OV_COLOR = cur.color || '';
    OV_EDGE = cur.edge || '';
    OV_BG = ovBgOf(cur.bg || '');
    $('ovPickFmt').hidden = !tile;
    $('ovDec').value = tile ? (cur.dec || '') : '';
    $('ovSep').checked = !(tile && cur.sep === false);
    ovPaintColors();
}

async function awCfgDo() {
    if (!CFG_FOR) { awCfgClose(); return; }
    const tile = CFG_FOR.kind === 'tile';
    const name = $('awCfgName').value.trim();
    if (!name) { $('awCfgName').focus(); return; }
    const paint = { name, color: OV_COLOR, edge: OV_EDGE, bg: OV_BG };
    if (tile) {
        const t = OV.find((x) => String(x.id) === CFG_FOR.id);
        if (!t) { awCfgClose(); toast('Цієї панелі вже немає', 'error'); return; }
        Object.assign(t, paint, { section: $('awCfgSection').value.trim(),
            dec: $('ovDec').value, sep: $('ovSep').checked });
        if (await ovSave()) {
            const fresh = OV.find((x) => String(x.id) === CFG_FOR.id) || t;
            if (OV_CUR && String(OV_CUR.id) === CFG_FOR.id) { OV_CUR = fresh; awCurShow(); }
            awCfgClose();
            toast('Збережено', 'success');
        }
        return;
    }
    const L = WLISTS.find((x) => String(x.id) === CFG_FOR.id);
    if (!L) { awCfgClose(); toast('Цього списку вже немає', 'error'); return; }
    Object.assign(L, paint, { category: $('awCfgCat').value,
        note: $('awCfgNote').value.trim() });
    const keep = WCUR && String(WCUR.id) === CFG_FOR.id;
    if (await wlSave()) {
        if (keep) wlSetCur(WLISTS.find((x) => String(x.id) === CFG_FOR.id) || null);
        awCfgClose();
        toast('Збережено', 'success');
    }
}

/* зберегти набране панеллю-показником «Огляду» */
async function awSaveTile(name, formula) {
    // кольори й формат числа тут НЕ чіпаємо — вони живуть під шестернею,
    // інакше збереження формули щоразу скидало б вигляд панелі
    const paint = { section: $('ovSection').value.trim() };
    if (!OV.length) {
        const r = await apiGet('/api/herd/overview-tiles');
        OV = (r && r.tiles) || [];
    }
    let t = OV.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (t) {
        const own = OV_CUR && String(OV_CUR.id) === String(t.id);
        if (!own && !await confirmAction(`Панель «${name}» уже є. Замінити?`,
            { ok: 'Замінити' })) return;
        // порожній розділ не затирає наявний (інакше збереження однойменної
        // панелі мовчки переносило б її в інший розділ)
        Object.assign(t, { name, formula }, paint.section ? paint : {});
    } else {
        t = Object.assign({ id: 'o' + (Date.now() % 100000), name, formula }, paint);
        OV.push(t);
    }
    const r = await apiSend('/api/herd/overview-tiles', 'POST', { tiles: OV });
    if (!r || r.ok === false) { toast((r && r.error) || 'Не збереглося', 'error'); return; }
    OV = r.tiles || OV;
    OV_CUR = OV.find((x) => x.name === name) || t;
    $('awSaveBox').hidden = true;
    awCurShow();
    toast(`Панель «${name}» збережено`, 'success');
}

async function awSaveDo() {
    const name = $('awSaveName').value.trim();
    const formula = awWithEq($('awInput').value);
    if (!name) { $('awSaveName').focus(); return; }
    if (!formula) { toast('Спершу наберіть формулу', 'error'); return; }
    if (SAVE_WHERE === 'tile') { await awSaveTile(name, formula); return; }
    if (!WLISTS.length) await wlLoad();
    const fields = { name, formula, category: $('awSaveCat').value, note: $('awSaveNote').value.trim() };
    let L = WLISTS.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (L) {
        // свій же відкритий список зберігається без запитання, чужий однойменний — із ним
        const own = WCUR && String(WCUR.id) === String(L.id);
        if (!own && !await confirmAction(`Список «${name}» уже є. Замінити?`, { ok: 'Замінити' })) return;
        Object.assign(L, fields);
    } else {
        L = Object.assign({ id: 'w' + (WLISTS.length + 1) + '-' + name.slice(0, 8) }, fields);
        WLISTS.push(L);
    }
    if (await wlSave()) {
        $('awSaveBox').hidden = true;
        wlSetCur(WLISTS.find((x) => x.name === name) || L);
        toast(`Список «${name}» збережено`, 'success');
    }
}

/* панелі «Огляду» — колір і фон живуть у вікні збереження «Роботи зі стадом» */
/* палітри шрифту, канта й фону */
document.addEventListener('click', (e) => {
    const sw = e.target.closest('.ov-sw');
    const box = $('ovPal');
    if (sw) {
        e.stopPropagation();
        if (box && !box.hidden && OV_PAL_FOR === sw.dataset.for) { box.hidden = true; return; }
        ovPalOpen(sw);
        return;
    }
    if (!box || box.hidden) return;
    const pc = e.target.closest('#ovPal [data-pc]');
    if (pc) { ovPalSet(pc.dataset.pc); box.hidden = true; return; }
    if (!e.target.closest('#ovPal')) box.hidden = true;
});
document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'ovPalCustom') ovPalSet(e.target.value);
});

/* перетягування панелей: порядок і розділ — куди кинули, там і стоїть */
let OV_DRAG = null;
/* формула панелі при наведенні — кольорова, як у рядку й у «Списках»
   (Роман 2026-09-19); замість звичайної сірої підказки браузера */
let ovTipT = null;
function ovTipHide() { clearTimeout(ovTipT); const t = $('ovTip'); if (t) t.hidden = true; }
bind('ovGrid', 'mouseover', (e) => {
    const tile = e.target.closest('.ov-tile');
    if (!tile || e.target.closest('.ov-acts')) { ovTipHide(); return; }
    if (tile.contains(e.relatedTarget)) return;
    clearTimeout(ovTipT);
    ovTipT = setTimeout(() => {
        let tip = $('ovTip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'ovTip';
            tip.className = 'ov-tip';
            document.body.appendChild(tip);              // панель має transform
        }
        tip.innerHTML = `<code class="wl-f">${awHlHtml(tile.dataset.fx || '')}</code>`;
        tip.hidden = false;
        const r = tile.getBoundingClientRect();
        const w = tip.offsetWidth, h = tip.offsetHeight;
        tip.style.left = `${Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8)))}px`;
        tip.style.top = `${Math.round(r.bottom + 6 + h > window.innerHeight ? r.top - h - 6 : r.bottom + 6)}px`;
    }, 350);
});
bind('ovGrid', 'mouseout', (e) => {
    const tile = e.target.closest('.ov-tile');
    if (tile && !tile.contains(e.relatedTarget)) ovTipHide();
});
window.addEventListener('scroll', ovTipHide, true);

bind('ovGrid', 'dragstart', (e) => {
    ovTipHide();
    const t = e.target.closest('.ov-tile');
    if (!t) return;
    OV_DRAG = t.dataset.id;
    t.classList.add('dragging');
    try { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', OV_DRAG); } catch (er) { /* ignore */ }
});
bind('ovGrid', 'dragover', (e) => {
    if (!OV_DRAG) return;
    const t = e.target.closest('.ov-tile');
    e.preventDefault();
    document.querySelectorAll('#ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('drop-before', 'drop-after'));
    if (!t || t.dataset.id === OV_DRAG) return;
    const r = t.getBoundingClientRect();
    t.classList.add(e.clientX < r.left + r.width / 2 ? 'drop-before' : 'drop-after');
});
bind('ovGrid', 'dragend', () => {
    OV_DRAG = null;
    document.querySelectorAll('#ovGrid .dragging, #ovGrid .drop-before, #ovGrid .drop-after')
        .forEach((x) => x.classList.remove('dragging', 'drop-before', 'drop-after'));
});
bind('ovGrid', 'drop', async (e) => {
    e.preventDefault();
    const target = e.target.closest('.ov-tile');
    const id = OV_DRAG;
    OV_DRAG = null;
    if (!target || !id || target.dataset.id === id) { ovRender(); return; }
    const after = target.classList.contains('drop-after');
    const moved = OV.find((x) => String(x.id) === String(id));
    const dest = OV.find((x) => String(x.id) === String(target.dataset.id));
    if (!moved || !dest) return;
    OV = OV.filter((x) => x !== moved);
    moved.section = dest.section || '';        // кинули в інший розділ — туди й переїхала
    const at = OV.indexOf(dest) + (after ? 1 : 0);
    OV.splice(at, 0, moved);
    ovRender();
    await ovSave();
});
bind('ovSection', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('ovGrid', 'click', async (e) => {
    ovTipHide();
    const tile = e.target.closest('.ov-tile');
    if (!tile) return;
    const t = OV.find((x) => String(x.id) === String(tile.dataset.id));
    if (!t) return;
    const act = (e.target.closest('[data-act]') || {}).dataset;
    if (act && act.act === 'edit') {         // правити — у «Роботі зі стадом»
        // ⚙, а НЕ вікно створення: вікно тепер лише для нового, і панель
        // через нього роздвоювалась у робочий список (знайдено перевіркою)
        ovOpenInWork(t);
        setTimeout(awCfgOpen, 300);
        return;
    }
    if (act && act.act === 'del') {
        const ok = await confirmAction(`Прибрати панель «${t.name}»?`,
            { ok: 'Прибрати', okClass: 'btn-danger' });
        if (!ok) return;
        OV = OV.filter((x) => x !== t);
        await ovSave();
        return;
    }
    ovOpenInWork(t);                        // клік по панелі — показати самих тварин
});

function ovOpenInWork(t) {
    if (CFG_FOR && String(t.id) !== CFG_FOR.id) awCfgClose();
    $('awInput').value = awNoEq(t.formula);
    try { localStorage.setItem(AW_KEY, t.formula); } catch (er) { /* ignore */ }
    WCUR = null;
    OV_CUR = t;
    awCurShow();
    setTab('work');
    awPaint();
}

bind('awSaveWhere', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awSaveWhere(b.dataset.w);
});
bind('awSave', 'click', awSaveClick);
bind('awCfgBtn', 'click', awCfgOpen);
bind('awCfgOk', 'click', awCfgDo);
bind('awCfgCancel', 'click', awCfgClose);
bind('awCfgBox', 'keydown', (e) => {
    if (e.key === 'Escape') awCfgClose();
    if (e.key === 'Enter' && e.target.id !== 'awCfgCancel') { e.preventDefault(); awCfgDo(); }
});
bind('awSaveOk', 'click', awSaveDo);
bind('awSaveCancel', 'click', () => { $('awSaveBox').hidden = true; });
bind('awSaveName', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
    if (e.key === 'Escape') $('awSaveBox').hidden = true;
});
bind('awSaveNote', 'keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); awSaveDo(); }
});

/* добір у «Списках» */
bind('wlSearch', 'input', wlRender);
bind('wlCat', 'change', wlRender);

/* дії над збереженими списками */
bind('animLists', 'click', async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const row = b.closest('.wl-row');
    const L = WLISTS.find((x) => String(x.id) === String(row.dataset.id));
    if (!L) return;
    if (b.dataset.act === 'open') { wlOpen(L); return; }
    /* СКОПІЮВАТИ ФОРМУЛУ в буфер (Роман 2026-09-22) — щоб укинути її в інший
       список, у листа чи просто поруч поправити. Береться рядок як є, разом
       із «=», тож вставляється просто в рядок «Роботи зі стадом». */
    if (b.dataset.act === 'fcopy') {
        const fx = L.formula || '';
        try {
            await navigator.clipboard.writeText(fx);
            toast('Формулу скопійовано', 'success');
        } catch (e) {
            // ферма відкривається і по http у мережі — там clipboard недоступний
            try {
                const ta = document.createElement('textarea');
                ta.value = fx; ta.style.position = 'fixed'; ta.style.opacity = '0';
                document.body.appendChild(ta); ta.select();
                document.execCommand('copy'); ta.remove();
                toast('Формулу скопійовано', 'success');
            } catch (e2) { toast('Не вдалося скопіювати', 'error'); }
        }
        return;
    }
    /* КОПІЯ СПИСКУ (Роман 2026-09-22). Робочий список зазвичай правлять «від
       наявного»: узяти готовий, трохи змінити добір — і це вже інший список.
       Копія лягає ОДРАЗУ під оригіналом і в ту саму категорію, тож шукати її
       не треба; назва «… (копія)», щоб не плутати з першим. */
    if (b.dataset.act === 'copy') {
        const base = L.name.replace(/\s*\(копія(?:\s+\d+)?\)$/, '');
        let name = base + ' (копія)';
        for (let n = 2; WLISTS.some((x) => x.name === name); n++) name = `${base} (копія ${n})`;
        let id = 'w' + (WLISTS.length + 1) + '-' + name.slice(0, 8);
        while (WLISTS.some((x) => String(x.id) === id)) id += 'x';
        const copy = Object.assign({}, L, { id, name });
        WLISTS.splice(WLISTS.indexOf(L) + 1, 0, copy);
        if (await wlSave()) toast(`Створено «${name}»`, 'success');
        return;
    }
    if (b.dataset.act === 'rename') {
        const span = row.querySelector('.wl-name');
        if (row.querySelector('input')) return;
        const inp = document.createElement('input');
        inp.className = 'aw-namein';
        inp.value = L.name;
        inp.maxLength = 80;
        span.replaceWith(inp);
        inp.focus();
        inp.select();
        const done = async (save) => {
            const v = inp.value.trim();
            if (save && v) { L.name = v; await wlSave(); } else wlRender();
        };
        inp.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') done(true);
            if (ev.key === 'Escape') done(false);
        });
        inp.addEventListener('blur', () => done(true));
        return;
    }
    if (b.dataset.act === 'del') {
        const ok = await confirmAction(`Видалити список «${L.name}»?`,
            { ok: 'Видалити', okClass: 'btn-danger' });
        if (!ok) return;
        if (WCUR && WCUR.id === L.id) wlSetCur(null);
        WLISTS = WLISTS.filter((x) => x !== L);
        await wlSave();
    }
});

/* вибрані тварини → «Груповий ввід». Сторінка вже вміє приймати ?ids= —
   тим самим шляхом туди веде календар, тож нічого нового на сервері. */
bind('awEvent', 'click', () => {
    // передаємо САМУ ФОРМУЛУ, а не перелік номерів: у груповому вводі
    // список лишається живим і не залежить від довжини адреси
    const f = awWithEq($('awInput').value);
    if (!f || !LAST_ITEMS.length) return;
    location.href = '/herd/group?f=' + encodeURIComponent(f);
});

/* рядок формули: підсвітка, підказки, Enter */
bind('awInput', 'input', () => { awPaint(); awSuggest(); });   // підказка вискакує сама
bind('awInput', 'scroll', () => { $('awHl').scrollLeft = $('awInput').scrollLeft; });
bind('awInput', 'keyup', awPaint);
bind('awInput', 'click', awSuggest);
bind('awInput', 'focus', awSuggest);
bind('awInput', 'blur', () => setTimeout(() => { $('awSug').hidden = true; }, 150));
bind('awInput', 'keydown', (e) => {
    const open = AW_SUG.length && !$('awSug').hidden;
    if (open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        AW_POS = (AW_POS + (e.key === 'ArrowDown' ? 1 : AW_SUG.length - 1)) % AW_SUG.length;
        AW_NAV = true;                               // обрали стрілками — Enter вставляє
        awDrawSug();
        const on = $('awSug').querySelector('.on');
        if (on) on.scrollIntoView({ block: 'nearest' });
        return;
    }
    if (e.key === 'Enter' && open && AW_NAV) { e.preventDefault(); awTake(AW_POS); return; }
    // Tab — підтвердити вибір із підказки
    if (e.key === 'Tab' && open) { e.preventDefault(); awTake(AW_POS); return; }
    if (e.key === 'Escape') { $('awSug').hidden = true; AW_SUG = []; return; }
    // Enter — прочитати список за формулою
    if (e.key === 'Enter') {
        e.preventDefault();
        $('awSug').hidden = true; AW_SUG = [];
        runFormula();
    }
});
window.addEventListener('scroll', awPlaceSug, true);
window.addEventListener('resize', awPlaceSug);
/* «+» — новий список: рядок чистий і ЖОДЕН збережений список більше не
   відкритий, тож наступне «Зберегти» заведе новий, а не перепише старий. */
bind('awNew', 'click', () => {
    const el = $('awInput');
    el.value = '';
    try { localStorage.setItem(AW_KEY, ''); } catch (e) { /* ignore */ }
    OV_CUR = null;
    wlSetCur(null);                                // смужка «відкрито…» гасне
    if ($('awSaveBox')) $('awSaveBox').hidden = true;
    awCfgClose();
    awPaint();
    runFormula();                                  // таблиця ховається, рядок чистий
    el.focus();
    awSuggest();
});
bind('awClear', 'click', () => {
    const el = $('awInput');
    el.value = '';
    awPaint();
    runFormula();                                  // таблиця ховається, рядок чистий
    el.focus();
    awSuggest();
});
bind('awSug', 'mousedown', (e) => {
    const d = e.target.closest('[data-i]');
    if (d) { e.preventDefault(); awTake(+d.dataset.i); }
});
bind('awHelpBtn', 'click', () => {
    const on = $('awHelp').hidden;          // одна кнопка на дві коробки:
    $('awHelp').hidden = !on;               // «як писати» + перелік параметрів
    $('awWords').hidden = !on;
});
// друк і вивантаження — лише коли є таблиця, тобто формула з BODY(…)
const needBody = (fn) => () => {
    if (Q && !Q.cols.length) { toast('Додайте у формулу BODY(…) — які колонки вивести', 'error'); return; }
    fn();
};
bind('awCsv', 'click', needBody(awCsv));
bind('awXlsx', 'click', needBody(awXlsx));
bind('awPrint', 'click', needBody(awPrint));
bind('awWords', 'click', (e) => {
    const b = e.target.closest('[data-w]');
    if (b) awInsert(b.dataset.w);
});

// підказка живе в <body>: у панелі є transform, а він ловить position:fixed
if ($('awSug')) document.body.appendChild($('awSug'));

restoreFilters();
try { $('awInput').value = awNoEq(localStorage.getItem(AW_KEY) || ''); } catch (e) { /* ignore */ }
awPaint();
// на старті — лише перелік параметрів; дані читає сама вкладка («Огляд» —
// легкий добір для панелей, «Робота» — за формулою). Раніше тут щоразу
// тягнувся весь список стада (1,3 МБ), навіть коли видно лише «Огляд».
loadColumns().then(() => {
    $('awHelp').innerHTML = awHelpHtml();
    // приклади в довідці — тими самими кольорами, що в рядку
    $('awHelp').querySelectorAll('code').forEach((c) => {
        c.classList.add('wl-f');
        c.innerHTML = awHlHtml(c.textContent);
    });
    $('awWords').innerHTML = awWordsHtml();
    // перехід на «Головну» — завжди «Огляд» (Роман 2026-09-19); оновлення
    // чи «назад» лишають вкладку, на якій людина була в цьому візиті
    let t = 'reg', nav = 'navigate';
    try { nav = (performance.getEntriesByType('navigation')[0] || {}).type || 'navigate'; } catch (e) { /* ignore */ }
    if (nav === 'reload' || nav === 'back_forward') {
        try { t = sessionStorage.getItem('herd:anim_tab') || 'reg'; } catch (e) { t = 'reg'; }
    }
    // посилання з формулою (напр. зі сторінки «Перевірка») — одразу ці тварини
    const fq = new URLSearchParams(location.search).get('f');
    if (fq) {
        $('awInput').value = awNoEq(fq);
        try { localStorage.setItem(AW_KEY, fq); } catch (e) { /* ignore */ }
        history.replaceState(null, '', location.pathname);   // оновлення не повторює
        t = 'work';
        awPaint();
    }
    setTab(t);                      // «Огляд» теж має свою розкладку (панелі)
});

// «⚙ Колонки» — спільний компонент гілки (herd_colpicker.js)
if ($('animCols') && window.herdColPicker) {
    herdColPicker({
        button: $('animCols'),
        params: () => PARAMS,
        hide: ['tag'],
        selected: () => COLS || [],
        onToggle: (k, on) => {
            if (on) { if (!COLS.includes(k)) COLS.push(k); }
            else COLS = COLS.filter((x) => x !== k);
            saveCols();
            // значень нового параметра в завантаженому списку ще немає
            const first = LAST_ITEMS[0];
            const missing = on && !CORE_COLS[k] && first
                && !Object.prototype.hasOwnProperty.call(first.p || {}, k);
            if (missing) loadList(); else renderTable(LAST_ITEMS);
        },
    });
}

/* Перемикач «Живі · Вибулі · Усі» у смужці гілки має рухати й саму таблицю:
   інакше вгорі написано одне, а в списку інше (Роман 2026-09-16 просив
   перевірити перемикач на всіх сторінках стада). */
window.herdRegistry = {
    reload() {
        let f = null;
        try { f = JSON.parse(localStorage.getItem(FLT_KEY) || 'null'); } catch (e) { f = null; }
        if (!f) return;
        $('animSearch').value = f.q || '';
        $('animStatus').value = f.status || '';
        $('animSex').value = f.sex || '';
        $('animGroup').value = f.group_id || '';
        return loadList();
    },
};

/* ---------- Нумерація приплоду ----------
   Роман 2026-09-16: «номер він іде похідний, а довгий номер UA він є
   основний» + «1-й варіант + перемикач на останній найбільший». Тож
   рахуємо довгий номер, а бирка — його хвіст; правило обирається тут. */
(function () {
    const box = $('animNumBox');
    if (!box) return;
    let CFG = {};

    const q = (id) => $(id);
    const setMode = (m) => {
        CFG.mode = (m === 'max') ? 'max' : 'counter';
        $('animNumMode').querySelectorAll('.seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.m === CFG.mode));
        // у режимі «найбільший» лічильник не потрібен — програма дивиться в базу
        $('animNumNextWrap').style.opacity = CFG.mode === 'max' ? '.45' : '';
        $('animNumNext').disabled = CFG.mode === 'max';
        $('animNumHint').textContent = CFG.mode === 'max'
            ? 'Бере найбільший номер із цим префіксом і додає одиницю. Чужі серії не враховуються, але випадково великий номер зсуне нумерацію.'
            : 'Свій лічильник: не збивається ні імпортом архіву, ні купленою твариною з чужим номером. Після кожного отелу зсувається сам.';
        $('animNumHint').textContent += ' Бирка — не коротша за 5 знаків: чотиризначні номери лишаються вільними для нашийників дійних корів.';
        preview();
    };

    async function preview() {
        try {
            const r = await apiGet('/api/herd/next-uin');
            $('animNumPrev').innerHTML = (r && r.ok && r.uin)
                ? `${escapeHtml(herdLabel('uin', 'Ідентифікаційний номер'))}: <b>${escapeHtml(r.uin)}</b> · ${escapeHtml(herdLabel('tag', 'Номер тварини'))}: <b>${escapeHtml(r.tag || '')}</b>`
                : 'номер поки нема від чого рахувати';
        } catch (e) { $('animNumPrev').textContent = ''; }
    }

    async function load() {
        const r = await apiGet('/api/herd/calf-numbering');
        CFG = (r && r.ok && r.cfg) || {};
        $('animNumPrefix').value = CFG.prefix || '';
        $('animNumNext').value = CFG.next || '';
        $('animNumTagLen').value = CFG.tag_len || '';
        setMode(CFG.mode);
    }

    $('animNumBtn') && $('animNumBtn').addEventListener('click', () => {
        box.hidden = !box.hidden;
        if (!box.hidden) load();
    });
    $('animNumMode').addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (b) setMode(b.dataset.m);
    });
    $('animNumSave').addEventListener('click', async () => {
        const r = await apiSend('/api/herd/calf-numbering', 'POST', {
            mode: CFG.mode,
            prefix: $('animNumPrefix').value.trim(),
            next: $('animNumNext').value.trim(),
            tag_len: $('animNumTagLen').value.trim(),
        });
        if (!r.ok) {
            toast(r.error || 'Помилка', 'error');
            $('animNumTagLen').focus(); $('animNumTagLen').select();
            return;
        }
        CFG = r.cfg || CFG;
        toast('Збережено', 'success');
        preview();
    });
})();
