/* Кольорова підсвітка рядка формули параметрів — одна на весь застосунок
   (Конструктор, картка тварини). Роман 2026-09-19.
   herdFxHl(текст, {params, events, funcs, soft}) → HTML зі <span class="…">:
   k — «=» на початку, f — функція, p — параметр, e — подія / life / lactation,
   n — число, s — текст у лапках, o — знак, b — дужки й коми,
   x — невідома назва (одруківка), v — «місце для значення» (у прикладах, soft). */
'use strict';
(function () {
    const DEFAULT_FUNCS = ['TODAY', 'DAYS', 'MONTHS', 'ADDDAYS', 'IF', 'AND', 'OR', 'NOT', 'IN',
        'ISEMPTY', 'COALESCE', 'MIN', 'MAX', 'ROUND', 'ROUNDUP', 'ROUNDDOWN', 'ABS', 'INT',
        'COUNT', 'LAST', 'FIRST', 'VAL', 'VALDATE', 'AVGVAL', 'TOTAL', 'LABEL', 'POS', 'MILKING', 'WITHDRAWAL', 'GESTATION'];
    const EVENT_FNS = ['COUNT', 'LAST', 'FIRST'];
    const HIST_FNS = ['VAL', 'VALDATE'];         // (параметр, позиція, період)
    const AGG_FNS = ['AVGVAL', 'TOTAL'];         // (параметр, період)
    const esc = (t) => String(t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    function herdFxHl(txt, opt) {
        const o = opt || {};
        const params = o.params || [];
        const events = o.events;                  // немає переліку — подію не перевіряємо
        const fnNames = new Set((o.funcs && o.funcs.length) ? o.funcs : DEFAULT_FUNCS);
        const soft = !!o.soft;
        const isParam = (n) => {
            const w = n.toLowerCase();
            return params.some((p) => [p.short, p.key, p.label].some((x) => (x || '').toLowerCase() === w));
        };
        const isEvent = (n) => !events || events.some((e) =>
            [e.key, e.label].some((x) => (x || '').toLowerCase() === n.toLowerCase()));
        const re = /(\s+)|("[^"]*"?|'[^']*'?)|(\[[^\]]*\]?)|(\d+(?:\.\d+)?)|([\p{L}_][\p{L}\d_]*)|(<=|>=|<>|!=|[-+*/^=<>])|([(),;])|(.)/gu;
        let out = '', m, first = true;
        const stack = [];
        const unknown = soft ? 'v' : 'x';
        while ((m = re.exec(String(txt || '')))) {
            const t = m[0];
            if (m[1]) { out += t; continue; }
            const top = stack[stack.length - 1];
            if (first && t === '=') { out += '<span class="k">=</span>'; first = false; continue; }
            first = false;
            if (m[2]) out += `<span class="s">${esc(t)}</span>`;
            else if (m[3]) out += `<span class="${isParam(t.replace(/^\[|\]$/g, '').trim()) ? 'p' : unknown}">${esc(t)}</span>`;
            else if (m[4]) out += `<span class="n">${esc(t)}</span>`;
            else if (m[5]) {
                const next = String(txt).slice(re.lastIndex).trimStart();
                const up = t.toUpperCase();
                let cls;
                if (next.startsWith('(')) cls = fnNames.has(up) ? 'f' : unknown;
                // у COUNT/LAST/FIRST першим аргументом буває і ПОДІЯ, і параметр
                // (COUNT(fdat) = скільки разів записано дату отелу)
                else if (top && EVENT_FNS.includes(top.fn) && top.arg === 0)
                    cls = isEvent(t) ? 'e' : (isParam(t) ? 'p' : unknown);
                else if (top && ((EVENT_FNS.includes(top.fn) && top.arg === 1)
                                 || (HIST_FNS.includes(top.fn) && top.arg === 2)
                                 || (AGG_FNS.includes(top.fn) && top.arg === 1))
                         && /^(life|lactation|prevlactation)$/i.test(t)) cls = 'e';
                else if (/^(and|or)$/i.test(t)) cls = 'o';     // між умовами
                else if (top && top.fn === 'WITHDRAWAL' && /^(milk|meat)$/i.test(t)) cls = 'e';
                else if (/^(TRUE|FALSE)$/i.test(t)) cls = 'n';
                else cls = isParam(t) ? 'p' : unknown;
                if (cls === 'f') stack.push({ fn: up, arg: 0, pending: true });
                out += `<span class="${cls}">${esc(t)}</span>`;
            } else if (m[6]) out += `<span class="o">${esc(t)}</span>`;
            else if (m[7]) {
                if (t === '(') {
                    if (top && top.pending) top.pending = false;
                    else stack.push({ fn: '', arg: 0 });
                } else if (t === ')') stack.pop();
                else if (top) top.arg += 1;
                out += `<span class="b">${esc(t)}</span>`;
            } else out += esc(t);
        }
        return out;
    }
    window.herdFxHl = herdFxHl;
}());
