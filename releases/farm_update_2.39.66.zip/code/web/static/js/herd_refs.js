/* Довідники значень стада: спільні списки (бики-плідники, причини вибуття…),
   з яких обирають параметри типу «Довідник». Значення можна деактивувати —
   у нових подіях воно не пропонується, а вже внесене лишається як було.
   Модуль в IIFE і стартує лише за наявності своєї розмітки. */
'use strict';
(function () {

const $ = (id) => document.getElementById(id);
let REFS = [];
// Джерело людей одне — спільний список «Ветеринари» (слово Романа
// 2026-09-16: «тільки із ветеринарів і свій список, і все»).
let VET_KEY = 'vet';
let VET_NAME = 'Ветеринари';
let openRef = 0;          // розкритий довідник
/* Пошук у довіднику і сторожа дублів (Роман 2026-09-23: «треба вставити в
   довідник строку пошуку, щоб знайти і помилково не продублювати запис. І
   якщо я ввожу, а такий запис уже є, треба попередження»). Запит тримаємо
   тут, бо список перемальовується після кожного збереження. */
const RF_Q = {};
const rfNorm = (s) => String(s || '').trim().toLowerCase().replace(/\s+/g, ' ');

async function load() {
    const r = await apiGet('/api/herd/refs');
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    REFS = r.refs || [];
    const src = (r.sources || [])[0];
    if (src) { VET_KEY = src.key; VET_NAME = src.name; }
    render();
    document.dispatchEvent(new CustomEvent('herd-refs-changed'));
}

/* Активні — ЗВЕРХУ, вимкнені — під роздільником унизу (Роман 2026-09-23:
   «неактивні вже там внизу, щоб не шукати їх по всьому списку»). Порядок
   усередині кожної групи лишається такий, як віддав сервер. Рядок міняє
   місце не в мить зняття галочки, а при наступному відкритті довідника —
   інакше він тікав би з-під руки. */
function rfSort(items) {
    const on = [], off = [];
    (items || []).forEach((it) => (it.is_active ? on : off).push(it));
    return on.concat(off);
}

/* значення, що трапляються в довіднику більш ніж раз */
function dupKeys(items) {
    const n = {};
    (items || []).forEach((it) => {
        const k = rfNorm(it.label);
        if (k) n[k] = (n[k] || 0) + 1;
    });
    return new Set(Object.keys(n).filter((k) => n[k] > 1));
}

function render() {
    $('rfCount').textContent = REFS.length ? '· ' + REFS.length : '';
    if (!REFS.length) {
        $('rfList').innerHTML = '<p class="hp-empty">Довідників ще немає — '
            + 'створіть перший, наприклад «Бики-плідники»</p>';
        return;
    }
    $('rfList').innerHTML = REFS.map((rf) => {
        const open = rf.id === openRef;
        const items = rfSort(rf.items || []);
        const nOff = items.filter((it) => !it.is_active).length;
        const firstOff = nOff ? items[items.length - nOff].id : 0;
        const used = (rf.used_by || []).length
            ? `використовує: ${rf.used_by.map(escapeHtml).join(', ')}`
            : 'поки не використовується жодним параметром';
        return `<div class="rf-item${open ? ' is-open' : ''}" data-id="${rf.id}">
            <div class="rf-head">
                <span class="rf-chev">${open ? '▾' : '▸'}</span>
                <span class="rf-name">${escapeHtml(rf.name)}</span>
                <span class="rf-meta">${rf.n_active} з ${rf.n_items} активні · ${used}</span>
                <button type="button" class="rf-del" data-del="${rf.id}"
                        title="Прибрати довідник">−</button>
            </div>
            ${open ? `<div class="rf-body">
                <div class="rf-src">
                    <span>Що в довіднику:</span>
                    <select class="rf-in rf-srcsel" data-ref="${rf.id}">
                        <option value=""${!rf.src_key ? ' selected' : ''}>власні значення</option>
                        <option value="${VET_KEY}"${rf.src_key ? ' selected' : ''}>
                            люди зі списку «${escapeHtml(VET_NAME)}»</option>
                    </select>
                    ${rf.src_key ? '<span class="rf-srchint">познач, хто входить у цей довідник — '
                        + 'одна людина може бути в кількох</span>' : ''}
                </div>

                ${rf.src_key ? `<div class="rf-pick">${
                    (rf.candidates || []).length
                        ? [...(rf.candidates || [])].sort((a, b) => (b.on ? 1 : 0) - (a.on ? 1 : 0))
                            .map((c) => `
                            <label class="rf-p${c.on ? ' on' : ''}">
                                <input type="checkbox" class="rf-pon" data-src="${c.id}"
                                       data-ref="${rf.id}"${c.on ? ' checked' : ''}>
                                <b>${escapeHtml(c.label || c.code)}</b>
                                ${c.note ? `<span class="rf-pnote">${escapeHtml(c.note)}</span>` : ''}
                            </label>`).join('')
                        : '<p class="hp-empty">Спільний список порожній — заповніть вкладку «' + escapeHtml(VET_NAME) + '»</p>'
                }</div>` : `
                <div class="rf-find">
                    <input type="search" class="rf-in rf-q" data-ref="${rf.id}"
                           placeholder="пошук значення" autocomplete="off"
                           value="${escapeHtml(RF_Q[rf.id] || '')}">
                    <span class="rf-qn" data-qn="${rf.id}"></span>
                </div>
                <table class="hp-tbl rf-tbl">
                    <thead><tr>
                        <th>Код</th><th>Значення</th><th>Примітка</th>
                        <th class="c">Активне</th><th class="c"></th>
                    </tr></thead>
                    <tbody>${items.length ? items.map((it) => `
                        ${it.id === firstOff ? `<tr class="rf-sep" data-sep="${rf.id}">
                            <td colspan="5">вимкнені · ${nOff}</td></tr>` : ''}
                        <tr data-item="${it.id}" data-key="${escapeHtml(rfNorm(it.label))}"
                            class="${it.is_active ? '' : 'is-off'}${dupKeys(items).has(rfNorm(it.label)) ? ' is-dup' : ''}"
                            ${dupKeys(items).has(rfNorm(it.label)) ? 'title="У довіднику вже є таке саме значення"' : ''}>
                            <td><input type="text" class="rf-in rf-code" value="${escapeHtml(it.code || '')}"
                                       placeholder="—"></td>
                            <td><input type="text" class="rf-in rf-label" value="${escapeHtml(it.label || '')}"></td>
                            <td><input type="text" class="rf-in rf-note" value="${escapeHtml(it.note || '')}"
                                       placeholder="лінія, походження…"></td>
                            <td class="c"><input type="checkbox" class="rf-on"${it.is_active ? ' checked' : ''}></td>
                            <td class="c"><button type="button" class="eb-x" data-idel="${it.id}"
                                    title="Видалити значення">✕</button></td>
                        </tr>`).join('')
                        : '<tr><td colspan="5" class="hp-empty">Значень ще немає</td></tr>'}
                    </tbody>
                </table>
                <div class="rf-newrow">
                    <input type="text" class="rf-in rf-ncode" placeholder="код">
                    <input type="text" class="rf-in rf-nlabel" placeholder="нове значення">
                    <button type="button" class="btn btn-ghost btn-sm rf-iadd" data-add="${rf.id}">+ Додати</button>
                </div>
                <p class="rf-warn" data-warn="${rf.id}" hidden></p>`}
            </div>` : ''}
        </div>`;
    }).join('');
    bind();
}

/* показати лише ті рядки, що підходять під пошук */
function rfFilter(refId) {
    const box = $('rfList');
    const wrap = box.querySelector(`.rf-item[data-id="${refId}"]`);
    if (!wrap) return;
    const q = rfNorm(RF_Q[refId]);
    let seen = 0, all = 0;
    wrap.querySelectorAll('tr[data-item]').forEach((tr) => {
        all += 1;
        const hay = rfNorm([...tr.querySelectorAll('.rf-in')].map((i) => i.value).join(' '));
        const hit = !q || hay.includes(q);
        tr.hidden = !hit;
        if (hit) seen += 1;
    });
    const sep = wrap.querySelector(`[data-sep="${refId}"]`);
    if (sep) {
        const offVisible = [...wrap.querySelectorAll('tr[data-item].is-off')].some((tr) => !tr.hidden);
        sep.hidden = !offVisible;
    }
    const n = wrap.querySelector(`[data-qn="${refId}"]`);
    if (n) n.textContent = q ? (seen ? `знайдено ${seen} із ${all}` : 'нічого не знайшли') : '';
}

/* попередження про дубль під рядком додавання */
function rfDupWarn(refId) {
    const box = $('rfList');
    const wrap = box.querySelector(`.rf-item[data-id="${refId}"]`);
    if (!wrap) return null;
    const inp = wrap.querySelector('.rf-nlabel');
    const warn = wrap.querySelector(`[data-warn="${refId}"]`);
    const key = rfNorm(inp && inp.value);
    const hit = key ? [...wrap.querySelectorAll('tr[data-item]')]
        .find((tr) => tr.dataset.key === key) : null;
    if (warn) {
        warn.hidden = !hit;
        if (hit) {
            const code = hit.querySelector('.rf-code').value.trim();
            const off = hit.classList.contains('is-off');
            warn.textContent = `Таке значення вже є${code ? ` (код ${code})` : ''}`
                + (off ? ' — воно лише вимкнене, увімкніть його замість нового.' : '.');
        }
    }
    if (inp) inp.classList.toggle('is-dup', !!hit);
    return hit;
}

function bind() {
    const box = $('rfList');
    // пошук у довіднику — фільтруємо рядки на місці, без перемальовування,
    // інакше поле губило б фокус на кожній літері
    box.querySelectorAll('.rf-q').forEach((q) => {
        const id = +q.dataset.ref;
        q.addEventListener('input', () => { RF_Q[id] = q.value; rfFilter(id); });
        if (RF_Q[id]) rfFilter(id);
    });
    // підказка про дубль просто під час набору
    box.querySelectorAll('.rf-nlabel').forEach((i) => {
        const id = +i.closest('.rf-item').dataset.id;
        i.addEventListener('input', () => rfDupWarn(id));
    });
    // звідки довідник бере значення: свій список чи підбірка зі спільного
    box.querySelectorAll('.rf-srcsel').forEach((sel) => sel.addEventListener('change', async () => {
        const r = await apiSend('/api/herd/refs/' + sel.dataset.ref, 'POST',
            { src_key: sel.value });
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }));
    // хто входить у підбірку
    box.querySelectorAll('.rf-pon').forEach((c) => c.addEventListener('change', async () => {
        c.closest('.rf-p').classList.toggle('on', c.checked);
        const r = await apiSend('/api/herd/ref-pick', 'POST',
            { ref_id: +c.dataset.ref, src_item_id: +c.dataset.src, on: c.checked });
        if (!r || !r.ok) {
            toast((r && r.error) || 'Не збережено', 'error');
            c.checked = !c.checked;
            c.closest('.rf-p').classList.toggle('on', c.checked);
        }
    }));
    box.querySelectorAll('.rf-head').forEach((h) => h.addEventListener('click', (e) => {
        if (e.target.closest('.rf-del')) return;
        const id = +h.closest('.rf-item').dataset.id;
        openRef = (openRef === id) ? 0 : id;
        render();
    }));
    box.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
        const rf = REFS.find((x) => x.id === +b.dataset.del);
        if (!(await confirmAction(`Прибрати довідник «${rf.name}» разом зі значеннями?`, { ok: 'Прибрати' }))) return;
        const r = await apiSend('/api/herd/refs/' + rf.id, 'DELETE');
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        toast('Довідник прибрано', 'success');
        load();
    }));
    box.querySelectorAll('[data-idel]').forEach((b) => b.addEventListener('click', async () => {
        const r = await apiSend('/api/herd/ref-items/' + b.dataset.idel, 'DELETE');
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }));
    // ⚠️ Замок першим рядком: між натисканням і записом стоїть перепит про
    // дубль, і друге натискання «＋» заводило другий такий самий запис.
    let rfAdding = false;
    box.querySelectorAll('[data-add]').forEach((b) => b.addEventListener('click', async () => {
        if (rfAdding) return;
        rfAdding = true;
        try { await rfAddRun(b); } finally { rfAdding = false; }
    }));

    async function rfAddRun(b) {
        const row = b.closest('.rf-newrow');
        const label = row.querySelector('.rf-nlabel').value.trim();
        const code = row.querySelector('.rf-ncode').value.trim();
        if (!label && !code) { row.querySelector('.rf-nlabel').focus(); return; }
        // такий запис уже є — показуємо його і питаємо, чи справді додавати
        let forced = false;
        const dup = rfDupWarn(+b.dataset.add);
        if (dup) {
            dup.scrollIntoView({ block: 'center' });
            dup.classList.add('rf-flash');
            setTimeout(() => dup.classList.remove('rf-flash'), 1600);
            const same = dup.querySelector('.rf-label').value.trim();
            if (!(await confirmAction(`«${same}» у довіднику вже є. Усе одно додати ще один такий запис?`,
                { ok: 'Усе одно додати' }))) return;
            forced = true;          // людина свідомо підтвердила збіг
        }
        const r = await apiSend('/api/herd/ref-items', 'POST',
            { ref_id: +b.dataset.add, code, label, force: forced });
        if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
        load();
    }
    // Enter у полі нового значення = натиснути «Додати»
    box.querySelectorAll('.rf-nlabel, .rf-ncode').forEach((inp) =>
        inp.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') e.target.closest('.rf-newrow').querySelector('.rf-iadd').click();
        }));
    // правки значень зберігаються самі
    box.querySelectorAll('tr[data-item]').forEach((tr) => {
        const id = +tr.dataset.item;
        let t = null;
        const save = (extra) => {
            clearTimeout(t);
            t = setTimeout(async () => {
                const body = Object.assign({
                    id,
                    code: tr.querySelector('.rf-code').value.trim(),
                    label: tr.querySelector('.rf-label').value.trim(),
                    note: tr.querySelector('.rf-note').value.trim(),
                }, extra || {});
                const r = await apiSend('/api/herd/ref-items', 'POST', body);
                if (!r || !r.ok) toast((r && r.error) || 'Не збережено', 'error');
                else document.dispatchEvent(new CustomEvent('herd-refs-changed'));
                const rid = +tr.closest('.rf-item').dataset.id;
                tr.dataset.key = rfNorm(tr.querySelector('.rf-label').value);
                rfFilter(rid); rfDupWarn(rid);
            }, 600);
        };
        tr.querySelectorAll('.rf-in').forEach((i) => i.addEventListener('input', () => save()));
        tr.querySelector('.rf-on').addEventListener('change', (e) => {
            tr.classList.toggle('is-off', !e.target.checked);
            save({ is_active: e.target.checked });
        });
    });
}

/* Новий довідник — одразу з відповіддю на головне питання: це перелік
   людей із спільного списку («Ветеринари») чи власні значення
   (бики-плідники, причини вибуття). Роман 2026-09-16: «при створенні
   довідника потрібно вказати, чи це список ветеринарів, чи інше». */
function openNewRef() {
    const m = $('rfNewModal');
    $('rfNewName').value = '';
    $('rfNewPeople').textContent = `Люди зі списку «${VET_NAME}»`;
    m.querySelectorAll('#rfNewKind .seg-btn').forEach((b, i) =>
        b.classList.toggle('is-active', i === 0));
    m.hidden = false;
    setTimeout(() => $('rfNewName').focus(), 30);
}

function newRefKind() {
    const on = $('rfNewKind').querySelector('.seg-btn.is-active');
    return on ? on.dataset.kind : 'own';
}

async function saveNewRef() {
    const name = $('rfNewName').value.trim();
    if (!name) { $('rfNewName').focus(); return; }
    const src = newRefKind() === 'people' ? VET_KEY : '';
    const r = await apiSend('/api/herd/refs', 'POST', { name, src_key: src });
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    $('rfNewModal').hidden = true;
    openRef = r.id;
    toast(`Довідник «${r.name}» створено`, 'success');
    load();
}

$('rfAdd').addEventListener('click', openNewRef);
$('rfNewSave').addEventListener('click', saveNewRef);
$('rfNewName').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveNewRef(); });
$('rfNewKind').addEventListener('click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (!b) return;
    $('rfNewKind').querySelectorAll('.seg-btn').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
});
$('rfNewModal').querySelectorAll('[data-close]').forEach((x) =>
    x.addEventListener('click', () => { $('rfNewModal').hidden = true; }));

if ($('rfList')) load();
})();
