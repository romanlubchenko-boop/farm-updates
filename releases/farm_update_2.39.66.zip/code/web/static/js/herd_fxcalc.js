/* Обчислення формул параметрів ПРЯМО У ФОРМІ (Роман 2026-09-20: «хочу
   вставити формулу, щоб ціна множилася на кілограми і зʼявлялася сума»).

   Рахується лише ЧИСТА АРИФМЕТИКА від значень, які вже є перед очима:
   IF/AND/OR/NOT/IN/ISEMPTY/COALESCE/MIN/MAX/ROUND/ROUNDUP/ROUNDDOWN/ABS/INT/
   DAYS/MONTHS/TODAY/ADDDAYS + оператори. Усе, що читає історію тварини
   (COUNT, LAST, FIRST, VAL, VALDATE, AVGVAL, TOTAL, WITHDRAWAL, MILKING,
   POS, LABEL, GESTATION), у браузері НЕ рахується — там лишається значення,
   яке порахував сервер.

   ⚠️ Семантика повторює app/vet_pharmacy/herd_formula.py дослівно, інакше
   у формі й у картці стояли б різні числа:
   • порожній операнд робить порожнім ВЕСЬ вираз (вага без ціни → порожньо);
   • ділення на нуль — порожньо, а не помилка;
   • «^» на одному рівні з «*» і «/», ліво-асоціативне: 2*3^2 = 36;
   • INT усікає ДО НУЛЯ: INT(-2,7) = -2;
   • ROUND рахується по ДЕСЯТКОВОМУ запису (2.675 → 2.68), а не по float;
   • десяткова кома буває у ЗНАЧЕННЯХ полів, але не в тексті формули;
   • результат: ціле — без «,0», інакше 4 знаки.
*/
(function () {
    'use strict';

    const SERVER_ONLY = new Set(['COUNT', 'LAST', 'FIRST', 'VAL', 'VALDATE', 'AVGVAL',
        'TOTAL', 'WITHDRAWAL', 'MILKING', 'POS', 'LABEL', 'GESTATION']);
    const ARITY = {
        TODAY: [0, 0], DAYS: [2, 2], MONTHS: [2, 2], ADDDAYS: [2, 2], IF: [2, 3],
        AND: [1, 9], OR: [1, 9], NOT: [1, 1], IN: [2, 20], ISEMPTY: [1, 1],
        COALESCE: [1, 9], MIN: [1, 9], MAX: [1, 9], ROUND: [1, 2], ROUNDUP: [1, 2],
        ROUNDDOWN: [1, 2], ABS: [1, 1], INT: [1, 1],
    };
    const TOKEN = /\s*(\d+(?:\.\d+)?|"[^"]*"|'[^']*'|\[[^\]]*\]|[^\W\d][\w]*|<=|>=|<>|!=|[-+*/^(),;=<>])/y;

    function tokens(src) {
        let s = String(src || '').trim();
        if (s.startsWith('=')) s = s.slice(1);
        const out = [];
        TOKEN.lastIndex = 0;
        while (TOKEN.lastIndex < s.length) {
            const m = TOKEN.exec(s);
            if (!m) throw new Error('не зрозуміло');
            out.push(m[1] === '!=' ? '<>' : m[1]);
        }
        return out;
    }

    /* ── значення ── */
    const DASH = '—';
    function isEmpty(v) {
        if (v === null || v === undefined) return true;
        const s = String(v).trim();
        return s === '' || s === DASH;
    }
    function num(v) {
        if (v === true) return 1; if (v === false) return 0;
        if (typeof v === 'number') return isFinite(v) ? v : null;
        if (isEmpty(v)) return null;
        const s = String(v).trim().replace(',', '.');
        return /^-?\d+(\.\d+)?$/.test(s) ? parseFloat(s) : null;
    }
    function asDate(v) {
        if (isEmpty(v)) return null;
        const s = String(v).trim();
        return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : null;
    }
    function dnum(s) {               // дата → днів від епохи
        const [y, m, d] = s.split('-').map(Number);
        return Date.UTC(y, m - 1, d) / 86400000;
    }
    function dstr(n) {
        const d = new Date(n * 86400000);
        return d.toISOString().slice(0, 10);
    }
    function truthy(v) {
        if (isEmpty(v)) return false;
        const n = num(v);
        return n === null ? true : n !== 0;
    }
    /* округлення по десятковому запису — як Decimal на сервері */
    function roundDec(n, nd, how) {
        const p = Math.pow(10, nd);
        const x = n * p;
        // зсув на десятковий «хвіст», щоб 2.675*100 = 267.49999 не з'їдало копійку
        const fixed = parseFloat(x.toPrecision(15));
        let r;
        if (how === 'up') r = x < 0 ? Math.floor(fixed) : Math.ceil(fixed);
        else if (how === 'down') r = x < 0 ? Math.ceil(fixed) : Math.floor(fixed);
        else r = x < 0 ? -Math.round(-fixed) : Math.round(fixed);   // HALF_UP від нуля
        return r / p;
    }

    /* ── розбір і обчислення (рекурсивний спуск, без eval) ── */
    function make(ts, resolve) {
        let i = 0;
        const peek = () => ts[i];
        const eat = (t) => { if (ts[i] === t) { i++; return true; } return false; };

        function expr() {
            let v = conj();
            while (String(peek() || '').toLowerCase() === 'or') { i++; const b = conj(); v = (truthy(v) || truthy(b)) ? 1 : 0; }
            return v;
        }
        function conj() {
            let v = cmp();
            while (String(peek() || '').toLowerCase() === 'and') { i++; const b = cmp(); v = (truthy(v) && truthy(b)) ? 1 : 0; }
            return v;
        }
        function cmp() {
            const a = add();
            const op = peek();
            if (['=', '<>', '<', '>', '<=', '>='].includes(op)) {
                i++; const b = add();
                if (isEmpty(a) || isEmpty(b)) {
                    if (op === '=') return (isEmpty(a) && isEmpty(b)) ? 1 : 0;
                    if (op === '<>') return (isEmpty(a) && isEmpty(b)) ? 0 : 1;
                    return 0;
                }
                const da = asDate(a), db = asDate(b);
                let x, y;
                if (da && db) { x = dnum(da); y = dnum(db); }
                else { x = num(a); y = num(b); }
                if (x === null || y === null) { x = String(a).trim().toLowerCase(); y = String(b).trim().toLowerCase(); }
                const r = { '=': x === y, '<>': x !== y, '<': x < y, '>': x > y, '<=': x <= y, '>=': x >= y }[op];
                return r ? 1 : 0;
            }
            return a;
        }
        function add() {
            let v = mul();
            while (peek() === '+' || peek() === '-') { const op = ts[i++]; v = bin(op, v, mul()); }
            return v;
        }
        function mul() {
            let v = unary();
            while (peek() === '*' || peek() === '/' || peek() === '^') { const op = ts[i++]; v = bin(op, v, unary()); }
            return v;
        }
        function unary() {
            if (eat('-')) { const v = unary(); const n = num(v); return n === null ? null : -n; }
            if (eat('+')) return unary();
            return atom();
        }
        function bin(op, a, b) {
            if (isEmpty(a) || isEmpty(b)) return null;     // як на сервері
            const da = asDate(a), db = asDate(b), na = num(a), nb = num(b);
            if (op === '-' && da && db) return dnum(da) - dnum(db);
            if (da && nb !== null && (op === '+' || op === '-'))
                return dstr(dnum(da) + (op === '+' ? nb : -nb));
            if (db && na !== null && op === '+') return dstr(dnum(db) + na);
            if (na === null || nb === null) return op === '+' ? String(a) + String(b) : null;
            if (op === '+') return na + nb;
            if (op === '-') return na - nb;
            if (op === '*') return na * nb;
            if (op === '/') return nb === 0 ? null : na / nb;
            if (op === '^') return Math.pow(na, nb);
            return null;
        }
        function args() {
            const out = [];
            if (peek() === ')') { i++; return out; }
            for (;;) {
                out.push({ at: i, val: null });
                skipArg();
                if (eat(',') || eat(';')) continue;
                if (eat(')')) break;
                throw new Error('очікували ) або ,');
            }
            return out;
        }
        function skipArg() {           // IF рахує лише потрібну гілку → пропуск
            let depth = 0;
            while (i < ts.length) {
                const t = ts[i];
                if (t === '(') depth++;
                else if (t === ')') { if (!depth) break; depth--; }
                else if ((t === ',' || t === ';') && !depth) break;
                i++;
            }
        }
        function evalAt(pos) {
            const save = i; i = pos;
            const v = expr();
            i = save;
            return v;
        }
        function atom() {
            const t = ts[i];
            if (t === undefined) throw new Error('вираз обірвано');
            if (t === '(') { i++; const v = expr(); if (!eat(')')) throw new Error('бракує )'); return v; }
            if (/^\d/.test(t)) { i++; return parseFloat(t); }
            if (t[0] === '"' || t[0] === "'") { i++; return t.slice(1, -1); }
            if (t[0] === '[') { i++; return resolve(t.slice(1, -1).trim()); }
            if (/^[^\W\d][\w]*$/.test(t)) {
                const up = t.toUpperCase();
                if (ts[i + 1] === '(') {
                    if (SERVER_ONLY.has(up)) throw new Error('SERVER');
                    if (!ARITY[up]) throw new Error('невідома функція ' + t);
                    i += 2;
                    const a = args();
                    const [lo, hi] = ARITY[up];
                    if (a.length < lo || a.length > hi) throw new Error('аргументи ' + t);
                    return fn(up, a, evalAt);
                }
                i++;
                if (/^(TRUE|FALSE)$/i.test(t)) return /^TRUE$/i.test(t) ? 1 : 0;
                return resolve(t);
            }
            throw new Error('не зрозуміло «' + t + '»');
        }
        return { run: () => { const v = expr(); if (i < ts.length) throw new Error('зайве «' + ts[i] + '»'); return v; } };
    }

    function fn(name, a, ev) {
        const V = (k) => ev(a[k].at);
        if (name === 'IF') {
            if (truthy(V(0))) return V(1);
            return a.length > 2 ? V(2) : null;
        }
        if (name === 'TODAY') return new Date().toISOString().slice(0, 10);
        const vals = a.map((_, k) => V(k));
        if (name === 'AND') return vals.every(truthy) ? 1 : 0;
        if (name === 'OR') return vals.some(truthy) ? 1 : 0;
        if (name === 'NOT') return truthy(vals[0]) ? 0 : 1;
        if (name === 'ISEMPTY') return isEmpty(vals[0]) ? 1 : 0;
        if (name === 'COALESCE') { const f = vals.find((v) => !isEmpty(v)); return f === undefined ? null : f; }
        if (name === 'IN') {
            if (isEmpty(vals[0])) return 0;
            const x = num(vals[0]), s = String(vals[0]).trim().toLowerCase();
            return vals.slice(1).some((v) => {
                const y = num(v);
                return (x !== null && y !== null) ? x === y : String(v).trim().toLowerCase() === s;
            }) ? 1 : 0;
        }
        if (name === 'MIN' || name === 'MAX') {
            const live = vals.filter((v) => !isEmpty(v));
            const ds = live.map(asDate);
            if (live.length && ds.every(Boolean))
                return name === 'MIN' ? ds.slice().sort()[0] : ds.slice().sort().reverse()[0];
            const ns = live.map(num).filter((n) => n !== null);
            if (!ns.length) return null;
            return name === 'MIN' ? Math.min(...ns) : Math.max(...ns);
        }
        if (name === 'ABS') { const n = num(vals[0]); return n === null ? null : Math.abs(n); }
        if (name === 'INT') { const n = num(vals[0]); return n === null ? null : Math.trunc(n); }
        if (name === 'ROUND' || name === 'ROUNDUP' || name === 'ROUNDDOWN') {
            const n = num(vals[0]);
            if (n === null) return null;
            const nd = a.length > 1 ? (num(vals[1]) || 0) : 0;
            const how = name === 'ROUNDUP' ? 'up' : (name === 'ROUNDDOWN' ? 'down' : 'half');
            return roundDec(n, Math.trunc(nd), how);
        }
        if (name === 'DAYS' || name === 'MONTHS') {
            const d1 = asDate(vals[0]), d2 = asDate(vals[1]);
            if (!d1 || !d2) return null;
            if (name === 'DAYS') return dnum(d1) - dnum(d2);
            const [y1, m1, dd1] = d1.split('-').map(Number), [y2, m2, dd2] = d2.split('-').map(Number);
            let mo = (y1 * 12 + m1) - (y2 * 12 + m2);
            if (dd1 < dd2) mo -= 1;
            return mo;
        }
        if (name === 'ADDDAYS') {
            const d = asDate(vals[0]); const n = num(vals[1]);
            return (!d || n === null) ? null : dstr(dnum(d) + Math.trunc(n));
        }
        return null;
    }

    /* Значення для показу: ціле — без дробової частини, інакше 4 знаки */
    function toValue(v) {
        if (v === null || v === undefined) return null;
        if (typeof v === 'number') {
            if (!isFinite(v)) return null;
            return Number.isInteger(v) ? v : Number(v.toFixed(4));
        }
        return v;
    }

    /* Порахувати формулу. resolve(назва) → значення (рядок або число).
       Повертає {ok:true, value} | {ok:false, server:true} — коли формула
       спирається на історію тварини і рахується лише на сервері. */
    window.herdFxCalc = function (formula, resolve) {
        const src = String(formula || '').trim();
        if (!src) return { ok: false };
        try {
            return { ok: true, value: toValue(make(tokens(src), resolve).run()) };
        } catch (e) {
            return { ok: false, server: String(e && e.message) === 'SERVER' };
        }
    };
}());
