/* ============ Новий прихід: накладні + історія ============
   Дизайн — 1-в-1 «нова видача» (vydacha.js, макет mockups/vydacha_new.html);
   Роман 2026-09-11: «зроби прихід медикаментів по дизайну видачі».
   Кілька накладних одночасно (кожна зі своїм постачальником і датами),
   скан у активну, проведення кожної окремо — тим самим /api/receive/bulk,
   що й стара сторінка. Невідомий штрихкод одразу відкриває міні-форму
   нового товару. Чернетки переживають закриття сторінки. */

/* ---------- формати чисел ---------- */
const nf = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
const money = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const rawNum = (v) => +String(v).replace(/\s| /g, '').replace(',', '.') || 0;

/* Формат кількості за одиницею (довідник): кг → 0 000,00, шт/дози → 0 000 */
let unitFmt = {};
async function loadUnitFormats() {
    const r = await apiGet('/api/unit-formats');
    ((r && r.items) || []).forEach((i) => { unitFmt[(i.unit || '').trim().toLowerCase()] = i.decimals; });
}
const qtyDec = (unit) => {
    const d = unitFmt[(unit || '').trim().toLowerCase()];
    return typeof d === 'number' ? d : null;
};
const _qtyNF = {};
function fmtQty(x, unit) {
    const d = qtyDec(unit);
    if (d === null) return nf.format(x || 0);
    if (!_qtyNF[d]) _qtyNF[d] = new Intl.NumberFormat('uk-UA',
        { minimumFractionDigits: d, maximumFractionDigits: d });
    return _qtyNF[d].format(x || 0);
}
const todayISO = () => new Date().toISOString().slice(0, 10);
const r2 = (x) => Math.round(x * 100) / 100;
const r4 = (x) => Math.round(x * 10000) / 10000;
// показ ціни: до 4 знаків (щоб точна ціна від суми не виглядала округленою)
const priceF = new Intl.NumberFormat('uk-UA', { minimumFractionDigits: 2, maximumFractionDigits: 4 });

const prodByBarcode = (bc) => productsIndex.find((p) => p.barcode === bc);

/* ---------- стан: накладні ---------- */
let invSeq = 0;
let invs = [];
let activeId = 0;

function newInv() {
    invSeq += 1;
    return { id: invSeq, supplier: lastSupplier(), invoice_number: '',
             invoice_date: todayISO(), receipt_date: todayISO(),
             collapsed: false, items: [] };
    // items: {barcode, qty, vat, pnv (ціна без ПДВ), pv (ціна з ПДВ)}
}
const invOf = (id) => invs.find((x) => x.id === id);
const dmyStr = (d) => {
    const t = String(d || '').slice(0, 10);
    return t ? t.slice(8, 10) + '.' + t.slice(5, 7) + '.' + t.slice(0, 4) : '';
};
/* заголовок картки: постачальник · № від дати · дата приходу */
function invHeadMeta(v) {
    const no = String(v.invoice_number || '').replace(/^\s*№\s*/, '');
    const invDt = dmyStr(v.invoice_date);
    const rcvDt = dmyStr(v.receipt_date);
    return `<span class="h-who">${escapeHtml(v.supplier || 'Накладна ' + v.id)}</span>`
        + (no ? `<span class="h-dot">·</span><span class="h-meta">№ ${escapeHtml(no)}${invDt ? ' від ' + invDt : ''}</span>` : '')
        + (rcvDt ? `<span class="h-dot">·</span><span class="h-meta">${rcvDt}</span>` : '');
}
/* шапка заповнена? (постачальник, № і дата приходу — обовʼязкові) */
const headReady = (v) => !!(String(v.supplier || '').trim()
    && String(v.invoice_number || '').trim() && v.receipt_date);
/* курсор у перше порожнє обовʼязкове поле шапки накладної */
function focusHead(v) {
    for (const f of ['supplier', 'invoice_number', 'receipt_date']) {
        if (String(v[f] || '').trim()) continue;
        const el = document.querySelector(`.inv-hd input[data-hd="${f}"][data-inv="${v.id}"]`);
        if (el) { el.focus(); return; }
    }
    focusScan();
}
const invSumV = (v) => v.items.reduce((a, r) => a + r.qty * (r.pv || 0), 0);
const invSumNv = (v) => v.items.reduce((a, r) => a + r.qty * (r.pnv || 0), 0);
function invSumLine(v, bold) {
    const sv = invSumV(v), snv = invSumNv(v);
    const b = (x) => bold ? `<b>${x}</b>` : x;
    return `${v.items.length} поз. · ${b(money.format(snv) + ' ₴')} <span class="unit">без ПДВ</span>`
        + ` · ${b(money.format(sv) + ' ₴')} <span class="unit">з ПДВ</span>`
        + ` · <span class="unit">ПДВ</span> ${money.format(sv - snv)} ₴`;
}

function lastSupplier() {
    try { return localStorage.getItem('farm:pry_sup:' + location.pathname) || ''; }
    catch (e) { return ''; }
}
function rememberSupplier(s) {
    try { if (s) localStorage.setItem('farm:pry_sup:' + location.pathname, s); }
    catch (e) { /**/ }
}
function forgetSupplier() {
    try { localStorage.removeItem('farm:pry_sup:' + location.pathname); }
    catch (e) { /**/ }
}

/* Чернетки: накладні переживають закриття сторінки */
const DRAFT_KEY = 'farm:pry_drafts:' + location.pathname;
function saveDraft() {
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ seq: invSeq, invs })); }
    catch (e) { /**/ }
}
function loadDraft() {
    try {
        const d = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null');
        if (!d || !Array.isArray(d.invs)) return false;
        invSeq = d.seq || d.invs.length;
        invs = d.invs.filter((v) => v && Array.isArray(v.items));
        return invs.length > 0;
    } catch (e) { return false; }
}

/* ---------- елементи ---------- */
const scan = document.getElementById('recvScan');
const ac = document.getElementById('pryAc');
function focusScan() { if (scan) scan.focus(); }

/* ---------- постачальники (datalist, вільний ввід дозволений) ---------- */
let suppliers = [];
async function loadSuppliers() {
    const r = await apiGet('/api/suppliers');
    suppliers = ((r && r.items) || []).map((s) => s.name).filter(Boolean);
    const dl = document.getElementById('supplierList');
    if (dl) dl.innerHTML = suppliers.map((s) => `<option value="${escapeHtml(s)}">`).join('');
}

/* ---------- рендер накладних ---------- */
function render() {
    const box = document.getElementById('invs');
    if (!invs.length) {
        box.innerHTML = '<div class="inv"><div class="inv-empty">'
            + 'Натисніть «＋ Накладна», заповніть шапку (постачальник, №, дати) — і скануйте товари</div></div>';
        saveDraft();
        return;
    }
    box.innerHTML = invs.map((v) => {
        const n = v.items.length, act = v.id === activeId;
        const rows = v.items.map((r, i) => {
            const p = prodByBarcode(r.barcode);
            if (!p) return '';
            return `<tr>
                <td><b>${escapeHtml(p.name)}</b>
                    <span class="leftline">на складі ${nf.format(+p.total_qty || 0)} ${escapeHtml(p.unit || '')}</span></td>
                <td class="num" style="white-space:nowrap"><input class="qty" data-f="qty" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${fmtQty(r.qty, p.unit)}">
                    <span class="unit">${escapeHtml(p.unit || '')}</span></td>
                <td class="num"><input class="qty w-p" data-f="pnv" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${r.pnv ? priceF.format(r.pnv) : ''}" placeholder="0,00"></td>
                <td class="num"><input class="qty w-s" data-f="snv" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${r.pnv ? money.format(r.qty * r.pnv) : ''}" placeholder="0,00"></td>
                <td class="num"><input class="qty w-v" data-f="vat" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${nf.format(r.vat)}"></td>
                <td class="num"><input class="qty w-p" data-f="pv" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${r.pv ? priceF.format(r.pv) : ''}" placeholder="0,00"></td>
                <td class="num"><input class="qty w-s b" data-f="sv" data-inv="${v.id}" data-i="${i}"
                    type="text" inputmode="decimal" value="${r.pv ? money.format(r.qty * r.pv) : ''}" placeholder="0,00"></td>
                <td><button class="rm" data-inv="${v.id}" data-i="${i}" title="Прибрати">✕</button></td>
            </tr>`;
        }).join('');
        const hdInputs = `<span class="inv-hd">
              <label class="f-sup">Постачальник *
                <input type="text" list="supplierList" data-hd="supplier" data-inv="${v.id}"
                       value="${escapeHtml(v.supplier)}" placeholder="почніть вводити…"></label>
              <label class="f-no">№ накладної *
                <input type="text" data-hd="invoice_number" data-inv="${v.id}"
                       value="${escapeHtml(v.invoice_number)}"></label>
              <label class="f-dt">Дата накладної
                <input type="date" data-hd="invoice_date" data-inv="${v.id}" value="${v.invoice_date}"></label>
              <label class="f-dt">Дата приходу *
                <input type="date" data-hd="receipt_date" data-inv="${v.id}" value="${v.receipt_date}"></label>
            </span>`;
        return `<div class="inv${act ? ' is-active' : ''}${v.collapsed ? ' is-collapsed' : ''}" data-inv="${v.id}">
          <div class="inv-head" data-inv="${v.id}">
            <span class="inv-caret">▾</span>
            ${v.collapsed ? `<span class="h-hd">${invHeadMeta(v)}</span>` : hdInputs}
            <span class="inv-sum">${invSumLine(v)}</span>
            <button class="inv-del" data-inv="${v.id}" title="Видалити накладну"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/></svg></button>
          </div>
          <div class="inv-body">
            <div class="inv-scroll">
            <table>
              <colgroup><col class="c-name"><col class="c-qty"><col class="c-pnv">
                <col class="c-sum"><col class="c-vat"><col class="c-pv"><col class="c-sum"><col class="c-rm"></colgroup>
              <thead><tr>
                <th>${window.ITEM_WORD || 'Товар'}</th>
                <th class="num" style="padding-right:44px">К-сть</th>
                <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th>
                <th class="num">ПДВ %</th><th class="num">Ціна з ПДВ</th>
                <th class="num">Сума з ПДВ</th><th></th>
              </tr></thead>
              <tbody>${rows || '<tr><td colspan="8" class="inv-empty">Скануйте товар — він потрапить сюди</td></tr>'}</tbody>
            </table>
            </div>
            <div class="inv-foot">
              <span class="t">${invSumLine(v, true)}</span>
              <span class="spacer"></span>
              <button class="inv-go" data-inv="${v.id}" ${n ? '' : 'disabled'}>Провести прихід</button>
            </div>
          </div>
        </div>`;
    }).join('');
    bindInvs();
    saveDraft();
}

function focusCell(inv, i, f) {
    const el = document.querySelector(`.qty[data-inv="${inv}"][data-i="${i}"][data-f="${f}"]`);
    if (el) { el.focus(); el.select(); }
}

/* перерахунок цін: заповнили одну — друга рахується за ставкою ПДВ */
function recalc(r, changed) {
    const k = 1 + (r.vat || 0) / 100;
    if (changed === 'pnv') r.pv = r4(r.pnv * k);
    else if (changed === 'pv') r.pnv = r4(r.pv / k);
    else if (changed === 'vat') {
        if (r.pnv) r.pv = r4(r.pnv * k);
        else if (r.pv) r.pnv = r4(r.pv / k);
    }
}

function bindInvs() {
    const box = document.getElementById('invs');
    box.querySelectorAll('.inv-head').forEach((h) => h.addEventListener('click', (e) => {
        if (e.target.closest('.inv-del') || e.target.closest('.inv-hd')) return;
        const id = +h.dataset.inv, v = invOf(id);
        if (activeId !== id) { activeId = id; v.collapsed = false; }
        else v.collapsed = !v.collapsed;
        render();
        if (!v.collapsed) focusScan();
    }));
    box.querySelectorAll('.inv-hd input').forEach((inp) => {
        const v = invOf(+inp.dataset.inv);
        inp.addEventListener('focus', () => {
            if (activeId !== v.id) { activeId = v.id; }
            // № одразу видно в полі
            if (inp.dataset.hd === 'invoice_number' && !inp.value.trim()) {
                inp.value = '№ '; v.invoice_number = '№ ';
            }
        });
        inp.addEventListener('input', () => {
            // № накладної: «№ » підставляється саме
            if (inp.dataset.hd === 'invoice_number' && inp.value && !/^\s*№/.test(inp.value)) {
                inp.value = '№ ' + inp.value.replace(/^\s+/, '');
            }
            v[inp.dataset.hd] = inp.value;
            inp.classList.remove('badf');
            if (inp.dataset.hd === 'supplier') rememberSupplier(inp.value.trim());
            // шапку в заголовку картки оновлюємо мʼяко, без перерендеру
            const head = inp.closest('.inv').querySelector('.inv-head .h-hd');
            if (head) head.innerHTML = invHeadMeta(v);
            saveDraft();
        });
        inp.addEventListener('blur', () => {
            // лишився самий «№» без номера — прибираємо
            if (inp.dataset.hd === 'invoice_number' && /^\s*№\s*$/.test(inp.value)) {
                inp.value = ''; v.invoice_number = ''; saveDraft();
            }
        });
        inp.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            // Enter веде по шапці: постачальник → № → дата накладної → дата приходу → сканер
            const order = ['supplier', 'invoice_number', 'invoice_date', 'receipt_date'];
            const next = order[order.indexOf(inp.dataset.hd) + 1];
            const el = next && document.querySelector(`.inv-hd input[data-hd="${next}"][data-inv="${v.id}"]`);
            if (el) el.focus(); else focusScan();
        });
    });
    box.querySelectorAll('.qty').forEach((q) => {
        const v = invOf(+q.dataset.inv);
        const row = () => v.items[+q.dataset.i];
        const f = q.dataset.f;
        const unitOf = () => {
            const p = prodByBarcode(row().barcode);
            return p ? p.unit : '';
        };
        // значення поля: суми — похідні від к-сті й ціни
        const val = () => {
            const r = row();
            if (f === 'snv') return r.qty * (r.pnv || 0);
            if (f === 'sv') return r.qty * (r.pv || 0);
            return r[f];
        };
        q.addEventListener('input', () => {
            // захист: у числових полях лише цифри та кома/крапка;
            // цілочисельні одиниці (шт, дози) — взагалі без коми
            const re = (f === 'qty' && qtyDec(unitOf()) === 0) ? /[^0-9]/g : /[^0-9.,]/g;
            const clean = q.value.replace(re, '');
            if (clean !== q.value) {
                const pos = Math.max(0, (q.selectionStart || clean.length) - (q.value.length - clean.length));
                q.value = clean;
                try { q.setSelectionRange(pos, pos); } catch (e) { /**/ }
            }
            const r = row(), x = rawNum(q.value);
            if (f === 'snv') { r.pnv = r.qty ? r4(x / r.qty) : 0; recalc(r, 'pnv'); }
            else if (f === 'sv') { r.pv = r.qty ? r4(x / r.qty) : 0; recalc(r, 'pv'); }
            else { r[f === 'qty' ? 'qty' : f] = x; recalc(r, f); }
            softRefresh(q, v);
        });
        q.addEventListener('focus', () => {
            activeId = v.id;
            const x = val();
            q.value = x ? String(r4(x)).replace('.', ',') : '';
            q.select();
        });
        q.addEventListener('blur', () => {
            const x = val();
            q.value = f === 'qty' ? fmtQty(x, unitOf())
                : f === 'vat' ? nf.format(x || 0)
                : (f === 'pnv' || f === 'pv') ? (x ? priceF.format(x) : '')
                : (x ? money.format(x) : '');
        });
        q.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter') return;
            e.preventDefault();
            // цикл: к-сть → ціна з ПДВ → назад до сканера
            if (f === 'qty') { render(); focusCell(v.id, +q.dataset.i, 'pv'); }
            else { render(); focusScan(); }
        });
    });
    box.querySelectorAll('.rm').forEach((b) => b.onclick = () => {
        invOf(+b.dataset.inv).items.splice(+b.dataset.i, 1);
        render(); focusScan();
    });
    box.querySelectorAll('.inv-del').forEach((b) => b.onclick = async (e) => {
        e.stopPropagation();
        const v = invOf(+b.dataset.inv);
        const what = v.items.length
            ? `${v.items.length} поз. — позиції не проведуться` : 'порожня';
        if (!await confirmAction(`Видалити накладну (${what})?`)) return;
        invs = invs.filter((x) => x !== v);
        forgetSupplier();   // шапка видаленої накладної не підставляється в нову
        if (activeId === v.id && invs.length) activeId = invs[0].id;
        render(); focusScan();
    });
    box.querySelectorAll('.inv-go').forEach((b) => b.onclick = () => processInvoice(+b.dataset.inv));
}

/* мʼяке оновлення сум без перерендеру (щоб не губити фокус) */
function softRefresh(q, v) {
    const r = v.items[+q.dataset.i];
    const tr = q.closest('tr');
    // сусідні поля оновлюємо, лише якщо вони НЕ у фокусі
    ['pnv', 'snv', 'vat', 'pv', 'sv'].forEach((f) => {
        const el = tr.querySelector(`.qty[data-f="${f}"]`);
        if (!el || el === document.activeElement) return;
        const x = f === 'snv' ? r.qty * (r.pnv || 0)
            : f === 'sv' ? r.qty * (r.pv || 0) : r[f];
        el.value = f === 'vat' ? nf.format(x || 0)
            : (f === 'pnv' || f === 'pv') ? (x ? priceF.format(x) : '')
            : (x ? money.format(x) : '');
    });
    const card = q.closest('.inv');
    card.querySelector('.inv-sum').innerHTML = invSumLine(v);
    card.querySelector('.inv-foot .t').innerHTML = invSumLine(v, true);
    saveDraft();
}

/* ---------- додавання товару ---------- */
function addRow(p) {
    if (scan) scan.value = '';
    if (ac) ac.hidden = true;
    let v = invOf(activeId);
    if (!v) { v = newInv(); invs.push(v); activeId = v.id; }
    v.collapsed = false;
    if (!headReady(v)) {
        // спершу шапка накладної, потім медикаменти
        render();
        toast('Спершу заповніть шапку накладної, потім скануйте товар', 'warn');
        focusHead(v);
        return;
    }
    const ex = v.items.findIndex((r) => r.barcode === p.barcode);
    if (ex >= 0) {
        render(); focusCell(v.id, ex, 'qty');
        toast('Товар уже в цій накладній — виправте кількість');
        return;
    }
    // ціни підставляються з останньої закупівлі — їх можна виправити
    const pnv = +p.avg_price_in_no_vat || 0;
    const vat = 20;
    v.items.push({ barcode: p.barcode, qty: 1, vat,
                   pnv, pv: pnv ? r4(pnv * (1 + vat / 100)) : 0 });
    render(); focusCell(v.id, v.items.length - 1, 'qty');
}

/* ---------- новий товар (невідомий штрихкод) ---------- */
function openNewProduct(code) {
    const m = document.getElementById('npModal');
    document.getElementById('npBarcode').value = code || '';
    document.getElementById('npName').value = '';
    document.getElementById('npUnit').value = (window.API_BASE === '/f') ? 'кг' : 'шт';
    if (window.openModal) openModal('npModal'); else m.hidden = false;
    setTimeout(() => document.getElementById('npName').focus(), 60);
}
document.getElementById('npSave').addEventListener('click', async () => {
    const name = document.getElementById('npName').value.trim();
    const barcode = document.getElementById('npBarcode').value.trim();
    if (!name) { toast('Вкажіть назву', 'warn'); return; }
    if (!barcode) { toast('Вкажіть штрихкод', 'warn'); return; }
    const r = await apiSend('/api/products', 'POST',
        { name, barcode, unit: document.getElementById('npUnit').value.trim() || 'шт' });
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    toast('Товар створено', 'success');
    if (window.closeModal) closeModal('npModal');
    else document.getElementById('npModal').hidden = true;
    await loadProductsIndex();
    const p = prodByBarcode(r.barcode || barcode);
    if (p) addRow(p);
});
document.getElementById('npName').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); document.getElementById('npSave').click(); }
});

/* ---------- проведення накладної ---------- */
async function processInvoice(id) {
    const v = invOf(id);
    if (!v || !v.items.length) return;
    // перевірки — як на старій сторінці: постачальник, №, дата приходу, ціни
    const need = [['supplier', 'Вкажіть постачальника'],
                  ['invoice_number', 'Вкажіть номер накладної'],
                  ['receipt_date', 'Вкажіть дату приходу']];
    for (const [f, msg] of need) {
        if (!String(v[f] || '').trim()) {
            const el = document.querySelector(`.inv-hd input[data-hd="${f}"][data-inv="${id}"]`);
            if (el) { el.classList.add('badf'); el.focus(); }
            toast(msg, 'warn');
            return;
        }
    }
    for (let i = 0; i < v.items.length; i += 1) {
        const r = v.items[i];
        if (!(r.qty > 0)) { focusCell(id, i, 'qty'); toast(`Рядок ${i + 1}: вкажіть кількість`, 'warn'); return; }
        if (!(r.pv > 0 || r.pnv > 0)) { focusCell(id, i, 'pv'); toast(`Рядок ${i + 1}: вкажіть ціну закупки`, 'warn'); return; }
    }
    const btn = document.querySelector(`.inv-go[data-inv="${id}"]`);
    if (btn) btn.disabled = true;
    const payload = {
        supplier_name: v.supplier.trim(),
        invoice_number: v.invoice_number.trim(),
        invoice_date: v.invoice_date || '',
        receipt_date: v.receipt_date || '',
        items: v.items.map((r) => ({
            barcode: r.barcode, qty: r.qty,
            lot_number: '', expires_on: '',
            vat_rate: r.vat, price_in: r.pv, price_in_no_vat: r.pnv,
        })),
    };
    let r = await apiSend('/api/receive/bulk', 'POST', payload);
    // накладна з таким номером від цього постачальника вже є — питаємо
    // (буває й чесно: довезли решту тією самою накладною)
    if (r && !r.ok && r.dup) {
        if (await confirmAction(`${r.error}\n\nУсе одно зарахувати ще раз?`,
            { ok: 'Усе одно зарахувати' })) {
            r = await apiSend('/api/receive/bulk', 'POST',
                Object.assign({}, payload, { force: true }));
        } else {
            if (btn) btn.disabled = false;
            return;
        }
    }
    if (!r || !r.ok) {
        if (btn) btn.disabled = false;
        toast((r && r.error) || 'Помилка проведення', 'error');
        return;
    }
    if (r.errors && r.errors.length) toast(`Зараховано ${r.added}, з помилками: ${r.errors[0]}`, 'warn');
    else toast(`Накладну проведено: ${r.added} поз. на ${money.format(+r.total || 0)} ₴`, 'success');
    invs = invs.filter((x) => x !== v);
    if (activeId === id && invs.length) activeId = invs[0].id;
    histDirty = true;
    await loadProductsIndex();
    render();
    focusScan();
}

/* ---------- пошук / сканування ---------- */
let hot = 0, hits = [];
function renderAc(q) {
    ac.innerHTML = hits.map((p, k) => `<div class="ac-row${k === hot ? ' hot' : ''}" data-bc="${escapeHtml(p.barcode)}">
        <span class="ac-name">${escapeHtml(p.name)}</span>
        <span class="ac-stock">залишок ${nf.format(+p.total_qty || 0)} ${escapeHtml(p.unit || '')}</span>
        <span class="ac-price">${money.format(+p.avg_price_in_no_vat || 0)} ₴</span>
    </div>`).join('')
        + `<div class="ac-row ac-newrow" data-new="${escapeHtml(q)}">
             <span class="ac-name ac-new">＋ Створити новий товар${q ? ' «' + escapeHtml(q) + '»' : ''}</span>
           </div>`;
    ac.hidden = false;
    ac.querySelectorAll('.ac-row').forEach((r) => r.onclick = () => {
        if (r.dataset.new !== undefined) { openNewProduct(/^\d{6,}$/.test(q) ? q : ''); return; }
        const p = prodByBarcode(r.dataset.bc);
        if (p) addRow(p);
    });
}
if (scan) {
    scan.addEventListener('input', () => {
        const q = scan.value.trim();
        if (q.length < 2) { ac.hidden = true; hits = []; return; }
        hits = searchProducts(q);
        hot = 0; renderAc(q);
    });
    scan.addEventListener('keydown', (e) => {
        const q = scan.value.trim();
        if (ac.hidden && e.key === 'Enter' && q) {
            const p = prodByBarcode(q) || (hits[0] || null);
            if (p) addRow(p);
            else openNewProduct(/^\d{6,}$/.test(q) ? q : '');   // скан невідомого коду
            return;
        }
        if (ac.hidden) return;
        if (e.key === 'ArrowDown') { hot = Math.min(hot + 1, hits.length - 1); renderAc(q); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { hot = Math.max(hot - 1, 0); renderAc(q); e.preventDefault(); }
        else if (e.key === 'Enter') {
            e.preventDefault();
            if (hits[hot]) addRow(hits[hot]);
            else openNewProduct(/^\d{6,}$/.test(q) ? q : '');
        } else if (e.key === 'Escape') { ac.hidden = true; }
    });
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.scanbox')) ac.hidden = true;
    });
}

/* камера телефона (той самий ZXing, що й у видачі) */
if (window.attachScanShortcut) {
    attachScanShortcut(scan, document.getElementById('cameraScanBtn'));
}
(function () {
    const camBtn = document.getElementById('cameraScanBtn');
    if (!camBtn || !window.openCameraScanner) return;
    camBtn.addEventListener('click', () => {
        const scanner = openCameraScanner(async (code) => {
            const p = prodByBarcode(code);
            if (p) addRow(p);
            if (scanner) scanner.setStatus(p ? '✓ Додано: ' + p.name : '✗ Не знайдено: ' + code);
            if (window.scanBeep) window.scanBeep(!!p);
            const a = document.activeElement;
            if (a && a.blur) a.blur();
        });
    });
})();

/* ---------- верхні керування ---------- */
document.getElementById('addInv').onclick = () => {
    const v = newInv(); invs.push(v); activeId = v.id; render(); focusHead(v);
};
document.getElementById('collapseAll').onclick = () => {
    const anyOpen = invs.some((v) => !v.collapsed);
    invs.forEach((v) => { v.collapsed = anyOpen; });
    render(); focusScan();
};

/* ---------- розділи Прихід / Історія ---------- */
let histDirty = true;
document.querySelectorAll('#viewSeg .cat-tab').forEach((b) => b.onclick = () => {
    document.querySelectorAll('#viewSeg .cat-tab').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
    const hist = b.dataset.view === 'hist';
    document.getElementById('viewRecv').hidden = hist;
    document.getElementById('viewHist').hidden = !hist;
    if (hist) { if (histDirty) loadHist(); } else focusScan();
});

/* ---------- історія ---------- */
let histPer = 'last';   // приходи не щоденні — типово останні накладні
let histInvs = [];

function histBounds() {
    // дата за місцевим часом (toISOString дає UTC і вночі зсуває день)
    const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const t = new Date();
    if (histPer === 'last') return ['', ''];      // без фільтра — останні 30
    if (histPer === 'today') return [iso(t), iso(t)];
    if (histPer === 'week') { const f = new Date(t); f.setDate(f.getDate() - 6); return [iso(f), iso(t)]; }
    if (histPer === 'month') { const f = new Date(t.getFullYear(), t.getMonth(), 1); return [iso(f), iso(t)]; }
    if (histPer === 'prevmonth') {
        const f = new Date(t.getFullYear(), t.getMonth() - 1, 1);
        const l = new Date(t.getFullYear(), t.getMonth(), 0);
        return [iso(f), iso(l)];
    }
    return [document.getElementById('histFrom').value || '',
            document.getElementById('histTo').value || ''];
}

async function loadHist() {
    const [d1, d2] = histBounds();
    const box = document.getElementById('histRows');
    box.innerHTML = '<div class="inv"><div class="inv-empty">Завантаження…</div></div>';
    const qs = (d1 || d2) ? `?from=${encodeURIComponent(d1)}&to=${encodeURIComponent(d2)}` : '';
    const r = await apiGet('/api/receipts/invoices' + qs);
    histInvs = (r && r.items) || [];
    if (histPer === 'last') histInvs = histInvs.slice(0, 30);
    histEdit = null;             // після перезавантаження правити нема чого
    histDirty = false;
    renderHist(document.getElementById('histQ').value);
}

/* ---------- редагування проведеної накладної ----------
   Історія — не лише перегляд: накладну виправляють на тому самому місці,
   де її бачать. Картка перемикається в той самий вигляд, що й чернетка
   (шапка полями, к-сть і ціни в рядках), і зберігається трьома кроками:
   прибрані позиції → шапка на всі рядки → змінені рядки. */
let histEdit = null;                 // чернетка правки або null

const invKey = (o) => (o.items || []).map((i) => i.batch_id).join(',');
// ціна без ПДВ: збережена, інакше знімаємо ставку з ціни з ПДВ
function pnvOf(i) {
    const pv = +i.price_in || 0;
    const pnv = +i.price_in_no_vat || 0;
    if (pnv) return pnv;
    const vat = (i.vat_rate === null || i.vat_rate === undefined || i.vat_rate === '') ? 20 : +i.vat_rate;
    return vat > 0 ? pv / (1 + vat / 100) : pv;
}
const canEditInv = (o) => (o.items || []).length
    && (o.items || []).every((i) => i.can_edit !== false && i.batch_id);

function startEdit(o) {
    histEdit = {
        key: invKey(o),
        supplier: o.supplier || '',
        invoice_number: o.invoice_number || '',
        invoice_date: (o.invoice_date || '').slice(0, 10),
        receipt_date: (o.receipt_date || o.invoice_date || '').slice(0, 10),
        items: (o.items || []).map((i) => {
            const vat = (i.vat_rate === null || i.vat_rate === undefined || i.vat_rate === '')
                ? 20 : +i.vat_rate;
            const r = { batch_id: i.batch_id, name: i.name || '', unit: i.unit || '',
                        qty: +i.received_qty || 0, pnv: r4(pnvOf(i)), pv: +i.price_in || 0,
                        vat, consumed: +i.consumed_qty || 0,
                        lot_number: i.lot_number || '', expires_on: i.expires_on || '',
                        note: i.user_note || '', gone: false };
            r.o = { qty: r.qty, pnv: r.pnv, pv: r.pv, vat: r.vat };
            return r;
        }),
    };
    renderHist(document.getElementById('histQ').value);
}

/* ---------- історія ---------- */
function renderHist(q) {
    const box = document.getElementById('histRows');
    const qq = (q || '').toLowerCase();
    const list = histInvs.filter((o) => !qq
        || String(o.invoice_number || '').toLowerCase().includes(qq)
        || (o.supplier || '').toLowerCase().includes(qq)
        || (o.items || []).some((i) => (i.name || '').toLowerCase().includes(qq)));
    if (!list.length) {
        box.innerHTML = '<div class="inv"><div class="inv-empty">За цей період приходів немає</div></div>';
        return;
    }
    box.innerHTML = list.map((o, oi) => (histEdit && histEdit.key === invKey(o))
        ? editCard() : viewCard(o, oi)).join('');
    box.querySelectorAll('.h-op:not(.is-edit) .inv-head').forEach((h) => h.onclick = (e) => {
        if (e.target.closest('.h-ed')) return;
        h.closest('.h-op').classList.toggle('is-collapsed');
    });
    box.querySelectorAll('.h-ed').forEach((b) => b.onclick = (e) => {
        e.stopPropagation();
        startEdit(histInvs[+b.dataset.oi]);
    });
    if (histEdit) bindEdit();
}

function viewCard(o, oi) {
    const items = o.items || [];
    const sumV = items.reduce((a, i) => a + (+i.received_qty || 0) * (+i.price_in || 0), 0);
    const sumNV = items.reduce((a, i) => a + (+i.received_qty || 0) * pnvOf(i), 0);
    const rows = items.map((i) => `<tr>
        <td><b>${escapeHtml(i.name)}</b>${i.lot_number
            ? `<span class="leftline">партія ${escapeHtml(i.lot_number)}</span>` : ''}</td>
        <td class="num">${nf.format(+i.received_qty || 0)} <span class="unit">${escapeHtml(i.unit || '')}</span></td>
        <td class="num">${money.format(pnvOf(i))}</td>
        <td class="num">${money.format((+i.received_qty || 0) * pnvOf(i))}</td>
        <td class="num">${money.format(+i.price_in || 0)}</td>
        <td class="num"><b>${money.format((+i.received_qty || 0) * (+i.price_in || 0))}</b></td>
    </tr>`).join('');
    const invDt = dmyStr(o.invoice_date);
    const rcvDt = dmyStr(o.receipt_date || o.invoice_date);
    const ed = canEditInv(o)
        ? `<button class="h-ed" data-oi="${histInvs.indexOf(o)}" title="Виправити накладну"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></button>` : '';
    return `<div class="inv h-op is-collapsed">
      <div class="inv-head" data-oi="${oi}">
        <span class="inv-caret">▾</span>
        <span class="tag in">Прихід</span>
        <span class="h-who">${escapeHtml(o.supplier || 'без постачальника')}</span>
        ${o.invoice_number ? `<span class="h-dot">·</span><span class="h-meta">№ ${escapeHtml(String(o.invoice_number).replace(/^\s*№\s*/, ''))}${invDt ? ' від ' + invDt : ''}</span>` : ''}
        ${rcvDt ? `<span class="h-dot">·</span><span class="h-meta">${rcvDt}</span>` : ''}
        <span class="inv-sum">${items.length} поз. · ${money.format(sumNV)} ₴ <span class="unit">без ПДВ</span> · ${money.format(sumV)} ₴ <span class="unit">з ПДВ</span> · <span class="unit">ПДВ</span> ${money.format(sumV - sumNV)} ₴</span>
        ${ed}
      </div>
      <div class="inv-body">
        <div class="inv-scroll">
        <table>
          <colgroup><col class="c-name"><col class="c-qty"><col class="c-pnv"><col class="c-sum"><col class="c-pv"><col class="c-sum"></colgroup>
          <thead><tr><th>${window.ITEM_WORD || 'Товар'}</th><th class="num">К-сть</th>
            <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th>
            <th class="num">Ціна з ПДВ</th><th class="num">Сума з ПДВ</th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><td>Всього</td><td></td><td></td>
            <td class="num">${money.format(sumNV)}</td><td></td>
            <td class="num">${money.format(sumV)}</td></tr></tfoot>
        </table>
        </div>
      </div>
    </div>`;
}

/* сума накладної в режимі правки (прибрані рядки не рахуються) */
function edSumLine(foot) {
    const live = histEdit.items.filter((r) => !r.gone);
    const nv = live.reduce((a, r) => a + r.qty * (r.pnv || 0), 0);
    const v = live.reduce((a, r) => a + r.qty * (r.pv || 0), 0);
    const b = (x) => foot ? `<b>${money.format(x)} ₴</b>` : `${money.format(x)} ₴`;
    return `${live.length} поз. · ${b(nv)} <span class="unit">без ПДВ</span> · ${b(v)} <span class="unit">з ПДВ</span> · <span class="unit">ПДВ</span> ${money.format(v - nv)} ₴`;
}

function editCard() {
    const e = histEdit;
    const rows = e.items.map((r, i) => `<tr class="${r.gone ? 'ed-gone' : ''}">
        <td><b>${escapeHtml(r.name)}</b>
            <span class="unit">${escapeHtml(r.unit || '')}</span>
            ${r.consumed > 0 ? `<span class="leftline">уже видано ${fmtQty(r.consumed, r.unit)} ${escapeHtml(r.unit || '')} — менше не поставити</span>` : ''}</td>
        <td class="num"><input class="qty eq" data-i="${i}" data-f="qty" type="text"
            inputmode="decimal" value="${fmtQty(r.qty, r.unit)}"></td>
        <td class="num"><input class="qty eq w-p" data-i="${i}" data-f="pnv" type="text"
            inputmode="decimal" value="${r.pnv ? priceF.format(r.pnv) : ''}" placeholder="0,00"></td>
        <td class="num"><input class="qty eq w-s" data-i="${i}" data-f="snv" type="text"
            inputmode="decimal" value="${r.pnv ? money.format(r.qty * r.pnv) : ''}" placeholder="0,00"></td>
        <td class="num"><input class="qty eq w-v" data-i="${i}" data-f="vat" type="text"
            inputmode="decimal" value="${nf.format(r.vat)}"></td>
        <td class="num"><input class="qty eq w-p" data-i="${i}" data-f="pv" type="text"
            inputmode="decimal" value="${r.pv ? priceF.format(r.pv) : ''}" placeholder="0,00"></td>
        <td class="num"><input class="qty eq w-s b" data-i="${i}" data-f="sv" type="text"
            inputmode="decimal" value="${r.pv ? money.format(r.qty * r.pv) : ''}" placeholder="0,00"></td>
        <td><button class="rm ed-rm" data-i="${i}"
            title="${r.consumed > 0 ? 'З цієї партії вже видавали — позицію не прибрати'
                    : (r.gone ? 'Повернути позицію' : 'Прибрати позицію з накладної')}"
            ${r.consumed > 0 ? 'disabled' : ''}>${r.gone ? '↺' : '✕'}</button></td>
    </tr>`).join('');
    return `<div class="inv h-op is-edit is-active">
      <div class="inv-head">
        <span class="tag ed">Правка</span>
        <span class="inv-hd">
          <label class="f-sup">Постачальник *
            <input type="text" list="supplierList" data-ed="supplier"
                   value="${escapeHtml(e.supplier)}"></label>
          <label class="f-no">№ накладної *
            <input type="text" data-ed="invoice_number" value="${escapeHtml(e.invoice_number)}"></label>
          <label class="f-dt">Дата накладної
            <input type="date" data-ed="invoice_date" value="${e.invoice_date}"></label>
          <label class="f-dt">Дата приходу *
            <input type="date" data-ed="receipt_date" value="${e.receipt_date}"></label>
        </span>
      </div>
      <div class="inv-body">
        <div class="inv-scroll">
        <table>
          <colgroup><col class="c-name"><col class="c-qty"><col class="c-pnv">
            <col class="c-sum"><col class="c-vat"><col class="c-pv"><col class="c-sum"><col class="c-rm"></colgroup>
          <thead><tr>
            <th>${window.ITEM_WORD || 'Товар'}</th>
            <th class="num" style="padding-right:44px">К-сть</th>
            <th class="num">Ціна без ПДВ</th><th class="num">Сума без ПДВ</th>
            <th class="num">ПДВ %</th><th class="num">Ціна з ПДВ</th>
            <th class="num">Сума з ПДВ</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
        </div>
        <div class="inv-foot">
          <button type="button" class="ed-kill">Видалити накладну</button>
          <span class="t">${edSumLine(true)}</span>
          <span class="spacer"></span>
          <button type="button" class="db-btn ed-cancel">Скасувати</button>
          <button type="button" class="inv-go ed-save">Зберегти зміни</button>
        </div>
      </div>
    </div>`;
}

function bindEdit() {
    const box = document.getElementById('histRows');
    const e = histEdit;
    box.querySelectorAll('.inv-hd input[data-ed]').forEach((inp) => {
        inp.addEventListener('input', () => {
            e[inp.dataset.ed] = inp.value;
            inp.classList.remove('badf');
        });
    });
    box.querySelectorAll('.eq').forEach((q) => {
        const r = () => e.items[+q.dataset.i];
        const f = q.dataset.f;
        const val = () => {
            const x = r();
            if (f === 'snv') return x.qty * (x.pnv || 0);
            if (f === 'sv') return x.qty * (x.pv || 0);
            return x[f];
        };
        q.addEventListener('input', () => {
            const re = (f === 'qty' && qtyDec(r().unit) === 0) ? /[^0-9]/g : /[^0-9.,]/g;
            const clean = q.value.replace(re, '');
            if (clean !== q.value) {
                const pos = Math.max(0, (q.selectionStart || clean.length) - (q.value.length - clean.length));
                q.value = clean;
                try { q.setSelectionRange(pos, pos); } catch (err) { /**/ }
            }
            const x = r(), n = rawNum(q.value);
            if (f === 'snv') { x.pnv = x.qty ? r4(n / x.qty) : 0; recalc(x, 'pnv'); }
            else if (f === 'sv') { x.pv = x.qty ? r4(n / x.qty) : 0; recalc(x, 'pv'); }
            else { x[f] = n; recalc(x, f); }
            edSoftRefresh(q, x);
        });
        q.addEventListener('focus', () => {
            const x = val();
            q.value = x ? String(r4(x)).replace('.', ',') : '';
            q.select();
        });
        q.addEventListener('blur', () => {
            const x = val();
            q.value = f === 'qty' ? fmtQty(x, r().unit)
                : f === 'vat' ? nf.format(x || 0)
                : (f === 'pnv' || f === 'pv') ? (x ? priceF.format(x) : '')
                : (x ? money.format(x) : '');
        });
    });
    box.querySelectorAll('.ed-rm').forEach((b) => b.onclick = () => {
        const r = e.items[+b.dataset.i];
        if (r.consumed > 0) return;
        r.gone = !r.gone;
        renderHist(document.getElementById('histQ').value);
    });
    const cancel = box.querySelector('.ed-cancel');
    if (cancel) cancel.onclick = () => {
        histEdit = null;
        renderHist(document.getElementById('histQ').value);
    };
    const save = box.querySelector('.ed-save');
    if (save) save.onclick = () => saveEdit(save);
    const kill = box.querySelector('.ed-kill');
    if (kill) kill.onclick = () => killInvoice();
}

/* сусідні поля рядка оновлюємо без перерендеру — щоб не губився фокус */
function edSoftRefresh(q, r) {
    const tr = q.closest('tr');
    ['pnv', 'snv', 'vat', 'pv', 'sv'].forEach((f) => {
        const el = tr.querySelector(`.eq[data-f="${f}"]`);
        if (!el || el === document.activeElement) return;
        const x = f === 'snv' ? r.qty * (r.pnv || 0)
            : f === 'sv' ? r.qty * (r.pv || 0) : r[f];
        el.value = f === 'vat' ? nf.format(x || 0)
            : (f === 'pnv' || f === 'pv') ? (x ? priceF.format(x) : '')
            : (x ? money.format(x) : '');
    });
    // підсумок у режимі правки живе лише в підвалі — у шапці поля
    q.closest('.inv').querySelector('.inv-foot .t').innerHTML = edSumLine(true);
}

function edBadHead(field, msg) {
    const el = document.querySelector(`.is-edit .inv-hd input[data-ed="${field}"]`);
    if (el) { el.classList.add('badf'); el.focus(); }
    toast(msg, 'warn');
}

async function saveEdit(btn) {
    const e = histEdit;
    const live = e.items.filter((r) => !r.gone);
    const gone = e.items.filter((r) => r.gone);
    if (!live.length) {
        toast('Прибрані всі позиції — тоді видаліть накладну цілком', 'warn');
        return;
    }
    if (!String(e.supplier || '').trim()) return edBadHead('supplier', 'Вкажіть постачальника');
    if (!String(e.invoice_number || '').trim()) return edBadHead('invoice_number', 'Вкажіть номер накладної');
    if (!e.receipt_date) return edBadHead('receipt_date', 'Вкажіть дату приходу');
    for (const r of live) {
        if (!(r.qty > 0)) { toast(`${r.name}: вкажіть кількість`, 'warn'); return; }
        if (r.qty < r.consumed - 1e-9) {
            toast(`${r.name}: уже видано ${fmtQty(r.consumed, r.unit)} ${r.unit} — менше поставити не можна`, 'warn');
            return;
        }
        if (!(r.pv > 0 || r.pnv > 0)) { toast(`${r.name}: вкажіть ціну закупки`, 'warn'); return; }
    }
    const what = [];
    if (gone.length) what.push(`прибрати ${gone.length} поз.`);
    const changed = live.filter((r) => r.qty !== r.o.qty || r.pnv !== r.o.pnv
        || r.pv !== r.o.pv || r.vat !== r.o.vat);
    if (changed.length) what.push(`змінити ${changed.length} поз.`);
    if (!what.length) what.push('оновити шапку');
    if (!await confirmAction(`Зберегти зміни накладної: ${what.join(', ')}?`)) return;

    btn.disabled = true;
    const head = {
        supplier_name: e.supplier.trim(), invoice_number: e.invoice_number.trim(),
        invoice_date: e.invoice_date || '', receipt_date: e.receipt_date || '',
    };
    const fail = (r) => { btn.disabled = false; toast((r && r.error) || 'Помилка збереження', 'error'); };
    // 1) прибрані позиції
    for (const r of gone) {
        const res = await apiSend('/api/receipts/' + r.batch_id, 'DELETE');
        if (!res || !res.ok) return fail(res);
    }
    // 2) шапка — на всі позиції, що лишились
    const res = await apiSend('/api/receipts/invoice-header', 'POST', {
        batch_ids: live.map((r) => r.batch_id),
        supplier: head.supplier_name, invoice_number: head.invoice_number,
        invoice_date: head.invoice_date, receipt_date: head.receipt_date,
    });
    if (!res || !res.ok) return fail(res);
    // 3) змінені рядки
    for (const r of changed) {
        const res2 = await apiSend('/api/receipts/' + r.batch_id, 'PUT', {
            qty: r.qty, vat_rate: r.vat,
            price_in_no_vat: r.pnv, price_in: r.pv,
            lot_number: r.lot_number, expires_on: r.expires_on || '',
            note: r.note, ...head,
        });
        if (!res2 || !res2.ok) return fail(res2);
    }
    toast('Накладну оновлено', 'success');
    histEdit = null;
    await Promise.all([loadHist(), loadProductsIndex(), loadSuppliers()]);
}

async function killInvoice() {
    const e = histEdit;
    const busy = e.items.filter((r) => r.consumed > 0);
    if (busy.length) {
        toast(`З партії «${busy[0].name}» уже видавали — накладну не видалити. `
              + 'Спершу скасуйте видачі.', 'error');
        return;
    }
    if (!await confirmAction(`Видалити всю накладну (${e.items.length} поз.)? `
        + 'Партії зникнуть зі складу.')) return;
    for (const r of e.items) {
        const res = await apiSend('/api/receipts/' + r.batch_id, 'DELETE');
        if (!res || !res.ok) { toast((res && res.error) || 'Помилка', 'error'); break; }
    }
    toast('Накладну видалено', 'success');
    histEdit = null;
    await Promise.all([loadHist(), loadProductsIndex()]);
}

document.querySelectorAll('#histPer .seg-btn').forEach((b) => b.onclick = () => {
    document.querySelectorAll('#histPer .seg-btn').forEach((x) => x.classList.remove('is-active'));
    b.classList.add('is-active');
    histPer = b.dataset.per;
    document.getElementById('histRange').hidden = histPer !== 'range';
    if (histPer !== 'range') loadHist();
});
['histFrom', 'histTo'].forEach((id) => {
    document.getElementById(id).addEventListener('change', () => {
        if (histPer === 'range') loadHist();
    });
});
document.getElementById('histQ').addEventListener('input', () => {
    renderHist(document.getElementById('histQ').value);
});

/* ---------- старт ---------- */
(async function init() {
    await Promise.all([loadProductsIndex(), loadSuppliers(), loadUnitFormats()]);
    if (!loadDraft()) { invs = []; }
    if (invs.length) activeId = invs[0].id;
    render();
    focusScan();
})();
