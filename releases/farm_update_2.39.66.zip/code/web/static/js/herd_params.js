/* Налаштування параметрів тварин (стандартні + власні). */
'use strict';
(function () {   // IIFE — щоб уживатись на одній сторінці з іншими модулями

const DTYPE_LABEL = {
    date: 'Дата', text: 'Текст', int: 'Ціле (int)', float: 'Дробове (float)',
    bool: 'Так/Ні', list: 'Список', cod: 'Код', ref: 'Довідник', ref_animal: 'Родовід',
    multi: 'Кілька чисел (1, 4)',
    computed: 'Обчислюване',
    // legacy-аліаси
    number: 'Число', select: 'Список', code: 'Код',
};
// Типи ДАНИХ (обчислюваність — окремо, через «Тип обчислення»)
const ADD_DTYPES = ['int', 'float', 'text', 'date', 'bool', 'list', 'cod', 'multi', 'ref', 'ref_animal'];
// Опис вбудованих (стандартних) формул — для показу «як обчислюється»
// опис вбудованих формул — назвами параметрів із конструктора
const L_ = (k, fb) => (window.herdLabel ? herdLabel(k, fb) : fb);
let EVENT_OPERANDS = [];   // події — для підказок у COUNT/LAST/FIRST
let ANY_OPERANDS = [];    // будь-який параметр — для «попереднього значення»
const IS_LIST = (dt) => dt === 'list' || dt === 'select';
const IS_COD = (dt) => dt === 'cod' || dt === 'code';
const HAS_OPTS = (dt) => IS_LIST(dt) || IS_COD(dt);
// режим параметра: fixed | history (значення з історії іншого) | computed
function modeOf(formula) {
    const f = (formula || '').trim();
    if (!f) return 'fixed';
    if (f.startsWith('{')) {
        try { if (String(JSON.parse(f).op || '').startsWith('hist_')) return 'history'; }
        catch (e) { /* ignore */ }
    }
    return 'computed';
}
function histCfg(formula) {
    try { return JSON.parse(formula || '{}'); } catch (e) { return {}; }
}

// Розбір значень: list → масив рядків; cod → масив {c,l}
// (діапазон «0-9» розгортається; або числа/пари «1=Телиця» через кому)
function parseOptions(dtype, raw) {
    const s = (raw || '').trim();
    if (IS_COD(dtype)) {
        const rng = s.match(/^(-?\d+)\s*[-–]\s*(-?\d+)$/);   // діапазон N-M
        if (rng) {
            let a = +rng[1], b = +rng[2];
            if (a > b) { const t = a; a = b; b = t; }
            const out = [];
            for (let i = a; i <= b; i++) out.push({ c: String(i), l: String(i) });
            return out;
        }
        return s.split(',').map((x) => x.trim()).filter(Boolean).map((x) => {
            const i = x.indexOf('=');
            return i < 0 ? { c: x, l: x } : { c: x.slice(0, i).trim(), l: x.slice(i + 1).trim() };
        }).filter((o) => o.c !== '');
    }
    return s.split(',').map((x) => x.trim()).filter(Boolean);
}
// чи це суцільний цілочисловий діапазон без власних підписів
function codIsRange(list) {
    if (!list || list.length < 2) return false;
    const nums = list.map((o) => Number(o.c));
    if (nums.some((n) => !Number.isInteger(n))) return false;
    if (list.some((o) => String(o.l) !== String(o.c))) return false;
    for (let i = 1; i < nums.length; i++) if (nums[i] !== nums[i - 1] + 1) return false;
    return true;
}
function formatOptions(dtype, list) {
    if (!list || !list.length) return '';
    if (IS_COD(dtype)) {
        if (codIsRange(list)) return `${list[0].c}-${list[list.length - 1].c}`;
        return list.map((o) => (String(o.l) === String(o.c) ? o.c : `${o.c}=${o.l}`)).join(', ');
    }
    return list.join(', ');
}
function detailText(p) {
    const f = (p.formula || '').trim();
    if (f) {                         // обчислюване
        if (f.includes('"hist_')) {  // «з історії» — окремий вид, не формула
            try {
                const c = JSON.parse(f);
                const o = ANY_OPERANDS.find((x) => x.key === c.a);
                const n = Math.abs(parseInt(c.b, 10) || 1);
                const nth = n === 1 ? 'останнє' : (n === 2 ? 'передостаннє' : n + '-те з кінця');
                const what = c.op === 'hist_date' ? 'дата' : 'значення';
                return `з історії: ${what} — ${nth} «${escapeHtml(o ? o.label : c.a)}»`;
            } catch (e) { /* ignore */ }
        }
        const line = f.startsWith('=') ? f : (p.fx_line || '');
        return line ? `формула: <code class="pp-fx-code">${escapeHtml(line)}</code>` : 'обчислюється';
    }
    if (IS_COD(p.dtype)) return escapeHtml(formatOptions(p.dtype, p.options_list || []));
    if (IS_LIST(p.dtype)) return escapeHtml((p.options_list || []).join(', '));
    return '';
}

const $ = (id) => document.getElementById(id);
let SECTIONS = [];
let PARAMS = [];            // усі параметри (за sort_order)
let REFS = [];              // довідники значень (для типу «ref»)
let editing = null;        // параметр, який редагуємо
// рядок формули: хто може писати, який режим, чи формула перевірена
let FX_CAN = false, FX_STATE = '', FX_DIRTY = false, fxTimer = null, fxSeq = 0;
let FX_FUNCS = [];         // функції рядка формули з описами (із сервера)
const FX_ADMIN = ((document.querySelector('meta[name="current-user-role"]') || {}).content || '') === 'admin';
let ppQuery = '';          // фільтр пошуку

// Параметри, що проходять фільтр (за назвою/скороченням/секцією)
function filteredParams() {
    const q = ppQuery.trim().toLowerCase();
    if (!q) return PARAMS;
    return PARAMS.filter((p) =>
        (p.label || '').toLowerCase().includes(q)
        || (p.short || '').toLowerCase().includes(q)
        || (p.section || '').toLowerCase().includes(q));
}

async function load() {
    const r = await apiGet('/api/herd/params');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    SECTIONS = r.sections || [];
    PARAMS = r.params || [];
    REFS = r.refs || [];
    FX_CAN = !!r.can_formula;
    FX_FUNCS = r.formula_funcs || [];
    ANY_OPERANDS = r.any_operands || [];
    EVENT_OPERANDS = r.event_operands || [];
    // приклади в довідці «Як писати» — тими самими кольорами, що в рядку
    document.querySelectorAll('.pp-fx-help code').forEach((c) => {
        if (!c.dataset.src) c.dataset.src = c.textContent;
        c.classList.add('fxc');
        c.innerHTML = fxHlHtml(c.dataset.src, true);
    });
    render(filteredParams());
    // сигнал іншим блокам (Події) — оновити списки параметрів
    document.dispatchEvent(new CustomEvent('herd-params-changed'));
}

function sectionOptions(sel) {
    return SECTIONS.map((s) =>
        `<option value="${escapeHtml(s)}"${s === sel ? ' selected' : ''}>${escapeHtml(s)}</option>`).join('');
}

/* ---------- список ---------- */
function render(params) {
    $('ppCount').textContent = params.length ? `· ${params.length}` : '';
    const bySec = {};
    params.forEach((p) => { (bySec[p.section] = bySec[p.section] || []).push(p); });
    const order = SECTIONS.concat(Object.keys(bySec).filter((s) => !SECTIONS.includes(s)));
    let html = '';
    let seq = 0;                       // суцільна нумерація згори вниз (по блоках)
    order.forEach((sec) => {
        const list = bySec[sec];
        if (!list || !list.length) return;
        html += `<tr class="pp-sec"><td colspan="9">${escapeHtml(sec)} · ${list.length}</td></tr>`;
        list.forEach((p) => {
            const idx = params.indexOf(p);
            seq += 1;
            const detail = detailText(p);
            html += `<tr class="pp-row ${p.is_active ? '' : 'off'}" data-id="${p.id}">
                <td class="pp-c pp-num">${seq}</td>
                <td class="pp-name" title="${escapeHtml(p.label)}">${p.color
                    ? `<i class="pp-dot pp-dot-${escapeHtml(p.color)}"></i>` : ''}<b>${escapeHtml(p.label)}</b></td>
                <td class="pp-short">${escapeHtml(p.short || '')}</td>
                <td class="pp-dtype">${DTYPE_LABEL[p.dtype] || p.dtype}</td>
                <td>${escapeHtml(p.unit || '')}</td>
                <td class="pp-detail" title="${escapeHtml((p.formula || '').trim() || p.options || '')}">${detail}</td>
                <td><span class="pp-badge ${p.is_standard ? 'std' : 'cus'}">${p.is_standard ? 'системний' : 'створений'}</span></td>
                <td class="pp-c"><input type="checkbox" data-act="toggle" ${p.is_active ? 'checked' : ''}></td>
                <td class="pp-c pp-actions">
                    <button class="pp-move" data-act="up" ${idx === 0 ? 'disabled' : ''} title="Вгору">▲</button>
                    <button class="pp-move" data-act="down" ${idx === params.length - 1 ? 'disabled' : ''} title="Вниз">▼</button>
                    <button data-act="edit" title="Редагувати">✏</button>
                    ${(!p.is_standard || window.canManage('herd')) ? '<button class="pp-del-btn" data-act="del" title="Видалити">−</button>' : ''}
                </td>
            </tr>`;
        });
    });
    $('ppBody').innerHTML = html ||
        `<tr><td colspan="9" class="empty">${ppQuery ? 'Нічого не знайдено' : 'Немає параметрів'}</td></tr>`;
    if (window.makeColumnsResizable) makeColumnsResizable('ppTable', 'farm:pp_cols');
}

/* ---------- модал: додати / редагувати ---------- */
function openEdit(p) {
    editing = p;                       // p == null → новий параметр
    const isNew = !p;
    let dtype = isNew ? 'int' : p.dtype;
    if (dtype === 'computed') dtype = 'int';   // legacy: computed більше не тип даних
    $('peTitle').textContent = isNew ? 'Новий параметр' : ('Параметр: ' + p.label);
    // новий створюється кнопкою, наявний зберігається сам
    $('peSaveBtn').textContent = isNew ? 'Створити' : 'Готово';
    if ($('peCancel')) $('peCancel').hidden = !isNew;
    clearTimeout(peTimer);
    setPeNote(isNew ? '' : 'ok');
    $('peLabel').value = isNew ? '' : (p.label || '');
    $('peShort').value = isNew ? '' : (p.short || '');
    $('peUnit').value = isNew ? '' : (p.unit || '');
    $('peSection').innerHTML = sectionOptions(isNew ? SECTIONS[0] : p.section);
    // тип: новий/власний — можна обрати; стандартний — лише показ.
    // Якщо поточний тип legacy (number/select/code) — додаємо його в список.
    const typeSel = $('peType');
    const types = ADD_DTYPES.slice();
    if (!types.includes(dtype)) types.unshift(dtype);
    typeSel.innerHTML = types
        .map((d) => `<option value="${d}"${d === dtype ? ' selected' : ''}>${DTYPE_LABEL[d] || d}</option>`).join('');
    // тип стандартних заблоковано, але адмін може змінити
    typeSel.disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peOptions').value = (!isNew && IS_LIST(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    $('peCodes').value = (!isNew && IS_COD(p.dtype)) ? formatOptions(p.dtype, p.options_list) : '';
    // межі й крок числового (порожні — вільний ввід)
    $('peMin').value = isNew ? '' : (p.vmin || '');
    $('peMax').value = isNew ? '' : (p.vmax || '');
    $('peStep').value = isNew ? '' : (p.vstep || '');
    $('peMoney').value = isNew ? '' : (p.money_role || '');
    // колір: із палітри або свій (#rrggbb)
    const _col = isNew ? '' : (p.color || '');
    const _own = /^#[0-9a-f]{6}$/i.test(_col);
    $('peColor').value = _own ? 'custom' : _col;
    $('peColorPick').value = _own ? _col : '#2f5fb0';
    $('peColorPick').hidden = !_own;
    // тип обчислення: обчислюване = є формула
    const fml = isNew ? '' : (p.formula || '');
    const mode = modeOf(fml);
    const computed = mode === 'computed';
    // обчислюване пишеться лише рядком формули (Роман 2026-09-19: «прибрати
    // конструктор з параметрів і лишити тільки командну строку»); запис у
    // старому вигляді показуємо рядком, а перезаписуємо — лише якщо змінили
    const line = computed ? (fml.trim().startsWith('=') ? fml.trim() : (p.fx_line || '')) : '';
    $('peFx').value = line;
    $('peFx').readOnly = !FX_CAN;
    $('peFxUsers').hidden = !FX_ADMIN;
    $('peFxNote').hidden = FX_CAN;
    FX_STATE = line ? 'ok' : '';
    FX_DIRTY = false;
    $('peFxRes').textContent = '';
    $('peFxRes').className = 'pp-fx-res';
    fxPaint();
    if (line) fxCheck(false);
    $('peCompute').value = mode;
    // «з історії»: джерело · номер запису · значення чи дата
    const hc = mode === 'history' ? histCfg(fml) : {};
    fillHistSrc(hc.a || '');
    $('peHistN').value = hc.b || '-1';
    $('peHistWhat').value = hc.op || 'hist_val';
    $('peCompute').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    togglePeOpts();
    // джерело: створений/системний. Системний→створений — лише адмін
    $('peSourceStd').checked = !(isNew || !p.is_standard);
    $('peSourceStd').disabled = !isNew && !!p.is_standard && !window.canManage('herd');
    $('peActive').checked = isNew ? true : !!p.is_active;
    // за якими значеннями шукається тварина (UIN, транспондер, чип)
    if ($('peSearch')) $('peSearch').checked = isNew ? false : !!p.searchable;
    const advBox = document.querySelector('.pp-adv');
    if (advBox) advBox.dataset.touched = '0';
    // «Розширені» згорнуті, але в обчислюваного там сама суть — формула:
    // її видно одразу (Роман 2026-09-19: «працюємо з параметрами у виді формул»)
    advSet(computed);
    advNote();
    $('peHint').textContent = isNew
        ? '«Тип обчислення»: Фіксоване — вводиться руками/подіями; Обчислюване — рахується формулою.'
        : (p.is_standard && !window.canManage('herd')
            ? 'Стандартний параметр: тип змінити не можна, але можна перейменувати, змінити секцію/одиницю та вимкнути.'
            : '');
    fillRefSelect(!isNew && (p.options || '').startsWith('@ref:') ? p.options.slice(5) : '');
    $('peDelBtn').style.display = (isNew ? false : (!p.is_standard || window.canManage('herd'))) ? '' : 'none';
    $('ppEditModal').hidden = false;
    $('peLabel').focus();
}

function fillHistSrc(want) {
    const sel = $('peHistSrc');
    if (!sel) return;
    sel.innerHTML = ANY_OPERANDS.map((o) =>
        `<option value="${escapeHtml(o.key)}">${escapeHtml(o.label)}</option>`).join('')
        || '<option value="">— спершу створіть параметр, який вводиться —</option>';
    if (want) sel.value = want;
    histHint();
}
function histHint() {
    const el = $('peHistHint');
    if (!el) return;
    const n = Math.abs(parseInt($('peHistN').value, 10) || 1);
    const nth = n === 1 ? 'останнє' : (n === 2 ? 'передостаннє' : `${n}-те з кінця`);
    el.textContent = `−1 останнє · −2 передостаннє · зараз: ${nth} внесене`;
}

function fillRefSelect(want) {
    const sel = $('peRef');
    sel.innerHTML = REFS.length
        ? REFS.map((r) => `<option value="${escapeHtml(r.key)}">`
            + `${escapeHtml(r.name)} (${r.n_active})</option>`).join('')
        : '<option value="">— довідників ще немає: створіть у вкладці «Довідники» —</option>';
    if (want) sel.value = want;
}

/* Розширені: стан панелі памʼятається; у згорнутому вигляді видно зведення. */
function advSet(open) {
    const box = document.querySelector('.pp-adv');
    if (!box) return;
    box.dataset.open = open ? '1' : '0';
    $('peAdvBody').hidden = !open;
    $('peAdvBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
}
function advNote() {
    const el = $('peAdvNote');
    if (!el) return;
    const bits = [];
    const mode = $('peCompute').value;
    if (mode === 'history') bits.push('з історії');
    else if (mode === 'computed') bits.push('формула');
    if (mode === 'fixed') {
        const lo = ($('peMin').value || '').trim(), hi = ($('peMax').value || '').trim();
        const st = ($('peStep').value || '').trim();
        if (lo || hi) bits.push(`межі ${lo || '…'}–${hi || '…'}${st ? ' крок ' + st : ''}`);
    }
    if ($('peSourceStd').checked) bits.push('системний');
    el.textContent = bits.join(' · ');
}

function togglePeOpts() {
    const dt = $('peType').value;
    const mode = $('peCompute').value;
    const computed = mode === 'computed';
    const histBox = document.querySelector('.pp-e-hist');
    if (histBox) {
        const wasHidden = histBox.hidden;
        histBox.hidden = mode !== 'history';
        if (mode === 'history') {
            if (!$('peHistSrc').options.length) fillHistSrc('');
            histHint();
            // щойно ввімкнули — показуємо блок, щоб його не шукали прокруткою
            if (wasHidden) requestAnimationFrame(() =>
                histBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
        }
    }
    // Поля вводу (списки, коди, довідник, межі) мають сенс ЛИШЕ для
    // фіксованого параметра: обчислюване й «з історії» значення не вводять.
    const typed = mode === 'fixed';
    document.querySelector('.pp-e-opts').hidden = !(IS_LIST(dt) && typed);
    document.querySelector('.pp-e-codes').hidden = !(IS_COD(dt) && typed);
    const isRef = dt === 'ref' && typed;
    document.querySelector('.pp-e-ref').hidden = !isRef;
    if (isRef && !$('peRef').options.length) fillRefSelect();
    // рядок формули — для обчислюваних
    document.querySelector('.pp-e-formula').hidden = !computed;
    advNote();
    // тип із власними налаштуваннями — показуємо їх одразу (інакше не знайти)
    if (mode !== 'fixed' && $('peAdvBody') && $('peAdvBody').hidden
        && document.querySelector('.pp-adv').dataset.touched === '1') advSet(true);
    // межі й крок — для числових, які вводяться
    const isNum = (dt === 'int' || dt === 'float' || dt === 'number' || dt === 'multi') && typed;
    document.querySelector('.pp-e-range').hidden = !isNum;
    // «кілька чисел» — лише межі (1–4), кроку немає
    if ($('peStep')) $('peStep').hidden = dt === 'multi';
    const stLbl = $('peStep') && $('peStep').previousElementSibling;
    if (stLbl) stLbl.hidden = dt === 'multi';
    if (isNum) {
        // у цілого дробового кроку бути не може
        $('peStep').placeholder = isIntType(dt) ? 'напр. 1' : 'напр. 0,25';
        rangeHint();
    }
}

const isIntType = (dt) => dt === 'int';

// Скільки значень дасть задана градація — показуємо одразу, щоб було видно,
// що саме побачить оператор.
const RANGE_LIMIT = 60;
function rangeScale() {
    const n = (el) => {
        const v = ($(el).value || '').replace(',', '.').trim();
        if (!v) return null;
        const f = parseFloat(v);
        return isFinite(f) ? f : null;
    };
    let lo = n('peMin'), hi = n('peMax'), st = n('peStep');
    if (lo === null || hi === null || !st || st <= 0 || hi < lo) return null;
    if (isIntType($('peType').value)) {          // ціле: усе округлюємо до цілих
        lo = Math.round(lo); hi = Math.round(hi); st = Math.max(1, Math.round(st));
        if (hi < lo) return null;
    }
    const cnt = Math.round((hi - lo) / st);
    if (cnt < 1 || cnt + 1 > RANGE_LIMIT) return null;
    const s = String(st), dec = s.includes('.') ? s.split('.')[1].length : 0;
    const out = [];
    for (let i = 0; i <= cnt; i++) out.push((lo + st * i).toFixed(dec));
    return out;
}
function rangeHint() {
    const el = $('peRangeHint');
    if (!el) return;
    const stRaw = ($('peStep').value || '').replace(',', '.').trim();
    if (isIntType($('peType').value) && stRaw && !Number.isInteger(parseFloat(stRaw))) {
        el.textContent = 'Ціле число — крок теж цілий; 0,25 тут неможливий'
            + ' (для дробових балів оберіть тип «Дробове»).';
        return;
    }
    const list = rangeScale();
    if (list) {
        const show = list.length > 8
            ? list.slice(0, 5).join(' · ') + ' … ' + list[list.length - 1]
            : list.join(' · ');
        el.textContent = `Вибір зі списку (${list.length}): ${show}`;
        return;
    }
    const has = ($('peMin').value || '').trim() || ($('peMax').value || '').trim();
    el.textContent = has
        ? 'Без кроку — ввід вільний, перевіряються лише межі.'
        : (isIntType($('peType').value)
            ? 'Порожньо — будь-яке число. «1 · 4 · 1» дасть вибір 1 · 2 · 3 · 4.'
            : 'Порожньо — будь-яке число. «3 · 4 · 0,25» дасть 3.00 · 3.25 · 3.50 · 3.75 · 4.00.');
}

/* Автозбереження у вікні параметра: кнопки «Зберегти» немає, кожна зміна
   фіксується сама. Новий параметр спершу треба створити кнопкою — доти
   в нього немає id, і зберігати нічого. */
let peTimer = null, peSaving = false, peAgain = false;

function setPeNote(state) {
    const el = $('peSaved');
    if (!el) return;
    el.className = 'pe-saved ' + state;
    el.textContent = { wait: 'зміни не збережено', busy: 'збереження…',
        ok: 'збережено', bad: 'не збережено' }[state] || '';
}

function markParamDirty() {
    if (!editing) return;          // новий створюється кнопкою
    setPeNote('wait');
    clearTimeout(peTimer);
    peTimer = setTimeout(flushParam, 700);
}

async function flushParam() {
    clearTimeout(peTimer);
    if (!editing) return;
    if (peSaving) { peAgain = true; return; }
    peSaving = true; setPeNote('busy');
    await saveEdit(true);
    peSaving = false;
    if (peAgain) { peAgain = false; return flushParam(); }
}

async function saveEdit(auto) {
    const isNew = !editing;
    if (auto && isNew) return;
    const warn = (msg, el) => {
        if (auto) { setPeNote('bad'); return; }
        toast(msg, 'warn');
        if (el) el.focus();
    };
    const label = $('peLabel').value.trim();
    if (!label) { warn('Вкажіть назву', $('peLabel')); return; }
    const payload = {
        label, short: $('peShort').value.trim(),
        unit: $('peUnit').value.trim(), section: $('peSection').value,
        is_active: $('peActive').checked,
        searchable: $('peSearch') ? $('peSearch').checked : false,
    };
    // межі й крок — доступні завжди (не міняють типу даних)
    payload.vmin = $('peMin').value.trim();
    payload.vmax = $('peMax').value.trim();
    payload.vstep = $('peStep').value.trim();
    payload.money_role = $('peMoney').value;
    payload.color = $('peColor').value === 'custom'
        ? $('peColorPick').value : $('peColor').value;
    // тип даних + обчислення + джерело: для нового, власного або адміна на системному
    if (isNew || !editing.is_standard || window.canManage('herd')) {
        payload.is_standard = $('peSourceStd').checked ? 1 : 0;
        const dtype = $('peType').value;
        payload.dtype = dtype;
        const mode = $('peCompute').value;
        const computed = mode === 'computed';
        if (mode === 'history') {               // значення з історії іншого параметра
            const src = $('peHistSrc').value;
            if (!src) { warn('Оберіть параметр-джерело'); return; }
            let n = parseInt($('peHistN').value, 10);
            if (!n || isNaN(n)) n = -1;
            payload.formula = JSON.stringify(
                { op: $('peHistWhat').value, a: src, b: String(n), fallback: '' });
            payload.options = [];               // свого списку значень немає
        }
        if (!computed && mode !== 'history' && dtype === 'ref') {
            const rk = $('peRef').value;
            if (!rk) { warn('Оберіть довідник'); return; }
            payload.options = '@ref:' + rk;   // не список, а посилання на довідник
        } else if (!computed && mode !== 'history' && IS_LIST(dtype)) {
            payload.options = parseOptions(dtype, $('peOptions').value);
            if (!payload.options.length) { warn('Додайте значення списку'); return; }
        } else if (!computed && mode !== 'history' && IS_COD(dtype)) {
            payload.options = parseOptions(dtype, $('peCodes').value);
            if (!payload.options.length) { warn('Задайте коди (напр. 0-9)'); return; }
        }
        if (mode !== 'history') {
            if (computed) {
                // формулу відправляємо, лише коли її справді змінили: інакше
                // перейменування не чіпає обчислення (і не потребує дозволу)
                if (FX_DIRTY || isNew) {
                    if (!FX_CAN) {
                        warn('Обчислюваний параметр пишеться формулою — це робить той, кому дозволив адміністратор');
                        return;
                    }
                    let t = $('peFx').value.trim();
                    if (!t) { warn('Напишіть формулу', $('peFx')); return; }
                    if (!t.startsWith('=')) t = '=' + t;
                    if (FX_STATE !== 'ok') {
                        if (auto) { setPeNote('wait'); return; }
                        warn('Спершу виправте формулу', $('peFx')); return;
                    }
                    payload.formula = t;
                }
            } else {
                payload.formula = '';   // фіксоване — очищаємо формулу
            }
        }
    }
    const url = isNew ? '/api/herd/params' : ('/api/herd/params/' + editing.id);
    const r = await apiSend(url, 'POST', payload);
    if (!r.ok) {
        if (auto) { setPeNote('bad'); toast(r.error || 'Не збережено', 'error'); return; }
        toast(r.error || 'Помилка', 'error'); return;
    }
    if (auto) {
        // вікно лишається відкритим; список під ним оновлюємо тихо
        Object.assign(editing, payload);
        setPeNote('ok');
        load();
        return;
    }
    $('ppEditModal').hidden = true;
    toast(isNew ? 'Додано' : 'Збережено', 'success');
    load();
}

async function delEdit() {
    if (!editing) return;
    if (editing.is_standard && !window.canManage('herd')) return;
    if (!(await confirmAction(`Видалити параметр «${editing.label}» і всі його значення?`, { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/params/' + editing.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    $('ppEditModal').hidden = true;
    load();
}

async function delParam(p) {
    if (!p) return;
    if (p.is_standard && !window.canManage('herd')) {
        toast('Стандартний параметр може видалити лише адміністратор', 'warn');
        return;
    }
    const warn = p.is_standard ? ' (СТАНДАРТНИЙ!)' : '';
    if (!(await confirmAction(`Видалити параметр «${p.label}»${warn} і всі його значення?`, { ok: 'Видалити' }))) return;
    const r = await apiSend('/api/herd/params/' + p.id, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Видалено', 'success');
    load();
}

/* ---------- переміщення / вкл-викл ---------- */
async function moveParam(id, dir) {
    const i = PARAMS.findIndex((p) => String(p.id) === String(id));
    const j = dir === 'up' ? i - 1 : i + 1;
    if (i < 0 || j < 0 || j >= PARAMS.length) return;
    const arr = PARAMS.slice();
    [arr[i], arr[j]] = [arr[j], arr[i]];
    PARAMS = arr;
    render(filteredParams());   // оптимістично
    await apiSend('/api/herd/params/reorder', 'POST', { order: arr.map((p) => p.id) });
}

async function toggleActive(id, checked) {
    const r = await apiSend('/api/herd/params/' + id, 'POST', { is_active: checked });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); load(); return; }
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (p) p.is_active = checked ? 1 : 0;
    render(filteredParams());
}

/* ---------- події таблиці ---------- */
$('ppBody').addEventListener('click', (e) => {
    const row = e.target.closest('.pp-row'); if (!row) return;
    const id = row.dataset.id; const act = e.target.dataset.act;
    const p = PARAMS.find((x) => String(x.id) === String(id));
    if (act === 'edit') { if (p) openEdit(p); }
    else if (act === 'up' || act === 'down') moveParam(id, act);
    else if (act === 'del') delParam(p);
    // клік будь-де по рядку (окрім кнопок/галочки) — відкрити редагування
    else if (!e.target.closest('button, input') && p) openEdit(p);
});
$('ppBody').addEventListener('change', (e) => {
    if (e.target.dataset.act === 'toggle') {
        toggleActive(e.target.closest('.pp-row').dataset.id, e.target.checked);
    }
});

/* ---------- ініт ---------- */
$('peCompute').addEventListener('change', () => {
    const box = document.querySelector('.pp-adv');
    if (box) box.dataset.touched = '1';       // зміна типу людиною → показати блок
});
$('peAdvBtn').addEventListener('click', () =>
    advSet(document.querySelector('.pp-adv').dataset.open !== '1'));
['peMin', 'peMax', 'peStep', 'peSourceStd', 'peCompute'].forEach((id) => {
    const el = $(id);
    if (el) ['input', 'change'].forEach((ev) => el.addEventListener(ev, advNote));
});
// «свій колір…» відкриває піпетку
$('peColor').addEventListener('change', () => {
    const pick = $('peColorPick');
    pick.hidden = $('peColor').value !== 'custom';
    if (!pick.hidden) pick.click();
});
$('peType').addEventListener('change', togglePeOpts);
['peMin', 'peMax', 'peStep'].forEach((id) =>
    $(id).addEventListener('input', rangeHint));   // підказка оновлюється на очах
['peHistSrc', 'peHistN', 'peHistWhat'].forEach((id) => {
    const el = $(id);
    if (el) ['input', 'change'].forEach((ev) => el.addEventListener(ev, histHint));
});
$('peCompute').addEventListener('change', togglePeOpts);
if ($('ppSearch')) $('ppSearch').addEventListener('input', (e) => {
    ppQuery = e.target.value || ''; render(filteredParams());
});
$('ppAddBtn').addEventListener('click', () => openEdit(null));
// та сама дія з шапки панелі — кругле «+» унизу списку помітне не всім
if ($('ppAddBtn2')) $('ppAddBtn2').addEventListener('click', () => openEdit(null));
$('peSaveBtn').addEventListener('click', async () => {
    if (editing) { await flushParam(); $('ppEditModal').hidden = true; return; }
    await saveEdit(false);          // новий параметр створюється явно
});
// будь-яка зміна у вікні фіксується сама (для вже створеного параметра)
['input', 'change'].forEach((evt) =>
    $('ppEditModal').addEventListener(evt, (e) => {
        if (e.target.closest('.actions')) return;
        markParamDirty();
    }));
$('peDelBtn').addEventListener('click', delEdit);

/* ── рядок формули ───────────────────────────────────────────────── */
// перевірка на сервері: синтаксис, відомі назви і приклад на тваринах
async function fxCheck(save) {
    const t = $('peFx').value.trim();
    const res = $('peFxRes');
    if (!t) { FX_STATE = ''; res.textContent = ''; res.className = 'pp-fx-res'; return; }
    const my = ++fxSeq;
    const r = await apiSend('/api/herd/params/formula-check', 'POST', { formula: t });
    if (my !== fxSeq) return;                       // уже набрали далі
    if (!r || r.ok === false || !r.ok || r.error) {
        FX_STATE = 'bad';
        res.className = 'pp-fx-res bad';
        res.textContent = (r && r.error) || 'не вдалося перевірити';
        return;
    }
    FX_STATE = 'ok';
    FX_PRETTY = r.formatted || '';
    FX_PRETTY_SRC = t;                              // для якого тексту
    // пробіли розставляються самі — щойно курсор покинув поле (під час
    // набору текст не стрибає); лише змінену формулу, щоб не «правити» чужу
    if (FX_PRETTY && FX_DIRTY && document.activeElement !== $('peFx')) fxApplyPretty();
    res.className = 'pp-fx-res ok';
    const show = (v) => (v === '' || v === null || v === undefined ? '—'
        : (/^\d{4}-\d{2}-\d{2}$/.test(String(v)) ? String(v).split('-').reverse().join('.') : String(v)));
    res.innerHTML = '✓ ' + ((r.sample || []).map((x) =>
        `№${escapeHtml(String(x.tag))} → <b>${escapeHtml(show(x.value))}</b>`).join(' · ') || 'формула правильна');
    if (save && editing) markParamDirty();
}
let FX_PRETTY = '', FX_PRETTY_SRC = '';
function fxApplyPretty() {
    const inp = $('peFx');
    if (!inp || inp.readOnly || !FX_PRETTY || !FX_DIRTY) return;
    // лише для того самого тексту, що перевіряли: інакше затерли б набране
    if (inp.value.trim() === FX_PRETTY_SRC && FX_PRETTY !== FX_PRETTY_SRC && FX_STATE === 'ok') {
        inp.value = FX_PRETTY;
        fxPaint();
    }
}
/* кольорова підсвітка рядка формули: функції, параметри, події, числа,
   текст, знаки; невідома назва — червоним хвилястим (одруківку видно одразу) */
function fxHlHtml(txt, soft) {
    return window.herdFxHl(txt, { params: PARAMS, events: EVENT_OPERANDS,
        funcs: FX_FUNCS.map((f) => f.name), soft });
}
function fxPaint() {
    const inp = $('peFx'), hl = $('peFxHl');
    if (!inp || !hl) return;
    hl.innerHTML = fxHlHtml(inp.value);
    hl.scrollLeft = inp.scrollLeft;
    const w = inp.closest('.pp-fx-wrap');
    if (w) w.classList.toggle('ro', inp.readOnly);
}
$('peFx').addEventListener('scroll', () => { $('peFxHl').scrollLeft = $('peFx').scrollLeft; });
$('peFx').addEventListener('keyup', fxPaint);

$('peFx').addEventListener('input', () => {
    fxPaint();
    FX_DIRTY = true;                  // формулу змінили — її й збережемо
    FX_STATE = 'pending';
    clearTimeout(fxTimer);
    fxTimer = setTimeout(() => fxCheck(true), 450);
    fxSuggest();
});

/* ── підказки під час набору формули (Роман 2026-09-19) ─────────────
   Функції з описом, короткі назви параметрів, а всередині COUNT/LAST/FIRST —
   назви подій; друге в COUNT — life / lactation. ↑↓ — вибрати,
   Tab або Enter — вставити, Esc — закрити. */
const FX_EVENT_FNS = ['COUNT', 'LAST', 'FIRST'];
const FX_HIST_FNS = ['VAL', 'VALDATE'];              // (параметр, позиція, період)
const FX_AGG_FNS = ['AVGVAL', 'TOTAL'];              // (параметр, період)
let FXS = [], FXS_I = 0, FXS_FROM = 0;
const fxSugEl = $('peFxSug');
if (fxSugEl) document.body.appendChild(fxSugEl);    // вікно має transform — ловить fixed

function fxContext(before) {
    const stack = [];
    let quote = null;
    for (let i = 0; i < before.length; i++) {
        const c = before[i];
        if (quote) { if (c === quote) quote = null; continue; }
        if (c === '"' || c === "'") { quote = c; continue; }
        if (c === '[') {
            const j = before.indexOf(']', i);
            if (j < 0) return { bracket: i };
            i = j;
            continue;
        }
        if (c === '(') {
            const m = before.slice(0, i).match(/([\p{L}_][\p{L}\d_]*)\s*$/u);
            stack.push({ fn: m ? m[1].toUpperCase() : '', arg: 0 });
        } else if (c === ')') stack.pop();
        else if ((c === ',' || c === ';') && stack.length) stack[stack.length - 1].arg += 1;
    }
    if (quote) return { quote: true };
    return stack[stack.length - 1] || { fn: '', arg: 0 };
}

const fxParamName = (p) => {
    const n = (p.short || p.key || '').trim();
    return /^[\p{L}_][\p{L}\d_]*$/u.test(n) ? n : `[${n || p.label}]`;
};

function fxCandidates(ctx, word) {
    const w = word.toLowerCase();
    const starts = (x) => String(x || '').toLowerCase().startsWith(w);
    if (ctx.bracket !== undefined) {                     // [Назва з пробілами
        return PARAMS.filter((p) => !w || (p.label || '').toLowerCase().includes(w)
            || starts(p.short) || starts(p.key)).slice(0, 12)
            .map((p) => ({ ins: `[${p.short || p.label}]`, name: p.short || p.key,
                hint: p.label, cls: 'p', from: ctx.bracket }));
    }
    if (FX_EVENT_FNS.includes(ctx.fn) && ctx.arg === 0) {    // назва події
        return EVENT_OPERANDS.filter((e) => !w || starts(e.key) || (e.label || '').toLowerCase().includes(w))
            .slice(0, 12).map((e) => ({ ins: e.key, name: e.key, hint: e.label, cls: 'e' }));
    }
    if (ctx.fn === 'WITHDRAWAL' && ctx.arg === 0) {          // каренція: молоко / мʼясо
        return [{ ins: 'milk', name: 'milk', hint: 'каренція молока — до якої дати', cls: 'e' },
            { ins: 'meat', name: 'meat', hint: 'каренція мʼяса — до якої дати', cls: 'e' }]
            .filter((x) => !w || starts(x.ins));
    }
    if (FX_HIST_FNS.includes(ctx.fn) && ctx.arg === 1 && !w) {   // позиція запису
        return [
            { ins: '1', name: '1', hint: 'перший запис (напр. вага при народженні)', cls: 'n' },
            { ins: '-1', name: '-1', hint: 'останній запис', cls: 'n' },
            { ins: '-2', name: '-2', hint: 'передостанній', cls: 'n' },
            { ins: '2', name: '2', hint: 'другий від початку', cls: 'n' },
        ];
    }
    if ((FX_EVENT_FNS.includes(ctx.fn) && ctx.arg === 1)
        || (FX_HIST_FNS.includes(ctx.fn) && ctx.arg === 2)
        || (FX_AGG_FNS.includes(ctx.fn) && ctx.arg === 1)) {    // період
        const sc = [
            { ins: 'lactation', name: 'lactation', hint: 'поточна лактація — від останнього отелу', cls: 'e' },
            { ins: 'prevlactation', name: 'prevlactation', hint: 'попередня лактація', cls: 'e' },
            { ins: 'life', name: 'life', hint: 'за все життя (як без періоду)', cls: 'e' },
            { ins: '2', name: 'число', hint: 'лактація № N: 2 — друга, 0 — до першого отелу', cls: 'e' },
            { ins: '"2026-01-01"', name: '"дата"', hint: 'з дати до сьогодні; дві дати — від і до', cls: 'e' },
        ].filter((x) => !w || starts(x.ins));
        return w && !sc.length ? fxCandidates({ fn: '', arg: 0 }, word) : sc;
    }
    if (!w) return [];
    const fns = FX_FUNCS.filter((f) => starts(f.name))
        .map((f) => ({ ins: f.name + '(', name: f.name + '(', hint: f.desc, cls: 'f', fn: true }));
    // and / or між умовами — після вже набраної умови (перед словом є щось)
    const kws = [{ ins: 'and ', name: 'and', hint: 'і — обидві умови: lact > 0 and rc = 5', cls: 'o', fn: true },
        { ins: 'or ', name: 'or', hint: 'або — хоч одна: rc = 4 or rc = 5', cls: 'o', fn: true }]
        .filter((k) => starts(k.name) && ctx.fn);
    const ps = PARAMS.filter((p) => p.is_active !== 0 && p.is_active !== false)
        .map((p) => ({ p, n: fxParamName(p) }))
        .filter(({ p, n }) => starts(n.replace(/^\[/, '')) || starts(p.key)
            || (p.label || '').toLowerCase().includes(w))
        .sort((x, y) => (Number(!starts(x.n)) - Number(!starts(y.n))) || (x.n.length - y.n.length))
        .map(({ p, n }) => ({ ins: n, name: n, hint: p.label, cls: 'p' }));
    return [...kws, ...fns, ...ps].slice(0, 12);
}

function fxSuggest() {
    const inp = $('peFx');
    if (!fxSugEl || !inp || inp.readOnly) return fxSugClose();
    const pos = inp.selectionStart;
    const before = inp.value.slice(0, pos);
    const ctx = fxContext(before);
    if (ctx.quote) return fxSugClose();
    const word = ctx.bracket !== undefined ? before.slice(ctx.bracket + 1)
        : (before.match(/[\p{L}\d_]*$/u) || [''])[0];
    if (/^\d/.test(word)) return fxSugClose();
    FXS = fxCandidates(ctx, word);
    FXS_FROM = ctx.bracket !== undefined ? ctx.bracket : pos - word.length;
    // уже набране повністю й одне — не набридаємо
    if (!FXS.length || (FXS.length === 1 && FXS[0].ins.replace(/\($/, '').toLowerCase() === word.toLowerCase()
        && !FXS[0].fn)) return fxSugClose();
    FXS_I = 0;
    fxSugPaint();
    // під курсором: ширина тексту до курсора тим самим шрифтом
    const cs = getComputedStyle(inp);
    const cv = fxSuggest.cv || (fxSuggest.cv = document.createElement('canvas'));
    const g = cv.getContext('2d');
    g.font = `${cs.fontSize} ${cs.fontFamily}`;
    const r = inp.getBoundingClientRect();
    const x = r.left + parseFloat(cs.paddingLeft) + g.measureText(inp.value.slice(0, FXS_FROM)).width
        - inp.scrollLeft;
    fxSugEl.hidden = false;
    const w = fxSugEl.offsetWidth;
    fxSugEl.style.left = Math.max(8, Math.min(x, window.innerWidth - w - 8)) + 'px';
    const below = r.bottom + 4;
    const h = fxSugEl.offsetHeight;
    fxSugEl.style.top = (below + h > window.innerHeight - 8 ? r.top - h - 4 : below) + 'px';
}

/* опис у підказці: приклад після «:» — тими самими кольорами, що в рядку */
function fxHintHtml(t) {
    const m = String(t || '').match(/^(.*?:\s)([A-Z][A-Z]*\(.*)$/);
    return m ? escapeHtml(m[1]) + `<i class="fxc">${fxHlHtml(m[2], true)}</i>` : escapeHtml(t || '');
}

function fxSugPaint() {
    fxSugEl.innerHTML = FXS.map((x, i) =>
        `<div data-i="${i}" class="${i === FXS_I ? 'on' : ''}"><b class="${x.cls}">${escapeHtml(x.name)}</b>`
        + `<span>${fxHintHtml(x.hint)}</span></div>`).join('')
        + '<div class="foot">↑↓ вибрати · Tab або Enter — вставити · Esc — закрити</div>';
}

function fxSugClose() { if (fxSugEl) fxSugEl.hidden = true; FXS = []; }

function fxAccept(i) {
    const x = FXS[i];
    const inp = $('peFx');
    if (!x || !inp) return;
    const v = inp.value;
    const pos = inp.selectionStart;
    let tail = v.slice(pos);
    let ins = x.ins;
    if (x.fn && tail.startsWith('(')) ins = ins.slice(0, -1);   // дужка вже є
    if (x.cls === 'p' && tail.startsWith(']')) tail = tail.slice(1);
    inp.value = v.slice(0, FXS_FROM) + ins + tail;
    const at = FXS_FROM + ins.length;
    inp.setSelectionRange(at, at);
    fxSugClose();
    inp.dispatchEvent(new Event('input', { bubbles: true }));   // перевірка + наступна підказка
    inp.focus();
}

$('peFx').addEventListener('keydown', (e) => {
    if (!FXS.length || fxSugEl.hidden) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        FXS_I = (FXS_I + (e.key === 'ArrowDown' ? 1 : -1) + FXS.length) % FXS.length;
        fxSugPaint();
        const on = fxSugEl.querySelector('.on');
        if (on) on.scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Tab' || e.key === 'Enter') {
        e.preventDefault();
        fxAccept(FXS_I);
    } else if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        fxSugClose();
    }
});
$('peFx').addEventListener('click', fxSuggest);
$('peFx').addEventListener('blur', () => { setTimeout(fxSugClose, 150); fxApplyPretty(); });
if (fxSugEl) {
    fxSugEl.addEventListener('mousedown', (e) => {
        e.preventDefault();                                 // не забирати фокус із рядка
        const d = e.target.closest('[data-i]');
        if (d) fxAccept(Number(d.dataset.i));
    });
}
/* хто пише формули — вирішує адміністратор */
$('peFxUsers').addEventListener('click', async () => {
    const r = await apiGet('/api/herd/formula-users');
    if (!r || !r.ok) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
    $('peFxUsersList').innerHTML = (r.users || []).map((u) =>
        `<label class="${u.admin ? 'adm' : ''}"><input type="checkbox" value="${u.id}"`
        + `${u.on ? ' checked' : ''}${u.admin ? ' disabled' : ''}> ${escapeHtml(u.name)}`
        + `${u.admin ? ' · адміністратор' : ''}</label>`).join('');
    $('peFxUsersModal').hidden = false;
});
document.querySelectorAll('[data-fxu-close]').forEach((el) =>
    el.addEventListener('click', () => { $('peFxUsersModal').hidden = true; }));
$('peFxUsersSave').addEventListener('click', async () => {
    const ids = [...document.querySelectorAll('#peFxUsersList input:checked:not(:disabled)')]
        .map((x) => Number(x.value));
    const r = await apiSend('/api/herd/formula-users', 'POST', { ids });
    if (!r || r.ok === false) { toast((r && r.error) || 'Не збереглося', 'error'); return; }
    $('peFxUsersModal').hidden = true;
    toast('Збережено', 'success');
});
document.querySelectorAll('#ppEditModal [data-close]').forEach((el) =>
    el.addEventListener('click', () => { $('ppEditModal').hidden = true; }));
if ($('ppTable')) load();   // запускаємось лише за наявності розмітки
})();
