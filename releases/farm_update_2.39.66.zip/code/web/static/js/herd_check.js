/* Перевірка стада (Роман 2026-09-19): «у всіх параметрів повинні бути
   значення — або якесь є, або прочерк, але щоб не було пусто».
   Сторінка показує, де в живих тварин порожньо, і тут же дає заповнити:
   конкретним значенням або прочерком. Наявні значення не чіпаються. */
'use strict';

(function () {
    const $ = (id) => document.getElementById(id);
    const DASH = '—';
    let DATA = null, SECTIONS = [];

    const esc = (s) => escapeHtml(String(s === null || s === undefined ? '' : s));
    const fmt = (n) => Number(n).toLocaleString('uk-UA');
    // коротку назву з пробілами чи знаками беремо в [ ] — так її читає мова формул
    const nm = (s) => (/^[\p{L}\d_/]+$/u.test(s) ? s : `[${s}]`);

    function optionsOf(p) {
        if (p.key === 'group') return SECTIONS.map((x) => ({ c: x, l: x }));
        if (p.key === 'sex') return [{ c: 'F', l: 'Жіноча' }, { c: 'M', l: 'Чоловіча' }];
        try {
            const o = JSON.parse(p.options || '[]');
            return Array.isArray(o) ? o.map((x) => (typeof x === 'object'
                ? { c: String(x.c), l: `${x.c} — ${x.l}` } : { c: String(x), l: String(x) })) : [];
        } catch (e) { return []; }
    }

    function fieldHtml(p) {
        const opts = optionsOf(p);
        if (opts.length) {
            return `<select data-v="${esc(p.key)}"><option value="">— значення —</option>${
                opts.map((o) => `<option value="${esc(o.c)}">${esc(o.l)}</option>`).join('')}</select>`;
        }
        const type = p.dtype === 'date' ? 'date' : 'text';
        const ph = { int: 'ціле число', float: 'число', number: 'число', multi: 'напр. 1, 4' }[p.dtype] || 'значення';
        return `<input type="${type}" data-v="${esc(p.key)}" placeholder="${ph}"
            ${['int', 'float', 'number'].includes(p.dtype) ? 'inputmode="decimal"' : ''}>`;
    }

    // суперечність, яку виправляють вручну: кількість, пояснення, номери
    function issueHtml(p) {
        const tags = p.tags || [];
        const list = tags.slice(0, 12).map((t) =>
            `<a href="/herd/animals?f=${encodeURIComponent(`=BODY(id name age group) FILTER(id=${t})`)}">${esc(t)}</a>`)
            .join(', ') + (tags.length > 12 ? ` <span title="${esc(tags.join(', '))}">і ще ${tags.length - 12}</span>` : '');
        return `<tr data-k="${esc(p.key)}">
            <td class="hck-nm">${esc(p.label)}</td>
            <td class="hck-cnt"><b>${fmt(p.issue)}</b> тварин</td>
            <td><div class="hck-note">${esc(p.hint)}</div><div class="hck-tags">№ ${list}</div></td>
        </tr>`;
    }

    function rowHtml(p, total) {
        if (p.issue) return issueHtml(p);
        const conf = p.conflict || 0;
        const filled = total ? Math.round(((total - p.empty - conf) / total) * 100) : 100;
        const ok = !p.empty && !conf;
        // лише ті, хто в стаді — перевірка теж рахує тільки живих
        const f = `=BODY(id name ${nm(p.short)}) FILTER(${nm(p.short)} empty status=active)`;
        const cnt = ok ? '<b>заповнено</b>' : [
            p.empty ? `<b>${fmt(p.empty)}</b> із ${fmt(total)}` : '',
            conf ? `<b>${fmt(conf)}</b> не за станом` : ''].filter(Boolean).join(' · ');
        const byState = p.key === 'birth_date' && !ok
            ? `<button type="button" class="btn${p.empty ? '' : ' btn-primary'}" data-fill="state"
                title="Розрахувати з лактації, дати отелу, осіменіння або віку секції">За станом</button>` : '';
        let act;
        if (ok) act = '<span class="hck-done">✓ у всіх є значення</span>';
        else if (!p.empty) act = `<div class="hck-act">${byState}</div>`;
        else act = `<div class="hck-act">
                ${fieldHtml(p)}
                <button type="button" class="btn btn-primary" data-fill="value">Заповнити порожні</button>
                ${byState}
                ${p.key === 'name' ? `<button type="button" class="btn" data-fill="dam"
                    title="Кличка на ту саму літеру, що й кличка матері">За матірʼю</button>` : ''}
                ${p.dash_ok ? `<button type="button" class="btn" data-fill="dash"
                    title="Поставити «—»: значення свідомо немає">Прочерк</button>` : ''}
                <a class="hck-go" href="/herd/animals?f=${encodeURIComponent(f)}"
                    title="Відкрити цих тварин у «Роботі зі стадом»">показати тварин</a>
            </div>`;
        return `<tr data-k="${esc(p.key)}">
            <td class="hck-nm">${esc(p.label)}<small>${esc(p.short)}</small></td>
            <td class="hck-cnt${ok ? ' ok' : ''}">${cnt}
                <span class="hck-bar"><i style="width:${filled}%"></i></span></td>
            <td>${act}</td>
        </tr>`;
    }

    function render() {
        if (!DATA) return;
        const all = $('hckShowAll').checked;
        const list = DATA.params.filter((p) => all || p.empty || p.conflict || p.issue);
        $('hckSum').innerHTML = `<b>${fmt(DATA.total)}</b> тварин у стаді · `
            + (DATA.bad
                ? `<span class="bad"><b>${DATA.bad}</b> параметрів із пропусками · `
                  + `<b>${fmt(DATA.cells)}</b> порожніх значень`
                  + (DATA.conflicts ? ` · <b>${fmt(DATA.conflicts)}</b> не за станом` : '') + '</span>'
                : '<span class="ok"><b>усе заповнено</b></span>');
        if (!list.length) {
            $('hckBody').innerHTML = '<tr><td colspan="3" class="hck-done">'
                + 'Пропусків немає — у кожної тварини в кожному параметрі є значення або прочерк.</td></tr>';
            return;
        }
        const secs = [];
        list.forEach((p) => {
            let g = secs.find((x) => x.k === p.section);
            if (!g) { g = { k: p.section, list: [] }; secs.push(g); }
            g.list.push(p);
        });
        $('hckBody').innerHTML = secs.map((g) =>
            `<tr class="hck-sec"><td colspan="3">${esc(g.k)}</td></tr>`
            + g.list.map((p) => rowHtml(p, DATA.total)).join('')).join('');
    }

    async function load() {
        const [r, s] = await Promise.all([apiGet('/api/herd/check'), apiGet('/api/herd/sections')]);
        if (!r || r.ok === false) { $('hckSum').textContent = (r && r.error) || 'Не вдалося прочитати'; return; }
        DATA = r;
        SECTIONS = ((s && s.sections) || []).filter((x) => x.is_active !== 0)
            .map((x) => x.name).filter(Boolean);
        render();
    }

    async function fill(key, value) {
        const p = DATA.params.find((x) => x.key === key);
        if (!p) return;
        const what = value === DASH ? 'прочерком «—»' : `значенням «${value}»`;
        const ok = await confirmAction(
            `Заповнити ${fmt(p.empty)} порожніх «${p.label}» ${what}? Наявні значення не зміняться.`,
            { ok: 'Заповнити' });
        if (!ok) return;
        const r = await apiSend('/api/herd/check/fill', 'POST', { key, value });
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
        toast(`Заповнено: ${fmt(r.filled)}`, 'success');
        if (r.check) { DATA = r.check; render(); } else load();
    }

    // клички приплоду: перша літера — як у клички матері
    async function namesByDam() {
        const d = await apiSend('/api/herd/check/names', 'POST', { dry: true });
        if (!d || d.ok === false) { toast((d && d.error) || 'Не вдалося', 'error'); return; }
        const left = d.no_dam + d.no_name;
        if (!d.count) {
            toast(`Нікому дати кличку за матірʼю: ${fmt(d.no_dam)} без матері, `
                + `${fmt(d.no_name)} — мати без клички`, 'error');
            return;
        }
        const ex = d.examples.map((x) => `${x.name} (мати ${x.dam_name})`).join(', ');
        const ok = await confirmAction(
            `Дати кличку ${fmt(d.count)} тваринам — на літеру клички матері, напр.: ${ex}.`
            + (left ? ` Лишаться без клички ${fmt(left)}: ${fmt(d.no_dam)} без матері, `
                + `${fmt(d.no_name)} — мати без клички.` : ''),
            { ok: 'Дати клички' });
        if (!ok) return;
        const r = await apiSend('/api/herd/check/names', 'POST', {});
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
        toast(`Клички дано: ${fmt(r.count)}`, 'success');
        if (r.check) { DATA = r.check; render(); } else load();
    }

    const dmy = (v) => (v ? v.split('-').reverse().join('.') : '—');
    // дата народження з лактації, отелу, осіменіння або віку секції
    async function birthByState() {
        const d = await apiSend('/api/herd/check/birth', 'POST', { dry: true });
        if (!d || d.ok === false) { toast((d && d.error) || 'Не вдалося', 'error'); return; }
        if (!d.count) { toast('Розраховувати нічого — дати узгоджені зі станом', 'success'); return; }
        const ex = d.examples.slice(0, 3).map((x) =>
            `№${x.tag}: ${dmy(x.old)} → ${dmy(x.new)} (${x.rule})`).join('; ');
        const parts = [d.empty ? `${fmt(d.empty)} порожніх` : '',
            d.conflict ? `${fmt(d.conflict)} таких, що суперечать стану` : ''].filter(Boolean).join(' і ');
        const ok = await confirmAction(
            `Розрахувати дату народження для ${fmt(d.count)} тварин (${parts}). Напр.: ${ex}.`
            + ' Разом зі зміною зсунеться й отел матері, яким записано тварину, якщо це не ламає її історію.',
            { ok: 'Розрахувати' });
        if (!ok) return;
        const r = await apiSend('/api/herd/check/birth', 'POST', {});
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося', 'error'); return; }
        toast(`Дату розраховано: ${fmt(r.count)}`, 'success');
        if (r.check) { DATA = r.check; render(); } else load();
    }

    document.addEventListener('DOMContentLoaded', () => {
        if (!$('hckBody')) return;
        $('hckShowAll').addEventListener('change', render);
        $('hckBody').addEventListener('click', (e) => {
            const b = e.target.closest('[data-fill]');
            if (!b) return;
            const tr = b.closest('tr');
            const key = tr.dataset.k;
            if (b.dataset.fill === 'dash') { fill(key, DASH); return; }
            if (b.dataset.fill === 'dam') { namesByDam(); return; }
            if (b.dataset.fill === 'state') { birthByState(); return; }
            const inp = tr.querySelector('[data-v]');
            const v = (inp.value || '').trim();
            if (!v) { inp.focus(); toast('Вкажіть значення або натисніть «Прочерк»', 'error'); return; }
            fill(key, v);
        });
        load();
    });
}());
