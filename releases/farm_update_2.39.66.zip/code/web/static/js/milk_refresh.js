'use strict';
/* «⟳ Оновити з Excel» на сторінках молока (Роман 2026-09-19: «хочу кнопкою
   оновити дані»). На сервері — книга забирається з OneDrive зараз, формули
   перераховуються, надій і продаж фіксуються в базу; далі сторінка
   перемальовується з новими даними. */
(function () {
    const btn = document.getElementById('milkRefresh');
    if (!btn) return;
    const msg = document.getElementById('milkRefreshMsg');
    btn.addEventListener('click', async () => {
        if (btn.disabled) return;
        btn.disabled = true;
        const was = btn.textContent;
        btn.textContent = '⟳ Оновлюю…';
        if (msg) msg.textContent = 'Забираю книгу з OneDrive і перераховую…';
        let r;
        try {
            r = await apiSend('/api/milk/refresh', 'POST', {});
        } catch (e) {
            r = { ok: false, error: 'Сервер не відповів' };
        }
        btn.disabled = false;
        btn.textContent = was;
        if (!r || !r.ok) {
            if (msg) msg.textContent = '';
            toast((r && r.error) || 'Не вдалося оновити', 'error');
            return;
        }
        const when = r.saved_at ? ' · книга збережена ' + r.saved_at : '';
        toast((r.pulled ? 'Оновлено з Excel' : 'Змін у книзі немає — дані вже свіжі') + when
            + (r.note ? ' (' + r.note + ')' : ''), r.note ? 'warn' : 'success');
        setTimeout(() => location.reload(), 700);
    });
}());
