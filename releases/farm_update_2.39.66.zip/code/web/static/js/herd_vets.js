/* Ветеринари — ОДИН спільний список людей ферми.
   Роман 2026-09-16: «ветеринар може бути і техніком штучного осіменіння, і
   звичайним ветеринаром… простіше зробити одну вкладку, а довідники брати з
   того списку — вони можуть перетинатися». Тож людина заводиться раз, а
   довідники під конкретну роботу лише позначають, хто туди входить. */
'use strict';
(function () {
    const box = document.getElementById('vtBox');
    if (!box) return;
    let REF = null;

    function render() {
        const items = (REF && REF.items) || [];
        document.getElementById('vtCount').textContent = items.length ? '· ' + items.length : '';
        box.innerHTML = `
            <table class="hp-tbl vt-tbl">
                <thead><tr>
                    <th class="vt-c">Код</th><th class="vt-nm">Прізвище, імʼя</th>
                    <th class="vt-nt">Примітка</th><th>Де задіяний</th>
                    <th class="c vt-onc">Працює</th><th class="c vt-xc"></th>
                </tr></thead>
                <tbody>${items.length ? items.map((it) => `
                    <tr data-item="${it.id}" class="${it.is_active ? '' : 'is-off'}">
                        <td><input type="text" class="rf-in vt-code" value="${escapeHtml(it.code || '')}"
                                   placeholder="—"></td>
                        <td><input type="text" class="rf-in vt-label" value="${escapeHtml(it.label || '')}"></td>
                        <td><input type="text" class="rf-in vt-note" value="${escapeHtml(it.note || '')}"
                                   placeholder="посада, телефон…"></td>
                        <td class="vt-used">${(it.used_in || []).length
                            ? it.used_in.map((n) => `<span class="vt-tag">${escapeHtml(n)}</span>`).join('')
                            : '<span class="text-mute">поки ніде</span>'}</td>
                        <td class="c"><input type="checkbox" class="vt-on"${it.is_active ? ' checked' : ''}></td>
                        <td class="c"><button type="button" class="eb-x" data-del="${it.id}"
                                title="Прибрати людину зі списку">✕</button></td>
                    </tr>`).join('')
                    : '<tr><td colspan="6" class="hp-empty">Список порожній — додайте першу людину</td></tr>'}
                </tbody>
            </table>
            <div class="vt-newrow">
                <input type="text" class="rf-in vt-ncode" placeholder="код">
                <input type="text" class="rf-in vt-nlabel" placeholder="прізвище, імʼя">
                <button type="button" class="btn btn-ghost btn-sm" id="vtAdd">+ Додати</button>
            </div>`;
        bind();
    }

    function bind() {
        box.querySelectorAll('tr[data-item]').forEach((tr) => {
            const id = +tr.dataset.item;
            let t = null;
            const save = (extra) => {
                clearTimeout(t);
                t = setTimeout(async () => {
                    const r = await apiSend('/api/herd/ref-items', 'POST', Object.assign({
                        id,
                        code: tr.querySelector('.vt-code').value.trim(),
                        label: tr.querySelector('.vt-label').value.trim(),
                        note: tr.querySelector('.vt-note').value.trim(),
                    }, extra || {}));
                    if (!r || !r.ok) toast((r && r.error) || 'Не збережено', 'error');
                }, 600);
            };
            tr.querySelectorAll('.rf-in').forEach((i) => i.addEventListener('input', () => save()));
            tr.querySelector('.vt-on').addEventListener('change', (e) => {
                tr.classList.toggle('is-off', !e.target.checked);
                save({ is_active: e.target.checked });
            });
        });
        box.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
            const tr = b.closest('tr');
            const used = tr.querySelectorAll('.vt-tag').length;
            const nm = tr.querySelector('.vt-label').value.trim() || 'людину';
            const msg = used
                ? `«${nm}» входить у ${used} довідник(ів). Прибрати зі спільного списку?`
                : `Прибрати «${nm}» зі списку?`;
            if (!(await confirmAction(msg, { ok: 'Прибрати' }))) return;
            const r = await apiSend('/api/herd/ref-items/' + b.dataset.del, 'DELETE');
            if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
            load();
        }));
        const add = document.getElementById('vtAdd');
        // ⚠️ Замок + свідоме підтвердження збігу. Сервер відхиляє точний
        // дубль, а звідси `force` не йшов узагалі — однофамільця (обидва без
        // коду) додати було б НЕМОЖЛИВО.
        let vtAdding = false;
        if (add) add.addEventListener('click', async () => {
            if (vtAdding) return;
            vtAdding = true;
            add.disabled = true;
            try {
                const label = box.querySelector('.vt-nlabel').value.trim();
                const code = box.querySelector('.vt-ncode').value.trim();
                if (!label && !code) { box.querySelector('.vt-nlabel').focus(); return; }
                let r = await apiSend('/api/herd/ref-items', 'POST',
                    { ref_id: REF.id, code, label });
                if (r && !r.ok && /вже є/.test(r.error || '')) {
                    if (!(await confirmAction(
                        `${r.error} Усе одно додати ще один такий запис?`,
                        { ok: 'Усе одно додати' }))) return;
                    r = await apiSend('/api/herd/ref-items', 'POST',
                        { ref_id: REF.id, code, label, force: true });
                }
                if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
                load();
            } finally {
                vtAdding = false;
                add.disabled = false;
            }
        });
        box.querySelectorAll('.vt-nlabel, .vt-ncode').forEach((inp) =>
            inp.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') document.getElementById('vtAdd').click();
            }));
    }

    async function load() {
        const r = await apiGet('/api/herd/vets');
        if (!r || !r.ok) { box.innerHTML = '<p class="hp-empty">Не вдалося прочитати список</p>'; return; }
        REF = r.ref;
        render();
    }
    load();
})();
