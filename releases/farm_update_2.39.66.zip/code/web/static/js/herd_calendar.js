/* Календар стада: списки, які ферма складає сама.

   Роман 2026-09-17: «списки я можу створювати дуже гнучко і поглиблено…
   один список на всю ширину… налаштовую відображення параметрів… потім
   переключитися на календар і побачити, яку саме дату цей список буде діяти.
   І ще діаграму Ганта».

   Список = відбір (ті самі фільтри, що в груповому вводі) + дні тижня, на
   які він формується + колонки + подія, яку з нього вносять. «Строку» немає
   (Роман: «це налаштовується параметрами: „Днів з осіменіння“ ≥ 35») — на
   майбутній день параметри «днів від…» просто рахуються на той день.
   Рахується тут, у браузері, з тих самих значень, що й груповий ввід. */
'use strict';

/* дробові числа — з комою й розрядами: 2349.5 → «2 349,5» (Роман 2026-09-18) */
function numText(raw, dtype) {
    const s = String(raw === null || raw === undefined ? '' : raw).trim().replace(',', '.');
    if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
    if (!['float', 'number'].includes(dtype || '')) return null;
    const n = parseFloat(s);
    const dec = (s.split('.')[1] || '').length;
    return n.toLocaleString('uk-UA', { minimumFractionDigits: Math.min(dec, 3),
        maximumFractionDigits: Math.min(Math.max(dec, 1), 3) });
}
(function () {

const $ = (id) => document.getElementById(id);
const LS_VIEW = 'herd:cal_view', LS_RANGE = 'herd:cal_range';
const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch (_) { return ''; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) { /* ignore */ } };

let LISTS = [], COLORS = [], EVENTS = [], PARAMS = [], CHOICES = {}, ANIMALS = [];
let cur = null;                   // список, який зараз налаштовують
let cfgOpen = false;              // чи відкрито його налаштування
let view = lsGet(LS_VIEW) || 'list';
let month = TODAY_M();            // 'YYYY-MM' у вигляді «Календар» — спільний для всіх
const selDay = {};                // обраний день у кожному списку
let loadedKeys = new Set();
/* згорнуті списки — у кожного свій стан (Роман: «списки скриваються, розкриваються») */
const LS_CLOSED = 'herd:cal_closed';
let closed = new Set((() => { try { return JSON.parse(lsGet(LS_CLOSED) || '[]'); } catch (_) { return []; } })());
const saveClosed = () => lsSet(LS_CLOSED, JSON.stringify([...closed]));
function TODAY_M() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; }

/* ─────────── дати ─────────── */
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const TODAY = iso(new Date());
const addDays = (s, n) => { const d = parse(s); d.setDate(d.getDate() + n); return iso(d); };
const diff = (a, b) => Math.round((parse(a) - parse(b)) / 86400000);
const dmy = (s) => s ? `${s.slice(8, 10)}.${s.slice(5, 7)}.${s.slice(0, 4)}` : '';
const MONTHS = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень', 'Липень',
    'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'];
const WD = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];
const WD_LONG = ['понеділок', 'вівторок', 'середа', 'четвер', 'пʼятниця', 'субота', 'неділя'];
const wdOf = (s) => ((parse(s).getDay() + 6) % 7) + 1;      // 1 = пн … 7 = нд
const MON_SHORT = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];

/* ─────────── назви — з конструктора ─────────── */
const paramOf = (k) => PARAMS.find((p) => p.key === k) || null;
const pLabel = (k) => (paramOf(k) || {}).label || herdLabel(k, k);
const evByKey = (k) => EVENTS.find((e) => e.key === k) || null;

function choiceLabel(key, v) {
    const c = (CHOICES[key] || []).find((x) => String(x.value) === String(v));
    return herdOpt(key, v, c ? c.label : v);
}

/* порожня назва — «Подія · варіанти відбору» */
function nameOf(L) {
    if (L.name) return L.name;
    const ev = evByKey(L.event);
    const parts = [ev ? ev.name : herdEvent(L.event, 'Список')];
    (L.filters || []).forEach((f) => {
        // стать у назві не потрібна — вона й так видна з відбору
        if (f.key !== 'sex' && f.vals && f.vals.length && !['empty', 'nempty'].includes(f.op)) {
            parts.push((f.op === 'ne' ? 'не ' : '') + f.vals.map((v) => choiceLabel(f.key, v)).join(', '));
        }
    });
    return parts.join(' · ');
}

const colLabel = (k) => pLabel(k);
const colOk = (k) => !!paramOf(k);

/* списки зі «Строком» — до фільтрів і днів формування */
function normalize(L) {
    if (L.v !== 3) {
        L.cols = (L.cols || []).filter((k) => !String(k).startsWith('__'));
        if (L.sort && String(L.sort.key).startsWith('__')) L.sort = { key: 'tag', dir: 'asc' };
        if (L.group === 'due') L.group = '';
        L.v = 3;
    }
    L.days = L.days || [];
    // сортування — кількома колонками по черзі (Роман 2026-09-17)
    if (!Array.isArray(L.sorts) || !L.sorts.length) L.sorts = [L.sort || { key: 'tag', dir: 'asc' }];
    delete L.sort;
    // групування — кількома параметрами вкладено (Роман 2026-09-17)
    if (!Array.isArray(L.groups)) L.groups = L.group ? [L.group] : [];
    delete L.group;
    return L;
}

/* ─────────── розрахунок ─────────── */
function formulaOf(k) {
    const p = paramOf(k);
    if (!p || !p.formula) return null;
    const src = String(p.formula).trim();
    if (src.startsWith('=')) {
        // рядок формули: «днів/місяців від дати» — DAYS(TODAY(), x) чи MONTHS(TODAY(), x),
        // можна й усередині IF(…) — тоді на інший день рахуємо так само
        const m = src.match(/\b(DAYS|MONTHS)\s*\(\s*TODAY\s*\(\s*\)\s*[,;]\s*\[?([^\],)]+?)\]?\s*\)/i);
        if (!m) return null;
        const w = m[2].trim().toLowerCase();
        const bp = PARAMS.find((x) => [x.short, x.key, x.label].some((y) => (y || '').toLowerCase() === w));
        return { op: m[1].toUpperCase() === 'DAYS' ? 'date_diff' : 'month_diff',
            a: '__today__', b: bp ? bp.key : '' };
    }
    try { const f = JSON.parse(p.formula); return f && f.op ? f : null; } catch (_) { return null; }
}
/* параметр «днів/місяців від дати» на інший день: сьогодні 30 — через тиждень 37 */
function valueOn(a, k, D) {
    const raw = (a.p || {})[k];
    if (D === TODAY) return raw;
    const f = formulaOf(k);
    if (!f || f.a !== '__today__' || !['date_diff', 'month_diff'].includes(f.op)) return raw;
    if (raw === '' || raw === null || raw === undefined) return raw;   // умова «лише якщо» не виконана
    const n = parseFloat(String(raw).replace(',', '.'));
    if (!isFinite(n)) return raw;
    if (f.op === 'date_diff') return String(n + diff(D, TODAY));
    const b = String((a.p || {})[f.b] || '').slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(b)) {
        const d1 = parse(b), d2 = parse(D);
        let m = (d2.getFullYear() - d1.getFullYear()) * 12 + d2.getMonth() - d1.getMonth();
        if (d2.getDate() < d1.getDate()) m -= 1;
        return String(m);
    }
    return String(n + Math.floor(diff(D, TODAY) / 30.44));
}

const isFormDay = (L, D) => !(L.days || []).length || L.days.includes(wdOf(D));
/* найближчий день формування від сьогодні */
function nextDay(L) {
    for (let i = 0; i < 7; i++) { const d = addDays(TODAY, i); if (isFormDay(L, d)) return d; }
    return TODAY;
}

let FLT = null;
/* додаткові списки (Роман 2026-09-17: «підсписок пропущених»): фільтри основного,
   а свої умови замінюють умову основного на той самий параметр */
function subFilters(L, sub) {
    const own = sub.filters || [];
    const keys = new Set(own.map((f) => f.key));
    return [...(L.filters || []).filter((f) => !keys.has(f.key)), ...own];
}
/* блоки на день D: основний + додаткові (лише на найближчий день формування);
   тварина, що вже є вище, у нижчий блок не потрапляє */
function blocksOf(L, D) {
    const main = membersOf(L, D);
    const out = [{ name: '', rows: main }];
    if (D !== nextDay(L)) return out;
    const seen = new Set(main.map((a) => a.id));
    (L.subs || []).forEach((sub) => {
        const rows = membersOf(L, D, subFilters(L, sub)).filter((a) => !seen.has(a.id));
        rows.forEach((a) => seen.add(a.id));
        out.push({ name: sub.name || 'Додатковий', rows, sub: true });
    });
    return out;
}
const blocksCount = (bl) => bl.reduce((t, b) => t + b.rows.length, 0);

function membersOf(L, D, filters) {
    const day = D || TODAY;
    const flt = filters || L.filters || [];
    const out = [];
    ANIMALS.forEach((a) => {
        let x = a;
        if (day !== TODAY) {
            const p = Object.assign({}, a.p);
            flt.forEach((f) => { p[f.key] = valueOn(a, f.key, day); });
            x = { p, pl: a.pl };
        }
        if (flt.every((f) => FLT.passes(x, f))) out.push(a);
    });
    return day === TODAY ? sortRows(L, out) : out;
}

function sortRows(L, rows) {
    const keys = (L.sorts && L.sorts.length ? L.sorts : [{ key: 'tag', dir: 'asc' }]);
    const val = (a, k) => {
        if (k === 'tag') return String(a.tag || '');
        const raw = (a.p || {})[k];
        return raw === null || raw === undefined ? '' : String((a.pl || {})[k] || raw);
    };
    const num = (v) => (/^-?\d+([.,]\d+)?$/.test(v) ? parseFloat(v.replace(',', '.')) : null);
    // списки (секції, коди) — у порядку конструктора, а не за абеткою
    const ord = {};
    keys.forEach((s) => {
        const ch = CHOICES[s.key] || [];
        if (ch.length) {
            ord[s.key] = new Map();
            ch.forEach((c, i) => { ord[s.key].set(String(c.value), i); ord[s.key].set(String(c.label), i); });
        }
    });
    const cmp = (x, y, k, dir) => {
        const a = val(x, k), b = val(y, k);
        if (a === '' && b !== '') return 1;               // порожні — завжди в кінці
        if (b === '' && a !== '') return -1;
        if (ord[k]) {
            const ia = ord[k].has(String((x.p || {})[k])) ? ord[k].get(String((x.p || {})[k])) : (ord[k].has(a) ? ord[k].get(a) : 1e6);
            const ib = ord[k].has(String((y.p || {})[k])) ? ord[k].get(String((y.p || {})[k])) : (ord[k].has(b) ? ord[k].get(b) : 1e6);
            if (ia !== ib) return (ia - ib) * dir;
        }
        const na = num(a), nb = num(b);
        const c = (na !== null && nb !== null) ? na - nb : a.localeCompare(b, 'uk', { numeric: true });
        return c * dir;
    };
    return rows.sort((x, y) => {
        for (const s of keys) {
            const c = cmp(x, y, s.key, s.dir === 'desc' ? -1 : 1);
            if (c) return c;
        }
        return cmp(x, y, 'tag', 1);                       // однакові — за номером
    });
}

/* колонки таблиці на день D: «днів від…» теж на той день */
const withDay = (a, D) => {
    if (D === TODAY) return a;
    const p = Object.assign({}, a.p);
    Object.keys(p).forEach((k) => { p[k] = valueOn(a, k, D); });
    return Object.assign({}, a, { p });
};

/* ─────────── завантаження ─────────── */
function neededKeys() {
    const ks = new Set(['group']);
    LISTS.forEach((L) => {
        (L.filters || []).forEach((f) => ks.add(f.key));
        (L.subs || []).forEach((sb) => (sb.filters || []).forEach((f) => ks.add(f.key)));
        (L.cols || []).forEach((c) => ks.add(c));
    });
    // від чого рахуються «днів від…» — потрібне, щоб рахувати місяці на інший день
    [...ks].forEach((k) => { const f = formulaOf(k); if (f && f.b && paramOf(f.b)) ks.add(f.b); });
    return [...ks].filter((k) => paramOf(k));
}

async function loadAnimals() {
    const keys = neededKeys();
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(',')));
    if (!r || !r.ok) { toast((r && r.error) || 'Помилка', 'error'); return; }
    ANIMALS = r.items || [];
    loadedKeys = new Set(keys);
}

async function ensureKeys() {
    if (neededKeys().some((k) => !loadedKeys.has(k))) await loadAnimals();
}

async function boot() {
    const [ev, ls] = await Promise.all([apiGet('/api/herd/events?active=1'), apiGet('/api/herd/cal-lists')]);
    if (!ev || !ev.ok || !ls || !ls.ok) {
        $('clLists').innerHTML = '<div class="cl-empty">Не вдалося завантажити календар</div>';
        return;
    }
    EVENTS = ev.events || [];
    PARAMS = ev.params || [];
    CHOICES = {};
    PARAMS.forEach((p) => { CHOICES[p.key] = p.choices || []; });
    LISTS = (ls.lists || []).map(normalize);
    COLORS = ls.colors || [];
    await loadAnimals();
    renderAll();
}

/* ─────────── збереження ─────────── */
function save() {
    clearTimeout(save.t);
    $('cfSaved').textContent = '…';
    save.t = setTimeout(async () => {
        const r = await apiSend('/api/herd/cal-lists', 'POST', { lists: LISTS });
        $('cfSaved').textContent = r && r.ok ? '✓ збережено' : 'не збережено';
        if (r && r.ok) setTimeout(() => { $('cfSaved').textContent = ''; }, 1500);
    }, 600);
}
const changed = async () => { save(); await ensureKeys(); updateAll(); };

/* ─────────── каркас: усі списки один під одним ─────────── */
function renderAll() {
    renderTop();
    const box = $('clLists');
    $('clHold').appendChild($('clCfg'));             // налаштування не губляться при перебудові
    if (view === 'gantt') {
        box.innerHTML = '<div class="cl-gantt" id="clGantt"></div>';
        renderGantt();
        return;
    }
    box.innerHTML = LISTS.map((L) => `<div class="cl-panel" data-id="${escapeHtml(L.id)}">
        <div class="cl-head"><span class="cl-grip" draggable="true" title="Потягніть, щоб переставити">⠿</span>
            <span class="cl-no"></span><span class="cl-chev"></span><h2></h2><span class="cl-cnt"></span>
            <span class="hp-sp"></span><a class="cl-go" hidden></a>
            <button type="button" class="cl-print" title="Друк на A4 — з попереднім переглядом">🖨</button>
            <button type="button" class="cl-gear" title="Налаштувати список">⚙</button></div>
        <div class="cl-title" hidden></div><div class="cl-slot"></div><div class="cl-body"></div></div>`).join('')
        || '<div class="cl-empty">Списків немає — «+ список»</div>';
    if (cur && cfgOpen && LISTS.includes(cur)) {
        const slot = box.querySelector(`.cl-panel[data-id="${CSS.escape(cur.id)}"] .cl-slot`);
        if (slot) { slot.appendChild($('clCfg')); renderCfg(); }
    } else {
        cfgOpen = false;
    }
    updateAll();
}

function renderTop() {
    document.querySelectorAll('#clView .seg-btn').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.v === view));
    const t = $('clTools');
    if (view === 'cal') {
        const [y, m] = month.split('-').map(Number);
        t.innerHTML = `<button type="button" data-m="-1">‹</button><b>${MONTHS[m - 1]} ${y}</b>
            <button type="button" data-m="1">›</button><button type="button" data-m="0">Сьогодні</button>`;
    } else if (view === 'gantt') {
        const span = +(lsGet(LS_RANGE) || 60);
        t.innerHTML = `<span class="segmented">${[[30, 'Місяць'], [60, '2 місяці'], [120, '4 місяці'], [365, 'Рік']]
            .map(([v, n]) => `<button type="button" class="seg-btn${v === span ? ' is-active' : ''}" data-r="${v}">${n}</button>`).join('')}</span>`;
    } else {
        t.innerHTML = '';
    }
}

$('clTools').addEventListener('click', (e) => {
    const m = e.target.closest('[data-m]'), r = e.target.closest('[data-r]');
    if (m) {
        const k = +m.dataset.m;
        if (k === 0) month = TODAY_M();
        else { const [y, mo] = month.split('-').map(Number); const d = new Date(y, mo - 1 + k, 1); month = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; }
        renderTop(); updateAll();
    } else if (r) {
        lsSet(LS_RANGE, r.dataset.r);
        renderTop(); renderGantt();
    }
});

function updateAll() {
    if (view === 'gantt') { renderGantt(); return; }
    LISTS.forEach(update);
}

const panelOf = (L) => $('clLists').querySelector(`.cl-panel[data-id="${CSS.escape(L.id)}"]`);
const listById = (id) => LISTS.find((L) => L.id === id) || null;

/* ─────────── налаштування списку ─────────── */
function renderCfg() {
    if (!cur) return;
    $('cfName').value = cur.name || '';
    $('cfName').placeholder = nameOf(Object.assign({}, cur, { name: '' }));
    $('cfEvent').innerHTML = '<option value="">— без події —</option>' + EVENTS.map((e) =>
        `<option value="${escapeHtml(e.key)}"${e.key === cur.event ? ' selected' : ''}>${escapeHtml(e.name)}</option>`).join('');
    $('cfColors').innerHTML = COLORS.map((c) =>
        `<button type="button" data-c="${c}" style="--sw:${c}"${c === cur.color ? ' class="on"' : ''}></button>`).join('');
    FLT.render();
    renderSubs();
    renderDays();
    renderDisplay();
    renderFont();
}

/* ─── додаткові списки в рівні «Фільтрація» ─── */
const SUB_FLT = new Map();          // id додаткового → його модуль фільтрів
function renderSubs() {
    const box = $('cfSubs');
    box.innerHTML = (cur.subs || []).map((sb, i) => `<div class="cl-subcfg" data-i="${i}">
        <div class="cl-row">
            <input type="text" class="cl-in w-name cl-subname" value="${escapeHtml(sb.name || '')}" placeholder="Назва, напр. Пропущені">
            <span class="cl-hint0">умови, що відрізняються від основного списку</span>
            <span class="hp-sp"></span>
            <button type="button" class="cl-del cl-subdel">Прибрати</button>
        </div>
        <div class="hf-bar"><div class="hf-list"></div><button type="button" class="hf-addbtn">+ умова</button></div>
    </div>`).join('');
    SUB_FLT.clear();
    box.querySelectorAll('.cl-subcfg').forEach((el) => {
        const sb = cur.subs[+el.dataset.i];
        sb.filters = sb.filters || [];
        const f = herdFilters({
            listEl: el.querySelector('.hf-list'),
            addBtn: el.querySelector('.hf-addbtn'),
            params: () => PARAMS,
            choices: () => CHOICES,
            animals: () => ANIMALS,
            filters: () => sb.filters,
            onChange: () => changed(),
        });
        f.render();
        SUB_FLT.set(sb.id, f);
    });
    renderTokens();
}
$('cfSubs').addEventListener('input', (e) => {
    const inp = e.target.closest('.cl-subname');
    if (!inp) return;
    cur.subs[+inp.closest('.cl-subcfg').dataset.i].name = inp.value.trim();
    renderTokens();
    save();
    update(cur);
});
$('cfSubs').addEventListener('click', (e) => {
    const del = e.target.closest('.cl-subdel');
    if (!del) return;
    cur.subs.splice(+del.closest('.cl-subcfg').dataset.i, 1);
    renderSubs();
    changed();
});
$('cfAddSub').addEventListener('click', () => {
    cur.subs = cur.subs || [];
    // найчастіше — ті самі умови, лише пропущений строк: копіюємо числові умови основного
    const copy = (cur.filters || []).filter((f) => { const p = paramOf(f.key); return p && ['int', 'float'].includes(p.dtype); })
        .map((f) => ({ key: f.key, op: 'gt', v: f.op === 'between' ? f.v2 : f.v }));
    cur.subs.push({ id: 's' + Date.now().toString(36), name: 'Пропущені', filters: copy });
    renderSubs();
    changed();
});

/* параметр прибрали з тіла — групування, сортування й «сховано» за ним теж зникають */
function dropRefs(L) {
    const has = new Set(L.cols || []);
    L.groups = (L.groups || []).filter((k) => has.has(k));
    L.sorts = (L.sorts || []).filter((x) => x.key === 'tag' || has.has(x.key));
    if (!L.sorts.length) L.sorts = [{ key: 'tag', dir: 'asc' }];
    L.hide = (L.hide || []).filter((c) => has.has(c));
}

/* ─── рівень 3: відображення ─── */
function renderDisplay() {
    const cols = (cur.cols || []).filter(colOk);
    $('cfCols').innerHTML = `<span class="cl-col fixed">${escapeHtml(herdLabel('tag', 'Номер тварини'))}</span>`
        + cols.map((k, i) => {
            const off = (cur.hide || []).includes(k);
            return `<span class="cl-col${off ? ' off' : ''}" draggable="true" data-i="${i}" data-k="${escapeHtml(k)}">
            <span class="g">⠿</span><button type="button" class="eye" title="${off ? 'Не показується в таблиці — лише для сортування й групування. Показати' : 'Сховати з таблиці (лишиться для сортування й групування)'}">${off ? '◌' : '●'}</button>${escapeHtml(colLabel(k))}<button type="button" class="x" title="Прибрати">✕</button></span>`;
        }).join('');
    const sortable = [{ key: 'tag', label: herdLabel('tag', 'Номер тварини') },
        ...cols.map((k) => ({ key: k, label: pLabel(k) }))];
    const used = new Set(cur.sorts.map((x) => x.key));
    $('cfSorts').innerHTML = cur.sorts.map((srt, i) => `<span class="cl-sort" data-i="${i}">
            <span class="n">${i + 1}.</span>
            ${i ? '<button type="button" class="up" data-f="up" title="Вище — сортувати за цим раніше">▲</button>' : '<span class="up-sp"></span>'}
            <select class="cl-in w-ev" data-f="key">${sortable.filter((c) => c.key === srt.key || !used.has(c.key)).map((c) =>
                `<option value="${escapeHtml(c.key)}"${c.key === srt.key ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')}</select>
            <button type="button" class="cl-in cl-dir" data-f="dir" title="${srt.dir === 'desc' ? 'За спаданням' : 'За зростанням'}">${srt.dir === 'desc' ? '↓' : '↑'}</button>
            ${cur.sorts.length > 1 ? '<button type="button" class="x" title="Прибрати">✕</button>' : ''}
        </span>`).join('')
        + (sortable.some((c) => !used.has(c.key)) ? '<button type="button" class="hf-addbtn" data-f="add">+ ще</button>' : '');
    const groupable = cols.map((k) => ({ key: k, label: pLabel(k) }));
    const gUsed = new Set(cur.groups);
    $('cfGroups').innerHTML = cur.groups.map((k, i) => `<span class="cl-sort" data-i="${i}">
            <span class="n">${i + 1}.</span>
            ${i ? '<button type="button" class="up" data-f="up" title="Вище — зовнішня група">▲</button>' : '<span class="up-sp"></span>'}
            <select class="cl-in w-ev">${groupable.filter((c) => c.key === k || !gUsed.has(c.key)).map((c) =>
                `<option value="${escapeHtml(c.key)}"${c.key === k ? ' selected' : ''}>${escapeHtml(c.label)}</option>`).join('')}</select>
            <button type="button" class="x" title="Прибрати">✕</button>
        </span>`).join('')
        + (groupable.some((c) => !gUsed.has(c.key))
            ? `<button type="button" class="hf-addbtn" data-f="add">${cur.groups.length ? '+ ще' : '+ групувати'}</button>` : '');
}

$('cfCols').addEventListener('click', (e) => {
    const x = e.target.closest('.cl-col button');
    if (!x) return;
    const k = x.closest('.cl-col').dataset.k;
    if (x.classList.contains('eye')) {
        // показувати чи ні: схований параметр лишається для сортування й групування
        const h = new Set(cur.hide || []);
        if (h.has(k)) h.delete(k); else h.add(k);
        cur.hide = [...h];
        renderDisplay();
        renderFit();
        changed();
        return;
    }
    cur.cols = cur.cols.filter((c) => c !== k);
    dropRefs(cur);
    renderDisplay();
    changed();
});
let colDrag = null;
$('cfCols').addEventListener('dragstart', (e) => {
    const c = e.target.closest('.cl-col[draggable]');
    if (!c) return;
    colDrag = c; c.classList.add('drag');
    try { e.dataTransfer.setData('text/plain', c.dataset.k); } catch (_) { /* ignore */ }
});
$('cfCols').addEventListener('dragover', (e) => {
    if (!colDrag) return;
    e.preventDefault();
    const over = e.target.closest('.cl-col[draggable]');
    if (!over || over === colDrag) return;
    const r = over.getBoundingClientRect();
    over.parentNode.insertBefore(colDrag, e.clientX > r.left + r.width / 2 ? over.nextSibling : over);
});
$('cfCols').addEventListener('dragend', () => {
    if (!colDrag) return;
    colDrag.classList.remove('drag'); colDrag = null;
    cur.cols = [...$('cfCols').querySelectorAll('.cl-col[draggable]')].map((c) => c.dataset.k);
    renderDisplay();
    changed();
});
$('cfSorts').addEventListener('change', (e) => {
    const row = e.target.closest('.cl-sort');
    if (!row) return;
    cur.sorts[+row.dataset.i].key = e.target.value;
    renderDisplay();
    changed();
});
$('cfSorts').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const row = b.closest('.cl-sort');
    if (b.dataset.f === 'add') {
        const used = new Set(cur.sorts.map((x) => x.key));
        // пропонуємо колонку таблиці, номер тварини — наостанок
        const free = [...(cur.cols || []).filter(colOk), 'tag'].find((k) => !used.has(k));
        if (free) {
            // сортування лише «за номером» (однакових номерів не буває, тож друге поле
            // ніколи б не спрацювало) — нове поле стає першим, номер — під ним
            if (cur.sorts.length === 1 && cur.sorts[0].key === 'tag') cur.sorts.unshift({ key: free, dir: 'asc' });
            else cur.sorts.push({ key: free, dir: 'asc' });
        }
    } else if (b.dataset.f === 'dir') {
        const srt = cur.sorts[+row.dataset.i];
        srt.dir = srt.dir === 'desc' ? 'asc' : 'desc';
    } else if (b.dataset.f === 'up') {
        const i = +row.dataset.i;
        [cur.sorts[i - 1], cur.sorts[i]] = [cur.sorts[i], cur.sorts[i - 1]];
    } else if (b.classList.contains('x')) {
        cur.sorts.splice(+row.dataset.i, 1);
    } else return;
    renderDisplay();
    changed();
});
$('cfGroups').addEventListener('change', (e) => {
    const row = e.target.closest('.cl-sort');
    if (!row) return;
    cur.groups[+row.dataset.i] = e.target.value;
    renderDisplay();
    changed();
});
$('cfGroups').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const row = b.closest('.cl-sort');
    if (b.dataset.f === 'add') {
        const free = (cur.cols || []).filter(colOk).find((k) => !cur.groups.includes(k));
        if (free) cur.groups.push(free);
    } else if (b.dataset.f === 'up') {
        const i = +row.dataset.i;
        [cur.groups[i - 1], cur.groups[i]] = [cur.groups[i], cur.groups[i - 1]];
    } else if (b.classList.contains('x')) {
        cur.groups.splice(+row.dataset.i, 1);
    } else return;
    renderDisplay();
    changed();
});

/* ─── ширина колонок, шрифт, аркуш A4 ─── */
const TWO_GAP_MM = window.herdPrint.TWO_GAP_MM;         // проміжок між колонками друку — з модуля
const DEF_W = { tag: 90, name: 110, __mark: 24, __no: 36 };
const colW = (L, k) => +((L.widths || {})[k]) || DEF_W[k] || 120;
const PX_MM = 25.4 / 96;                                  // 1 css-піксель при друку
const A4_MM = { p: 190, l: 277 };                         // ширина аркуша без полів 10 мм
const hasMarks = (L) => (L.subs || []).length > 0;
const tableWidth = (L) => [...(L.rownum ? ['__no'] : []), ...(hasMarks(L) ? ['__mark'] : []), 'tag', ...shownCols(L)].reduce((t, k) => t + colW(L, k), 0);
function tableStyle(L, all) {
    const f = L.font || {};
    const w = all.reduce((t, k) => t + colW(L, k), 0);
    return `width:${w}px;` + (f.size ? `font-size:${f.size}px;` : '')
        + (f.family ? `font-family:'${f.family}',sans-serif;` : '')
        + (f.bold ? 'font-weight:600;' : '') + (f.italic ? 'font-style:italic;' : '');
}
function renderFit() {
    if (!cur) return;
    const mm = Math.round(tableWidth(cur) * PX_MM);
    const full = A4_MM[cur.orient === 'l' ? 'l' : 'p'];
    const max = cur.twocol ? Math.floor((full - TWO_GAP_MM) / 2) : full;
    $('cfFit').textContent = `таблиця ${mm} мм із ${max} мм` + (mm > max ? ' — не вміститься' : ' ✓');
    $('cfFit').classList.toggle('bad', mm > max);
}
function renderFont() {
    const f = cur.font || {};
    $('cfFont').value = f.family || '';
    $('cfSize').innerHTML = [9, 10, 11, 12, 13, 14, 16, 18].map((n) =>
        `<option value="${n}"${n === (+f.size || 12) ? ' selected' : ''}>${n}</option>`).join('');
    $('cfBold').classList.toggle('on', !!f.bold);
    $('cfItalic').classList.toggle('on', !!f.italic);
    $('cfOrient').value = cur.orient === 'l' ? 'l' : 'p';
    document.querySelectorAll('#cfTwo .seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x.dataset.c === (cur.twocol ? '1' : '0')));
    $('cfTitle').value = cur.title || '';
    renderTokens();
    document.querySelectorAll('#cfNum .seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x.dataset.n === (cur.rownum === 'group' ? 'group' : (cur.rownum ? '1' : '0'))));
    document.querySelectorAll('#cfShort .seg-btn').forEach((x) =>
        x.classList.toggle('is-active', x.dataset.s === (cur.short ? '1' : '0')));
    renderFit();
}
const setFont = (k, v) => { cur.font = Object.assign({}, cur.font || {}, { [k]: v }); renderFont(); changed(); };
$('cfFont').addEventListener('change', () => setFont('family', $('cfFont').value));
$('cfSize').addEventListener('change', () => setFont('size', +$('cfSize').value));
$('cfBold').addEventListener('click', () => setFont('bold', !(cur.font || {}).bold));
$('cfItalic').addEventListener('click', () => setFont('italic', !(cur.font || {}).italic));
$('cfTitle').addEventListener('input', () => { cur.title = $('cfTitle').value; save(); update(cur); });
$('cfTokens').addEventListener('click', (e) => {
    const b = e.target.closest('[data-t]');
    if (!b) return;
    const inp = $('cfTitle');
    const tok = `{${b.dataset.t}}`;
    const at = inp.selectionStart != null ? inp.selectionStart : inp.value.length;
    const endAt = inp.selectionEnd != null ? inp.selectionEnd : at;
    inp.value = inp.value.slice(0, at) + tok + inp.value.slice(endAt);
    inp.focus();
    inp.setSelectionRange(at + tok.length, at + tok.length);
    cur.title = inp.value;
    save();
    update(cur);
});
$('cfNum').addEventListener('click', (e) => {
    const x = e.target.closest('[data-n]');
    if (!x) return;
    cur.rownum = x.dataset.n === 'group' ? 'group' : x.dataset.n === '1';
    renderFont();
    changed();
});
$('cfShort').addEventListener('click', (e) => {
    const x = e.target.closest('[data-s]');
    if (!x) return;
    cur.short = x.dataset.s === '1';
    renderFont();
    changed();
});
$('cfOrient').addEventListener('change', () => { cur.orient = $('cfOrient').value; renderFit(); save(); });
$('cfTwo').addEventListener('click', (e) => {
    const b = e.target.closest('[data-c]');
    if (!b) return;
    cur.twocol = b.dataset.c === '1';
    renderFont(); renderFit(); save();
});

/* тягнемо межу в заголовку — ширина зберігається в списку */
$('clLists').addEventListener('mousedown', (e) => {
    const rz = e.target.closest('.cl-rz');
    if (!rz) return;
    e.preventDefault(); e.stopPropagation();
    const L = listById(rz.closest('.cl-panel').dataset.id);
    const th = rz.closest('th'), table = th.closest('table');
    const k = th.dataset.k;
    const col = table.querySelector(`col[data-k="${CSS.escape(k)}"]`);
    const x0 = e.clientX, w0 = colW(L, k);
    rz.classList.add('on');
    const move = (ev) => {
        const w = Math.max(40, Math.round(w0 + ev.clientX - x0));
        L.widths = Object.assign({}, L.widths || {}, { [k]: w });
        col.style.width = w + 'px';
        table.style.width = tableWidth(L) + 'px';
        if (cur === L && cfgOpen) renderFit();
    };
    const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        rz.classList.remove('on');
        save();
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
});

/* ─── друк: попередній перегляд аркушів A4 — спільний модуль herd_print.js ─── */
function printList(L) {
    window.herdPrint.open({
        state: L,                                  // orient / twocol живуть у списку
        twocolToggle: true,
        content: () => {
            const D = nextDay(L);
            const blocks = blocksOf(L, D);
            // пояснення стрілки: якщо кількість уже є в заголовку — лише назва
            const custom = (L.title || '').trim();
            const legend = blocks.slice(1).filter((b) => b.rows.length).map((b) =>
                `→ ${escapeHtml(b.name)}${custom ? '' : ' · ' + b.rows.length}`).join('; ');
            return { title: nameOf(L), sub: titleOf(L, blocks, D, true), legend,
                body: listHtml(L, blocks, D, true) };
        },
        onChange: () => {
            save();
            if (cur === L && cfgOpen) { renderFont(); renderFit(); }
        },
    });
}

/* дні формування списку: жодного не обрано — щодня */
function renderDays() {
    const on = new Set(cur.days || []);
    $('cfDays').innerHTML = WD.map((w, i) =>
        `<button type="button" class="seg-btn${on.has(i + 1) ? ' is-active' : ''}" data-d="${i + 1}">${w}</button>`).join('');
    $('cfDaysNote').textContent = on.size ? '' : 'щодня';
}
$('cfDays').addEventListener('click', (e) => {
    const b = e.target.closest('[data-d]');
    if (!b) return;
    const d = +b.dataset.d;
    const on = new Set(cur.days || []);
    if (on.has(d)) on.delete(d); else on.add(d);
    cur.days = [...on].sort();
    renderDays();
    changed();
});
$('cfName').addEventListener('input', () => { cur.name = $('cfName').value.trim(); save(); update(cur); });
$('cfEvent').addEventListener('change', () => {
    cur.event = $('cfEvent').value;
    $('cfName').placeholder = nameOf(Object.assign({}, cur, { name: '' }));
    changed();
});
$('cfColors').addEventListener('click', (e) => {
    const b = e.target.closest('[data-c]');
    if (!b) return;
    cur.color = b.dataset.c;
    renderCfg();
    changed();
});
$('cfDel').addEventListener('click', async () => {
    if (!cur || !(await confirmAction(`Видалити список «${nameOf(cur)}»?`, { ok: 'Видалити' }))) return;
    LISTS = LISTS.filter((L) => L !== cur);
    cur = null; cfgOpen = false;
    save();
    renderAll();
});
$('clNew').addEventListener('click', () => {
    const used = new Set(LISTS.map((L) => L.color));
    const L = {
        id: 'l' + Date.now().toString(36), name: '', event: '',
        color: COLORS.find((c) => !used.has(c)) || COLORS[0] || '#5b7083',
        filters: [], days: [],
        cols: ['name', 'group'], sorts: [{ key: 'tag', dir: 'asc' }], groups: [], v: 3,
    };
    LISTS.push(L);
    cur = L; cfgOpen = true;
    closed.delete(L.id); saveClosed();
    if (view === 'gantt') { view = 'list'; lsSet(LS_VIEW, view); }
    save();
    renderAll();
    panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'center' });
    $('cfName').focus();
});

FLT = herdFilters({
    listEl: $('cfFilters'),
    addBtn: $('cfAddFilter'),
    params: () => PARAMS,
    choices: () => CHOICES,
    animals: () => ANIMALS,
    filters: () => { cur.filters = cur.filters || []; return cur.filters; },
    onChange: () => {
        $('cfName').placeholder = nameOf(Object.assign({}, cur, { name: '' }));
        changed();
    },
});

herdColPicker({
    button: $('clCols'),
    params: () => PARAMS,
    hide: ['tag'],
    selected: () => (cur && cur.cols) || [],
    onToggle: async (k, on) => {
        if (!cur) return;
        cur.cols = cur.cols || [];
        if (on) { if (!cur.cols.includes(k)) cur.cols.push(k); } else { cur.cols = cur.cols.filter((x) => x !== k); dropRefs(cur); }
        renderDisplay();
        renderFit();
        await changed();
    },
});

$('clView').addEventListener('click', (e) => {
    const b = e.target.closest('.seg-btn');
    if (!b) return;
    view = b.dataset.v;
    lsSet(LS_VIEW, view);
    renderAll();
});

$('clLists').addEventListener('click', (e) => {
    const panel = e.target.closest('.cl-panel');
    const L = panel && listById(panel.dataset.id);
    if (!L) return;
    if (e.target.closest('.cl-gear')) {
        if (cur === L && cfgOpen) {
            cfgOpen = false;
            $('clHold').appendChild($('clCfg'));
        } else {
            cur = L; cfgOpen = true;
            closed.delete(L.id); saveClosed();
            panel.querySelector('.cl-slot').appendChild($('clCfg'));
            renderCfg();
        }
        LISTS.forEach(update);
        return;
    }
    if (e.target.closest('.cl-print')) { printList(L); return; }
    if (e.target.closest('.cl-go, .cl-cfg, .cl-grip, .cl-rz')) return;
    if (e.target.closest('.cl-head')) {
        if (closed.has(L.id)) closed.delete(L.id); else closed.add(L.id);
        saveClosed();
        update(L);
        return;
    }
    const day = e.target.closest('.cl-day');
    if (day && !day.classList.contains('off')) { selDay[L.id] = selDay[L.id] === day.dataset.d ? '' : day.dataset.d; update(L); return; }
    if (e.target.closest('.cl-dayx')) { selDay[L.id] = ''; update(L); }
});

/* ─────────── порядок: перетягування за ⠿ ─────────── */
let dragId = null;
$('clLists').addEventListener('dragstart', (e) => {
    const grip = e.target.closest && e.target.closest('.cl-grip');
    if (!grip) return;
    const panel = grip.closest('.cl-panel');
    dragId = panel.dataset.id;
    panel.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', dragId); e.dataTransfer.setDragImage(panel, 20, 16); } catch (_) { /* ignore */ }
});
$('clLists').addEventListener('dragover', (e) => {
    if (!dragId) return;
    const over = e.target.closest('.cl-panel');
    const src = $('clLists').querySelector('.cl-panel.dragging');
    if (!over || !src || over === src) { e.preventDefault(); return; }
    e.preventDefault();
    const r = over.getBoundingClientRect();
    const after = e.clientY > r.top + r.height / 2;
    over.parentNode.insertBefore(src, after ? over.nextSibling : over);
});
$('clLists').addEventListener('drop', (e) => { if (dragId) e.preventDefault(); });
$('clLists').addEventListener('dragend', () => {
    if (!dragId) return;
    dragId = null;
    const order = [...$('clLists').querySelectorAll('.cl-panel')].map((p) => p.dataset.id);
    $('clLists').querySelectorAll('.cl-panel.dragging').forEach((p) => p.classList.remove('dragging'));
    const next = order.map(listById).filter(Boolean);
    if (next.map((L) => L.id).join() === LISTS.map((L) => L.id).join()) return;
    LISTS = next;
    save();
    LISTS.forEach((L) => { const p = panelOf(L); if (p) p.querySelector('.cl-no').textContent = LISTS.indexOf(L) + 1; });
});

/* ─────────── один список ─────────── */
const dayWord = (D) => (D === TODAY ? 'сьогодні' : `${WD_LONG[wdOf(D) - 1]} ${dmy(D).slice(0, 5)}`);

function update(L) {
    const panel = panelOf(L);
    if (!panel) return;
    const isClosed = closed.has(L.id);
    panel.style.setProperty('--c', L.color);
    panel.classList.toggle('closed', isClosed);
    panel.querySelector('.cl-chev').textContent = isClosed ? '▸' : '▾';
    panel.querySelector('h2').textContent = nameOf(L);
    panel.querySelector('.cl-no').textContent = LISTS.indexOf(L) + 1;
    panel.querySelector('.cl-gear').classList.toggle('on', cur === L && cfgOpen);
    const D = nextDay(L);
    const blocks = blocksOf(L, D);
    const extra = blocks.slice(1).map((b) => b.rows.length);
    panel.querySelector('.cl-cnt').innerHTML = `<b>${blocks[0].rows.length}</b>`
        + extra.map((n) => ` + <b>${n}</b>`).join('') + ` · ${dayWord(D)}`
        + ((L.days || []).length ? ` · ${L.days.map((d) => WD[d - 1]).join(', ')}` : '');
    // внести подію можна лише в день формування — сьогодні; одна кнопка на всі блоки
    const all = blocks.flatMap((b) => b.rows);
    const ev = evByKey(L.event), go = panel.querySelector('.cl-go');
    const can = ev && all.length && D === TODAY;
    go.hidden = !can;
    if (can) {
        go.textContent = `Внести «${ev.name}» · ${all.length}`;
        go.href = `/herd/group?event=${encodeURIComponent(ev.key)}&ids=${all.map((a) => a.id).join(',')}`;
    }
    // заголовок таблиці — одразу під назвою списку
    const tt = panel.querySelector(':scope > .cl-title');
    const showT = !isClosed && view !== 'cal' && (L.title || '').trim() && blocksCount(blocks);
    tt.hidden = !showT;
    // назва вже стоїть рядком вище — тут її не повторюємо (у друці лишається)
    tt.textContent = showT ? titleOf(L, blocks, D, true) : '';
    tt.hidden = !tt.textContent;
    if (isClosed) return;
    const body = panel.querySelector('.cl-body');
    body.innerHTML = view === 'cal' ? monthHtml(L) : listHtml(L, blocks, D, false, true);
}

/* значення колонки */
function cell(a, k) {
    const raw = (a.p || {})[k];
    if (raw === null || raw === undefined || raw === '') return '';
    // репродуктивний код — цілим числом; назву показує «Репродуктивний статус»
    const lbl = k === 'repro_code' ? '' : (a.pl || {})[k];
    if (lbl) return lbl;
    const num = numText(raw, (paramOf(k) || {}).dtype);
    if (num !== null) return num;
    if (/^\d{4}-\d{2}-\d{2}/.test(String(raw))) return dmy(String(raw).slice(0, 10));
    return String(raw);
}

/* видимі колонки таблиці: без схованих (ними лише сортують і групують) */
const shownCols = (L) => (L.cols || []).filter((k) => colOk(k) && !(L.hide || []).includes(k));

/* marks: id тварини → назва додаткового списку; такі рядки мають позначку зліва від номера */
function tableHtml(L, rows, D, forPrint, marks) {
    const cols = shownCols(L);
    const mk = hasMarks(L);
    const all = [...(L.rownum ? ['__no'] : []), ...(mk ? ['__mark'] : []), 'tag', ...cols];
    const th = (k, label) => `<th data-k="${escapeHtml(k)}">${escapeHtml(label)}${forPrint || k === '__mark' ? '' : '<span class="cl-rz"></span>'}</th>`;
    let no = 0;                                        // порядковий номер рядка
    // коротка назва — з конструктора («Скорочення»); немає — повна
    const hl = (k, full) => (L.short && (paramOf(k) || {}).short) || full;
    const head = `<tr>${L.rownum ? th('__no', '№') : ''}${mk ? th('__mark', '') : ''}${th('tag', hl('tag', herdLabel('tag', 'Номер тварини')))}${cols.map((k) => th(k, hl(k, colLabel(k)))).join('')}</tr>`;
    const colgroup = `<colgroup>${all.map((k) => `<col data-k="${escapeHtml(k)}" style="width:${colW(L, k)}px">`).join('')}</colgroup>`;
    const span = all.length;
    const list = sortRows(L, rows.map((a) => withDay(a, D || TODAY)));
    const markTd = (a) => {
        if (!mk) return '';
        const nm = marks && marks.get(a.id);
        return nm ? `<td class="cl-mk"><span title="${escapeHtml(nm)}">→</span></td>` : '<td class="cl-mk"></td>';
    };
    const row = (a) => `<tr${marks && marks.has(a.id) ? ' class="is-extra"' : ''}>${L.rownum ? `<td class="cl-rn">${++no}</td>` : ''}${markTd(a)}<td><a class="tag" href="/herd/animals/${a.id}">${escapeHtml(a.tag)}</a></td>`
        + cols.map((k) => `<td${k === 'name' ? ' class="nm"' : ''}>${escapeHtml(cell(a, k))}</td>`).join('') + '</tr>';
    let body;
    const gs = (L.groups || []).filter((k) => (L.cols || []).includes(k));
    // вкладене групування: група → підгрупа → …; рядки всередині — за сортуванням
    const nest = (arr, lvl) => {
        if (lvl >= gs.length) {
            if (L.rownum === 'group') no = 0;              // «у кожній групі» — знову з 1
            return arr.map(row).join('');
        }
        const g = gs[lvl];
        const by = new Map();
        arr.forEach((a) => {
            const t = cell(a, g) || '— не вказано';
            if (!by.has(t)) by.set(t, []);
            by.get(t).push(a);
        });
        // порядок груп — як у конструкторі (секції, варіанти списку); решта — як ідуть за сортуванням
        const order = new Map();
        (CHOICES[g] || []).forEach((c, i) => { order.set(String(c.label), i); order.set(String(c.value), i); });
        const pos = (t) => (t === '— не вказано' ? 1e9 : (order.has(t) ? order.get(t) : 1e8));
        const lbl = gs.length > 1 ? `${escapeHtml(pLabel(g))}: ` : '';
        return [...by.entries()].sort((x, y) => pos(x[0]) - pos(y[0])).map(([t, part]) =>
            `<tr class="sec l${Math.min(lvl, 2)}"><td colspan="${span}">${lbl}${escapeHtml(t)} · ${part.length}</td></tr>`
            + nest(part, lvl + 1)).join('');
    };
    body = nest(list, 0);
    const table = `<table class="cl-tbl fixed" style="${tableStyle(L, all)}">${colgroup}<thead>${head}</thead><tbody>${body}</tbody></table>`;
    return forPrint ? table : `<div class="cl-scroll">${table}</div>`;
}

/* основний і додаткові — ОДНА таблиця (Роман: «злити в один список, щоб бачити по групах»);
   рядки додаткових позначені зліва від номера */
function mergeBlocks(blocks) {
    const marks = new Map();
    const rows = [];
    blocks.forEach((b, i) => b.rows.forEach((a) => { rows.push(a); if (i) marks.set(a.id, b.name); }));
    return { rows, marks };
}
// кнопки змінних заголовка — оновлюються й тоді, коли додали / перейменували додатковий список
function renderTokens() {
    if (!cur) return;
    $('cfTokens').innerHTML = titleTokens(cur).map((t) => `<button type="button" data-t="${escapeHtml(t)}" title="Вставити в заголовок">{${escapeHtml(t)}}</button>`).join('');
}

/* заголовок таблиці — з налаштувань, зі змінними: {Назва} {Дата} {Усього} {За планом} {<додатковий>} */
function titleTokens(L) {
    return ['Назва', 'Дата', 'Усього', 'За планом', ...(L.subs || []).map((sb) => sb.name || 'Додатковий')];
}
function titleOf(L, blocks, D, noName) {
    let tpl = (L.title || '').trim() || '{Назва} · {Дата}';
    if (noName) tpl = tpl.replace(/\{Назва\}\s*[·:—-]?\s*/g, '').trim();
    const vals = {
        'Назва': nameOf(L), 'Дата': dmy(D), 'Усього': String(blocksCount(blocks)),
        'За планом': String(blocks[0].rows.length),
    };
    blocks.slice(1).forEach((b) => { vals[b.name] = String(b.rows.length); });
    (L.subs || []).forEach((sb) => { const k = sb.name || 'Додатковий'; if (!(k in vals)) vals[k] = '0'; });
    return tpl.replace(/\{([^}]+)\}/g, (m, k) => (k in vals ? vals[k] : m));
}

function listHtml(L, blocks, D, forPrint, noTitle) {
    const { rows, marks } = mergeBlocks(blocks);
    if (!rows.length) {
        return `<div class="cl-empty">${(L.filters || []).length ? `На ${dayWord(D)} нікого` : 'Задайте фільтри — ⚙'}</div>`;
    }
    const legend = blocks.slice(1).filter((b) => b.rows.length).map((b) =>
        `<span class="cl-mk"><span>→</span></span> ${escapeHtml(b.name)} · ${b.rows.length}`).join(' &nbsp; ');
    const title = (L.title || '').trim() && !forPrint && !noTitle ? `<div class="cl-title">${escapeHtml(titleOf(L, blocks, D))}</div>` : '';
    return title + (legend && !forPrint && !(L.title || '').trim() ? `<div class="cl-legend">${legend}</div>` : '') + tableHtml(L, rows, D, forPrint, marks);
}

/* ─────────── календар місяця: список на кожен день формування ─────────── */
function monthHtml(L) {
    const [y, mo] = month.split('-').map(Number);
    const first = new Date(y, mo - 1, 1);
    const start = new Date(first);
    start.setDate(1 - ((first.getDay() + 6) % 7));           // понеділок
    const sd = selDay[L.id] || '';
    let cells = '';
    for (let i = 0; i < 42; i++) {
        const d = new Date(start); d.setDate(start.getDate() + i);
        if (i >= 35 && d.getMonth() !== mo - 1) break;
        const s = iso(d);
        const form = isFormDay(L, s) && s >= TODAY;
        const bl = form ? blocksOf(L, s) : [{ rows: [] }];
        const list = bl.flatMap((b) => b.rows);
        const extraIds = new Set(bl.slice(1).flatMap((b) => b.rows.map((a) => a.id)));
        const extraN = bl.slice(1).reduce((t, b) => t + b.rows.length, 0);
        // пропущені — червоною стрілкою, як у таблиці
        const nTxt = `${bl[0].rows.length}`;
        const cls = ['cl-day', d.getMonth() !== mo - 1 ? 'out' : '', s === TODAY ? 'today' : '',
            s === sd ? 'sel' : '', form ? '' : 'off'].filter(Boolean).join(' ');
        cells += `<div class="${cls}" data-d="${s}"><span class="dt"><span class="dn">${d.getDate()}</span>
            ${list.length ? `<span class="n">${nTxt}</span>` : ''}${extraN ? `<span class="cl-ex"><i class="cl-arr">→</i>${extraN}</span>` : ''}</span>
            ${list.slice(0, 2).map((a) => `<span class="tg">${extraIds.has(a.id) ? '<i class="cl-arr">→</i> ' : ''}${escapeHtml(a.tag)}${a.name ? ' ' + escapeHtml(a.name) : ''}</span>`).join('')}
            ${list.length > 2 ? `<span class="tg">ще ${list.length - 2}</span>` : ''}</div>`;
    }
    const dayBl = sd ? blocksOf(L, sd) : [];
    return `<div class="cl-month">${WD.map((w) => `<div class="cl-wd">${w}</div>`).join('')}${cells}</div>
        ${sd ? `<div class="cl-dayhead">${dayWord(sd)} ${dmy(sd).slice(6)} · ${blocksCount(dayBl)}
            <button type="button" class="cl-dayx">закрити</button></div>
            ${blocksCount(dayBl) ? listHtml(L, dayBl, sd) : '<div class="cl-empty">Цього дня нікого</div>'}` : ''}`;
}

/* ─────────── Гант: рядок = список ─────────── */
function renderGantt() {
    const span = +(lsGet(LS_RANGE) || 60);
    const from = TODAY;
    const days = [];
    for (let i = 0; i < span; i++) days.push(addDays(from, i));
    const cols = `grid-template-columns:repeat(${span}, minmax(0,1fr))`;
    // шкала: місяці
    let marks = '', prevM = '';
    days.forEach((d, i) => {
        const m = d.slice(0, 7);
        if (m !== prevM) {
            prevM = m;
            let len = 0;
            while (i + len < span && days[i + len].slice(0, 7) === m) len++;
            marks += `<span class="cl-gm" style="grid-column:${i + 1} / span ${len}">${MON_SHORT[+m.slice(5) - 1]} ${m.slice(0, 4)}</span>`;
        }
    });
    const rowsHtml = LISTS.map((L) => {
        const cnt = new Map();
        const parts = new Map(), mainN = new Map(), extraN = new Map();
        days.forEach((d) => {
            if (!isFormDay(L, d)) return;
            const bl = blocksOf(L, d);
            cnt.set(d, blocksCount(bl));
            parts.set(d, bl.map((b) => b.rows.length).join(' + '));
            mainN.set(d, bl[0].rows.length);
            extraN.set(d, blocksCount(bl) - bl[0].rows.length);
        });
        const max = Math.max(1, ...cnt.values());
        const cells = days.map((d) => {
            const form = cnt.has(d);
            const n = cnt.get(d) || 0;
            const wk = wdOf(d) === 1;
            const alpha = n ? (0.25 + 0.75 * n / max) : 0;
            // на блідій клітинці біле число не читається — темне
            const bg = n ? `background:color-mix(in srgb, ${L.color} ${Math.round(alpha * 100)}%, transparent)`
                + (alpha < 0.55 ? ';color:var(--text)' : '') : '';
            return `<span class="cl-gc${wk ? ' wk' : ''}${d === TODAY ? ' today' : ''}${form ? '' : ' off'}" data-l="${escapeHtml(L.id)}" data-d="${d}"
                style="${bg}" title="${escapeHtml(nameOf(L))} · ${WD[wdOf(d) - 1]} ${dmy(d)}${form ? ' · ' + parts.get(d) : ' · не формується'}">${n && span <= 60 ? (mainN.get(d) || '') : ''}${extraN.get(d) ? '<i class="cl-arr cl-garr">→</i>' : ''}</span>`;
        }).join('');
        return `<div class="cl-grow">
            <div class="cl-gname" data-l="${escapeHtml(L.id)}" style="--c:${L.color}"><i></i><span>${LISTS.indexOf(L) + 1}. ${escapeHtml(nameOf(L))}</span></div>
            <div class="cl-gcells" style="${cols}">${cells}</div></div>`;
    }).join('');
    const box = $('clGantt');
    if (!box) return;
    box.innerHTML = `
            <div class="cl-grow hdr"><div></div>
                <div class="cl-gcells" style="${cols}">${marks}</div></div>
            ${rowsHtml}
`;
    // клік по назві — до цього списку; по дню — календар із цим днем
    box.querySelectorAll('.cl-gname').forEach((n) => n.addEventListener('click', () => {
        closed.delete(n.dataset.l); saveClosed();
        view = 'list'; lsSet(LS_VIEW, view);
        renderAll();
        const L = listById(n.dataset.l);
        if (L) panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
    box.querySelectorAll('.cl-gc:not(.off)').forEach((c) => c.addEventListener('click', () => {
        closed.delete(c.dataset.l); saveClosed();
        view = 'cal'; lsSet(LS_VIEW, view);
        selDay[c.dataset.l] = c.dataset.d; month = c.dataset.d.slice(0, 7);
        renderAll();
        const L = listById(c.dataset.l);
        if (L) panelOf(L).scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
}

boot();
/* Визначення списку — кольоровим рядком формули, як у «Роботі зі стадом»
   (Роман 2026-09-19: «підсвітку кольорами в Календар»). Наведіть мишу на
   назву списку — видно, кого він бере й як показує. */
function calFilterQ(f) {
    const op = f.op || (f.vals ? 'eq' : ((f.from || f.to) ? 'between' : (f.text ? 'has' : 'eq')));
    const o = { key: f.key, op };
    if (op === 'between') {
        o.v = f.v !== undefined ? f.v : f.from;
        o.v2 = f.v2 !== undefined ? f.v2 : f.to;
        if (!o.v2) o.op = 'ge';
        else if (!o.v) { o.op = 'le'; o.v = o.v2; }
    } else if (op === 'has') o.v = f.v !== undefined ? f.v : f.text;
    else if (f.vals && f.vals.length > 1) o.vals = f.vals;
    else if (f.vals && f.vals.length) o.v = f.vals[0];
    else o.v = f.v;
    return o;
}
function calFormula(L) {
    if (!window.herdQuery) return '';
    const q = { cols: ['tag', ...(L.cols || []).filter((k) => k !== 'tag')],
        filters: (L.filters || []).map(calFilterQ), sorts: L.sorts || [],
        groups: L.groups || [], rownum: !!L.rownum, aggs: [] };
    return window.herdQuery.format(q, PARAMS);
}
let calTipT = null;
function calTipHide() { clearTimeout(calTipT); const t = $('calFxTip'); if (t) t.hidden = true; }
document.addEventListener('mouseover', (e) => {
    const h = e.target.closest('.cl-head h2');
    if (!h || h.contains(e.relatedTarget)) return;
    const panel = h.closest('.cl-panel');
    const L = LISTS.find((x) => x.id === (panel && panel.dataset.id));
    if (!L) return;
    clearTimeout(calTipT);
    calTipT = setTimeout(() => {
        let tip = $('calFxTip');
        if (!tip) {
            tip = document.createElement('div');
            tip.id = 'calFxTip';
            tip.className = 'fx-tip';
            document.body.appendChild(tip);
        }
        const hl = (t) => `<code class="qfc">${window.herdQuery.highlight(t, PARAMS)}</code>`;
        const subs = (L.subs || []).filter((sb) => (sb.filters || []).length).map((sb) =>
            `<div class="fx-tip-h">${escapeHtml(sb.name || 'Додатковий')} — замість тих самих умов</div>`
            + hl(window.herdQuery.format({ cols: [], filters: sb.filters.map(calFilterQ),
                sorts: [], groups: [], aggs: [] }, PARAMS))).join('');
        tip.innerHTML = `<div class="fx-tip-h">Список «${escapeHtml(L.name)}» як формула</div>`
            + hl(calFormula(L)) + subs;
        tip.hidden = false;
        const r = h.getBoundingClientRect();
        const w = tip.offsetWidth, ht = tip.offsetHeight;
        tip.style.left = `${Math.round(Math.max(8, Math.min(r.left, window.innerWidth - w - 8)))}px`;
        tip.style.top = `${Math.round(r.bottom + 6 + ht > window.innerHeight ? r.top - ht - 6 : r.bottom + 6)}px`;
    }, 350);
});
document.addEventListener('mouseout', (e) => {
    const h = e.target.closest('.cl-head h2');
    if (h && !h.contains(e.relatedTarget)) calTipHide();
});
window.addEventListener('scroll', calTipHide, true);

})();
