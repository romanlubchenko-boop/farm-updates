'use strict';
/* Секції стада (вкладка «Налаштування» модуля Управління стада).
   Секція: назва + секція роздачі Profeed (блок). Періоди: дата з-по, статус
   (Корови/Молодняк), підгрупа (Дійні/Сухостій/Телята…), поголів'я. Статус і
   підгрупа задаються на кожен період — секція може змінюватись у часі. */
(function () {
    const wrap = document.getElementById('sectionsWrap');
    if (!wrap) return;

    let sections = [];
    let deleted = [];
    let profeedGroups = [];   // роздачі зі звітів Profeed: «Група-1», «Група-2»…
    let subByKind = { cow: [], young: [], all: [] };   // підкатегорії з довідника Годівлі

    // Секція роздачі Profeed = роздача зі звітів (Група-N), не блок довідника
    function profeedOptions(cur) {
        const c = (cur == null ? '' : String(cur));
        // якщо збережена мітка ще не у списку сканованих — все одно показуємо
        const all = profeedGroups.includes(c) || !c ? profeedGroups : [c, ...profeedGroups];
        return ['<option value="">— секція роздачі Profeed —</option>'].concat(
            all.map((g) => `<option value="${escapeHtml(g)}" ${g === c ? 'selected' : ''}>${escapeHtml(g)}</option>`)
        ).join('');
    }

    const KINDS = [['', '—'], ['cow', 'Корови'], ['young', 'Молодняк']];
    function kindSelect(cur) {
        const c = cur || '';
        return `<select class="pd-kind">${KINDS.map(([v, l]) =>
            `<option value="${v}" ${v === c ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    }
    // Підкатегорія (Дійні/Сухостій/Телята…) — зі списку блоків обраної
    // Категорії в Довіднику: обрав «Корови» → підкатегорії з блоків Корів.
    function subOptions(kind, cur) {
        const c = (cur || '').trim();
        let list = kind ? (subByKind[kind] || []).slice() : [];
        if (c && !list.includes(c)) list.unshift(c);   // збережене значення завжди у списку
        return ['<option value="">— підкатегорія —</option>'].concat(
            list.map((s) => `<option value="${escapeHtml(s)}" ${s === c ? 'selected' : ''}>${escapeHtml(s)}</option>`)
        ).join('');
    }
    function subSelect(kind, cur) {
        return `<select class="pd-sub" title="Підкатегорія з блоків обраної категорії (Довідник). Впливає на «Рух кормів → По категоріях».">${subOptions(kind, cur)}</select>`;
    }

    function periodRow(p) {
        p = p || {};
        return `<div class="prow">
            <input type="date" class="pd-from" value="${p.date_from || ''}" title="Дата з">
            <input type="date" class="pd-to" value="${p.date_to || ''}" title="Дата по">
            <select class="pd-pf" title="Секція роздачі Profeed">${profeedOptions(p.profeed_group)}</select>
            ${kindSelect(p.herd_kind)}
            ${subSelect(p.herd_kind, p.subgroup)}
            <input type="number" class="pd-share" min="0" step="1"
                   value="${p.eat_coef != null && p.eat_coef !== '' && p.eat_coef !== 1 ? p.eat_coef : ''}"
                   placeholder="частка %" title="Частка цієї підкатегорії у групі, % (для поділу однієї Profeed-групи). Лишіть порожнім, якщо поділу немає.">
            <button type="button" class="btn btn-icon btn-icon-danger pd-del" title="Прибрати період">✕</button>
        </div>`;
    }

    // Секція «активна», якщо має період, що покриває сьогодні (або відкритий/
    // без дат — чернетка). Інакше — неактивна (можна сховати перемикачем).
    function isSectionActive(s) {
        const periods = (s && s.periods) || [];
        if (!periods.length) return true;                 // чернетка — не ховаємо
        const t = new Date().toISOString().slice(0, 10);
        return periods.some((p) => {
            const f = (p.date_from || '').slice(0, 10);
            const to = (p.date_to || '').slice(0, 10);
            return (!f || f <= t) && (!to || to >= t);
        });
    }

    // Секція — в один рядок: Назва + період(и) інлайн (кожен зі своєю роздачею
    // Profeed з дати по дату).
    function card(s, no) {
        s = s || {};
        const periods = (s.periods && s.periods.length) ? s.periods : [{}];
        const inactive = isSectionActive(s) ? '' : ' sec-inactive';
        return `<div class="sec-card${inactive}" data-id="${s.id || ''}">
            <div class="sec-main">
                <span class="sec-grip" draggable="true" title="Перетягніть, щоб змінити порядок">⠿</span>
                <span class="sec-no" title="Порядковий номер секції. Це те саме число, що «№ секції» в картці тварини — воно рахується як позиція секції в цьому списку. Змінюється перетягуванням ⠿.">${no || ''}</span>
                <input type="text" class="sec-code" value="${escapeHtml(s.code || '')}"
                       placeholder="№" title="Номер секції — короткий запис; назва поруч це опис">
                <input type="text" class="sec-name" value="${escapeHtml(s.name || '')}" placeholder="опис секції">
                <label class="sec-milk" title="Дійна секція: у формулах MILKING() дає 1, інакше 0">
                    <input type="checkbox" class="sec-milk-cb" ${s.milking ? 'checked' : ''}> дійна</label>
                <div class="sec-periods">${periods.map(periodRow).join('')}</div>
                <button type="button" class="btn btn-ghost btn-sm sec-add-period" title="Додати період">+ період</button>
                <button type="button" class="btn btn-icon btn-icon-danger sec-del" title="Прибрати секцію">🗑</button>
            </div>
        </div>`;
    }

    function render() {
        wrap.innerHTML = sections.length
            ? sections.map((s, i) => card(s, i + 1)).join('')
            : '<p class="text-mute form-hint">Секцій ще немає — «↻ Створити з Profeed» або «+ Секція».</p>';
        applyInactiveFilter();
        renderUnassigned();
    }

    /* ПОРЯДКОВИЙ НОМЕР секції = її позиція в цьому списку. Саме цим числом
       живе «№ секції» в картці тварини (формула POS за списком секцій), тож
       після перетягування перенумеровуємо ОДРАЗУ — інакше на екрані було б
       одне число, а в картці інше (Роман 2026-09-22).
       ⚠️ Рахуємо ВСІ картки, зокрема приховані перемикачем «Активні»: той
       перемикач лише ховає їх з очей, а в списку секцій вони лишаються. */
    function renumber() {
        wrap.querySelectorAll('.sec-card').forEach((c, i) => {
            const n = c.querySelector('.sec-no');
            if (n) n.textContent = String(i + 1);
        });
    }

    // Перемикач «Показати неактивні»: ховаємо неактивні картки візуально
    // (лишаються в DOM — щоб не губились при збереженні). Стан памʼятаємо.
    function applyInactiveFilter() {
        const seg = document.getElementById('secActiveToggle');
        const showAll = seg
            ? seg.querySelector('.seg-btn.is-active')?.dataset.inactive === '1'
            : false;
        wrap.classList.toggle('hide-inactive', !showAll);
        const n = wrap.querySelectorAll('.sec-card.sec-inactive').length;
        const cnt = document.getElementById('secInactiveCount');
        if (cnt) cnt.textContent = n ? `неактивних: ${n}` : '';
    }

    function gather() {
        const out = [];
        wrap.querySelectorAll('.sec-card').forEach((c) => {
            const name = (c.querySelector('.sec-name').value || '').trim();
            const code = (c.querySelector('.sec-code').value || '').trim();
            if (!name) return;
            const periods = [];
            c.querySelectorAll('.sec-periods .prow').forEach((tr) => {
                periods.push({
                    date_from: tr.querySelector('.pd-from').value || '',
                    date_to: tr.querySelector('.pd-to').value || '',
                    profeed_group: tr.querySelector('.pd-pf').value || '',
                    herd_kind: tr.querySelector('.pd-kind').value || '',
                    subgroup: (tr.querySelector('.pd-sub').value || '').trim(),
                    // частка підкатегорії у групі, % (для поділу однієї Profeed-групи);
                    // голови прикріпимо пізніше (управління стада)
                    headcount: 0,
                    eat_coef: parseFloat(tr.querySelector('.pd-share').value) || 0,
                });
            });
            out.push({
                id: c.dataset.id ? Number(c.dataset.id) : null, name, code,
                milking: !!(c.querySelector('.sec-milk-cb') || {}).checked,
                profeed_group: '',
                periods,
            });
        });
        return out;
    }

    // Нерозподілені: секції стада без роздачі Profeed і роздачі Profeed без секції
    function renderUnassigned() {
        const cur = gather();
        const pfOf = (s) => (s.periods || []).map((p) => (p.profeed_group || '').trim()).filter(Boolean);
        const usedPf = new Set(cur.flatMap(pfOf));
        const herdEl = document.getElementById('unHerd');
        const pfEl = document.getElementById('unProfeed');
        if (herdEl) {
            const noPf = cur.filter((s) => pfOf(s).length === 0);
            herdEl.innerHTML = noPf.length
                ? noPf.map((s) => `<li>${escapeHtml(s.name)}<span class="un-badge">без роздачі</span></li>`).join('')
                : '<li class="empty">усі привʼязані</li>';
        }
        if (pfEl) {
            const free = profeedGroups.filter((g) => !usedPf.has(g));
            pfEl.innerHTML = free.length
                ? free.map((g) => `<li>${escapeHtml(g)}<span class="un-badge">без секції</span></li>`).join('')
                : '<li class="empty">усі використані</li>';
        }
    }

    async function loadProfeedGroups() {
        try {
            const r = await apiGet('/api/herd/profeed-groups');
            profeedGroups = (r && r.groups) || [];
        } catch (e) { profeedGroups = []; }
    }

    async function loadSubgroups() {
        // Підкатегорії — з довідника Годівлі: назва блоку (2-й рівень),
        // згруповані за Категорією блоку (Корови/Молодняк).
        const cow = new Set(), young = new Set(), all = new Set();
        try {
            const r = await apiGet('/f/api/blocks');
            for (const b of (r && r.items || [])) {
                const s = (b.subgroup || b.name || '').trim();
                if (!s) continue;
                all.add(s);
                if (b.herd_kind === 'cow') cow.add(s);
                else if (b.herd_kind === 'young') young.add(s);
            }
        } catch (e) { /* ignore */ }
        const srt = (set) => [...set].sort((a, b) => a.localeCompare(b, 'uk'));
        subByKind = { cow: srt(cow), young: srt(young), all: srt(all) };
    }

    async function load() {
        const r = await apiGet('/api/herd/sections');
        sections = (r && r.sections) || [];
        render();
    }

    // Частки однієї Profeed-групи (поділ) мають давати рівно 100%.
    function validateShares() {
        const byLabel = {};
        wrap.querySelectorAll('.sec-periods .prow').forEach((tr) => {
            const label = (tr.querySelector('.pd-pf').value || '').trim();
            const inp = tr.querySelector('.pd-share');
            if (!label || !inp) return;
            const raw = (inp.value || '').trim();
            const val = raw === '' ? null : parseFloat(raw);
            (byLabel[label] = byLabel[label] || []).push({ val, inp });
        });
        wrap.querySelectorAll('.pd-share.is-error').forEach((i) => i.classList.remove('is-error'));
        for (const label in byLabel) {
            const arr = byLabel[label];
            const filled = arr.filter((x) => x.val != null && x.val > 0);
            if (arr.length < 2 || filled.length === 0) continue;   // поділу немає
            const sum = arr.reduce((s, x) => s + (x.val || 0), 0);
            if (Math.abs(sum - 100) > 0.5) {
                arr.forEach((x) => x.inp.classList.add('is-error'));
                return `Частки групи «${label}» мають давати 100% (зараз ${Math.round(sum * 10) / 10}%).`;
            }
        }
        return null;
    }

    async function save() {
        const verr = validateShares();
        if (verr) { toast(verr, 'error'); return; }
        const r = await apiSend('/api/herd/sections/save', 'POST', { sections: gather(), deleted });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        deleted = [];
        sections = r.sections || [];
        render();
        toast('Збережено', 'success');
    }

    document.getElementById('addSectionBtn').addEventListener('click', () => {
        sections = gather();
        sections.push({ id: null, name: '', profeed_block_id: null, periods: [{}] });
        render();
        const last = wrap.querySelector('.sec-card:last-child .sec-name');
        if (last) last.focus();
    });
    document.getElementById('saveSectionsBtn').addEventListener('click', save);

    const pfBtn = document.getElementById('secFromProfeedBtn');
    if (pfBtn) pfBtn.addEventListener('click', async () => {
        pfBtn.disabled = true;
        const r = await apiSend('/api/herd/sections/from-profeed', 'POST', {});
        pfBtn.disabled = false;
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        sections = r.sections || [];
        render();
        toast(r.created_count ? `Створено секцій: ${r.created_count}` : 'Нових секцій немає', 'success');
    });

    // зміна Категорії → оновити список Підкатегорії у цьому ж рядку;
    // зміна роздачі Profeed / назви секції → перерахувати нерозподілені
    wrap.addEventListener('change', (e) => {
        const k = e.target.closest('.pd-kind');
        if (k) {
            const sub = k.closest('.prow').querySelector('.pd-sub');
            if (sub) sub.innerHTML = subOptions(k.value, '');
            return;
        }
        if (e.target.closest('.pd-pf') || e.target.closest('.sec-name')) renderUnassigned();
    });

    // редагування частки — прибрати підсвітку помилки
    wrap.addEventListener('input', (e) => {
        const sh = e.target.closest('.pd-share');
        if (sh) wrap.querySelectorAll('.pd-share.is-error').forEach((i) => i.classList.remove('is-error'));
    });

    wrap.addEventListener('click', (e) => {
        const addP = e.target.closest('.sec-add-period');
        if (addP) {
            addP.closest('.sec-main').querySelector('.sec-periods')
                .insertAdjacentHTML('beforeend', periodRow({}));
            return;
        }
        const delP = e.target.closest('.pd-del');
        if (delP) {
            const wrapP = delP.closest('.sec-periods');
            delP.closest('.prow').remove();
            if (!wrapP.querySelector('.prow')) wrapP.insertAdjacentHTML('beforeend', periodRow({}));
            return;
        }
        const delS = e.target.closest('.sec-del');
        if (delS) {
            const c = delS.closest('.sec-card');
            if (c.dataset.id) deleted.push(Number(c.dataset.id));
            const keep = gather();
            const idx = [...wrap.querySelectorAll('.sec-card')].indexOf(c);
            keep.splice(idx, 1);
            sections = keep;
            render();
        }
    });

    // Перетягування секцій за ручкою ⠿ — змінює порядок; при «Зберегти»
    // порядок карток стає sort_order. Читаємо DOM-порядок у gather().
    let dragCard = null;
    wrap.addEventListener('dragstart', (e) => {
        const grip = e.target.closest('.sec-grip');
        if (!grip) { e.preventDefault(); return; }
        dragCard = grip.closest('.sec-card');
        dragCard.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', ''); } catch (err) { /* ignore */ }
    });
    wrap.addEventListener('dragend', () => {
        if (dragCard) dragCard.classList.remove('dragging');
        dragCard = null;
    });
    wrap.addEventListener('dragover', (e) => {
        if (!dragCard) return;
        e.preventDefault();
        const over = e.target.closest('.sec-card');
        if (!over || over === dragCard) return;
        const r = over.getBoundingClientRect();
        const after = e.clientY > r.top + r.height / 2;
        wrap.insertBefore(dragCard, after ? over.nextSibling : over);
        renumber();          // номер має йти за карткою, а не лишатись на місці
    });

    // Сегментований перемикач «Активні / Усі» — стан запамʼятовуємо.
    const actSeg = document.getElementById('secActiveToggle');
    if (actSeg) {
        const IKEY = 'farm:herd_show_inactive';
        const setActive = (showAll) => {
            actSeg.querySelectorAll('.seg-btn').forEach((b) =>
                b.classList.toggle('is-active', (b.dataset.inactive === '1') === showAll));
        };
        setActive(localStorage.getItem(IKEY) === '1');
        actSeg.addEventListener('click', (e) => {
            const btn = e.target.closest('.seg-btn');
            if (!btn) return;
            const showAll = btn.dataset.inactive === '1';
            setActive(showAll);
            try { localStorage.setItem(IKEY, showAll ? '1' : '0'); } catch (err) { /* ignore */ }
            applyInactiveFilter();
        });
    }

    // Згортання панелі «Секції стада» — ховає вміст, лишає шапку. Стан памʼятаємо.
    const tog = document.getElementById('secPanelToggle');
    const body = document.getElementById('secBody');
    if (tog && body) {
        const KEY = 'farm:herd_sections_collapsed';
        const apply = (on) => {
            body.hidden = on;
            tog.classList.toggle('is-collapsed', on);
            tog.title = on ? 'Розгорнути' : 'Згорнути';
        };
        apply(localStorage.getItem(KEY) === '1');
        tog.addEventListener('click', () => {
            const on = !body.hidden;
            apply(on);
            try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) { /* ignore */ }
        });
    }

    document.addEventListener('DOMContentLoaded', async () => {
        await Promise.all([loadProfeedGroups(), loadSubgroups()]);
        load();
    });
})();
