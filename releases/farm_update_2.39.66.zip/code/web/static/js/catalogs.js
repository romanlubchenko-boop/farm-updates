/* ============ Довідники: блоки / отримувачі / постачальники ============ */

const REFS = {
    blocks:     { api: '/api/blocks',     label: 'блок' },
    recipients: { api: '/api/recipients', label: 'отримувача' },
    suppliers:  { api: '/api/suppliers',  label: 'постачальника' },
};

async function loadRef(kind) {
    if (kind === 'blocks') { return loadBlocks(); }
    const cfg = REFS[kind];
    const list = document.querySelector(`.ref-list[data-list="${kind}"]`);
    const r = await apiGet(cfg.api);
    const items = (r && r.items) || [];
    if (items.length === 0) {
        list.innerHTML = '<li class="empty">Поки що порожньо</li>';
        return;
    }
    list.innerHTML = items.map((x) => `
        <li class="ref-item">
            <span class="ref-item-name">${escapeHtml(x.name)}</span>
            <button class="blk-del" data-del="${x.id}" title="Видалити">−</button>
        </li>
    `).join('');
}

/* ---- Блоки: ієрархія Корови / Молодняк, блоки в кожній групі ---- */
const BLOCK_KINDS = [
    { v: '',      label: '— перенести —' },
    { v: 'cow',   label: 'Корови' },
    { v: 'young', label: 'Молодняк' },
    { v: 'pig',   label: 'Свині' },
];

function blockKindSelect(id, cur) {
    const c = cur || '';
    const opts = BLOCK_KINDS.map((k) =>
        `<option value="${k.v}" ${k.v === c ? 'selected' : ''}>${k.label}</option>`).join('');
    return `<select class="ref-kind" data-kind-for="${id}">${opts}</select>`;
}

// Групи стада для привʼязки секцій (лише гілка Годівля). Заповнюється в loadBlocks.
let herdGroups = [];
const IS_FEED = (window.API_BASE || '') === '/f';

function herdGroupSelect(id, cur) {
    const c = cur == null ? '' : String(cur);
    const opts = ['<option value="">— група стада —</option>']
        .concat(herdGroups.map((g) =>
            `<option value="${g.id}" ${String(g.id) === c ? 'selected' : ''}>${escapeHtml(g.name)}</option>`));
    return `<select class="ref-herd" data-herd-for="${id}" title="Поголівʼя береться з цієї групи стада">${opts.join('')}</select>`;
}

function blockItemHtml(x, kind, withKind) {
    // Просто назва блоку. Підкатегорія (Дійні/Сухостій…) задається не тут,
    // а в «Управлінні стада» (секція → період → Підкатегорія).
    const nm = (x.name || '').trim();
    const nameHtml = nm
        ? escapeHtml(nm)
        : `<span class="ref-item-noname">Без назви · №${x.id}</span>`;
    return `<li class="ref-item">
        <span class="ref-item-name">${nameHtml}</span>
        ${withKind ? blockKindSelect(x.id, x.herd_kind) : ''}
        <button class="blk-del" data-del="${x.id}" title="Прибрати">−</button>
    </li>`;
}

// Плаский список блоків групи (за назвою). Підкатегорії тут не задаються.
function renderBlockList(kind, items) {
    const ul = document.querySelector(`.ref-list[data-blocklist="${kind}"]`);
    if (!ul) return;
    if (!items.length) { ul.innerHTML = '<li class="empty">Поки що порожньо</li>'; return; }
    items = items.slice().sort((a, b) =>
        (a.name || '').localeCompare(b.name || '', 'uk'));
    ul.innerHTML = items.map((x) => blockItemHtml(x, kind, false)).join('');
}

function renderNoneList(items) {
    const wrap = document.getElementById('blockGroupNone');
    const ul = document.querySelector('.ref-list[data-blocklist="none"]');
    if (!ul || !wrap) return;
    if (!items.length) { wrap.hidden = true; ul.innerHTML = ''; return; }
    wrap.hidden = false;          // показуємо лише якщо є старі нерозподілені блоки
    ul.innerHTML = items.map((x) => blockItemHtml(x, 'none', true)).join('');
}

// datalist наявних підгруп у групі — щоб перевикористовувати назви
function renderSubDatalists(by) {
    ['cow', 'young', 'pig'].forEach((k) => {
        let dl = document.getElementById('subs_' + k);
        if (!dl) {
            dl = document.createElement('datalist'); dl.id = 'subs_' + k;
            document.body.appendChild(dl);
        }
        const subs = [...new Set(by[k].map((x) => (x.subgroup || '').trim()).filter(Boolean))];
        dl.innerHTML = subs.map((s) => `<option value="${escapeHtml(s)}">`).join('');
    });
}

async function loadBlocks() {
    const r = await apiGet('/api/blocks');
    const items = (r && r.items) || [];
    const by = { cow: [], young: [], pig: [], none: [] };
    items.forEach((x) => {
        const k = ['cow', 'young', 'pig'].includes(x.herd_kind) ? x.herd_kind : 'none';
        by[k].push(x);
    });
    renderBlockList('cow', by.cow);
    renderBlockList('young', by.young);
    renderBlockList('pig', by.pig);
    // Групу «Не розподілено» прибрано з UI (старий безіменний мотлох
    // деактивується міграцією _cleanup_empty_blocks_once).
}

async function addBlockToGroup(kind, name, subgroup) {
    const r = await apiSend('/api/blocks', 'POST', { name, herd_kind: kind, subgroup: subgroup || '' });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return false; }
    toast(BW('nom') + ' додано', 'success');
    await loadBlocks();
    return true;
}

async function setBlockKind(id, herdKind) {
    const r = await apiSend('/api/blocks/' + id + '/kind', 'POST', { herd_kind: herdKind });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    loadBlocks();
}

async function setBlockSubgroup(id, subgroup) {
    const r = await apiSend('/api/blocks/' + id + '/subgroup', 'POST', { subgroup });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    loadBlocks();
}

async function setBlockHerdGroup(id, herdGroupId) {
    const r = await apiSend('/api/blocks/' + id + '/herd-group', 'POST',
                            { herd_group_id: herdGroupId || null });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    loadBlocks();
}

async function addRef(kind, name) {
    const cfg = REFS[kind];
    const r = await apiSend(cfg.api, 'POST', { name });
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return false; }
    toast('Додано', 'success');
    await loadRef(kind);
    return true;
}

async function delRef(kind, id) {
    const cfg = REFS[kind];
    if (!await confirmAction(`Видалити цей запис із довідника?`)) return;
    const r = await apiSend(`${cfg.api}/${id}`, 'DELETE');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    toast('Видалено', 'success');
    loadRef(kind);
}

document.querySelectorAll('form.ref-add[data-add]').forEach((form) => {
    const kind = form.dataset.add;
    const input = form.querySelector('.ref-add-input');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (input.value || '').trim();
        if (!name) { input.focus(); return; }
        if (await addRef(kind, name)) {
            input.value = '';
            input.focus();
        }
    });
});

/* Додавання блоку в конкретну групу (Корови / Молодняк) */
document.querySelectorAll('form.block-add').forEach((form) => {
    const kind = form.dataset.addkind;
    const input = form.querySelector('.ref-add-input');
    const subInput = form.querySelector('.ref-add-sub');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (input.value || '').trim();
        if (!name) { input.focus(); return; }
        const sub = subInput ? (subInput.value || '').trim() : '';
        if (await addBlockToGroup(kind, name, sub)) {
            input.value = ''; if (subInput) subInput.value = ''; input.focus();
        }
    });
});

/* Довідники отримувачів / постачальників */
document.querySelectorAll('.ref-list[data-list]').forEach((list) => {
    const kind = list.dataset.list;
    list.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-del]');
        if (btn) delRef(kind, btn.dataset.del);
    });
});

/* Панель блоків: прибрати блок + перенести нерозподілений у групу */
const blocksPanel = document.querySelector('.panel[data-ref="blocks"]');
if (blocksPanel) {
    blocksPanel.addEventListener('click', (e) => {
        const del = e.target.closest('[data-del]');
        if (del) delRef('blocks', del.dataset.del);
    });
    blocksPanel.addEventListener('change', (e) => {
        const sel = e.target.closest('[data-kind-for]');
        if (sel) { setBlockKind(sel.dataset.kindFor, sel.value); return; }
        const hg = e.target.closest('[data-herd-for]');
        if (hg) setBlockHerdGroup(hg.dataset.herdFor, hg.value);
    });
}

/* ============ Каталог препаратів/матеріалів ============ */

const catBody = document.getElementById('catBody');
const catSearch = document.getElementById('catSearch');
const catName = document.getElementById('catName');
const catUnit = document.getElementById('catUnit');
const catBarcode = document.getElementById('catBarcode');

let _catItems = [];

function renderCatalog() {
    if (!catBody) return;
    const q = (catSearch && catSearch.value || '').trim().toLowerCase();
    const items = q
        ? _catItems.filter((x) =>
            (x.name || '').toLowerCase().includes(q) ||
            (x.barcode || '').toLowerCase().includes(q))
        : _catItems;
    if (items.length === 0) {
        catBody.innerHTML = '<tr><td colspan="4" class="empty">' +
            (q ? 'Нічого не знайдено' : 'Поки що порожньо') + '</td></tr>';
        return;
    }
    catBody.innerHTML = items.map((x) => `
        <tr>
            <td>${escapeHtml(x.name)}</td>
            <td>${escapeHtml(x.unit || '')}</td>
            <td class="cat-bc">${escapeHtml(x.barcode)}</td>
            <td class="col-actions">
                <button class="btn btn-icon btn-icon-danger" data-cat-del="${x.id}"
                        title="Видалити">🗑</button>
            </td>
        </tr>`).join('');
}

async function loadCatalog() {
    if (!catBody) return;
    const r = await apiGet('/api/catalog');
    _catItems = (r && r.items) || [];
    const cnt = document.getElementById('catCount');
    if (cnt) cnt.textContent = _catItems.length ? '· ' + _catItems.length + ' позицій' : '';
    renderCatalog();
}

/* ---- Експорт каталогу у CSV ---- */
const catExportBtn = document.getElementById('catExportBtn');
if (catExportBtn) {
    catExportBtn.addEventListener('click', () => {
        if (!_catItems.length) { toast('Каталог порожній', 'warn'); return; }
        window.location.href = (window.API_BASE || '') + '/api/catalog/export';
    });
}

/* ---- Імпорт каталогу з файлу (CSV/Excel) ---- */
const catImportBtn = document.getElementById('catImportBtn');
const catImportFile = document.getElementById('catImportFile');
if (catImportBtn && catImportFile) {
    catImportBtn.addEventListener('click', () => catImportFile.click());
    catImportFile.addEventListener('change', async () => {
        const file = catImportFile.files && catImportFile.files[0];
        if (!file) return;
        const replace = await confirmAction(
            'Імпортувати «' + file.name + '» у каталог?\n\n' +
            'OK — додати/оновити (наявні лишаться).\n' +
            'Скасувати — нічого не робити.');
        if (!replace) { catImportFile.value = ''; return; }
        catImportBtn.disabled = true;
        catImportBtn.textContent = '⏳ Імпорт…';
        try {
            const fd = new FormData();
            fd.append('file', file);
            const url = (window.API_BASE || '') + '/api/catalog/import';
            const resp = await fetch(url, { method: 'POST', body: fd });
            const r = await resp.json();
            if (!r.ok) { toast(r.error || 'Помилка імпорту', 'error'); return; }
            toast('Імпортовано: +' + r.added + ', оновлено ' + r.updated +
                  ' (всього ' + r.catalog_count + ')', 'success');
            await loadCatalog();
        } catch (e) {
            toast('Помилка імпорту файлу', 'error');
        } finally {
            catImportBtn.disabled = false;
            catImportBtn.textContent = '⬆ Імпорт з файлу';
            catImportFile.value = '';
        }
    });
}

if (catSearch) catSearch.addEventListener('input', renderCatalog);

if (catBody) {
    catBody.addEventListener('click', async (e) => {
        const btn = e.target.closest('[data-cat-del]');
        if (!btn) return;
        if (!await confirmAction('Видалити запис із каталогу?')) return;
        const r = await apiSend('/api/catalog/' + btn.dataset.catDel, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Видалено', 'success');
        loadCatalog();
    });
}

const catGenBtn = document.getElementById('catGenBtn');
if (catGenBtn) {
    catGenBtn.addEventListener('click', async () => {
        catGenBtn.disabled = true;
        const r = await apiGet('/api/generate-barcode');
        catGenBtn.disabled = false;
        if (!r.ok || !r.barcode) { toast(r.error || 'Не вдалося згенерувати', 'error'); return; }
        if (catBarcode) catBarcode.value = r.barcode;
        toast('Штрихкод згенеровано', 'success');
    });
}

const catAddForm = document.getElementById('catAddForm');
if (catAddForm) {
    // ⚠️ Замок: друге надсилання форми заводило ДРУГИЙ запис із тією самою назвою
    let catBusy = false;
    catAddForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (catBusy) return;
        catBusy = true;
        try { await catAddRun(); } finally { catBusy = false; }
    });

    async function catAddRun() {
        const name = (catName.value || '').trim();
        if (!name) { catName.focus(); return; }
        let barcode = (catBarcode.value || '').trim();
        // Без штрихкоду — згенеруємо внутрішній автоматично
        if (!barcode) {
            const g = await apiGet('/api/generate-barcode');
            if (!g.ok || !g.barcode) { toast(g.error || 'Вкажіть штрихкод', 'error'); return; }
            barcode = g.barcode;
        }
        const r = await apiSend('/api/catalog', 'POST', {
            name, unit: (catUnit.value || '').trim() || 'шт', barcode,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Додано в каталог', 'success');
        catName.value = ''; catUnit.value = ''; catBarcode.value = '';
        catName.focus();
        await loadCatalog();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    Object.keys(REFS).forEach(loadRef);
    loadCatalog();
});
