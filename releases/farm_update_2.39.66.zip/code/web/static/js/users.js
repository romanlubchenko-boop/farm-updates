/* ============ Користувачі (адмін) ============ */

const usersBody         = document.querySelector('#usersTable tbody');
const userForm          = document.getElementById('userForm');
const userModalTitle    = document.getElementById('userModalTitle');
const userPasswordLabel = document.getElementById('userPasswordLabel');

const ROLE_LABEL = { admin: 'Адміністратор', user: 'Користувач' };

const userBranchesList = document.getElementById('userBranchesList');

const userWorkPlace = document.getElementById('userWorkPlace');

/* Рівень доступу на КОЖНУ гілку: '' немає | view | work | manage. */
function setBranchLevels(levels) {
    const map = levels || {};
    userBranchesList.querySelectorAll('.ubranch').forEach((sel) => {
        sel.value = map[sel.dataset.branch] || '';
    });
}

function selectedBranchLevels() {
    const out = {};
    userBranchesList.querySelectorAll('.ubranch').forEach((sel) => {
        if (sel.value) out[sel.dataset.branch] = sel.value;
    });
    return out;
}

/* Робочі місця ферми — щоб можна було привʼязати людину до КОНКРЕТНОГО
   компʼютера, а не просто «до якогось ПК» (Роман 2026-09-11: «щоб не входити
   під чужим акаунтом на іншому ПК»). */
let PLACES = [];

async function loadPlaces() {
    try {
        const r = await apiGet('/api/setup/places');
        PLACES = (r && r.places) || [];
    } catch (e) { PLACES = []; }
    if (!userWorkPlace) return;
    Array.from(userWorkPlace.options).forEach((o) => { if (o.dataset.dyn) o.remove(); });
    PLACES.forEach((pl) => {
        if (pl.key === 'server') return;          // «лише у браузері» вже є вище
        const o = document.createElement('option');
        o.value = pl.key; o.dataset.dyn = '1';
        o.textContent = 'лише на компʼютері ' + pl.name;
        userWorkPlace.appendChild(o);
    });
}

function loadBranchesForNew() {
    setBranchLevels({});
    if (userWorkPlace) userWorkPlace.value = 'any';
}

async function loadBranchesForUser(id) {
    const r = await apiGet('/api/users/' + id + '/branches');
    setBranchLevels((r && r.levels) || {});
    if (!userWorkPlace) return;
    const w = (r && r.work_place) || 'any';
    // привʼязка до компʼютера, якого вже немає у списку — показуємо як є
    if (w.indexOf('dev:') === 0 && !PLACES.some((pl) => pl.key === w)) {
        const o = document.createElement('option');
        o.value = w; o.dataset.dyn = '1';
        o.textContent = 'лише на компʼютері (не на звʼязку)';
        userWorkPlace.appendChild(o);
    }
    userWorkPlace.value = w;
}

async function saveBranches(id) {
    await apiSend('/api/users/' + id + '/branches', 'POST', {
        levels: selectedBranchLevels(),
        work_place: (userWorkPlace && userWorkPlace.value) || 'any',
    });
}

/* ---- Офлайн-доступ (галочки по гілках) ---- */

function formatActivity(lastSeen, isOnline) {
    if (!lastSeen) return '<span class="text-mute">—</span>';
    const t = Date.parse(String(lastSeen).replace(' ', 'T'));
    if (!t) return '<span class="text-mute">' + escapeHtml(lastSeen) + '</span>';
    const diff = Date.now() - t;
    const mins = Math.floor(Math.max(0, diff) / 60000);
    // «Онлайн» — лише якщо користувач залогінений І останній запит свіжий
    if (isOnline && mins < 5) {
        return '<span class="online-now">● Онлайн</span>';
    }
    if (mins < 1) return 'щойно';
    if (mins < 60) return mins + ' хв тому';
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return hrs + ' год тому';
    const days = Math.floor(hrs / 24);
    if (days < 7) return days + ' дн тому';
    return '<span class="text-mute">' + fmtDateTime(lastSeen) + '</span>';
}

let userList = [];
let editingUserId = null;
let lastUsersJson = '';
let userView = 'active';   // 'active' | 'inactive'

async function loadUsers() {
    const r = await apiGet('/api/users');
    if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
    userList = r.items || [];
    // Перемальовуємо тільки якщо щось реально змінилось — економія миготіння
    const j = userView + '|' + JSON.stringify(userList);
    if (j === lastUsersJson) return;
    lastUsersJson = j;
    renderUsers();
}

function renderUsers() {
    const wantActive = (userView === 'active');
    const rows = userList.filter((u) => !!u.is_active === wantActive);
    if (!rows.length) {
        usersBody.innerHTML = '<tr><td colspan="7" class="empty">' +
            (wantActive ? 'Активних користувачів немає' : 'Неактивних користувачів немає') +
            '</td></tr>';
        return;
    }
    usersBody.innerHTML = rows.map((u) => `
        <tr data-id="${u.id}">
            <td><strong>${escapeHtml(u.username)}</strong></td>
            <td>${escapeHtml(u.full_name || '')}</td>
            <td>${ROLE_LABEL[u.role] || u.role}</td>
            <td>${u.is_active ? 'Так' : '<span class="text-danger">Ні</span>'}</td>
            <td class="nowrap">${formatActivity(u.last_seen, u.is_online)}</td>
            <td class="text-mute nowrap">${fmtDateTime(u.created_at)}</td>
            <td class="col-actions">
                <div class="row-actions">
                    ${u.is_active ? `
                        <button class="btn btn-icon" data-edit="${u.id}" title="Редагувати">✎</button>
                        <button class="btn btn-icon btn-icon-danger" data-delete="${u.id}" title="Видалити">🗑</button>
                    ` : `
                        <button class="btn btn-ghost" data-restore="${u.id}" title="Відновити доступ">↩ Відновити</button>
                    `}
                </div>
            </td>
        </tr>
    `).join('');
}

document.querySelectorAll('#userViewToggle .seg-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
        if (btn.dataset.view === userView) return;
        userView = btn.dataset.view;
        document.querySelectorAll('#userViewToggle .seg-btn').forEach((b) =>
            b.classList.toggle('is-active', b.dataset.view === userView));
        lastUsersJson = '';
        renderUsers();
    });
});

const userPasswordField    = document.getElementById('userPasswordField');
const userPasswordSelfHint = document.getElementById('userPasswordSelfHint');

document.getElementById('addUserBtn').addEventListener('click', () => {
    userForm.reset();
    userForm.id.value = '';
    userForm.username.disabled = false;
    editingUserId = null;
    userModalTitle.textContent = 'Новий користувач';
    userPasswordLabel.textContent = 'Пароль (мін. 4 символи)';
    userForm.password.required = true;
    userPasswordField.hidden = false;
    userPasswordSelfHint.hidden = true;
    loadBranchesForNew();
    openModal('userModal');
});

usersBody.addEventListener('click', async (e) => {
    const editBtn = e.target.closest('[data-edit]');
    const delBtn  = e.target.closest('[data-delete]');
    if (editBtn) {
        const id = parseInt(editBtn.dataset.edit, 10);
        const u = userList.find((x) => x.id === id);
        if (!u) return;
        userForm.reset();
        userForm.id.value = u.id;
        userForm.username.value = u.username;
        userForm.full_name.value = u.full_name || '';
        userForm.role.value = u.role;
        userForm.is_active.value = u.is_active ? '1' : '0';
        editingUserId = u.id;
        userModalTitle.textContent = 'Редагування: ' + u.username;
        userPasswordLabel.textContent = 'Новий пароль (порожньо — не змінювати)';
        userForm.password.required = false;
        // Якщо адмін редагує сам себе — ховаємо поле скидання пароля.
        // Свій пароль міняється через 🔑 у топбарі з підтвердженням старого.
        const isSelf = u.id === CURRENT_USER_ID;
        userPasswordField.hidden = isSelf;
        userPasswordSelfHint.hidden = !isSelf;
        if (isSelf) userForm.password.value = '';
        loadBranchesForUser(u.id);
        openModal('userModal');
        return;
    }
    if (delBtn) {
        const id = parseInt(delBtn.dataset.delete, 10);
        if (!await confirmAction('Видалити цього користувача? Його можна буде відновити у вкладці «Неактивні».')) return;
        const r = await apiSend('/api/users/' + id, 'DELETE');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Користувача видалено', 'success');
        lastUsersJson = '';
        loadUsers();
        return;
    }
    const restoreBtn = e.target.closest('[data-restore]');
    if (restoreBtn) {
        const id = parseInt(restoreBtn.dataset.restore, 10);
        const r = await apiSend('/api/users/' + id + '/restore', 'POST');
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        toast('Користувача відновлено', 'success');
        lastUsersJson = '';
        loadUsers();
    }
});

userForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(userForm).entries());
    delete data.id;
    if (editingUserId) {
        const upd = {
            username: data.username,
            role: data.role,
            full_name: data.full_name,
            is_active: data.is_active === '1',
        };
        const r = await apiSend('/api/users/' + editingUserId, 'PUT', upd);
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        if (data.password) {
            const p = await apiSend('/api/users/' + editingUserId + '/password',
                                    'POST', { password: data.password });
            if (!p.ok) { toast(p.error || 'Не вдалося змінити пароль', 'error'); return; }
        }
        await saveBranches(editingUserId);
        toast('Користувача оновлено', 'success');
    } else {
        if (!data.password) { toast('Вкажіть пароль', 'warn'); return; }
        const r = await apiSend('/api/users', 'POST', {
            username: data.username,
            password: data.password,
            role: data.role,
            full_name: data.full_name,
        });
        if (!r.ok) { toast(r.error || 'Помилка', 'error'); return; }
        if (r.id) { await saveBranches(r.id); }
        toast('Користувача додано', 'success');
    }
    userForm.username.disabled = false;
    closeModal('userModal');
    loadUsers();
});

/* ---------- авто-оновлення статусів онлайн ---------- */

let usersPollTimer = null;

function startUsersPoll() {
    if (usersPollTimer) return;
    usersPollTimer = setInterval(loadUsers, 5000);  // раз на 5 секунд
}

function stopUsersPoll() {
    if (usersPollTimer) {
        clearInterval(usersPollTimer);
        usersPollTimer = null;
    }
}

// Не оновлюємо, поки вкладка прихована — економимо запити
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        stopUsersPoll();
    } else {
        loadUsers();
        startUsersPoll();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    loadPlaces();
    loadUsers();
    startUsersPoll();
});


/* ---------- «Хто що може» + «Хто що зробив» ---------- */
/* Матриця: користувачі × гілки одним екраном, зміна прямо в клітинках.
   Збереження — тим самим POST /api/users/<id>/branches, що й картка. */
(function () {
    const tbl = document.getElementById('permMatrix');
    const actUser = document.getElementById('actUser');
    const actList = document.getElementById('actList');
    if (!tbl) return;
    const esc = (x) => { const d = document.createElement('div'); d.textContent = x == null ? '' : x; return d.innerHTML; };
    const LVLS = [['', '—'], ['view', 'перегляд'], ['work', 'робота'], ['manage', 'керування']];
    let M = null;

    function lvlSel(uid, branch, val) {
        return '<select class="pm-lvl" data-uid="' + uid + '" data-branch="' + branch + '">'
            + LVLS.map(([v, t]) => '<option value="' + v + '"'
                + (v === (val || '') ? ' selected' : '') + '>' + t + '</option>').join('')
            + '</select>';
    }

    function placeSel(uid, val) {
        let opts = [['any', 'будь-де'], ['server', 'лише сервер'], ['pc', 'будь-який ПК']]
            .concat((M.places || []).filter((p) => p.key !== 'server')
                .map((p) => [p.key, p.name]));
        if (val && !opts.some(([v]) => v === val)) opts.push([val, 'компʼютер (не на звʼязку)']);
        return '<select class="pm-place" data-uid="' + uid + '">'
            + opts.map(([v, t]) => '<option value="' + v + '"'
                + (v === val ? ' selected' : '') + '>' + esc(t) + '</option>').join('')
            + '</select>';
    }

    function render() {
        const brs = M.branches || [];
        tbl.querySelector('thead').innerHTML = '<tr><th>Користувач</th>'
            + brs.map((b) => '<th>' + esc(b.label) + '</th>').join('')
            + '<th>Де вносить зміни</th></tr>';
        const rows = (M.users || []).filter((u) => u.is_active).map((u) => {
            const nm = esc(u.full_name || u.username);
            if (u.role === 'admin') {
                return '<tr><td><b>' + nm + '</b></td><td colspan="'
                    + (brs.length + 1) + '" class="text-mute">адміністратор — повний '
                    + 'доступ, працює лише з сервера</td></tr>';
            }
            return '<tr><td><b>' + nm + '</b></td>'
                + brs.map((b) => '<td>' + lvlSel(u.id, b.id, (u.levels || {})[b.id]) + '</td>').join('')
                + '<td>' + placeSel(u.id, u.work_place || 'any') + '</td></tr>';
        });
        tbl.querySelector('tbody').innerHTML = rows.join('')
            || '<tr><td class="empty">Немає користувачів</td></tr>';
    }

    async function saveRow(uid) {
        const u = (M.users || []).find((x) => x.id === uid);
        if (!u) return;
        const levels = {};
        tbl.querySelectorAll('.pm-lvl[data-uid="' + uid + '"]').forEach((sel) => {
            if (sel.value) levels[sel.dataset.branch] = sel.value;
        });
        const place = tbl.querySelector('.pm-place[data-uid="' + uid + '"]');
        const st = document.getElementById('pmStatus');
        try {
            const r = await apiSend('/api/users/' + uid + '/branches', 'POST',
                { levels, work_place: (place && place.value) || 'any' });
            if (st) st.textContent = (r && r.ok) ? '✓ збережено' : ((r && r.error) || '✗');
            u.levels = levels;
            if (place) u.work_place = place.value;
        } catch (e) { if (st) st.textContent = '✗ сервер не відповів'; }
        if (st) setTimeout(() => { st.textContent = ''; }, 2200);
    }

    tbl.addEventListener('change', (e) => {
        const t = e.target.closest('.pm-lvl, .pm-place');
        if (t) saveRow(parseInt(t.dataset.uid, 10));
    });

    async function loadActivity(uid) {
        if (!actList) return;
        actList.innerHTML = '<tr><td colspan="3" class="empty">Завантаження…</td></tr>';
        let r; try { r = await apiGet('/api/users/' + uid + '/activity'); } catch (e) { r = null; }
        const items = (r && r.items) || [];
        actList.innerHTML = items.map((it) => '<tr><td>' + esc((it.at || '').slice(0, 16))
            + '</td><td>' + esc(it.text) + '</td><td>' + esc(it.where || '—') + '</td></tr>').join('')
            || '<tr><td colspan="3" class="empty">Дій ще не зафіксовано</td></tr>';
    }

    (async function init() {
        let r; try { r = await apiGet('/api/users/matrix'); } catch (e) { return; }
        if (!r || !r.ok) return;
        M = r;
        render();
        if (actUser) {
            actUser.innerHTML = (M.users || []).filter((u) => u.is_active)
                .map((u) => '<option value="' + u.id + '">'
                    + esc(u.full_name || u.username) + '</option>').join('');
            actUser.addEventListener('change', () => loadActivity(parseInt(actUser.value, 10)));
            if (actUser.value) loadActivity(parseInt(actUser.value, 10));
        }
    })();
})();
