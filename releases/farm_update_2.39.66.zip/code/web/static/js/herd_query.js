/* Рядок запиту реєстру тварин: «мова» зі слів конструктора.
   Роман 2026-09-18: «контекстне поле, щоб зробити будь-який звіт і не
   обовʼязково його зберігати». Приклад:

     днів з осіменіння >= 35, репродуктивний код = 4,
     показати кличка, група, днів з осіменіння,
     групувати група, сортувати номер тварини

   Слова — ті самі, що в конструкторі параметрів: назва, скорочення або ключ.
   Порівняння: = ≠ > >= < <= , «between 28 35», «empty», «notempty»,
   «contains», кілька значень через «or». Службові слова — англійською
   (Роман 2026-09-19), як і дії FILTER/BODY/VIEW; українські (між, містить,
   порожньо, не порожньо, або) лишаються запасними — старі формули працюють. */
'use strict';

(function () {
    const norm = (s) => String(s === null || s === undefined ? '' : s)
        .trim().toLowerCase().replace(/[ʼ`´]/g, "'").replace(/\s+/g, ' ');
    const numOf = (v) => {
        const s = String(v === null || v === undefined ? '' : v).replace(',', '.').trim();
        if (!s || !/^-?\d+(\.\d+)?$/.test(s)) return null;
        return parseFloat(s);
    };

    // слова, з яких починається розділ запиту
    const HEADS = [
        { re: /^(body|тіло|показати|вивести|колонки)(?=\s|$)/, mode: 'show' },
        { re: /^(sort|сортувати|сортування|порядок)(?=\s|$)/, mode: 'sort' },
        { re: /^(groupby|групувати|групування|по групах)(?=\s|$)/, mode: 'group' },
        { re: /^(filter|де|фільтр|відбір)(?=\s|$)/, mode: 'where' },
    ];
    const DESC = /^(desc|спад|спадання|спадаюче|назад|↓)$/;
    const ASC = /^(asc|зрост|зростання|зростаюче|↑)$/;

    /* Параметр за словом: назва, скорочення, ключ або однозначний початок. */
    function findParam(word, params) {
        const w = norm(String(word).replace(/^\s*\[|\]\s*$/g, ''));
        if (!w) return null;
        const eq = params.find((p) => norm(p.label) === w || norm(p.short) === w
            || norm(p.key) === w);
        if (eq) return eq;
        const starts = params.filter((p) => norm(p.label).startsWith(w)
            || norm(p.short).startsWith(w) || norm(p.key).startsWith(w));
        if (starts.length === 1) return starts[0];
        const inside = params.filter((p) => norm(p.label).includes(w));
        if (inside.length === 1) return inside[0];
        return null;
    }

    /* Значення умови: для списків приймається і назва, і код. */
    function valueOf(p, raw) {
        // значення з пробілами пишуться в дужках: group=[Група 0-3]
        const v = String(raw || '').trim().replace(/^\[(.*)\]$/, '$1').trim();
        const ch = p.choices || [];
        if (!ch.length) return v;
        const w = norm(v);
        const hit = ch.find((c) => norm(c.value) === w || norm(c.label) === w)
            || ch.find((c) => norm(c.label).startsWith(w))
            || ch.find((c) => norm(c.label).includes(w));
        return hit ? String(hit.value) : v;
    }

    function parseWhere(part, params) {
        const src = part.trim();
        // «empty» / «notempty» (і «порожньо» / «не порожньо»)
        let m = src.match(/^(.+?)\s+(notempty|not\s+empty|empty|(?:не\s+)?порожн\S*)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            return { f: { key: p.key, op: /^(не|not)/i.test(m[2]) ? 'nempty' : 'empty' } };
        }
        // «between 28 35», «between 28 and 35» (і «між 28 35»)
        m = src.match(/^(.+?)\s+(?:between|між)\s+(.+?)\s*(?:,|—|-|\s+and\s+|\s+і\s+|\s+та\s+|\s)\s*(\S+)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            return { f: { key: p.key, op: 'between', v: m[2].trim(), v2: m[3].trim() } };
        }
        // «contains текст» (і «містить»)
        m = src.match(/^(.+?)\s+(?:contains|містить)\s+(.+)$/i);
        if (m) {
            const p = findParam(m[1], params);
            if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
            return { f: { key: p.key, op: 'has', v: m[2].trim() } };
        }
        // звичайне порівняння
        m = src.match(/^(.+?)\s*(>=|<=|<>|!=|≠|≥|≤|=|>|<)\s*(.+)$/);
        if (!m) return { error: `не зрозуміла умова «${src}»` };
        const p = findParam(m[1], params);
        if (!p) return { error: `невідомий параметр «${m[1].trim()}»` };
        const opMap = { '>=': 'ge', '≥': 'ge', '<=': 'le', '≤': 'le', '<>': 'ne', '!=': 'ne', '≠': 'ne', '=': 'eq', '>': 'gt', '<': 'lt' };
        const op = opMap[m[2]];
        const vals = m[3].split(/\s+(?:or|або)\s+|\s*\|\s*/).map((x) => valueOf(p, x)).filter((x) => x !== '');
        if (op === 'eq' && vals.length > 1) return { f: { key: p.key, op: 'eq', vals } };
        if (op === 'ne' && vals.length > 1) return { f: { key: p.key, op: 'ne', vals } };
        return { f: { key: p.key, op, v: vals[0] || '' } };
    }

    /* Функції формули (одним рядком, як в Excel):
       =ФІЛЬТР([Днів з осіменіння]>=35; [Репродуктивний код]=4)
        ПОКАЗАТИ([Кличка]; [Група]) ГРУПУВАТИ([Група]) СОРТУВАТИ([Номер тварини]; спад) */
    // три частини, як у налаштуваннях списку календаря:
    // ТІЛО (які параметри) · ФІЛЬТРАЦІЯ (кого брати) · ВІДОБРАЖЕННЯ (як показати)
    const FUNCS = {
        'body': 'show', 'тіло': 'show', 'показати': 'show', 'колонки': 'show',
        'filter': 'where', 'фільтрація': 'where', 'фільтр': 'where', 'де': 'where',
        'view': 'display', 'відображення': 'display', 'вигляд': 'display',
        'sort': 'sort', 'сортувати': 'sort', 'порядок': 'sort',
        'groupby': 'group', 'групувати': 'group', 'групи': 'group',
    };
    // слова всередині ВІДОБРАЖЕННЯ(…)
    const SHOW_WORDS = [
        { re: /^(groupby|групувати|групи|за групами)(?=\s|$)/, mode: 'group' },
        { re: /^(sort|сортувати|порядок|за)(?=\s|$)/, mode: 'sort' },
    ];
    const isFormula = (text) => {
        const t = String(text || '');
        if (/^\s*=/.test(t)) return true;
        return new RegExp('(' + Object.keys(FUNCS).join('|') + ')\\s*\\(', 'i').test(t);
    };
    /* Формула → ті самі розділи, що й рядки. */
    /* Частини ТІЛО(…) ФІЛЬТРАЦІЯ(…) ВІДОБРАЖЕННЯ(…): усередині можна писати
       і через пробіл, і через «;» — як зручніше (Роман 2026-09-18). */
    const NAME = '(\\[[^\\]]+\\]|[^\\s;,[\\]<>=!≠≥≤]+)';
    const ONE = '(?:\\[[^\\]]+\\]|[^\\s;,]+)';
    const VAL = ONE + '(?:\\s+(?:or|або)\\s+' + ONE + ')*';
    const CONDS = new RegExp(
        NAME + '\\s*(?:'
        + '(>=|<=|<>|!=|≠|≥|≤|=|>|<)\\s*(' + VAL + ')'          // dslh>=35
        + '|(between|між)\\s+([^\\s;,]+)\\s*(?:and|і|та|-|—)?\\s*([^\\s;,]+)' // dslh between 28 35
        + '|(contains|містить)\\s+([^\\s;,]+)'                     // name contains Рай
        + '|(notempty|not\\s+empty|empty|не\\s+порожньо|порожньо)'   // name notempty
        + ')', 'giu');

    function splitNames(src) {                    // «name group dslh» або «[name]; [group]»
        return String(src).split(/[;,]|\s+/).map((x) => x.trim()).filter(Boolean);
    }

    function splitConds(src) {                    // «dslh>=35 rc=4» або «dslh >= 35; rc = 4»
        const txt = String(src).trim();
        if (!txt) return [];
        const out = [];
        let m;
        CONDS.lastIndex = 0;
        while ((m = CONDS.exec(txt))) {
            const nm = m[1];
            if (m[2]) out.push(`${nm} ${m[2]} ${m[3]}`);
            else if (m[4]) out.push(`${nm} between ${m[5]} ${m[6]}`);
            else if (m[7]) out.push(`${nm} contains ${m[8]}`);
            else if (m[9]) out.push(`${nm} ${/^(не|not)/i.test(m[9]) ? 'notempty' : 'empty'}`);
        }
        return out.length ? out : txt.split(/[;,]/).map((x) => x.trim()).filter(Boolean);
    }

    /* ВІДОБРАЖЕННЯ: слова-дії, далі назви; «спад» діє на попереднє сортування */
    function splitDisplay(src, out, params) {
        const toks = String(src).split(/[;,]|\s+/).map((x) => x.trim()).filter(Boolean);
        let mode = '';
        let expect = false;                       // одразу після «group»/«sort» іде назва
        const isKw = (n) => /^(groupby|групувати|групи|sort|сортувати|порядок)$/.test(n);
        for (let ti = 0; ti < toks.length; ti++) {
            const t = toks[ti];
            const n = norm(t);
            // «group» — і слово-дія, і коротка назва параметра «Група». Якщо далі
            // назви немає — це сам параметр (VIEW(group) = групувати за групою).
            const nextT = toks[ti + 1];
            const asKw = isKw(n) && !expect
                && (!findParam(t, params) || (nextT && !!findParam(nextT, params)));
            if (asKw && /^(groupby|групувати|групи)$/.test(n)) { mode = 'group'; expect = true; continue; }
            if (asKw && /^(sort|сортувати|порядок)$/.test(n)) { mode = 'sort'; expect = true; continue; }
            if (/^(no|num|нумерація|нумерувати|номер|№)$/.test(n)) { out.push({ mode: 'rownum', text: '1' }); continue; }
            if (/^(cnt|count|кількість|к-сть)$/.test(n)) {
                const nx = toks[ti + 1];
                const hasP = nx && !isKw(norm(nx)) && !DESC.test(norm(nx)) && !ASC.test(norm(nx))
                    && !/^(cnt|count|avg|sum|min|max|no|num|кількість|середнє|сума|мін|макс|нумерація)$/.test(norm(nx))
                    && !!findParam(nx, params);
                out.push({ mode: 'cnt', text: hasP ? nx : '' });
                if (hasP) ti += 1;
                expect = false;
                continue;
            }
            if (/^(avg|середнє|середне)$/.test(n)) { mode = 'avg'; expect = true; continue; }
            if (/^(sum|сума)$/.test(n)) { mode = 'sum'; expect = true; continue; }
            if (/^(min|мін|мінімум)$/.test(n)) { mode = 'min'; expect = true; continue; }
            if (/^(max|макс|максимум)$/.test(n)) { mode = 'max'; expect = true; continue; }
            if (DESC.test(n) || ASC.test(n)) {
                // «desc» діє на попереднє сортування, а якщо його немає —
                // на попереднє групування: VIEW(groupby group desc) = групи навпаки
                let hit = -1;
                for (let i = out.length - 1; i >= 0; i--) {
                    if (out[i].mode === 'sort' || out[i].mode === 'group') { hit = i; break; }
                }
                if (hit >= 0 && out[hit].mode === 'sort') out[hit].text += ' ' + t;
                else if (hit >= 0) out.push({ mode: 'sort', text: `${out[hit].text} ${t}` });
                continue;
            }
            if (!mode) mode = 'group';            // сама назва у VIEW = групування
            out.push({ mode, text: t });
            expect = false;
        }
        return '';
    }

    function formulaParts(text, params) {
        const src = String(text || '').replace(/^\s*=/, '');
        const out = [];
        const re = /([\p{L}]+)\s*\(([^()]*)\)/gu;
        let m, seen = 0;
        // те, що не вклалось у ДІЯ(...) — напр. незакрита дужка «VIEW(groupby group»
        // або зайве слово: не мовчати й НЕ губити при впорядкуванні рядка
        const left = src.replace(re, ' ').trim();
        if (left) return { error: `не зрозуміло «${left}» — перевірте дужки` };
        while ((m = re.exec(src))) {
            const fn = FUNCS[norm(m[1])];
            if (!fn) return { error: `невідома дія «${m[1]}»` };
            seen += 1;
            if (fn === 'display') {
                const err = splitDisplay(m[2], out, params);
                if (err) return { error: err };
            } else if (fn === 'where') {
                splitConds(m[2]).forEach((c) => out.push({ mode: 'where', text: c }));
            } else if (fn === 'sort') {
                const toks = splitNames(m[2]);
                const dir = toks.filter((t) => DESC.test(norm(t)) || ASC.test(norm(t))).pop() || '';
                toks.filter((t) => !DESC.test(norm(t)) && !ASC.test(norm(t)))
                    .forEach((t) => out.push({ mode: 'sort', text: dir ? `${t} ${dir}` : t }));
            } else {
                splitNames(m[2]).forEach((t) => out.push({ mode: fn, text: t }));
            }
        }
        if (!seen) return { error: 'не бачу жодної дії — напр. FILTER(rc=4)' };
        return { parts: out };
    }

    /* Текст → {cols, filters, sorts, groups, keys, error}. */
    function parse(text, params) {
        const out = { cols: [], filters: [], sorts: [], groups: [], rownum: false,
            aggs: [], keys: [], error: '' };
        const src = String(text || '').trim();
        if (!src) return out;
        let mode = 'where';
        let parts;
        let modes = null;
        if (isFormula(src)) {
            const f = formulaParts(src, params);
            if (f.error) { out.error = f.error; return out; }
            parts = f.parts.map((x) => x.text);
            modes = f.parts.map((x) => x.mode);
        } else {
            parts = src.split(/[,;\n]+/).map((x) => x.trim()).filter(Boolean);
        }
        for (let pi = 0; pi < parts.length; pi++) {
            let part = parts[pi];
            if (modes) mode = modes[pi];
            if (mode === 'rownum') { out.rownum = true; continue; }
            if (mode === 'cnt' && !part) { out.aggs.push({ fn: 'cnt', key: '' }); continue; }
            if (mode === 'cnt') {
                const p = part ? findParam(part, params) : null;
                if (part && !p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.aggs.push({ fn: 'cnt', key: p ? p.key : '' });
                continue;
            }
            if (['avg', 'sum', 'min', 'max'].includes(mode)) {
                const p = findParam(part, params);
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.aggs.push({ fn: mode, key: p.key });
                continue;
            }
            for (const h of (modes ? [] : HEADS)) {
                if (h.re.test(norm(part))) {
                    mode = h.mode;
                    part = part.replace(/^\S+\s*/, '').trim();
                    break;
                }
            }
            if (!part) continue;
            if (mode === 'show' || mode === 'group') {
                let p = findParam(part, params);
                if (!p && parts[pi + 1]) {          // назва з комою: «Вік, міс»
                    const joined = part + ', ' + parts[pi + 1];
                    p = findParam(joined, params);
                    if (p) pi += 1;
                }
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                (mode === 'show' ? out.cols : out.groups).push(p.key);
            } else if (mode === 'sort') {
                const w = part.split(/\s+/);
                let dir = 'asc';
                if (w.length > 1 && (DESC.test(norm(w[w.length - 1])) || ASC.test(norm(w[w.length - 1])))) {
                    dir = DESC.test(norm(w.pop())) ? 'desc' : 'asc';
                }
                let p = findParam(w.join(' '), params);
                if (!p && parts[pi + 1]) {
                    p = findParam(w.join(' ') + ', ' + parts[pi + 1], params);
                    if (p) pi += 1;
                }
                if (!p) { out.error = `невідомий параметр «${part}»`; return out; }
                out.sorts.push({ key: p.key, dir });
            } else {
                let r = parseWhere(part, params);
                if (r.error && parts[pi + 1]) {     // назва з комою: «Вік, міс > 24»
                    const r2 = parseWhere(part + ', ' + parts[pi + 1], params);
                    if (!r2.error) { r = r2; pi += 1; }
                }
                if (r.error) { out.error = r.error; return out; }
                out.filters.push(r.f);
            }
        }
        out.cols = [...new Set(out.cols)];       // «вік, міс» не двоїться
        out.groups = [...new Set(out.groups)];
        out.keys = [...new Set([...out.cols, ...out.groups, ...out.aggs.map((a) => a.key),
            ...out.sorts.map((s) => s.key), ...out.filters.map((f) => f.key)])];
        return out;
    }

    /* ── перевірка умов ───────────────────────────────────────────────── */
    const valOf = (a, k) => (a.p || {})[k];
    const labOf = (a, k) => (a.pl || {})[k];

    function cmp(a, f) {
        const raw = valOf(a, f.key);
        const has = !(raw === null || raw === undefined || raw === '');
        if (f.op === 'empty') return !has;
        if (f.op === 'nempty') return has;
        if (!has) return false;
        const n = numOf(raw);
        const list = (f.vals || []).map(norm);
        const one = norm(f.v);
        const lab = norm(labOf(a, f.key));
        const me = norm(raw);
        if (f.op === 'has') return me.includes(one) || lab.includes(one);
        if (f.op === 'eq') return list.length ? (list.includes(me) || list.includes(lab))
            : (me === one || lab === one);
        if (f.op === 'ne') return list.length ? !(list.includes(me) || list.includes(lab))
            : (me !== one && lab !== one);
        if (f.op === 'between') {
            const lo = numOf(f.v), hi = numOf(f.v2);
            if (n === null || lo === null || hi === null) return false;
            return n >= Math.min(lo, hi) && n <= Math.max(lo, hi);
        }
        const x = numOf(f.v);
        if (n === null || x === null) {            // дати й текст — як рядки
            const s = String(raw), t = String(f.v);
            if (f.op === 'gt') return s > t;
            if (f.op === 'ge') return s >= t;
            if (f.op === 'lt') return s < t;
            if (f.op === 'le') return s <= t;
            return false;
        }
        if (f.op === 'gt') return n > x;
        if (f.op === 'ge') return n >= x;
        if (f.op === 'lt') return n < x;
        if (f.op === 'le') return n <= x;
        return false;
    }

    const passes = (a, filters) => (filters || []).every((f) => cmp(a, f));

    /* Сортування кількома ключами; порожні — в кінець. */
    function sortRows(rows, sorts, params) {
        const order = new Map();
        (params || []).forEach((p) => {
            const m = new Map();
            (p.choices || []).forEach((c, i) => { m.set(String(c.value), i); });
            order.set(p.key, m);
        });
        // значення для порівняння: [ранг, число] або [ранг, рядок]. Ранг ділить
        // числа/позиції у списку (0) і текст (1) — інакше порівняння числа з
        // рядком дає NaN, і сортування мовчки розвалюється (секція, якої немає
        // у списку конструктора, ламала порядок усіх груп)
        const val = (a, k) => {
            const raw = valOf(a, k);
            if (raw === null || raw === undefined || raw === '') return null;
            const pos = order.get(k);
            if (pos && pos.size && pos.has(String(raw))) return [0, pos.get(String(raw))];
            const n = numOf(raw);
            return n === null ? [1, norm(raw)] : [0, n];
        };
        const cmpv = (a, b) => {
            if (a[0] !== b[0]) return a[0] - b[0];
            if (a[1] < b[1]) return -1;
            if (a[1] > b[1]) return 1;
            return 0;
        };
        return rows.slice().sort((x, y) => {
            for (const s of (sorts || [])) {
                const a = val(x, s.key), b = val(y, s.key);
                if (a === null && b === null) continue;
                if (a === null) return 1;
                if (b === null) return -1;
                const c = cmpv(a, b);
                if (c) return s.dir === 'desc' ? -c : c;
            }
            return 0;
        });
    }

    /* Акуратний вигляд формули: дії великими, без зайвих пробілів,
       параметри — короткими назвами (Роман 2026-09-18). */
    const OP_SIGN = { eq: '=', ne: '<>', gt: '>', ge: '>=', lt: '<', le: '<=' };

    function shortOf(key, params) {
        const p = (params || []).find((x) => x.key === key);
        return p ? ((p.short || p.key || '').trim() || p.label) : key;
    }

    function format(q, params) {
        if (!q || q.error) return '';
        const nm = (k) => shortOf(k, params);
        const parts = [];
        if (q.cols.length) parts.push(`BODY(${q.cols.map(nm).join(' ')})`);
        if (q.filters.length) {
            parts.push('FILTER(' + q.filters.map((f) => {
                const k = nm(f.key);
                if (f.op === 'empty') return `${k} empty`;
                if (f.op === 'nempty') return `${k} notempty`;
                if (f.op === 'between') return `${k} between ${f.v} ${f.v2}`;
                if (f.op === 'has') return `${k} contains ${f.v}`;
                const q = (x) => (/\s/.test(String(x)) ? `[${x}]` : x);   // з пробілом — у дужках
                const v = (f.vals && f.vals.length) ? f.vals.map(q).join(' or ') : q(f.v);
                return `${k}${OP_SIGN[f.op] || '='}${v}`;
            }).join(' ') + ')');
        }
        const view = [];
        if (q.rownum) view.push('no');
        q.groups.forEach((k) => view.push(`groupby ${nm(k)}`));
        q.sorts.forEach((sx) => view.push(`sort ${nm(sx.key)}${sx.dir === 'desc' ? ' desc' : ''}`));
        (q.aggs || []).forEach((a) => view.push(a.key ? `${a.fn} ${nm(a.key)}` : a.fn));
        if (view.length) parts.push(`VIEW(${view.join(' ')})`);
        return parts.length ? '=' + parts.join(' ') : '';
    }

    /* Кольорова підсвітка рядка формули — одна для «Роботи зі стадом»,
       «Списків», «Огляду» і Календаря (Роман 2026-09-19). Класи:
       k — дія, w — службове слово, p — параметр, o — умова, n — значення,
       b — дужки й розділові. */
    const ACT_RE = /^(body|filter|view|тіло|фільтрація|фільтр|відображення|вигляд|показати|колонки|де|sort|group|groupby)$/i;
    const WORD_RE = /^(groupby|sort|no|num|cnt|count|avg|sum|min|max|desc|asc|кількість|середнє|сума|мін|макс|групувати|групи|сортувати|порядок|нумерація|номер|спад|зрост|між|містить|порожньо|не|або|between|and|contains|empty|notempty|not|or)$/i;
    const hEsc = (t) => String(t).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    function highlight(txt, params) {
        const ps = params || [];
        const short = (p) => ((p.short || p.key || '').trim() || p.label || '').toLowerCase();
        const isP = (w) => {
            const x = String(w).trim().toLowerCase();
            return ps.some((p) => short(p) === x || (p.label || '').toLowerCase() === x);
        };
        const src = String(txt || '');
        // назва може містити «/» і «.» (milk/lkd); значення з пробілом — у [дужках]
        const re = /([A-Za-zА-Яа-яЇїІіЄєҐґ_][A-Za-zА-Яа-яЇїІіЄєҐґ_\d.\-]*(?:\/[A-Za-zА-Яа-яЇїІіЄєҐґ_\d.\-]+)*)|(\d+[.,]?\d*)|(>=|<=|<>|!=|≠|≥|≤|=|>|<)|(\[[^\]]*\]?)|([()\];,])|(\s+)|(.)/g;
        let out = '', m;
        while ((m = re.exec(src))) {
            const t = m[0], e = hEsc(t);
            if (m[1]) {
                if (ACT_RE.test(t) && src.slice(re.lastIndex).trimStart().startsWith('(')) out += `<span class="k">${e}</span>`;
                else if (WORD_RE.test(t)) out += `<span class="w">${e}</span>`;
                else out += `<span class="${isP(t) ? 'p' : 'n'}">${e}</span>`;
            } else if (m[2]) out += `<span class="n">${e}</span>`;
            else if (m[3]) out += `<span class="o">${e}</span>`;
            else if (m[4]) out += `<span class="${isP(t.replace(/^\[|\]$/g, '')) ? 'p' : 'n'}">${e}</span>`;
            else if (m[5]) out += `<span class="b">${e}</span>`;
            else out += e;
        }
        return out;
    }

    window.herdQuery = { parse, passes, sortRows, findParam, valOf, labOf, isFormula, format, highlight };
}());
