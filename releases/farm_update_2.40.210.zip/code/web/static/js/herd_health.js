/* ЗДОРОВ’Я СТАДА — ВАКЦИНАЦІЯ (Роман 2026-10-01: «окремий блок вакцинація тварин — прописувати схему вакцинації й
   впроваджувати в списки» → обрав: строк кроку — від віку чи від події; проведено — подія й тварина зникає зі списку;
   аптеку поки не списуємо).
   📌 Крок — ЛИШЕ РЯДОК ФОРМУЛИ (Роман 2026-10-01: «всі дані фільтрація від строки формул… прибрати від чого рахувати;
      залишити крок, препарат, доза, активний/неактивний; кроки перетягувати вверх-вниз»): клік по кроку — його FILTER(…)
      у стандартному рядку формули під пошуком тварини, Enter — записати. У рядку кроку: ⠿ (тягнути) · назва · препарат ·
      доза · формула (тихо) · активний / неактивний · ✕. Схема — лише назва й кроки.
   📌 Хто кому вже зроблено — подія «Вакцинація» з полем __vstep «схема:крок» (сервер: /api/herd/vacc → done).
   📌 Кому час — рахуємо тут, на живих тваринах: «зараз» (у вікні), «прострочено» (до 30 днів по вікну), «скоро» (до 14
      днів до вікна). «Провести» — груповий запис події тим, кого відмічено. */
'use strict';
(function () {
const $ = (id) => document.getElementById(id);
if (!$('hhSchemes')) return;

let PARAMS = [], SCHEMES = [], EVENT = null, ANIMALS = [];
let SEL = '';                                         // схема, чия умова «Кого» — у рядку формули вгорі
const OPEN = new Set();                              // розгорнуті кроки (до першого рендера — усі, де є «зараз»)
let FIRST = true;

const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const parseD = (s) => {
    const m = String(s || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
};
const addD = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const diff = (a, b) => Math.round((a - b) / 86400000);
const dm = (d) => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
const dmy = (d) => `${dm(d)}.${d.getFullYear()}`;
const sk = (sc, st) => `${sc.id}:${st.id}`;
const WD = ['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'нд'];

/* ---------- хто кому час ---------- */
/* рахунок — спільний із мовою списків (herd_vacc.js): одна схема — одні числа скрізь */
const V = window.herdVacc;
const whoQ = (sc) => V.whoQ(sc);
const needKeys = () => V.deps();
const stateOf = (a, sc, st, t0) => V.stateOf(a, sc, st, t0);
function computeDue() {
    const t0 = today();
    const out = [];
    SCHEMES.forEach((sc) => {
        if (!sc.steps.some((st) => !st.off)) return;
        const q = whoQ(sc);
        const whoAll = q.error ? [] : ANIMALS.filter((a) => window.herdQuery.passes(a, q.filters));
        sc.steps.forEach((st) => {
            if (st.off) return;                       // неактивний крок — не рахується
            const who = st.fx ? ANIMALS : whoAll;     // крок-формула сам каже, кого брати
            const rows = [];
            const day = V.dayOf(st, t0);             // найближчий день проведення кроку
            who.forEach((a) => { const s = stateOf(a, sc, st, day); if (s) rows.push(Object.assign({ a }, s)); });
            if (!rows.length) return;
            const rank = { late: 0, now: 1, soon: 2 };
            rows.sort((p, r) => rank[p.st] - rank[r.st] || String(p.a.tag).localeCompare(String(r.a.tag), 'uk', { numeric: true }));
            out.push({ sc, st, rows, day });
        });
    });
    return out;
}

/* ---------- «До вакцинації» ----------
   Крок розкривається на три рівні (Роман 2026-10-01): прострочено · зараз · скоро; кожен рівень розкривається окремо
   на перелік тварин. «Скоро» — підійде протягом SOON днів (перемикач 7 · 14 · 30 у шапці), «прострочено» — вікно минуло
   не більше 30 · 60 · 90 днів тому (перемикач «прострочено — за»). Вибір тварин для «Провести» — PICK (за замовчуванням лише «зараз»), живе поза розміткою,
   тож згорнутий рівень вибору не губить. */
const LV = [
    { k: 'late', t: 'Прострочено' },
    { k: 'now', t: 'Зараз' },
    { k: 'soon', t: 'Скоро' },
];
const LV_OPEN = new Set();                           // розкриті рівні: «схема:крок|late»
const PICK = new Map();                              // крок → Set(id тварин) для «Провести»
const SOON_OPTS = [7, 14, 30];
const wdm = (d) => `${WD[V.wdOf(d) - 1]} ${dm(d)}`;
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; return m10 === 1 && m100 !== 11 ? a : (m10 >= 2 && m10 <= 4 && !(m100 >= 12 && m100 <= 14) ? b : c); };
const dn = (n) => `${n} ${plural(n, 'день', 'дні', 'днів')}`;
/* межі кроку з формули — діапазон днів життя (чи іншого лічильника) для рівня (Роман 2026-10-01: «скоро — інший діапазон»):
   скоро — [від − межа «скоро»; від − 1], прострочено — [до + 1; до + межа «прострочено»] */
function lvRange(k, g) {
    const c = V.counterOf({ p: {} }, g.st).find((x) => x.t === 'd' && (x.lo !== null || x.hi !== null));
    if (!c) return '';
    const life = /житт/i.test(c.label);
    const fmt = (a, b) => (life ? `${a}–${b}-й день життя` : `${c.label} ${a}–${b}`);
    if (k === 'now' && c.lo !== null && c.hi !== null) return fmt(c.lo, c.hi);
    if (k === 'soon' && c.lo !== null) return fmt(Math.max(0, c.lo - V.soon()), c.lo - 1);
    if (k === 'late' && c.hi !== null) return fmt(c.hi + 1, c.hi + V.late());
    return '';
}
function lvNote(k, rows, g) {                        // що означає рівень і наскільки
    const rng = lvRange(k, g);
    const d0 = parseD(g.st.start || g.sc.start);
    const head = rng ? rng + ' · ' : '';
    if (k === 'late') return `${head}минуло до ${dn(V.late())}` + (d0 ? ` · не раніше «діє з» ${dmy(d0)}` : '');
    if (k === 'soon') return `${head}до кроку до ${dn(V.soon())}`;
    return `${head}колоти зараз`;
}
/* вік тварини і межі кроку: «52-й день життя · колоти на 49–55-й»; без лічильника днів у формулі — дати */
function ageText(r, g) {
    const cs = V.counterOf(r.a, g.st).filter((c) => c.now !== null && (c.lo !== null || c.hi !== null));
    if (!cs.length) return `з ${wdm(r.w1)} по ${wdm(r.w2)}`;
    return cs.map((c) => {
        const rng = c.lo !== null && c.hi !== null ? (c.lo === c.hi ? `${c.lo}` : `${c.lo}–${c.hi}`)
            : (c.lo !== null ? `від ${c.lo}` : `до ${c.hi}`);
        if (c.t === 'm') return `${c.now} міс. · колоти у ${rng} міс.`;
        if (/житт/i.test(c.label)) return `${c.now}-й день життя · колоти на ${rng}-й`;
        return `${c.label} ${c.now} · колоти при ${rng}`;
    }).join('; ');
}
function rowWhen(r, g) {
    const age = escapeHtml(ageText(r, g));
    if (r.st === 'soon') return `<b>через ${dn(r.n)}</b> · ${age}`;
    if (r.st === 'late') return `<b>${dn(r.n)} тому</b> · ${age}`;
    return age;
}
/* «ДО ВАКЦИНАЦІЇ» — У САМИХ КРОКАХ СХЕМИ (Роман 2026-10-01: «об’єднати до вакцинації і схеми: крок Хіпра 1 розкрити вниз
   і побачити, що прострочено, що зараз і що скоро»). У рядку кроку — числа (клік розкриває), під ним — рівні з тваринами
   й «Провести». DUE: ключ кроку → { g, by, pk }; paintDue перемальовує лише ці клітинки й рядки, поля кроку не чіпає. */
let DUE = new Map();
function renderDue() {
    V.setSchemes(SCHEMES);                         // правки схеми — одразу в спільному рахунку
    DUE = new Map();
    if (!SCHEMES.length) { $('hhSum').textContent = ''; paintDue(); return; }
    if (SCHEMES.every((sc) => sc.steps.every((st) => st.off))) {
        $('hhSum').textContent = 'усі кроки неактивні';
        scCountsPaint([]);
        paintDue();
        return;
    }
    const list = computeDue();
    scCountsPaint(list);
    let now = 0, late = 0, soon = 0;
    list.forEach((g) => g.rows.forEach((r) => { if (r.st === 'now') now++; else if (r.st === 'late') late++; else soon++; }));
    $('hhSum').innerHTML = list.length
        ? `зараз <b>${now}</b>` + (late ? ` · прострочено <b>${late}</b>` : '') + (soon ? ` · скоро ${soon}` : '')
        : 'нікому — усе зроблено';
    if (FIRST) { list.forEach((g) => { if (g.rows.some((r) => r.st !== 'soon')) OPEN.add(sk(g.sc, g.st)); }); FIRST = false; }
    const tagCmp = (p, r) => String(p.a.tag).localeCompare(String(r.a.tag), 'uk', { numeric: true });
    list.forEach((g) => {
        const key = sk(g.sc, g.st);
        // вибір «Провести»: за замовчуванням лише «зараз» (прострочених могли колоти без запису — їх відмічають свідомо);
        // тварини, що вже не в переліку, з вибору випадають
        const ids = new Set(g.rows.map((r) => r.a.id));
        if (!PICK.has(key)) PICK.set(key, new Set(g.rows.filter((r) => r.st === 'now').map((r) => r.a.id)));
        const pk = PICK.get(key);
        [...pk].forEach((id) => { if (!ids.has(id)) pk.delete(id); });
        const by = { late: [], now: [], soon: [] };
        g.rows.forEach((r) => by[r.st].push(r));
        by.late.sort((p, r) => r.n - p.n || tagCmp(p, r));     // найдавніше прострочені — першими
        by.now.sort(tagCmp);
        by.soon.sort((p, r) => p.n - r.n || tagCmp(p, r));     // найближчі — першими
        DUE.set(key, { g, by, pk });
    });
    paintDue();
}
/* клітинка кроку: шеврон + «5 зараз · 6 скоро»; нікому — «—» */
function dueCellHtml(key, off) {
    if (off) return '<span class="hh-due0">неактивний</span>';
    const d = DUE.get(key);
    if (!d) return '<span class="hh-due0">нікому</span>';
    const pills = LV.map((l) => [l.k, d.by[l.k].length, l.t.toLowerCase()]).filter((p) => p[1])
        .map((p) => `<span class="hh-pill ${p[0]}" title="${p[1]} ${p[2]}">${p[1]}</span>`).join('');   // лише числа: колір каже, що це
    return `<span class="hh-chev">${OPEN.has(key) ? '▾' : '▸'}</span><span class="cnt">${pills}</span>`;
}
function dueRowHtml(key) {
    const d = DUE.get(key);
    if (!d || !OPEN.has(key)) return '';
    const { g, by, pk } = d;
    const lvHtml = (l) => {
        const rows = by[l.k];
        const lk = `${key}|${l.k}`;
        const lopen = LV_OPEN.has(lk);
        const nPick = rows.filter((r) => pk.has(r.a.id)).length;
        const all = rows.length && nPick === rows.length;
        return `<div class="hh-lv ${l.k}${rows.length ? '' : ' is-empty'}" data-lv="${escapeHtml(lk)}">
            <div class="hh-lvh"${rows.length ? ' data-lvtog' : ''}>
                <span class="hh-chev">${rows.length ? (lopen ? '▾' : '▸') : ''}</span>
                <span class="hh-lvt">${l.t}</span><span class="hh-pill ${l.k}">${rows.length}</span>
                <span class="hh-lvn">${escapeHtml((rows.length ? '' : 'нікого · ') + lvNote(l.k, rows, g))}</span>
                ${rows.length ? `<label class="hh-lvall" title="Відмітити всіх цього рівня для «Провести»"><input type="checkbox" data-all="${l.k}"${all ? ' checked' : ''}> ${nPick ? `вибрано ${nPick}` : 'вибрати'}</label>` : ''}
            </div>
            ${lopen && rows.length ? `<table class="hh-tbl"><thead><tr><th class="ck"></th><th>Номер</th><th class="hide-sm">Кличка</th><th>Вік і межі кроку</th></tr></thead><tbody>
                ${rows.map((r) => `<tr><td class="ck"><input type="checkbox" data-id="${r.a.id}"${pk.has(r.a.id) ? ' checked' : ''}></td>
                    <td><a href="/herd/animals/${r.a.id}">${escapeHtml(r.a.tag || '')}</a></td>
                    <td class="hide-sm">${escapeHtml(r.a.name || '')}</td>
                    <td class="hh-when ${r.st}">${rowWhen(r, g)}</td></tr>`).join('')}
                </tbody></table>` : ''}
        </div>`;
    };
    return `<tr class="hh-xrow" data-xk="${escapeHtml(key)}"><td colspan="11"><div class="hh-xin">
        <div class="hh-xh">
            <button type="button" class="btn btn-primary btn-sm" data-go="${escapeHtml(key)}"${pk.size ? '' : ' disabled'}>Провести · <span data-n>${pk.size}</span></button>
            ${(g.st.days || []).length ? `<span class="hh-day" title="Найближчий день проведення кроку">на ${wdm(g.day)}</span>` : ''}
            <span class="hh-xn">${escapeHtml([g.st.drug, g.st.dose].filter(Boolean).join(' · '))}</span>
        </div>
        <div class="hh-lvs">${LV.map(lvHtml).join('')}</div>
    </div></td></tr>`;
}
function paintDue() {
    document.querySelectorAll('#hhSchemes tr[data-st]').forEach((tr) => {
        const sc = SCHEMES.find((x) => x.id === tr.closest('[data-sc]').dataset.sc);
        const st = sc && sc.steps.find((x) => x.id === tr.dataset.st);
        if (!st) return;
        const key = sk(sc, st);
        const cell = tr.querySelector('.hh-duec');
        if (cell) {
            cell.innerHTML = dueCellHtml(key, st.off);
            cell.classList.toggle('is-tog', DUE.has(key));
        }
        const nx = tr.nextElementSibling;
        if (nx && nx.classList.contains('hh-xrow')) nx.remove();
        const h = dueRowHtml(key);
        if (h) tr.insertAdjacentHTML('afterend', h);
    });
}
const LATE_OPTS = [30, 60, 90];
function renderSoonSeg() {
    const el = $('hhSoon');
    if (el) el.innerHTML = SOON_OPTS.map((n) => `<button type="button" class="seg-btn${V.soon() === n ? ' is-active' : ''}" data-soon="${n}">${n} дн.</button>`).join('');
    const el2 = $('hhLate');
    if (el2) el2.innerHTML = LATE_OPTS.map((n) => `<button type="button" class="seg-btn${V.late() === n ? ' is-active' : ''}" data-late="${n}">${n} дн.</button>`).join('');
}
$('hhLate') && $('hhLate').addEventListener('click', (e) => {
    const b = e.target.closest('[data-late]');
    if (!b) return;
    saveCfg({ late: +b.dataset.late });
});
/* межі — для всієї ферми (Роман 2026-10-01): одразу рахуємо тут, записуємо на сервер; не записалось — назад */
async function saveCfg(ch) {
    const was = { soon: V.soon(), late: V.late() };
    if (ch.soon) V.setSoon(ch.soon);
    if (ch.late) V.setLate(ch.late);
    renderSoonSeg();
    renderDue();
    const r = await apiSend('/api/herd/vacc/cfg', 'POST', ch).catch(() => null);
    if (!r || r.ok === false) {
        V.setSoon(was.soon); V.setLate(was.late);
        renderSoonSeg();
        renderDue();
        toast((r && r.error) || 'Межу не збережено', 'error');
        return;
    }
    // пам’ять herd_vacc (з неї стартують списки й Календар) — з новими межами
    try { const m = JSON.parse(localStorage.getItem('herd:vacc') || 'null'); if (m) { m.cfg = r.cfg; localStorage.setItem('herd:vacc', JSON.stringify(m)); } } catch (e) { /* ignore */ }
}
$('hhSoon') && $('hhSoon').addEventListener('click', (e) => {
    const b = e.target.closest('[data-soon]');
    if (!b) return;
    saveCfg({ soon: +b.dataset.soon });
});
/* клік у розкритому кроці: «Провести», рівень, позначки */
async function dueClick(e) {
    const x = e.target.closest('.hh-xrow');
    const d = x && DUE.get(x.dataset.xk);
    if (!d) return;
    const go = e.target.closest('[data-go]');
    if (go) { conduct(d.g, [...d.pk]); return; }
    if (e.target.closest('input, a, label')) return;
    const lv = e.target.closest('[data-lvtog]');
    if (lv) {
        const lk = lv.closest('[data-lv]').dataset.lv;
        if (LV_OPEN.has(lk)) LV_OPEN.delete(lk); else LV_OPEN.add(lk);
        paintDue();
    }
}
function dueChange(e) {
    const x = e.target.closest('.hh-xrow');
    const d = x && DUE.get(x.dataset.xk);
    if (!d) return;
    const { g, pk } = d;
    if (e.target.matches('[data-all]')) {
        const lvk = e.target.dataset.all;
        g.rows.filter((r) => r.st === lvk).forEach((r) => { if (e.target.checked) pk.add(r.a.id); else pk.delete(r.a.id); });
    } else if (e.target.matches('[data-id]')) {
        if (e.target.checked) pk.add(+e.target.dataset.id); else pk.delete(+e.target.dataset.id);
    } else return;
    paintDue();
}

let BUSY = false;
async function conduct(g, ids) {
    if (BUSY || !ids.length) return;
    if (!EVENT) { toast('Немає події «Вакцинація» — заведіть її в Конструкторі', 'error'); return; }
    const date = $('hhDate').value || iso(today());
    const drug = [g.st.drug, g.st.dose].filter(Boolean).join(' · ');
    const ok = await confirmAction(`Внести «${EVENT.name}»${drug ? ` (${drug})` : ''} — крок «${g.st.name}» — ${ids.length} `
        + `${ids.length === 1 ? 'тварині' : 'тваринам'} за ${dmy(parseD(date))}?`, { ok: 'Провести', okClass: 'btn-primary' });
    if (!ok) return;
    BUSY = true;
    try {
        const inputs = { __vstep: sk(g.sc, g.st) };
        if (EVENT.drug_key) inputs[EVENT.drug_key] = g.st.drug || g.st.name;
        const r = await apiSend('/api/herd/apply-event-bulk', 'POST', {
            animal_ids: ids, event_id: EVENT.id, event_date: date, inputs,
            note: [g.st.name, g.st.dose].filter(Boolean).join(' · '),
        });
        if (!r || r.ok === false) { toast((r && r.error) || 'Не вдалося провести', 'error'); return; }
        const bad = (r.failed || []).length, dup = (r.dupes || []).length;
        toast(`Проведено: ${r.applied || 0}` + (bad ? ` · не вдалося ${bad}: ${(r.failed || []).slice(0, 3).map((x) => `${x.tag} — ${x.error}`).join('; ')}` : '')
            + (dup ? ` · ${dup} уже мали цю подію щойно` : ''), bad ? 'error' : 'success');
        PICK.delete(sk(g.sc, g.st));                // проведених уже немає в переліку — вибір знову за замовчуванням
        await loadDone();
        renderDue();
        renderHist();
    } finally { BUSY = false; }
}

/* ---------- «Проведені вакцинації»: одне проведення (день · крок чи препарат) — рядок; 15 останніх ---------- */
const HIST_OPEN = new Set();
function renderHist() {
    const byId = new Map(ANIMALS.map((a) => [a.id, a]));
    const groups = new Map();
    V.done().forEach((ev) => {
        const a = byId.get(ev.a);
        if (!a) return;
        const so = V.stepOf(a, ev);
        const key = `${ev.d}|${so ? sk(so.sc, so.st) : 'g:' + (ev.g || '')}`;
        if (!groups.has(key)) groups.set(key, { d: ev.d, so, g: ev.g, rows: [] });
        groups.get(key).rows.push(a);
    });
    const list = [...groups.values()].sort((x, y) => (x.d < y.d ? 1 : x.d > y.d ? -1 : 0));
    const total = list.reduce((t, g) => t + g.rows.length, 0);
    $('hhHistSum').textContent = list.length ? `${total} гол. · ${list.length} ${(list.length % 10 >= 1 && list.length % 10 <= 4 && !(list.length % 100 >= 11 && list.length % 100 <= 14)) ? 'проведення' : 'проведень'}` : '';
    if (!list.length) { $('hhHist').innerHTML = '<div class="hh-empty">Ще нічого не проведено.</div>'; return; }
    const shown = list.slice(0, 15);
    $('hhHist').innerHTML = `<table><thead><tr><th>Дата</th><th>Крок</th><th>Препарат</th><th class="hide-sm">Схема</th><th class="num">Голів</th></tr></thead><tbody>`
        + shown.map((g) => {
            const key = `${g.d}|${g.so ? sk(g.so.sc, g.so.st) : g.g}`;
            const open = HIST_OPEN.has(key);
            const drug = g.so ? [g.so.st.drug, g.so.st.dose].filter(Boolean).join(' · ') : (g.g || '');
            const tags = g.rows.slice().sort((x, y) => String(x.tag).localeCompare(String(y.tag), 'uk', { numeric: true }));
            return `<tr class="hh-hr" data-h="${escapeHtml(key)}"><td>${dmy(parseD(g.d))}</td>
                <td>${g.so ? `<b>${escapeHtml(g.so.st.name)}</b>` : '<span class="mute">поза схемою</span>'}</td>
                <td>${escapeHtml(drug)}</td><td class="hide-sm mute">${g.so ? escapeHtml(g.so.sc.name) : ''}</td>
                <td class="num">${g.rows.length} ${open ? '▾' : '▸'}</td></tr>`
                + (open ? `<tr><td colspan="5" class="tags">${tags.map((a) => `<a href="/herd/animals/${a.id}" title="${escapeHtml(a.name || '')}">${escapeHtml(a.tag || '')}</a>`).join('')}</td></tr>` : '');
        }).join('') + '</tbody></table>'
        + (list.length > 15 ? `<div class="hh-empty">Показано 15 останніх із ${list.length}.</div>` : '');
}
$('hhHist').addEventListener('click', (e) => {
    const tr = e.target.closest('tr.hh-hr');
    if (!tr) return;
    if (HIST_OPEN.has(tr.dataset.h)) HIST_OPEN.delete(tr.dataset.h); else HIST_OPEN.add(tr.dataset.h);
    renderHist();
});

/* ---------- схеми: назва + кроки; крок — рядок формули ---------- */
const stStart = (sc, st) => st.start || sc.start || '';        // «діє з» кроку; давні — дата схеми
/* ЧИ Є КРОК У СПИСКАХ (Роман 2026-10-01): списки «Роботи зі стадом», що беруть крок словом vacc / vacc_soon / vacc_late */
let WLISTS = null;                                   // null — ще не прочитали
const reEsc = (t) => String(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function listsOf(st) {
    const nm = String(st.name || '').trim();
    if (!nm || !WLISTS) return [];
    const re = new RegExp(`\\bvacc(?:_late|_soon)?\\s*=\\s*(?:\\[\\s*${reEsc(nm)}\\s*\\]|${reEsc(nm)}(?![\\w\\d]))`, 'i');
    const all = /\bvacc(?:_late|_soon)?\s+(?:notempty|not\s+empty|не\s+порожн)/i;    // «vacc notempty» — усі кроки
    return WLISTS.filter((L) => re.test(String(L.formula || '')) || all.test(String(L.formula || ''))).map((L) => L.name);
}
function inListsHtml(st) {
    if (!WLISTS) return '';
    const ls = listsOf(st);
    return ls.length
        ? `<button type="button" class="hh-inl is-on" data-inl title="Є в списках «Роботи зі стадом»: ${escapeHtml(ls.join(', '))}">☰ ✓</button>`
        : `<button type="button" class="hh-inl" data-inl title="Цього кроку немає в жодному списку «Роботи зі стадом» — клацніть, щоб перенести">☰ +</button>`;
}
async function loadWLists() {
    const r = await apiGet('/api/herd/work-lists').catch(() => null);
    if (r && r.ok !== false) { WLISTS = r.lists || []; renderSchemes(); }
}
function stepRow(sc, st) {
    const key = sk(sc, st);
    const q = st.fx ? V.stepQ(st) : null;
    const fxt = st.fx || '— клацніть і впишіть FILTER(…) у рядку формули вгорі';
    return `<tr data-st="${escapeHtml(st.id)}" class="${st.off ? 'is-off' : ''}${key === SEL ? ' is-sel' : ''}">
        <td class="hh-grip" title="Тягніть, щоб переставити крок">⠿</td>
        <td class="hh-namec"><input class="hh-in w-sn" data-f="name" value="${escapeHtml(st.name || '')}" placeholder="Хіпра 1" maxlength="40">${inListsHtml(st)}</td>
        <td class="hh-duec" title="Кому час за цим кроком — клацніть, щоб розкрити: прострочено · зараз · скоро"></td>
        <td><input class="hh-in w-drug" data-f="drug" value="${escapeHtml(st.drug || '')}" placeholder="Хіпрабовіс 4" maxlength="60"></td>
        <td><input class="hh-in w-dose" data-f="dose" value="${escapeHtml(st.dose || '')}" placeholder="3 мл" maxlength="20"></td>
        <td class="hh-remc" title="Ремарка складається сама: число з кінця назви кроку · препарат · доза — так її покаже список у «Примітці»"><span>${escapeHtml(V.remOf(sc, st))}</span></td>
        <td class="hh-days" title="Дні проведення кроку; жодного — щодня"><span class="hh-dbox">${WD.map((w, i) => `<button type="button" data-wd="${i + 1}" class="${(st.days || []).includes(i + 1) ? 'is-on' : ''}">${w}</button>`).join('')}</span></td>
        <td><input type="date" class="hh-in w-start" data-f="start" value="${escapeHtml(stStart(sc, st))}" max="${iso(today())}"
            title="Діє з: прострочка кроку рахується від цієї дати — межі, що минули раніше, не прострочка"></td>
        <td class="hh-fxc${q && q.error ? ' is-bad' : ''}${st.fx ? '' : ' is-empty'}" title="${escapeHtml(q && q.error ? q.error : 'Формула кроку — клацніть, і вона відкриється в рядку формули вгорі')}"><span class="hh-fxbox">${escapeHtml(fxt)}</span></td>
        <td><button type="button" class="hh-act${st.off ? '' : ' is-on'}" data-act title="Неактивний крок у «До вакцинації» і в vacc не рахується">${st.off ? 'неактивний' : 'активний'}</button></td>
        <td><button type="button" class="hh-x" data-delst title="Прибрати крок">✕</button></td></tr>`;
}
/* окрема схема згортається (Роман 2026-10-01): шеврон або клік по вільному місцю шапки; стан у браузері */
const SC_FOLD_KEY = 'herd:health_scfold';
let SC_FOLD = {};
try { SC_FOLD = JSON.parse(localStorage.getItem(SC_FOLD_KEY) || '{}') || {}; } catch (e) { SC_FOLD = {}; }
function scFoldSet(id, on) {
    if (on) SC_FOLD[id] = 1; else delete SC_FOLD[id];
    const el = document.querySelector(`#hhSchemes [data-sc="${CSS.escape(id)}"]`);
    if (el) el.classList.toggle('is-fold', !!on);
}
function scFoldSave() {
    try { localStorage.setItem(SC_FOLD_KEY, JSON.stringify(SC_FOLD)); } catch (e) { /* ignore */ }
    scFoldAllPaint();
}
function scFoldToggle(id) { scFoldSet(id, !SC_FOLD[id]); scFoldSave(); }
/* «згорнути всі / розгорнути всі» у шапці «Схем вакцинації»: текст — за тим, чи є хоч одна розгорнута */
function scFoldAllPaint() {
    const b = $('hhFoldAll');
    if (!b) return;
    b.hidden = SCHEMES.length < 2;
    b.textContent = SCHEMES.some((sc) => !SC_FOLD[sc.id]) ? 'згорнути всі' : 'розгорнути всі';
}
$('hhFoldAll') && $('hhFoldAll').addEventListener('click', () => {
    const on = SCHEMES.some((sc) => !SC_FOLD[sc.id]);
    SCHEMES.forEach((sc) => scFoldSet(sc.id, on));
    scFoldSave();
});
/* числа «До вакцинації» по схемі — у шапці ЗГОРНУТОЇ схеми (Роман 2026-10-01): зараз · прострочено · скоро */
const SC_CNT = new Map();
let SC_CNT_READY = false;
const scCntHtml = (id) => {
    const c = SC_CNT.get(id);
    if (!c) return SC_CNT_READY ? '<span class="hh-scnt-0">нікому</span>' : '';
    return (c.now ? `<span class="hh-pill now">${c.now} зараз</span>` : '')
        + (c.late ? `<span class="hh-pill late">${c.late} прострочено</span>` : '')
        + (c.soon ? `<span class="hh-pill soon">${c.soon} скоро</span>` : '')
        || '<span class="hh-scnt-0">нікому</span>';
};
function scCountsPaint(list) {
    SC_CNT.clear();
    SC_CNT_READY = true;
    list.forEach((g) => {
        const c = SC_CNT.get(g.sc.id) || { now: 0, late: 0, soon: 0 };
        g.rows.forEach((r) => { c[r.st === 'now' ? 'now' : r.st === 'late' ? 'late' : 'soon'] += 1; });
        SC_CNT.set(g.sc.id, c);
    });
    document.querySelectorAll('#hhSchemes .hh-sch[data-sc]').forEach((el) => {
        const box = el.querySelector('.hh-scnt');
        if (box) box.innerHTML = scCntHtml(el.dataset.sc);
    });
}
function renderSchemes() {
    const box = $('hhSchemes');
    if (!SCHEMES.length) { box.innerHTML = '<div class="hh-empty">Натисніть «+ схема»: назва і кроки — препарат, доза й формула, кому.</div>'; return; }
    box.innerHTML = SCHEMES.map((sc) => `<div class="hh-sch${SC_FOLD[sc.id] ? ' is-fold' : ''}" data-sc="${escapeHtml(sc.id)}">
        <div class="hh-sch-head" title="Клацніть вільне місце шапки, щоб згорнути або розгорнути схему">
            <button type="button" class="hh-fold" data-scfold aria-label="Згорнути / розгорнути схему"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>
            <span class="hh-grip" data-sgrip title="Тягніть, щоб переставити схему">⠿</span>
            <input class="hh-in w-name" data-sf="name" value="${escapeHtml(sc.name || '')}" placeholder="Назва схеми" maxlength="60">
            <span class="hh-wn">${sc.steps.length} ${sc.steps.length === 1 ? 'крок' : (sc.steps.length % 10 >= 2 && sc.steps.length % 10 <= 4 && !(sc.steps.length % 100 >= 12 && sc.steps.length % 100 <= 14)) ? 'кроки' : 'кроків'}</span>
            <span class="hh-scnt">${scCntHtml(sc.id)}</span>
            <button type="button" class="hh-link" data-addst>+ крок</button>
            <button type="button" class="hh-x" data-delsc title="Видалити схему">✕</button>
        </div>
        <table class="hh-steps"><thead><tr><th></th><th>Крок</th><th class="hh-dueh" title="Кому час: прострочено · зараз · скоро">Кому час</th><th>Препарат</th><th>Доза</th><th>Ремарка</th><th>Дні</th><th>Діє з</th><th class="hh-fxh" title="Кому крок — FILTER(…); клацніть клітинку, щоб правити в рядку формули вгорі">Формула</th><th></th><th></th></tr></thead>
            <tbody>${sc.steps.map((st) => stepRow(sc, st)).join('')}</tbody></table>
    </div>`).join('');
    scFoldAllPaint();
    renderDue();                        // числа й розкриті кроки — у щойно намальованих рядках
}
const scOf = (el) => SCHEMES.find((x) => x.id === el.closest('[data-sc]').dataset.sc);
const stOf = (sc, el) => sc.steps.find((x) => x.id === el.closest('[data-st]').dataset.st);

let SAVE_T = 0, SAVE_SEQ = 0;
function saveSoon() { clearTimeout(SAVE_T); $('hhSaved').textContent = 'зберігаю…'; $('hhSaved').classList.remove('is-bad'); SAVE_T = setTimeout(save, 500); }
async function save() {
    const my = ++SAVE_SEQ;
    SCHEMES.forEach((sc) => sc.steps.forEach((st) => { st.rem = V.remOf(sc, st); }));   // ремарка — з номера, препарату, дози
    const r = await apiSend('/api/herd/vacc/schemes', 'POST', { schemes: SCHEMES }).catch(() => null);
    if (my !== SAVE_SEQ) return;
    if (!r || r.ok === false) {
        $('hhSaved').textContent = '⚠ ' + ((r && r.error) || 'не збереглося');
        $('hhSaved').classList.add('is-bad');
        return;
    }
    // сервер дає id новим — беремо їх, решту лишаємо як є (фокус у полі не губимо)
    (r.schemes || []).forEach((s2, i) => {
        const s1 = SCHEMES[i];
        if (!s1) return;
        const was = SEL;
        if (s1.id !== s2.id) {
            const el = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"]`);
            if (SEL.startsWith(s1.id + ':')) SEL = s2.id + SEL.slice(s1.id.length);
            s1.id = s2.id;
            if (el) el.dataset.sc = s2.id;
        }
        (s2.steps || []).forEach((t2, j) => {
            const t1 = s1.steps[j];
            if (t1 && t1.id !== t2.id) {
                if (was === `${s1.id}:${t1.id}` || SEL === `${s1.id}:${t1.id}`) SEL = `${s1.id}:${t2.id}`;
                const tr = document.querySelector(`[data-sc="${CSS.escape(s1.id)}"] [data-st="${CSS.escape(t1.id)}"]`);
                t1.id = t2.id;
                if (tr) tr.dataset.st = t2.id;
            }
        });
    });
    $('hhSaved').textContent = 'збережено';
    setTimeout(() => { if (my === SAVE_SEQ && !$('hhSaved').classList.contains('is-bad')) $('hhSaved').textContent = ''; }, 1500);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderDue();
    renderHist();                                  // назви кроків у журналі — свіжі
}
let NID = 0;
const nid = (p) => p + Date.now().toString(36) + (++NID);
function newStep(sc) {
    const last = sc.steps[sc.steps.length - 1];
    return { id: nid('k'), name: `Крок ${sc.steps.length + 1}`, drug: last ? last.drug : '', rem: '', dose: last ? last.dose : '',
        off: 0, fx: last && last.fx ? last.fx : '', days: last && last.days ? last.days.slice() : [], start: iso(today()) };     // формулу попереднього — щоб лише поправити дні
}
function selectStep(sc, st, focusFx) {
    SEL = sk(sc, st);
    $('hhSchemes').querySelectorAll('tr[data-st]').forEach((tr) => {
        tr.classList.toggle('is-sel', `${tr.closest('[data-sc]').dataset.sc}:${tr.dataset.st}` === SEL);
    });
    fxRender();
    if (focusFx && FX) FX.focus();
}
$('hhAddScheme').addEventListener('click', () => {
    let name = 'Нова схема', i = 1;
    while (SCHEMES.some((s) => s.name === name)) name = `Нова схема ${++i}`;
    const sc = { id: nid('v'), name, who: '', off: 0, steps: [] };
    sc.steps.push(newStep(sc));
    SCHEMES.push(sc);
    SEL = sk(sc, sc.steps[0]);
    renderSchemes();
    fxRender();
    saveSoon();
    const els = document.querySelectorAll('#hhSchemes .w-name');
    const el = els[els.length - 1];
    if (el) { el.focus(); el.select(); }
});
$('hhSchemes').addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('.hh-xrow')) { await dueClick(e); return; }
    const dc = t.closest('.hh-duec.is-tog');
    if (dc) {                                         // числа кроку — розкрити / згорнути під ним
        const tr = dc.closest('tr[data-st]');
        const key = `${tr.closest('[data-sc]').dataset.sc}:${tr.dataset.st}`;
        if (OPEN.has(key)) OPEN.delete(key); else OPEN.add(key);
        paintDue();
        return;
    }
    const fh = t.closest('.hh-sch-head');
    if (t.closest('[data-scfold]') || (fh && (t === fh || t.closest('.hh-wn')))) { scFoldToggle(scOf(t).id); return; }
    if (t.closest('[data-addst]')) {
        const sc = scOf(t);
        const st = newStep(sc);
        sc.steps.push(st);
        SEL = sk(sc, st);
        renderSchemes();
        fxRender();
        saveSoon();
        if (FX) FX.focus();
        return;
    }
    if (t.closest('[data-delst]')) { await delStep(scOf(t), stOf(scOf(t), t)); return; }
    if (t.closest('[data-delsc]')) { await delScheme(scOf(t)); return; }
    if (t.closest('[data-wd]')) {                       // день проведення кроку
        const sc = scOf(t);
        const st = stOf(sc, t);
        const d = +t.closest('[data-wd]').dataset.wd;
        const ds = new Set(st.days || []);
        if (ds.has(d)) ds.delete(d); else ds.add(d);
        st.days = [...ds].sort();
        t.closest('[data-wd]').classList.toggle('is-on', ds.has(d));
        saveSoon();
        return;
    }
    if (t.closest('[data-inl]')) {                    // позначка «у списках / немає»: немає — перенести
        const sc = scOf(t);
        const st = stOf(sc, t);
        if (!t.closest('[data-inl]').classList.contains('is-on')) await toLists(sc, st);
        else toast(t.closest('[data-inl]').title, 'success');
        return;
    }
    if (t.closest('[data-act]')) {
        const sc = scOf(t);
        const st = stOf(sc, t);
        st.off = st.off ? 0 : 1;
        renderSchemes();
        saveSoon();
        return;
    }
    const tr = t.closest('tr[data-st]');
    if (tr && !t.closest('.hh-grip')) {                // клік по кроку — його формула в рядку вгорі
        const sc = scOf(t);
        selectStep(sc, stOf(sc, t), !!t.closest('.hh-fxc'));
    }
});
/* «Перенести в списки» (Роман 2026-10-01): список «Роботи зі стадом» з назвою кроку — кому зараз, «+» кому скоро, «!» прострочені;
   колонки — номер і лічильник кроку (днів життя…), ремарка кроку — у «Примітці» сама. Категорія — назва схеми, якщо така є.
   Список з такою назвою вже є — перепитуємо й оновлюємо лише його формулу */
async function toLists(sc, st) {
    const nm = String(st.name || '').trim();
    if (!nm) { toast('У кроку немає назви', 'error'); return; }
    if (!st.fx) { toast('У кроку ще немає формули — спершу впишіть FILTER(…)', 'error'); return; }
    // колонки — номер і лічильник кроку коротким ім’ям (days_life, а не службовий ключ)
    const keys = V.counterOf({ p: {} }, st).map((c) => { const p = PARAMS.find((x) => x.key === c.key); return (p && p.short) || c.key; });
    const v = `[${nm}]`;
    const flt = `FILTER(vacc=${v}) FILTER2([+] vacc_soon=${v}) FILTER3([!] vacc_late=${v})`;
    let formula = `BODY(id ${keys.join(' ')}) ${flt} VIEW(no)`.replace(/\s+\)/g, ')');
    const got = await apiGet('/api/herd/work-lists').catch(() => null);
    if (!got || got.ok === false) { toast('Не вдалося прочитати списки', 'error'); return; }
    const lists = got.lists || [];
    const cats = (got.categories || []).map((c) => (typeof c === 'string' ? c : c && c.name)).filter(Boolean);
    let L = lists.find((x) => String(x.name || '').trim().toLowerCase() === nm.toLowerCase());
    if (L) {
        // наявний список: його колонки (BODY) і вигляд (VIEW) лишаються — міняємо лише фільтри
        const body = (String(L.formula || '').match(/\bBODY\s*\([^)]*\)/i) || [])[0];
        const view = (String(L.formula || '').match(/\bVIEW\s*\([^)]*\)/i) || [])[0];
        if (body || view) formula = [body || `BODY(id ${keys.join(' ')})`.replace(/\s+\)/g, ')'), flt, view || 'VIEW(no)'].join(' ');
        if (window.herdQuery.canon(String(L.formula || '')) === window.herdQuery.canon(formula)) { toast(`Список «${nm}» уже такий`, 'success'); return; }
        if (!await confirmAction(`Список «${nm}» уже є. Оновити його формулу — зараз, «+» скоро, «!» прострочені?`, { ok: 'Оновити', okClass: 'btn-primary' })) return;
        L.formula = formula;
    } else {
        // категорія: як у списку іншого кроку цієї схеми; інакше — назва схеми, якщо така категорія є
        const sib = lists.find((x) => sc.steps.some((t) => t !== st && t.name && String(x.formula || '').includes(`vacc=[${t.name}]`)) && x.category);
        L = { id: 'w' + Date.now().toString(36), name: nm, formula, category: sib ? sib.category : (cats.includes(sc.name) ? sc.name : ''), note: '' };
        lists.push(L);
    }
    const r = await apiSend('/api/herd/work-lists', 'POST', { lists, revs: got.revs || {}, dirty: [L.id], deleted: [] }).catch(() => null);
    if (!r || r.ok === false) { toast((r && r.error) || 'Список не збережено', 'error'); return; }
    toast(`Список «${nm}» — у «Роботі зі стадом»`, 'success');
    loadWLists();
}
async function delStep(sc, st) {
    if (sc.steps.some((x) => x.base === 'step' && x.prev === st.id && !x.fx)) { toast('Від цього кроку рахується інший — спершу перепишіть той формулою', 'error'); return; }
    if (!await confirmAction(`Прибрати крок «${st.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Прибрати' })) return;
    sc.steps = sc.steps.filter((x) => x !== st);
    renderSchemes();
    fxRender();
    saveSoon();
}
function stepsChanged(sc, st, focusFx) {               // після дії меню: перемалювати, вибрати крок, зберегти
    SEL = sk(sc, st);
    renderSchemes();
    fxRender();
    saveSoon();
    if (focusFx && FX) FX.focus();
}
/* права кнопка по кроку (Роман 2026-10-01 «2»): ті самі дії, що й кнопки рядка, плюс дублювання й порядок */
$('hhSchemes').addEventListener('contextmenu', (e) => {
    const tr = e.target.closest('tr[data-st]');
    if (!tr || e.target.closest('input')) return;          // у полі — рідне меню (вставити, копіювати)
    e.preventDefault();
    const sc = scOf(tr);
    const st = stOf(sc, tr);
    if (!sc || !st) return;
    const i = sc.steps.indexOf(st);
    const move = (d) => { sc.steps.splice(i, 1); sc.steps.splice(i + d, 0, st); stepsChanged(sc, st); };
    selectStep(sc, st);
    ctxMenu(e.clientX, e.clientY, [
        { t: 'ƒ Правити формулу', fn: () => selectStep(sc, st, true) },
        { t: '⧉ Дублювати крок', fn: () => {
            const cp = JSON.parse(JSON.stringify(st));
            cp.id = nid('k');
            cp.start = iso(today());                 // новий крок — прострочка з сьогодні
            cp.name = dupName(st.name || 'Крок', (n) => sc.steps.some((x) => x.name === n));
            sc.steps.splice(i + 1, 0, cp);
            stepsChanged(sc, cp);
        } },
        { t: '+ Крок нижче', fn: () => {
            const nw = newStep(sc);
            Object.assign(nw, { drug: st.drug || '', dose: st.dose || '', fx: st.fx || '', days: (st.days || []).slice() });
            sc.steps.splice(i + 1, 0, nw);
            stepsChanged(sc, nw, true);
        } },
        'sep',
        ...(i > 0 ? [{ t: '↑ Вище', fn: () => move(-1) }] : []),
        ...(i < sc.steps.length - 1 ? [{ t: '↓ Нижче', fn: () => move(1) }] : []),
        { t: st.off ? '● Зробити активним' : '○ Зробити неактивним', fn: () => { st.off = st.off ? 0 : 1; stepsChanged(sc, st); } },
        { t: '☰ Перенести в списки', fn: () => toLists(sc, st) },
        ...(st.fx ? [{ t: '⧉ Копіювати формулу', fn: () => copyText(window.herdQuery.canon(st.fx)).then((ok) => toast(ok ? 'Формулу скопійовано' : 'Не вдалося скопіювати', ok ? '' : 'error')) }] : []),
        'sep',
        { t: '✕ Прибрати крок', del: true, fn: () => delStep(sc, st) },
    ]);
});
async function delScheme(sc) {
    if (!await confirmAction(`Видалити схему «${sc.name}»? Уже проведені вакцинації лишаються в картках тварин.`, { ok: 'Видалити' })) return;
    SCHEMES = SCHEMES.filter((x) => x !== sc);
    renderSchemes();
    fxRender();
    saveSoon();
}
const schemeEl = (sc) => document.querySelector(`#hhSchemes [data-sc="${CSS.escape(sc.id)}"]`);
/* права кнопка по шапці схеми (Роман 2026-10-01): перейменувати, + крок, дублювати, вище/нижче, усі кроки активні/неактивні, видалити */
$('hhSchemes').addEventListener('contextmenu', (e) => {
    const head = e.target.closest('.hh-sch-head');
    if (!head || e.target.closest('input')) return;       // у полі назви — рідне меню
    e.preventDefault();
    const sc = scOf(head);
    if (!sc) return;
    const i = SCHEMES.indexOf(sc);
    const redraw = (focus) => {
        renderSchemes();
        fxRender();
        saveSoon();
        const el = focus && schemeEl(focus);
        if (el) el.scrollIntoView({ block: 'nearest' });
    };
    const move = (d) => { SCHEMES.splice(i, 1); SCHEMES.splice(i + d, 0, sc); redraw(sc); };
    const allOff = sc.steps.length && sc.steps.every((st) => st.off);
    ctxMenu(e.clientX, e.clientY, [
        { t: '✎ Перейменувати', fn: () => { const el = schemeEl(sc); const inp = el && el.querySelector('[data-sf="name"]'); if (inp) { inp.focus(); inp.select(); } } },
        { t: '+ Крок', fn: () => { const st = newStep(sc); sc.steps.push(st); SEL = sk(sc, st); redraw(sc); if (FX) FX.focus(); } },
        { t: '⧉ Дублювати схему', fn: () => {
            const cp = JSON.parse(JSON.stringify(sc));
            cp.id = nid('v');
            cp.name = dupName(sc.name || 'Схема', (n) => SCHEMES.some((x) => x.name === n));
            cp.steps.forEach((st) => { st.id = nid('k'); st.start = iso(today()); });   // нова схема — прострочка з сьогодні
            SCHEMES.splice(i + 1, 0, cp);
            redraw(cp);
            const inp = schemeEl(cp) && schemeEl(cp).querySelector('[data-sf="name"]');
            if (inp) { inp.focus(); inp.select(); }
        } },
        'sep',
        ...(i > 0 ? [{ t: '↑ Вище', fn: () => move(-1) }] : []),
        ...(i < SCHEMES.length - 1 ? [{ t: '↓ Нижче', fn: () => move(1) }] : []),
        ...(sc.steps.length ? [{ t: allOff ? '● Усі кроки активні' : '○ Усі кроки неактивні',
            fn: () => { sc.steps.forEach((st) => { st.off = allOff ? 0 : 1; }); redraw(); } }] : []),
        'sep',
        { t: '✕ Видалити схему', del: true, fn: () => delScheme(sc) },
    ]);
});
$('hhSchemes').addEventListener('focusin', (e) => {
    const tr = e.target.closest('tr[data-st]');
    if (!tr) return;
    const sc = scOf(tr);
    if (`${sc.id}:${tr.dataset.st}` !== SEL) selectStep(sc, stOf(sc, tr), false);
});
$('hhSchemes').addEventListener('change', (e) => {
    const t = e.target;
    if (t.closest('.hh-xrow')) { dueChange(e); return; }
    const sc = scOf(t);
    if (!sc) return;
    if (t.dataset.sf) { sc[t.dataset.sf] = t.value.trim(); saveSoon(); return; }
    const tr = t.closest('[data-st]');
    if (!tr || !t.dataset.f) return;
    const st = stOf(sc, t);
    if (t.dataset.f === 'start') {                    // «діє з» кроку: порожньо не буває — повертаємо, що було
        if (!/^\d{4}-\d{2}-\d{2}$/.test(t.value)) { t.value = stStart(sc, st); return; }
        st.start = t.value;
        saveSoon();
        renderDue();                                  // прострочка кроку рахується від цієї дати
        return;
    }
    st[t.dataset.f] = t.value.trim();
    if (t.dataset.f === 'name') {
        fxRender();
        const b = tr.querySelector('[data-inl]');      // інша назва — інші списки
        if (b) b.outerHTML = inListsHtml(st);
    }
    saveSoon();
});
/* препарат чи доза набираються — ремарка в тому самому рядку міняється одразу (запишеться з виходом із поля) */
$('hhSchemes').addEventListener('input', (e) => {
    const t = e.target;
    if (!t.matches('[data-f="drug"], [data-f="dose"], [data-f="name"]')) return;   // номер ремарки — з кінця назви
    const tr = t.closest('tr[data-st]');
    const sc = tr && scOf(tr);
    const st = sc && stOf(sc, tr);
    if (!st) return;
    const cell = tr.querySelector('.hh-remc span');
    if (cell) cell.textContent = V.remOf(sc, Object.assign({}, st, { [t.dataset.f]: t.value.trim() }));
});
$('hhSchemes').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches('input.hh-in')) { e.preventDefault(); e.target.blur(); }
});

/* перетягування кроків угору-вниз за ⠿ (у межах своєї схеми) */
let DRAG = null, SDRAG = null;                    // крок у схемі · схема цілком
$('hhSchemes').addEventListener('mousedown', (e) => {
    const g = e.target.closest('.hh-grip');
    if (!g) return;
    if (g.dataset.sgrip !== undefined) g.closest('.hh-sch').draggable = true;
    else g.closest('tr').draggable = true;
});
$('hhSchemes').addEventListener('dragstart', (e) => {
    const box = e.target.closest && e.target.closest('.hh-sch');
    if (box && box === e.target && box.draggable) {      // схема — переставляємо цілком
        SDRAG = box.dataset.sc;
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', SDRAG); } catch (er) { /* ignore */ }
        box.classList.add('is-drag');
        return;
    }
    const tr = e.target.closest && e.target.closest('tr[data-st]');
    if (!tr || !tr.draggable) return;
    DRAG = { sc: tr.closest('[data-sc]').dataset.sc, st: tr.dataset.st };
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', DRAG.st); } catch (er) { /* ignore */ }
    tr.classList.add('is-drag');
});
const dropClear = () => $('hhSchemes').querySelectorAll('.drop-before, .drop-after').forEach((x) => x.classList.remove('drop-before', 'drop-after'));
$('hhSchemes').addEventListener('dragover', (e) => {
    if (SDRAG) {
        const box = e.target.closest('.hh-sch');
        if (!box) return;
        e.preventDefault();
        dropClear();
        const r = box.getBoundingClientRect();
        box.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
        return;
    }
    if (!DRAG) return;
    const tr = e.target.closest('tr[data-st]');
    if (!tr || tr.closest('[data-sc]').dataset.sc !== DRAG.sc) return;
    e.preventDefault();
    dropClear();
    const r = tr.getBoundingClientRect();
    tr.classList.add(e.clientY < r.top + r.height / 2 ? 'drop-before' : 'drop-after');
});
$('hhSchemes').addEventListener('drop', (e) => {
    if (SDRAG) {
        const box = e.target.closest('.hh-sch');
        if (!box) return;
        e.preventDefault();
        const moving = SCHEMES.find((x) => x.id === SDRAG);
        const target = SCHEMES.find((x) => x.id === box.dataset.sc);
        if (moving && target && moving !== target) {
            const after = box.classList.contains('drop-after');
            const rest = SCHEMES.filter((x) => x !== moving);
            rest.splice(rest.indexOf(target) + (after ? 1 : 0), 0, moving);
            SCHEMES = rest;
            renderSchemes();
            saveSoon();
        }
        return;
    }
    if (!DRAG) return;
    const tr = e.target.closest('tr[data-st]');
    if (!tr || tr.closest('[data-sc]').dataset.sc !== DRAG.sc) return;
    e.preventDefault();
    const sc = SCHEMES.find((x) => x.id === DRAG.sc);
    const after = tr.classList.contains('drop-after');
    const moving = sc.steps.find((x) => x.id === DRAG.st);
    const target = sc.steps.find((x) => x.id === tr.dataset.st);
    if (moving && target && moving !== target) {
        const rest = sc.steps.filter((x) => x !== moving);
        rest.splice(rest.indexOf(target) + (after ? 1 : 0), 0, moving);
        sc.steps = rest;
        renderSchemes();
        saveSoon();
    }
});
// натиснули ⠿ і відпустили без перетягування — рядок і схема знову звичайні (інакше поля в них тягнулись би)
document.addEventListener('mouseup', () => {
    if (DRAG || SDRAG) return;
    $('hhSchemes').querySelectorAll('[draggable="true"]').forEach((x) => { x.draggable = false; });
});
$('hhSchemes').addEventListener('dragend', () => {
    dropClear();
    $('hhSchemes').querySelectorAll('[draggable="true"]').forEach((x) => { x.draggable = false; x.classList.remove('is-drag'); });
    DRAG = null; SDRAG = null;
});

/* ---------- рядок формули вгорі: формула вибраного кроку ---------- */
let FX = null;
const FX_PH = 'FILTER(lact=0 rc<9 days_life between 49 55) — кому цей крок; Enter — записати';
const selPair = () => {
    for (const sc of SCHEMES) for (const st of sc.steps) if (sk(sc, st) === SEL) return { sc, st };
    return null;
};
function fxMsg(t, bad) { $('hhFxMsg').textContent = t || ''; $('hhFxMsg').classList.toggle('bad', !!bad); }
function fxShown(st) { return st.fx ? window.herdQuery.canon(st.fx) : ''; }
function fxRender() {
    if (!FX) {
        FX = herdFxEdit($('hhFx'), {
            params: () => PARAMS,
            groups: () => [...new Set(ANIMALS.map((a) => a.group_name).filter(Boolean))],
            acts: ['FILTER'],
            placeholder: FX_PH,
            onEnter: () => fxApply(),
            onInput: () => { $('hhFx').classList.remove('is-bad'); fxMsg(''); },
            // Esc (підказок немає) — формула кроку як була, нічого не зберігаємо
            onEscape: () => { fxRender(); FX.input.blur(); },
        });
        FX.input.addEventListener('blur', () => { const pr = selPair(); if (pr && FX.get().trim() !== fxShown(pr.st)) fxApply(); });
    }
    const pr = selPair();
    FX.input.disabled = !pr;
    FX.input.placeholder = pr ? FX_PH : 'Клацніть крок схеми — його формула відкриється тут';
    FX.set(pr ? fxShown(pr.st) : '');
    $('hhFx').classList.remove('is-bad');
    fxMsg('');                          // під рядком — лише помилка (Роман 2026-10-01: підпис «під формулу підходить N» прибрати)
}
async function fxApply() {
    const pr = selPair();
    if (!pr) return;
    let text = window.herdQuery.canon(FX.get());
    if (text && !/^FILTER\s*\(/i.test(text)) {
        if (/\(/.test(text)) { $('hhFx').classList.add('is-bad'); fxMsg('Крок — лише FILTER(…): BODY і VIEW тут не потрібні', true); return; }
        text = `FILTER(${text})`;
    }
    if (text) {
        const q = window.herdQuery.parse(text, PARAMS);
        if (q.error) { $('hhFx').classList.add('is-bad'); fxMsg(q.error, true); return; }
        if ((q.keys || []).some((k) => /^vacc(_late|_soon)?$/.test(k))) { $('hhFx').classList.add('is-bad'); fxMsg('Формула кроку не може залежати від vacc', true); return; }
        if (q.cols.length || q.groups.length || q.sorts.length || (q.extra || []).length || q.aggs.length) {
            $('hhFx').classList.add('is-bad'); fxMsg('Крок — лише FILTER(…) з умовами', true); return;
        }
    }
    if (text === (pr.st.fx || '')) { FX.set(fxShown(pr.st)); return; }
    pr.st.fx = text;
    // формула замінює давнє «від чого рахувати»
    ['base', 'prev', 'from', 'to'].forEach((k) => { delete pr.st[k]; });
    FX.set(fxShown(pr.st));
    V.setSchemes(SCHEMES);
    if (needKeys().some((k) => !LOADED.has(k))) await loadAnimals();
    renderSchemes();
    fxMsg('');
    saveSoon();
}
/* ГОЛОВНІ ПАНЕЛІ ЗГОРТАЮТЬСЯ (Роман 2026-10-01): клік по шапці (повз кнопки й перемикачі) — сховати / показати; стан у браузері */
(function () {
    const KEY = 'herd:health_fold';
    let fold = {};
    try { fold = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { fold = {}; }
    document.querySelectorAll('.hh-panel[data-fold]').forEach((p) => {
        const k = p.dataset.fold;
        p.classList.toggle('is-collapsed', !!fold[k]);
        const head = p.querySelector('.panel-head');
        head.setAttribute('title', 'Клацніть, щоб згорнути або розгорнути');
        head.addEventListener('click', (e) => {
            if (e.target.closest('button, a, select, input, label, .segmented')) return;
            const on = !p.classList.contains('is-collapsed');
            p.classList.toggle('is-collapsed', on);
            if (on) fold[k] = 1; else delete fold[k];
            try { localStorage.setItem(KEY, JSON.stringify(fold)); } catch (er) { /* ignore */ }
        });
    });
}());
/* рядок формули тримається вгорі під час прокрутки — як у «Роботі зі стадом» і Календарі */
(function () {
    const bar = $('hhFxTop');
    const topbar = document.querySelector('.topbar');
    if (!bar) return;
    let TOP = null, IO = null;
    const barTop = () => (window.farmStickyTop ? window.farmStickyTop()   // шапка (на телефоні) + стежка
        : (topbar && getComputedStyle(topbar).position === 'sticky' ? topbar.offsetHeight : 0));
    function place() {
        const t = barTop();
        if (t === TOP) return;
        TOP = t;
        bar.style.top = (t - 1) + 'px';
        if (!window.IntersectionObserver) return;
        if (IO) IO.disconnect();
        IO = new IntersectionObserver(([en]) => { bar.classList.toggle('is-stuck', en.intersectionRatio < 1); },
            { threshold: [1], rootMargin: `${-t}px 0px 0px 0px` });
        IO.observe(bar);
    }
    place();
    window.addEventListener('resize', place);
    if (window.ResizeObserver && topbar) new ResizeObserver(place).observe(topbar);
    if (window.farmStickyWatch) window.farmStickyWatch(place);   // стежка зʼявилась / змінила висоту
}());

/* ---------- дані ---------- */
let LOADED = new Set();
async function loadAnimals() {
    const keys = needKeys().filter((k) => PARAMS.some((p) => p.key === k));
    const r = await apiGet('/api/herd/animals/bulk?status=active&params=' + encodeURIComponent(keys.join(','))).catch(() => null);
    if (!r || !r.ok) { toast('Стадо не прочиталось — оновіть сторінку', 'error'); return; }
    ANIMALS = r.items || [];
    LOADED = new Set(needKeys());
}
async function loadDone() {
    const r = await V.load();
    if (!r) return false;
    EVENT = r.event || null;
    return r;
}
/* СТАН СТОРІНКИ ПЕРЕЖИВАЄ ОНОВЛЕННЯ (Роман 2026-10-01): вибраний крок, розгорнуті картки й рядки журналу, дата
   вакцинації (лише сьогоднішня — завтра знову сьогодні) і прокрутка */
const STATE_KEY = 'herd:health_state';
function stateSave() {
    try {
        localStorage.setItem(STATE_KEY, JSON.stringify({ sel: SEL, open: [...OPEN], hist: [...HIST_OPEN], lv: [...LV_OPEN],
            date: { on: iso(today()), v: $('hhDate').value } }));
        sessionStorage.setItem(STATE_KEY + ':scroll', String(window.scrollY));
    } catch (e) { /* ignore */ }
}
function stateLoad() {
    let st = null;
    try { st = JSON.parse(localStorage.getItem(STATE_KEY) || 'null'); } catch (e) { st = null; }
    if (!st) return;
    if (st.sel) SEL = st.sel;
    if (Array.isArray(st.open)) { st.open.forEach((k) => OPEN.add(k)); FIRST = false; }
    if (Array.isArray(st.hist)) st.hist.forEach((k) => HIST_OPEN.add(k));
    if (Array.isArray(st.lv)) st.lv.forEach((k) => LV_OPEN.add(k));
    if (st.date && st.date.on === iso(today()) && st.date.v) $('hhDate').value = st.date.v;
}
let SAVE_ST = 0;
const stateSoon = () => { clearTimeout(SAVE_ST); SAVE_ST = setTimeout(stateSave, 250); };
window.addEventListener('scroll', stateSoon, { passive: true });
window.addEventListener('pagehide', stateSave);
document.addEventListener('click', stateSoon);
$('hhDate').addEventListener('change', stateSoon);
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
function scrollRestore() {
    let y = 0;
    try { y = +sessionStorage.getItem(STATE_KEY + ':scroll') || 0; } catch (e) { y = 0; }
    if (!y) return;
    // над сторінкою ще довантажуються банери — доганяємо позицію кілька разів, доки людина сама не прокрутила
    let user = false;
    const stop = () => { user = true; };
    ['wheel', 'touchstart', 'keydown', 'mousedown'].forEach((ev) => window.addEventListener(ev, stop, { once: true, passive: true }));
    [0, 150, 400, 800, 1500, 2500].forEach((ms) => setTimeout(() => { if (!user) window.scrollTo(0, y); }, ms));
}
async function boot() {
    $('hhDate').value = iso(today());
    stateLoad();
    renderSoonSeg();
    const [ev, v] = await Promise.all([apiGet('/api/herd/events?lite=1').catch(() => null), loadDone()]);
    if (!ev || !ev.ok || !v) { $('hhSum').textContent = 'Не вдалося завантажити'; return; }
    renderSoonSeg();                                  // межі ферми — з сервера
    PARAMS = ev.params || [];
    V.use({ params: () => PARAMS });
    window.HERD_CONSTS = ev.consts || [];
    SCHEMES = V.normSchemes((v.schemes || []).map((s) => Object.assign({ steps: [] }, JSON.parse(JSON.stringify(s)))));
    // давні кроки (від дати + дні) — одразу формулою, коли її можна скласти (дні життя, DIM); записується з першою правкою
    SCHEMES.forEach((sc) => sc.steps.forEach((st) => {
        if (st.fx) return;
        const f = V.fxOfLegacy(sc, st);
        if (f) { st.fx = f; ['base', 'prev', 'from', 'to'].forEach((k) => { delete st[k]; }); }
    }));
    if (!selPair() && SCHEMES.length && SCHEMES[0].steps.length) SEL = sk(SCHEMES[0], SCHEMES[0].steps[0]);
    V.setSchemes(SCHEMES);
    await loadAnimals();
    renderSchemes();
    fxRender();
    renderDue();
    renderHist();
    scrollRestore();
    loadWLists();                                     // позначки «у списках» — слідом
}
boot();
})();
