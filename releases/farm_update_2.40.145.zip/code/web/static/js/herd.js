'use strict';
/* Управління стада — «Рух поголівʼя» З ПОДІЙ стада (Роман 2026-09-27: «давай
   попрацюємо над Рух поголівʼя» → «рух із подій стада»). Доти тут була сітка
   «тип × місяць», яку вписували руками, — на буртах порожня. Тепер таблиці
   складає ферма (конструктор нижче), кожне число рахує сервер за датою події,
   наведення на число — хто саме. */

const MONTHS = ['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер', 'Вер', 'Жов', 'Лис', 'Гру'];
const MONTHS_FULL = ['січень', 'лютий', 'березень', 'квітень', 'травень', 'червень', 'липень',
    'серпень', 'вересень', 'жовтень', 'листопад', 'грудень'];
const MONTHS_OF = ['січня', 'лютого', 'березня', 'квітня', 'травня', 'червня', 'липня',
    'серпня', 'вересня', 'жовтня', 'листопада', 'грудня'];

(function herdMovement() {
    /* Конструктор руху (Роман 2026-09-27: «хочу рух поголівʼя сам налаштовувати…
       таблиці, перегородки, формули. Кольори, шрифти, розміри. І якщо наводиш на
       число — підказка»; 2026-09-28: «рядок формул і мова… рух по голівʼї формулами…
       достатньо фільтр і що входить в цей фільтр. Щоб це було професійно, коректно,
       гарно і мінімально»). Рядок таблиці — формула (vet_pharmacy/herd_move.py):
       EVENT/BORN/ENTRY — події за період; START(група), група — голів на початок і на
       кінець; IN/OUT(група) — хто увійшов і вийшов; [Рядок] + − × ÷ — арифметика.
       ✎ — правка на самій таблиці з рядком формули вгорі (як в Excel): клік по рядку —
       його формула в рядку, Enter — перерахувати, Tab — наступний рядок, Esc — як було. */
    const box = document.getElementById('mvTables');
    if (!box) return;
    const label = document.getElementById('mvLabel');
    const seg = document.getElementById('mvBy');
    const tip = document.getElementById('mvTip');
    const pop = document.getElementById('mvPop');
    const addTableBtn = document.getElementById('mvAddTable');
    const addMenu = document.getElementById('mvAddMenu');
    const CAN = !!addTableBtn;                      // керує гілкою — може правити
    // рядок формули — угорі сторінки, під смужкою гілки (Роман 2026-09-29): клік по показнику таблиці
    // показує тут його формулу, а хто керує гілкою — одразу пише умови
    const fxBar = document.getElementById('mvFx');
    const fxRo = document.getElementById('mvFxRo');
    const fxEd = document.getElementById('mvFxEd');
    const fxOps = document.getElementById('mvFxOps');
    const fxRes = document.getElementById('mvFxRes');
    const VIEW_KEY = 'herd:move_by';
    const pad = (n) => String(n).padStart(2, '0');
    const now = new Date();
    const todayKey = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    let by = 'month';
    try { if (localStorage.getItem(VIEW_KEY) === 'day') by = 'day'; } catch (e) { /* ignore */ }
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    let CONFIG = [];                                  // таблиці, як збережено
    let REVS = {};                                    // відбиток кожної таблиці на сервері — ловить чужу правку
    let SAMPLE = [];                                  // зразок «Оборот стада»
    let REPORT = null;                                // пораховано за період
    let ED = null;                                    // таблиця в правці: {tid, draft, orig, prev, sel, base, mode, fx}
    let VOCAB = null;                                 // події, панелі, параметри — для підказок
    /* «Поголівʼя для звітів годівлі» (Роман 2026-09-29: «як таблиці руху») — ще одна таблиця на цій
       панелі: рядки — групи знімка поголівʼя, стовпці — ті самі місяці чи дні. Числа — щоденний знімок
       реєстру за формулою рядка (Бовіо) або книга Excel; формула — мовою «Роботи зі стадом». Правка —
       та сама, що в таблицях руху: клік по рядку — назва й формула просто на місці. */
    const HID = '__heads';
    const HSRC_KEY = 'herd:heads_src';
    const FEED_KEYS = { d_cow: 'дійних', dry_cow_1: 'сухостій', dry_cow_2: 'сухостій', f_cow: 'фуражних',
        all_anymal: 'все поголів’я' };                 // ці рядки беруть звіти годівлі
    const HFX_PH = 'FILTER(lact>0 rc<6)  або  [Дійні]';
    let FEED = { since: box.dataset.feedSince || '', first: box.dataset.feedFirst || '' };
    let HSRC = FEED.since ? 'bovio' : 'excel';       // типово — те, чим рахуються звіти
    try {
        const kept = localStorage.getItem(HSRC_KEY);
        if (kept === 'bovio' || kept === 'excel') HSRC = kept;
    } catch (e) { /* ignore */ }
    let HEADS = null;                                 // числа поголів’я за показаний рік чи місяць
    let HCFG = null;                                  // рядки з Бовіо: {cols:[{key,label,formula}], errors, last}
    let HW = null;                                    // для «скільки зараз»: панелі, списки, тварини
    let seq = 0, nid = 0;
    const nf = new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 1 });
    const dmy = (iso) => (iso ? `${iso.slice(8, 10)}.${iso.slice(5, 7)}.${iso.slice(0, 4)}` : '');
    const clone = (o) => JSON.parse(JSON.stringify(o));
    // палітра — та сама, що _MOVE_PALETTE на сервері; одна для тексту, фону й смуги шапки
    const PALETTE = [["brown", "Коричневий"], ["red", "Червоний"], ["orange", "Помаранчевий"], ["yellow", "Жовтий"], ["olive", "Оливковий"], ["green", "Зелений"], ["teal", "Бірюзовий"], ["cyan", "Блакитний"], ["blue", "Синій"], ["indigo", "Індиго"], ["violet", "Фіолетовий"], ["pink", "Рожевий"], ["gray", "Сірий"], ["slate", "Графітовий"], ["black", "Чорний"]];
    const PAL_NAME = Object.fromEntries(PALETTE);
    const SIZES = [['sm', 'Мал'], ['', 'Звич'], ['lg', 'Вел'], ['xl', 'Дуже']];
    const FUNCS = {
        // народження й купівля — теж EVENT (один стандарт, Роман 2026-09-29): EVENT(birth), EVENT(entry)
        EVENT: 'події за період: EVENT(calving) FILTER(lact>0), EVENT(birth) FILTER(alive), EVENT(entry)',
        START: 'голів у групі на початок періоду: START([Дійні])',
        IN: 'скільки увійшло в групу: IN([Дійні]), IN([Фуражні] from=[Нетелі])',
        OUT: 'скільки вийшло з групи: OUT([Дійні]), OUT(HERD by=EVENT(cull))',
    };
    // назви подій (для формул, українські й ключі) — підсвітка одразу після EVENT(
    const evNames = () => ((VOCAB && VOCAB.events) || []).flatMap((e) => [e.en, e.name, e.key]).filter(Boolean);
    const HL = { acts: /^(event|born|entry|start|in|out)$/i, words: /^(herd|first|alive|dead|all|from|to|by)$/i,
        events: evNames };
    const FX_PH = 'EVENT(calving) FILTER(lact>0) · START([Дійні]) · IN([Дійні] by=EVENT(calving)) · [Рядок] - [Рядок]';

    function periodName(p) {
        if (p === '*') return by === 'month' ? `${year} рік` : `${MONTHS_FULL[month - 1]} ${year}`;
        if (p.length === 7) return `${MONTHS_FULL[+p.slice(5, 7) - 1]} ${p.slice(0, 4)}`;
        return `${+p.slice(8, 10)} ${MONTHS_OF[+p.slice(5, 7) - 1]} ${p.slice(0, 4)}`;
    }
    function periodShort(p) {
        return p.length === 7 ? `${MONTHS[+p.slice(5, 7) - 1]} ${p.slice(0, 4)}` : dmy(p).slice(0, 5);
    }
    // межа кварталу (квітень, липень, жовтень) чи тижня (понеділок) — тонка лінія стовпця
    function edgeCls(p) {
        if (p.length === 7) return ['04', '07', '10'].includes(p.slice(5, 7)) ? ' q-start' : '';
        return new Date(p + 'T00:00:00').getDay() === 1 && p.slice(8, 10) !== '01' ? ' q-start' : '';
    }
    function colHead(p) {
        if (p.length === 7) {
            return `<th class="num${edgeCls(p)}${todayKey.slice(0, 7) === p ? ' is-now' : ''}${p > todayKey.slice(0, 7) ? ' is-fut' : ''}" title="${MONTHS_FULL[+p.slice(5, 7) - 1]} ${p.slice(0, 4)}">`
                + `${MONTHS[+p.slice(5, 7) - 1]}</th>`;
        }
        const d = new Date(p + 'T00:00:00');
        const wk = d.getDay() === 0 || d.getDay() === 6;
        return `<th class="num${edgeCls(p)}${p === todayKey ? ' is-now' : ''}${wk ? ' is-weekend' : ''}${p > todayKey ? ' is-fut' : ''}" title="${dmy(p)}">${+p.slice(8, 10)}</th>`;
    }
    function rowCls(st) {
        st = st || {};
        return [st.c ? 'mc-' + st.c : '', st.bg ? 'mb-' + st.bg : '', st.s ? 'fs-' + st.s : '',
            st.b ? 'fw-b' : 'fw-n', st.i ? 'fi' : '', st.ind ? 'ind-1' : ''].filter(Boolean).join(' ');
    }
    const fmt = (v) => (v === null || v === undefined || v === '' ? '' : nf.format(v));
    const TOTAL_HINT = { sum: 'сума за всі стовпці', first: 'на початок першого стовпця',
        last: 'на кінець останнього стовпця', calc: 'та сама формула на підсумках рядків' };

    /* ── показ ── */
    function calcOf(tid) {
        if (tid === HID) return headsCalc();
        if (ED && ED.tid === tid && ED.prev) return ED.prev;
        return ((REPORT && REPORT.tables) || []).find((x) => x.id === tid) || null;
    }
    function rowOf(tid, rid) {
        const c = calcOf(tid);
        return ((c && c.rows) || []).find((r) => r.id === rid) || null;
    }
    function cellHtml(t, r, c, p, nowKey) {
        const st = (c.st || {})[p];
        const cl = 'num' + edgeCls(p) + (p === nowKey ? ' is-now' : '');
        if (st === 'fut') return `<td class="${cl} is-fut"></td>`;
        if (st === 'na') return `<td class="${cl}"><span class="mv-na" data-why="na" data-p="${p}" data-r="${escapeHtml(r.id)}">—</span></td>`;
        if (st === 'div0') return `<td class="${cl}"><span class="mv-na" data-why="div0">—</span></td>`;
        const v = (c.counts || {})[p];
        const part = st === 'part' ? ' is-part' : '';
        if (v === undefined || v === null) return `<td class="${cl}${part}"></td>`;
        if (c.heads) return `<td class="${cl}"><span class="mv-hv" data-r="${escapeHtml(r.id)}" data-p="${p}">${fmt(v)}</span></td>`;
        const stock = c.kind === 'stock';
        if (v === 0 && !stock) return `<td class="${cl}${part}"></td>`;
        const has = ((c.cells || {})[p] || []).length;
        const btn = (has || (stock && c.tk !== 'calc'))
            ? `<button type="button" class="mv-n" data-t="${escapeHtml(t.id)}" data-r="${escapeHtml(r.id)}" data-p="${p}"${stock ? ' data-stock="1"' : ''}>${fmt(v)}</button>`
            : fmt(v);
        return `<td class="${cl}${part}">${btn}</td>`;
    }
    /* дата «на кінець» у «Разом» — один раз у шапці стовпця, а не під кожним числом (Роман 2026-09-29: «показувати на дату
       десь в одному місці»): найчастіша «на …» у таблиці йде в шапку, під числом лишається лише інша дата */
    function onNote(tid) {
        const calc = tid ? calcOf(tid) : null;
        if (!calc || calc.heads) return '';
        const n = {};
        (calc.rows || []).forEach((c) => { if (/^на /.test(c.tnote || '')) n[c.tnote] = (n[c.tnote] || 0) + 1; });
        return Object.keys(n).sort((a, b) => n[b] - n[a])[0] || '';
    }
    function headHtml(periods, editing, hd, tid) {      // hd — рахунок поголів’я (його дата — у шапці «На …»)
        // у правці, доки нічого не вибрано, шапка першої колонки підказує, що робити
        const hint = editing && ED && !ED.sel && ED.mode !== 'block' && (ED.draft.rows || []).length > 0;
        const first = !editing ? (hd ? 'Група' : 'Рух') : (hint ? 'Клацніть рядок, щоб правити' : 'Рядок');
        const total = hd ? `<th class="num mv-total" title="Голів на кінець останнього стовпця, де є число">${hd.hday ? 'На ' + dmy(hd.hday).slice(0, 5) : 'На кінець'}</th>`
            : '<th class="num mv-total" title="Разом: події й рух — сума; на початок — перший стовпець; на кінець — останній">Разом'
                + ((n) => (n ? `<small class="mv-tn">${escapeHtml(n.slice(0, 8))}</small>` : ''))(onNote(tid)) + '</th>';
        return `<tr><th class="mv-name${hint ? ' is-hint' : ''}">${first}</th>` + periods.map(colHead).join('') + total + '</tr>';
    }
    function cellsHtml(t, r, c, periods, nowKey) {     // усе, крім назви
        if (r.type === 'sep') return `<td colspan="${periods.length + 1}"></td>`;
        const tot = c.total === null || c.total === undefined || (c.total === 0 && c.kind !== 'stock') ? ''
            : fmt(c.total);
        const tn = tot && c.tnote && c.tnote !== onNote(t.id) ? `<small class="mv-tn">${escapeHtml(c.tnote)}</small>` : '';
        return periods.map((p) => cellHtml(t, r, c, p, nowKey)).join('')
            + `<td class="num mv-total" title="${TOTAL_HINT[c.tk] || ''}">${tot}${tn}</td>`;
    }
    // місце рядка в таблиці — класами, а не сусідніми селекторами: у правці рядки лежать у трьох
    // tbody, і вибір рядка не повинен зсувати сусідів ні на піксель
    function posCls(rows, i) {
        const r = rows[i], pv = rows[i - 1], nx = rows[i + 1];
        const sub = (x) => !!(x && x.type !== 'sep' && x.style && x.style.ind);
        const out = [];
        if (!pv || (r.type !== 'sep' && pv.type === 'sep')) out.push('no-line');
        if (r.type !== 'sep') out.push(sub(r) ? (sub(nx) ? '' : 'g-end') : (sub(nx) ? 'g-top' : ''));
        // смуг «через один» немає (Роман 2026-09-29: «не повинна мати авточередування кольору — колір я сам
        // налаштовую»): фон рядка — лише той, що задали в Aa
        return out.filter(Boolean).join(' ');
    }
    /* вигляд таблиці (Роман 2026-09-29: «таблиця має виглядати професійно»): смуга шапки з датами —
       колір із палітри чи без смуги. Лише класи — кольори (і темна тема) в CSS */
    const lookCls = (st) => {
        st = st || {};
        return st.hb ? ' hb-' + st.hb : '';
    };
    // перегородка без назви — тонкий розділювач, а не порожня смуга на всю висоту (у правці — повна, щоб було куди писати)
    const rowClass = (r, o) => [r.type === 'sep' ? 'mt-sep' : '',
        r.type === 'sep' && !String(r.label || '').trim() && !o.editing && !o.sel ? 'is-empty' : '',
        rowCls(r.style), o.pos || '', o.nil ? 'is-nil' : '',
        o.sel ? 'is-sel' : ''].filter(Boolean).join(' ');
    /* ледь помітний кружечок перед назвою рядка — лише щоб викликати вікно вигляду рядка (Роман 2026-09-29: «мітка,
       на яку можна натиснути… ледь помітною і тільки для того, щоб можна було визвати контекстне меню»); у правці */
    function markHtml(r, o) {
        if (!(o.editing || o.sel || o.canDot)) return '';
        if (r.type === 'sep') {                        // перегородка: кружечок лише щоб тягнути її разом з блоком
            return `<button type="button" class="mv-mkb is-sep" data-r="${escapeHtml(r.id)}"`
                + ` title="Перетягніть — перегородка переїде разом з усіма рядками свого блоку" aria-label="Перетягнути блок"></button>`;
        }
        return `<button type="button" class="mv-mkb" data-r="${escapeHtml(r.id)}"`
            + ` title="Вигляд рядка: колір тексту, фон, шрифт і розмір" aria-label="Вигляд рядка"></button>`;
    }
    function rowHtml(t, r, c, periods, nowKey, o) {
        // виділений у правці рядок: назва правиться просто в ньому, формула — під ним; невидиме мірило
        // тримає ширину колонки за назвою — поле само її не задає, і таблиця стрибала б
        const mk = markHtml(r, o);
        const name = o.sel
            ? `<span class="mv-nmrow">${mk}<input type="text" class="mb-name" maxlength="${t.heads ? 60 : 80}" spellcheck="false" autocomplete="off" value="${escapeHtml(r.label || '')}"`
                + ` placeholder="${r.type === 'sep' ? 'Назва перегородки' : 'Назва рядка'}"></span>`
                + `<span class="mb-sizer" aria-hidden="true">${mk ? '<i class="mv-mkgap"></i>' : ''}${escapeHtml(r.label || '')}</span>`
            : mk + `<span class="mv-lab" data-t="${escapeHtml(t.id)}" data-r="${escapeHtml(r.id)}">${escapeHtml(r.label || (o.editing ? '(без назви)' : ''))}</span>`
                + (c.err && r.type !== 'sep' ? `<span class="mr-err" title="${escapeHtml(c.err)}">⚠ ${escapeHtml(c.err)}</span>` : '');
        return `<tr class="${rowClass(r, o)}" data-rid="${escapeHtml(r.id)}"><td class="mv-name">${name}</td>`
            + `${cellsHtml(t, r, c, periods, nowKey)}</tr>`;
    }
    function tableHtml(t, calc) {                      // перегляд — одна таблиця на всю ширину панелі
        const periods = (REPORT && REPORT.periods) || [];
        const nowKey = by === 'month' ? todayKey.slice(0, 7) : todayKey;
        const byId = {};
        ((calc && calc.rows) || []).forEach((r) => { byId[r.id] = r; });
        // рядок, у якому за весь період не видно жодного числа, — тихий
        const nil = (c) => !c.err && periods.every((p) => {
            const v = (c.counts || {})[p];
            return v === undefined || v === null || (v === 0 && c.kind !== 'stock') || ['na', 'fut', 'div0'].includes((c.st || {})[p]);
        });
        const rows = t.rows || [];
        const canDot = canEdit(t.id);                  // кружечок вигляду — завжди, хто може правити
        const body = rows.map((r, i) => {
            const c = byId[r.id] || {};
            return rowHtml(t, r, c, periods, nowKey, { pos: posCls(rows, i), nil: r.type !== 'sep' && !!calc && nil(c), canDot });
        }).join('');
        return `<div class="table-scroll mv-scroll"><table class="table table-compact mv-table${by === 'day' ? ' by-day' : ''}">`
            + `<thead>${headHtml(periods, false, t.heads ? (calc || {}) : null, t.id)}</thead>`
            + `<tbody>${body || `<tr class="no-line"><td class="empty" colspan="${periods.length + 2}">${t.heads && !headsFresh() ? 'Завантаження…' : 'Рядків ще немає'}</td></tr>`}</tbody></table></div>`;
    }
    function sinceHtml(calc) {
        if (calc && calc.heads) return headsFootHtml();
        const s = calc && calc.since;
        return s ? `<p class="mt-foot">Склад груп рахується з ${dmy(s)} — з дня, коли стадо з’явилось у Бовіо; `
            + 'раніше секції й стан тварин по днях невідомі. Події — за всю історію.</p>' : '';
    }
    const TRASH = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" '
        + 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6'
        + 'M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>';
    /* ↩ ПОВЕРНУТИ (Роман 2026-09-29): кожен запис таблиці кладе попередній її стан у стос — «↩» чи Ctrl+Z повертає
       крок за кроком, і повернене теж одразу записується. Стос живе, доки відкрита сторінка (до 30 кроків на таблицю). */
    const HIST = {};
    let HIST_LAST = '';
    function undoBtn(tid) {
        if (!CAN) return '';
        const n = (HIST[tid] || []).length;
        return `<button type="button" class="mt-undo" data-undo="${escapeHtml(tid)}"${n ? '' : ' hidden'}`
            + ` title="Повернути, як було до останньої зміни (Ctrl+Z) · кроків: ${n}">↩</button>`;
    }
    function paintUndo(tid) {
        const b = box.querySelector(`.mt[data-tid="${CSS.escape(tid)}"] .mt-undo`);
        if (!b) return;
        const n = (HIST[tid] || []).length;
        b.hidden = !n;
        b.title = `Повернути, як було до останньої зміни (Ctrl+Z) · кроків: ${n}`;
    }
    function pushHist(tid, snap) {
        if (!snap) return;
        const h = HIST[tid] = HIST[tid] || [];
        const s = snapOf(snap);
        if (h.length && snapOf(h[h.length - 1]) === s) return;
        h.push(clone(snap));
        if (h.length > 30) h.shift();
        HIST_LAST = tid;
        paintUndo(tid);
    }
    /* кроки назад переживають оновлення сторінки (localStorage), але лише доки таблицю ніхто інший не змінив: разом зі
       стосом лежить відбиток її записаного стану, і чужа зміна тим часом стирає стос цієї таблиці — інакше «↩» затер би її */
    const HIST_KEY = 'herd:mv_hist';
    let HIST_READY = false;
    function histSave() {
        if (!HIST_READY) return;
        const now = {};
        Object.keys(HIST).forEach((tid) => { const t = curTable(tid); if (t && HIST[tid].length) now[tid] = snapOf(t); });
        const h = {};
        Object.keys(now).forEach((tid) => { h[tid] = HIST[tid]; });
        try { localStorage.setItem(HIST_KEY, JSON.stringify({ h, now, last: HIST_LAST })); } catch (e) { /* ignore */ }
    }
    function histRestore() {
        if (HIST_READY || !CFG_OK || !HCFG) return;
        HIST_READY = true;
        let st = null;
        try { st = JSON.parse(localStorage.getItem(HIST_KEY) || 'null'); } catch (e) { st = null; }
        if (!st || !st.h) return;
        Object.keys(st.h).forEach((tid) => {
            const t = curTable(tid);
            if (t && Array.isArray(st.h[tid]) && st.now && st.now[tid] === snapOf(t) && !(HIST[tid] || []).length) {
                HIST[tid] = st.h[tid].slice(-30);
            }
        });
        if (st.last && HIST[st.last]) HIST_LAST = st.last;
        histSave();                                    // стоси чужих змін прибрано й зі сховища
    }
    const curTable = (tid) => (tid === HID ? (HCFG ? headsTable() : null) : CONFIG.find((t) => t.id === tid) || null);
    /* таблицю можна згорнути до шапки (Роман 2026-09-29: «таблиці можна скривати, розкривати»): шеврон ліворуч від
       назви чи клік по назві; стан — у браузері, для кожної таблиці свій. Таблиця в правці не згортається. */
    const FOLD_KEY = 'herd:mv_fold';
    let FOLD = {};
    try { FOLD = JSON.parse(localStorage.getItem(FOLD_KEY) || '{}') || {}; } catch (e) { FOLD = {}; }
    const foldCls = (tid, editing) => (FOLD[tid] && !editing ? ' is-fold' : '');
    const CHEV = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" '
        + 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
    const foldBtn = (tid) => `<button type="button" class="mt-fold" title="${FOLD[tid] ? 'Розгорнути таблицю' : 'Згорнути таблицю'}"`
        + ` aria-expanded="${!FOLD[tid]}">${CHEV}</button>`;
    /* згорнута таблиця показує в шапці головне: до чотирьох головних рядків (не ↳, не перегородки) за поточний місяць
       (у «По днях» — за сьогодні); поточного періоду на екрані немає — за весь показаний рік чи місяць */
    function foldSumHtml(t) {
        const calc = calcOf(t.id);
        const periods = (REPORT && REPORT.periods) || [];
        if (!calc || !periods.length) return '';
        const nowKey = by === 'month' ? todayKey.slice(0, 7) : todayKey;
        const cur = periods.includes(nowKey);
        const byId = {};
        (calc.rows || []).forEach((c) => { byId[c.id] = c; });
        const parts = [];
        (t.rows || []).forEach((r) => {
            if (parts.length >= 4 || r.type === 'sep' || (r.style && r.style.ind)) return;
            const c = byId[r.id];
            if (!c || c.err) return;
            let v = cur ? (c.counts || {})[nowKey] : c.total;
            if (v === null || v === undefined || v === '') {
                if (c.kind === 'stock' || c.heads) return;  // поголівʼя без знімка — не вигадуємо
                v = 0;                                  // подій не було — нуль
            }
            parts.push(`<span>${escapeHtml(r.label || '')} <b>${fmt(v)}</b></span>`);
        });
        if (!parts.length) return '';
        const mi = Number(nowKey.slice(5, 7)) - 1;
        const when = cur ? (by === 'month' ? MONTHS_FULL[mi] : `${nowKey.slice(8, 10)}.${nowKey.slice(5, 7)}`)
            : (by === 'month' ? String(year) : `${MONTHS_FULL[month - 1]} ${year}`);
        return `<span class="mt-sum" title="Згорнута таблиця: головні рядки за ${escapeHtml(when)}">${parts.join('<i>·</i>')}`
            + `<em>${escapeHtml(when)}</em></span>`;
    }
    function paintFoldAll() {                          // «Згорнути всі», поки хоч одна розгорнута
        if (!foldAllBtn) return;
        const secs = [...box.querySelectorAll('.mt[data-tid]')];
        const open = secs.some((x) => !x.classList.contains('is-fold'));
        foldAllBtn.hidden = !secs.length;
        foldAllBtn.textContent = open ? 'Згорнути всі' : 'Розгорнути всі';
    }
    function toggleFold(tid) {
        if (ED && ED.tid === tid) stopEdit();          // записане вже записане — згортаємо перегляд
        if (FOLD[tid]) delete FOLD[tid]; else FOLD[tid] = 1;
        try { localStorage.setItem(FOLD_KEY, JSON.stringify(FOLD)); } catch (e) { /* ignore */ }
        const sec = box.querySelector(`.mt[data-tid="${CSS.escape(tid)}"]`);
        if (!sec) return;
        sec.classList.toggle('is-fold', !!FOLD[tid]);
        const b = sec.querySelector('.mt-fold');
        if (b) { b.title = FOLD[tid] ? 'Розгорнути таблицю' : 'Згорнути таблицю'; b.setAttribute('aria-expanded', String(!FOLD[tid])); }
        closeCells();
        paintFoldAll();
    }
    const foldAllBtn = document.getElementById('mvFoldAll');
    if (foldAllBtn) foldAllBtn.addEventListener('click', () => {
        const secs = [...box.querySelectorAll('.mt[data-tid]')];
        const fold = secs.some((x) => !x.classList.contains('is-fold'));
        if (fold && ED) stopEdit();
        FOLD = {};
        if (fold) CONFIG.concat([{ id: HID }]).forEach((t) => { FOLD[t.id] = 1; });
        try { localStorage.setItem(FOLD_KEY, JSON.stringify(FOLD)); } catch (e) { /* ignore */ }
        box.querySelectorAll('.mt[data-tid]').forEach((x) => {
            x.classList.toggle('is-fold', fold);
            const b = x.querySelector('.mt-fold');
            if (b) { b.title = fold ? 'Розгорнути таблицю' : 'Згорнути таблицю'; b.setAttribute('aria-expanded', String(!fold)); }
        });
        closeCells();
        paintFoldAll();
    });
    function sectionHtml(t) {
        const editing = !!(ED && ED.tid === t.id);
        const tt = editing ? ED.draft : t;
        const calc = calcOf(t.id);
        if (t.heads) return headsSectionHtml(t, tt, calc, editing);
        const titleCls = tt.style && tt.style.c ? ' mc-' + tt.style.c : '';
        // шапка таблиці однакової висоти в обох режимах — у правці нічого не зсувається
        const head = editing
            ? `<div class="mt-head">${foldBtn(t.id)}<input type="text" class="mt-title-in${titleCls}" maxlength="80" value="${escapeHtml(tt.title || '')}" placeholder="Назва таблиці">`
                + '<button type="button" class="mr-style mt-tstyle" title="Вигляд таблиці: колір назви, смуга шапки, смуги рядків">Aa</button>'
                + undoBtn(t.id)
                + `<span class="mt-ops"><button type="button" class="mt-x mt-drop" title="Прибрати таблицю">${TRASH}</button></span></div>`
            : `<div class="mt-head">${foldBtn(t.id)}<h3 class="mt-title${titleCls}">${escapeHtml(tt.title || '')}</h3>`
                + foldSumHtml(tt) + undoBtn(t.id) + '</div>';
        // у правці — три частини: рядки до виділеного · виділений із правкою · решта (refreshEdit)
        const body = editing ? EDIT_BODY : tableHtml(tt, calc);
        return `<section class="mt${editing ? ' is-edit' : ''}${foldCls(t.id, editing)}${lookCls(tt.style)}" data-tid="${escapeHtml(t.id)}">${head}`
            + `<div class="mt-body">${body}</div><div class="mv-det" hidden></div>`
            + `<div class="mt-since">${sinceHtml(calc)}</div></section>`;
    }
    const EDIT_BODY = '<div class="table-scroll mv-scroll"><table class="table table-compact mv-table"><thead></thead>'
        + '<tbody class="mv-tb"></tbody><tbody class="mv-edtb"></tbody><tbody class="mv-tb"></tbody></table></div>';
    /* ── поголів’я: та сама таблиця, що й рух; шапка — джерело чисел і правка ── */
    const headsFresh = () => !!(HEADS && HEADS.src === HSRC);   // числа саме того джерела, що вибране
    function headsTable() {
        // Бовіо — рядки з формулами (HCFG); без них правки немає, лише назви зі знімка
        const cols = HSRC === 'bovio' ? (HCFG ? HCFG.cols : ((headsFresh() && HEADS.cols) || []))
            : ((headsFresh() && HEADS.cols) || []);
        return { id: HID, heads: true, title: 'Поголів’я для звітів годівлі', style: Object.assign({}, (HCFG && HCFG.style) || {}),
            rows: cols.map((c) => ({ id: c.key, key: c.key, type: 'row', label: c.label || c.key,
                formula: String(c.formula || '').replace(/^\s*=\s*/, ''), style: Object.assign({}, c.style || {}) })) };
    }
    const tableOf = (tid) => (tid === HID ? headsTable() : CONFIG.find((t) => t.id === tid));
    function headsCalc() {                            // числа рядків — як рахунок таблиці руху
        if (!HEADS) return null;
        const fresh = headsFresh();                   // інше джерело ще читається — клітинки порожні
        const periods = (REPORT && REPORT.periods) || [];
        const nowKey = by === 'month' ? todayKey.slice(0, 7) : todayKey;
        const errs = (HSRC === 'bovio' && HCFG && HCFG.errors) || {};
        const rows = headsTable().rows.map((r) => {
            const counts = {}, st = {}, days = {};
            let total = null, tday = '';
            periods.forEach((p) => {
                if (p > nowKey) { st[p] = 'fut'; return; }
                if (!fresh) return;
                const b = HEADS.per[p];
                const v = b ? b.values[r.key] : undefined;
                if (v === undefined || v === null) { st[p] = 'na'; return; }
                counts[p] = v;
                days[p] = b.day;
                total = v;
                tday = b.day;
            });
            return { id: r.id, label: r.label, heads: true, kind: 'stock', tk: 'last', counts, st, days, total, tday,
                tnote: '', err: errs[r.key] || '' };
        });
        // дата «На кінець» — у шапці стовпця; під числом — лише в рядку, де вона інша
        const hday = rows.reduce((m, x) => (x.tday > m ? x.tday : m), '');
        rows.forEach((x) => { if (x.tday && x.tday !== hday) x.tnote = 'на ' + dmy(x.tday); });
        return { heads: true, rows, hday };
    }
    function feedHtml(editing) {                      // звідки звіти годівлі беруть поголів’я — видно всім
        const on = !!FEED.since;
        const txt = on
            ? (HSRC === 'bovio' ? `Звіти годівлі беруть ці числа з <b>${dmy(FEED.since)}</b>, раніші дні — з книги Excel.`
                : `Звіти годівлі беруть цю книгу лише для днів до <b>${dmy(FEED.since)}</b>, далі — поголів’я з Бовіо.`)
            : (HSRC === 'bovio' ? 'Звіти годівлі поки рахують поголів’я за книгою Excel.' : 'Звіти годівлі рахують поголів’я за цією книгою.');
        const btn = CAN && !editing && (on || FEED.first)
            ? ` <button type="button" class="mt-lnk mt-feedbtn">${on ? 'Повернути книгу Excel' : `Рахувати з Бовіо з ${dmy(FEED.first)}`}</button>` : '';
        return `<p class="mt-feed">${txt}${btn}</p>`;
    }
    function headsFootHtml() {
        if (!HEADS) return '';
        if (HEADS.error) return `<p class="mt-foot is-bad">${escapeHtml(HEADS.error)}</p>`;
        const end = by === 'month' ? 'місяця' : 'дня';
        if (HSRC === 'excel') return `<p class="mt-foot">Голів на кінець ${end} — з книги Excel, наживо.</p>`;
        const last = (HCFG && HCFG.last) || '';
        return `<p class="mt-foot">Голів на кінець ${end} — щоденний знімок реєстру за формулою рядка`
            + (FEED.first ? `, ведеться з ${dmy(FEED.first)}` : '')
            + (last ? `; останній — ${dmy(last)} о ${last.slice(11, 16)}` : '') + '.</p>';
    }
    function headsSectionHtml(t, tt, calc, editing) {
        const title = `<h3 class="mt-title${tt.style && tt.style.c ? ' mc-' + tt.style.c : ''}">${escapeHtml(t.title)}</h3>`;
        const head = editing
            ? `<div class="mt-head">${foldBtn(HID)}${title}`
                + '<button type="button" class="mr-style mt-tstyle" title="Вигляд таблиці: колір назви, смуга шапки, смуги рядків">Aa</button>'
                + undoBtn(HID) + '</div>'
            : `<div class="mt-head">${foldBtn(HID)}${title}${foldSumHtml(tt)}<span class="segmented mt-src" role="group" aria-label="Звідки числа">`
                + [['bovio', 'Бовіо'], ['excel', 'Excel']].map(([k, l]) => `<button type="button" class="seg-btn${HSRC === k ? ' is-active' : ''}" data-src="${k}">${l}</button>`).join('')
                + '</span>'
                + (HSRC === 'bovio' ? undoBtn(HID) : '')
                + (CAN && HSRC === 'excel' ? '<a class="mt-btn" href="/herd/structure" title="Книга Excel і відповідність її колонок">⚙ Джерело</a>' : '')
                + '</div>';
        return `<section class="mt mt-heads${editing ? ' is-edit' : ''}${foldCls(HID, editing)}${lookCls(tt.style)}" data-tid="${HID}">${head}${feedHtml(editing)}`
            + `<div class="mt-body">${editing ? EDIT_BODY : tableHtml(tt, calc)}</div>`
            + `<div class="mt-since">${sinceHtml(calc)}</div></section>`;
    }
    let CFG_OK = false;                               // таблиці прочитано — лише тоді можна зберігати
    /* Колонка назв однакової ширини в усіх таблицях панелі — місяці стоять один під одним
       (по місяцях — table-layout: fixed). Ширина — за найдовшою назвою, від 200 до 480 px. */
    function syncNameWidth() {
        let w = 200;
        box.querySelectorAll('.mv-table tbody tr:not(.mt-sep) > td.mv-name').forEach((td) => {
            const lab = td.querySelector('.mv-lab, .mb-sizer');
            if (!lab || !lab.textContent) return;
            const cs = getComputedStyle(td);
            const rg = document.createRange();
            rg.selectNodeContents(lab);
            let tw = rg.getBoundingClientRect().width + (parseFloat(getComputedStyle(lab).paddingRight) || 0);
            const mk = lab.classList.contains('mv-lab') && td.querySelector('.mv-mkb');   // кружечок перед назвою (у правці)
            if (mk) tw += mk.getBoundingClientRect().width + parseFloat(getComputedStyle(mk).marginRight || 0);
            w = Math.max(w, Math.ceil(tw + parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight) + 2));
        });
        box.style.setProperty('--mv-nw', Math.min(w, 480) + 'px');   // довша — з «…», уся — у підказці
        paintFoldAll();                                // зветься після кожного перемальовування таблиць
    }
    function render() {
        const all = CONFIG.concat([headsTable()]);
        const empty = CONFIG.length ? '' : `<p class="empty mv-empty">Таблиць руху ще немає${CAN ? ' — «+ таблиця» вгорі' : ''}.</p>`;
        // таблиця в правці не перебудовується: інакше поле назви у вибраному рядку втратило б фокус
        const keep = ED && ED.fx ? box.querySelector(`.mt[data-tid="${ED.tid}"]`) : null;
        if (keep) {
            [...box.children].forEach((el) => { if (el !== keep) el.remove(); });
            const before = [], after = [];
            let seen = false;
            all.forEach((t) => {
                if (t.id === ED.tid) seen = true;
                else if (seen) after.push(t);
                else before.push(t);
            });
            keep.insertAdjacentHTML('beforebegin', empty + before.map(sectionHtml).join(''));
            keep.insertAdjacentHTML('afterend', after.map(sectionHtml).join(''));
            refreshSoon();
            syncNameWidth();
            return;
        }
        box.innerHTML = empty + all.map(sectionHtml).join('');
        if (ED) { mountEditor(); refreshEdit(); }      // рядок формули вгорі живе далі — лише рядки таблиці
        syncNameWidth();
        paintBar();
    }

    let STALE_T = 0, STALE_N = 0;
    /* Смуга прогресу (Роман 2026-09-29): звіту ще немає — сервер рахує фоном і каже, скільки зроблено.
       p = null — відсотка ще немає (біжить відрізок). */
    function loadbarHtml(p, cap) {
        const pct = (p === null || p === undefined) ? null : Math.max(0, Math.min(100, Math.round(p * 100)));
        return `<div class="loadbar${pct === null ? ' is-ind' : ''}" role="progressbar" aria-valuemin="0" `
            + `aria-valuemax="100"${pct === null ? '' : ` aria-valuenow="${pct}"`} aria-label="Завантаження руху поголівʼя">`
            + `<div class="loadbar-track"><i style="width:${pct === null ? 35 : pct}%"></i></div>`
            + `<div class="loadbar-cap"><span>${escapeHtml(cap)}</span>${pct === null ? '' : `<b>${pct} %</b>`}</div></div>`;
    }
    let PROG_MAX = 0;                                  // смуга не повзе назад, навіть якщо сервер почав наново
    async function pollReport(my) {                    // лише звіт руху — решта вже прочитана
        const rep = await apiGet('/api/herd/move-report?' + rangeQuery()).catch(() => null);
        if (my !== seq) return;
        if (rep && rep.computing) {
            showProgress(rep, my);
            return;
        }
        load();                                        // готово — звичайне читання (з таблицями й поголів’ям)
    }
    function showProgress(rep, my) {
        PROG_MAX = Math.max(PROG_MAX, Number(rep.progress) || 0);
        box.innerHTML = loadbarHtml(PROG_MAX, rep.stage || 'Рахую рух поголівʼя');
        clearTimeout(STALE_T);
        STALE_T = setTimeout(() => { if (my === seq) pollReport(my); }, 700);
    }
    async function load() {
        const my = ++seq;
        seg.querySelectorAll('.seg-btn').forEach((b) => b.classList.toggle('is-active', b.dataset.by === by));
        label.textContent = by === 'month' ? String(year) : `${MONTHS_FULL[month - 1]} ${year}`;
        hideTip();
        const hwant = headsUrl();
        const hmy = ++HSEQ;                            // давніша відповідь поголів’я вже не потрібна
        const [cfg, rep, hd, hc] = await Promise.all([
            ED ? Promise.resolve(null) : apiGet('/api/herd/move-tables').catch(() => null),
            apiGet('/api/herd/move-report?' + rangeQuery()).catch(() => null),
            apiGet(hwant).catch(() => null),
            ED && ED.tid === HID ? Promise.resolve(null) : apiGet('/api/herd/heads/cols').catch(() => null)]);
        if (my !== seq) return;
        if (hmy === HSEQ) {                            // тим часом поголів’я перечитали — те новіше
            if (hwant === headsUrl()) takeHeads(hd);
            takeHcfg(hc);
        }
        if (cfg && cfg.ok !== false && Array.isArray(cfg.tables)) {
            // свіжі — зміни з іншої вкладки теж; нову, ще не збережену таблицю не губимо
            const fresh = CONFIG.filter((t) => t._new && !cfg.tables.some((x) => x.id === t.id));
            CONFIG = cfg.tables.concat(fresh);
            REVS = cfg.revs || {};
            SAMPLE = cfg.sample || [];
            CFG_OK = true;
        }
        if (addTableBtn) addTableBtn.disabled = !CFG_OK;
        if (rep && rep.computing) {                    // звіту ще немає — рахується фоном: смуга й перепитування
            if (ED) {                                   // у правці таблицю не чіпаємо — тихо перепитаємо
                clearTimeout(STALE_T);
                STALE_T = setTimeout(() => { if (my === seq) load(); }, 1500);
                return;
            }
            showProgress(rep, my);
            return;
        }
        PROG_MAX = 0;
        if (!CFG_OK || !rep || rep.ok === false) {
            if (ED) { if (window.toast) toast('Не вдалося перерахувати — спробуйте ще раз', 'error'); return; }
            // поголів'я для звітів годівлі від звіту руху не залежить — показуємо його й так
            REPORT = { periods: localPeriods(), tables: [] };
            box.innerHTML = `<p class="empty mv-empty">${escapeHtml((rep && rep.error) || 'Не вдалося прочитати рух — оновіть сторінку')}</p>`
                + sectionHtml(headsTable());
            syncNameWidth();
            paintBar();
            return;
        }
        REPORT = rep;
        histRestore();
        // дані тим часом змінились: сервер віддав останній звіт одразу, свіжий рахує фоном — перепитуємо тихо
        clearTimeout(STALE_T);
        if (rep.stale && STALE_N < 40) { STALE_N += 1; STALE_T = setTimeout(() => { if (my === seq) load(); }, 1500); }
        else STALE_N = 0;
        if (ED) { ED.prev = null; preview(); }
        render();
    }
    const rangeQuery = () => (by === 'month' ? `by=month&year=${year}` : `by=day&month=${year}-${pad(month)}`);
    function localPeriods() {                         // ті самі стовпці, що дає звіт руху
        if (by === 'month') return MONTHS.map((_, i) => `${year}-${pad(i + 1)}`);
        const n = new Date(year, month, 0).getDate();
        return Array.from({ length: n }, (_, i) => `${year}-${pad(month)}-${pad(i + 1)}`);
    }
    function headsUrl() {                             // поголівʼя на кінець кожного показаного місяця чи дня
        const from = by === 'month' ? `${year}-01-01` : `${year}-${pad(month)}-01`;
        const to = by === 'month' ? `${year}-12-31` : `${year}-${pad(month)}-${pad(new Date(year, month, 0).getDate())}`;
        return `${HSRC === 'bovio' ? '/api/herd/heads' : '/api/herd/daily'}?period=${by === 'month' ? 'month' : 'day'}`
            + `&today=1&from=${from}&to=${to}`;
    }
    function takeHeads(r) {
        if (!r || r.ok === false) {
            HEADS = { cols: (HEADS && HEADS.src === HSRC && HEADS.cols) || [], per: {}, src: HSRC,
                error: "Не вдалося прочитати поголів’я — оновіть сторінку" };
            return;
        }
        if (r.feed) FEED = r.feed;
        const per = {};
        (r.rows || []).forEach((x) => {
            const d = String(x.day || '').slice(0, 10);
            if (d) per[by === 'month' ? d.slice(0, 7) : d] = { day: d, values: x.values || {} };
        });
        HEADS = { src: HSRC, cols: r.cols || [], per, error: r.error || '' };
    }
    function takeHcfg(r) {
        if (!r || r.ok === false) return;
        HCFG = { cols: r.cols || [], errors: r.errors || {}, last: r.last || '', style: r.style || {}, rev: r.rev || '' };
        if (r.feed) FEED = r.feed;
    }
    let HSEQ = 0;
    async function loadHeads() {                      // лише поголівʼя: інше джерело, перемикання звітів, збереження
        const my = ++HSEQ, want = headsUrl();
        const [hd, hc] = await Promise.all([apiGet(want).catch(() => null),
            ED && ED.tid === HID ? Promise.resolve(null) : apiGet('/api/herd/heads/cols').catch(() => null)]);
        if (my !== HSEQ || want !== headsUrl()) return;
        takeHeads(hd);
        takeHcfg(hc);
        paintHeads();
    }
    function paintHeads() {                           // лише секція поголівʼя — таблицю руху в правці не чіпаємо
        const sec = box.querySelector(`.mt[data-tid="${HID}"]`);
        if (!sec || !REPORT) { if (REPORT) render(); return; }
        if (ED && ED.tid === HID) { refreshSoon(); return; }
        sec.outerHTML = sectionHtml(headsTable());
        syncNameWidth();
        paintBar();                                    // вибраний рядок поголів’я — нові числа й у рядку формули
    }
    function shift(delta) {
        if (by === 'month') year += delta;
        else {
            month += delta;
            if (month < 1) { month = 12; year -= 1; }
            if (month > 12) { month = 1; year += 1; }
        }
        load();
    }

    /* ── підказки: хто за числом, що рахує рядок, чому «—» ── */
    function placeTip(el) {
        tip.hidden = false;
        const b = el.getBoundingClientRect();
        const w = tip.offsetWidth, h = tip.offsetHeight;
        const x = Math.min(b.left, window.innerWidth - w - 8);
        let y = b.bottom + 6;
        if (y + h > window.innerHeight - 8) y = Math.max(8, b.top - h - 6);
        tip.style.left = Math.max(8, x) + 'px';
        tip.style.top = y + 'px';
    }
    function balanceLine(tid, r, p) {
        if (!r.bal) return '';
        const s = rowOf(tid, r.bal.s), i = rowOf(tid, r.bal.i), o = rowOf(tid, r.bal.o);
        const pick = (x) => (p === '*' ? x && x.total : x && (x.counts || {})[p]);
        const a = pick(s), b = pick(i), c = pick(o), e = p === '*' ? r.total : (r.counts || {})[p];
        if ([a, b, c, e].some((x) => x === null || x === undefined)) return '';
        const ok = a + b - c === e;
        return `<div class="tp-bal">${fmt(a)} + ${fmt(b)} − ${fmt(c)} = ${fmt(e)} ${ok ? '✓' : '✗'}</div>`;
    }
    function heads(n) {
        const a = Math.abs(Math.round(Number(n) || 0)), d = a % 10, h = a % 100;
        return d === 1 && h !== 11 ? 'голова' : (d >= 2 && d <= 4 && (h < 12 || h > 14) ? 'голови' : 'голів');
    }
    function rowTitle(tid, r) {                       // «Дійні › На кінець» — однакові назви в блоках
        const src = (ED && ED.tid === tid ? ED.draft : tableOf(tid)) || {};
        const rows = src.rows || [];
        const i = rows.findIndex((x) => x.id === r.id);
        let sep = '';
        for (let j = i - 1; j >= 0; j -= 1) if (rows[j].type === 'sep') { sep = rows[j].label || ''; break; }
        return (sep ? sep + ' › ' : '') + (r.label || '');
    }
    function showTip(btn) {
        const r = rowOf(btn.dataset.t, btn.dataset.r);
        if (!r) { hideTip(); return; }
        const p = btn.dataset.p;
        const items = p === '*' ? [] : ((r.cells || {})[p] || []);
        const MAX = 15;
        let html = `<div class="tp-h">${escapeHtml(rowTitle(btn.dataset.t, r))} · ${escapeHtml(periodName(p))}</div>`;
        if (btn.dataset.stock) {
            const day = (r.st || {})[p] === 'part' && r.tk === 'first' ? ' (з першого дня історії)' : '';
            const v = (r.counts || {})[p];
            html += balanceLine(btn.dataset.t, r, p)
                + `<div class="tp-more">${fmt(v)} ${heads(v)}${day} — клік покаже всіх</div>`;
        } else {
            html += items.slice(0, MAX).map((it) => `<div class="tp-i"><span class="tp-d">${dmy(it.date).slice(0, 5)}</span>`
                + `<b>${escapeHtml(it.tag || '')}</b>${it.name ? ' ' + escapeHtml(it.name) : ''}`
                + (it.note ? ` <span class="tp-d">· ${escapeHtml(it.note)}</span>` : '') + '</div>').join('')
                + (items.length > MAX ? `<div class="tp-more">… і ще ${items.length - MAX} — клік покаже всіх</div>` : '');
        }
        tip.innerHTML = html;
        placeTip(btn);
    }
    function showHeadsTip(el) {                       // поголів’я: скільки й на яку дату — переліку за минулі дні немає
        const c = rowOf(HID, el.dataset.r);
        if (!c) { hideTip(); return; }
        const p = el.dataset.p, v = (c.counts || {})[p], day = (c.days || {})[p];
        tip.innerHTML = `<div class="tp-h">${escapeHtml(c.label || '')} · ${escapeHtml(periodName(p))}</div>`
            + `<div class="tp-more">${fmt(v)} ${heads(v)}${day && day !== p ? ` на ${dmy(day)}` : ''} · `
            + `${HSRC === 'bovio' ? 'знімок реєстру' : 'з книги Excel'}</div>`;
        placeTip(el);
    }
    function headsWhy(p, rid) {
        if (HSRC === 'excel') return 'У книзі Excel за цей період чисел немає';
        const row = headsTable().rows.find((x) => x.id === rid);
        if (row && !row.formula) return 'У рядка ще немає формули';
        const first = FEED.first || '';
        if (!first) return 'Знімків поголів’я в Бовіо ще немає';
        if ((p.length === 7 ? p < first.slice(0, 7) : p < first)) return `Знімки поголів’я в Бовіо ведуться з ${dmy(first)}`;
        return by === 'month' ? 'За цей місяць знімка цього рядка немає' : 'Знімка цього рядка за цей день немає';
    }
    function showHeadsLabelTip(el) {
        const editing = !!(ED && ED.tid === HID);
        const row = ((editing ? ED.draft : headsTable()).rows || []).find((x) => x.id === el.dataset.r);
        if (!row) { hideTip(); return; }
        const what = FEED_KEYS[row.key];
        tip.innerHTML = `<div class="tp-h">${escapeHtml(row.label || '')}</div>`
            + (HSRC === 'excel' && !editing ? `<div class="tp-more">колонка книги Excel «${escapeHtml(row.key)}»</div>`
                : (row.formula ? `<div class="tp-fx">${window.herdQuery.highlight(row.formula, paramsList())}</div>`
                    : '<div class="tp-more">формули ще немає</div>'))
            + (what ? `<div class="tp-more">звідси звіти годівлі беруть ${what}</div>` : '')
            + (clickHint(HID) ? `<div class="tp-more">${clickHint(HID)}</div>` : '');
        placeTip(el);
    }
    function showLabelTip(el) {
        if (el.dataset.t === HID) { showHeadsLabelTip(el); return; }
        const r = rowOf(el.dataset.t, el.dataset.r);
        const src = (ED && ED.tid === el.dataset.t ? ED.draft : tableOf(el.dataset.t)) || {};
        const row = (src.rows || []).find((x) => x.id === el.dataset.r);
        if (!row || row.type === 'sep') { hideTip(); return; }
        tip.innerHTML = `<div class="tp-h">${escapeHtml(row.label || '')}</div>`
            + (row.formula ? `<div class="tp-fx">${window.herdQuery.highlight(row.formula, paramsList(), HL)}</div>`
                : '<div class="tp-more">формули ще немає</div>')
            + (r && r.desc ? `<div class="tp-more">${escapeHtml(r.desc)}</div>` : '')
            + (clickHint(el.dataset.t) ? `<div class="tp-more">${clickHint(el.dataset.t)}</div>` : '');
        placeTip(el);
    }
    const clickHint = (tid) => (canEdit(tid) ? 'клацніть — правити цей рядок' : '');
    function showWhy(el) {
        const sec = el.closest('.mt');
        if (sec && sec.dataset.tid === HID) {
            tip.innerHTML = `<div class="tp-more">${escapeHtml(headsWhy(el.dataset.p || '', el.dataset.r || ''))}</div>`;
            placeTip(el);
            return;
        }
        const calc = sec && calcOf(sec.dataset.tid);
        const s = calc && calc.since;
        tip.innerHTML = el.dataset.why === 'div0' ? '<div class="tp-more">ділення на нуль</div>'
            : `<div class="tp-more">${s ? `Групи рахуються з ${dmy(s)}: раніше історії в Бовіо немає` : 'Цей період поза межами історії'}</div>`;
        placeTip(el);
    }
    function hideTip() { tip.hidden = true; TIPEL = null; }
    // стовпець під курсором — його місяць (день) у шапці підсвічується
    let HCOL = null;
    function markCol(td) {
        const th = td && td.cellIndex > 0 && td.colSpan === 1 && td.closest('tbody')
            ? td.closest('table').tHead.rows[0].cells[td.cellIndex] : null;
        if (th === HCOL) return;
        if (HCOL) HCOL.classList.remove('is-hcol');
        HCOL = th;
        if (th) th.classList.add('is-hcol');
    }
    /* Після перемальовування рядків (Tab, перерахунок) браузер шле mouseover елементу під НЕРУХОМИМ курсором —
       підказка лягала б на вибраний рядок. Такий mouseover має ті самі координати, що й останній рух миші, —
       його пропускаємо; перший справжній рух над елементом (після прокрутки теж) підказку покаже. */
    let LX = null, LY = null, TIPEL = null;
    document.addEventListener('mousemove', (e) => { LX = e.clientX; LY = e.clientY; }, { passive: true, capture: true });
    const TIP_SEL = '.mv-n, .mv-hv, .mv-lab, .mv-na';
    function hoverAt(target) {
        markCol(target.closest('.mv-table td'));
        const el = target.closest(TIP_SEL);
        TIPEL = el;
        if (!el) return;
        if (el.classList.contains('mv-n')) showTip(el);
        else if (el.classList.contains('mv-hv')) showHeadsTip(el);
        else if (el.classList.contains('mv-lab')) showLabelTip(el);
        else showWhy(el);
    }
    box.addEventListener('mouseover', (e) => {
        if (e.clientX === LX && e.clientY === LY) return;
        hoverAt(e.target);
    });
    box.addEventListener('mousemove', (e) => {
        const el = e.target.closest(TIP_SEL);
        if (el && el !== TIPEL) hoverAt(e.target);
    }, { passive: true });
    box.addEventListener('mouseout', (e) => {
        if (!e.relatedTarget || !box.contains(e.relatedTarget)) markCol(null);
        const b = e.target.closest('.mv-n, .mv-hv, .mv-lab, .mv-na');
        if (b && !b.contains(e.relatedTarget)) hideTip();
    });
    window.addEventListener('scroll', hideTip, { passive: true });

    function listHtml(tid, r, p, items, dated) {
        return `<div class="mv-det-head"><b>${escapeHtml(r ? rowTitle(tid, r) : '')}</b>`
            + `<span class="text-mute">· ${escapeHtml(periodName(p))} · ${items.length}</span>`
            + '<button type="button" class="mv-x" title="Закрити">✕</button></div>'
            + '<div class="mv-det-list">' + items.map((it) => `<a class="mv-item" href="/herd/animals/${it.id}">`
                + (dated ? `<span class="mv-d">${dmy(it.date)}</span>` : '') + `<b>${escapeHtml(it.tag || '')}</b>`
                + (it.name ? `<span>${escapeHtml(it.name)}</span>` : '')
                + (it.note ? `<span class="mv-note">${escapeHtml(it.note)}</span>` : '') + '</a>').join('') + '</div>';
    }
    async function showCell(btn) {
        const sec = btn.closest('.mt');
        const det = sec.querySelector('.mv-det');
        const { t: tid, r: rid, p } = btn.dataset;
        const r = rowOf(tid, rid);
        box.querySelectorAll('.mv-n.is-open').forEach((x) => x.classList.remove('is-open'));
        box.querySelectorAll('.mv-det').forEach((d) => { if (d !== det) d.hidden = true; });
        btn.classList.add('is-open');
        det.hidden = false;
        if (!btn.dataset.stock) { det.innerHTML = listHtml(tid, r, p, (r && (r.cells || {})[p]) || [], true); return; }
        det.innerHTML = '<p class="text-mute" style="margin:4px 2px">Рахую…</p>';
        const body = { t: tid, r: rid, p, by, year, month: `${year}-${pad(month)}` };
        // збережена таблиця — GET (бачить і той, хто лише переглядає); чернетка — POST
        const res = await (ED && ED.tid === tid
            ? apiSend('/api/herd/move-cell', 'POST', Object.assign(body, { tables: [ED.draft] }))
            : apiGet('/api/herd/move-cell?' + new URLSearchParams(body).toString())).catch(() => null);
        if (!btn.classList.contains('is-open') || !btn.isConnected) { det.hidden = true; return; }
        det.innerHTML = res && res.ok !== false ? listHtml(tid, r, p, res.items || [], false)
            : '<p class="text-mute" style="margin:4px 2px">Не вдалося прочитати перелік</p>';
    }
    function closeCells() {
        box.querySelectorAll('.mv-det').forEach((d) => { d.hidden = true; });
        box.querySelectorAll('.mv-n.is-open').forEach((b) => b.classList.remove('is-open'));
    }

    /* ── правка (Роман 2026-09-28: «натиснув на показник — з ним працюю… не треба розкривати
       всі показники… таблиця в таблиці, замість того щоб зробити щось єдине»): таблиця та сама,
       що в перегляді; клік по рядку відкриває правку лише цього рядка — назва стає полем просто в
       ньому, під ним рядок формули з підсвіткою й підказками. Решта рядків — як були. ── */
    const paramsList = () => (VOCAB && VOCAB.params) || [];
    async function ensureVocab() {
        if (VOCAB) return VOCAB;
        const r = await apiGet('/api/herd/move-vocab').catch(() => null);
        VOCAB = (r && r.ok !== false) ? r : { events: [], reports: [], params: [], sections: [], consts: [] };
        window.HERD_CONSTS = window.HERD_CONSTS || VOCAB.consts || [];
        return VOCAB;
    }
    const draftRow = (rid) => ((ED && ED.draft.rows) || []).find((r) => r.id === rid);
    const secOf = () => (ED ? box.querySelector(`.mt[data-tid="${ED.tid}"]`) : null);
    // хто керує гілкою — править; поголів’я з книги Excel формул не має
    const canEdit = (tid) => CAN && (tid !== HID || (HSRC === 'bovio' && !!HCFG));
    /* щось змінено — лише тоді питаємо перед виходом і не пускаємо до іншої таблиці. Порівнюємо зміст, а не
       запис: обрізана формула, порожній стиль чи назва таблиці, що стала '', — не зміна. Набране в рядку
       формули, але ще не застосоване (без Enter), — зміна: інакше перехід до іншої таблиці мовчки його губив. */
    const styleKey = (st) => Object.keys(st || {}).filter((k) => st[k]).sort().map((k) => `${k}=${st[k]}`).join(';');
    const snapOf = (t) => JSON.stringify([String(t.title || ''), styleKey(t.style), (t.rows || []).map((r) =>
        [r.id, r.type || 'row', String(r.label || ''), String(r.formula || '').trim(), styleKey(r.style), r.key || ''])]);
    /* з 2.40.102 кожна застосована зміна одразу записується — «змінено» лише те, що ще не дійшло до сервера,
       і набране в рядку формули без Enter */
    const dirty = () => !!(ED && (ED.svT || ED.svBusy
        || (ED.fx && ED.mode === 'row' && ED.sel && ED.fx.get().trim() !== String(ED.base || '').trim())
        || (ED.fx && ED.mode === 'block' && ED.fx.get().trim())));
    function startEdit(tid, pick, where = '') {
        if (SAVING) return false;                      // іде збереження — відповідь сама перемалює таблиці
        if (ED && ED.tid !== tid) stopEdit();          // записане — записане, до іншої таблиці можна одразу
        if (ED) { selectRow(pick || null, !!pick, where); return true; }
        const hd = tid === HID;
        if (hd && (HSRC !== 'bovio' || !HCFG)) {       // без формул запис дав би порожні
            if (window.toast) toast('Рядки поголів’я ще не прочитано — оновіть сторінку', 'error');
            return false;
        }
        const t = tableOf(tid);
        if (!t) return false;
        ED = { tid, draft: clone(t), orig: snapOf(t), sent: snapOf(t), srv: t._new ? null : clone(t), prev: hd ? null : calcOf(tid), heads: hd, hnow: {},
            sel: null, base: '', lab0: '', mode: 'row', fx: null, selTr: null,
            // яку версію відкрили: тим часом її змінили — запис перепитає, а не затре мовчки
            rev: hd ? (HCFG && HCFG.rev) || '' : (t._new ? '' : REVS[tid] || '') };
        /* таблиця лишається там само на екрані: секція перебудовується (на мить коротша — сторінку
           могло «відкинути» вгору), а над нею зʼявляється рядок формули — прокрутку зсуваємо на різницю */
        const sq = () => box.querySelector(`.mt[data-tid="${CSS.escape(tid)}"]`);
        const top0 = sq().getBoundingClientRect().top;
        sq().outerHTML = sectionHtml(t);
        mountEditor();
        selectRow(pick || null, false);                // нічого не вибрано — вибирає людина кліком
        const dy = sq().getBoundingClientRect().top - top0;
        if (Math.abs(dy) > 1) window.scrollBy(0, dy);
        if (pick) focusSel(where);
        ensureVocab().then(() => { if (ED && ED.fx) ED.fx.repaint(); });
        if (hd) { HW = null; headsWorld().catch(() => {}); }   // свіжі панелі, списки й тварини — для «скільки зараз»
        return true;
    }
    function unmountEditor() {
        if (!ED) return;
        if (ED.fx) ED.fx.destroy();
        fxEd.innerHTML = '';
        ED.fx = ED.selTr = null;
    }
    function stopEdit() {
        if (!ED || SAVING) return;                     // прибирають таблицю — відповідь покаже, що лишилось
        const ed = ED;
        if (ed.svT) { clearTimeout(ed.svT); ed.svT = null; saveNow(ed); }   // відкладений запис — одразу
        unmountEditor();
        ED = null;
        closePop();
        CONFIG = CONFIG.filter((t) => !t._new || t.id !== ed.tid);   // нову, де так нічого й не назвали, — не пишемо
        box.innerHTML = '';
        if (ed.saved || ed.svBusy) load(); else render();   // записане — свіжі числа для перегляду
    }
    function closeRow() {                              // Esc удруге: рядок закрито, таблиця — знову перегляд
        selectRow(null, false);
        stopEdit();
    }
    function mountEditor() {                          // рядок формули вгорі: один на правку
        if (!ED || ED.fx) return;
        fxEd.innerHTML = '<div class="ed-fx"></div>';
        // поголівʼя пишеться мовою «Роботи зі стадом» (FILTER, [Панель]); рух — своєю (EVENT, START…)
        const lang = ED.heads
            ? { params: paramsList, groups: () => (VOCAB && VOCAB.sections) || [], items: headsFxItems, placeholder: HFX_PH }
            : { params: paramsList, groups: () => (VOCAB && VOCAB.sections) || [], acts: Object.keys(FUNCS), actHints: FUNCS,
                condActs: ['event', 'born', 'entry'], highlight: (txt) => window.herdQuery.highlight(txt, paramsList(), HL),
                items: moveItems, placeholder: FX_PH };
        ED.fx = window.herdFxEdit(fxEd.firstElementChild, Object.assign(lang, {
            onEnter: () => { applyFx(); persist(true); },   // Enter — і є збереження рядка
            onTab: (back) => { applyFx(true); stepRow(back ? -1 : 1); },
            onEscape: () => {
                if (ED.mode === 'block') { ED.insAt = null; selectRow(ED.sel, true); return; }
                if (ED.fx.get().trim() !== ED.base) { // як було до правки (підказки дописують пробіл)
                    ED.fx.set(ED.base);
                    const c = rowOf(ED.tid, ED.sel);
                    ED.fx.setError(c && c.err ? (c.epos || []) : null);
                    paintEd();
                    return;
                }
                closeRow();                            // ще раз — закрити рядок
            },
            onInput: () => { ED.fx.setError(null); },
        }));
        ED.fx.input.addEventListener('blur', () => {
            setTimeout(() => {                         // клік по підказці повертає фокус
                if (!ED || !ED.fx || document.activeElement === ED.fx.input) return;
                if (ED.mode === 'row') applyFx(true);
            }, 180);
        });
    }
    /* Поки кнопку миші тримають над таблицею, рядки не перемальовуємо: елемент під курсором зник би
       між натисканням і відпусканням, і клік загубився б (відповідь перерахунку, перепис назв). */
    let PRESS = 0, LATER = false;
    box.addEventListener('pointerdown', () => { PRESS = Date.now(); }, true);
    const release = () => {
        if (!PRESS) return;
        PRESS = 0;
        if (LATER) { LATER = false; setTimeout(refreshEdit, 0); }   // уже після кліку
    };
    window.addEventListener('pointerup', release, true);
    window.addEventListener('pointercancel', release, true);
    function refreshSoon() {
        if (PRESS && Date.now() - PRESS < 2000) { LATER = true; return; }
        refreshEdit();
    }
    function refreshEdit() {                          // числа й рядки — без перебудови поля, в якому пишуть
        const sec = secOf();
        if (!sec || !ED) return;
        const table = sec.querySelector('.mv-table');
        if (!table || table.tBodies.length < 3) return;
        const calc = calcOf(ED.tid);
        const periods = (REPORT && REPORT.periods) || [];
        const nowKey = by === 'month' ? todayKey.slice(0, 7) : todayKey;
        const byId = {};
        ((calc && calc.rows) || []).forEach((r) => { byId[r.id] = r; });
        table.classList.toggle('by-day', by === 'day');
        table.tHead.innerHTML = headHtml(periods, true, ED.heads ? (calc || {}) : null, ED.tid);
        const rows = ED.draft.rows || [];
        const i = ED.sel ? rows.findIndex((r) => r.id === ED.sel) : -1;
        const sel = ED.mode !== 'block' && i >= 0 ? rows[i] : null;
        const cut = i < 0 ? rows.length : (sel ? i : i + 1);
        const from = sel ? i + 1 : cut;
        const pos = rows.map((r, k) => posCls(rows, k));
        const html = (r, k) => rowHtml(ED.draft, r, byId[r.id] || {}, periods, nowKey, { editing: true, pos: pos[k] });
        const [tbA, tbEd, tbB] = table.tBodies;
        tbA.innerHTML = rows.length ? rows.slice(0, cut).map((r, k) => html(r, k)).join('')
            : `<tr class="no-line"><td class="empty" colspan="${periods.length + 2}">Рядків ще немає — `
                + '<button type="button" class="hc-add mt-add-row">+ рядок</button>'
                + (ED.heads ? '' : ' <button type="button" class="hc-add mt-add-sep">+ перегородка</button> '
                    + '<button type="button" class="hc-add mt-add-blk">+ рух групи</button>') + '</td></tr>';
        tbB.innerHTML = rows.slice(from).map((r, k) => html(r, from + k)).join('');
        // виділений рядок: вузол живе, доки рядок той самий, — поле назви не губить фокусу
        let st = ED.selTr;
        if (st && (!st.isConnected || !sel || st.dataset.rid !== sel.id || st.dataset.type !== (sel.type || 'row'))) {
            st.remove();
            st = null;
        }
        if (sel) {
            const c = byId[sel.id] || {};
            if (!st) {
                tbEd.insertAdjacentHTML('afterbegin', rowHtml(ED.draft, sel, c, periods, nowKey, { editing: true, sel: true, pos: pos[i] }));
                st = tbEd.firstElementChild;
                st.dataset.type = sel.type || 'row';
            } else {
                st.className = rowClass(sel, { sel: true, pos: pos[i] });
                [...st.cells].slice(1).forEach((td) => td.remove());
                st.insertAdjacentHTML('beforeend', cellsHtml(ED.draft, sel, c, periods, nowKey));
            }
        }
        ED.selTr = st;
        sec.querySelector('.mt-since').innerHTML = sinceHtml(calc);
        paintBar();
        syncNameWidth();
    }
    function selectRow(rid, focus = true, where = '') {
        if (!ED) return;
        hideTip();                                     // підказка з назви лягла б на рядок
        if (ED.sel && ED.sel !== rid) commitName();
        const r = rid ? draftRow(rid) : null;
        ED.mode = 'row';
        ED.sel = r ? r.id : null;
        ED.base = r && r.type !== 'sep' ? (r.formula || '') : '';
        ED.lab0 = r ? (r.label || '') : '';
        if (ED.fx) {
            ED.fx.set(ED.base);
            ED.fx.input.placeholder = ED.heads ? HFX_PH : FX_PH;
            const c = r && rowOf(ED.tid, r.id);
            ED.fx.setError(c && c.err ? (c.epos || []) : null);
            ED.fx.close();
        }
        refreshEdit();
        if (ED.heads && r) headsCount();
        if (!focus || !r) return;
        revealRow(ED.selTr);
        focusSel(where);
    }
    function focusSel(where) {                         // назва — у самому рядку, формула — у рядку формули вгорі
        const r = ED && draftRow(ED.sel);
        if (!r) return;
        const nm = ED.selTr && ED.selTr.querySelector('.mb-name');
        if (nm && (where === 'name' || r.type === 'sep' || !String(r.label || '').trim())) {
            nm.focus({ preventScroll: true });
            nm.setSelectionRange(nm.value.length, nm.value.length);
        } else if (ED.fx && r.type !== 'sep') { ED.fx.input.focus({ preventScroll: true }); ED.fx.close(); }
    }
    /* рядок таблиці — у видимій частині сторінки, а не під рядком формули, що стоїть угорі */
    function revealRow(tr, center) {
        if (!tr || !tr.isConnected) return;
        const b = tr.getBoundingClientRect();
        const top = (fxBar ? barTop() + fxBar.offsetHeight : 0) + 10, bottom = window.innerHeight - 12;
        let dy = 0;
        if (center) dy = b.top - (top + bottom - b.height) / 2;
        else if (b.top < top) dy = b.top - top;
        else if (b.bottom > bottom) dy = b.bottom - bottom;
        if (Math.abs(dy) > 1) window.scrollBy({ top: dy, behavior: center ? 'smooth' : 'auto' });
    }
    function stepRow(d) {
        if (!ED) return;
        const rows = ED.draft.rows || [];
        const i = rows.findIndex((r) => r.id === ED.sel);
        const j = Math.max(0, Math.min(rows.length - 1, i + d));
        if (rows[j]) selectRow(rows[j].id);
    }
    /* ↳ ПІДРЯДОК (Роман 2026-09-29: «як робити підгрупи?»): уточнення рядка вище — з відступом,
       тихіше, в одній смузі з ним. Раніше це була галочка «↳ відступ» в Aa, тепер — кнопка й Alt+→ / Alt+← */
    function indentSel(on) {
        const r = ED && draftRow(ED.sel);
        if (!r || r.type === 'sep') return;
        r.style = r.style || {};
        if (on) r.style.ind = 1; else delete r.style.ind;
        refreshEdit();
        persist();
    }
    function moveSel(d) {                              // ↑ ↓ і Alt+↑ ↓ — вибраний рядок вище чи нижче
        const rows = ED.draft.rows;
        const i = rows.findIndex((r) => r.id === ED.sel);
        const j = i + d;
        if (i < 0 || j < 0 || j >= rows.length) return;
        rows.splice(j, 0, rows.splice(i, 1)[0]);
        refreshEdit();
        revealRow(ED.selTr);
        persist();
    }
    /* ОДИН ФОРМАТ ФОРМУЛИ (Роман 2026-09-30: «строка формул у русі поголівʼя повинна завжди бути в одному
       форматі»): без «=» на початку, одинарні пробіли, біля > < = >= <= <> != — без пробілів, після «(» і перед
       «)» — без, слова мови перед «(» — великими, «…) СЛОВО(» — через один пробіл, + - * / поза дужками — з
       пробілами; [в дужках] і "в лапках" — як набрали. ⚠️ Та сама функція — herd_move.canon на сервері. */
    const CANON_WORDS = new Set(['event', 'filter', 'view', 'body', 'start', 'in', 'out', 'born', 'entry', 'herd']);
    function fxCanon(text) {
        let s = String(text == null ? '' : text).trim().replace(/^=\s*/, '');
        const skip = (str, i) => {                      // кінець [..] / ".." / '..' від i
            const c = str[i], close = c === '[' ? ']' : c;
            const e = str.indexOf(close, i + 1);
            return e < 0 ? str.length - 1 : e;
        };
        let out = '';
        for (let i = 0; i < s.length;) {
            const c = s[i];
            if (c === '[' || c === '"' || c === "'") { const e = skip(s, i); out += s.slice(i, e + 1); i = e + 1; continue; }
            if (/\s/.test(c)) { while (i < s.length && /\s/.test(s[i])) i += 1; out += ' '; continue; }
            out += c; i += 1;
        }
        const parts = out.split(/(\[[^\]]*\]?|"[^"]*"?|'[^']*'?)/);
        for (let k = 0; k < parts.length; k += 2) {
            let p = parts[k];
            p = p.replace(/\s*(>=|<=|<>|!=|=|>|<)\s*/g, '$1').replace(/\(\s+/g, '(').replace(/\s+\)/g, ')');
            p = p.replace(/\b([A-Za-z]+\d*)\s*\(/g, (m, w) =>
                (CANON_WORDS.has(w.replace(/\d+$/, '').toLowerCase()) ? w.toUpperCase() : w) + '(');
            p = p.replace(/\)\s*(?=[A-Za-zА-Яа-яІіЇїЄєҐґ\[])/g, ') ');
            parts[k] = p;
        }
        s = parts.join('');
        let res = '', depth = 0;
        for (let i = 0; i < s.length;) {
            const c = s[i];
            if (c === '[' || c === '"' || c === "'") { const e = skip(s, i); res += s.slice(i, e + 1); i = e + 1; continue; }
            if (c === '(') depth += 1;
            else if (c === ')') depth = Math.max(0, depth - 1);
            if (depth === 0 && '+-*/'.includes(c)) {
                const prev = res.trimEnd();
                const unary = !prev || '+-*/(='.includes(prev[prev.length - 1]);
                res = res.replace(/ +$/, '');
                res += unary ? (prev ? ' ' : '') + c : ' ' + c + ' ';
                i += 1;
                while (s[i] === ' ') i += 1;
                continue;
            }
            res += c; i += 1;
        }
        return res.replace(/ {2,}/g, ' ').trim();
    }
    function applyFx(quiet) {                          // набране в рядку формули → чернетка виділеного рядка
        if (!ED || !ED.fx) return;
        if (ED.mode === 'block') { addBlock(ED.fx.get()); return; }
        const r = draftRow(ED.sel);
        if (!r || r.type === 'sep') return;
        const v = fxCanon(ED.fx.get());
        if (v !== ED.fx.get()) ED.fx.set(v);            // застосоване — одразу в єдиному форматі
        ED.base = v;                                   // застосоване — Esc далі не відкочує
        if (ED.heads) { r.formula = v; headsCount(); persist(); return; }
        if (v === (r.formula || '') && ED.prev && quiet) return;
        r.formula = v;
        preview();
        persist();
    }

    /* ── рядок формули вгорі (Роман 2026-09-29): чий рядок, його формула, що він рахує. Є лише під час
       налаштування («верхня строка появляється тільки тоді, коли йде налаштування»); клік по показнику
       таблиці — сам вхід у правку. ── */
    const BAR_MODES = ['idle', 'none', 'ed', 'sep', 'block'];
    function barState() {
        if (!ED) return { mode: 'idle', tid: null, t: null, r: null };
        if (ED.mode === 'block') return { mode: 'block', tid: ED.tid, t: ED.draft, r: null };
        const r = ED.sel ? draftRow(ED.sel) : null;
        return { mode: r ? (r.type === 'sep' ? 'sep' : 'ed') : 'none', tid: ED.tid, t: ED.draft, r };
    }
    const phHtml = (txt) => `<div class="fxe fb-ph"><span>${txt}</span></div>`;
    /* смуга зʼявляється й зникає над таблицями — таблиця, з якою працюють, лишається на тому самому
       місці екрана (прокрутку зсуваємо на висоту смуги) */
    function showBar(on) {
        if (fxBar.hidden === !on) return;
        const a = [...box.querySelectorAll('.mt')].find((x) => x.getBoundingClientRect().bottom > 0);
        const y0 = a ? a.getBoundingClientRect().top : null;
        fxBar.hidden = !on;
        if (y0 === null || !a.isConnected) return;
        const dy = a.getBoundingClientRect().top - y0;
        if (Math.abs(dy) > 1) window.scrollBy(0, dy);
    }
    function paintBar() {
        if (!fxBar) return;
        const { mode, tid, r } = barState();
        BAR_MODES.forEach((m) => fxBar.classList.toggle('is-' + m, m === mode));
        // смуга стоїть завжди (для того, хто керує гілкою) — вхід у правку й вихід не зсувають сторінку
        // (Роман 2026-09-29: «залиш строку формул завжди активною, щоб екран не блимав вверх-вниз»)
        showBar(CAN);
        const live = mode === 'ed' || mode === 'block';
        fxEd.hidden = !live;
        fxRo.hidden = live;
        fxOps.hidden = !(mode === 'ed' || mode === 'sep');   // idle / none — лише підказка
        if (!fxOps.hidden) {
            const ind = fxOps.querySelector('.mr-ind');
            ind.hidden = mode === 'sep';
            fxOps.querySelector('.mr-copy').hidden = mode === 'sep';   // у перегородки формули немає
            ind.classList.toggle('is-on', !!(r && r.style && r.style.ind));
            ind.title = r && r.style && r.style.ind ? 'Зробити звичайним рядком (Alt+←)'
                : 'Зробити підрядком — уточненням рядка вище (Alt+→)';
            const del = fxOps.querySelector('.mr-del');
            const what = tid === HID && r && FEED_KEYS[r.key];
            del.disabled = !!what;
            del.title = what ? 'Цей рядок беруть звіти годівлі — прибрати не можна' : 'Прибрати рядок';
        }
        if (!live) {
            fxRo.innerHTML = phHtml(mode === 'sep' ? 'Перегородка — назва блоку на всю ширину таблиці; назву правте просто в рядку'
                : 'Клацніть рядок таблиці — його формула відкриється тут');
        }
        fxRes.className = 'fb-res';
        fxRes.innerHTML = '';                          // підказок під полем немає — лише помилка (Роман 2026-09-29)
        if (live) paintEd();
    }
    function paintEd() {                               // що під рядком формули: опис, число, помилка
        if (!ED) return;
        const res = fxRes;
        res.className = 'fb-res';
        if (ED.mode === 'block') {
            res.innerHTML = 'Група: <b>[Дійні]</b>, <b>FILTER(…)</b> або <b>HERD</b> — Enter додасть чотири рядки: '
                + 'на початок, надійшло, вибуло, на кінець · Esc — назад';
            return;
        }
        const r = draftRow(ED.sel);
        if (!r || r.type === 'sep') { res.innerHTML = ''; return; }
        if (ED.heads) { paintHeadsEd(res, r); return; }
        const c = rowOf(ED.tid, r.id);
        if (c && c.err) res.className = 'fb-res is-bad';
        // опису «що рахує · число · Разом» під полем немає (Роман 2026-09-29: «прибери цю підказку») — числа й так у рядку
        // таблиці, а що рахує — на підказці до назви; тут лише помилка
        res.innerHTML = c && c.err ? `⚠ ${escapeHtml(c.err)}` : '';
    }
    function paintHeadsEd(res, r) {                   // поголів’я: скільки голів зараз за цією формулою
        const what = FEED_KEYS[r.key];
        const tail = what ? ` · звідси звіти годівлі беруть ${what}` : '';
        res.className = 'fb-res';
        if (!String(r.formula || '').trim()) {
            res.innerHTML = 'Хто в групі — мовою «Роботи зі стадом»: <b>FILTER(lact&gt;0 rc&lt;6)</b> або панель «Огляду» '
                + `<b>[Дійні]</b> · Enter — порахувати${tail}`;
            return;
        }
        const n = ED.hnow[r.id];
        if (!n || n.f !== r.formula) { res.innerHTML = `<span class="text-mute">рахую…</span>${tail}`; return; }
        if (n.err) { res.className = 'fb-res is-bad'; res.innerHTML = `⚠ ${escapeHtml(n.err)}`; return; }
        const c = rowOf(HID, r.id);
        const snap = c && c.total !== null && c.total !== undefined && c.tday ? ` · на ${dmy(c.tday)}: <b>${fmt(c.total)}</b>` : '';
        res.innerHTML = `Зараз за цією формулою: <b>${fmt(n.v)}</b> ${heads(n.v)}${snap}${tail}`;
    }
    function pickRow(tid, rid, where) {                // клік по показнику: правка цієї таблиці з цим рядком
        hideTip();
        if (!canEdit(tid)) return;                     // формулу видно й на підказці до назви
        if (startEdit(tid, rid, where)) revealRow(ED && ED.selTr);
    }
    async function headsCount() {                     // Enter, вибір рядка — рахуємо «зараз» у браузері
        if (!ED || !ED.heads) return;
        const ed = ED, r = draftRow(ED.sel);
        if (!r) return;
        const f = String(r.formula || '').trim();
        const had = ed.hnow[r.id];
        if (!f || (had && had.f === f && !had.tmp)) { paintEd(); return; }
        paintEd();                                     // «рахую…»
        const got = await headsNow(f).catch(() => ({ err: 'не вдалося порахувати', tmp: 1 }));
        // формулу тим часом змінили — рахує новіший виклик, цей результат уже не про неї
        if (ED !== ed || String(r.formula || '').trim() !== f) return;
        ed.hnow[r.id] = Object.assign({ f }, got);    // tmp — збій читання: наступного разу — ще раз
        if (ed.sel === r.id) paintEd();
    }
    function headsWorld() {                           // панелі й списки — щоб «[Дійні]» розгорталось, як на «Огляді»
        if (!HW) {
            HW = (async () => {
                const [tl, wl] = await Promise.all([apiGet('/api/herd/overview-tiles').catch(() => null),
                    apiGet('/api/herd/work-lists').catch(() => null), ensureVocab()]);
                if (!tl || tl.ok === false || !wl || wl.ok === false) {
                    HW = null;                          // не прочиталось — наступний підрахунок спробує знову
                    throw new Error('panels');
                }
                const w = { tiles: tl.tiles || [], lists: wl.lists || [], items: [], keys: null };
                window.herdPanels.use({ lists: () => w.lists, tiles: () => w.tiles, params: paramsList });
                return w;
            })();
        }
        return HW;
    }
    async function headsNow(formula) {                // той самий модуль, що рахує панелі «Огляду»
        const w = await headsWorld().catch(() => null);
        if (!w) return { err: 'не вдалося прочитати панелі й списки', tmp: 1 };
        const keys = new Set();
        window.herdPanels.fxAllParts(formula).forEach((part) => {
            const fx = window.herdPanels.fxSides(part);
            if (fx.error) return;
            fx.sides.forEach((x) => {
                const q = window.herdQuery.parse(x, paramsList());
                if (!q.error) (q.keys || []).forEach((k) => keys.add(k));
            });
        });
        if (!w.keys || [...keys].some((k) => !w.keys.has(k))) {
            const all = new Set([...(w.keys || []), ...keys]);
            const q = new URLSearchParams({ lean: '1', status: 'active' });
            if (all.size) q.set('params', [...all].join(','));
            const r = await apiGet('/api/herd/animals?' + q.toString()).catch(() => null);
            if (!r || r.ok === false) return { err: 'не вдалося прочитати стадо', tmp: 1 };
            w.items = r.items || [];
            w.keys = all;
        }
        const r = window.herdPanels.ovCountOn(formula, w.items);
        if (r === null || r === undefined) return { err: 'порожньо' };
        if (typeof r === 'string') return { err: r };
        return r.err ? { err: r.err } : { v: r.v };
    }
    /* «[» поза дією — панелі «Огляду» й списки (решту підказує рядок формули сам) */
    function headsFxItems(ctx, left) {
        if (ctx || left.lastIndexOf('[') <= left.lastIndexOf(']')) return null;
        const from = left.lastIndexOf('[') + 1;
        const q = left.slice(from).toLowerCase();
        const list = ((VOCAB && VOCAB.reports) || []).filter((x) => !q || x.name.toLowerCase().includes(q))
            .map((x) => ({ ins: x.name + '] ', w: x.name, t: x.kind, k: 'p' }))
            .sort((a, b) => (Number(!a.w.toLowerCase().startsWith(q)) - Number(!b.w.toLowerCase().startsWith(q)))
                || (a.w.length - b.w.length));
        return { from, list };
    }
    let PSEQ = 0;
    let CALC_T = 0;
    async function preview() {
        if (!ED) return;
        if (ED.heads) { headsCount(); return; }
        const my = ++PSEQ;
        const ed = ED;
        syncHead();
        const body = { tables: [ED.draft], by, year, month: `${year}-${pad(month)}` };
        // довше за мить — числа вибраного рядка тьмяніють і в «Разом» стоїть «рахую…» (Роман 2026-09-29): видно, що
        // нове число ще йде, а не що старе — правильне
        clearTimeout(CALC_T);
        CALC_T = setTimeout(() => { const sc = secOf(); if (sc && ED === ed && my === PSEQ) sc.classList.add('is-calc'); }, 150);
        const r = await apiSend('/api/herd/move-preview', 'POST', body).catch(() => null);
        if (my === PSEQ) {
            clearTimeout(CALC_T);
            box.querySelectorAll('.mt.is-calc').forEach((x) => x.classList.remove('is-calc'));
        }
        if (my !== PSEQ || !ED || ED !== ed) return;
        if (!r || r.ok === false) { if (window.toast) toast((r && r.error) || 'Не вдалося порахувати', 'error'); return; }
        ED.prev = (r.tables || [])[0] || null;
        refreshSoon();
        const c = rowOf(ED.tid, ED.sel);
        if (ED.fx && ED.mode === 'row') ED.fx.setError(c && c.err ? (c.epos || []) : null);
    }
    function syncHead() {
        const sec = secOf();
        if (!sec || !ED) return;
        const ti = sec.querySelector('.mt-title-in');
        if (ti) ED.draft.title = ti.value;
    }
    let SAVING = false;
    /* Запис із перевіркою версії: тим часом цю таблицю змінили (інша вкладка, інший компʼютер, сценарій) —
       сервер відповідає conflict, і ми перепитуємо, а не затираємо мовчки (Роман 2026-09-29). */
    async function sendChecked(url, body) {
        let r = await apiSend(url, 'POST', body).catch(() => null);
        if (r && r.conflict) {
            const ok = await confirmAction(`${r.error}. Записати вашу версію поверх? Інакше таблиця покаже свіжу версію.`,
                { ok: 'Записати поверх' });
            if (!ok) return { ok: false, cancelled: true };
            r = await apiSend(url, 'POST', Object.assign({}, body, { force: 1 })).catch(() => null);
        }
        return r;
    }
    /* ЗАПИС БЕЗ «ГОТОВО» (Роман 2026-09-29: «кнопки Скасувати, Готово прибрати. Натискання на Enter і є
       збереження налаштування строки»). Кожна застосована зміна — Enter у формулі чи назві, Tab, ↑ ↓ ✕ ↳, вигляд,
       рух групи — одразу на сервер (кліки поспіль — один запит, по черзі). Рядок без назви ще не пишемо: він лишається
       в чернетці, доки його не назвуть. Версію таблиці тримаємо свіжою (ed.rev) — чужа правка тим часом перепитає. */
    function persist(now) {
        if (!ED || !CAN) return;
        const ed = ED;
        clearTimeout(ed.svT);
        ed.svT = setTimeout(() => { ed.svT = null; saveNow(ed); }, now ? 0 : 300);
    }
    const namedRows = (ed) => (ed.draft.rows || []).filter((r) => r.type === 'sep' || String(r.label || '').trim());
    async function saveNow(ed) {
        if (ed.svBusy) { ed.svAgain = true; return; }
        if (!ed.heads && !CFG_OK) return;
        const rows = namedRows(ed);
        const snap = snapOf(Object.assign({}, ed.draft, { rows }));
        if (snap === ed.sent && !(ed.draft._new && ed.tpl)) return;   // нічого нового
        ed.svBusy = true;
        ed.svAgain = false;
        let r;
        if (ed.heads) {
            const cols = rows.map((x) => ({ key: x.key || '', label: String(x.label || '').trim(),
                formula: String(x.formula || '').trim(), style: x.style || {} }));
            r = await sendChecked('/api/herd/heads/cols', { cols, style: ed.draft.style || {}, rev: ed.rev });
        } else {
            // лише свою таблицю — сервер кладе її в ТЕПЕРІШНІЙ перелік: чужі зміни в інших таблицях цілі
            const table = Object.assign({}, ed.draft, { rows });
            delete table._new;
            r = await sendChecked('/api/herd/move-tables', { table, rev: ed.rev });
        }
        ed.svBusy = false;
        if (!r || r.ok === false) {
            if (r && r.cancelled) {                    // не записали поверх — показуємо свіже
                if (ED === ed) { unmountEditor(); ED = null; closePop(); }
                box.innerHTML = '';
                load();
                return;
            }
            if (window.toast) toast((r && r.error) || 'Не вдалося зберегти', 'error');
            return;
        }
        ed.saved = true;
        ed.sent = snap;
        ed.tpl = false;
        if (snap !== ed.undoSnap) pushHist(ed.tid, ed.srv);   // повернене кроком «↩» у стос не кладемо
        ed.undoSnap = '';
        ed.srv = clone(Object.assign({}, ed.draft, { rows }));
        delete ed.srv._new;
        if (ed.heads) {
            takeHcfg(r);
            rows.forEach((x, i) => { const c = (r.cols || [])[i]; if (c && !x.key) x.key = c.key; });   // ключ нового — від сервера
            ed.rev = (HCFG && HCFG.rev) || '';
            loadHeads();                               // знімок на сьогодні сервер уже перерахував
        } else {
            const saved = (r.tables || []).find((t) => t.id === ed.draft.id);
            let moved = false;
            if (saved) rows.forEach((x, i) => {        // сервер міг дати рядку інший id
                const y = saved.rows[i];
                if (y && y.id !== x.id) { if (ed.sel === x.id) ed.sel = y.id; x.id = y.id; moved = true; }
            });
            const keepNew = CONFIG.filter((x) => x._new && x.id !== ed.draft.id && !(r.tables || []).some((y) => y.id === x.id));
            CONFIG = (r.tables || []).concat(keepNew);
            REVS = r.revs || REVS;
            ed.rev = REVS[ed.draft.id] || '';
            delete ed.draft._new;
            if (moved && ED === ed) refreshSoon();
        }
        histSave();
        if (ed.svAgain) { saveNow(ed); return; }
        if (ED !== ed) { if (!ED) box.innerHTML = ''; load(); }   // правку вже закрили — показуємо записане
    }
    async function feedSwitch(btn) {                  // звідки звіти годівлі беруть поголів’я
        const on = !!FEED.since;
        const ok = await confirmAction(on
            ? 'Звіти годівлі знову рахуватимуть поголів’я з книги Excel — за всі дні.'
            : `Звіти годівлі рахуватимуть поголів’я з Бовіо з ${dmy(FEED.first)}: «Рух годівлі», «Огляд годівлі», сайт аналітики й оберти залу в боті. Раніші дні — як і досі, з книги Excel.`,
        { ok: on ? 'Повернути книгу' : 'Рахувати з Бовіо', okClass: 'btn-primary' });
        if (!ok) return;
        btn.disabled = true;
        const r = await apiSend('/api/herd/heads/feed', 'POST', { src: on ? 'excel' : 'bovio' }).catch(() => null);
        btn.disabled = false;
        if (!r || r.ok === false) { if (window.toast) toast((r && r.error) || 'Не вдалося перемкнути', 'error'); return; }
        FEED = r.feed || FEED;
        HSRC = FEED.since ? 'bovio' : 'excel';        // показуємо те, чим тепер рахуються звіти
        try { localStorage.setItem(HSRC_KEY, HSRC); } catch (e) { /* ignore */ }
        paintHeads();
        loadHeads();
    }
    function newId() { nid += 1; return 'n' + Date.now().toString(36) + nid; }
    function insertAfterSel(items) {
        const rows = ED.draft.rows;
        if (ED.insAt !== undefined && ED.insAt !== null) {   // місце вибрали «+» між рядками
            rows.splice(Math.min(ED.insAt, rows.length), 0, ...items);
            ED.insAt = null;
            return;
        }
        const i = rows.findIndex((r) => r.id === ED.sel);
        rows.splice(i < 0 ? rows.length : i + 1, 0, ...items);
    }
    function addBlock(text) {
        const g = String(text || '').trim();
        if (!g) return;
        const nm = g.toUpperCase() === 'HERD' ? 'Усе стадо' : (g.match(/^\[([^\]]+)\]$/) || [null, 'Група'])[1];
        const items = [
            { id: newId(), type: 'sep', label: nm, style: {} },
            { id: newId(), type: 'row', label: 'На початок', formula: `START(${g})`, style: {} },
            { id: newId(), type: 'row', label: 'Надійшло', formula: `IN(${g})`, style: { b: 1 } },
            { id: newId(), type: 'row', label: 'Вибуло', formula: `OUT(${g})`, style: { b: 1 } },
            { id: newId(), type: 'row', label: 'На кінець', formula: g, style: { b: 1 } },
        ];
        insertAfterSel(items);
        selectRow(items[2].id);
        preview();
        persist(true);
    }

    /* свої підказки рядка формули руху: функції, групи, події, поля події */
    function moveItems(ctx, left, word) {
        const at = left.length;
        const lw = (word || '').toLowerCase();
        const inBr = left.lastIndexOf('[') > left.lastIndexOf(']');
        const V = VOCAB || { events: [], reports: [] };
        const starts = (s) => String(s || '').toLowerCase().startsWith(lw);
        // спершу те, що починається з набраного, далі — що містить; коротші вище
        const rank = (q) => (a, b) => (Number(!a.w.toLowerCase().startsWith(q)) - Number(!b.w.toLowerCase().startsWith(q)))
            || (a.w.length - b.w.length);
        const groupItems = (w) => {
            const q = (w || '').toLowerCase();
            return (V.reports || []).filter((x) => !q || x.name.toLowerCase().includes(q))
                .map((x) => ({ ins: x.name + '] ', w: x.name, t: x.kind, k: 'p' })).sort(rank(q));
        };
        const rowItems = (w) => {
            const q = (w || '').toLowerCase();
            return ((ED && ED.draft.rows) || []).filter((r) => r.type !== 'sep' && r.id !== (ED && ED.sel) && r.label
                && (!q || r.label.toLowerCase().includes(q)))
                .map((r) => ({ ins: r.label + '] ', w: r.label, t: 'рядок цієї таблиці', k: 'v' })).sort(rank(q));
        };
        const grpHead = [{ ins: 'HERD ', w: 'HERD', t: 'усе стадо', k: 'w' },
            { ins: '[', w: '[', t: 'панель «Огляду» чи список', k: 'b' },
            { ins: 'FILTER(', w: 'FILTER(', t: 'своя умова мовою списків: FILTER(lact>0 rc<6)', k: 'a' }]
            .filter((x) => !lw || x.w.toLowerCase().startsWith(lw));
        // FILTER(…) одразу після EVENT(…) — умови цієї події: підказки ті самі, що всередині EVENT після назви
        const fm = /\bEVENT\s*\(([^()]*)\)(?:\s*(?:FILTER|VIEW)\s*\([^()]*\))*\s*FILTER\s*\(([^()]*)$/i.exec(left);
        const m = fm ? null : left.match(/(\b(?:EVENT|BORN|ENTRY|START|IN|OUT)\s*\()([^()]*)$/i);
        const fn = fm ? 'EVENT' : (m ? m[1].replace(/\s*\($/, '').toUpperCase() : '');
        const inside = fm ? fm[1] + ' ' + fm[2] : (m ? m[2] : '');
        if (inBr) {
            const from = left.lastIndexOf('[') + 1;
            const w = left.slice(from);
            if (!ctx) return { from, list: rowItems(w).concat(groupItems(w)) };
            if (['start', 'in', 'out'].includes(ctx) && !/[<>=]\s*\[[^\]]*$/.test(left.replace(/(from|to)=\s*\[[^\]]*$/i, ''))) {
                return { from, list: groupItems(w) };
            }
            return null;                               // значення чи параметр — як у списках
        }
        // EVENT(…) / BORN() / ENTRY() — далі FILTER(…) з умовами (як BODY(…) FILTER(…) у «Роботі зі стадом»)
        const flowEnd = /\b(?:EVENT|BORN|ENTRY)\s*\([^()]*\)(?:\s*(?:FILTER|VIEW)\s*\([^()]*\))*\s*([A-Za-z]*)$/i.exec(left);
        const filt = { ins: 'FILTER(', w: 'FILTER(', t: 'кого рахувати: FILTER(lact>0), FILTER(lact=1), FILTER(exit_way=Продаж)', k: 'a' };
        const view = { ins: 'VIEW(', w: 'VIEW(', t: 'що рахувати з подій: VIEW(avg milk/lkd), VIEW(sum weight), VIEW(max fat)', k: 'a' };
        if ((!ctx || ctx === 'in' || ctx === 'out') && flowEnd) {
            const list = [filt, view].filter((x) => !lw || x.w.toLowerCase().startsWith(lw));
            if (list.length) return { from: at - word.length, list: list.concat(lw ? [] : [{ ins: '+ ', w: '+', t: 'далі — арифметика з рядків', k: 'w' }]) };
        }
        // VIEW(…) після події: функція й поле; період у таблиці — її стовпці
        if (/^(view|відображення|вигляд)$/.test(ctx || '') && /\b(?:EVENT|BORN|ENTRY)\s*\(/i.test(left)) {
            if (/(?:^|[\s(])(avg|sum|min|max|cnt|середнє|сума|мін|макс)\s+[^\s()]*$/i.test(left)) {
                const ps = paramsList();
                const sh = (p) => (p.short || p.key || '').trim() || p.label;
                return { from: at - word.length, list: ps.filter((p) => !lw || starts(sh(p)) || starts(p.label))
                    .slice(0, 40).map((p) => ({ ins: sh(p) + ' ', w: sh(p), t: p.label, k: 'p' })) };
            }
            return { from: at - word.length, list: [['avg', 'середнє поля'], ['sum', 'сума поля'], ['min', 'найменше'],
                ['max', 'найбільше'], ['cnt', 'кількість (поле — де воно заповнене)']]
                .filter(([w]) => !lw || w.startsWith(lw)).map(([w, t]) => ({ ins: w + ' ', w, t, k: 'w' })) };
        }
        if (!ctx) {
            // після готового доданка далі — знак (+ − * /), а не нова функція
            if (!lw && /(\)|\]|\bHERD|\d)\s*$/i.test(left)) return { from: at, list: [] };
            const list = Object.keys(FUNCS).filter((w) => starts(w))
                .map((w) => ({ ins: w + '(', w: w + '(', t: FUNCS[w], k: 'a' }))
                .concat(grpHead);
            return { from: at - word.length, list };
        }
        if (fn === 'EVENT') {
            // спершу — назва події: для формул (calving) чи українська (буває з кількох слів)
            const raw = inside.replace(/^\s+/, '');
            const q = raw.toLowerCase().replace(/[ʼ’]/g, "'");
            const names = (e) => [e.en, e.name, e.key].filter(Boolean).map((x) => x.toLowerCase().replace(/[ʼ’]/g, "'"));
            const evRef = (e) => e.en || (/[\s()]/.test(e.name) ? `[${e.name}]` : e.name);
            const named = (V.events || []).find((e) => names(e).some((n) => q.startsWith(n + ' ') || q.startsWith('[' + n + ']')));
            if (!named && !/[<>=]/.test(raw)) {
                const qq = q.replace(/^\[/, '');
                // назву події одразу закриваємо дужкою — далі підкаже FILTER(…); дужка вже є — не дублюємо
                const inp = ED && ED.fx && ED.fx.input;
                const right = inp ? inp.value.slice(inp.selectionStart === null ? inp.value.length : inp.selectionStart) : '';
                const tail = /^\s*\)/.test(right) || fm ? ' ' : ') ';
                const list = (V.events || []).filter((e) => !qq || names(e).some((n) => n.startsWith(qq)))
                    .map((e) => ({ ins: evRef(e) + tail, w: e.en || e.name, t: e.en ? e.name : 'подія', k: 'e' }));
                return { from: at - raw.length, list };
            }
            if (/[<>=]\s*[^\s]*$/.test(left) || /\s(between|contains)\s+\S*$/i.test(left)) return null;
            const ev = named;
            const own = ev ? ev.fields || [] : [];
            const ps = paramsList();
            const sh = (p) => (p.short || p.key || '').trim() || p.label;
            const flags = ev && ev.key === 'calving' ? [{ ins: 'first ', w: 'first', t: 'лише перший отел', k: 'w' }]
                : ev && ev.key === 'birth' ? [{ ins: 'alive ', w: 'alive', t: 'лише живі', k: 'w' },
                    { ins: 'dead ', w: 'dead', t: 'лише мертвонароджені', k: 'w' },
                    { ins: 'gndr=', w: 'gndr=', t: 'стать: F — телички, M — бички', k: 'p' }] : [];
            const ownItems = ps.filter((p) => own.includes(p.key) && (!lw || starts(sh(p)) || starts(p.label)))
                .map((p) => ({ ins: sh(p), w: sh(p), t: p.label + ' — поле події', k: 'p' }));
            const stItems = ps.filter((p) => !own.includes(p.key) && (!lw || starts(sh(p)) || starts(p.label)))
                .slice(0, 30).map((p) => ({ ins: sh(p), w: sh(p), t: p.label + ' — стан тварини напередодні', k: 'p' }));
            return { from: at - word.length, list: flags.filter((x) => !lw || starts(x.w)).concat(ownItems, stItems) };
        }
        if (fn === 'BORN' && !/[<>=]\s*\S*$/.test(left)) {
            const list = [{ ins: 'dead ', w: 'dead', t: 'мертвонароджені', k: 'w' }, { ins: 'all ', w: 'all', t: 'живі й мертві', k: 'w' },
                { ins: 'gndr=', w: 'gndr=', t: 'стать: F — телички, M — бички', k: 'p' }].filter((x) => !lw || starts(x.w));
            return { from: at - word.length, list };
        }
        if (['START', 'IN', 'OUT'].includes(fn)) {
            const after = inside.match(/(?:^|\s)(from|to|by)=\s*(\S*)$/i);
            if (after) {
                const list = after[1].toLowerCase() === 'by'
                    ? ['EVENT'].filter((w) => !lw || starts(w)).map((w) => ({ ins: w + '(', w: w + '(', t: FUNCS[w], k: 'a' }))
                    : grpHead;
                return { from: at - word.length, list };
            }
            const hasGroup = /(\]|HERD|\))\s+\S*$/i.test(inside);
            if (!hasGroup) return { from: at - word.length, list: grpHead };
            if (fn === 'START') return { from: at, list: [] };
            const nm = fn === 'IN' ? 'from=' : 'to=';
            const list = [{ ins: nm, w: nm, t: fn === 'IN' ? 'звідки: хто напередодні був у цій групі' : 'куди: хто того ж дня опинився в цій групі', k: 'w' },
                { ins: 'by=', w: 'by=', t: 'через що: подія того ж дня — by=EVENT(calving)', k: 'w' }].filter((x) => !lw || starts(x.w));
            return { from: at - word.length, list };
        }
        return null;
    }

    /* «+» між рядками (Роман 2026-09-29: «при наведенні з лівої частини таблиці між двома показниками треба висвітлювати
       плюс, щоб вставити строку з показником»): біля лівого краю, на межі двох рядків — «+» і лінія, куди ляже рядок;
       клік — таблиця в правці, новий рядок саме тут, курсор у його назві */
    const insBtn = document.createElement('button');
    insBtn.type = 'button';
    insBtn.className = 'mv-ins';
    insBtn.textContent = '+';
    insBtn.title = 'Вставити рядок сюди';
    insBtn.hidden = true;
    const insLine = document.createElement('div');
    insLine.className = 'mv-insline';
    insLine.hidden = true;
    document.body.append(insBtn, insLine);
    let INS = null;
    const insHide = () => { insBtn.hidden = true; insLine.hidden = true; INS = null; };
    const rowsOf = (tid) => (ED && ED.tid === tid ? ED.draft.rows : ((tableOf(tid) || {}).rows || []));
    box.addEventListener('mousemove', (e) => {
        if (DRAG && DRAG.on) return;                   // лінію зараз показує перетягування
        if (!CAN || SAVING || (ED && ED.mode === 'block')) { insHide(); return; }
        const tr = e.target.closest('tbody tr[data-rid]');
        const sec = tr && tr.closest('.mt');
        const tid = sec && sec.dataset.tid;
        if (!tr || !canEdit(tid)) { insHide(); return; }
        const td = tr.querySelector('td');
        const tl = td.getBoundingClientRect().left;
        const rc = tr.getBoundingClientRect();
        if (e.clientX - tl > 18) { insHide(); return; }
        const rows = rowsOf(tid);
        const i = rows.findIndex((r) => r.id === tr.dataset.rid);
        if (i < 0) { insHide(); return; }
        let y, at;
        if (e.clientY - rc.top <= 8) { y = rc.top; at = i; }
        else if (rc.bottom - e.clientY <= 8) { y = rc.bottom; at = i + 1; }
        else { insHide(); return; }
        INS = { tid, at };
        const tw = Math.min(sec.getBoundingClientRect().right, window.innerWidth) - tl;
        insBtn.style.left = (tl + 1) + 'px';
        insBtn.style.top = (y - 8) + 'px';
        insLine.style.left = (tl + 18) + 'px';
        insLine.style.top = (y - 1) + 'px';
        insLine.style.width = Math.max(0, tw - 18) + 'px';
        insBtn.hidden = false;
        insLine.hidden = false;
    });
    box.addEventListener('mouseleave', (e) => { if (e.relatedTarget !== insBtn) insHide(); });
    insBtn.addEventListener('mouseleave', (e) => { if (!box.contains(e.relatedTarget)) insHide(); });
    window.addEventListener('scroll', insHide, true);
    insBtn.addEventListener('mousedown', (e) => e.preventDefault());
    /* клік по «+» — що вставити: рядок, перегородку чи рух групи (Роман 2026-09-29: «при створенні рядка одразу вказати
       + рядок, + перегородка, + рух групи, а не вгорі в шапці таблиці»); поголівʼя — лише рядок */
    const insMenu = document.createElement('div');
    insMenu.className = 'mv-pop mv-insmenu';
    insMenu.hidden = true;
    insMenu.innerHTML = '<button type="button" data-add="row"><b>+</b> рядок</button>'
        + '<button type="button" data-add="sep"><b>+</b> перегородка</button>'
        + '<button type="button" data-add="blk"><b>+</b> рух групи</button>';
    document.body.appendChild(insMenu);
    let INS_AT = null;
    const insMenuHide = () => { insMenu.hidden = true; INS_AT = null; };
    function insertAt(ins, kind) {
        closePop();
        if (ED && ED.tid !== ins.tid) stopEdit();
        if (!ED && !startEdit(ins.tid, null, '')) return;
        applyFx(true);
        if (kind === 'blk') {                          // рух групи — як і доти: група в рядку формули, Enter — чотири рядки
            commitName();
            ED.insAt = ins.at;
            ED.mode = 'block';
            ED.fx.set('');
            ED.fx.setError(null);
            ED.fx.input.placeholder = '[Дійні], FILTER(…) або HERD — Enter додасть чотири рядки';
            refreshEdit();
            ED.fx.focus();
            return;
        }
        const item = { id: newId(), type: kind === 'sep' ? 'sep' : 'row', label: '', style: {} };
        if (kind !== 'sep') item.formula = '';
        if (ED.heads) item.key = '';                   // ключ дасть сервер
        ED.draft.rows.splice(Math.min(ins.at, ED.draft.rows.length), 0, item);
        selectRow(item.id, true, 'name');              // новий — спершу назва, Enter — до формули
    }
    insBtn.addEventListener('click', () => {
        const ins = INS;
        if (!ins) return;
        const heads = ins.tid === HID;
        const r = insBtn.getBoundingClientRect();
        insHide();
        if (heads) { insertAt(ins, 'row'); return; }
        INS_AT = ins;
        insMenu.hidden = false;
        const w = insMenu.offsetWidth, h = insMenu.offsetHeight;
        insMenu.style.left = Math.max(8, Math.min(r.right + 6, window.innerWidth - w - 8)) + 'px';
        insMenu.style.top = Math.max(8, Math.min(r.top - 6, window.innerHeight - h - 8)) + 'px';
    });
    insMenu.addEventListener('click', (e) => {
        const b = e.target.closest('button[data-add]');
        if (!b || !INS_AT) return;
        const ins = INS_AT;
        insMenuHide();
        insertAt(ins, b.dataset.add);
    });
    document.addEventListener('mousedown', (e) => { if (!insMenu.hidden && !insMenu.contains(e.target)) insMenuHide(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !insMenu.hidden) { insMenuHide(); e.stopPropagation(); } }, true);
    /* права кнопка миші по рядку — вікно вигляду рядка (Роман 2026-09-29): у перегляді таблиця спершу переходить у правку
       з цим рядком (як лівий клік), далі — те саме вікно, що й кружечок біля назви. Хто лише переглядає — звичайне меню */
    box.addEventListener('contextmenu', (e) => {
        const tr = e.target.closest('tbody tr[data-rid]');
        const sec = e.target.closest('.mt');
        if (!tr || !sec || e.target.closest('input, textarea')) return;
        const tid = sec.dataset.tid, rid = tr.dataset.rid;
        if (!canEdit(tid)) return;
        const r = (ED && ED.tid === tid ? draftRow(rid) : ((tableOf(tid) || {}).rows || []).find((x) => x.id === rid));
        if (!r || r.type === 'sep') return;
        e.preventDefault();
        openPop(tr.querySelector('.mv-mkb') || tr, rid, tid);
    });
    box.addEventListener('click', async (e) => {
        const mkb = e.target.closest('.mv-mkb');       // кружечок біля назви — усе налаштування вигляду рядка
        if (mkb) {
            e.preventDefault();
            if (Date.now() - DRAG_END < 300) return;   // це було перетягування, а не клік
            if (mkb.classList.contains('is-sep')) return;   // кружечок перегородки лише тягнуть
            const tid = mkb.closest('.mt').dataset.tid;
            if (POP && POP.rid === mkb.dataset.r && POP.tid === tid && !pop.hidden) closePop();
            else openPop(mkb, mkb.dataset.r, tid);
            return;
        }
        const n = e.target.closest('.mv-n');
        if (n) {
            let btn = n;
            if (ED && ED.tid === n.dataset.t && n.dataset.r !== ED.sel) {
                applyFx(true);
                selectRow(n.dataset.r, false);
                // рядок перемальовано — та сама клітинка вже інша кнопка
                btn = secOf().querySelector(`.mv-n[data-r="${CSS.escape(n.dataset.r)}"][data-p="${n.dataset.p}"]`) || n;
            }
            if (btn.classList.contains('is-open')) closeCells(); else showCell(btn);
            return;
        }
        if (e.target.closest('.mv-x')) { closeCells(); return; }
        const sec = e.target.closest('.mt');
        if (!sec) return;
        const tid = sec.dataset.tid;
        const srcBtn = e.target.closest('.mt-src .seg-btn');
        if (srcBtn) {
            if (srcBtn.dataset.src === HSRC) return;
            HSRC = srcBtn.dataset.src;
            try { localStorage.setItem(HSRC_KEY, HSRC); } catch (er) { /* ignore */ }
            paintHeads();                              // кнопки нового джерела, числа — щойно прочитаються
            loadHeads();
            return;
        }
        if (e.target.closest('.mt-feedbtn')) { feedSwitch(e.target.closest('.mt-feedbtn')); return; }
        if (e.target.closest('.mt-fold') || (e.target.closest('h3.mt-title') && !(ED && ED.tid === tid))) { toggleFold(tid); return; }
        if (!ED || ED.tid !== tid) {                   // клік по показнику — його формула в рядку формули вгорі
            const tr = e.target.closest('tbody tr[data-rid]');
            // з перегляду клік — одразу в рядок формули (назву правлять уже потім, клацнувши по ній)
            if (tr && !e.target.closest('a, button, input')) pickRow(tid, tr.dataset.rid, '');
            return;
        }
        if (e.target.closest('.mt-drop')) {
            if (SAVING || !CFG_OK) return;
            const ok = await confirmAction(`Прибрати таблицю «${ED.draft.title || ''}» разом з усіма її рядками?`, { ok: 'Прибрати' });
            if (!ok || !ED) return;
            clearTimeout(ED.svT);
            ED.svT = null;
            const isNew = !!(tableOf(tid) || {})._new && !ED.saved;
            SAVING = true;
            const r = isNew ? { ok: true, tables: CONFIG.filter((t) => t.id !== tid), revs: REVS }   // ще не збережена
                : await sendChecked('/api/herd/move-tables', { drop: tid, rev: ED.rev });
            SAVING = false;
            if (!ED) return;
            if (!r || r.ok === false) { if (r && r.cancelled) return; if (window.toast) toast((r && r.error) || 'Не вдалося', 'error'); return; }
            CONFIG = r.tables || [];
            REVS = r.revs || REVS;
            unmountEditor();
            ED = null;
            paintBar();
            box.innerHTML = '';
            load();
            return;
        }
        if (e.target.closest('.mt-tstyle')) { syncHead(); openPop(e.target.closest('.mt-tstyle'), '__title'); return; }
        if (e.target.closest('.mt-add-row') || e.target.closest('.mt-add-sep')) {
            applyFx(true);
            const sep = !!e.target.closest('.mt-add-sep');
            const item = { id: newId(), type: sep ? 'sep' : 'row', label: '', style: {} };
            if (!sep) item.formula = '';
            if (ED.heads) item.key = '';               // ключ дасть сервер
            insertAfterSel([item]);
            selectRow(item.id, true, 'name');          // новий — спершу назва, Enter — до формули
            return;
        }
        if (e.target.closest('.mt-add-blk')) {
            applyFx(true);
            commitName();
            ED.mode = 'block';
            ED.fx.set('');
            ED.fx.setError(null);
            ED.fx.input.placeholder = '[Дійні], FILTER(…) або HERD — Enter додасть чотири рядки';
            refreshEdit();
            ED.fx.focus();
            return;
        }
        const tr = e.target.closest('tbody.mv-tb tr[data-rid]');
        if (tr) {                                      // клік по назві — правимо назву, по числах — формулу
            applyFx(true);
            selectRow(tr.dataset.rid, true, e.target.closest('td.mv-name') ? 'name' : '');
            return;
        }
        if (e.target.closest('tr.is-sel') && !e.target.closest('input') && ED.fx && ED.mode === 'row') {
            const r = draftRow(ED.sel);
            if (r && r.type !== 'sep') ED.fx.focus();
        }
    });
    function setName(nm, v) {                          // назва в чернетці й мірило ширини колонки
        const r = draftRow(ED.sel);
        if (r) r.label = v;
        if (nm.value !== v) nm.value = v;
        const sz = nm.parentNode.querySelector('.mb-sizer');
        if (sz) sz.textContent = v;
    }
    box.addEventListener('input', (e) => {
        if (!ED) return;
        const nm = e.target.closest('.mb-name');
        if (nm) setName(nm, nm.value);
    });
    const normL = (x) => String(x || '').toLowerCase().replace(/[ʼ’]/g, "'").split(/\s+/).filter(Boolean).join(' ');
    function renameRowRefs(f, oldL, newL) {
        /* «[стара назва]» у місці числа → «[нова]»; у дужках функцій (START, EVENT…) —
           це групи чи значення умов, їх не чіпаємо */
        const key = normL(oldL);
        let out = '', i = 0;
        const stack = [];
        while (i < f.length) {
            const c = f[i];
            if (c === '[') {
                const k = f.indexOf(']', i + 1);
                if (k < 0) { out += f.slice(i); break; }
                const nm = f.slice(i + 1, k);
                out += !stack.some(Boolean) && normL(nm) === key ? `[${newL}]` : f.slice(i, k + 1);
                i = k + 1;
                continue;
            }
            if (c === '(') stack.push(/[\wА-Яа-яЇїІіЄєҐґ]\s*$/.test(out));
            else if (c === ')') stack.pop();
            out += c;
            i += 1;
        }
        return out;
    }
    function commitName() {                           // назву дописано: «[стара]» в інших рядках → «[нова]»
        if (!ED || !ED.sel) return;
        const r = draftRow(ED.sel);
        const old = ED.lab0, now = r ? (r.label || '') : '';
        ED.lab0 = now;
        persist();                                     // назва — одразу на сервер (перепис посилань — тим самим записом)
        if (ED.heads || !r || r.type === 'sep' || !old || !now.trim() || normL(old) === normL(now)) return;
        let hit = 0;
        (ED.draft.rows || []).forEach((x) => {
            if (x === r || x.type === 'sep' || !x.formula) return;
            const f2 = renameRowRefs(x.formula, old, now);
            if (f2 !== x.formula) { x.formula = f2; hit += 1; }
        });
        if (hit) preview();                            // рядки формул не показують — досить перерахунку
    }
    box.addEventListener('change', (e) => {
        if (!ED) return;
        if (e.target.closest('.mb-name')) commitName();
        if (e.target.closest('.mt-title-in')) { syncHead(); persist(); }
    });
    box.addEventListener('keydown', (e) => {
        if (!ED) return;
        const nm = e.target.closest('.mb-name');
        if (nm && e.key === 'Tab' && !e.altKey && !e.ctrlKey && !e.metaKey) {
            e.preventDefault();                         // Tab — наступний рядок і з назви, і з перегородки
            commitName();
            applyFx(true);
            stepRow(e.shiftKey ? -1 : 1);
            return;
        }
        if (nm && e.key === 'Enter') {                 // Enter — назву записано; далі — формула
            e.preventDefault();
            commitName();
            persist(true);
            const r = draftRow(ED.sel);
            if (r && r.type !== 'sep' && ED.fx) ED.fx.focus();
            return;
        }
        if (nm && e.key === 'Escape') {                // як було; ще раз — закрити рядок
            e.preventDefault();
            const r = draftRow(ED.sel);
            if (r && nm.value !== ED.lab0) { setName(nm, ED.lab0); return; }
            closeRow();
            return;
        }
        if (e.key === 'Enter' && e.target.closest('.mt-title-in')) { e.preventDefault(); syncHead(); persist(true); e.target.blur(); return; }
        if (e.altKey && (e.key === 'ArrowRight' || e.key === 'ArrowLeft') && e.target.closest('.mv-edtb')) {
            e.preventDefault();
            indentSel(e.key === 'ArrowRight');
            return;
        }
        if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown') && e.target.closest('.mv-edtb')) {
            e.preventDefault();
            moveSel(e.key === 'ArrowUp' ? -1 : 1);
        }
    });

    /* рядок формули вгорі: ↑ ↓ ✕ Aa вибраного рядка; клік по назві рядка — показати його в таблиці */
    /* скопіювати формулу (Роман 2026-09-29): те, що зараз у рядку формули, — у буфер обміну */
    async function copyFx(btn) {
        const txt = ED && ED.fx ? ED.fx.get().trim() : '';
        if (!txt) { if (window.toast) toast('Формули немає — нема чого копіювати', 'error'); return; }
        let ok = false;
        try { await navigator.clipboard.writeText(txt); ok = true; } catch (e) { /* немає доступу — запасний шлях */ }
        if (!ok) {
            const ta = document.createElement('textarea');
            ta.value = txt;
            ta.setAttribute('readonly', '');
            ta.style.cssText = 'position:fixed;left:-9999px;top:0';
            document.body.appendChild(ta);
            ta.select();
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            ta.remove();
            if (ED && ED.fx) ED.fx.focus();
        }
        if (window.toast) toast(ok ? 'Формулу скопійовано' : 'Не вдалося скопіювати — виділіть формулу й натисніть Ctrl+C', ok ? 'success' : 'error');
        if (ok && btn) { btn.classList.add('is-done'); setTimeout(() => btn.classList.remove('is-done'), 1200); }
    }
    fxBar.addEventListener('click', (e) => {
        if (e.target.closest('.mr-copy')) { copyFx(e.target.closest('.mr-copy')); return; }
        if (!ED) return;
        const rows = ED.draft.rows;
        const i = rows.findIndex((r) => r.id === ED.sel);
        if (i < 0) return;
        if (e.target.closest('.mr-del')) {
            const what = ED.heads && FEED_KEYS[rows[i].key];
            if (what) {                                // звіти годівлі без нього зламались би
                if (window.toast) toast(`З рядка «${rows[i].label || ''}» звіти годівлі беруть ${what} — його не прибрати; назву й формулу змінити можна`, 'error');
                return;
            }
            rows.splice(i, 1);
            const next = rows[Math.min(i, rows.length - 1)];
            ED.sel = null;                             // прибраний — посилань на нього не переписуємо
            selectRow(next ? next.id : null, false);
            preview();
            persist();
            return;
        }
        if (e.target.closest('.mr-ind')) { indentSel(!(rows[i].style && rows[i].style.ind)); return; }
        if (e.target.closest('.mr-up')) { moveSel(-1); return; }
        if (e.target.closest('.mr-down')) { moveSel(1); return; }
        if (e.target.closest('.mr-style')) openPop(e.target.closest('.mr-style'), ED.sel);
    });
    fxBar.addEventListener('keydown', (e) => {
        if (ED && ED.mode === 'row' && e.altKey && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')
            && !(ED.fx && ED.fx.isOpen())) {
            e.preventDefault();
            indentSel(e.key === 'ArrowRight');
            return;
        }
        if (ED && ED.mode === 'row' && e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')
            && !(ED.fx && ED.fx.isOpen())) {
            e.preventDefault();
            moveSel(e.key === 'ArrowUp' ? -1 : 1);
        }
    });
    /* де «прилипає» рядок формули: під самим верхом вікна, а на телефоні — під шапкою застосунку (вона там
       теж липка). Висота обох — щоб рядок таблиці, до якого гортаємо, не ховався під ними; тінь — коли прилип. */
    const topbar = document.querySelector('.topbar');
    let BAR_TOP = -1, BAR_IO = null;
    const barTop = () => (topbar && getComputedStyle(topbar).position === 'sticky' ? topbar.offsetHeight : 0);
    function placeBar() {
        const t = barTop();
        document.documentElement.style.setProperty('--fxbar-h', (t + fxBar.offsetHeight) + 'px');
        if (t === BAR_TOP) return;
        BAR_TOP = t;
        fxBar.style.top = (t - 1) + 'px';
        if (!window.IntersectionObserver) return;
        if (BAR_IO) BAR_IO.disconnect();
        BAR_IO = new IntersectionObserver(([en]) => { fxBar.classList.toggle('is-stuck', en.intersectionRatio < 1); },
            { threshold: [1], rootMargin: `${-t}px 0px 0px 0px` });
        BAR_IO.observe(fxBar);
    }
    placeBar();
    if (window.ResizeObserver) {
        const ro = new ResizeObserver(placeBar);
        ro.observe(fxBar);
        if (topbar) ro.observe(topbar);
    }
    window.addEventListener('resize', placeBar);

    /* ── Aa: колір, фон, шрифт і розмір рядка (маленьке вікно поруч) ── */
    // кружечок кольору в переліках (Aa і мітка): none — «без смуги», порожнє — «як звичайно»
    const palDot = (key, v) => (v === 'none' ? '<i class="pp-dot is-off"></i>' : !v ? '<i class="pp-dot is-none"></i>'
        : `<i class="pp-dot ${key === 'c' ? 'mc-x mc-' : 'mb-x mb-'}${v}"></i>`);
    /* вікно вигляду — ліворуч біля рядка (Роман 2026-09-29), а не біля кнопки: видно, чий це вигляд.
       Ліворуч не влазить — під рядком, від його лівого краю */
    function anchorOf(rid, tid) {
        const sec = tid ? box.querySelector(`.mt[data-tid="${CSS.escape(tid)}"]`) : secOf();
        if (!sec) return null;
        if (rid === '__title') return sec.querySelector('.mt-title-in, h3.mt-title');
        return sec.querySelector(`tr[data-rid="${CSS.escape(rid)}"] > td.mv-name`);
    }
    function placeNear(el, anchor) {
        const a = anchor.getBoundingClientRect();
        const w = el.offsetWidth, h = el.offsetHeight;
        let x = a.left - w - 8, y = a.top;
        if (x < 8) { x = Math.max(8, Math.min(a.left, window.innerWidth - w - 8)); y = a.bottom + 6; }
        if (y + h > window.innerHeight - 8) y = Math.max(8, window.innerHeight - h - 8);
        el.style.left = x + 'px';
        el.style.top = Math.max(8, y) + 'px';
    }
    let POP = null, POP_DD = '';                         // POP_DD — який спадний список кольорів розгорнуто
    /* вікно вигляду рядка: кожна зміна одразу в таблиці й одразу записується (Роман 2026-09-29). У правці — через
       чернетку таблиці (persist), поза нею — «швидко» (quickSave) */
    function popTarget(p) {
        if (!p.quick) return p.rid === '__title' ? ED.draft : draftRow(p.rid);
        if (p.tid === HID) return ((HCFG && HCFG.cols) || []).find((c) => c.key === p.rid) || null;
        const t = CONFIG.find((x) => x.id === p.tid);
        return t ? (t.rows || []).find((r) => r.id === p.rid) || null : null;
    }
    function openPop(btn, rid, tid) {
        tid = tid || (ED && ED.tid) || '';
        const quick = !(ED && ED.tid === tid);
        if (!quick && !ED) return;
        if (quick && (!canEdit(tid) || rid === '__title')) return;
        const p = { rid, btn, tid, quick };
        const target = popTarget(p);
        if (!target) return;
        const isTitle = rid === '__title';
        target.style = target.style || {};
        if (!POP || POP.rid !== rid || POP.tid !== tid) POP_DD = '';   // інший рядок — списки кольорів згорнуті
        POP = p;
        const st = target.style;
        /* колір — спадним списком: «кружечок · назва» (Роман 2026-09-29: «більше кольорів методом спливаючого
           списку» + скрін крапки з Конструктора параметрів — «зробити таким принципом») */
        const dot = palDot;
        const dd = (key, noneLabel, extra) => {
            const v = st[key] || '';
            const name = v === 'none' ? 'Без смуги' : v ? (PAL_NAME[v] || v) : noneLabel;
            const item = (val, label) => `<button type="button" data-k="${key}" data-v="${val}" class="${v === val ? 'is-on' : ''}">`
                + `${dot(key, val)}<span>${escapeHtml(label)}</span></button>`;
            const open = POP_DD === key;
            return `<div class="pp-dd${open ? ' is-open' : ''}" data-dd="${key}">`
                + `<button type="button" class="pp-ddbtn" aria-expanded="${open}">${dot(key, v)}<span class="pp-cv">${escapeHtml(name)}</span><span class="pp-ch">▾</span></button>`
                + `<div class="pp-ddlist"${open ? '' : ' hidden'}>${item('', noneLabel)}${extra ? item('none', extra) : ''}`
                + PALETTE.map(([k, l]) => item(k, l)).join('') + '</div></div>';
        };
        pop.innerHTML = `<div class="pp-l">${isTitle ? 'Колір назви' : 'Колір тексту'}</div>${dd('c', 'Як звичайно')}`
            + (isTitle ? '<div class="pp-l">Смуга шапки з датами</div>' + dd('hb', 'Колір гілки', 'Без смуги')
                : '<div class="pp-l">Фон</div>' + dd('bg', 'Без фону')
                + '<div class="pp-l">Шрифт</div><div class="pp-row">'
                + `<button type="button" data-k="b" class="${st.b ? 'is-on' : ''}"><b>Ж</b> жирний</button>`
                + `<button type="button" data-k="i" class="${st.i ? 'is-on' : ''}"><i>К</i> курсив</button>`
                + `<button type="button" data-k="ind" class="${st.ind ? 'is-on' : ''}">↳ відступ</button></div>`
                + '<div class="pp-l">Розмір</div><div class="pp-row">'
                + SIZES.map(([v, l]) => `<button type="button" data-k="s" data-v="${v}" class="${(st.s || '') === v ? 'is-on' : ''}">${l}</button>`).join('') + '</div>');
        pop.hidden = false;
        placeNear(pop, anchorOf(rid, tid) || btn);
    }
    function closePop() { pop.hidden = true; POP = null; POP_DD = ''; }
    /* «швидкий» вигляд — запис кожної зміни (кліки поспіль зводяться в один запит): рух — лише ця таблиця з відбитком
       версії, поголівʼя — його рядки (знімок сервер не перераховує: змінився лише вигляд) */
    const QS = {};
    function quickSave(tid, reload) {
        clearTimeout(QS[tid]);
        QS[tid] = setTimeout(async () => {
            delete QS[tid];
            let r;
            if (tid === HID) {
                if (!HCFG) return;
                const cols = (HCFG.cols || []).map((c) => ({ key: c.key, label: c.label, formula: c.formula || '', style: c.style || {} }));
                r = await sendChecked('/api/herd/heads/cols', { cols, style: HCFG.style || {}, rev: HCFG.rev || '' });
                if (r && r.ok !== false) { takeHcfg(r); histSave(); if (reload) loadHeads(); return; }
            } else {
                const t = CONFIG.find((x) => x.id === tid);
                if (!t) return;
                const table = Object.assign({}, t);
                delete table._new;
                r = await sendChecked('/api/herd/move-tables', { table, rev: REVS[tid] || '' });
                if (r && r.ok !== false) {
                    const keepNew = CONFIG.filter((x) => x._new && !(r.tables || []).some((y) => y.id === x.id));
                    CONFIG = (r.tables || []).concat(keepNew);
                    REVS = r.revs || REVS;
                    histSave();
                    if (reload && !ED) { box.innerHTML = ''; load(); } else if (reload) load();   // формули змінились — свіжі числа
                    return;
                }
            }
            if (r && r.cancelled) { closePop(); load(); return; }   // не записали — показуємо свіже
            if (window.toast) toast((r && r.error) || 'Не вдалося зберегти вигляд', 'error');
        }, reload ? 0 : 350);
    }
    /* крок назад: правка відкрита — у чернетку й одразу записати; ні — просто в таблиці й записати */
    function undoTable(tid) {
        const h = HIST[tid];
        if (!h || !h.length || SAVING) return;
        closePop();
        const snap = h.pop();
        paintUndo(tid);
        if (ED && ED.tid === tid) {
            clearTimeout(ED.svT);
            ED.svT = null;
            const keep = ED.sel;
            ED.draft = Object.assign(clone(snap), { id: ED.draft.id });
            ED.sel = null;
            ED.lab0 = '';
            const sec = secOf();
            const ti = sec && sec.querySelector('.mt-title-in');
            if (ti) { ti.value = ED.draft.title || ''; ti.className = 'mt-title-in' + (ED.draft.style && ED.draft.style.c ? ' mc-' + ED.draft.style.c : ''); }
            if (sec) {
                [...sec.classList].filter((c) => /^hb-/.test(c)).forEach((c) => sec.classList.remove(c));
                lookCls(ED.draft.style).trim().split(/\s+/).filter(Boolean).forEach((c) => sec.classList.add(c));
            }
            selectRow(keep && draftRow(keep) ? keep : null, false);
            if (!ED.heads) preview();
            ED.undoSnap = snapOf(Object.assign({}, ED.draft, { rows: namedRows(ED) }));
            saveNow(ED);
            return;
        }
        if (tid === HID) {
            if (!HCFG) return;
            HCFG.cols = (snap.rows || []).map((x) => ({ key: x.key, label: x.label, formula: x.formula || '', style: x.style || {} }));
            HCFG.style = snap.style || {};
        } else {
            const i = CONFIG.findIndex((t) => t.id === tid);
            if (i < 0) return;
            CONFIG[i] = clone(snap);
        }
        render();
        quickSave(tid, true);
    }
    box.addEventListener('click', (e) => {
        const u = e.target.closest('.mt-undo');
        if (u) { e.stopPropagation(); undoTable(u.dataset.undo); }
    }, true);
    /* Ctrl+Z (⌘Z) — той самий крок назад. У полі з незаписаним набраним — звичайне «назад» самого поля */
    document.addEventListener('keydown', (e) => {
        if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey || e.code !== 'KeyZ') return;
        const el = document.activeElement;
        if (el && el.matches && el.matches('input, textarea')) {
            if (!el.closest('#mvTables, #mvFx')) return;
            if (ED && ED.fx && el === ED.fx.input && ED.fx.get().trim() !== String(ED.base || '').trim()) return;
            if (ED && el.matches('.mb-name') && el.value !== ED.lab0) return;
            if (ED && el.matches('.mt-title-in') && el.value !== (ED.draft.title || '')) return;
        }
        const tid = ED ? ED.tid : HIST_LAST;
        if (!tid || !(HIST[tid] || []).length) return;
        e.preventDefault();
        undoTable(tid);
    });

    /* ПЕРЕТЯГУВАННЯ РЯДКА ЗА КРУЖЕЧОК (Роман 2026-09-29): тягнеш вище чи нижче — лінія показує, куди ляже; головний
       рядок їде разом зі своїми ↳ підрядками. Клік без руху — як і доти, вікно вигляду. */
    let DRAG = null, DRAG_END = 0;
    function moveGroup(rows, rid, at) {
        const i = rows.findIndex((r) => r.id === rid);
        if (i < 0) return false;
        let n = 1;
        if (rows[i].type === 'sep') {                  // перегородка — з усім блоком до наступної
            while (rows[i + n] && rows[i + n].type !== 'sep') n += 1;
        } else if (!(rows[i].style && rows[i].style.ind)) {
            while (rows[i + n] && rows[i + n].type !== 'sep' && rows[i + n].style && rows[i + n].style.ind) n += 1;
        }
        if (at >= i && at <= i + n) return false;      // на своє ж місце
        const part = rows.splice(i, n);
        rows.splice(at > i ? at - n : at, 0, ...part);
        return true;
    }
    box.addEventListener('pointerdown', (e) => {
        const mkb = e.target.closest('.mv-mkb');
        if (!mkb || e.button !== 0) return;
        const sec = mkb.closest('.mt');
        if (!sec || !canEdit(sec.dataset.tid) || SAVING) return;
        DRAG = { tid: sec.dataset.tid, rid: mkb.dataset.r, y: e.clientY, on: false, sec, at: null };
    });
    document.addEventListener('pointermove', (e) => {
        if (!DRAG) return;
        if (!DRAG.on) {
            if (Math.abs(e.clientY - DRAG.y) < 5) return;
            DRAG.on = true;
            closePop();
            insHide();
            document.body.classList.add('mv-dragging');
            const tr = DRAG.sec.querySelector(`tbody tr[data-rid="${CSS.escape(DRAG.rid)}"]`);
            if (tr) tr.classList.add('is-drag');
        }
        e.preventDefault();
        const rows = rowsOf(DRAG.tid);
        const trs = [...DRAG.sec.querySelectorAll('tbody tr[data-rid]')];
        if (!trs.length) return;
        let at = rows.length, y = trs[trs.length - 1].getBoundingClientRect().bottom;
        for (const tr of trs) {
            const b = tr.getBoundingClientRect();
            if (e.clientY < b.top + b.height / 2) {
                const k = rows.findIndex((r) => r.id === tr.dataset.rid);
                if (k >= 0) { at = k; y = b.top; }
                break;
            }
        }
        DRAG.at = at;
        const td = trs[0].querySelector('td');
        const tl = td.getBoundingClientRect().left;
        const tw = Math.min(DRAG.sec.getBoundingClientRect().right, window.innerWidth) - tl;
        insLine.style.left = tl + 'px';
        insLine.style.top = (y - 1) + 'px';
        insLine.style.width = Math.max(0, tw) + 'px';
        insLine.hidden = false;
    });
    function dragEnd() {
        const d = DRAG;
        DRAG = null;
        if (!d || !d.on) return;
        DRAG_END = Date.now();
        insLine.hidden = true;
        document.body.classList.remove('mv-dragging');
        box.querySelectorAll('tr.is-drag').forEach((x) => x.classList.remove('is-drag'));
        if (d.at === null) return;
        if (ED && ED.tid === d.tid) {
            if (!moveGroup(ED.draft.rows, d.rid, d.at)) return;
            refreshEdit();
            persist(true);
            return;
        }
        const before = curTable(d.tid);
        if (!before) return;
        const snap = clone(before);
        if (d.tid === HID) {
            const cols = HCFG.cols.map((c) => Object.assign({ id: c.key }, c));
            if (!moveGroup(cols, d.rid, d.at)) return;
            HCFG.cols = cols.map((c) => { const x = Object.assign({}, c); delete x.id; return x; });
        } else {
            const t = CONFIG.find((x) => x.id === d.tid);
            if (!t || !moveGroup(t.rows, d.rid, d.at)) return;
        }
        pushHist(d.tid, snap);
        render();
        quickSave(d.tid);
    }
    document.addEventListener('pointerup', dragEnd);
    document.addEventListener('pointercancel', dragEnd);

    pop.addEventListener('click', (e) => {
        const ddb = e.target.closest('.pp-ddbtn');
        if (ddb && POP) {                                  // розгорнути / згорнути список кольорів (один за раз)
            const k = ddb.closest('.pp-dd').dataset.dd;
            POP_DD = POP_DD === k ? '' : k;
            openPop(POP.btn, POP.rid, POP.tid);
            const on = pop.querySelector('.pp-dd.is-open .pp-ddlist button.is-on');
            if (on) on.scrollIntoView({ block: 'nearest' });
            return;
        }
        const b = e.target.closest('button[data-k]');
        if (!b || !POP || (!POP.quick && !ED)) return;
        const target = popTarget(POP);
        if (!target) return;
        if (POP.quick && !QS[POP.tid]) pushHist(POP.tid, curTable(POP.tid));   // кліки поспіль — один крок «↩»
        const st = target.style = target.style || {};
        const k = b.dataset.k;
        if (['b', 'i', 'ind'].includes(k)) { if (st[k]) delete st[k]; else st[k] = 1; }
        else if (b.dataset.v) st[k] = b.dataset.v; else delete st[k];
        if (b.closest('.pp-ddlist')) POP_DD = '';
        const { rid, btn, tid, quick } = POP;
        if (quick) {                                   // одразу в таблиці й одразу записати
            render();
            quickSave(tid);
            openPop(btn, rid, tid);
            return;
        }
        if (rid === '__title') {
            const sec = secOf();
            const ti = sec.querySelector('.mt-title-in');
            if (ti) ti.className = 'mt-title-in' + (st.c ? ' mc-' + st.c : '');
            const h3 = sec.querySelector('h3.mt-title');       // поголівʼя: назва не правиться, лише колір
            if (h3) h3.className = 'mt-title' + (st.c ? ' mc-' + st.c : '');
            [...sec.classList].filter((c) => /^hb-/.test(c)).forEach((c) => sec.classList.remove(c));
            lookCls(st).trim().split(/\s+/).filter(Boolean).forEach((c) => sec.classList.add(c));
        } else refreshEdit();
        persist();
        openPop(btn, rid);
    });
    document.addEventListener('mousedown', (e) => {
        if (!pop.hidden && !pop.contains(e.target) && !e.target.closest('.mr-style, .mv-mkb')) closePop();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        if (!pop.hidden) { closePop(); return; }
        if (e.target.closest && e.target.closest('.mb-name, .mt-title-in, .ed-fx')) return;
        const det = box.querySelector('.mv-det:not([hidden])');
        if (det) { closeCells(); return; }
        // курсор не в полі (клацнули перегородку, кружечок, порожнє місце) — Esc теж закриває рядок і правку
        // (Роман 2026-09-29: «нажимаю Esc — не покидаю редагування строки»)
        if (ED && !document.querySelector('.modal:not([hidden])') && !(e.target.closest && e.target.closest('input, textarea, select'))) {
            e.preventDefault();
            closeRow();
        }
    });

    if (addTableBtn) {
        const addTable = (tpl) => {
            if (ED) stopEdit();                        // записане вже записане — нову можна одразу
            const id = 'n' + Date.now().toString(36);
            const t = tpl ? Object.assign(clone(tpl), { id, _new: true })
                : { id, title: 'Нова таблиця', style: {}, _new: true, rows: [{ id: id + 'r1', type: 'row', label: '', formula: '', style: {} }] };
            t.rows.forEach((r, i) => { r.id = `${id}r${i + 1}`; });
            CONFIG.push(t);
            const at = box.querySelector(`.mt[data-tid="${HID}"]`);
            const ph = `<section class="mt" data-tid="${id}"></section>`;
            if (at) at.insertAdjacentHTML('beforebegin', ph); else box.insertAdjacentHTML('beforeend', ph);
            const em = box.querySelector('.mv-empty');
            if (em) em.remove();
            startEdit(id, tpl ? null : t.rows[0].id);  // порожня — одразу назва першого рядка
            const sec = box.querySelector(`.mt[data-tid="${id}"]`);
            if (sec) sec.scrollIntoView({ block: 'start', behavior: 'smooth' });
            if (tpl && ED) { ED.tpl = true; preview(); persist(true); }   // зразок — одразу записаний
        };
        addTableBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (!addMenu) { addTable(null); return; }
            addMenu.hidden = !addMenu.hidden;
        });
        if (addMenu) {
            addMenu.addEventListener('click', (e) => {
                const b = e.target.closest('button[data-tpl]');
                if (!b) return;
                addMenu.hidden = true;
                addTable(b.dataset.tpl === 'sample' ? (SAMPLE[0] || null) : null);
            });
            document.addEventListener('click', (e) => {
                if (!addMenu.hidden && !addMenu.contains(e.target) && e.target !== addTableBtn) addMenu.hidden = true;
            });
        }
    }
    seg.addEventListener('click', (e) => {
        const b = e.target.closest('.seg-btn');
        if (!b || b.dataset.by === by) return;
        by = b.dataset.by;
        try { localStorage.setItem(VIEW_KEY, by); } catch (er) { /* ignore */ }
        if (by === 'day' && year !== now.getFullYear()) month = 12;
        load();
    });
    document.getElementById('mvPrev').addEventListener('click', () => shift(-1));
    document.getElementById('mvNext').addEventListener('click', () => shift(1));
    document.getElementById('mvNow').addEventListener('click', () => {
        year = now.getFullYear(); month = now.getMonth() + 1; load();
    });
    window.addEventListener('beforeunload', (e) => {
        if (dirty()) { e.preventDefault(); e.returnValue = ''; }
    });
    if (addTableBtn) addTableBtn.disabled = true;      // доки не прочитали таблиці
    load();
})();
